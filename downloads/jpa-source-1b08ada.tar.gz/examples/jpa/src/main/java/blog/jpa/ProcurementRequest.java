package blog.jpa;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "purchase_request")
public class ProcurementRequest {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Version
    private long version;
    @Column(name = "tenant_id", nullable = false)
    private String tenantId;
    @Enumerated(EnumType.STRING)
    private RequestStatus status = RequestStatus.DRAFT;
    @Column(precision = 18, scale = 2, nullable = false)
    private BigDecimal total = BigDecimal.ZERO;
    @OneToMany(mappedBy = "request", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<ProcurementLine> lines = new ArrayList<>();

    protected ProcurementRequest() {}

    public ProcurementRequest(String tenantId) {
        this.tenantId = Objects.requireNonNull(tenantId);
    }

    public void addLine(String item, BigDecimal unitPrice, int quantity) {
        requireStatus(RequestStatus.DRAFT);
        if (unitPrice == null || unitPrice.signum() < 0 || quantity <= 0) {
            throw new IllegalArgumentException("Invalid line price or quantity");
        }
        BigDecimal price;
        try {
            price = unitPrice.setScale(2, RoundingMode.UNNECESSARY);
        } catch (ArithmeticException error) {
            throw new IllegalArgumentException("Price has more than two nonzero decimal places", error);
        }
        BigDecimal newTotal = total.add(price.multiply(BigDecimal.valueOf(quantity)));
        if (price.precision() > 18 || newTotal.precision() > 18) {
            throw new IllegalArgumentException("Amount exceeds numeric(18,2)");
        }
        ProcurementLine line = new ProcurementLine(this, item, price, quantity);
        lines.add(line);
        total = newTotal;
    }

    public void submit() {
        requireStatus(RequestStatus.DRAFT);
        if (lines.isEmpty()) throw new IllegalStateException("Empty request");
        status = RequestStatus.SUBMITTED;
    }

    public void approve() {
        requireStatus(RequestStatus.SUBMITTED);
        status = RequestStatus.APPROVED;
    }

    public void reject() {
        requireStatus(RequestStatus.SUBMITTED);
        status = RequestStatus.REJECTED;
    }

    public void markOrdered() {
        requireStatus(RequestStatus.APPROVED);
        status = RequestStatus.ORDERED;
    }

    private void requireStatus(RequestStatus expected) {
        if (status != expected) throw new IllegalStateException("Expected " + expected + ", got " + status);
    }

    public Long id() { return id; }
    public long version() { return version; }
    public String tenantId() { return tenantId; }
    public RequestStatus status() { return status; }
    public BigDecimal total() { return total; }
    public List<ProcurementLine> lines() { return List.copyOf(lines); }
}
