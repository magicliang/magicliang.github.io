package blog.jpa;

import jakarta.persistence.EntityManager;
import java.util.Objects;

public class ProcurementService {
    private final EntityManager manager;

    public ProcurementService(EntityManager manager) {
        this.manager = Objects.requireNonNull(manager);
    }

    public ProcurementRequest findForTenant(long requestId, String tenantId) {
        ProcurementRequest request = manager.find(ProcurementRequest.class, requestId);
        if (request == null || !request.tenantId().equals(tenantId)) {
            throw new IllegalArgumentException("Request not found");
        }
        return request;
    }

    public ProcurementOrder order(long requestId, String tenantId) {
        ProcurementRequest request = findForTenant(requestId, tenantId);
        if (request.status() == RequestStatus.ORDERED) {
            return manager.createQuery("select o from ProcurementOrder o where o.request = :request", ProcurementOrder.class)
                    .setParameter("request", request).getSingleResult();
        }
        ProcurementOrder order = new ProcurementOrder(request);
        request.markOrdered();
        manager.persist(order);
        return order;
    }
}
