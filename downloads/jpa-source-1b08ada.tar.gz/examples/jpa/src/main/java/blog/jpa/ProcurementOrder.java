package blog.jpa;

import jakarta.persistence.Entity;
import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "purchase_order")
public class ProcurementOrder {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "request_id", nullable = false, unique = true)
    private ProcurementRequest request;
    @Column(name = "tenant_id", nullable = false)
    private String tenantId;

    protected ProcurementOrder() {}

    public ProcurementOrder(ProcurementRequest request) {
        if (request.status() != RequestStatus.APPROVED) throw new IllegalStateException("Approval required");
        this.request = request;
        this.tenantId = request.tenantId();
    }

    public Long id() { return id; }
    public ProcurementRequest request() { return request; }
    public String tenantId() { return tenantId; }
}
