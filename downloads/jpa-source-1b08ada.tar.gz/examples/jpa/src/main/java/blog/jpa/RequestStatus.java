package blog.jpa;

public enum RequestStatus {
    DRAFT, SUBMITTED, APPROVED, REJECTED, ORDERED
}
