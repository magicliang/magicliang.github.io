package blog.jpa;

import jakarta.persistence.Entity;
import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "purchase_line")
public class ProcurementLine {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "request_id", nullable = false)
    private ProcurementRequest request;
    private String item;
    @Column(name = "unit_price", precision = 18, scale = 2, nullable = false)
    private BigDecimal unitPrice;
    private int quantity;

    protected ProcurementLine() {}

    ProcurementLine(ProcurementRequest request, String item, BigDecimal unitPrice, int quantity) {
        this.request = Objects.requireNonNull(request);
        this.item = Objects.requireNonNull(item);
        this.unitPrice = unitPrice;
        this.quantity = quantity;
    }

    public Long id() { return id; }
    public String item() { return item; }
    public BigDecimal unitPrice() { return unitPrice; }
    public int quantity() { return quantity; }
}
