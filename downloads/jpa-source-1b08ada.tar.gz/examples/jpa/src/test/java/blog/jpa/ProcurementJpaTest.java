package blog.jpa;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import java.math.BigDecimal;
import org.hibernate.SessionFactory;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProcurementJpaTest {
    private static EntityManagerFactory factory;

    @BeforeAll
    static void start() { factory = DatabaseSupport.factory(); }

    @AfterAll
    static void stop() { if (factory != null) factory.close(); }

    @Test
    void lifecycleAndServerCalculatedTotal() {
        String tenant = DatabaseSupport.tenant();
        try (EntityManager manager = factory.createEntityManager()) {
            manager.getTransaction().begin();
            ProcurementRequest request = new ProcurementRequest(tenant);
            request.addLine("paper", new BigDecimal("2.25"), 3);
            manager.persist(request);
            assertSame(request, manager.find(ProcurementRequest.class, request.id()));
            manager.getTransaction().commit();
            manager.clear();
            ProcurementRequest restored = manager.find(ProcurementRequest.class, request.id());
            assertNotSame(request, restored);
            assertEquals(0, restored.total().compareTo(new BigDecimal("6.75")));
            assertEquals(1, restored.lines().size());
        }
    }

    @Test
    void rejectsPrecisionLossBeforePersistAndKeepsStoredTotalEqualToLines() {
        String tenant = DatabaseSupport.tenant();
        long requestId;
        try (EntityManager manager = factory.createEntityManager()) {
            manager.getTransaction().begin();
            ProcurementRequest request = new ProcurementRequest(tenant);
            assertThrows(IllegalArgumentException.class, () -> request.addLine("fraction", new BigDecimal("19.905"), 1));
            assertThrows(IllegalArgumentException.class, () -> request.addLine("fraction", new BigDecimal("0.005"), 1));
            request.addLine("first", new BigDecimal("19.90"), 1);
            request.addLine("second", new BigDecimal("0.01"), 1);
            manager.persist(request);
            manager.getTransaction().commit();
            requestId = request.id();
        }
        try (EntityManager manager = factory.createEntityManager()) {
            ProcurementRequest restored = manager.find(ProcurementRequest.class, requestId);
            BigDecimal sum = restored.lines().stream().map(line -> line.unitPrice()
                    .multiply(BigDecimal.valueOf(line.quantity()))).reduce(BigDecimal.ZERO, BigDecimal::add);
            assertEquals(0, restored.total().compareTo(sum));
            assertEquals(2, restored.lines().size());
        }
    }

    @Test
    void rollbackAfterFlushDoesNotPersistTransition() {
        String tenant = DatabaseSupport.tenant();
        long requestId;
        try (EntityManager manager = factory.createEntityManager()) {
            manager.getTransaction().begin();
            ProcurementRequest request = new ProcurementRequest(tenant);
            request.addLine("paper", new BigDecimal("2.25"), 1);
            manager.persist(request);
            manager.getTransaction().commit();
            requestId = request.id();
        }
        try (EntityManager manager = factory.createEntityManager()) {
            manager.getTransaction().begin();
            manager.find(ProcurementRequest.class, requestId).submit();
            manager.flush();
            manager.getTransaction().rollback();
        }
        try (EntityManager manager = factory.createEntityManager()) {
            assertEquals(RequestStatus.DRAFT, manager.find(ProcurementRequest.class, requestId).status());
        }
    }

    @Test
    void uniqueOrderAndTenantAndRetry() {
        String tenant = DatabaseSupport.tenant();
        long requestId;
        try (EntityManager manager = factory.createEntityManager()) {
            requestId = DatabaseSupport.submitted(manager, tenant);
            manager.getTransaction().begin();
            manager.find(ProcurementRequest.class, requestId).approve();
            manager.getTransaction().commit();
        }
        try (EntityManager manager = factory.createEntityManager()) {
            manager.getTransaction().begin();
            ProcurementService service = new ProcurementService(manager);
            assertThrows(IllegalArgumentException.class, () -> service.order(requestId, "other-tenant"));
            ProcurementOrder first = service.order(requestId, tenant);
            ProcurementOrder second = service.order(requestId, tenant);
            assertEquals(first.id(), second.id());
            manager.getTransaction().commit();
        }
        try (EntityManager manager = factory.createEntityManager()) {
            manager.getTransaction().begin();
            ProcurementOrder retry = new ProcurementService(manager).order(requestId, tenant);
            assertNotNull(retry.id());
            manager.getTransaction().commit();
            Long count = manager.createQuery("select count(o) from ProcurementOrder o where o.request.id = :id", Long.class)
                    .setParameter("id", requestId).getSingleResult();
            assertEquals(1L, count);
        }
    }

    @Test
    void optimisticConflictWithControlledInterleaving() {
        String tenant = DatabaseSupport.tenant();
        long requestId;
        try (EntityManager setup = factory.createEntityManager()) {
            requestId = DatabaseSupport.submitted(setup, tenant);
        }
        try (EntityManager first = factory.createEntityManager(); EntityManager second = factory.createEntityManager()) {
            first.getTransaction().begin();
            second.getTransaction().begin();
            ProcurementRequest firstCopy = first.find(ProcurementRequest.class, requestId);
            ProcurementRequest secondCopy = second.find(ProcurementRequest.class, requestId);
            firstCopy.approve();
            secondCopy.reject();
            first.getTransaction().commit();
            assertThrows(RuntimeException.class, () -> second.getTransaction().commit());
            if (second.getTransaction().isActive()) second.getTransaction().rollback();
        }
        try (EntityManager check = factory.createEntityManager()) {
            assertEquals(RequestStatus.APPROVED, check.find(ProcurementRequest.class, requestId).status());
        }
    }

    @Test
    void jpqlCriteriaNativeAndBulkContextBoundary() {
        String tenant = DatabaseSupport.tenant();
        long requestId;
        try (EntityManager manager = factory.createEntityManager()) {
            requestId = DatabaseSupport.submitted(manager, tenant);
        }
        try (EntityManager manager = factory.createEntityManager()) {
            var page = manager.createQuery("select r.id from ProcurementRequest r where r.tenantId = :tenant order by r.id", Long.class)
                    .setParameter("tenant", tenant).setFirstResult(0).setMaxResults(1).getResultList();
            assertEquals(java.util.List.of(requestId), page);

            CriteriaBuilder builder = manager.getCriteriaBuilder();
            CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
            Root<ProcurementRequest> root = criteria.from(ProcurementRequest.class);
            criteria.select(builder.count(root)).where(builder.equal(root.get("tenantId"), tenant));
            assertEquals(1L, manager.createQuery(criteria).getSingleResult());
            assertEquals(0, ((BigDecimal) manager.createNativeQuery("select total from purchase_request where id = :id")
                    .setParameter("id", requestId).getSingleResult()).compareTo(new BigDecimal("7.00")));

            manager.getTransaction().begin();
            ProcurementRequest managed = manager.find(ProcurementRequest.class, requestId);
            int updated = manager.createQuery("update ProcurementRequest r set r.status = :next where r.id = :id")
                    .setParameter("next", RequestStatus.APPROVED).setParameter("id", requestId).executeUpdate();
            assertEquals(1, updated);
            assertEquals(RequestStatus.SUBMITTED, managed.status());
            manager.clear();
            assertEquals(RequestStatus.APPROVED, manager.find(ProcurementRequest.class, requestId).status());
            manager.getTransaction().commit();
        }
    }

    @Test
    void hibernateSpecificQueryCountContrastsLazyFetch() {
        String tenant = DatabaseSupport.tenant();
        try (EntityManager setup = factory.createEntityManager()) {
            for (int index = 0; index < 3; index++) DatabaseSupport.submitted(setup, tenant);
        }
        var statistics = factory.unwrap(SessionFactory.class).getStatistics();
        statistics.setStatisticsEnabled(true);
        try (EntityManager manager = factory.createEntityManager()) {
            statistics.clear();
            var requests = manager.createQuery("select r from ProcurementRequest r where r.tenantId = :tenant order by r.id", ProcurementRequest.class)
                    .setParameter("tenant", tenant).getResultList();
            for (ProcurementRequest request : requests) assertEquals(1, request.lines().size());
            assertEquals(4L, statistics.getPrepareStatementCount());
        }
        try (EntityManager manager = factory.createEntityManager()) {
            statistics.clear();
            var requests = manager.createQuery("select distinct r from ProcurementRequest r left join fetch r.lines where r.tenantId = :tenant order by r.id", ProcurementRequest.class)
                    .setParameter("tenant", tenant).getResultList();
            assertEquals(3, requests.size());
            for (ProcurementRequest request : requests) assertEquals(1, request.lines().size());
            assertEquals(1L, statistics.getPrepareStatementCount());
        }
    }
}
