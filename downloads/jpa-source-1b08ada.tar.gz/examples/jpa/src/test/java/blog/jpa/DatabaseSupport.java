package blog.jpa;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.util.Map;
import java.util.UUID;

final class DatabaseSupport {
    private DatabaseSupport() {}

    static EntityManagerFactory factory() {
        String url = required("JPA_LAB_JDBC_URL");
        String username = required("JPA_LAB_USER");
        String password = required("JPA_LAB_PASSWORD");
        if (!url.endsWith("/jpa_lab")) throw new IllegalStateException("Only isolated jpa_lab database is permitted");
        return Persistence.createEntityManagerFactory("procurement", Map.of(
                "jakarta.persistence.jdbc.url", url,
                "jakarta.persistence.jdbc.user", username,
                "jakarta.persistence.jdbc.password", password,
                "jakarta.persistence.jdbc.driver", "org.postgresql.Driver"));
    }

    private static String required(String key) {
        String value = System.getenv(key);
        if (value == null || value.isBlank()) throw new IllegalStateException("Missing " + key);
        return value;
    }

    static String tenant() { return "tenant-" + UUID.randomUUID(); }

    static long submitted(EntityManager manager, String tenant) {
        manager.getTransaction().begin();
        ProcurementRequest request = new ProcurementRequest(tenant);
        request.addLine("stationery", new java.math.BigDecimal("3.50"), 2);
        request.submit();
        manager.persist(request);
        manager.getTransaction().commit();
        return request.id();
    }
}
