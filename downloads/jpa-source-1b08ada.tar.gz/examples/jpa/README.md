# JPA 采购审批累计工程

与 Java EE 系列相同的采购状态与 PostgreSQL 16 表语义，但使用独立数据库 `jpa_lab`，本地 JPA `RESOURCE_LOCAL` 事务；不会自动连接生产库，也不以本地事务代替 JTA。规范 Jakarta Persistence 3.2，实现 Hibernate ORM 7.1.36.Final，Java 21、pgJDBC 42.7.7。先在本机创建**专用**角色 `jpa_lab` 和独立数据库 `jpa_lab`，审阅 `db/migrations/01-init.sql`，在仓库根目录执行下列命令；把引号内口令换成本地真实口令，切勿提交（禁止在共享数据库执行）：

```bash
cd examples/jpa
export JPA_LAB_PSQL_URL='postgresql://127.0.0.1:5432/jpa_lab'
export JPA_LAB_JDBC_URL=jdbc:postgresql://127.0.0.1:5432/jpa_lab
export JPA_LAB_USER='jpa_lab'
export JPA_LAB_PASSWORD='replace-with-your-local-password'
bash ./migrate-lab.sh
../hibernate-lab/mvnw -B -ntp -f "$PWD/pom.xml" clean test
```

运行测试前必须检查环境变量；缺失时故意失败而非暗中跳过。测试对专用库插入带随机租户名的合成数据，不自动清空现存数据；版本为 `hibernate.hbm2ddl.auto=validate`，建表靠迁移脚本。真实 PostgreSQL 的并发读写通过两个 EntityManager 可控交错；只有 `RESOURCE_LOCAL` 实验，JTA、XA、容器注入和第二 provider 均不能由此证明。

2026-10-04 的六项累计 PostgreSQL 16 回归及代码 SHA、退出码、原始输出和结果边界见 `../../writing-plans/jpa/verification/20261004T053805Z-pg16-resource-local/RUN.md`。覆盖身份与金额、flush/rollback、租户与订单重试、乐观锁、JPQL/Criteria/原生 SQL/bulk、Hibernate 统计计数的抓取对照；**未覆盖** Embeddable、继承、JTA、悲观锁超时、缓存、EntityGraph、跨行写偏差、旧库迁移或吞吐量。不能把六个测试映射成十二篇全部实验通过。
