#!/usr/bin/env bash
set -euo pipefail

: "${JPA_LAB_PSQL_URL:?Set JPA_LAB_PSQL_URL for the isolated jpa_lab database}"
: "${JPA_LAB_JDBC_URL:?Set JPA_LAB_JDBC_URL}"
: "${JPA_LAB_USER:?Set JPA_LAB_USER}"
: "${JPA_LAB_PASSWORD:?Set JPA_LAB_PASSWORD}"

if [[ "$JPA_LAB_PSQL_URL" != 'postgresql://127.0.0.1:5432/jpa_lab' ||
      "$JPA_LAB_JDBC_URL" != 'jdbc:postgresql://127.0.0.1:5432/jpa_lab' ||
      "$JPA_LAB_USER" != 'jpa_lab' ]]; then
    printf 'Refusing migration: expected isolated localhost jpa_lab and jpa_lab role\n' >&2
    exit 2
fi

identity=$(PGPASSWORD="$JPA_LAB_PASSWORD" psql "$JPA_LAB_PSQL_URL" -X -A -t -v ON_ERROR_STOP=1 \
    -U "$JPA_LAB_USER" -c "SELECT current_database() || '|' || current_user")
if [[ "$identity" != 'jpa_lab|jpa_lab' ]]; then
    printf 'Refusing migration: connected to the wrong database or role\n' >&2
    exit 2
fi

PGPASSWORD="$JPA_LAB_PASSWORD" psql "$JPA_LAB_PSQL_URL" -X -v ON_ERROR_STOP=1 \
    -U "$JPA_LAB_USER" -f "$(dirname "$0")/db/migrations/01-init.sql"
