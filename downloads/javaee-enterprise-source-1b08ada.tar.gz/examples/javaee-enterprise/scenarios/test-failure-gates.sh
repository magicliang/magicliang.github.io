#!/usr/bin/env bash
set -euo pipefail

base=$(cd "$(dirname "$0")" && pwd)
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
printf 'candidate' >"$scratch/candidate.war"
cat >"$scratch/psql-fail" <<'EOF'
#!/usr/bin/env bash
printf 'preflight error\n' >&2
exit 3
EOF
cat >"$scratch/psql-permission" <<'EOF'
#!/usr/bin/env bash
printf 'ERROR:  42501: permission denied for table purchase_request\n' >&2
exit 3
EOF
cat >"$scratch/psql-check" <<'EOF'
#!/usr/bin/env bash
sql=$(cat)
if [[ "$sql" == *'SELECT count(*)'* ]]; then
    printf '0\n'
else
    printf 'ERROR:  23514: new row violates check constraint "valid_request_state"\n' >&2
    exit 3
fi
EOF
chmod +x "$scratch"/psql-*
export JAVAEE_LAB_USER=javaee_lab JAVAEE_LAB_PASSWORD=test-only JAVAEE_STAGE_DIR="$scratch"
if PSQL="$scratch/psql-fail" bash "$base/38-preflight-and-stage.sh" \
    "$scratch/candidate.war" "$scratch/staged.war" >"$scratch/gate.out" 2>&1; then
    printf 'Preflight failure was accepted\n' >&2; exit 1
fi
[[ ! -e "$scratch/staged.war" ]] || { printf 'Downstream copy ran\n' >&2; exit 1; }
if PSQL="$scratch/psql-permission" bash "$base/35-check-constraint.sh" >"$scratch/permission.out" 2>&1; then
    printf 'Permission error was misreported as CHECK rejection\n' >&2; exit 1
fi
PSQL="$scratch/psql-check" bash "$base/35-check-constraint.sh" >"$scratch/check.out"
printf 'preflight failure blocked downstream copy; permission error rejected; CHECK mock accepted\n'
