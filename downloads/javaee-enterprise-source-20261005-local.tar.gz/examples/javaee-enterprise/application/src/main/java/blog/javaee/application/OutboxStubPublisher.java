package blog.javaee.application;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.util.OptionalLong;

@ApplicationScoped
public class OutboxStubPublisher {
    @Inject
    private OutboxStubStore store;

    @Transactional
    public OptionalLong attempt(String tenantId, boolean abortAfterUpdate) {
        OptionalLong eventId = store.recordAttempt(tenantId);
        if (abortAfterUpdate && eventId.isPresent()) {
            throw new IllegalStateException("Injected failure after outbox attempt");
        }
        return eventId;
    }
}
