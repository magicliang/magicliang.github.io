package blog.javaee.application;

import blog.javaee.domain.LineItem;
import blog.javaee.domain.ProcurementRequest;
import blog.javaee.domain.RequestState;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import java.util.List;
import java.util.Objects;

@ApplicationScoped
public class ProcurementUseCases {
    private final RequestStore store;
    private final PriceCatalog catalog;

    protected ProcurementUseCases() {
        this.store = null;
        this.catalog = null;
    }

    @Inject
    public ProcurementUseCases(RequestStore store, PriceCatalog catalog) {
        this.store = Objects.requireNonNull(store);
        this.catalog = Objects.requireNonNull(catalog);
    }

    public record ItemInput(String sku, int quantity) {}

    @Transactional
    public long draft(String tenantId, List<ItemInput> items) {
        if (items == null) throw new IllegalArgumentException("Missing items");
        List<LineItem> lines = items.stream().map(input ->
                new LineItem(input.sku(), catalog.priceFor(input.sku()), input.quantity())).toList();
        return store.insert(ProcurementRequest.draft(tenantId, lines));
    }

    @Transactional
    public void draftThenAbortForLab(String tenantId, List<ItemInput> items) {
        if (!"true".equals(System.getenv("JAVAEE_DEMO_MODE"))) throw new IllegalStateException("Lab mode disabled");
        draft(tenantId, items);
        throw new IllegalStateException("Injected failure after JDBC inserts");
    }

    @Transactional
    public void submit(long id, String tenantId) { change(id, tenantId, RequestState.SUBMITTED); }

    @Transactional
    public void approve(long id, String tenantId) { change(id, tenantId, RequestState.APPROVED); }

    @Transactional
    public void reject(long id, String tenantId) { change(id, tenantId, RequestState.REJECTED); }

    @Transactional
    public long order(long id, String tenantId) {
        ProcurementRequest request = store.find(id, tenantId);
        if (request.state() == RequestState.ORDERED) return store.findOrder(id, tenantId);
        requireTransition(request, RequestState.ORDERED);
        long orderId = store.insertOrder(id, tenantId);
        store.transition(request, RequestState.ORDERED);
        store.enqueueOrderCreated(id, tenantId, orderId);
        return orderId;
    }

    private void change(long id, String tenantId, RequestState next) {
        ProcurementRequest request = store.find(id, tenantId);
        requireTransition(request, next);
        store.transition(request, next);
    }

    private void requireTransition(ProcurementRequest request, RequestState next) {
        try {
            request.transition(next);
        } catch (IllegalStateException error) {
            throw new RequestConflictException(error.getMessage());
        }
    }
}
