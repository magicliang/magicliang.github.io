package blog.javaee.application;

public class RequestMissingException extends RuntimeException {
    public RequestMissingException() { super("Request not found"); }
}
