package blog.javaee.application;

import blog.javaee.domain.ProcurementRequest;
import blog.javaee.domain.RequestState;

public interface RequestStore {
    long insert(ProcurementRequest request);
    ProcurementRequest find(long id, String tenantId);
    void transition(ProcurementRequest before, RequestState next);
    long insertOrder(long requestId, String tenantId);
    long findOrder(long requestId, String tenantId);
    void enqueueOrderCreated(long requestId, String tenantId, long orderId);
}
