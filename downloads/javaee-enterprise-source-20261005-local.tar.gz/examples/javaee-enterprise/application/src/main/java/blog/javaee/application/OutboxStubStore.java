package blog.javaee.application;

import java.util.OptionalLong;

public interface OutboxStubStore {
    OptionalLong recordAttempt(String tenantId);
}
