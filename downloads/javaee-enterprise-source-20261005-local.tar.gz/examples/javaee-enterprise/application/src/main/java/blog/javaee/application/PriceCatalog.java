package blog.javaee.application;

import java.math.BigDecimal;

public interface PriceCatalog {
    BigDecimal priceFor(String sku);
}
