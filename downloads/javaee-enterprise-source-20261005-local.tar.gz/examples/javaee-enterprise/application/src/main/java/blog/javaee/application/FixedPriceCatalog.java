package blog.javaee.application;

import jakarta.enterprise.context.ApplicationScoped;
import java.math.BigDecimal;
import java.util.Map;

@ApplicationScoped
public class FixedPriceCatalog implements PriceCatalog {
    private static final Map<String, BigDecimal> PRICES = Map.of(
            "paper", new BigDecimal("3.50"), "pen", new BigDecimal("2.25"));

    @Override
    public BigDecimal priceFor(String sku) {
        BigDecimal price = PRICES.get(sku);
        if (price == null) throw new IllegalArgumentException("Unknown product");
        return price;
    }
}
