package blog.javaee.comparison;

import java.math.BigDecimal;
import javax.sql.DataSource;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@MapperScan("blog.javaee.comparison")
@EnableTransactionManagement
public class ComparisonApp {
    public static void main(String[] args) { SpringApplication.run(ComparisonApp.class, args); }

    @Bean
    PlatformTransactionManager transactionManager(DataSource database) {
        return new DataSourceTransactionManager(database);
    }

    @Bean
    ApplicationRunner labApproval(ApprovalService service) {
        return (ApplicationArguments args) -> {
            if (!"true".equals(System.getenv("COMPARE_LAB_RUN"))) return;
            service.approve(System.getenv("COMPARE_ACTOR"), System.getenv("COMPARE_TENANT"),
                    Long.parseLong(System.getenv("COMPARE_REQUEST_ID")),
                    Long.parseLong(System.getenv("COMPARE_EXPECTED_VERSION")),
                    new BigDecimal(System.getenv("COMPARE_LIMIT")),
                    "true".equals(System.getenv("COMPARE_FAIL_AFTER_UPDATE")));
        };
    }
}
