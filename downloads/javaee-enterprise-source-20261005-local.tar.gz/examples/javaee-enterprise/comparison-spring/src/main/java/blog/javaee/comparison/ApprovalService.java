package blog.javaee.comparison;

import java.math.BigDecimal;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ApprovalService {
    private final ApprovalMapper mapper;

    public ApprovalService(ApprovalMapper mapper) { this.mapper = mapper; }

    @Transactional
    public void approve(String actor, String tenant, long id, long expectedVersion,
                        BigDecimal limit, boolean failAfterUpdate) {
        if (actor == null || actor.isBlank() || tenant == null || tenant.isBlank() || id <= 0 || limit.signum() < 0) {
            throw new IllegalArgumentException("Invalid lab actor/approval");
        }
        if (mapper.approve(id, tenant, expectedVersion, limit) != 1) {
            throw new IllegalStateException("No authorized pending row at expected version");
        }
        if (failAfterUpdate) throw new IllegalStateException("Injected before audit");
        mapper.audit(id, tenant, actor);
    }
}
