package blog.javaee.comparison;

import java.math.BigDecimal;
import org.apache.ibatis.annotations.Param;

public interface ApprovalMapper {
    int approve(@Param("id") long id, @Param("tenant") String tenant,
                @Param("version") long version, @Param("limit") BigDecimal limit);

    int audit(@Param("id") long id, @Param("tenant") String tenant, @Param("actor") String actor);
}
