import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class SupplierStub {
    private static final Pattern IDENTIFIER = Pattern.compile("[A-Za-z0-9._-]{1,80}");
    private static final Pattern ORDER_BODY = Pattern.compile("\\{\\s*\"orderId\"\\s*:\\s*([1-9][0-9]*)\\s*,\\s*\"taskId\"\\s*:\\s*\"([A-Za-z0-9._-]{1,80})\"\\s*(?:,\\s*\"supplierId\"\\s*:\\s*\"([A-Za-z0-9._-]{1,80})\")?\\s*\\}");
    private static final int MAX_BODY = 4096;
    private final Path directory;
    private final Map<String, Entry> ledger = new HashMap<>();
    private final Map<String, Fault> faults = new HashMap<>();
    private final Map<String, Fault> inFlight = new HashMap<>();
    private long nextOrder = 1;

    private static final class Entry {
        final String supplier;
        final String key;
        final String task;
        final long requestedOrder;
        final long supplierOrder;
        final long attempts;
        final String state;

        Entry(String supplier, String key, String task, long requestedOrder, long supplierOrder, long attempts,
              String state) {
            this.supplier = supplier;
            this.key = key;
            this.task = task;
            this.requestedOrder = requestedOrder;
            this.supplierOrder = supplierOrder;
            this.attempts = attempts;
            this.state = state;
        }
    }

    private static final class Fault {
        final String mode;
        final CountDownLatch accepted = new CountDownLatch(1);
        final CountDownLatch release = new CountDownLatch(1);

        Fault(String mode) {
            this.mode = mode;
        }
    }

    private SupplierStub(Path directory) throws IOException {
        this.directory = directory;
        Files.createDirectories(directory);
        Path snapshot = directory.resolve("ledger.tsv");
        if (!Files.exists(snapshot)) {
            return;
        }
        String[] lines = Files.readString(snapshot).split("\n", -1);
        if (lines.length < 2 || !lines[0].matches("2\\t[1-9][0-9]*")) {
            throw new IOException("Invalid ledger header");
        }
        nextOrder = Long.parseLong(lines[0].substring(2));
        long maxOrder = 0;
        for (int index = 1; index < lines.length - 1; index++) {
            String[] fields = lines[index].split("\t", -1);
            if (fields.length != 7 || !valid(fields[0]) || !valid(fields[1]) || !valid(fields[2])) {
                throw new IOException("Invalid ledger entry");
            }
            Entry entry = new Entry(fields[0], fields[1], fields[2], Long.parseLong(fields[3]),
                    Long.parseLong(fields[4]), Long.parseLong(fields[5]), fields[6]);
            if (entry.requestedOrder <= 0 || entry.supplierOrder < 0 || entry.attempts <= 0
                    || !(entry.state.equals("CONFIRMED") && entry.supplierOrder > 0
                         || entry.state.equals("REJECTED") && entry.supplierOrder == 0
                         || entry.state.equals("RETRYABLE") && entry.supplierOrder == 0)
                    || ledger.putIfAbsent(composite(entry.supplier, entry.key), entry) != null) {
                throw new IOException("Invalid or duplicate ledger entry");
            }
            maxOrder = Math.max(maxOrder, entry.supplierOrder);
        }
        if (!lines[lines.length - 1].isEmpty() || nextOrder <= maxOrder) {
            throw new IOException("Truncated or inconsistent ledger");
        }
    }

    private static boolean valid(String input) {
        return input != null && IDENTIFIER.matcher(input).matches();
    }

    private static String composite(String supplier, String key) {
        return supplier + "/" + key;
    }

    private void save(Map<String, Entry> updated, long next) throws IOException {
        StringBuilder text = new StringBuilder("2\t").append(next).append('\n');
        for (Entry entry : new TreeMap<>(updated).values()) {
            text.append(entry.supplier).append('\t').append(entry.key).append('\t')
                    .append(entry.task).append('\t').append(entry.requestedOrder).append('\t')
                    .append(entry.supplierOrder).append('\t').append(entry.attempts).append('\t')
                    .append(entry.state).append('\n');
        }
        Path temporary = Files.createTempFile(directory, "ledger-", ".tmp");
        try {
            try (FileChannel channel = FileChannel.open(temporary, StandardOpenOption.WRITE)) {
                ByteBuffer buffer = StandardCharsets.UTF_8.encode(text.toString());
                while (buffer.hasRemaining()) {
                    channel.write(buffer);
                }
                channel.force(true);
            }
            try {
                Files.move(temporary, directory.resolve("ledger.tsv"), StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException exception) {
                throw new IOException("Atomic ledger replacement is required", exception);
            }
            try (FileChannel channel = FileChannel.open(directory, StandardOpenOption.READ)) {
                channel.force(true);
            }
        } finally {
            Files.deleteIfExists(temporary);
        }
    }

    private synchronized Entry attempt(String supplier, String key, String task, long requestedOrder, String mode)
            throws IOException {
        String composite = composite(supplier, key);
        Entry previous = ledger.get(composite);
        long attempts = previous == null ? 1 : Math.addExact(previous.attempts, 1);
        long supplierOrder = previous == null ? 0 : previous.supplierOrder;
        boolean conflict = previous != null && (!previous.task.equals(task) || previous.requestedOrder != requestedOrder);
        if (!conflict && supplierOrder == 0 && (previous == null || !previous.state.equals("REJECTED"))
                && !mode.equals("error-422") && !mode.equals("error-503")) {
            supplierOrder = nextOrder;
        }
        String state = previous != null && (conflict || previous.state.equals("REJECTED"))
                ? previous.state : supplierOrder != 0 ? "CONFIRMED"
                : mode.equals("error-422") ? "REJECTED" : "RETRYABLE";
        Entry updated = new Entry(supplier, key, previous == null ? task : previous.task,
                previous == null ? requestedOrder : previous.requestedOrder, supplierOrder, attempts, state);
        Map<String, Entry> copy = new HashMap<>(ledger);
        copy.put(composite, updated);
        long newNext = supplierOrder == nextOrder ? Math.addExact(nextOrder, 1) : nextOrder;
        save(copy, newNext);
        ledger.clear();
        ledger.putAll(copy);
        nextOrder = newNext;
        return updated;
    }

    private static Map<String, String> query(URI uri) {
        Map<String, String> result = new HashMap<>();
        if (uri.getRawQuery() != null) {
            for (String pair : uri.getRawQuery().split("&")) {
                String[] parts = pair.split("=", -1);
                if (parts.length != 2 || result.putIfAbsent(parts[0], parts[1]) != null) {
                    throw new IllegalArgumentException("Invalid query");
                }
            }
        }
        return result;
    }

    private static void respond(HttpExchange exchange, int code, String json) throws IOException {
        byte[] body = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.getResponseHeaders().set("Cache-Control", "no-store");
        exchange.sendResponseHeaders(code, body.length);
        try (var output = exchange.getResponseBody()) {
            output.write(body);
        }
    }

    private static String result(Entry entry) {
        return "{\"supplierId\":\"" + entry.supplier + "\",\"idempotencyKey\":\"" + entry.key
                + "\",\"taskId\":\"" + entry.task + "\",\"orderId\":" + entry.requestedOrder
                + ",\"supplierOrderId\":" + entry.supplierOrder + ",\"requestCount\":" + entry.attempts
                + ",\"state\":\"" + entry.state + "\"}";
    }

    private void handle(HttpExchange exchange) throws IOException {
        String path = exchange.getRequestURI().getRawPath();
        String method = exchange.getRequestMethod();
        Map<String, String> params;
        try {
            params = query(exchange.getRequestURI());
        } catch (IllegalArgumentException exception) {
            respond(exchange, 400, "{\"error\":\"invalid_query\"}");
            return;
        }
        if (path.equals("/health") && method.equals("GET")) {
            respond(exchange, 200, "{\"status\":\"ready\"}");
        } else if (path.equals("/orders") && method.equals("POST")) {
            order(exchange);
        } else if (path.startsWith("/orders/by-key/") && method.equals("GET")) {
            String key = path.substring("/orders/by-key/".length());
            String supplier = params.getOrDefault("supplierId", "demo-supplier");
            if (!valid(key) || !valid(supplier)) {
                respond(exchange, 400, "{\"error\":\"invalid_key\"}");
                return;
            }
            Entry entry;
            synchronized (this) {
                entry = ledger.get(composite(supplier, key));
            }
            respond(exchange, entry == null || entry.supplierOrder == 0 ? 404 : 200,
                    entry == null ? "{\"error\":\"not_found\"}" : result(entry));
        } else if (path.equals("/stats") && method.equals("GET")) {
            synchronized (this) {
                long orders = ledger.values().stream().filter(entry -> entry.supplierOrder != 0).count();
                long requests = ledger.values().stream().mapToLong(entry -> entry.attempts).sum();
                respond(exchange, 200, "{\"orders\":" + orders + ",\"requests\":" + requests + "}");
            }
        } else if (path.startsWith("/control/fault/") && method.equals("POST")) {
            String key = path.substring("/control/fault/".length());
            String mode = params.get("mode");
            if (!valid(key) || !valid(params.getOrDefault("supplierId", "demo-supplier"))
                    || mode == null || !mode.matches("slow-response|error-422|error-503|committed-then-disconnect|committed-500")) {
                respond(exchange, 400, "{\"error\":\"invalid_fault\"}");
                return;
            }
            synchronized (this) {
                String composite = composite(params.getOrDefault("supplierId", "demo-supplier"), key);
                if (faults.containsKey(composite)) {
                    respond(exchange, 409, "{\"error\":\"fault_already_armed\"}");
                    return;
                }
                faults.put(composite, new Fault(mode));
            }
            respond(exchange, 200, "{\"armed\":true}");
        } else if (path.startsWith("/control/wait/") && method.equals("GET")) {
            String key = path.substring("/control/wait/".length());
            Fault fault;
            synchronized (this) {
                String composite = composite(params.getOrDefault("supplierId", "demo-supplier"), key);
                fault = inFlight.get(composite);
                if (fault == null) {
                    fault = faults.get(composite);
                }
            }
            if (!valid(key) || fault == null || !fault.mode.equals("slow-response")) {
                respond(exchange, 404, "{\"error\":\"no_slow_fault\"}");
                return;
            }
            try {
                boolean accepted = fault.accepted.await(5, TimeUnit.SECONDS);
                respond(exchange, accepted ? 200 : 408, "{\"accepted\":" + accepted + "}");
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                respond(exchange, 503, "{\"error\":\"interrupted\"}");
            }
        } else if (path.startsWith("/control/release/") && method.equals("POST")) {
            String key = path.substring("/control/release/".length());
            Fault fault;
            synchronized (this) {
                fault = inFlight.remove(composite(params.getOrDefault("supplierId", "demo-supplier"), key));
            }
            if (!valid(key) || fault == null || !fault.mode.equals("slow-response")) {
                respond(exchange, 404, "{\"error\":\"no_slow_fault\"}");
                return;
            }
            fault.release.countDown();
            respond(exchange, 200, "{\"released\":true}");
        } else {
            respond(exchange, 404, "{\"error\":\"not_found\"}");
        }
    }

    private void order(HttpExchange exchange) throws IOException {
        if (!"application/json".equalsIgnoreCase(exchange.getRequestHeaders().getFirst("Content-Type"))) {
            respond(exchange, 415, "{\"error\":\"json_required\"}");
            return;
        }
        byte[] bytes = exchange.getRequestBody().readNBytes(MAX_BODY + 1);
        Matcher matcher = ORDER_BODY.matcher(new String(bytes, StandardCharsets.UTF_8));
        String key = exchange.getRequestHeaders().getFirst("Idempotency-Key");
        if (bytes.length > MAX_BODY || !matcher.matches() || !valid(key)) {
            respond(exchange, 400, "{\"error\":\"invalid_order\"}");
            return;
        }
        long requestedOrder;
        try {
            requestedOrder = Long.parseLong(matcher.group(1));
        } catch (NumberFormatException exception) {
            respond(exchange, 400, "{\"error\":\"invalid_order_id\"}");
            return;
        }
        String task = matcher.group(2);
        String supplier = matcher.group(3) == null ? "demo-supplier" : matcher.group(3);
        String composite = composite(supplier, key);
        Fault fault;
        Entry previous;
        Entry entry;
        synchronized (this) {
            fault = faults.remove(composite);
            previous = ledger.get(composite);
            String mode = fault == null ? "success" : fault.mode;
            if (previous != null && previous.supplierOrder != 0
                    && (mode.equals("error-422") || mode.equals("error-503"))) {
                mode = "success";
            }
            try {
                entry = attempt(supplier, key, task, requestedOrder, mode);
            } catch (IOException exception) {
                System.err.println("ledger_write_failed at=" + Instant.now() + " reason=" + exception.getMessage());
                Runtime.getRuntime().halt(3);
                return;
            }
            if (fault != null && fault.mode.equals("slow-response")) {
                inFlight.put(composite, fault);
            }
        }
        String mode = fault == null ? "success" : fault.mode;
        boolean conflict = previous != null && (!previous.task.equals(task) || previous.requestedOrder != requestedOrder);
        System.out.println("accepted at=" + Instant.now() + " supplier=" + supplier + " key=" + key
                + " mode=" + mode + " attempt=" + entry.attempts + " supplierOrderId=" + entry.supplierOrder
                + " conflict=" + conflict);
        if (fault != null) {
            fault.accepted.countDown();
        }
        if (conflict) {
            respond(exchange, 409, "{\"error\":\"same_key_different_payload\"}");
        } else if (entry.state.equals("REJECTED")) {
            respond(exchange, 422, "{\"error\":\"business_rejected\"}");
        } else if (mode.equals("error-503") && entry.supplierOrder == 0) {
            respond(exchange, 503, "{\"error\":\"temporary_error\"}");
        } else if (mode.equals("committed-500")) {
            respond(exchange, 500, "{\"error\":\"response_failed_after_commit\"}");
        } else if (mode.equals("committed-then-disconnect")) {
            exchange.close();
        } else {
            if (fault != null && mode.equals("slow-response")) {
                try {
                    if (!fault.release.await(30, TimeUnit.SECONDS)) {
                        synchronized (this) {
                            inFlight.remove(composite, fault);
                        }
                        respond(exchange, 504, "{\"error\":\"release_deadline\"}");
                        return;
                    }
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    exchange.close();
                    return;
                }
            }
            try {
                respond(exchange, 200, result(entry));
            } catch (IOException exception) {
                System.out.println("response_lost at=" + Instant.now() + " key=" + key);
            }
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("Usage: java SupplierStub <private-ledger-directory> <port>");
            System.exit(2);
        }
        Path directory = Path.of(args[0]).toAbsolutePath();
        int port = Integer.parseInt(args[1]);
        if (port < 1024 || port > 65535) {
            throw new IllegalArgumentException("Use an unprivileged port");
        }
        Files.createDirectories(directory);
        try (FileChannel lockChannel = FileChannel.open(directory.resolve("server.lock"),
                StandardOpenOption.CREATE, StandardOpenOption.WRITE);
             FileLock lock = lockChannel.tryLock()) {
            if (lock == null) {
                throw new IllegalStateException("Ledger already in use");
            }
            SupplierStub stub = new SupplierStub(directory);
            HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
            server.createContext("/", exchange -> {
                try {
                    stub.handle(exchange);
                } catch (Exception exception) {
                    System.err.println("handler_failed at=" + Instant.now() + " reason=" + exception);
                    try {
                        respond(exchange, 500, "{\"error\":\"handler_failed\"}");
                    } catch (IOException ignored) {
                        exchange.close();
                    }
                }
            });
            server.setExecutor(Executors.newFixedThreadPool(8));
            Runtime.getRuntime().addShutdownHook(new Thread(() -> server.stop(0)));
            server.start();
            System.out.println("ready at=" + Instant.now() + " address=127.0.0.1:" + port
                    + " ledger=" + directory.resolve("ledger.tsv"));
            new CountDownLatch(1).await();
        }
    }
}
