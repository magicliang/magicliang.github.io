# 第 32 篇供应商 HTTP stub

独立 JDK 21 `HttpServer`；没有 Maven 依赖，不接采购应用、PostgreSQL 或真实供应商。只绑定 `127.0.0.1`；不得对公网开放。订单账本按 `(supplierId, Idempotency-Key)` 保存，从落盘的账本查询，不从客户端返回值推断终态。同键不同 `orderId` / `taskId` 返回 409，不覆盖原订单。只存教学用标识和计数，不提供认证；**不要向它传真实订单、用户信息或凭证**。

## 启动与手动控制

在仓库根目录，选择独立空目录作为账本，终止后用同一目录重启以检查持久性（示例中的目录位于 `/tmp`，勿删除直到核对结束）：

```bash
cd examples/javaee-enterprise/stubs/supplier
mkdir -p /tmp/javaee-supplier-classes /tmp/javaee-supplier-ledger
javac -d /tmp/javaee-supplier-classes SupplierStub.java
java -cp /tmp/javaee-supplier-classes SupplierStub /tmp/javaee-supplier-ledger 18089
```

另一个终端用 `curl`；下列 JSON 顺序与该 stub 的严格教学解析器一致（字段限 `orderId`、`taskId`、可选 `supplierId`，标识限 `[A-Za-z0-9._-]{1,80}`；必须带 `Content-Type: application/json` 和 `Idempotency-Key`）：

```bash
curl -i -H 'Content-Type: application/json' -H 'Idempotency-Key: test-task' \
  --data '{"orderId":42,"taskId":"test-task"}' http://127.0.0.1:18089/orders
bash control.sh lookup test-task
bash control.sh stats

# 只为下一次此键的有效 POST 设置故障；独立测试应使用新键。
bash control.sh arm lost-task committed-then-disconnect
curl -i -H 'Content-Type: application/json' -H 'Idempotency-Key: lost-task' \
  --data '{"orderId":43,"taskId":"lost-task"}' http://127.0.0.1:18089/orders
bash control.sh lookup lost-task
```

`bash control.sh arm <key> <mode> [supplierId]` 支持 `slow-response`（请求账本先提交，然后阻塞响应）、`error-422`（无订单、终态 `REJECTED`）、`error-503`（无订单、状态 `RETRYABLE`）、`committed-then-disconnect`（先持久化，直接关闭连接，不发送状态行）、`committed-500`（已提交但返回 500）。`bash control.sh wait <key>` 等待 slow 请求已完成落盘的屏障，`bash control.sh release <key>` 解除响应阻塞；只用控制屏障判断请求已进入服务端，不用固定 `sleep` 猜竞态。`SUPPLIER_PORT` 可覆盖默认 18089；所有控制端点仅用于本地隔离实验，任何本地进程均能设置故障。控制设置不持久化，订单、`state` 和有效 POST 请求次数持久化；缺失的键返回 404，未创建订单但已经收到有效请求的键也返回 404，响应体保留 `requestCount` 和状态；`REJECTED` 同键重试仍拒绝。

## 一键自检与证据

从仓库根目录运行（依赖 JDK 21、curl、jq、sha256sum、bash）：

```bash
bash examples/javaee-enterprise/stubs/supplier/selfcheck.sh
```

脚本在一次性 `/tmp` 目录编译和创建独立账本；先屏障确认慢请求**已提交**，客户端的 1 秒截止后才解除阻塞；检查 422/503 无副作用、拒绝后同键重试仍拒绝、500/断连已提交、相同键跨进程重启只保留一张订单、不同 supplier 可共享同名键，以及同键不同业务载荷得到 409。最后断言账本总计 `orders=6, requests=12`。脚本打印时间、Java 版本、源码哈希、HTTP 原始状态/响应/错误、每次请求耗时、服务端处理日志和断言结论；测试结束自动清理一次性账本。若需要保留完整账本用于人工审计，请采用上面的手动持久目录启动方式；不要将真实凭证写入仓库。

已运行的 stdout/stderr、账本快照和退出码见 `evidence/`；其中 `RESULT=PASS` **仅证明 stub 自检**，不代表 Java EE 出站客户端、超时属性、数据库确认状态、真实供应商或 broker 已实测。自检的 curl 客户端只测 1 秒读取截止，与正文教学预算的连接 2 秒、读取 3 秒、总 10 秒、最多两次尝试不是同一个客户端配置实验。正确的 Java EE 集成验收必须另配网关与 `scenarios/32-supplier.sh`，核对任务 ID、稳定调用键、真实出站超时/重试、采购侧的 `UNKNOWN → CONFIRMED`、应用数据库和供应商账本。`server.lock` 防止同一账本双进程打开；账本用临时文件、文件强制刷盘、原子替换和目录强制刷盘，要求支持 POSIX 目录 fsync/原子替换的本地文件系统；写盘异常时进程中止，客户端必须以同键查询或重试。慢响应屏障最多等待 30 秒，超时后订单仍可能已提交。没有跨机器持久化、身份认证或生产级高可用承诺。
