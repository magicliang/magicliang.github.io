#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "$0")" && pwd)"
port="${SUPPLIER_PORT:-18089}"
export SUPPLIER_PORT="$port"
base="http://127.0.0.1:$port"
scratch="$(mktemp -d)"
server_pid=''
cleanup() {
    if [[ -n "$server_pid" ]]; then kill "$server_pid" 2>/dev/null || :; wait "$server_pid" 2>/dev/null || :; fi
    rm -rf "$scratch"
}
trap cleanup EXIT
fail() { echo "FAIL: $*" >&2; exit 1; }
assert() { [[ "$1" == "$2" ]] || fail "expected [$2], got [$1] ($3)"; }
control() { bash "$root/control.sh" "$@"; }
get() { curl -fsS --max-time 7 "$base$1"; }
post() {
    local key="$1" order="$2" task="$3" supplier="${4:-demo-supplier}"
    rm -f "$scratch/body"
    curl -sS --max-time "${CLIENT_TIMEOUT:-5}" -o "$scratch/body" -w '%{http_code} %{time_total}' \
        -H 'Content-Type: application/json' -H "Idempotency-Key: $key" \
        --data "{\"orderId\":$order,\"taskId\":\"$task\",\"supplierId\":\"$supplier\"}" \
        "$base/orders"
}
call() {
    local label="$1" expected_rc="$2" expected_status="$3" key="$4" order="$5" task="$6" supplier="${7:-demo-supplier}"
    local response rc status duration
    set +e
    response="$(post "$key" "$order" "$task" "$supplier" 2>"$scratch/curl.err")"
    rc=$?
    set -e
    read -r status duration <<< "$response"
    printf '%s curl_rc=%s http=%s duration_s=%s body=%s stderr=%s\n' "$label" "$rc" "$status" "$duration" \
        "$(cat "$scratch/body" 2>/dev/null)" "$(cat "$scratch/curl.err")"
    assert "$rc" "$expected_rc" "$label curl exit"
    assert "$status" "$expected_status" "$label HTTP"
}
start() {
    java -cp "$scratch/classes" SupplierStub "$scratch/ledger" "$port" >>"$scratch/server.log" 2>&1 &
    server_pid=$!
    local ready=0
    for ((check=0; check<100; check++)); do
        if ! kill -0 "$server_pid" 2>/dev/null; then cat "$scratch/server.log" >&2; fail 'server failed to start'; fi
        if curl -fsS --max-time 1 "$base/health" > /dev/null 2>&1; then ready=1; break; fi
        sleep 0.05
    done
    [[ "$ready" == 1 ]] || fail 'readiness deadline exceeded'
}

echo "started_utc=$(date -u +%FT%TZ)"
java -version 2>&1
echo "source_sha256=$(sha256sum "$root/SupplierStub.java" | cut -d' ' -f1)"
echo "selfcheck_sha256=$(sha256sum "$root/selfcheck.sh" | cut -d' ' -f1)"
echo "source_git_head=$(git -C "$root" rev-parse HEAD 2>/dev/null || echo not-a-repository)"
echo "command=bash examples/javaee-enterprise/stubs/supplier/selfcheck.sh port=$port"
echo 'ledger=temp-directory, disposed after test; service binds 127.0.0.1'
javac -d "$scratch/classes" "$root/SupplierStub.java"
start

call success 0 200 success-key 42 task-success
assert "$(jq -r .supplierOrderId "$scratch/body")" 1 success-id
assert "$(control lookup success-key | jq -r '.supplierOrderId, .requestCount' | paste -sd / -)" 1/1 success-ledger

control arm slow-key slow-response; echo
CLIENT_TIMEOUT=1 post slow-key 43 task-slow >"$scratch/slow.out" 2>"$scratch/slow.err" &
client_pid=$!
assert "$(control wait slow-key | jq -r .accepted)" true slow-acceptance-barrier
assert "$(control lookup slow-key | jq -r '.supplierOrderId, .requestCount' | paste -sd / -)" 2/1 slow-committed
# The client has a one-second read deadline. Wait for its actual exit, never guess a server delay.
set +e
wait "$client_pid"; slow_rc=$?
set -e
read -r slow_status slow_duration <<< "$(cat "$scratch/slow.out")"
printf 'slow-response curl_rc=%s http=%s duration_s=%s stderr=%s\n' "$slow_rc" "$slow_status" "$slow_duration" "$(cat "$scratch/slow.err")"
assert "$slow_rc" 28 slow-client-timeout
assert "$slow_status" 000 slow-no-response
control release slow-key; echo
call slow-retry-same-key 0 200 slow-key 43 task-slow
assert "$(jq -r '.supplierOrderId, .requestCount' "$scratch/body" | paste -sd / -)" 2/2 slow-idempotent

control arm rejected-key error-422; echo
call error-business-422 0 422 rejected-key 44 task-rejected
assert "$(curl -sS --max-time 7 -o "$scratch/rejected" -w '%{http_code}' "$base/orders/by-key/rejected-key")" 404 rejected-no-supplier-order
assert "$(jq -r .requestCount "$scratch/rejected")" 1 rejected-attempt
assert "$(jq -r .state "$scratch/rejected")" REJECTED rejected-terminal
assert "$(get /stats | jq -r .orders)" 2 rejected-no-order
call rejected-retry-same-key 0 422 rejected-key 44 task-rejected
assert "$(get /stats | jq -r .orders)" 2 rejected-still-no-order

control arm retry-key error-503; echo
call error-transient-503 0 503 retry-key 45 task-retry
assert "$(curl -sS --max-time 7 -o "$scratch/retryable" -w '%{http_code}' "$base/orders/by-key/retry-key")" 404 transient-no-supplier-order
assert "$(jq -r .state "$scratch/retryable")" RETRYABLE transient-persistent
assert "$(get /stats | jq -r .orders)" 2 transient-no-order
call retry-same-key 0 200 retry-key 45 task-retry
assert "$(jq -r '.supplierOrderId, .requestCount' "$scratch/body" | paste -sd / -)" 3/2 retry-converged

control arm lost-key committed-then-disconnect; echo
call committed-then-disconnect 52 000 lost-key 46 task-lost
assert "$(control lookup lost-key | jq -r '.supplierOrderId, .requestCount' | paste -sd / -)" 4/1 disconnect-committed

control arm error-after-commit-key committed-500; echo
call committed-500 0 500 error-after-commit-key 47 task-500
assert "$(control lookup error-after-commit-key | jq -r '.supplierOrderId, .requestCount' | paste -sd / -)" 5/1 error-committed

call conflict-same-key-different-order 0 409 success-key 99 task-success
assert "$(control lookup success-key | jq -r '.orderId, .supplierOrderId, .requestCount' | paste -sd / -)" 42/1/2 conflict-preserves-original

echo "ledger_sha256_before_restart=$(sha256sum "$scratch/ledger/ledger.tsv" | cut -d' ' -f1)"
kill "$server_pid"; wait "$server_pid" 2>/dev/null || :; server_pid=''
start
assert "$(control lookup lost-key | jq -r '.supplierOrderId, .requestCount' | paste -sd / -)" 4/1 restart-preserves-ledger
call restart-retry-same-key 0 200 lost-key 46 task-lost
assert "$(jq -r '.supplierOrderId, .requestCount' "$scratch/body" | paste -sd / -)" 4/2 restart-idempotent
call second-supplier-same-key 0 200 success-key 42 task-success other-supplier
assert "$(jq -r '.supplierOrderId, .requestCount' "$scratch/body" | paste -sd / -)" 6/1 supplier-scoped-key
stats="$(control stats)"
echo "final_supplier_ledger=$stats"
assert "$(jq -r '.orders, .requests' <<< "$stats" | paste -sd / -)" 6/12 final-counts
echo "ledger_sha256_final=$(sha256sum "$scratch/ledger/ledger.tsv" | cut -d' ' -f1)"
echo 'ledger_snapshot_begin'; cat "$scratch/ledger/ledger.tsv"; echo 'ledger_snapshot_end'
echo 'server_log_begin'; cat "$scratch/server.log"; echo 'server_log_end'
echo 'RESULT=PASS stub-only; Java EE outbound client/local DB/broker/confirmation NOT_RUN'
