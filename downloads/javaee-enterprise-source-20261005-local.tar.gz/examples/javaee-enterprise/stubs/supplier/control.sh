#!/usr/bin/env bash
set -euo pipefail

port="${SUPPLIER_PORT:-18089}"
base="http://127.0.0.1:$port"
action="${1:?Usage: bash control.sh arm|wait|release|lookup|stats [key] [mode] [supplierId]}"
key="${2:-}"
mode="${3:-}"
supplier="${4:-demo-supplier}"
if [[ ! "$port" =~ ^[0-9]+$ || "$port" -lt 1024 || "$port" -gt 65535 ]]; then
    echo 'Invalid port' >&2; exit 2
fi
if [[ "$action" != stats && ( ! "$key" =~ ^[A-Za-z0-9._-]{1,80}$ || ! "$supplier" =~ ^[A-Za-z0-9._-]{1,80}$ ) ]]; then
    echo 'Invalid key or supplier' >&2; exit 2
fi
case "$action" in
    arm)
        if [[ ! "$mode" =~ ^(slow-response|error-422|error-503|committed-then-disconnect|committed-500)$ ]]; then
            echo 'Invalid fault mode' >&2; exit 2
        fi
        exec curl --fail-with-body -sS --max-time 7 -X POST "$base/control/fault/$key?mode=$mode&supplierId=$supplier"
        ;;
    wait) exec curl --fail-with-body -sS --max-time 7 "$base/control/wait/$key?supplierId=$supplier" ;;
    release) exec curl --fail-with-body -sS --max-time 7 -X POST "$base/control/release/$key?supplierId=$supplier" ;;
    lookup) exec curl --fail-with-body -sS --max-time 7 "$base/orders/by-key/$key?supplierId=$supplier" ;;
    stats) exec curl --fail-with-body -sS --max-time 7 "$base/stats" ;;
    *) echo 'Unknown action' >&2; exit 2 ;;
esac
