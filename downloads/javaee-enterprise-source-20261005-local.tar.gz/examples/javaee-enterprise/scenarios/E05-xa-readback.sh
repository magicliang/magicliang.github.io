#!/usr/bin/env bash
set -euo pipefail
: "${JAVAEE_XA_PURCHASE_HOST:?}" "${JAVAEE_XA_PURCHASE_PORT:?}" "${JAVAEE_XA_PURCHASE_DB:?}" "${JAVAEE_XA_PURCHASE_USER:?}" "${JAVAEE_XA_PURCHASE_PASSWORD:?}"
: "${JAVAEE_XA_SETTLEMENT_HOST:?}" "${JAVAEE_XA_SETTLEMENT_PORT:?}" "${JAVAEE_XA_SETTLEMENT_DB:?}" "${JAVAEE_XA_SETTLEMENT_USER:?}" "${JAVAEE_XA_SETTLEMENT_PASSWORD:?}"
: "${1:?Provide numeric orderId}"
[[ "$1" =~ ^[0-9]+$ ]] || exit 2
[[ "$JAVAEE_XA_PURCHASE_HOST:$JAVAEE_XA_PURCHASE_PORT" != "$JAVAEE_XA_SETTLEMENT_HOST:$JAVAEE_XA_SETTLEMENT_PORT" ]] || {
    printf 'Two separate PostgreSQL instances required\n' >&2; exit 2;
}
for side in PURCHASE SETTLEMENT; do
    host_var="JAVAEE_XA_${side}_HOST"; port_var="JAVAEE_XA_${side}_PORT"
    db_var="JAVAEE_XA_${side}_DB"; user_var="JAVAEE_XA_${side}_USER"; pass_var="JAVAEE_XA_${side}_PASSWORD"
    table=posting; [[ "$side" == SETTLEMENT ]] && table=settlement
    printf '%s: ' "$side"
    PGPASSWORD="${!pass_var}" psql -X -v ON_ERROR_STOP=1 \
        -h "${!host_var}" -p "${!port_var}" -U "${!user_var}" -d "${!db_var}" -At \
        -c "SELECT count(*) FROM $table WHERE order_id=$1; SELECT count(*) FROM pg_prepared_xacts WHERE database=current_database()"
done
