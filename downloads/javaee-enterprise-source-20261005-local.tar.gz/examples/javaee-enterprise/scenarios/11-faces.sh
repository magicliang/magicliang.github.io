#!/usr/bin/env bash
set -euo pipefail

: "${JAVAEE_PORT:?Set JAVAEE_PORT}"
: "${JAVAEE_LAB_PASSWORD:?Set JAVAEE_LAB_PASSWORD}"
if [[ "${JAVAEE_DEMO_MODE:-}" != 'true' || "${JAVAEE_LAB_USER:-}" != 'javaee_lab' ]]; then
    printf 'Only the loopback demo server is supported\n' >&2
    exit 2
fi

tenant="faces-$(date -u +%Y%m%dT%H%M%SZ)-$RANDOM"
base="http://127.0.0.1:${JAVAEE_PORT}/procurement"
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
status=$(curl -sS --max-time 20 -X POST -H "X-Lab-Tenant: $tenant" \
    -H 'Content-Type: application/json' -d '{"items":[{"sku":"paper","quantity":1}]}' \
    -o "$scratch/created" -w '%{http_code}' "$base/api/lab/requests")
if [[ "$status" != '201' ]]; then cat "$scratch/created" >&2; exit 1; fi
request_id=$(jq -er '.id | numbers' "$scratch/created")
status=$(curl -sS --max-time 20 -X POST -H "X-Lab-Tenant: $tenant" \
    -o "$scratch/submitted" -w '%{http_code}' "$base/api/lab/requests/$request_id/submit")
if [[ "$status" != '204' ]]; then cat "$scratch/submitted" >&2; exit 1; fi

status=$(curl -sS --max-time 20 -b "$scratch/cookies" -c "$scratch/cookies" \
    -o "$scratch/page" -w '%{http_code}' "$base/approval.xhtml")
if [[ "$status" != '200' ]]; then exit 1; fi
view_state=$(rg -o '<input[^>]*name="jakarta.faces.ViewState"[^>]*>' "$scratch/page" \
    | sed -nE 's/.*value="([^"]+)".*/\1/p')
if [[ -z "$view_state" ]]; then printf 'No Faces view state\n' >&2; exit 1; fi
form_marker=$(rg -o '<input[^>]*name="approval(_SUBMIT)?"[^>]*>' "$scratch/page" | head -n 1)
form_marker_name=$(printf '%s\n' "$form_marker" | sed -nE 's/.*name="([^"]+)".*/\1/p')
form_marker_value=$(printf '%s\n' "$form_marker" | sed -nE 's/.*value="([^"]+)".*/\1/p')
if [[ -z "$form_marker_name" || -z "$form_marker_value" ]]; then
    printf 'Missing Faces form marker\n' >&2
    exit 1
fi

approve() {
    curl -sS --max-time 20 -b "$scratch/cookies" -c "$scratch/cookies" \
        --data-urlencode "$form_marker_name=$form_marker_value" --data-urlencode "approval:requestId=$request_id" \
        --data-urlencode "approval:tenantId=$tenant" --data-urlencode "jakarta.faces.ViewState=$view_state" \
        -d 'approval:approve=Approve' -o "$scratch/result" -w '%{http_code}' "$base/approval.xhtml"
}
status=$(approve)
if [[ "$status" != '200' ]] || ! rg -q 'approved' "$scratch/result"; then
    printf 'First approval failed: HTTP%s; response excerpt: ' "$status" >&2
    head -c 1800 "$scratch/result" >&2
    printf '\n' >&2
    exit 1
fi
printf 'first_approval=HTTP%s state=approved\n' "$status"
view_state=$(rg -o '<input[^>]*name="jakarta.faces.ViewState"[^>]*>' "$scratch/result" \
    | sed -nE 's/.*value="([^"]+)".*/\1/p')
status=$(approve)
if [[ "$status" != '200' ]] || ! rg -q 'Approval rejected|rejected' "$scratch/result"; then
    printf 'Repeated approval failed: HTTP%s; response excerpt: ' "$status" >&2
    head -c 400 "$scratch/result" >&2
    printf '\n' >&2
    exit 1
fi
printf 'repeat_approval=HTTP%s state=rejected\n' "$status"
final=$(PGPASSWORD="$JAVAEE_LAB_PASSWORD" psql -h 127.0.0.1 -U javaee_lab -d javaee_lab -At \
    -v ON_ERROR_STOP=1 -c "SELECT status || '|' || version FROM purchase_request
        WHERE id = $request_id AND tenant_id = '$tenant'")
printf 'request_after_repeat=%s\n' "$final"
if [[ "$final" != 'APPROVED|2' ]]; then exit 1; fi
