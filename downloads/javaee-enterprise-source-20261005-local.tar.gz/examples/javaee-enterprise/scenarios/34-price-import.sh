#!/usr/bin/env bash
set -euo pipefail
: "${JAVAEE_PORT:?Set JAVAEE_PORT}"
: "${JAVAEE_REGISTRY_PASSWORD:?Set JAVAEE_REGISTRY_PASSWORD for local batch HTTP Basic}"
[[ "${JAVAEE_DEMO_MODE:-}" == 'true' ]] || { printf 'Local demo only\n' >&2; exit 2; }
base="http://127.0.0.1:${JAVAEE_PORT}/procurement/api/lab/batch"
case "${1:-}" in
    start)
        curl -fsS --max-time 15 -u "lab-container:$JAVAEE_REGISTRY_PASSWORD" -X POST -H 'X-Lab-Tenant: batch-lab' \
            "$base?fileName=sample.csv&failAtLine=${2:-}" | jq .
        ;;
    status)
        [[ "${2:-}" =~ ^[0-9]+$ ]] || exit 2
        curl -fsS --max-time 15 -u "lab-container:$JAVAEE_REGISTRY_PASSWORD" -H 'X-Lab-Tenant: batch-lab' "$base/$2" | jq .
        ;;
    restart)
        [[ "${2:-}" =~ ^[0-9]+$ ]] || exit 2
        curl -fsS --max-time 15 -u "lab-container:$JAVAEE_REGISTRY_PASSWORD" -X POST -H 'X-Lab-Tenant: batch-lab' \
            "$base/$2/restart?fileName=sample.csv" | jq .
        ;;
    *)
        printf 'Usage: %s start [failAtLine] | status id | restart id\n' "$0" >&2; exit 2
        ;;
esac
