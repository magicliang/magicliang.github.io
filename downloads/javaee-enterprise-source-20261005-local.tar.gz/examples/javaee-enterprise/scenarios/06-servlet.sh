#!/usr/bin/env bash
set -euo pipefail

: "${JAVAEE_PORT:?Set JAVAEE_PORT}"
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
url="http://127.0.0.1:${JAVAEE_PORT}/procurement/servlet/echo"
curl -sS -G --max-time 10 -D "$scratch/headers" -o "$scratch/body" \
    --data-urlencode 'value=采购' --data-urlencode 'value=审批' "$url"
printf 'GET echo: %s\n' "$(cat "$scratch/body")"
if [[ "$(cat "$scratch/body")" != '采购|审批' ]]; then exit 1; fi
if ! grep -qi '^X-Request-ID: ' "$scratch/headers"; then exit 1; fi
code=$(curl -sS --max-time 10 -o "$scratch/bad" -w '%{http_code}' "$url")
printf 'GET missing value: HTTP %s\n' "$code"
if [[ "$code" != '400' ]]; then exit 1; fi
code=$(curl -sS --max-time 10 -X POST -o "$scratch/wrong-method" -w '%{http_code}' "$url")
printf 'POST unsupported method: HTTP %s\n' "$code"
if [[ "$code" != '405' ]]; then exit 1; fi
