#!/usr/bin/env bash
set -euo pipefail
: "${JAVAEE_PORT:?Set JAVAEE_PORT}"
[[ "${JAVAEE_DEMO_MODE:-}" == 'true' ]] || { printf 'Local demo only\n' >&2; exit 2; }
order_id=${1:?Provide a new numeric order ID}
fail_at=${2:-none}
[[ "$order_id" =~ ^[0-9]+$ ]] || exit 2
case "$fail_at" in none|afterPurchase|afterBoth) ;; *) exit 2;; esac
url="http://127.0.0.1:${JAVAEE_PORT}/procurement/api/lab/xa?orderId=$order_id&key=xa-$order_id"
[[ "$fail_at" == none ]] || url="$url&failAt=$fail_at"
status=$(curl -sS --max-time 20 -X POST -H 'X-Lab-Tenant: xa-lab' -o /dev/null -w '%{http_code}' "$url")
expected=204
[[ "$fail_at" == none ]] || expected=500
printf 'phase=%s HTTP=%s expected=%s\n' "$fail_at" "$status" "$expected"
[[ "$status" == "$expected" ]] || exit 1
bash "$(dirname "$0")/E05-xa-readback.sh" "$order_id"
