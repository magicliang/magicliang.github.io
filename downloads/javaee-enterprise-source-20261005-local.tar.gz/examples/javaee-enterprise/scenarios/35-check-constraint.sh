#!/usr/bin/env bash
set -euo pipefail

: "${JAVAEE_LAB_PASSWORD:?Set JAVAEE_LAB_PASSWORD}"
export PGPASSWORD="$JAVAEE_LAB_PASSWORD"
[[ "${JAVAEE_LAB_USER:-}" =~ ^(javaee_lab|rev_[0-9]+)$ ]] || { printf 'Dedicated lab role required\n' >&2; exit 2; }
database=${JAVAEE_LAB_DB:-javaee_lab}
[[ "$database" =~ ^(javaee_lab|rev_[0-9]+)$ ]] || { printf 'Dedicated lab database required\n' >&2; exit 2; }
psql_bin=${PSQL:-psql}
tenant="invalid-state-probe-$$-$RANDOM"
error_file=$(mktemp)
trap 'rm -f "$error_file"' EXIT

status=0
printf "INSERT INTO purchase_request(tenant_id,status,total) VALUES (:'tenant','UNKNOWN',0);\n" | \
"$psql_bin" -X -h 127.0.0.1 -U "$JAVAEE_LAB_USER" -d "$database" -v ON_ERROR_STOP=1 \
    -v VERBOSITY=verbose -v "tenant=$tenant" \
    >"$error_file" 2>&1 || status=$?
if [[ $status -ne 3 ]] || ! grep -Eq '23514:.*valid_request_state|23514:|SQL state: 23514' "$error_file" \
    || ! grep -Fq 'valid_request_state' "$error_file"; then
    cat "$error_file" >&2
    printf 'Expected SQLSTATE 23514 from valid_request_state, got exit %s\n' "$status" >&2
    exit 1
fi

count=$(printf "SELECT count(*) FROM purchase_request WHERE tenant_id=:'tenant';\n" | \
    "$psql_bin" -X -h 127.0.0.1 -U "$JAVAEE_LAB_USER" -d "$database" -v ON_ERROR_STOP=1 \
    -v "tenant=$tenant" -At)
[[ "$count" == '0' ]] || { printf 'Probe row remained: %s\n' "$count" >&2; exit 1; }
printf 'SQLSTATE 23514 valid_request_state; probe rows=0\n'
