#!/usr/bin/env bash
set -euo pipefail
: "${JAVAEE_PORT:?}" "${JAVAEE_DEMO_MODE:?}" "${JAVAEE_LAB_PASSWORD:?}" "${JAVAEE_LAB_USER:?}"
[[ "$JAVAEE_DEMO_MODE" == 'true' ]] || exit 2
database=${JAVAEE_LAB_DB:-javaee_lab}
[[ "$database" =~ ^(javaee_lab|rev_[0-9]+)$ && "$JAVAEE_LAB_USER" =~ ^(javaee_lab|rev_[0-9]+)$ ]] || exit 2
scratch=$(mktemp)
trap 'rm -f "$scratch"' EXIT
base="http://127.0.0.1:${JAVAEE_PORT}/procurement/api/lab/requests"
tenant="null-rev-$$-$RANDOM"
code=$(curl -sS --max-time 15 -X POST -H "X-Lab-Tenant: $tenant" -H 'Content-Type: application/json' \
    -d '{"items":[null]}' -o "$scratch" -w '%{http_code}' "$base")
rows=$(PGPASSWORD="$JAVAEE_LAB_PASSWORD" psql -X -v ON_ERROR_STOP=1 -h 127.0.0.1 \
    -U "$JAVAEE_LAB_USER" -d "$database" -At \
    -c "SELECT count(*) FROM purchase_request WHERE tenant_id='$tenant'")
printf 'items:[null] HTTP=%s rows=%s\n' "$code" "$rows"
[[ "$code" == 400 && "$rows" == 0 ]] || exit 1

tenant="unknown-rev-$$-$RANDOM"
code=$(curl -sS --max-time 15 -X POST -H "X-Lab-Tenant: $tenant" -H 'Content-Type: application/json' \
    -d '{"items":[{"sku":"paper","quantity":2,"unitPrice":0.01}],"role":"approver","status":"APPROVED"}' \
    -o "$scratch" -w '%{http_code}' "$base")
record=$(PGPASSWORD="$JAVAEE_LAB_PASSWORD" psql -X -v ON_ERROR_STOP=1 -h 127.0.0.1 \
    -U "$JAVAEE_LAB_USER" -d "$database" -At \
    -c "SELECT status,total FROM purchase_request WHERE tenant_id='$tenant'")
printf 'unknown fields HTTP=%s persisted=%s\n' "$code" "$record"
[[ "$code" == 201 && "$record" == 'DRAFT|7.00' ]] || exit 1
