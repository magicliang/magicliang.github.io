#!/usr/bin/env bash
set -euo pipefail

: "${JAVAEE_PORT:?Set JAVAEE_PORT}"
response=$(curl -fsS --max-time 10 "http://127.0.0.1:${JAVAEE_PORT}/procurement/api/health")
if [[ "$response" != 'ready' ]]; then
    printf 'Unexpected health body: %s\n' "$response" >&2
    exit 1
fi
printf 'GET /procurement/api/health: %s\n' "$response"
