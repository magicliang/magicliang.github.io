#!/usr/bin/env bash
set -euo pipefail

: "${JAVAEE_PORT:?Set JAVAEE_PORT}"
response=$(curl -fsS --max-time 10 "http://127.0.0.1:${JAVAEE_PORT}/procurement/api/db-check")
if [[ "$response" != 'connected' ]]; then
    printf 'Unexpected database probe body: %s\n' "$response" >&2
    exit 1
fi
printf 'GET /procurement/api/db-check: %s\n' "$response"
