#!/usr/bin/env bash
set -euo pipefail

: "${JAVAEE_PORT:?Set JAVAEE_PORT}"
: "${JAVAEE_LAB_PASSWORD:?Set JAVAEE_LAB_PASSWORD}"
if [[ "${JAVAEE_DEMO_MODE:-}" != 'true' || "${JAVAEE_LAB_USER:-}" != 'javaee_lab' ]]; then
    printf 'Only isolated demo mode and javaee_lab role are allowed\n' >&2
    exit 2
fi

tenant="broker-$(date -u +%Y%m%dT%H%M%SZ)-$RANDOM"
base="http://127.0.0.1:${JAVAEE_PORT}/procurement/api/lab"
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT

call() {
    local label="$1" url="$2" expected="$3" response_code
    response_code=$(curl -sS --max-time 20 -X POST -H "X-Lab-Tenant: $tenant" \
        -H 'Content-Type: application/json' -o "$scratch/body" -w '%{http_code}' "$url")
    printf '%s=HTTP%s\n' "$label" "$response_code"
    if [[ "$response_code" != "$expected" ]]; then cat "$scratch/body" >&2; exit 1; fi
}

create_status=$(curl -sS --max-time 20 -X POST -H "X-Lab-Tenant: $tenant" \
    -H 'Content-Type: application/json' -d '{"items":[{"sku":"paper","quantity":2}]}' \
    -o "$scratch/body" -w '%{http_code}' "$base/requests")
if [[ "$create_status" != '201' ]]; then cat "$scratch/body" >&2; exit 1; fi
request_id=$(jq -er '.id | numbers' "$scratch/body")
call submit "$base/requests/$request_id/submit" 204
call approve "$base/requests/$request_id/approve" 204
call order "$base/requests/$request_id/order" 200
order_id=$(jq -er '.orderId | numbers' "$scratch/body")
printf 'tenant=%s request_id=%s order_id=%s\n' "$tenant" "$request_id" "$order_id"

query_state() {
    PGPASSWORD="$JAVAEE_LAB_PASSWORD" psql -h 127.0.0.1 -U javaee_lab -d javaee_lab -At \
        -v ON_ERROR_STOP=1 -c "SELECT o.id || '|' || o.status || '|' || COUNT(r.event_id)
        FROM notification_outbox o LEFT JOIN notification_receipt r ON r.event_id = o.id
        WHERE o.tenant_id = '$tenant' AND o.request_id = $request_id AND o.order_id = $order_id
        GROUP BY o.id, o.status"
}
before=$(query_state)
printf 'before_broker=%s\n' "$before"
if [[ "$before" != *'|PENDING|0' ]]; then exit 1; fi
event_id=${before%%|*}

call 'send-then-abort' "$base/broker/send-next?tenant=$tenant&abortAfterSend=true" 500
after_send_abort=$(query_state)
printf 'after_send_abort=%s\n' "$after_send_abort"
if [[ "$after_send_abort" != "$before" ]]; then exit 1; fi
call send-retry "$base/broker/send-next?tenant=$tenant" 200
if [[ "$(jq -er '.eventId | numbers' "$scratch/body")" != "$event_id" ]]; then exit 1; fi
after_send_retry=$(query_state)
printf 'after_send_retry=%s\n' "$after_send_retry"
if [[ "$after_send_retry" != "$event_id|PUBLISHED|0" ]]; then exit 1; fi

call 'receive-then-abort' "$base/broker/receive-one?abortAfterRecord=true" 500
after_receive_abort=$(query_state)
printf 'after_receive_abort=%s\n' "$after_receive_abort"
if [[ "$after_receive_abort" != "$event_id|PUBLISHED|1" ]]; then exit 1; fi

received_duplicate=false
for attempt in 1 2 3 4 5 6 7 8 9 10; do
    response_code=$(curl -sS --max-time 20 -X POST -o "$scratch/body" -w '%{http_code}' \
        "$base/broker/receive-one")
    if [[ "$response_code" == '204' ]]; then
        sleep 1
        continue
    fi
    if [[ "$response_code" != '200' ]]; then cat "$scratch/body" >&2; exit 1; fi
    if [[ "$(jq -er '.eventId | numbers' "$scratch/body")" != "$event_id" ]]; then exit 1; fi
    if [[ "$(jq -r '.newReceipt' "$scratch/body")" != 'false' ]]; then exit 1; fi
    received_duplicate=true
    break
done
if [[ "$received_duplicate" != 'true' ]]; then printf 'Redelivery not observed in bounded window\n' >&2; exit 1; fi
final_state=$(query_state)
printf 'duplicate_message_replayed=true receipt_unchanged=%s\n' "$final_state"
if [[ "$final_state" != "$event_id|PUBLISHED|1" ]]; then exit 1; fi
