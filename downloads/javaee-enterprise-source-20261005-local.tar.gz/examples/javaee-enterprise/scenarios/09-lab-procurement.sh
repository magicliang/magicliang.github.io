#!/usr/bin/env bash
set -euo pipefail

: "${JAVAEE_PORT:?Set JAVAEE_PORT}"
: "${JAVAEE_LAB_PASSWORD:?Set JAVAEE_LAB_PASSWORD}"
if [[ "${JAVAEE_DEMO_MODE:-}" != 'true' || "${JAVAEE_LAB_USER:-}" != 'javaee_lab' ]]; then
    printf 'Only isolated demo mode and javaee_lab role are allowed\n' >&2
    exit 2
fi

tenant="lab-$(date -u +%Y%m%dT%H%M%SZ)-$RANDOM"
base="http://127.0.0.1:${JAVAEE_PORT}/procurement/api/lab/requests"
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT

check_request() {
    local label="$1" expected="$2" method="$3" url="$4" requesting_tenant="$5" status
    status=$(curl -sS --max-time 20 -X "$method" -H "X-Lab-Tenant: $requesting_tenant" \
        -H 'Content-Type: application/json' -o "$scratch/body" -w '%{http_code}' "$url")
    printf '%s: HTTP %s\n' "$label" "$status"
    if [[ "$status" != "$expected" ]]; then
        cat "$scratch/body" >&2
        exit 1
    fi
}

status=$(curl -sS --max-time 20 -X POST -H "X-Lab-Tenant: $tenant" \
    -H 'Content-Type: application/json' \
    -d '{"items":[{"sku":"paper","quantity":2},{"sku":"pen","quantity":3}]}' \
    -o "$scratch/body" -w '%{http_code}' "$base")
if [[ "$status" != '201' ]]; then cat "$scratch/body" >&2; exit 1; fi
request_id=$(jq -er '.id | numbers' "$scratch/body")
printf 'tenant=%s request_id=%s create=HTTP %s\n' "$tenant" "$request_id" "$status"

check_request 'order before approval' 409 POST "$base/$request_id/order" "$tenant"
check_request 'cross-tenant submit (untrusted demo header)' 404 POST "$base/$request_id/submit" "not-$tenant"
check_request 'submit' 204 POST "$base/$request_id/submit" "$tenant"
check_request 'approve' 204 POST "$base/$request_id/approve" "$tenant"
check_request 'order' 200 POST "$base/$request_id/order" "$tenant"
order_id=$(jq -er '.orderId | numbers' "$scratch/body")
check_request 'retry order' 200 POST "$base/$request_id/order" "$tenant"
retry_order_id=$(jq -er '.orderId | numbers' "$scratch/body")
if [[ "$retry_order_id" != "$order_id" ]]; then exit 1; fi
check_request 'reject ordered request' 409 POST "$base/$request_id/reject" "$tenant"

result=$(PGPASSWORD="$JAVAEE_LAB_PASSWORD" psql -h 127.0.0.1 -U javaee_lab -d javaee_lab -At \
    -c "SELECT r.status || '|' || r.total || '|' || COUNT(o.id) FROM purchase_request r LEFT JOIN purchase_order o ON o.request_id = r.id WHERE r.id = $request_id AND r.tenant_id = '$tenant' GROUP BY r.status, r.total")
printf 'final_request=%s order_id=%s\n' "$result" "$order_id"
if [[ "$result" != 'ORDERED|13.75|1' ]]; then exit 1; fi
