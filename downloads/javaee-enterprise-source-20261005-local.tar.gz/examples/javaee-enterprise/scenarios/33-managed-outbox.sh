#!/usr/bin/env bash
set -euo pipefail

: "${JAVAEE_PORT:?Set JAVAEE_PORT}"
: "${JAVAEE_LAB_PASSWORD:?Set JAVAEE_LAB_PASSWORD}"
if [[ "${JAVAEE_DEMO_MODE:-}" != 'true' || "${JAVAEE_LAB_USER:-}" != 'javaee_lab' ]]; then
    printf 'Only isolated demo mode and javaee_lab role are allowed\n' >&2
    exit 2
fi

tenant="managed-$(date -u +%Y%m%dT%H%M%SZ)-$RANDOM"
base="http://127.0.0.1:${JAVAEE_PORT}/procurement/api/lab"
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT

post() {
    local label="$1" url="$2" expected="$3" actual
    actual=$(curl -sS --max-time 20 -X POST -H "X-Lab-Tenant: $tenant" \
        -H 'Content-Type: application/json' -o "$scratch/body" -w '%{http_code}' "$url")
    printf '%s=HTTP%s\n' "$label" "$actual"
    if [[ "$actual" != "$expected" ]]; then cat "$scratch/body" >&2; exit 1; fi
}

actual=$(curl -sS --max-time 20 -X POST -H "X-Lab-Tenant: $tenant" \
    -H 'Content-Type: application/json' -d '{"items":[{"sku":"pen","quantity":3}]}' \
    -o "$scratch/body" -w '%{http_code}' "$base/requests")
if [[ "$actual" != '201' ]]; then cat "$scratch/body" >&2; exit 1; fi
request_id=$(jq -er '.id | numbers' "$scratch/body")
post submit "$base/requests/$request_id/submit" 204
post approve "$base/requests/$request_id/approve" 204
post order "$base/requests/$request_id/order" 200

query_status() {
    PGPASSWORD="$JAVAEE_LAB_PASSWORD" psql -h 127.0.0.1 -U javaee_lab -d javaee_lab -At \
        -v ON_ERROR_STOP=1 -c "SELECT id || '|' || status FROM notification_outbox
        WHERE tenant_id = '$tenant' AND request_id = $request_id"
}
before=$(query_status)
if [[ "$before" != *'|PENDING' ]]; then printf 'Unexpected pre-task state: %s\n' "$before" >&2; exit 1; fi
event_id=${before%%|*}
post accepted-not-completed "$base/broker/schedule?tenant=$tenant" 202

completed=false
for attempt in 1 2 3 4 5 6 7 8 9 10; do
    state=$(query_status)
    if [[ "$state" == "$event_id|PUBLISHED" ]]; then completed=true; break; fi
    sleep 1
done
printf 'outbox_after_managed_task=%s\n' "$state"
if [[ "$completed" != 'true' ]]; then exit 1; fi

post consume-ledger "$base/broker/receive-one" 200
if [[ "$(jq -er '.eventId | numbers' "$scratch/body")" != "$event_id" ||
      "$(jq -r '.newReceipt' "$scratch/body")" != 'true' ]]; then
    cat "$scratch/body" >&2
    exit 1
fi
receipt=$(PGPASSWORD="$JAVAEE_LAB_PASSWORD" psql -h 127.0.0.1 -U javaee_lab -d javaee_lab -At \
    -v ON_ERROR_STOP=1 -c "SELECT COUNT(*) FROM notification_receipt WHERE event_id = $event_id")
printf 'event_id=%s receipt_rows=%s\n' "$event_id" "$receipt"
if [[ "$receipt" != '1' ]]; then exit 1; fi
