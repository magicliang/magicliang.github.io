#!/usr/bin/env bash
set -euo pipefail

: "${JAVAEE_LAB_PASSWORD:?Set JAVAEE_LAB_PASSWORD}"
: "${JAVAEE_STAGE_DIR:?Set a dedicated temporary staging directory}"
export PGPASSWORD="$JAVAEE_LAB_PASSWORD"
database=${JAVAEE_LAB_DB:-javaee_lab}
if [[ ! "${JAVAEE_LAB_USER:-}" =~ ^(javaee_lab|rev_[0-9]+)$ || ! "$database" =~ ^(javaee_lab|rev_[0-9]+)$ || $# != 2 ]]; then
    printf 'Usage: JAVAEE_LAB_USER=lab_role %s candidate.war staging.war\n' "$0" >&2
    exit 2
fi

candidate=$1
staging=$2
[[ -d "$JAVAEE_STAGE_DIR" ]] || { printf 'Dedicated staging directory missing\n' >&2; exit 2; }
stage_directory=$(cd -- "$JAVAEE_STAGE_DIR" && pwd -P)
staging_parent=$(cd -- "$(dirname -- "$staging")" && pwd -P) || {
    printf 'Staging parent directory missing\n' >&2; exit 2;
}
[[ "$staging_parent" == "$stage_directory" ]] || {
    printf 'Staging path must be inside the dedicated directory\n' >&2; exit 2;
}
[[ "$stage_directory" == /tmp/* || "$stage_directory" == /private/tmp/* ]] || {
    printf 'Staging must remain under /tmp\n' >&2; exit 2;
}
[[ -f "$candidate" ]] || { printf 'Candidate WAR missing\n' >&2; exit 2; }
[[ ! -e "$staging" && ! -L "$staging" ]] || { printf 'Staging path already exists\n' >&2; exit 2; }

"${PSQL:-psql}" -X -v ON_ERROR_STOP=1 -h 127.0.0.1 -U "$JAVAEE_LAB_USER" -d "$database" \
    -At -c "SELECT CASE WHEN to_regclass('public.purchase_request') IS NOT NULL
        AND to_regclass('public.purchase_order') IS NOT NULL
        AND to_regclass('public.notification_outbox') IS NOT NULL
        AND to_regclass('public.notification_receipt') IS NOT NULL
        THEN 'ready' ELSE 'missing' END" | grep -Fx ready

cp -- "$candidate" "$staging"
printf 'Staged %s; no live deployment performed\n' "$staging"
