#!/usr/bin/env bash
set -euo pipefail

: "${JAVAEE_PORT:?Set JAVAEE_PORT}"
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
url="http://127.0.0.1:${JAVAEE_PORT}/procurement/servlet/lab-session"
if [[ "$(curl -fsS --max-time 10 -b "$scratch/cookies" "$url")" != 'inactive' ]]; then exit 1; fi
start=$(curl -sS --max-time 10 -X POST -c "$scratch/cookies" -b "$scratch/cookies" \
    --data 'action=start' -o "$scratch/start-body" -w '%{http_code}' "$url")
if [[ "$start" != '204' ]]; then exit 1; fi
if [[ "$(curl -fsS --max-time 10 -b "$scratch/cookies" "$url")" != 'active' ]]; then exit 1; fi
end=$(curl -sS --max-time 10 -X POST -c "$scratch/cookies" -b "$scratch/cookies" \
    --data 'action=end' -o "$scratch/end-body" -w '%{http_code}' "$url")
if [[ "$end" != '204' ]]; then exit 1; fi
if [[ "$(curl -fsS --max-time 10 -b "$scratch/cookies" "$url")" != 'inactive' ]]; then exit 1; fi
printf 'session absent/start/active/end/absent: PASS\n'
