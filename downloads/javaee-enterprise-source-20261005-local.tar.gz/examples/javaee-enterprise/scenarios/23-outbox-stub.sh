#!/usr/bin/env bash
set -euo pipefail

: "${JAVAEE_PORT:?Set JAVAEE_PORT}"
: "${JAVAEE_LAB_PASSWORD:?Set JAVAEE_LAB_PASSWORD}"
if [[ "${JAVAEE_DEMO_MODE:-}" != 'true' || "${JAVAEE_LAB_USER:-}" != 'javaee_lab' ]]; then
    printf 'Only isolated demo mode and javaee_lab role are allowed\n' >&2
    exit 2
fi

tenant="outbox-$(date -u +%Y%m%dT%H%M%SZ)-$RANDOM"
base="http://127.0.0.1:${JAVAEE_PORT}/procurement/api/lab/requests"
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT

post() {
    local label="$1" route="$2" expected="$3" status
    status=$(curl -sS --max-time 20 -X POST -H "X-Lab-Tenant: $tenant" \
        -H 'Content-Type: application/json' -o "$scratch/body" -w '%{http_code}' "$base/$route")
    printf '%s=HTTP%s\n' "$label" "$status"
    if [[ "$status" != "$expected" ]]; then cat "$scratch/body" >&2; exit 1; fi
}

create_status=$(curl -sS --max-time 20 -X POST -H "X-Lab-Tenant: $tenant" \
    -H 'Content-Type: application/json' -d '{"items":[{"sku":"paper","quantity":2}]}' \
    -o "$scratch/body" -w '%{http_code}' "$base")
if [[ "$create_status" != '201' ]]; then cat "$scratch/body" >&2; exit 1; fi
request_id=$(jq -er '.id | numbers' "$scratch/body")
post submit "$request_id/submit" 204
post approve "$request_id/approve" 204
post order "$request_id/order" 200
order_id=$(jq -er '.orderId | numbers' "$scratch/body")
post retry "$request_id/order" 200
if [[ "$(jq -er '.orderId | numbers' "$scratch/body")" != "$order_id" ]]; then exit 1; fi

query_outbox() {
    PGPASSWORD="$JAVAEE_LAB_PASSWORD" psql -h 127.0.0.1 -U javaee_lab -d javaee_lab -At \
        -v ON_ERROR_STOP=1 -c "SELECT COUNT(*) || '|' || MIN(status) || '|' || MIN(attempts) FROM notification_outbox WHERE tenant_id = '$tenant' AND request_id = $request_id AND order_id = $order_id"
}
before=$(query_outbox)
printf 'outbox_before_attempt=%s\n' "$before"
if [[ "$before" != '1|PENDING|0' ]]; then exit 1; fi

post attempt-one 'outbox/attempt' 200
event_id=$(jq -er '.eventId | numbers' "$scratch/body")
post abort-after-update 'outbox/attempt?abortAfterUpdate=true' 500
after_abort=$(query_outbox)
printf 'outbox_after_abort=%s\n' "$after_abort"
if [[ "$after_abort" != '1|PENDING|1' ]]; then exit 1; fi
post attempt-again 'outbox/attempt' 200
if [[ "$(jq -er '.eventId | numbers' "$scratch/body")" != "$event_id" ]]; then exit 1; fi
after_retry=$(query_outbox)
printf 'outbox_after_retry=%s event_id=%s\n' "$after_retry" "$event_id"
if [[ "$after_retry" != '1|PENDING|2' ]]; then exit 1; fi
