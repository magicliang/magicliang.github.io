#!/usr/bin/env bash
set -euo pipefail

: "${JAVAEE_PORT:?Set JAVAEE_PORT}"
: "${JAVAEE_LAB_PASSWORD:?Set JAVAEE_LAB_PASSWORD}"
if [[ "${JAVAEE_DEMO_MODE:-}" != 'true' || "${JAVAEE_LAB_USER:-}" != 'javaee_lab' ]]; then
    printf 'Only isolated demo mode and javaee_lab role are allowed\n' >&2
    exit 2
fi

tenant="rollback-$(date -u +%Y%m%dT%H%M%SZ)-$RANDOM"
before_request=$(PGPASSWORD="$JAVAEE_LAB_PASSWORD" psql -h 127.0.0.1 -U javaee_lab -d javaee_lab -At \
    -c 'SELECT last_value FROM purchase_request_id_seq')
before_line=$(PGPASSWORD="$JAVAEE_LAB_PASSWORD" psql -h 127.0.0.1 -U javaee_lab -d javaee_lab -At \
    -c 'SELECT last_value FROM purchase_line_id_seq')
response=$(mktemp)
trap 'rm -f "$response"' EXIT
status=$(curl -sS --max-time 20 -X POST -H "X-Lab-Tenant: $tenant" -H 'Content-Type: application/json' \
    -d '{"items":[{"sku":"paper","quantity":2}]}' -o "$response" -w '%{http_code}' \
    "http://127.0.0.1:${JAVAEE_PORT}/procurement/api/lab/requests/abort")
printf 'tenant=%s injected_failure_http=%s\n' "$tenant" "$status"
if [[ "$status" != '500' ]]; then cat "$response" >&2; exit 1; fi

remaining=$(PGPASSWORD="$JAVAEE_LAB_PASSWORD" psql -h 127.0.0.1 -U javaee_lab -d javaee_lab -At \
    -c "SELECT COUNT(*) FROM purchase_request WHERE tenant_id = '$tenant'")
after_request=$(PGPASSWORD="$JAVAEE_LAB_PASSWORD" psql -h 127.0.0.1 -U javaee_lab -d javaee_lab -At \
    -c 'SELECT last_value FROM purchase_request_id_seq')
after_line=$(PGPASSWORD="$JAVAEE_LAB_PASSWORD" psql -h 127.0.0.1 -U javaee_lab -d javaee_lab -At \
    -c 'SELECT last_value FROM purchase_line_id_seq')
printf 'committed_requests_after_failure=%s request_sequence=%s->%s line_sequence=%s->%s\n' \
    "$remaining" "$before_request" "$after_request" "$before_line" "$after_line"
if [[ "$remaining" != '0' || "$after_request" -le "$before_request" || "$after_line" -le "$before_line" ]]; then exit 1; fi
