package blog.javaee.web;

import jakarta.annotation.Resource;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@ApplicationScoped
public class TwoResourcePosting {
    @Resource(lookup = "jdbc/PurchaseXA") DataSource purchase;
    @Resource(lookup = "jdbc/SettlementXA") DataSource settlement;

    @Transactional(rollbackOn = SQLException.class)
    public void post(long orderId, String businessKey, String failAt) throws SQLException {
        try (Connection first = purchase.getConnection()) {
            insert(first, "posting", orderId, businessKey);
            if ("afterPurchase".equals(failAt)) throw new IllegalStateException("After first resource");
            try (Connection second = settlement.getConnection()) {
                insert(second, "settlement", orderId, businessKey);
                if ("afterBoth".equals(failAt)) throw new IllegalStateException("Before prepare");
            }
        }
    }

    private void insert(Connection connection, String table, long orderId, String businessKey) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT INTO " + table + "(order_id,business_key) VALUES (?,?)")) {
            statement.setLong(1, orderId);
            statement.setString(2, businessKey);
            statement.executeUpdate();
        }
    }
}
