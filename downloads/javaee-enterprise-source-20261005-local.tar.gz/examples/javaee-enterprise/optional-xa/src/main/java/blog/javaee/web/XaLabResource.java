package blog.javaee.web;

import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Response;
import java.sql.SQLException;

@Path("/lab/xa")
public class XaLabResource {
    @Inject TwoResourcePosting posting;

    @POST
    public Response post(@HeaderParam("X-Lab-Tenant") String tenant, @QueryParam("orderId") long orderId,
                         @QueryParam("key") String businessKey, @QueryParam("failAt") String failAt) throws SQLException {
        if (!"true".equals(System.getenv("JAVAEE_DEMO_MODE"))) throw new NotFoundException();
        if (tenant == null || tenant.isBlank() || orderId <= 0 || businessKey == null
                || !businessKey.matches("[a-zA-Z0-9_-]{1,100}")
                || (failAt != null && !failAt.equals("afterPurchase") && !failAt.equals("afterBoth"))) {
            throw new BadRequestException("Invalid lab request");
        }
        posting.post(orderId, businessKey, failAt);
        return Response.noContent().build();
    }
}
