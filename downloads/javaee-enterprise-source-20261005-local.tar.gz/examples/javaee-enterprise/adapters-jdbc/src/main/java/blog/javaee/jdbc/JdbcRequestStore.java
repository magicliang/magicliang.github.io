package blog.javaee.jdbc;

import blog.javaee.application.RequestStore;
import blog.javaee.application.RequestConflictException;
import blog.javaee.application.RequestMissingException;
import blog.javaee.domain.LineItem;
import blog.javaee.domain.ProcurementRequest;
import blog.javaee.domain.RequestState;
import jakarta.annotation.Resource;
import jakarta.enterprise.context.ApplicationScoped;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;

@ApplicationScoped
public class JdbcRequestStore implements RequestStore {
    @Resource(lookup = "jdbc/Procurement")
    private DataSource source;

    @Override
    public long insert(ProcurementRequest request) {
        try (Connection connection = source.getConnection();
             PreparedStatement insert = connection.prepareStatement(
                     "INSERT INTO purchase_request(tenant_id, version, status, total) VALUES (?,0,?,?) RETURNING id")) {
            insert.setString(1, request.tenantId());
            insert.setString(2, request.state().name());
            insert.setBigDecimal(3, request.total());
            long id;
            try (ResultSet rows = insert.executeQuery()) {
                if (!rows.next()) throw new IllegalStateException("Missing generated request ID");
                id = rows.getLong(1);
            }
            try (PreparedStatement lineInsert = connection.prepareStatement(
                    "INSERT INTO purchase_line(request_id,sku,unit_price,quantity) VALUES (?,?,?,?)")) {
                for (LineItem line : request.lines()) {
                    lineInsert.setLong(1, id);
                    lineInsert.setString(2, line.sku());
                    lineInsert.setBigDecimal(3, line.unitPrice());
                    lineInsert.setInt(4, line.quantity());
                    lineInsert.addBatch();
                }
                lineInsert.executeBatch();
            }
            return id;
        } catch (SQLException error) {
            throw new IllegalStateException("Insert request failed", error);
        }
    }

    @Override
    public ProcurementRequest find(long id, String tenantId) {
        try (Connection connection = source.getConnection();
             PreparedStatement query = connection.prepareStatement(
                     "SELECT id,tenant_id,version,status,total FROM purchase_request WHERE id=? AND tenant_id=?")) {
            query.setLong(1, id);
            query.setString(2, tenantId);
            try (ResultSet rows = query.executeQuery()) {
                if (!rows.next()) throw new RequestMissingException();
                try (PreparedStatement linesQuery = connection.prepareStatement(
                        "SELECT sku,unit_price,quantity FROM purchase_line WHERE request_id=? ORDER BY id")) {
                    linesQuery.setLong(1, id);
                    List<LineItem> lines = new ArrayList<>();
                    try (ResultSet lineRows = linesQuery.executeQuery()) {
                        while (lineRows.next()) lines.add(new LineItem(lineRows.getString(1), lineRows.getBigDecimal(2), lineRows.getInt(3)));
                    }
                    return new ProcurementRequest(rows.getLong(1), rows.getString(2), rows.getLong(3),
                            RequestState.valueOf(rows.getString(4)), rows.getBigDecimal(5), lines);
                }
            }
        } catch (SQLException error) {
            throw new IllegalStateException("Load request failed", error);
        }
    }

    @Override
    public void transition(ProcurementRequest before, RequestState next) {
        try (Connection connection = source.getConnection();
             PreparedStatement update = connection.prepareStatement("""
                     UPDATE purchase_request SET status=?, version=version+1
                     WHERE id=? AND tenant_id=? AND status=? AND version=?
                     """)) {
            update.setString(1, next.name());
            update.setLong(2, before.id());
            update.setString(3, before.tenantId());
            update.setString(4, before.state().name());
            update.setLong(5, before.version());
            if (update.executeUpdate() != 1) throw new RequestConflictException("Transition conflict");
        } catch (SQLException error) {
            throw new IllegalStateException("Transition failed", error);
        }
    }

    @Override
    public long insertOrder(long requestId, String tenantId) {
        try (Connection connection = source.getConnection();
             PreparedStatement insert = connection.prepareStatement(
                     "INSERT INTO purchase_order(request_id,tenant_id) VALUES (?,?) ON CONFLICT(request_id) DO NOTHING RETURNING id")) {
            insert.setLong(1, requestId);
            insert.setString(2, tenantId);
            try (ResultSet rows = insert.executeQuery()) {
                if (rows.next()) return rows.getLong(1);
            }
            try (PreparedStatement lookup = connection.prepareStatement(
                    "SELECT id FROM purchase_order WHERE request_id=? AND tenant_id=?")) {
                lookup.setLong(1, requestId);
                lookup.setString(2, tenantId);
                try (ResultSet rows = lookup.executeQuery()) {
                    if (!rows.next()) throw new RequestConflictException("Conflicting order belongs to another tenant");
                    return rows.getLong(1);
                }
            }
        } catch (SQLException error) {
            throw new IllegalStateException("Insert order failed", error);
        }
    }

    @Override
    public long findOrder(long requestId, String tenantId) {
        try (Connection connection = source.getConnection();
             PreparedStatement query = connection.prepareStatement(
                     "SELECT id FROM purchase_order WHERE request_id=? AND tenant_id=?")) {
            query.setLong(1, requestId);
            query.setString(2, tenantId);
            try (ResultSet rows = query.executeQuery()) {
                if (!rows.next()) throw new IllegalStateException("Ordered request has no order");
                return rows.getLong(1);
            }
        } catch (SQLException error) {
            throw new IllegalStateException("Load order failed", error);
        }
    }

    @Override
    public void enqueueOrderCreated(long requestId, String tenantId, long orderId) {
        try (Connection connection = source.getConnection();
             PreparedStatement insert = connection.prepareStatement("""
                     INSERT INTO notification_outbox(request_id, tenant_id, order_id, event_type)
                     VALUES (?, ?, ?, 'ORDER_CREATED')
                     ON CONFLICT(request_id, event_type) DO NOTHING
                     """)) {
            insert.setLong(1, requestId);
            insert.setString(2, tenantId);
            insert.setLong(3, orderId);
            insert.executeUpdate();
        } catch (SQLException error) {
            throw new IllegalStateException("Enqueue order event failed", error);
        }
    }
}
