package blog.javaee.jdbc;

import blog.javaee.application.OutboxStubStore;
import jakarta.annotation.Resource;
import jakarta.enterprise.context.ApplicationScoped;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.OptionalLong;
import javax.sql.DataSource;

@ApplicationScoped
public class JdbcOutboxStubStore implements OutboxStubStore {
    @Resource(lookup = "jdbc/Procurement")
    private DataSource source;

    @Override
    public OptionalLong recordAttempt(String tenantId) {
        try (Connection connection = source.getConnection();
             PreparedStatement select = connection.prepareStatement("""
                     SELECT id FROM notification_outbox
                     WHERE tenant_id = ? AND status = 'PENDING'
                     ORDER BY id LIMIT 1 FOR UPDATE SKIP LOCKED
                     """)) {
            select.setString(1, tenantId);
            try (ResultSet rows = select.executeQuery()) {
                if (!rows.next()) return OptionalLong.empty();
                long eventId = rows.getLong(1);
                try (PreparedStatement update = connection.prepareStatement(
                        "UPDATE notification_outbox SET attempts = attempts + 1 WHERE id = ?")) {
                    update.setLong(1, eventId);
                    if (update.executeUpdate() != 1) throw new IllegalStateException("Outbox event disappeared");
                }
                return OptionalLong.of(eventId);
            }
        } catch (SQLException error) {
            throw new IllegalStateException("Outbox stub failed", error);
        }
    }
}
