package blog.javaee.domain;

import java.math.BigDecimal;
import java.math.RoundingMode;

public record LineItem(String sku, BigDecimal unitPrice, int quantity) {
    public LineItem {
        if (sku == null || sku.isBlank() || unitPrice == null || unitPrice.signum() < 0 || quantity < 1) {
            throw new IllegalArgumentException("Invalid line item");
        }
        try {
            unitPrice = unitPrice.setScale(2, RoundingMode.UNNECESSARY);
        } catch (ArithmeticException error) {
            throw new IllegalArgumentException("Price has more than two nonzero decimal places", error);
        }
        if (unitPrice.precision() > 18) throw new IllegalArgumentException("Price exceeds numeric(18,2)");
    }

    public BigDecimal amount() {
        return unitPrice.multiply(BigDecimal.valueOf(quantity));
    }
}
