package blog.javaee.domain;

import java.math.BigDecimal;
import java.util.List;

public record ProcurementRequest(long id, String tenantId, long version, RequestState state,
                                 BigDecimal total, List<LineItem> lines) {
    public ProcurementRequest {
        if (tenantId == null || tenantId.isBlank()) throw new IllegalArgumentException("Missing tenant");
        lines = List.copyOf(lines);
        if (lines.isEmpty()) throw new IllegalArgumentException("Request needs a line");
        BigDecimal calculated = lines.stream().map(LineItem::amount).reduce(BigDecimal.ZERO, BigDecimal::add);
        if (total == null || total.compareTo(calculated) != 0) throw new IllegalArgumentException("Total must be server calculated");
        if (total.precision() > 18) throw new IllegalArgumentException("Total exceeds numeric(18,2)");
    }

    public static ProcurementRequest draft(String tenantId, List<LineItem> lines) {
        BigDecimal total = lines.stream().map(LineItem::amount).reduce(BigDecimal.ZERO, BigDecimal::add);
        return new ProcurementRequest(0, tenantId, 0, RequestState.DRAFT, total, lines);
    }

    public ProcurementRequest transition(RequestState next) {
        return new ProcurementRequest(id, tenantId, version + 1, state.moveTo(next), total, lines);
    }
}
