package blog.javaee.domain;

public enum RequestState {
    DRAFT, SUBMITTED, APPROVED, REJECTED, ORDERED;

    public RequestState moveTo(RequestState next) {
        boolean allowed = switch (this) {
            case DRAFT -> next == SUBMITTED;
            case SUBMITTED -> next == APPROVED || next == REJECTED;
            case APPROVED -> next == ORDERED;
            case REJECTED, ORDERED -> false;
        };
        if (!allowed) throw new IllegalStateException("Invalid procurement transition: " + this + " to " + next);
        return next;
    }
}
