package blog.javaee.domain;

import java.math.BigDecimal;
import java.util.List;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProcurementRulesTest {
    @Test
    void calculatesTotalAndRejectsInvalidTransition() {
        var request = ProcurementRequest.draft("tenant-one", List.of(new LineItem("pen", new BigDecimal("3.50"), 2)));
        assertEquals(0, new BigDecimal("7.00").compareTo(request.total()));
        assertThrows(IllegalStateException.class, () -> request.transition(RequestState.APPROVED));
        assertEquals(RequestState.ORDERED, request.transition(RequestState.SUBMITTED)
                .transition(RequestState.APPROVED).transition(RequestState.ORDERED).state());
        assertThrows(IllegalStateException.class, () -> request.transition(RequestState.SUBMITTED)
                .transition(RequestState.REJECTED).transition(RequestState.ORDERED));
        assertThrows(IllegalArgumentException.class, () -> new ProcurementRequest(0, "tenant-one", 0,
                RequestState.DRAFT, BigDecimal.ONE, request.lines()));
        assertThrows(IllegalArgumentException.class, () -> new LineItem("pen", new BigDecimal("19.905"), 1));
    }
}
