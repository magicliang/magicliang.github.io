# Java EE 采购审批累计工程

本工程（包含后加的 Batch、XA 与 Spring 对照）是修订时对既有工程的增量，不是从历史日志倒推的旧源码。JPA 独立于此工程；采购主线持续使用 JDBC、显式 SQL、DAO，不引入 JPA 映射。

独立入口：`scenarios/10-json-boundary.sh` 只在回环实例验证 null 元素/未知 JSON 键和数据库终态；`scenarios/35-check-constraint.sh` 要求 SQLSTATE 23514、目标约束名和零残留；`scenarios/38-preflight-and-stage.sh` 仅复制到新的暂存路径，`test-failure-gates.sh` 用替身证明预检失败绝不拷贝。`db/migrations/004-price-import.sql`、`batch-input/sample.csv`、`deploy/server-batch.xml`、`scenarios/34-price-import.sh` 是批处理最小入口；2026-10-05 Liberty 26.0.0.5 的 Batch 内部授权返回 `CWWKY0304W`，虽然 HTTP Basic 已验证且持久 repository 已激活，作业未启动，重启与文件账本仍 NOT_RUN。不能用 202 或成功编译替代它。

`optional-xa/` 是独立 WAR，`deploy/server-xa.xml` 与 `db/xa/` 分别给出两项 XA 资源/表；`scenarios/E05-xa.sh` 的受控异常仅在 prepare 之前，`E05-xa-readback.sh` 只读取两库行数与 prepared xact 数。需要两套真正独立的 PostgreSQL 实例及 Liberty 恢复日志；prepare 后的进程故障与恢复尚未实现，E05 NOT_RUN。`comparison-spring/` 冻结 Spring Boot 3.5.7/MyBatis starter 3.0.5，独立 `clean verify` 与单侧 PostgreSQL 正常/异常回滚有证据；CLI 的主体参数是隔离模拟输入，不提供认证。两侧同数据集与权限矩阵仍未验证，E06 PARTIAL。增量和原始验证结果见 `../../writing-plans/javaee-enterprise/verification/20261005T-revision/RUN.md`。

版本基线：OpenJDK 21、Jakarta EE 11 Platform、Open Liberty 26.0.0.5、Maven Wrapper 3.9.9、PostgreSQL 16.15、pgJDBC 42.7.7。各自产品兼容资料与**实际部署**证据分开看 `../../writing-plans/javaee-enterprise/VERSIONS.md`；本工程只在隔离环境运行，不要部署博客或改生产数据库。

`domain/` 定义同 JPA 系列对照的采购状态机及金额约束；`application/` 用 CDI 与受管事务实施用例，价格由服务端固定目录获取；`adapters-jdbc/` 使用 `javax.sql.DataSource`、PreparedStatement 与显式 PostgreSQL SQL；`webapp/` 构建单 WAR。`/api/health` 和 `/api/db-check` 无认证，仅适用于回环探针；`JAVAEE_DEMO_MODE=true` 才允许教学采购、Faces 页面审批动作和 broker 试验路由；`approval.xhtml` 的空表单 GET 在关闭开关时仍可渲染。采购用例尚**未通过正式认证/授权的 HTTP 接口开放**：`X-Lab-Tenant` 由客户端伪造，拥有一个租户 ID 不等于通过登录鉴权。`002` 迁移及同库 outbox stub、`003` 收据和 Liberty 内嵌持久消息引擎、单个受管执行器已做局部实验，但没有正式租户身份、MDB 死信、外部通知网关、XA、安全验收或第 39 篇完整交付验收。

```bash
cd examples/javaee-enterprise
../hibernate-lab/mvnw -B -ntp -f "$PWD/pom.xml" clean verify
```

若需要运行容器，先创建**独立**的 PostgreSQL `javaee_lab` 和专用角色，在确认库名后用 `psql -1 -v ON_ERROR_STOP=1 -f` **按 001、002、003 顺序各执行一次**对应的 `db/migrations/*.sql`；不要共用 `jpa_lab`，也不要在已有表上重跑非幂等建表脚本。后两次迁移只验证本机底座上的增量，不证明任意旧库无损升级。从 Maven 仓库取 Open Liberty 26.0.0.5 ZIP 时先验证同发布物官方仓库提供的 SHA-256；基础配置 `deploy/server.xml` 使用 `jakartaee-11.0`，受管 DataSource 只接 `javaee_lab`。本机隔离运行示例，口令必须由本机自行提供并保留在进程环境而非仓库：

```bash
export JAVAEE_PORT=9085
export JAVAEE_LAB_USER='<your-local-db-role>'
export JAVAEE_LAB_PASSWORD='<your-local-secret>'
export JAVAEE_REGISTRY_PASSWORD='<separate-local-registry-secret>'
export JAVAEE_DRIVER_DIR="$HOME/.m2/repository/org/postgresql/postgresql/42.7.7"
mkdir -p /path/to/wlp/usr/servers/procurement/apps
cp webapp/target/procurement-webapp-1.0-SNAPSHOT.war /path/to/wlp/usr/servers/procurement/apps/procurement.war
export JAVAEE_WAR=/path/to/wlp/usr/servers/procurement/apps/procurement.war
cp deploy/server.xml /path/to/wlp/usr/servers/procurement/server.xml
/path/to/wlp/bin/server start procurement
bash scenarios/00-health.sh
bash scenarios/05-datasource.sh
```

`db-check` 查询 `SELECT current_database()`，只有独立库 `javaee_lab` 才返回 `connected`；仅用于绑定到 127.0.0.1 的隔离教学运行时，不能暴露成生产公共端点。

第 32 篇的独立供应商故障 stub 位于 `stubs/supplier/`，用 JDK 21 编译，执行 `bash stubs/supplier/selfcheck.sh` 可复现慢响应、错误、提交后断连和重启同键去重；它只绑定回环且不连接采购 WAR，不证明 Jakarta REST 出站客户端、业务确认状态或供应商通知已完成。手动运行及留证边界见 `stubs/supplier/README.md`。

容器事务的故障注入只能在同样隔离且启用 `JAVAEE_DEMO_MODE=true` 的环境执行：`JAVAEE_PORT=9085 JAVAEE_DEMO_MODE=true JAVAEE_LAB_USER=javaee_lab JAVAEE_LAB_PASSWORD='<真实本地密码>' bash scenarios/18-lab-rollback.sh`。脚本要求插入申请/明细之后人为抛错返回 HTTP 500，并通过独立连接检查该测试租户的请求行数仍为 0；这不覆盖提交确认丢失、XA 或出站消息。

`JAVAEE_DEMO_MODE=true` 仅允许在本机隔离环境启用 `/api/lab/requests`、`/api/lab/broker` 和页面的未认证教学路径；`X-Lab-Tenant` 是由测试客户端提供的**不可信演示值**，不是已验证身份。实际授权、跨租户不可冒用等需求仍待 24–26 篇实现和容器测试，绝不可对公网开启该模式。受控运行可用 `JAVAEE_PORT=9085 JAVAEE_DEMO_MODE=true JAVAEE_LAB_USER=javaee_lab JAVAEE_LAB_PASSWORD='<真实本地密码>' bash scenarios/09-lab-procurement.sh`；该脚本只断言测试租户的数据及最终数据库行，不能证明真实用户身份或通知送达。

增量试验分别执行 `scenarios/11-faces.sh`、`scenarios/23-outbox-stub.sh`。仅在复制 `deploy/server-messaging.xml` 作为**本机** server 配置，并保证 JMS 7277 也只监听 `127.0.0.1` 后，再执行 `scenarios/30-broker-lab.sh` 和 `scenarios/33-managed-outbox.sh`。脚本依赖 `curl`、`jq`、`psql` 和私有环境变量中的 `JAVAEE_LAB_PASSWORD`；30 的消息代理是 Liberty 进程内真实持久消息引擎，不是独立外部 broker。结果依次是任务尝试、broker 接受、消费收据三个不同事实；收据表不能证明向外部供应商发送通知。原始构建摘要和步骤证据分别在 `writing-plans/javaee-enterprise/verification/20261004T-outbox-stub/`、`20261004T-broker-lab/`、`20261004T-managed-outbox/`。

上面 `/path/to/wlp`、尖括号口令是需替换的说明，不是预配置的可用凭证；可以改用 `server run` 前台观察日志。`GET /health` 返回 200 只能说明健康端点可响应，不能证明采购数据库事务、租户权限或通知完成。`db/migrations` 与 `scenarios` 随篇号增量扩展，实验未实测的项目按 `writing-plans/javaee-enterprise/STATUS.md` 标记 NOT_RUN。
