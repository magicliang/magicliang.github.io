package blog.javaee.web;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BoundedUploadTest {
    @TempDir Path directory;

    @Test
    void limitFailureRemovesTemporary() throws IOException {
        Path temporary = Files.createTempFile(directory, "upload", ".tmp");
        IOException failure = assertThrows(IOException.class, () ->
                BoundedUpload.copy(new ByteArrayInputStream(new byte[3]), temporary, 2));
        assertEquals("Upload limit exceeded", failure.getMessage());
        assertFalse(Files.exists(temporary));
    }

    @Test
    void cleanupFailureDoesNotReplaceOriginal() throws IOException {
        Path temporary = Files.createDirectory(directory.resolve("nonempty"));
        Files.createFile(temporary.resolve("child"));
        IOException failure = assertThrows(IOException.class, () ->
                BoundedUpload.copy(new ByteArrayInputStream(new byte[0]), temporary, 1));
        assertEquals(1, failure.getSuppressed().length);
        assertTrue(Files.exists(temporary));
    }
}
