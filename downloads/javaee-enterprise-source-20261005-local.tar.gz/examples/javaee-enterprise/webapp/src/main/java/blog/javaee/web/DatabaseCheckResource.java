package blog.javaee.web;

import jakarta.annotation.Resource;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;

@Path("/db-check")
public class DatabaseCheckResource {
    @Resource(lookup = "jdbc/Procurement")
    private DataSource source;

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String check() {
        try (Connection connection = source.getConnection();
             PreparedStatement query = connection.prepareStatement("SELECT current_database()")) {
            try (ResultSet rows = query.executeQuery()) {
                if (!rows.next() || !"javaee_lab".equals(rows.getString(1))) {
                    throw new IllegalStateException("Unexpected database target");
                }
            }
            return "connected";
        } catch (SQLException error) {
            throw new IllegalStateException("Database connection unavailable", error);
        }
    }
}
