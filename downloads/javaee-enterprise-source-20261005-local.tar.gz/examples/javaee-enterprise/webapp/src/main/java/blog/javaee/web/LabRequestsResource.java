package blog.javaee.web;

import blog.javaee.application.ProcurementUseCases;
import blog.javaee.application.OutboxStubPublisher;
import blog.javaee.application.RequestConflictException;
import blog.javaee.application.RequestMissingException;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.OptionalLong;

@Path("/lab/requests")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class LabRequestsResource {
    @Inject
    private ProcurementUseCases useCases;

    @Inject
    private OutboxStubPublisher outboxStub;

    public static class CreateInput {
        @NotEmpty
        public List<@NotNull @Valid ItemInput> items;
    }

    public static class ItemInput {
        @NotBlank
        public String sku;
        @Positive
        public int quantity;
    }

    @POST
    public Response draft(@Valid CreateInput input, @HeaderParam("X-Lab-Tenant") String tenant) {
        requireLab(tenant);
        try {
            long id = useCases.draft(tenant, itemInputs(input));
            return Response.created(URI.create("/procurement/api/lab/requests/" + id))
                    .entity(Map.of("id", id)).build();
        } catch (IllegalArgumentException error) {
            throw new BadRequestException("Invalid request fields");
        }
    }

    @POST @Path("/abort")
    public Response abort(CreateInput input, @HeaderParam("X-Lab-Tenant") String tenant) {
        requireLab(tenant);
        useCases.draftThenAbortForLab(tenant, itemInputs(input));
        throw new IllegalStateException("Failure injection did not abort");
    }

    private List<ProcurementUseCases.ItemInput> itemInputs(CreateInput input) {
        if (input == null || input.items == null) throw new BadRequestException("Items required");
        return input.items.stream().map(item -> {
            if (item == null) throw new BadRequestException("Null item");
            return new ProcurementUseCases.ItemInput(item.sku, item.quantity);
        }).toList();
    }

    @POST @Path("/{id}/submit")
    public Response submit(@PathParam("id") long id, @HeaderParam("X-Lab-Tenant") String tenant) {
        requireLab(tenant);
        useCases.submit(id, tenant);
        return Response.noContent().build();
    }

    @POST @Path("/{id}/approve")
    public Response approve(@PathParam("id") long id, @HeaderParam("X-Lab-Tenant") String tenant) {
        requireLab(tenant);
        useCases.approve(id, tenant);
        return Response.noContent().build();
    }

    @POST @Path("/{id}/reject")
    public Response reject(@PathParam("id") long id, @HeaderParam("X-Lab-Tenant") String tenant) {
        requireLab(tenant);
        useCases.reject(id, tenant);
        return Response.noContent().build();
    }

    @POST @Path("/{id}/order")
    public Response order(@PathParam("id") long id, @HeaderParam("X-Lab-Tenant") String tenant) {
        requireLab(tenant);
        return Response.ok(Map.of("orderId", useCases.order(id, tenant))).build();
    }

    @POST @Path("/outbox/attempt")
    public Response attemptStub(@HeaderParam("X-Lab-Tenant") String tenant,
                                @QueryParam("abortAfterUpdate") boolean abortAfterUpdate) {
        requireLab(tenant);
        OptionalLong eventId = outboxStub.attempt(tenant, abortAfterUpdate);
        if (eventId.isEmpty()) return Response.noContent().build();
        return Response.ok(Map.of("eventId", eventId.getAsLong())).build();
    }

    private void requireLab(String tenant) {
        if (!"true".equals(System.getenv("JAVAEE_DEMO_MODE"))) throw new NotFoundException();
        if (tenant == null || tenant.isBlank()) throw new BadRequestException("Lab tenant required");
    }
}
