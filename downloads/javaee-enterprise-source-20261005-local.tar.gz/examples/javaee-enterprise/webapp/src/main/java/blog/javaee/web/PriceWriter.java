package blog.javaee.web;

import jakarta.annotation.Resource;
import jakarta.batch.api.BatchProperty;
import jakarta.batch.api.chunk.ItemWriter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

@Dependent
@Named("priceWriter")
public class PriceWriter implements ItemWriter {
    @Resource(lookup = "jdbc/Procurement") DataSource database;
    @Inject @BatchProperty(name = "fileName") String fileName;
    @Inject @BatchProperty(name = "failAtLine") String failAtLine;

    @Override
    public void open(Serializable checkpoint) { }

    @Override
    public void writeItems(List<Object> items) throws Exception {
        try (Connection connection = database.getConnection();
             PreparedStatement accepted = connection.prepareStatement(
                     "INSERT INTO supplier_price(file_id,line_no,sku,price) VALUES (?,?,?,?) ON CONFLICT DO NOTHING");
             PreparedStatement rejected = connection.prepareStatement(
                     "INSERT INTO supplier_price_rejection(file_id,line_no,reason) VALUES (?,?,?) ON CONFLICT DO NOTHING")) {
            for (Object item : items) {
                PriceReader.PriceLine line = (PriceReader.PriceLine) item;
                if (failAtLine != null && !failAtLine.isBlank()
                        && line.number() == Integer.parseInt(failAtLine)) {
                    throw new IllegalStateException("Injected before chunk write: " + line.number());
                }
                String[] columns = line.text().split(",", -1);
                try {
                    if (columns.length != 2 || !columns[0].matches("[a-zA-Z0-9_-]{1,100}")) {
                        throw new IllegalArgumentException("Invalid fields");
                    }
                    BigDecimal price = new BigDecimal(columns[1]).setScale(2, RoundingMode.UNNECESSARY);
                    if (price.signum() <= 0) throw new IllegalArgumentException("Nonpositive price");
                    accepted.setString(1, fileName);
                    accepted.setInt(2, line.number());
                    accepted.setString(3, columns[0]);
                    accepted.setBigDecimal(4, price);
                    accepted.executeUpdate();
                } catch (IllegalArgumentException exception) {
                    rejected.setString(1, fileName);
                    rejected.setInt(2, line.number());
                    rejected.setString(3, exception.getMessage());
                    rejected.executeUpdate();
                }
            }
        }
    }

    @Override
    public Serializable checkpointInfo() { return null; }

    @Override
    public void close() { }
}
