package blog.javaee.web;

import blog.javaee.application.RequestConflictException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;

@Provider
public class ConflictMapper implements ExceptionMapper<RequestConflictException> {
    @Override
    public Response toResponse(RequestConflictException error) {
        return Response.status(Response.Status.CONFLICT).build();
    }
}
