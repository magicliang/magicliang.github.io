package blog.javaee.web;

import jakarta.annotation.Resource;
import jakarta.enterprise.concurrent.ManagedExecutorService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.DeliveryMode;
import jakarta.jms.JMSContext;
import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.Queue;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

@Path("/lab/broker")
@ApplicationScoped
@Produces(MediaType.APPLICATION_JSON)
public class BrokerLabResource {
    @Resource(lookup = "jdbc/Procurement")
    private DataSource source;

    @Resource(lookup = "java:comp/DefaultManagedExecutorService")
    private ManagedExecutorService executor;

    private final Semaphore availableWorkers = new Semaphore(1);
    private final Logger logger = Logger.getLogger(BrokerLabResource.class.getName());

    @POST @Path("/send-next")
    public Response sendNext(@QueryParam("tenant") String tenant,
                             @QueryParam("abortAfterSend") boolean abortAfterSend) {
        requireLab();
        if (tenant == null || tenant.isBlank()) throw new IllegalArgumentException("Lab tenant required");
        Event event = nextPending(tenant);
        if (event == null) return Response.noContent().build();
        try (JMSContext context = connectionFactory().createContext(JMSContext.SESSION_TRANSACTED)) {
            Message message = context.createTextMessage(Long.toString(event.id()));
            context.createProducer().setDeliveryMode(DeliveryMode.PERSISTENT).send(queue(), message);
            context.commit();
        }
        if (abortAfterSend) throw new IllegalStateException("Injected failure after broker commit");
        markPublished(event.id());
        return Response.ok(Map.of("eventId", event.id())).build();
    }

    @POST @Path("/schedule")
    public Response schedule(@QueryParam("tenant") String tenant) {
        requireLab();
        if (tenant == null || tenant.isBlank()) throw new IllegalArgumentException("Lab tenant required");
        if (!availableWorkers.tryAcquire()) return Response.status(429).build();
        try {
            executor.execute(() -> {
                try {
                    sendNext(tenant, false);
                } catch (RuntimeException error) {
                    logger.log(Level.WARNING, "Managed outbox attempt failed", error);
                } finally {
                    availableWorkers.release();
                }
            });
        } catch (RejectedExecutionException error) {
            availableWorkers.release();
            return Response.status(503).build();
        }
        return Response.accepted().build();
    }

    @POST @Path("/receive-one")
    public Response receiveOne(@QueryParam("abortAfterRecord") boolean abortAfterRecord) {
        requireLab();
        try (JMSContext context = connectionFactory().createContext(JMSContext.SESSION_TRANSACTED)) {
            Message message = context.createConsumer(queue()).receive(2000);
            if (message == null) {
                context.rollback();
                return Response.noContent().build();
            }
            long eventId;
            try {
                eventId = Long.parseLong(message.getBody(String.class));
            } catch (JMSException error) {
                context.rollback();
                throw new IllegalStateException("Unreadable broker event", error);
            }
            boolean newReceipt = recordReceipt(eventId);
            if (abortAfterRecord) {
                context.rollback();
                throw new IllegalStateException("Injected failure after receipt commit, before JMS ack");
            }
            context.commit();
            return Response.ok(Map.of("eventId", eventId, "newReceipt", newReceipt)).build();
        }
    }

    private Event nextPending(String tenant) {
        try (Connection connection = source.getConnection();
             PreparedStatement select = connection.prepareStatement("""
                     SELECT id FROM notification_outbox
                     WHERE status = 'PENDING' AND tenant_id = ? ORDER BY id LIMIT 1
                     """)) {
            select.setString(1, tenant);
            try (ResultSet rows = select.executeQuery()) {
                return rows.next() ? new Event(rows.getLong(1)) : null;
            }
        } catch (SQLException error) {
            throw new IllegalStateException("Load pending event failed", error);
        }
    }

    private void markPublished(long eventId) {
        try (Connection connection = source.getConnection();
             PreparedStatement update = connection.prepareStatement("""
                     UPDATE notification_outbox SET status = 'PUBLISHED', published_at = current_timestamp
                     WHERE id = ? AND status = 'PENDING'
                     """)) {
            update.setLong(1, eventId);
            if (update.executeUpdate() != 1) throw new IllegalStateException("Outbox publish status changed");
        } catch (SQLException error) {
            throw new IllegalStateException("Mark published failed", error);
        }
    }

    private boolean recordReceipt(long eventId) {
        try (Connection connection = source.getConnection();
             PreparedStatement insert = connection.prepareStatement("""
                     INSERT INTO notification_receipt(event_id, tenant_id)
                     SELECT id, tenant_id FROM notification_outbox WHERE id = ?
                     ON CONFLICT(event_id) DO NOTHING
                     """)) {
            insert.setLong(1, eventId);
            if (insert.executeUpdate() == 1) return true;
            try (PreparedStatement exists = connection.prepareStatement(
                    "SELECT 1 FROM notification_receipt WHERE event_id = ?")) {
                exists.setLong(1, eventId);
                try (ResultSet rows = exists.executeQuery()) {
                    if (!rows.next()) throw new IllegalStateException("Unknown outbox event");
                }
            }
            return false;
        } catch (SQLException error) {
            throw new IllegalStateException("Record broker receipt failed", error);
        }
    }

    private ConnectionFactory connectionFactory() {
        try {
            return (ConnectionFactory) new InitialContext().lookup("jms/ProcurementCF");
        } catch (NamingException error) {
            throw new IllegalStateException("Messaging is not configured", error);
        }
    }

    private Queue queue() {
        try {
            return (Queue) new InitialContext().lookup("jms/ProcurementNotifications");
        } catch (NamingException error) {
            throw new IllegalStateException("Notification queue is not configured", error);
        }
    }

    private void requireLab() {
        if (!"true".equals(System.getenv("JAVAEE_DEMO_MODE"))) throw new NotFoundException();
    }

    private record Event(long id) {}
}
