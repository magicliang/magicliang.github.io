package blog.javaee.web;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;

@WebServlet("/servlet/echo")
public class RequestEchoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String[] values = request.getParameterValues("value");
        if (values == null || values.length == 0 || values.length > 5 ||
                Arrays.stream(values).anyMatch(value -> value.length() > 100)) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Expected 1-5 short values");
            return;
        }
        response.setContentType("text/plain;charset=UTF-8");
        response.getWriter().write(String.join("|", values));
    }
}
