package blog.javaee.web;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.UUID;

@WebServlet("/servlet/lab-session")
public class LabSessionServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        requireLocalLab(request, response);
        if (response.isCommitted()) return;
        response.setHeader("Cache-Control", "no-store");
        response.setContentType("text/plain;charset=UTF-8");
        HttpSession session = request.getSession(false);
        response.getWriter().write(session == null ? "inactive" : "active");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        requireLocalLab(request, response);
        if (response.isCommitted()) return;
        String action = request.getParameter("action");
        if ("start".equals(action)) {
            HttpSession existing = request.getSession(false);
            if (existing != null) request.changeSessionId();
            HttpSession session = request.getSession(true);
            session.setAttribute("labNonce", UUID.randomUUID().toString());
            response.setStatus(HttpServletResponse.SC_NO_CONTENT);
        } else if ("end".equals(action)) {
            HttpSession session = request.getSession(false);
            if (session != null) session.invalidate();
            response.setStatus(HttpServletResponse.SC_NO_CONTENT);
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Unknown session operation");
        }
    }

    private void requireLocalLab(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (!"true".equals(System.getenv("JAVAEE_DEMO_MODE")) || !request.getLocalAddr().equals("127.0.0.1")) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
}
