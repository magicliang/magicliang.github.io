package blog.javaee.web;

import blog.javaee.application.ProcurementUseCases;
import blog.javaee.application.RequestConflictException;
import blog.javaee.application.RequestMissingException;
import jakarta.enterprise.context.RequestScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named("labApprovalPage")
@RequestScoped
public class LabApprovalPage {
    @Inject
    private ProcurementUseCases useCases;
    private long requestId;
    private String tenantId;
    private String result;

    public long getRequestId() { return requestId; }
    public void setRequestId(long requestId) { this.requestId = requestId; }
    public String getTenantId() { return tenantId; }
    public void setTenantId(String tenantId) { this.tenantId = tenantId; }
    public String getResult() { return result; }

    public String approve() {
        if (!"true".equals(System.getenv("JAVAEE_DEMO_MODE"))) {
            throw new IllegalStateException("Lab mode disabled");
        }
        try {
            useCases.approve(requestId, tenantId);
            result = "approved";
        } catch (RequestConflictException | RequestMissingException error) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Approval rejected", null));
            result = "rejected";
        }
        return null;
    }
}
