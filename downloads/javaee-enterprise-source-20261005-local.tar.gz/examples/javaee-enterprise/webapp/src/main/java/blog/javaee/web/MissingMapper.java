package blog.javaee.web;

import blog.javaee.application.RequestMissingException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;

@Provider
public class MissingMapper implements ExceptionMapper<RequestMissingException> {
    @Override
    public Response toResponse(RequestMissingException error) {
        return Response.status(Response.Status.NOT_FOUND).build();
    }
}
