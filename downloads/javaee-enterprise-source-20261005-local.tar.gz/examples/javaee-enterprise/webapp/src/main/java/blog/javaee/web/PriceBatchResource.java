package blog.javaee.web;

import jakarta.batch.operations.JobOperator;
import jakarta.batch.runtime.BatchRuntime;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Response;
import java.util.Map;
import java.util.Properties;

@Path("/lab/batch")
public class PriceBatchResource {
    @GET @Path("/{executionId}")
    public Response status(@HeaderParam("X-Lab-Tenant") String tenant,
                           @PathParam("executionId") long executionId) {
        requireLab(tenant);
        var execution = operator().getJobExecution(executionId);
        if (execution == null) throw new NotFoundException();
        return Response.ok(Map.of("status", execution.getBatchStatus().toString(),
                "exitStatus", execution.getExitStatus() == null ? "" : execution.getExitStatus())).build();
    }

    @POST
    public Response start(@HeaderParam("X-Lab-Tenant") String tenant,
                          @QueryParam("fileName") String fileName,
                          @QueryParam("failAtLine") String failAtLine) {
        requireLab(tenant);
        Properties parameters = parameters(fileName, failAtLine);
        return Response.accepted(Map.of("executionId", operator().start("price-import", parameters))).build();
    }

    @POST @Path("/{executionId}/restart")
    public Response restart(@HeaderParam("X-Lab-Tenant") String tenant,
                            @PathParam("executionId") long executionId,
                            @QueryParam("fileName") String fileName) {
        requireLab(tenant);
        return Response.accepted(Map.of("executionId", operator().restart(executionId, parameters(fileName, "")))).build();
    }

    private Properties parameters(String fileName, String failAtLine) {
        if (fileName == null || !fileName.matches("[a-zA-Z0-9_.-]{1,100}")) {
            throw new BadRequestException("Invalid file name");
        }
        Properties parameters = new Properties();
        parameters.setProperty("fileName", fileName);
        parameters.setProperty("failAtLine", failAtLine == null ? "" : failAtLine);
        return parameters;
    }

    private void requireLab(String tenant) {
        if (!"true".equals(System.getenv("JAVAEE_DEMO_MODE"))) throw new NotFoundException();
        if (tenant == null || tenant.isBlank()) throw new BadRequestException("Lab tenant required");
    }

    private JobOperator operator() { return BatchRuntime.getJobOperator(); }
}
