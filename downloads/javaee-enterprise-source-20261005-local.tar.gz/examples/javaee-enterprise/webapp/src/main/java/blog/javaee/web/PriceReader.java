package blog.javaee.web;

import jakarta.batch.api.BatchProperty;
import jakarta.batch.api.chunk.ItemReader;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.HexFormat;

@Dependent
@Named("priceReader")
public class PriceReader implements ItemReader {
    public record PriceLine(int number, String text) { }
    public record Position(String sha256, int nextLine) implements Serializable { }

    @Inject @BatchProperty(name = "fileName") String fileName;
    private List<String> lines;
    private String sha256;
    private int nextLine;

    @Override
    public void open(Serializable checkpoint) throws Exception {
        if (fileName == null || !fileName.matches("[a-zA-Z0-9_.-]{1,100}")) {
            throw new IllegalArgumentException("Invalid input name");
        }
        String inputDir = System.getenv("JAVAEE_BATCH_DIR");
        if (inputDir == null) throw new IllegalStateException("JAVAEE_BATCH_DIR required");
        Path input = Path.of(inputDir, fileName);
        if (Files.size(input) > 1_000_000) throw new IllegalArgumentException("Input too large");
        byte[] content = Files.readAllBytes(input);
        sha256 = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(content));
        lines = new String(content, StandardCharsets.UTF_8).lines().toList();
        if (lines.size() > 1000) throw new IllegalArgumentException("Too many records");
        if (checkpoint instanceof Position position) {
            if (!sha256.equals(position.sha256()) || position.nextLine() > lines.size()) {
                throw new IllegalStateException("Input changed after checkpoint");
            }
            nextLine = position.nextLine();
        }
    }

    @Override
    public Object readItem() {
        if (nextLine == lines.size()) return null;
        return new PriceLine(++nextLine, lines.get(nextLine - 1));
    }

    @Override
    public Serializable checkpointInfo() {
        return new Position(sha256, nextLine);
    }

    @Override
    public void close() { }
}
