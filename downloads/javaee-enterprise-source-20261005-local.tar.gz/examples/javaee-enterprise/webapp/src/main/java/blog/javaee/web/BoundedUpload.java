package blog.javaee.web;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

public final class BoundedUpload {
    private BoundedUpload() { }

    public static long copy(InputStream input, Path temporary, long limit) throws IOException {
        long total = 0;
        try (OutputStream output = Files.newOutputStream(temporary)) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) {
                if (count > limit - total) throw new IOException("Upload limit exceeded");
                output.write(buffer, 0, count);
                total += count;
            }
            return total;
        } catch (IOException failure) {
            try {
                Files.deleteIfExists(temporary);
            } catch (IOException cleanupFailure) {
                failure.addSuppressed(cleanupFailure);
            }
            throw failure;
        }
    }
}
