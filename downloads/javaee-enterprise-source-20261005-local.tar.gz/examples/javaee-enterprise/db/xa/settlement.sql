CREATE TABLE settlement (
    order_id bigint PRIMARY KEY,
    business_key varchar(100) NOT NULL UNIQUE
);
