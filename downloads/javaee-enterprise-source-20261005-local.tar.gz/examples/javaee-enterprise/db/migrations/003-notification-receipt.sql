CREATE TABLE notification_receipt (
    event_id bigint PRIMARY KEY REFERENCES notification_outbox(id),
    tenant_id varchar(255) NOT NULL,
    received_at timestamptz NOT NULL DEFAULT current_timestamp
);
