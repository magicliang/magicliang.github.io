CREATE TABLE supplier_price (
    file_id varchar(100) NOT NULL,
    line_no integer NOT NULL,
    sku varchar(100) NOT NULL,
    price numeric(18,2) NOT NULL CHECK (price > 0),
    PRIMARY KEY (file_id, line_no)
);
CREATE TABLE supplier_price_rejection (
    file_id varchar(100) NOT NULL,
    line_no integer NOT NULL,
    reason varchar(100) NOT NULL,
    PRIMARY KEY (file_id, line_no)
);
