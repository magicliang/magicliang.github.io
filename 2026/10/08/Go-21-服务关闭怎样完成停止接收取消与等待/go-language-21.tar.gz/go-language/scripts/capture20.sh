#!/usr/bin/env bash
set -u
root=$(cd "$(dirname "$0")/../../.." && pwd)
evidence="$root/writing-plans/go-language/evidence/20"
mkdir -p "$evidence"
export PATH="/tmp/go-language-toolchain-1.27.1/go/bin:$PATH"
export GOTOOLCHAIN=local GOWORK=off GOMAXPROCS=2 CGO_ENABLED=1
cd "$root/examples/go-language" || exit 1
date -Ins > "$evidence/environment.txt"
uname -smr >> "$evidence/environment.txt"
go version >> "$evidence/environment.txt"
go env GOOS GOARCH GOTOOLCHAIN GOWORK GOMAXPROCS CGO_ENABLED CC GOMOD >> "$evidence/environment.txt"
gcc --version | head -1 >> "$evidence/environment.txt"

capture() {
  local name=$1 command=$2 status
  printf '%s\n' "$command" > "$evidence/$name.command"
  bash -c "$command" > "$evidence/$name.stdout" 2> "$evidence/$name.stderr"
  status=$?
  printf '%s\n' "$status" > "$evidence/$name.exit"
  printf '%s exit=%s\n' "$name" "$status"
}

capture spec-channel "sed -n '360,413p' /tmp/go-language-toolchain-1.27.1/go/doc/go_mem.html"
capture spec-buffer "sed -n '1730,1754p;6105,6129p' /tmp/go-language-toolchain-1.27.1/go/doc/go_spec.html"
capture doc-context 'go doc context.Context'
capture doc-wait 'go doc sync.WaitGroup'
capture tidy 'go mod tidy -diff'
capture focused "go test -count=1 -run 'TestBoundedPool|TestCLIWorkerAndQueueLimits' -v ."
capture repeat "go test -count=50 -run 'TestBoundedPool|TestCLIWorkerAndQueueLimits|TestCancelRequestWaitsForWorkerExit|TestStoreRaceScenario' -v ."
capture tests 'go test -count=1 -v ./...'
capture race 'go test -race -count=1 ./...'
capture build 'go build -o /tmp/go-language-20-taskstats .'
capture cli-batch "/tmp/go-language-20-taskstats --batch 'Go|one two|Go' --workers 2 --queue-capacity 1"
capture cli-invalid '/tmp/go-language-20-taskstats --text Go --workers 0'
capture cli-empty "/tmp/go-language-20-taskstats --batch 'Go|' --workers 2 --queue-capacity 1"
capture cli-timeout '/tmp/go-language-20-taskstats --text Go --timeout 0s --workers 2'
capture module 'go list -m all'
