package stats

import (
	"context"
	"strings"
	"unicode"
	"unicode/utf8"
)

type Counts struct {
	Words int
	Bytes int
	Runes int
}

func CountWords(text string) int {
	return len(strings.Fields(text))
}

func Analyze(text string) Counts {
	return Counts{
		Words: CountWords(text),
		Bytes: len(text),
		Runes: utf8.RuneCountInString(text),
	}
}

func AnalyzeContext(ctx context.Context, text string) (Counts, error) {
	return analyzeContextWith(ctx, text, nil)
}

func analyzeContextWith(ctx context.Context, text string, afterRune func()) (Counts, error) {
	counts := Counts{Bytes: len(text)}
	inWord := false
	for len(text) > 0 {
		if err := ctx.Err(); err != nil {
			return Counts{}, err
		}
		r, size := utf8.DecodeRuneInString(text)
		text = text[size:]
		counts.Runes++
		if unicode.IsSpace(r) {
			inWord = false
		} else if !inWord {
			inWord = true
			counts.Words++
		}
		if afterRune != nil {
			afterRune()
		}
	}
	if err := ctx.Err(); err != nil {
		return Counts{}, err
	}
	return counts, nil
}
