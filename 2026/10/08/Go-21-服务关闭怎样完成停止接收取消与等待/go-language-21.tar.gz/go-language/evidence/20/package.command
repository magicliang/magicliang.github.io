tar --exclude='*/http-archive.body' -C '/tmp/go-language-20-pack.fJii87' -czf '/home/admin/workspace/my-blogs/source/_posts/2026-10-08-Go-20-有界worker-pool怎样限制并发与排队/go-language-20.tar.gz' go-language
