# 20 原始实验索引

`environment.txt` 给出日期、平台、Go 1.27.1、CGO/GCC、module。每条 `.command`、`.stdout`、`.stderr`、`.exit` 是实际执行的命令、原始双流与退出码；`capture20.sh` 是采集入口，不以脚本文字替代原始输出。`focused` 为受控正反例，`repeat` 重跑同组 50 次，`tests` 为两包完整套件，`race` 为本机两包 race；`cli-invalid`、`cli-empty`、`cli-timeout` 预期退出 2，不是构建失败。`spec-buffer`、`spec-channel`、`doc-context`、`doc-wait` 为冻结版资料。打包与页面/解包证据在本目录补充；页面不能代替 Go 实验。

`package`/`sha` 保存最终归档构建与 SHA-256 校验；同名素材目录 `unpack-*` 记录最终归档真正独立解包、50 次复跑、两包回归、race、构建和 CLI 正反结果。`hexo`/`page`/`http-*` 保存隔离生成及五类静态资源 200、下载包摘要一致。正式全站构建、真实 HTTP/SQL 任务服务、其他平台和发布仍 `NOT_RUN`。
