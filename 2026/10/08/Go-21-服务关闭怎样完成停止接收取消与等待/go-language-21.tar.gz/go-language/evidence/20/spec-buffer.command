sed -n '1730,1754p;6105,6129p' /tmp/go-language-toolchain-1.27.1/go/doc/go_spec.html
