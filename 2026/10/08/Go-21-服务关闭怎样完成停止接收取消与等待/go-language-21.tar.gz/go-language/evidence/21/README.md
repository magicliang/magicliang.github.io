# 21 原始实验索引

`environment.txt` 记录实际平台、Go 1.27.1、CGO/GCC 和 module；每条 `.command/.stdout/.stderr/.exit` 记录执行命令、双流和退出码。`spec-send` 为本版 channel 发送规范片段，`doc-cancel`、`doc-mutex`、`doc-wait` 为本版公开 API。`focused` 受控协议测试，`repeat` 100 次，`tests` 两包完整回归，`race` 和 `race-full` 是本轮在支持平台上实跑的路径；无报告不证明所有路径安全。`negative` 是单独构建的故意向已关闭 channel 发送的程序，应出现 `send on closed channel` 并退出 2，不代表真实执行器失败；`cli-invalid` 和 `cli-timeout` 预期退出 2。打包、最终独立解包、页面和 HTTP 证据在完成后补充，不能用页面检查替代 Go 测试。
