# 19 原始实验索引

`environment.txt` 记录 linux/amd64/Go 1.27.1、`CGO_ENABLED=1`、gcc 和 module。每项 `.command`、`.stdout`、`.stderr`、`.exit` 保存实际命令、双流和进程退出码。`doc-*` 是本版一手 API 片段；`tests` 完整两包，`focused-repeat` 同组受控场景重复 40 次。`atomic-unsafe` 仅在环境变量 `TASKSTATS_UNSAFE_RACE=1` 下切到测试内无锁替身，计数器也是 atomic，但记录字段冲突被报告（退出 1）；`atomic-safe`/`race-full` 使用真实有锁存储并在本次路径无报告（退出 0）。`batch`/`json` 是旧 CLI 正例，`invalid`/`deadline` 是预期业务错误（退出 2）。没有把反例的非零码算作生产构建失败，也没有把 40 次或无 race 报告说成所有路径安全。

素材目录 `unpack-*` 保存真实 SHA 校验、独立解包、同样的 atomic 有锁/无锁 race 正反复跑、构建和 CLI；本目录 `package.*`、`hexo-*`、`page-*`、`http-*` 保存打包、隔离 Hexo、导航及资源链接和本地静态 HTTP 四资源 200 检查，HTTP 下载 SHA-256 与素材 `SHA256SUMS` 相同。页面不替代 Go 实验。全站、其他平台、多 worker、SQL、任务服务 HTTP 及发布 `NOT_RUN`。
