/tmp/go-language-19-taskstats --batch "Go|one two" --json
