go doc sync/atomic.Uint64
