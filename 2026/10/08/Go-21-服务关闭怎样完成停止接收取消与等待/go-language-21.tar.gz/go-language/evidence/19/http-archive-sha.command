sha256sum '/home/admin/workspace/my-blogs/writing-plans/go-language/evidence/19/http-archive.body'
