# 17 实验索引

`environment.txt` 是此次固定平台与工具链；每组 `.command`、`.stdout`、`.stderr`、`.exit` 是实际执行的命令与原始双流、进程退出码。`doc-*` 保存本版 `go doc` 的一手契约原文；`tests` 是两包回归，`cancellation-repeat` 是同一受控闸门测试的 50 次复跑，并非性能/全路径安全证明。`deadline` 和 `deadline-batch` 是直接运行的二进制，退出 2，stderr 为约定的 `task deadline exceeded` 且 stdout 为空；`timeout-normal` 退出 0；`invalid`/`missing` 是原有不同类别的业务错误。归档解包与静态页面验证分别在素材目录和此目录的其他证据文件中记录；页面不替代 Go 实验。

本次 `CGO_ENABLED=0`，race detector、其他平台、HTTP、数据库、文件输入期间超时、外部副作用及发布均 `NOT_RUN`；截止时间只从任务处理阶段开始计时。后续 18 需引入多字段状态的真正同步与正反 race 实验。
