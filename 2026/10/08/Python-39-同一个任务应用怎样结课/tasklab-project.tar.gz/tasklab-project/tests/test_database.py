import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest

from tasklab import TaskExecutionError
from tasklab.database import SQLiteTaskGateway


class SQLiteTests(unittest.TestCase):
    def test_new_gateway_reads_committed_result(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "tasklab.sqlite"
            first = SQLiteTaskGateway(path)
            task_id = first.submit("word_count", "One one", metadata={"labels": ["样本"]})
            self.assertEqual(first.run(task_id), {"one": 2})
            second = SQLiteTaskGateway(path)
            self.assertEqual(second.query(task_id)["result"], {"one": 2})
            self.assertEqual(second.query(task_id)["metadata"], {"labels": ["样本"]})
            with self.assertRaisesRegex(ValueError, "only queued"):
                second.run(task_id)
            self.assertEqual(second.query(task_id)["state"], "succeeded")

    def test_injected_failure_rolls_back_state_and_result(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "tasklab.sqlite"
            gateway = SQLiteTaskGateway(path)
            task_id = gateway.submit("word_count", "one two one")
            with self.assertRaisesRegex(RuntimeError, "between state and result"):
                gateway.run(task_id, fail_at="after_state")
            reopened = SQLiteTaskGateway(path)
            self.assertEqual((reopened.query(task_id)["state"], reopened.query(task_id)["result"]),
                             ("queued", None))
            self.assertEqual(reopened.run(task_id), {"one": 2, "two": 1})
            self.assertEqual(reopened.query(task_id)["state"], "succeeded")

    def test_compute_failure_and_cancel_are_durable(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "tasklab.sqlite"
            gateway = SQLiteTaskGateway(path)
            failed = gateway.submit("word_count", "one")
            cancelled = gateway.submit("word_count", "two")
            with self.assertRaises(TaskExecutionError):
                gateway.run(failed, fail_at="compute")
            self.assertTrue(gateway.cancel(cancelled))
            reopened = SQLiteTaskGateway(path)
            self.assertEqual(reopened.query(failed)["state"], "failed")
            self.assertIsNone(reopened.query(failed)["result"])
            self.assertIn("synthetic computation failure", reopened.query(failed)["error"])
            self.assertEqual(reopened.query(cancelled)["state"], "cancelled")
            self.assertFalse(reopened.cancel(cancelled))

    def test_cli_queries_from_new_process(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "tasklab.sqlite"
            environment = os.environ.copy()
            environment["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")

            def invoke(*arguments):
                return subprocess.run([sys.executable, "-m", "tasklab.db_cli", "--db", str(path),
                                       *arguments], capture_output=True, text=True,
                                      env=environment, check=False)

            submitted = invoke("submit", "--text", "One one")
            self.assertEqual((submitted.returncode, submitted.stderr), (0, ""))
            task_id = json.loads(submitted.stdout)["id"]
            self.assertEqual(json.loads(invoke("query", task_id).stdout)["state"], "queued")
            executed = invoke("run", task_id)
            self.assertEqual(executed.returncode, 0)
            self.assertEqual(json.loads(invoke("query", task_id).stdout)["result"], {"one": 2})
            invalid = invoke("run", task_id)
            self.assertEqual((invalid.returncode, invalid.stdout), (2, ""))
            self.assertIn("only queued", invalid.stderr)


if __name__ == "__main__":
    unittest.main()
