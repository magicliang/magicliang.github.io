import unittest

from tasklab import create_store, query, run, submit
from tasklab.model import TaskResult


class ProtocolTests(unittest.TestCase):
    def test_len_protocol_matches_direct_class_method(self):
        result = TaskResult({"one": 2, "two": 1})
        self.assertEqual(len(result), TaskResult.__len__(result))
        self.assertEqual(len(result), 2)
        self.assertEqual(result.total, 3)
        self.assertIn("one", repr(result))

    def test_state_property_rejects_unknown_vocabulary(self):
        store = create_store()
        task_id = submit(store, "word_count", "one")
        task = store["tasks"][task_id]
        with self.assertRaisesRegex(ValueError, "unknown task state"):
            task.state = "ghost"
        self.assertEqual(query(store, task_id)["state"], "queued")
        self.assertEqual(run(store, task_id), {"one": 1})
        self.assertEqual(query(store, task_id)["state"], "succeeded")

    def test_instance_override_does_not_change_len_protocol(self):
        result = TaskResult({"one": 2})
        result.__len__ = lambda: 99
        self.assertEqual(result.__len__(), 99)
        self.assertEqual(len(result), 1)


if __name__ == "__main__":
    unittest.main()
