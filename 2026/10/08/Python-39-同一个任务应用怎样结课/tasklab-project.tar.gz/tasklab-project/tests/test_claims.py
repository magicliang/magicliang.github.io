import json
import os
from pathlib import Path
import subprocess
import sys
import unittest


class ClaimTests(unittest.TestCase):
    def test_barrier_reproduces_duplicate_and_lock_prevents_it(self):
        root = Path(__file__).resolve().parents[1]
        environment = os.environ.copy()
        environment["PYTHONPATH"] = str(root / "src")
        outcome = subprocess.run([sys.executable, root / "experiments" / "28_claims.py"],
                                 env=environment, capture_output=True, text=True, check=False)
        self.assertEqual(outcome.returncode, 0, outcome.stderr)
        records = [json.loads(line) for line in outcome.stdout.splitlines()]
        self.assertEqual([record["case"] for record in records], ["naive", "locked", "sqlite"])
        self.assertEqual(len(records[0]["claims"]), 2)
        self.assertEqual(len(records[1]["claims"]), 1)
        self.assertEqual(records[2]["finished"], [{"one": 2, "two": 1}])
        self.assertEqual(records[2]["errors"], ["ValueError: only queued tasks can run"])


if __name__ == "__main__":
    unittest.main()
