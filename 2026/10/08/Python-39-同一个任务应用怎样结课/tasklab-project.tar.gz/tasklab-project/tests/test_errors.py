import traceback
import unittest

from tasklab import TaskExecutionError, create_store, query, run, submit


class ErrorTests(unittest.TestCase):
    def test_input_error_does_not_allocate_task(self):
        store = create_store()
        previous = submit(store, "word_count", "one")
        before = query(store, previous)
        with self.assertRaises(ValueError):
            submit(store, "", "bad")
        self.assertEqual(query(store, previous), before)
        self.assertEqual(len(store["tasks"]), 1)

    def test_execution_failure_retains_chain_and_failed_state(self):
        store = create_store()
        task_id = submit(store, "word_count", "one")
        with self.assertRaises(TaskExecutionError) as raised:
            run(store, task_id, fail_at="compute")
        error = raised.exception
        self.assertIsInstance(error.__cause__, RuntimeError)
        self.assertIsInstance(error.__cause__.__cause__, ValueError)
        formatted = "".join(traceback.format_exception(error))
        self.assertIn("synthetic computation failure", formatted)
        self.assertIn("synthetic-not-a-number", formatted)
        snapshot = query(store, task_id)
        self.assertEqual(snapshot["state"], "failed")
        self.assertIsNone(snapshot["result"])
        self.assertEqual(snapshot["error"], "RuntimeError: synthetic computation failure")
        with self.assertRaises(ValueError):
            run(store, task_id)

    def test_invalid_injection_fails_before_state_change(self):
        store = create_store()
        task_id = submit(store, "word_count", "one")
        with self.assertRaisesRegex(ValueError, "unknown fault injection"):
            run(store, task_id, fail_at="unknown")
        self.assertEqual(query(store, task_id)["state"], "queued")


if __name__ == "__main__":
    unittest.main()
