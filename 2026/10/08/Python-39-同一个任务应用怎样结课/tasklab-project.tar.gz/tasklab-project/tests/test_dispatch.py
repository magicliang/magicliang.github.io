import unittest

from tasklab import create_store
from tasklab.dispatch import dispatch


class DispatchTests(unittest.TestCase):
    def test_dispatch_preserves_four_operations(self):
        store = create_store()
        finished = dispatch(store, "submit", kind="word_count", text="one")
        cancelled = dispatch(store, "submit", kind="word_count", text="two")
        self.assertEqual(dispatch(store, "run", task_id=finished), {"one": 1})
        self.assertEqual(dispatch(store, "query", task_id=finished)["state"], "succeeded")
        self.assertTrue(dispatch(store, "cancel", task_id=cancelled))
        self.assertEqual(dispatch(store, "query", task_id=cancelled)["state"], "cancelled")

    def test_short_circuit_does_not_lose_empty_result(self):
        store = create_store()
        task_ids = [dispatch(store, "submit", kind="word_count", text=text) for text in ("", "word")]
        for task_id in task_ids:
            dispatch(store, "run", task_id=task_id)
        results = [dispatch(store, "query", task_id=task_id)["result"] for task_id in task_ids]
        self.assertEqual([result for result in results if result is not None], [{}, {"word": 1}])
        self.assertEqual([result for result in results if result], [{"word": 1}])

    def test_unknown_operation_and_invalid_payload_do_not_modify_store(self):
        store = create_store()
        task_id = dispatch(store, "submit", kind="word_count", text="one")
        before = dispatch(store, "query", task_id=task_id)
        with self.assertRaisesRegex(ValueError, "unknown operation"):
            dispatch(store, "remove", task_id=task_id)
        with self.assertRaisesRegex(TypeError, "operation must"):
            dispatch(store, None, task_id=task_id)
        with self.assertRaises(TypeError):
            dispatch(store, "submit", kind="word_count", text=None)
        with self.assertRaises(TypeError):
            dispatch(store, "submit", kind="word_count", text="two", unexpected=True)
        self.assertEqual(dispatch(store, "query", task_id=task_id), before)
        self.assertEqual(len(store["tasks"]), 1)

    def test_unknown_stored_state_is_not_silently_returned(self):
        store = create_store()
        task_id = dispatch(store, "submit", kind="word_count", text="one")
        store["tasks"][task_id]._state = "ghost"
        with self.assertRaisesRegex(ValueError, "unknown task state"):
            dispatch(store, "query", task_id=task_id)


if __name__ == "__main__":
    unittest.main()
