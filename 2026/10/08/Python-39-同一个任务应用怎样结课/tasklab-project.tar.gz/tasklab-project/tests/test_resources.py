import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from tasklab import create_store, run, submit
from tasklab.resources import count_file, open_word_file


class ResourceTests(unittest.TestCase):
    def setUp(self):
        self.directory = TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name) / "generated.txt"
        self.path.write_text("One two one", encoding="utf-8")

    def test_normal_read_closes_file_and_matches_task(self):
        with open_word_file(self.path) as (words, source):
            result = list(words)
            self.assertFalse(source.closed)
        self.assertTrue(source.closed)
        self.assertEqual(result, ["one", "two", "one"])
        store = create_store()
        self.assertEqual(count_file(self.path), run(store, submit(store, "word_count", "One two one")))

    def test_early_exit_closes_file(self):
        with open_word_file(self.path) as (words, source):
            self.assertEqual(next(words), "one")
            self.assertFalse(source.closed)
        self.assertTrue(source.closed)

    def test_consumer_error_propagates_and_file_closes(self):
        with self.assertRaisesRegex(RuntimeError, "synthetic consumer error"):
            with open_word_file(self.path) as (words, source):
                self.assertEqual(next(words), "one")
                raise RuntimeError("synthetic consumer error")
        self.assertTrue(source.closed)

    def test_decode_error_propagates_and_file_closes(self):
        self.path.write_bytes(b"\xff")
        with self.assertRaises(UnicodeDecodeError):
            with open_word_file(self.path) as (words, source):
                list(words)
        self.assertTrue(source.closed)


if __name__ == "__main__":
    unittest.main()
