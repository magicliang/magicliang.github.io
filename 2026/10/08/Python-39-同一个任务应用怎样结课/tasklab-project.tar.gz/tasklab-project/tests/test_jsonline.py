import asyncio
import json
import unittest

from tasklab import create_store, task_ids
from tasklab.jsonline import LoopbackService


class JsonLineTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.store = create_store()
        self.service = LoopbackService(self.store, max_connections=2, read_timeout=0.15)
        self.host, self.port = await self.service.start()
        self.addAsyncCleanup(self.service.close)

    async def request(self, payload):
        reader, writer = await asyncio.open_connection(self.host, self.port)
        writer.write(payload)
        await writer.drain()
        response = json.loads(await reader.readline())
        writer.close()
        await writer.wait_closed()
        return response

    async def test_contract_and_ack_is_not_result(self):
        submitted = await self.request(b'{"op":"submit","kind":"word_count","text":"One two one"}\n')
        task_id = submitted["id"]
        self.assertEqual(submitted, {"ok": True, "id": task_id})
        before = await self.request(json.dumps({"op": "query", "id": task_id}).encode() + b"\n")
        self.assertEqual(before["task"]["state"], "queued")
        run = await self.request(json.dumps({"op": "run", "id": task_id}).encode() + b"\n")
        self.assertEqual(run["result"], {"one": 2, "two": 1})
        self.assertEqual(run["task"]["state"], "succeeded")
        self.assertFalse((await self.request(json.dumps({"op": "cancel", "id": task_id}).encode() + b"\n"))["accepted"])
        second = (await self.request(b'{"op":"submit","kind":"word_count","text":"Another"}\n'))["id"]
        cancelled = await self.request(json.dumps({"op": "cancel", "id": second}).encode() + b"\n")
        self.assertTrue(cancelled["accepted"])
        self.assertEqual(cancelled["task"]["state"], "cancelled")

    async def test_partial_and_bad_frames(self):
        reader, writer = await asyncio.open_connection(self.host, self.port)
        writer.write(b'{"op":"submit","kind":"word_count","text":"One')
        await writer.drain()
        self.assertEqual(task_ids(self.store), ())
        writer.write(b' two one"}\n')
        self.assertTrue(json.loads(await reader.readline())["ok"])
        writer.close()
        await writer.wait_closed()
        for payload in (b'{"op":"submit","op":"submit","kind":"word_count","text":"X"}\n',
                        b'{"op":"unknown"}\n', b'\xff\n', b'a' * 3000 + b'\n'):
            self.assertFalse((await self.request(payload))["ok"])
        reader, writer = await asyncio.open_connection(self.host, self.port)
        writer.write(b'{"op":"submit"')
        await writer.drain()
        writer.close()
        await writer.wait_closed()
        await asyncio.sleep(0)
        self.assertEqual(len(task_ids(self.store)), 1)

    async def test_idle_timeout_and_connection_limit(self):
        first_reader, first_writer = await asyncio.open_connection(self.host, self.port)
        second_reader, second_writer = await asyncio.open_connection(self.host, self.port)
        await asyncio.sleep(0)
        response = await self.request(b'{"op":"query","id":"task-0001"}\n')
        self.assertEqual(response, {"ok": False, "error": "busy"})
        self.assertEqual(json.loads(await first_reader.readline())["error"], "read timeout")
        self.assertEqual(json.loads(await second_reader.readline())["error"], "read timeout")
        first_writer.close()
        second_writer.close()
        await first_writer.wait_closed()
        await second_writer.wait_closed()
