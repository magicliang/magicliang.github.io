import unittest
import sys

from tasklab.app import count_words


class RuntimeIntrospectionTests(unittest.TestCase):
    def test_count_words_disassembly_corresponds_to_same_result(self):
        import dis
        operations = [instruction.opname for instruction in dis.get_instructions(count_words)]
        addition = 'BINARY_ADD' if sys.implementation.name == 'pypy' else 'BINARY_OP'
        self.assertIn(addition, operations)
        self.assertIn("FOR_ITER", operations)
        self.assertEqual(count_words(iter(("one", "two", "one"))),
                         {"one": 2, "two": 1})


if __name__ == "__main__":
    unittest.main()
