import unittest

from tasklab import create_store, query, submit


class FunctionTests(unittest.TestCase):
    def test_mutable_default_reuses_list_between_calls(self):
        def unsafe_submit(store, label, labels=[]):
            labels.append(label)
            return submit(store, "word_count", label, metadata={"labels": labels})

        store = create_store()
        first = unsafe_submit(store, "first")
        second = unsafe_submit(store, "second")
        self.assertEqual(query(store, first)["metadata"]["labels"], ["first"])
        self.assertEqual(query(store, second)["metadata"]["labels"], ["first", "second"])

    def test_none_default_creates_fresh_list_and_copies_caller(self):
        def safe_submit(store, label, *, labels=None):
            selected = [] if labels is None else labels.copy()
            selected.append(label)
            return submit(store, "word_count", label, metadata={"labels": selected})

        store = create_store()
        first = safe_submit(store, "first")
        second = safe_submit(store, "second")
        caller = ["caller"]
        third = safe_submit(store, "third", labels=caller)
        self.assertEqual(query(store, first)["metadata"]["labels"], ["first"])
        self.assertEqual(query(store, second)["metadata"]["labels"], ["second"])
        self.assertEqual(query(store, third)["metadata"]["labels"], ["caller", "third"])
        self.assertEqual(caller, ["caller"])

    def test_invalid_signature_does_not_allocate_task(self):
        store = create_store()
        with self.assertRaises(TypeError):
            submit(store, "word_count", "ok", {"labels": []})
        with self.assertRaises(TypeError):
            submit(store, "word_count")
        self.assertEqual(len(store["tasks"]), 0)
        self.assertEqual(submit(store, "word_count", "ok", metadata={"labels": []}), "task-0001")


if __name__ == "__main__":
    unittest.main()
