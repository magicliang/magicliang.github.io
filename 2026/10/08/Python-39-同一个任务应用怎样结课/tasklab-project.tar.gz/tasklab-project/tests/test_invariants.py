from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from tasklab import cancel, create_store, query, run, submit
from tasklab.database import SQLiteTaskGateway


class BusinessInvariantTests(unittest.TestCase):
    def test_memory_cancelled_task_has_no_result(self):
        store = create_store()
        task_id = submit(store, "word_count", "one")
        self.assertTrue(cancel(store, task_id))
        self.assertEqual(query(store, task_id)["state"], "cancelled")
        self.assertIsNone(query(store, task_id)["result"])
        with self.assertRaises(ValueError):
            run(store, task_id)

    def test_sqlite_cancelled_task_survives_reopen(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "tasklab.sqlite"
            gateway = SQLiteTaskGateway(path)
            task_id = gateway.submit("word_count", "one")
            self.assertTrue(gateway.cancel(task_id))
            reopened = SQLiteTaskGateway(path)
            self.assertEqual(reopened.query(task_id)["state"], "cancelled")
            self.assertIsNone(reopened.query(task_id)["result"])
            with self.assertRaises(ValueError):
                reopened.run(task_id)


if __name__ == "__main__":
    unittest.main()
