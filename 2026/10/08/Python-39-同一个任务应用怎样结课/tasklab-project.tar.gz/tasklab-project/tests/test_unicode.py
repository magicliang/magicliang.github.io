import unittest

from tasklab import create_store, query, run, submit, submit_bytes


class UnicodeTests(unittest.TestCase):
    def test_utf8_round_trip(self):
        store = create_store()
        task_id = submit_bytes(store, "word_count", "你好 世界".encode("utf-8"))
        self.assertEqual(run(store, task_id), {"你好": 1, "世界": 1})
        self.assertEqual(query(store, task_id)["text"], "你好 世界")

    def test_invalid_utf8_and_oversized_input_do_not_change_store(self):
        store = create_store()
        previous = submit(store, "word_count", "one")
        before = query(store, previous)
        with self.assertRaises(UnicodeDecodeError):
            submit_bytes(store, "word_count", b"\xff")
        with self.assertRaisesRegex(ValueError, "1024 UTF-8"):
            submit_bytes(store, "word_count", ("汉" * 342).encode("utf-8"))
        with self.assertRaisesRegex(ValueError, "1024 UTF-8"):
            submit(store, "word_count", "汉" * 342)
        self.assertEqual(query(store, previous), before)
        self.assertEqual(len(store["tasks"]), 1)
        self.assertEqual(submit_bytes(store, "word_count", b"ok"), "task-0002")

    def test_numeric_conversion_is_not_implicit(self):
        self.assertEqual(int("12"), 12)
        with self.assertRaises(ValueError):
            int("12x")
        store = create_store()
        with self.assertRaises(TypeError):
            submit_bytes(store, "word_count", "not bytes")
        self.assertEqual(len(store["tasks"]), 0)


if __name__ == "__main__":
    unittest.main()
