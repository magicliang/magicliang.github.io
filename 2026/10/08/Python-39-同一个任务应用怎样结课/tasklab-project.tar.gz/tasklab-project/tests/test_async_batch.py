import asyncio
import unittest

from tasklab import cancel, create_store, query, submit
from tasklab.async_batch import run_batch


class AsyncBatchTests(unittest.IsolatedAsyncioTestCase):
    async def test_failure_cancels_waiting_sibling_and_joins_cleanup(self):
        store = create_store()
        faulty = submit(store, "word_count", "One two one")
        siblings = (submit(store, "word_count", "One two one"),
                    submit(store, "word_count", "One two one"))
        task_ids = (faulty, *siblings)
        started = {task_id: asyncio.Event() for task_id in task_ids}
        cleaned = {task_id: asyncio.Event() for task_id in task_ids}
        fault_gate = asyncio.Event()
        sibling_gates = {task_id: asyncio.Event() for task_id in siblings}
        batch = asyncio.create_task(run_batch(
            store, task_ids,
            release_events={faulty: fault_gate, **sibling_gates},
            started_events=started, cleaned_events=cleaned, fail_id=faulty))
        await asyncio.gather(*(event.wait() for event in started.values()))
        self.assertEqual([query(store, task_id)["state"] for task_id in started],
                         ["running", "running", "running"])
        fault_gate.set()
        with self.assertRaises(ExceptionGroup) as raised:
            await batch
        self.assertEqual(len(raised.exception.exceptions), 1)
        self.assertEqual(type(raised.exception.exceptions[0]).__name__, "TaskExecutionError")
        self.assertTrue(all(event.is_set() for event in cleaned.values()))
        self.assertFalse(any(event.is_set() for event in sibling_gates.values()))
        self.assertEqual(query(store, faulty)["state"], "failed")
        for sibling in siblings:
            self.assertEqual(query(store, sibling)["state"], "cancelled")
            self.assertIsNone(query(store, sibling)["result"])

    async def test_deadline_waits_for_cancellation_cleanup(self):
        store = create_store()
        task_id = submit(store, "word_count", "One two one")
        started, cleaned, gate = asyncio.Event(), asyncio.Event(), asyncio.Event()
        loop = asyncio.get_running_loop()
        with self.assertRaises(TimeoutError):
            await run_batch(store, [task_id], release_events={task_id: gate},
                            started_events={task_id: started},
                            cleaned_events={task_id: cleaned},
                            timeout_at=loop.time() + 0.1)
        self.assertTrue(started.is_set())
        self.assertTrue(cleaned.is_set())
        self.assertFalse(gate.is_set())
        self.assertEqual(query(store, task_id)["state"], "cancelled")

    async def test_normal_result_and_duplicate_ids_rejected_before_execution(self):
        store = create_store()
        task_id = submit(store, "word_count", "One two one")
        with self.assertRaisesRegex(ValueError, "distinct"):
            await run_batch(store, [task_id, task_id])
        self.assertEqual(query(store, task_id)["state"], "queued")
        self.assertEqual(await run_batch(store, [task_id]),
                         {task_id: {"one": 2, "two": 1}})
        self.assertEqual(query(store, task_id)["state"], "succeeded")

    async def test_accepted_cancel_is_not_actual_stop(self):
        store = create_store()
        task_id = submit(store, "word_count", "One two one")
        started, cleaned, gate = asyncio.Event(), asyncio.Event(), asyncio.Event()
        batch = asyncio.create_task(run_batch(
            store, [task_id], release_events={task_id: gate},
            started_events={task_id: started}, cleaned_events={task_id: cleaned}))
        await started.wait()
        self.assertTrue(cancel(store, task_id))
        self.assertEqual(query(store, task_id)["state"], "cancel_requested")
        self.assertFalse(cleaned.is_set())
        batch.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await batch
        self.assertTrue(cleaned.is_set())
        self.assertEqual(query(store, task_id)["state"], "cancelled")
