import asyncio
import unittest

from tasklab import cancel, create_store, query, submit, task_ids
from tasklab.async_queue import AsyncTaskQueue, BusyError


class QueueTests(unittest.IsolatedAsyncioTestCase):
    async def test_slow_workers_bound_queue_and_total_admission(self):
        store = create_store()
        gate = asyncio.Event()
        queue = AsyncTaskQueue(store, workers=2, waiting=1, wait_event=gate)
        await queue.start()
        started = [asyncio.Event(), asyncio.Event()]
        first = queue.submit_nowait("word_count", "One two one", started_event=started[0])
        await started[0].wait()
        second = queue.submit_nowait("word_count", "One two one", started_event=started[1])
        await started[1].wait()
        third = queue.submit_nowait("word_count", "One two one")
        self.assertEqual(queue.snapshot(), {"admitted": 3, "running": 2,
                                            "queued": 1, "capacity": 3})
        with self.assertRaises(BusyError):
            queue.submit_nowait("word_count", "One two one")
        self.assertEqual(task_ids(store), (first, second, third))
        self.assertTrue(cancel(store, third))
        self.assertEqual(query(store, third)["state"], "cancelled")
        self.assertEqual(queue.snapshot()["admitted"], 3)
        gate.set()
        await queue.join()
        self.assertEqual(queue.snapshot()["admitted"], 0)
        self.assertEqual(queue.snapshot()["running"], 0)
        self.assertEqual(query(store, first)["result"], {"one": 2, "two": 1})
        self.assertEqual(query(store, second)["state"], "succeeded")
        self.assertIsNone(query(store, third)["result"])
        fourth = queue.submit_nowait("word_count", "One two one")
        await queue.close()
        self.assertEqual(query(store, fourth)["state"], "succeeded")
        with self.assertRaises(BusyError):
            queue.submit_nowait("word_count", "One two one")

    async def test_invalid_input_does_not_use_capacity(self):
        store = create_store()
        queue = AsyncTaskQueue(store, workers=1, waiting=1)
        await queue.start()
        with self.assertRaises(ValueError):
            queue.submit_nowait("unknown", "text")
        self.assertEqual(queue.snapshot()["admitted"], 0)
        await queue.close()


if __name__ == "__main__":
    unittest.main()
