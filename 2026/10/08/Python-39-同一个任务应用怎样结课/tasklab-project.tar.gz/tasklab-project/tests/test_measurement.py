import json
import os
from pathlib import Path
import subprocess
import sys
import unittest


class MeasurementTests(unittest.TestCase):
    def test_repeat_samples_and_profile_have_disjoint_scopes(self):
        project = Path(__file__).resolve().parents[1]
        env = dict(os.environ, PYTHONPATH=str(project / "src"))
        result = subprocess.run(
            [sys.executable, str(project / "benchmarks/36_measure.py"),
             "--samples", "2", "--iterations", "250"],
            cwd=project, env=env, capture_output=True, text=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)
        raw, profile = result.stdout.split("PROFILE_SEQUENTIAL_BEGIN\n", 1)
        self.assertIn("cpu_work", profile)
        records = [json.loads(line) for line in raw.splitlines()]
        self.assertEqual(records[0]["scope"],
                         "create store, runner/pool startup, execution, join/shutdown")
        samples = [record for record in records if record["type"] == "sample"]
        self.assertEqual(len(samples), 8)
        self.assertEqual({sample["mode"] for sample in samples},
                         {"sequential", "thread", "process", "asyncio"})
        self.assertTrue(all(sample["completed"] == 4 and sample["failed"] == 0
                            and sample["wall_ns"] > 0 for sample in samples))


if __name__ == "__main__":
    unittest.main()
