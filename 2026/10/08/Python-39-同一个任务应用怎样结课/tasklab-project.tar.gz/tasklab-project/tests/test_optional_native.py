import importlib.util
import json
import platform
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
EXPERIMENTS = ROOT / "experiments"


@unittest.skipUnless(shutil.which("cc") or shutil.which("clang"), "C compiler is not available")
class OptionalNativeTests(unittest.TestCase):
    def build_extension(self, source):
        if platform.python_implementation() != "CPython":
            self.skipTest("optional native tests cover the CPython C API only")
        temporary = tempfile.TemporaryDirectory(prefix="tasklab-native-test-")
        self.addCleanup(temporary.cleanup)
        out = Path(temporary.name)
        completed = subprocess.run(
            [sys.executable, str(EXPERIMENTS / "E03_build.py"), str(source), "--out", str(out)],
            cwd=ROOT, text=True, capture_output=True)
        self.assertEqual(completed.returncode, 0, completed.stderr[-1000:])
        return Path(json.loads(completed.stdout)["extension"])

    def test_fastbytes_matches_python_and_rejects_mutable_input(self):
        extension_path = self.build_extension(EXPERIMENTS / "E03_fastbytes.c")
        spec = importlib.util.spec_from_file_location("_fastbytes", extension_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self.assertEqual(module.checksum(b"one", 13), 747040194)
        with self.assertRaises(TypeError):
            module.checksum(bytearray(b"one"), 1)
        class BytesChild(bytes):
            pass
        with self.assertRaises(TypeError):
            module.checksum(BytesChild(b"one"), 1)
        with self.assertRaises((TypeError, ValueError)):
            module.checksum(b"one", True)

    def test_subinterpreter_contract_runs_when_private_module_exists(self):
        if importlib.util.find_spec("_xxsubinterpreters") is None:
            self.skipTest("_xxsubinterpreters is not available")
        extension_path = self.build_extension(EXPERIMENTS / "E07_reject.c")
        completed = subprocess.run(
            [sys.executable, str(EXPERIMENTS / "E07_subinterpreters.py"),
             "--reject-extension", str(extension_path), "--json"],
            cwd=ROOT, text=True, capture_output=True, timeout=60)
        self.assertEqual(completed.returncode, 0, completed.stderr)
        data = json.loads(completed.stdout)
        last = data["subinterpreter"]["last"]
        self.assertEqual(last["result"]["result"], {"one": 100, "two": 50})
        self.assertFalse(last["parent_has_child_marker"])
        self.assertTrue(last["bytes_shareable"])
        self.assertFalse(last["list_shareable"])
        self.assertFalse(last["extension"]["loaded"])


if __name__ == "__main__":
    unittest.main()
