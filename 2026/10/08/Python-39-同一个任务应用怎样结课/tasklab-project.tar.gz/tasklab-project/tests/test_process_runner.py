import os
import pickle
import unittest

from tasklab import TaskExecutionError, create_store, query, run, submit
from tasklab.process_runner import ProcessTaskRunner
from tasklab.workloads import cpu_work


class ProcessRunnerTests(unittest.TestCase):
    def test_spawned_process_matches_sequential_result(self):
        store = create_store()
        text = "One two one"
        baseline_id = submit(store, "word_count", text)
        process_id = submit(store, "word_count", text)
        baseline = run(store, baseline_id, workload=lambda data: cpu_work(data, iterations=20000))
        with ProcessTaskRunner(workers=1) as runner:
            self.assertEqual(runner.run(store, process_id, iterations=20000), baseline)
            self.assertNotEqual(runner.traces[0]["pid"], os.getpid())
            self.assertEqual(runner.traces[0]["result"], baseline)
        self.assertEqual(query(store, process_id)["state"], "succeeded")

    def test_nonserializable_argument_fails_without_committing(self):
        store = create_store()
        task_id = submit(store, "word_count", "one")
        with ProcessTaskRunner(workers=1) as runner:
            with self.assertRaises(TaskExecutionError) as caught:
                runner.run(store, task_id, iterations=lambda value: value)
        self.assertIsInstance(caught.exception.__cause__,
                              (AttributeError, pickle.PicklingError, TypeError))
        self.assertRegex(str(caught.exception.__cause__), "pickl|local object")
        self.assertEqual(query(store, task_id)["state"], "failed")
        self.assertIsNone(query(store, task_id)["result"])


if __name__ == "__main__":
    unittest.main()
