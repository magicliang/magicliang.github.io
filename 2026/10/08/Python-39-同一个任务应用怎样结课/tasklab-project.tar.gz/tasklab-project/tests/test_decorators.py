import inspect
import unittest

from tasklab import create_store, query, run, submit
from tasklab.metrics import timed


class DecoratorTests(unittest.TestCase):
    def test_success_return_and_metadata_preserved(self):
        store = create_store()
        task_id = submit(store, "word_count", "one one")
        records = []

        @timed(records)
        def execute(task_id, *, expected):
            result = run(store, task_id)
            self.assertEqual(result, expected)
            return result

        self.assertEqual(execute(task_id, expected={"one": 2}), {"one": 2})
        self.assertEqual(execute.__name__, "execute")
        self.assertEqual(inspect.signature(execute), inspect.signature(execute.__wrapped__))
        self.assertEqual(len(records), 1)
        self.assertTrue(records[0]["succeeded"])
        self.assertGreaterEqual(records[0]["elapsed_ns"], 0)

    def test_error_is_not_swallowed_or_retried(self):
        store = create_store()
        task_id = submit(store, "word_count", "one")
        before = query(store, task_id)
        records = []

        @timed(records)
        def execute(task_id):
            return run(store, task_id)

        with self.assertRaises(KeyError):
            execute("unknown")
        self.assertEqual(query(store, task_id), before)
        self.assertEqual(len(records), 1)
        self.assertFalse(records[0]["succeeded"])


if __name__ == "__main__":
    unittest.main()
