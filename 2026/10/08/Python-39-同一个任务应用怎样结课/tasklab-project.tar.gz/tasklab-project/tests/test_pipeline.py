import unittest

from tasklab import create_store, run, submit
from tasklab.pipeline import word_batches


class PipelineTests(unittest.TestCase):
    def test_batching_consumes_each_chunk_only_once(self):
        seen = []

        def chunks():
            for chunk in ("one two ", "one skip "):
                seen.append(chunk)
                yield chunk

        batches = word_batches(chunks(), skip={"skip"}, size=2)
        self.assertEqual(seen, [])
        self.assertEqual(next(batches), ("one", "two"))
        self.assertEqual(seen, ["one two "])
        self.assertEqual(list(batches), [("one",)])
        self.assertEqual(seen, ["one two ", "one skip "])

    def test_unfiltered_batches_keep_word_count_contract(self):
        store = create_store()
        result = run(store, submit(store, "word_count", "one two one skip"))
        self.assertEqual(result, {"one": 2, "two": 1, "skip": 1})
        self.assertEqual(list(word_batches(("one two one skip",), size=2)), [
            ("one", "two"), ("one", "skip"),
        ])

    def test_bad_batch_size_fails_before_reading_chunks(self):
        seen = []

        def chunks():
            seen.append("read")
            yield "one"

        with self.assertRaisesRegex(ValueError, "batch size"):
            word_batches(chunks(), size=0)
        self.assertEqual(seen, [])


if __name__ == "__main__":
    unittest.main()
