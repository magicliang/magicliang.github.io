import unittest

from tasklab import create_store, query, run, submit
from tasklab.model import Task


class MethodTests(unittest.TestCase):
    def test_task_instances_hold_independent_state(self):
        store = create_store()
        first = submit(store, "word_count", "one", metadata={"labels": ["first"]})
        second = submit(store, "word_count", "two", metadata={"labels": ["second"]})
        self.assertEqual(run(store, first), {"one": 1})
        self.assertEqual(query(store, first)["state"], "succeeded")
        self.assertEqual(query(store, second)["state"], "queued")
        self.assertEqual(query(store, second)["metadata"]["labels"], ["second"])

    def test_bound_method_receives_the_same_instance(self):
        store = create_store()
        task_id = submit(store, "word_count", "one")
        task = store["tasks"][task_id]
        self.assertIs(task.snapshot.__self__, task)
        self.assertIs(task.snapshot.__func__, Task.snapshot)
        self.assertEqual(task.snapshot(), Task.snapshot(task))

    def test_class_level_list_shares_mutation(self):
        class BrokenTask:
            labels = []

        first = BrokenTask()
        second = BrokenTask()
        first.labels.append("leak")
        self.assertEqual(second.labels, ["leak"])


if __name__ == "__main__":
    unittest.main()
