import unittest

from tasklab import create_store, query, run, submit
from tasklab.transforms import suffix_callbacks


class ClosureTests(unittest.TestCase):
    def test_late_binding_uses_last_loop_value(self):
        suffixes = ["red", "blue", "green"]
        callbacks = [lambda text: f"{text} {suffix}" for suffix in suffixes]
        self.assertEqual([callback("hello") for callback in callbacks], ["hello green"] * 3)

    def test_early_binding_keeps_each_task_input_distinct(self):
        store = create_store()
        callbacks = suffix_callbacks(["red", "blue", "green"])
        task_ids = [submit(store, "word_count", callback("hello")) for callback in callbacks]
        results = [run(store, task_id) for task_id in task_ids]
        self.assertEqual(results, [
            {"hello": 1, "red": 1},
            {"hello": 1, "blue": 1},
            {"hello": 1, "green": 1},
        ])
        self.assertEqual(query(store, task_ids[0])["text"], "hello red")
        self.assertEqual(len(store["tasks"]), 3)


if __name__ == "__main__":
    unittest.main()
