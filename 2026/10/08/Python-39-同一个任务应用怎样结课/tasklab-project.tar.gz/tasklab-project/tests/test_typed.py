import json
import unittest

from tasklab.typed import MemoryTaskGateway, TaskGateway


class TypedGatewayTests(unittest.TestCase):
    def test_four_operations_delegate_to_same_app(self):
        service: TaskGateway = MemoryTaskGateway()
        finished = service.submit("word_count", "One one")
        cancelled = service.submit("word_count", "two")
        self.assertEqual(service.run(finished), {"one": 2})
        self.assertEqual(service.query(finished)["state"], "succeeded")
        self.assertTrue(service.cancel(cancelled))
        self.assertEqual(service.query(cancelled)["state"], "cancelled")

    def test_json_any_does_not_bypass_runtime_validation(self):
        service = MemoryTaskGateway()
        payload = json.loads('{"kind":"word_count","text":42}')
        with self.assertRaisesRegex(TypeError, "text must be a string"):
            service.submit(payload["kind"], payload["text"])
        self.assertEqual(service.store["tasks"], {})


if __name__ == "__main__":
    unittest.main()
