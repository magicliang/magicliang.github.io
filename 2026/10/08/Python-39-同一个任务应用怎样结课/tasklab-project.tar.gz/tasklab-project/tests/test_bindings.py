import unittest

from tasklab import create_store, query, run, submit


class BindingTests(unittest.TestCase):
    def test_rebinding_does_not_replace_callers_list(self):
        words = ["hello"]
        alias = words
        alias = ["different"]
        self.assertEqual(words, ["hello"])
        self.assertIsNot(alias, words)
        self.assertEqual(alias, ["different"])

    def test_mutation_is_visible_but_submitted_text_is_a_snapshot(self):
        words = ["hello"]
        alias = words
        store = create_store()
        first = submit(store, "word_count", " ".join(words))
        alias.append("world")
        second = submit(store, "word_count", " ".join(words))
        run(store, first)
        run(store, second)
        self.assertIs(alias, words)
        self.assertEqual(words, ["hello", "world"])
        self.assertEqual(query(store, first)["result"], {"hello": 1})
        self.assertEqual(query(store, second)["result"], {"hello": 1, "world": 1})


if __name__ == "__main__":
    unittest.main()
