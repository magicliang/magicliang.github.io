import unittest

from tasklab import create_store, run, submit
from tasklab.words import iter_words


class GeneratorTests(unittest.TestCase):
    def test_generator_does_not_read_next_chunk_before_first_token(self):
        read = []

        def chunks():
            for chunk in ("alpha ", "beta ", "alpha"):
                read.append(chunk)
                yield chunk

        words = iter_words(chunks())
        self.assertEqual(read, [])
        self.assertEqual(next(words), "alpha")
        self.assertEqual(read, ["alpha "])
        self.assertEqual(list(words), ["beta", "alpha"])
        self.assertEqual(read, ["alpha ", "beta ", "alpha"])

    def test_lazily_tokenized_task_matches_split_baseline(self):
        for text in ("", "A b A", " 你好\t世界 ", "UP UP\nDOWN"):
            with self.subTest(text=text):
                store = create_store()
                result = run(store, submit(store, "word_count", text))
                expected = {}
                for word in text.lower().split():
                    expected[word] = expected.get(word, 0) + 1
                self.assertEqual(result, expected)

    def test_closing_started_generator_does_not_read_remaining_chunks(self):
        read = []

        def chunks():
            for chunk in ("first ", "second "):
                read.append(chunk)
                yield chunk

        words = iter_words(chunks())
        self.assertEqual(next(words), "first")
        words.close()
        self.assertEqual(read, ["first "])
        self.assertEqual(list(words), [])


if __name__ == "__main__":
    unittest.main()
