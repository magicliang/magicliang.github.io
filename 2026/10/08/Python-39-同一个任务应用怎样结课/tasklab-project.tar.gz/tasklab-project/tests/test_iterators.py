import unittest

from tasklab import create_store, submit, task_ids


class IteratorTests(unittest.TestCase):
    def test_collection_can_be_read_again_but_iterator_stays_exhausted(self):
        store = create_store()
        first = submit(store, "word_count", "one")
        second = submit(store, "word_count", "two")
        collection = task_ids(store)
        iterator = iter(collection)
        self.assertEqual(next(iterator), first)
        self.assertEqual(list(iterator), [second])
        self.assertEqual(list(iterator), [])
        self.assertEqual(list(collection), [first, second])
        self.assertIsNot(iter(collection), iter(collection))

    def test_snapshot_does_not_change_after_new_submission(self):
        store = create_store()
        first = submit(store, "word_count", "one")
        snapshot = task_ids(store)
        second = submit(store, "word_count", "two")
        self.assertEqual(list(snapshot), [first])
        self.assertEqual(list(task_ids(store)), [first, second])


if __name__ == "__main__":
    unittest.main()
