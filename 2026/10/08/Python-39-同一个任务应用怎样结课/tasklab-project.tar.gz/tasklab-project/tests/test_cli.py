import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest


class CliTests(unittest.TestCase):
    def invoke(self, *arguments):
        environment = os.environ.copy()
        environment["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
        return subprocess.run(
            [sys.executable, "-m", "tasklab.cli", *map(str, arguments)],
            capture_output=True, text=True, env=environment, check=False,
        )

    def test_stdout_is_one_json_result(self):
        outcome = self.invoke("--text", "One two one")
        self.assertEqual(outcome.returncode, 0)
        self.assertEqual(outcome.stderr, "")
        result = json.loads(outcome.stdout)
        self.assertEqual(result["id"], "task-0001")
        self.assertEqual(result["state"], "succeeded")
        self.assertEqual(result["result"], {"one": 2, "two": 1})

    def test_file_and_text_use_same_task(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "words.txt"
            path.write_text("One two one", encoding="utf-8")
            from_file = self.invoke("--file", path)
        self.assertEqual(from_file.returncode, 0)
        self.assertEqual(from_file.stderr, "")
        self.assertEqual(json.loads(from_file.stdout), json.loads(self.invoke("--text", "One two one").stdout))

    def test_help_has_no_error_or_result(self):
        outcome = self.invoke("--help")
        self.assertEqual(outcome.returncode, 0)
        self.assertIn("--file", outcome.stdout)
        self.assertEqual(outcome.stderr, "")

    def test_errors_do_not_write_success_stdout(self):
        with TemporaryDirectory() as directory:
            bad = Path(directory) / "bad.txt"
            bad.write_bytes(b"\xff")
            big = Path(directory) / "big.txt"
            big.write_bytes(b"a" * 1025)
            cases = [
                ("--file", bad), ("--file", big),
                ("--file", Path(directory) / "missing"),
                ("--kind", "other", "--text", "one"),
                ("--text", "one", "--file", bad),
                ("--text", "a" * 1025),
                (),
            ]
            for arguments in cases:
                with self.subTest(arguments=arguments):
                    outcome = self.invoke(*arguments)
                    self.assertEqual(outcome.returncode, 2)
                    self.assertEqual(outcome.stdout, "")
                    self.assertIn("error:", outcome.stderr)


if __name__ == "__main__":
    unittest.main()
