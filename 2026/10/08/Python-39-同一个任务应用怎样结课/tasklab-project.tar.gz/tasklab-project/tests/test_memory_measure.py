import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch
import runpy


class MemoryMeasureTests(unittest.TestCase):
    def test_full_stream_equivalence_and_file_closure(self):
        project = Path(__file__).resolve().parents[1]
        result = subprocess.run([sys.executable, str(project / "benchmarks/37_memory.py"),
                                 "--lines", "100"], cwd=project,
                                env=dict(os.environ, PYTHONPATH=str(project / "src")),
                                capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)
        env, full, stream = map(json.loads, result.stdout.splitlines())
        self.assertEqual(env["measure_scope"],
                         "separate child processes per mode, tracing after input write")
        self.assertEqual(full["counts"], stream["counts"])
        self.assertEqual(full["counts"], {"one": 200, "two": 100})
        self.assertTrue(full["closed"] and stream["closed"])
        self.assertTrue(full["cycle_collected"] and stream["cycle_collected"])
        expected = ('pypy_gc_stats' if sys.implementation.name == 'pypy'
                    else 'cpython_tracemalloc')
        self.assertEqual(env['allocation_tracing'], expected)
        for record in (full, stream):
            self.assertEqual(record['allocation_tracing'], expected)
            if expected == 'cpython_tracemalloc':
                self.assertGreater(record['traced_peak_bytes'], 0)
                self.assertGreaterEqual(record['traced_retained_after_gc_bytes'], 0)
                self.assertIsNone(record['pypy_gc'])
            else:
                self.assertIsNone(record['traced_peak_bytes'])
                self.assertIsNone(record['traced_retained_after_gc_bytes'])
                snapshots = record['pypy_gc']
                self.assertEqual(set(snapshots), {'before', 'during', 'after_gc'})
                for snapshot in snapshots.values():
                    self.assertGreater(snapshot['total_gc_memory'], 0)
                    self.assertGreaterEqual(snapshot['total_allocated_memory'],
                                            snapshot['total_gc_memory'])
                    self.assertGreaterEqual(snapshot['peak_memory'],
                                            snapshot['total_gc_memory'])
        self.assertTrue(all(record["current_rss_source"] in {"linux_proc_statm",
                                                             "mach_task_basic_info"}
                            for record in (full, stream)))
        self.assertTrue(all(record["current_rss_during_bytes"] > 0
                            and record["peak_rss"]["bytes"] >= record["current_rss_during_bytes"]
                            for record in (full, stream)))

    def test_missing_tracer_does_not_hide_other_import_errors(self):
        namespace = runpy.run_path(str(Path(__file__).resolve().parents[1] /
                                      'benchmarks/37_memory.py'))
        loader = namespace['load_tracer']
        for missing in ('tracemalloc', '_tracemalloc'):
            with patch('builtins.__import__', side_effect=ModuleNotFoundError(name=missing)):
                self.assertIsNone(loader())
        with patch('builtins.__import__', side_effect=ModuleNotFoundError(name='unrelated')):
            with self.assertRaises(ModuleNotFoundError):
                loader()


if __name__ == "__main__":
    unittest.main()
