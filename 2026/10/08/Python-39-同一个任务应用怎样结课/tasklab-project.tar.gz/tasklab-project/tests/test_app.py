import unittest

from tasklab import cancel, create_store, query, run, submit


class TaskLabTests(unittest.TestCase):
    def setUp(self):
        self.store = create_store()

    def test_submit_run_query(self):
        task_id = submit(self.store, "word_count", "hello hello world")
        self.assertEqual(task_id, "task-0001")
        self.assertEqual(query(self.store, task_id)["state"], "queued")
        self.assertEqual(run(self.store, task_id), {"hello": 2, "world": 1})
        self.assertEqual(query(self.store, task_id)["state"], "succeeded")
        self.assertEqual(cancel(self.store, task_id), False)

    def test_invalid_input_preserves_existing_tasks_and_id(self):
        previous = submit(self.store, "word_count", "one")
        before = query(self.store, previous)
        with self.assertRaisesRegex(ValueError, "only word_count"):
            submit(self.store, "", "invalid")
        with self.assertRaisesRegex(TypeError, "text must be a string"):
            submit(self.store, "word_count", None)
        self.assertEqual(query(self.store, previous), before)
        self.assertEqual(len(self.store["tasks"]), 1)
        self.assertEqual(submit(self.store, "word_count", "two"), "task-0002")

    def test_cancel_queued_task_without_running(self):
        task_id = submit(self.store, "word_count", "one")
        self.assertTrue(cancel(self.store, task_id))
        self.assertEqual(query(self.store, task_id)["state"], "cancelled")
        with self.assertRaisesRegex(ValueError, "only queued"):
            run(self.store, task_id)

    def test_query_snapshot_does_not_change_result(self):
        task_id = submit(self.store, "word_count", "one")
        run(self.store, task_id)
        query(self.store, task_id)["result"]["one"] = 9
        self.assertEqual(query(self.store, task_id)["result"], {"one": 1})


if __name__ == "__main__":
    unittest.main()
