import unittest
from dataclasses import FrozenInstanceError, dataclass, field

from tasklab import create_store, query, run, submit
from tasklab.model import TaskDefinition, TaskResult


class DataclassTests(unittest.TestCase):
    def test_default_factory_creates_independent_counts(self):
        first = TaskResult()
        second = TaskResult()
        first.counts["one"] = 1
        self.assertEqual(second.counts, {})
        self.assertIsNot(first.counts, second.counts)

    def test_frozen_field_assignment_fails_but_nested_list_can_change(self):
        @dataclass(frozen=True)
        class FrozenExample:
            labels: list[str] = field(default_factory=list)

        record = FrozenExample()
        with self.assertRaises(FrozenInstanceError):
            record.labels = []
        record.labels.append("changed")
        self.assertEqual(record.labels, ["changed"])

    def test_production_definition_uses_immutable_label_tuple(self):
        first = TaskDefinition("word_count", "one", ("first",))
        second = TaskDefinition("word_count", "one", ("first",))
        self.assertEqual(first, second)
        self.assertIsNot(first, second)
        with self.assertRaises(FrozenInstanceError):
            first.text = "two"
        store = create_store()
        task_id = submit(store, "word_count", "one", metadata={"labels": ["first"]})
        self.assertEqual(run(store, task_id), {"one": 1})
        query(store, task_id)["metadata"]["labels"].append("outside")
        self.assertEqual(query(store, task_id)["metadata"]["labels"], ["first"])


if __name__ == "__main__":
    unittest.main()
