import asyncio
import unittest

from tasklab import create_store, query, submit
from tasklab.async_runner import run_async


class AsyncRunnerTests(unittest.IsolatedAsyncioTestCase):
    async def test_coroutine_needs_scheduling_and_wait_yields(self):
        store = create_store()
        task_id = submit(store, "word_count", "One two one")
        gate = asyncio.Event()
        coroutine = run_async(store, task_id, wait_event=gate)
        self.assertEqual(query(store, task_id)["state"], "queued")
        task = asyncio.create_task(coroutine)
        self.assertEqual(query(store, task_id)["state"], "queued")
        order = []

        async def heartbeat():
            await asyncio.sleep(0)
            order.append("heartbeat")

        beat = asyncio.create_task(heartbeat())
        await asyncio.sleep(0)
        self.assertEqual(query(store, task_id)["state"], "running")
        self.assertFalse(task.done())
        await beat
        self.assertEqual(order, ["heartbeat"])
        self.assertFalse(task.done())
        gate.set()
        self.assertEqual(await task, {"one": 2, "two": 1})
        self.assertEqual(query(store, task_id)["state"], "succeeded")

    async def test_cpu_work_blocks_heartbeat_until_return(self):
        store = create_store()
        task_id = submit(store, "word_count", "One two one")
        gate = asyncio.Event()
        order = []

        async def heartbeat():
            await gate.wait()
            order.append("heartbeat")

        async def compute():
            order.append("start")
            gate.set()
            result = await run_async(store, task_id, iterations=20000)
            order.append("end")
            return result

        beat = asyncio.create_task(heartbeat())
        worker = asyncio.create_task(compute())
        self.assertEqual(await worker, {"one": 2, "two": 1})
        await beat
        self.assertEqual(order, ["start", "end", "heartbeat"])


if __name__ == "__main__":
    unittest.main()
