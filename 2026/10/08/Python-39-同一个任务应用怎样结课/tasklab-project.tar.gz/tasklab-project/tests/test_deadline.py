from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from tasklab import TaskExecutionError, create_store, query, run, submit
from tasklab.database import SQLiteTaskGateway
from tasklab.resources import open_word_file


class DeadlineTests(unittest.TestCase):
    def test_expired_before_start_leaves_task_queued(self):
        store = create_store()
        task_id = submit(store, "word_count", "one")
        with self.assertRaisesRegex(TimeoutError, "before start"):
            run(store, task_id, clock=lambda: 5, deadline=5)
        self.assertEqual(query(store, task_id)["state"], "queued")
        self.assertEqual(run(store, task_id, clock=lambda: 1, deadline=5), {"one": 1})

    def test_expired_after_compute_is_failed_not_success(self):
        store = create_store()
        task_id = submit(store, "word_count", "one two")
        samples = iter((1, 6))
        with self.assertRaises(TaskExecutionError) as caught:
            run(store, task_id, clock=lambda: next(samples), deadline=5)
        self.assertIsInstance(caught.exception.__cause__, TimeoutError)
        self.assertEqual(query(store, task_id)["state"], "failed")
        self.assertIsNone(query(store, task_id)["result"])

    def test_real_database_and_file_still_work(self):
        with TemporaryDirectory() as directory:
            folder = Path(directory)
            path = folder / "words.txt"
            path.write_text("One two one", encoding="utf-8")
            with open_word_file(path) as (words, source):
                self.assertEqual(next(words), "one")
            self.assertTrue(source.closed)
            gateway = SQLiteTaskGateway(folder / "tasklab.sqlite")
            failed = gateway.submit("word_count", "One two one")
            samples = iter((1, 6))
            with self.assertRaises(TaskExecutionError):
                gateway.run(failed, clock=lambda: next(samples), deadline=5)
            reopened = SQLiteTaskGateway(folder / "tasklab.sqlite")
            self.assertEqual(reopened.query(failed)["state"], "failed")
            self.assertIsNone(reopened.query(failed)["result"])
            successful = reopened.submit("word_count", path.read_text(encoding="utf-8"))
            self.assertEqual(reopened.run(successful, clock=lambda: 1, deadline=5),
                             {"one": 2, "two": 1})


if __name__ == "__main__":
    unittest.main()
