import unittest

from tasklab import create_store, query, run, submit


class ValueTests(unittest.TestCase):
    def test_empty_text_is_valid_but_non_strings_are_not(self):
        store = create_store()
        empty = submit(store, "word_count", "")
        self.assertEqual(run(store, empty), {})
        self.assertEqual(query(store, empty)["result"], {})
        self.assertEqual(query(store, empty)["state"], "succeeded")
        for value in (0, False, None):
            with self.subTest(value=value):
                with self.assertRaises(TypeError):
                    submit(store, "word_count", value)
                self.assertEqual(len(store["tasks"]), 1)
        self.assertEqual(submit(store, "word_count", "next"), "task-0002")

    def test_equal_texts_produce_equal_results_without_identity_requirement(self):
        store = create_store()
        first = submit(store, "word_count", "hello world")
        second = submit(store, "word_count", " ".join(["hello", "world"]))
        self.assertEqual(run(store, first), run(store, second))
        self.assertEqual(query(store, first)["result"], {"hello": 1, "world": 1})
        self.assertIsNot(query(store, first)["result"], query(store, second)["result"])


if __name__ == "__main__":
    unittest.main()
