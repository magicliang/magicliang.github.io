from threading import Event, Thread
import unittest

from tasklab import TaskExecutionError, create_store, query, run, submit
from tasklab.workloads import cpu_work


class WorkloadTests(unittest.TestCase):
    def test_cpu_work_does_not_change_business_result(self):
        store = create_store()
        plain = submit(store, "word_count", "One two one")
        loaded = submit(store, "word_count", "One two one")
        self.assertEqual(cpu_work("one", iterations=4), cpu_work("one", iterations=4))
        self.assertEqual(run(store, plain), run(store, loaded,
                                               workload=lambda text: cpu_work(text, iterations=1000)))
        self.assertEqual(query(store, loaded)["state"], "succeeded")

    def test_wait_uses_events_not_sleep(self):
        store = create_store()
        task_id = submit(store, "word_count", "One two one")
        entered = Event()
        release = Event()
        exited = Event()
        result = {}

        def wait_workload(text):
            self.assertEqual(text, "One two one")
            entered.set()
            if not release.wait(5):
                raise TimeoutError("test release event never arrived")

        def worker():
            try:
                result["counts"] = run(store, task_id, workload=wait_workload)
            finally:
                exited.set()

        thread = Thread(target=worker)
        thread.start()
        try:
            self.assertTrue(entered.wait(5))
            self.assertEqual(query(store, task_id)["state"], "running")
            self.assertFalse(exited.is_set())
        finally:
            release.set()
            thread.join(5)
        self.assertFalse(thread.is_alive())
        self.assertTrue(exited.is_set())
        self.assertEqual(result["counts"], {"one": 2, "two": 1})

    def test_workload_error_is_execution_failure(self):
        store = create_store()
        task_id = submit(store, "word_count", "one")

        def fail(_text):
            raise RuntimeError("controlled workload failure")

        with self.assertRaises(TaskExecutionError):
            run(store, task_id, workload=fail)
        self.assertEqual(query(store, task_id)["state"], "failed")
        self.assertIsNone(query(store, task_id)["result"])


if __name__ == "__main__":
    unittest.main()
