import asyncio
import json
from pathlib import Path
import signal
import sys
import tempfile
import unittest

from tasklab import create_store
from tasklab.database import SQLiteTaskGateway
from tasklab.jsonline import LoopbackService


async def wait_for_active_handler(service):
    for _ in range(100):
        if service._active:
            return
        await asyncio.sleep(0.01)
    raise AssertionError("handler did not become active")


async def wait_for_closing(service):
    for _ in range(100):
        if service._closing:
            return
        await asyncio.sleep(0.01)
    raise AssertionError("service did not begin closing")


class ServiceShutdownTests(unittest.IsolatedAsyncioTestCase):
    async def test_late_handler_after_close_gate_is_rejected(self):
        class Writer:
            def __init__(self):
                self.closed = False

            def close(self):
                self.closed = True

            async def wait_closed(self):
                pass

        service = LoopbackService(create_store())
        service._closing = True
        writer = Writer()
        await service._serve_client(None, writer)
        self.assertTrue(writer.closed)
        self.assertFalse(service._active)

    async def test_late_loopback_handler_after_close_does_not_submit(self):
        store = create_store()
        service = LoopbackService(store)
        original_serve_client = service._serve_client
        entered, release = asyncio.Event(), asyncio.Event()

        async def gated_serve_client(reader, writer):
            entered.set()
            await release.wait()
            await original_serve_client(reader, writer)

        service._serve_client = gated_serve_client
        host, port = await service.start()
        reader, writer = await asyncio.open_connection(host, port)
        writer.write(b'{"op":"submit","kind":"word_count","text":"One two one"}\n')
        await writer.drain()
        await entered.wait()
        close_task = asyncio.create_task(service.close(drain_timeout=0))
        await wait_for_closing(service)
        release.set()
        self.assertEqual(await asyncio.wait_for(close_task, timeout=0.2), 0)
        self.assertEqual(await reader.read(), b"")
        self.assertEqual(store["tasks"], {})
        self.assertFalse(service._active)
        writer.close()
        await writer.wait_closed()

    async def test_late_half_frame_does_not_delay_zero_drain_close(self):
        store = create_store()
        service = LoopbackService(store)
        original_serve_client = service._serve_client
        entered, release = asyncio.Event(), asyncio.Event()

        async def gated_serve_client(reader, writer):
            entered.set()
            await release.wait()
            await original_serve_client(reader, writer)

        service._serve_client = gated_serve_client
        host, port = await service.start()
        reader, writer = await asyncio.open_connection(host, port)
        writer.write(b'{"op":"submit"')
        await writer.drain()
        await entered.wait()
        close_task = asyncio.create_task(service.close(drain_timeout=0))
        await wait_for_closing(service)
        loop = asyncio.get_running_loop()
        before = loop.time()
        release.set()
        self.assertEqual(await asyncio.wait_for(close_task, timeout=0.2), 0)
        self.assertLess(loop.time() - before, 0.2)
        self.assertEqual(await reader.read(), b"")
        self.assertEqual(store["tasks"], {})
        self.assertFalse(service._active)
        writer.close()
        await writer.wait_closed()

    async def test_stop_accepting_and_bounded_drain(self):
        service = LoopbackService(create_store(), read_timeout=10)
        host, port = await service.start()
        reader, writer = await asyncio.open_connection(host, port)
        writer.write(b'{"op":"submit"')
        await writer.drain()
        await wait_for_active_handler(service)
        self.assertEqual(await service.close(drain_timeout=0), 1)
        self.assertEqual(await reader.read(), b"")
        self.assertFalse(service._active)
        with self.assertRaises(OSError):
            await asyncio.open_connection(host, port)
        writer.close()
        await writer.wait_closed()

    async def test_complete_request_before_graceful_close(self):
        store = create_store()
        service = LoopbackService(store)
        host, port = await service.start()
        reader, writer = await asyncio.open_connection(host, port)
        writer.write(b'{"op":"submit","kind":"word_count","text":"One two one"}\n')
        await writer.drain()
        self.assertEqual(json.loads(await reader.readline())["id"], "task-0001")
        self.assertEqual(await service.close(), 0)
        writer.close()
        await writer.wait_closed()


class CrashRecoveryTests(unittest.IsolatedAsyncioTestCase):
    async def test_force_kill_distinguishes_committed_claim_and_rollback(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "tasks.db"
            gateway = SQLiteTaskGateway(path)
            claimed = gateway.submit("word_count", "One two one")
            rolled_back = gateway.submit("word_count", "One two one")
            worker = Path(__file__).resolve().parents[1] / "experiments/35_worker.py"
            for task_id, mode, message in ((claimed, "claimed", b"claimed running"),
                                           (rolled_back, "transaction", b"inside uncommitted run")):
                process = await asyncio.create_subprocess_exec(
                    sys.executable, str(worker), str(path), task_id, mode,
                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
                try:
                    line = await asyncio.wait_for(process.stdout.readline(), timeout=3)
                    self.assertIn(message, line)
                    if mode == "claimed":
                        self.assertEqual(gateway.query(task_id)["state"], "running")
                        process.kill()
                    self.assertEqual(await asyncio.wait_for(process.wait(), 3), -signal.SIGKILL)
                finally:
                    if process.returncode is None:
                        process.kill()
                        await process.wait()
            reopened = SQLiteTaskGateway(path)
            self.assertEqual(reopened.query(rolled_back)["state"], "queued")
            self.assertEqual(reopened.query(claimed)["state"], "running")
            requested = reopened.submit("word_count", "One two one")
            reopened.claim(requested)
            self.assertTrue(reopened.cancel(requested))
            self.assertEqual(reopened.query(requested)["state"], "cancel_requested")
            self.assertEqual(reopened.recover_running(), (claimed, requested))
            self.assertEqual(reopened.query(claimed)["state"], "failed")
            self.assertEqual(reopened.query(requested)["state"], "failed")
            self.assertIn("unknown", reopened.query(claimed)["error"])
            self.assertIsNone(reopened.query(claimed)["result"])
            self.assertEqual(reopened.recover_running(), ())
            self.assertEqual(reopened.run(rolled_back), {"one": 2, "two": 1})


if __name__ == "__main__":
    unittest.main()
