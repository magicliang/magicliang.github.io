import json
import os
from pathlib import Path
import subprocess
import sys
import unittest


class ImportTests(unittest.TestCase):
    def invoke(self, *arguments):
        environment = os.environ.copy()
        environment["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
        return subprocess.run([sys.executable, *arguments], capture_output=True, text=True,
                              check=False, env=environment)

    def test_import_does_not_construct_store(self):
        outcome = self.invoke("-c", "import tasklab.app as app; app.create_store = lambda: 1/0; import tasklab.cli, tasklab.storage; print('loaded')")
        self.assertEqual((outcome.returncode, outcome.stdout, outcome.stderr), (0, "loaded\n", ""))

    def test_package_entry_reuses_original_task(self):
        outcome = self.invoke("-m", "tasklab", "--text", "One two one")
        self.assertEqual(outcome.returncode, 0)
        self.assertEqual(outcome.stderr, "")
        self.assertEqual(json.loads(outcome.stdout)["result"], {"one": 2, "two": 1})

    def test_import_cache_stays_same_object(self):
        outcome = self.invoke("-c", "import tasklab.cli as first; import tasklab.cli as second; print(first is second)")
        self.assertEqual((outcome.returncode, outcome.stdout, outcome.stderr), (0, "True\n", ""))


if __name__ == "__main__":
    unittest.main()
