from threading import Event, Thread, enumerate as active_threads
import unittest

from tasklab import create_store, query, submit
from tasklab.thread_runner import ThreadTaskRunner


class ThreadRunnerTests(unittest.TestCase):
    def test_queued_and_running_cancel_have_different_future_status(self):
        store = create_store()
        running = submit(store, "word_count", "one")
        pending = submit(store, "word_count", "two")
        entered = Event()
        release = Event()

        def blocked(_text):
            entered.set()
            if not release.wait(5):
                raise TimeoutError("worker release missing")

        try:
            with ThreadTaskRunner(store, workers=1, backlog=1) as runner:
                first = runner.submit(running, workload=blocked)
                self.assertTrue(entered.wait(5))
                second = runner.submit(pending)
                with self.assertRaises(BufferError):
                    runner.submit(pending)
                self.assertEqual(runner.cancel(second),
                                 {"future_cancelled": True, "request_accepted": True})
                self.assertEqual(query(store, pending)["state"], "cancelled")
                self.assertEqual(runner.cancel(first),
                                 {"future_cancelled": False, "request_accepted": True})
                self.assertEqual(query(store, running)["state"], "cancel_requested")
                self.assertFalse(first.done())
                release.set()
                self.assertIsNone(first.result(timeout=5))
            self.assertEqual(query(store, running)["state"], "cancelled")
            self.assertIsNone(query(store, running)["result"])
            self.assertFalse(any(thread.name.startswith("tasklab-worker")
                                 for thread in active_threads()))
        finally:
            release.set()

    def test_shutdown_cancels_pending_and_waits_for_worker(self):
        store = create_store()
        first_id = submit(store, "word_count", "one")
        second_id = submit(store, "word_count", "two")
        entered = Event()
        release = Event()
        closed = Event()
        pending_cancelled = Event()
        runner = ThreadTaskRunner(store, workers=1, backlog=1)

        def blocked(_text):
            entered.set()
            if not release.wait(5):
                raise TimeoutError("worker release missing")

        shutdown_thread = None
        try:
            first = runner.submit(first_id, workload=blocked)
            self.assertTrue(entered.wait(5))
            second = runner.submit(second_id)
            second.add_done_callback(lambda _future: pending_cancelled.set())

            def close_runner():
                runner.shutdown()
                closed.set()

            shutdown_thread = Thread(target=close_runner)
            shutdown_thread.start()
            self.assertTrue(pending_cancelled.wait(5))
            self.assertTrue(second.cancelled())
            self.assertEqual(query(store, second_id)["state"], "cancelled")
            self.assertFalse(first.done())
            self.assertFalse(closed.is_set())
        finally:
            release.set()
            if shutdown_thread is not None:
                shutdown_thread.join(5)
            runner.shutdown()
        self.assertFalse(shutdown_thread.is_alive())
        self.assertTrue(closed.is_set())
        self.assertEqual(first.result(timeout=5), {"one": 1})


if __name__ == "__main__":
    unittest.main()
