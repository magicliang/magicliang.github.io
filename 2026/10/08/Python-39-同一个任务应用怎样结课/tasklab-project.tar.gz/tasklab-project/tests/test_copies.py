import unittest

from tasklab import create_store, query, run, submit


class CopyTests(unittest.TestCase):
    def test_shallow_copy_leaks_nested_mutation(self):
        metadata = {"labels": ["first"]}
        shallow = metadata.copy()
        shallow["labels"].append("leaked")
        self.assertEqual(metadata["labels"], ["first", "leaked"])
        self.assertIs(metadata["labels"], shallow["labels"])

    def test_submit_and_query_isolate_supported_nested_metadata(self):
        metadata = {"labels": ["first"]}
        store = create_store()
        first = submit(store, "word_count", "hello", metadata=metadata)
        metadata["labels"].append("second")
        second = submit(store, "word_count", "world", metadata=metadata)
        query(store, first)["metadata"]["labels"].append("outside")
        self.assertEqual(query(store, first)["metadata"]["labels"], ["first"])
        self.assertEqual(query(store, second)["metadata"]["labels"], ["first", "second"])
        self.assertEqual(run(store, first), {"hello": 1})
        self.assertEqual(run(store, second), {"world": 1})

    def test_invalid_metadata_does_not_claim_id(self):
        store = create_store()
        for metadata in ({"labels": "bad"}, {"labels": [1]}, {"unknown": []}):
            with self.subTest(metadata=metadata):
                with self.assertRaises(ValueError):
                    submit(store, "word_count", "hello", metadata=metadata)
                self.assertEqual(len(store["tasks"]), 0)
        self.assertEqual(submit(store, "word_count", "hello"), "task-0001")

    def test_equal_hash_keys_alias_same_dictionary_slot(self):
        first = ("label", "short")
        equal = tuple(["label", "short"])
        self.assertEqual(first, equal)
        self.assertEqual(hash(first), hash(equal))
        self.assertEqual({first: "known"}[equal], "known")
        with self.assertRaises(TypeError):
            {"labels": []}[[]]


if __name__ == "__main__":
    unittest.main()
