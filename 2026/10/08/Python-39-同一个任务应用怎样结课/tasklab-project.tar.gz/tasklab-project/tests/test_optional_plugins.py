import unittest

from tasklab import TaskExecutionError, create_store, query, run, submit
from tasklab.optional_plugins import observed


class OptionalPluginTests(unittest.TestCase):
    def test_forwarding_return_metadata_and_business_result(self):
        events = []

        def named(text: str, *, label: str) -> int:
            return len(text) + len(label)

        wrapped = observed(named, events)
        self.assertEqual(wrapped('one', label='two'), 6)
        self.assertEqual(wrapped.__name__, 'named')
        self.assertEqual(events, ['entered', 'exited'])
        events.clear()
        store = create_store()
        task_id = submit(store, 'word_count', 'One two one')

        def workload(text: str) -> int:
            events.append('workload:' + text)
            return 999

        self.assertEqual(run(store, task_id, workload=observed(workload, events)),
                         {'one': 2, 'two': 1})
        self.assertEqual(events, ['entered', 'workload:One two one', 'exited'])
        self.assertEqual(query(store, task_id)['state'], 'succeeded')

    def test_plugin_failure_keeps_finally_and_failed_state(self):
        store = create_store()
        task_id = submit(store, 'word_count', 'one')
        events = []

        def failing(text: str) -> None:
            raise ValueError('controlled plugin failure')

        with self.assertRaises(TaskExecutionError):
            run(store, task_id, workload=observed(failing, events))
        self.assertEqual(events, ['entered', 'exited'])
        self.assertEqual(query(store, task_id)['state'], 'failed')
        self.assertIsNone(query(store, task_id)['result'])

    def test_runtime_input_rejected_without_creating_task(self):
        store = create_store()
        with self.assertRaisesRegex(TypeError, 'text must be a string'):
            submit(store, 'word_count', 42)
        self.assertEqual(store['tasks'], {})


if __name__ == '__main__':
    unittest.main()
