import json
import unittest

from tasklab import cancel, create_store, query, run, submit
from tasklab.serialization import TaskFormatError, decode_task, encode_task


class SerializationTests(unittest.TestCase):
    def test_round_trip_for_queued_completed_cancelled(self):
        store = create_store()
        for text in ("", "一 二 一", "two"):
            task_id = submit(store, "word_count", text, metadata={"labels": ["汉字"]})
            if text == "一 二 一":
                run(store, task_id)
            if text == "two":
                cancel(store, task_id)
            encoded = encode_task(task_id, query(store, task_id))
            self.assertEqual(decode_task(encoded), (task_id, query(store, task_id)))

    def test_reject_invalid_fields_and_state_combinations(self):
        store = create_store()
        task_id = submit(store, "word_count", "one")
        valid = json.loads(encode_task(task_id, query(store, task_id)))
        for updates in ({"version": 2}, {"version": True}, {"text": 42},
                        {"text": "\ud800"},
                        {"metadata": {"labels": [1]}}, {"kind": "shell"},
                        {"state": "ghost"}, {"result": {"one": True}},
                        {"error": "unexpected"}, {"id": 1}):
            with self.subTest(updates=updates):
                with self.assertRaises(TaskFormatError):
                    decode_task(json.dumps(valid | updates))
        for name in valid:
            with self.subTest(missing=name):
                with self.assertRaises(TaskFormatError):
                    decode_task(json.dumps({key: value for key, value in valid.items() if key != name}))

    def test_malformed_duplicate_and_nonfinite_rejected(self):
        for raw in ("{", '{"version":1,"version":2}',
                    json.dumps({"version": float("nan")})):
            with self.subTest(raw=raw):
                with self.assertRaises(TaskFormatError):
                    decode_task(raw)


if __name__ == "__main__":
    unittest.main()
