import argparse
import ctypes
import gc
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import tempfile
import weakref

from tasklab.app import count_words
from tasklab.resources import open_word_file
from tasklab.words import iter_words


def load_tracer():
    try:
        import tracemalloc
    except ModuleNotFoundError as error:
        if error.name not in {'tracemalloc', '_tracemalloc'}:
            raise
        return None
    return tracemalloc


tracemalloc = load_tracer()


def pypy_gc_snapshot():
    if sys.implementation.name != "pypy" or not hasattr(gc, "get_stats"):
        return None
    stats = gc.get_stats(memory_pressure=True)._s
    return {name: int(getattr(stats, name)) for name in (
        "total_gc_memory", "total_allocated_memory", "peak_memory",
        "peak_allocated_memory", "total_memory_pressure", "jit_backend_used",
        "jit_backend_allocated")}


def current_rss():
    statm = Path("/proc/self/statm")
    if statm.exists():
        pages = int(statm.read_text().split()[1])
        return {"bytes": pages * os.sysconf("SC_PAGE_SIZE"), "source": "linux_proc_statm"}
    if sys.platform == "darwin":
        return {"bytes": macos_current_rss_bytes(), "source": "mach_task_basic_info"}
    raise RuntimeError("current RSS is only implemented for Linux and macOS")


def macos_current_rss_bytes():
    class TimeValue(ctypes.Structure):
        _fields_ = [("seconds", ctypes.c_int), ("microseconds", ctypes.c_int)]

    class MachTaskBasicInfo(ctypes.Structure):
        _fields_ = [("virtual_size", ctypes.c_uint64),
                    ("resident_size", ctypes.c_uint64),
                    ("resident_size_max", ctypes.c_uint64),
                    ("user_time", TimeValue),
                    ("system_time", TimeValue),
                    ("policy", ctypes.c_int),
                    ("suspend_count", ctypes.c_int)]

    libsystem = ctypes.CDLL("/usr/lib/libSystem.B.dylib")
    info = MachTaskBasicInfo()
    count = ctypes.c_uint32(ctypes.sizeof(info) // ctypes.sizeof(ctypes.c_int))
    result = libsystem.task_info(libsystem.mach_task_self(), 20, ctypes.byref(info),
                                 ctypes.byref(count))
    if result != 0:
        raise OSError(result, "task_info failed")
    return int(info.resident_size)


def peak_rss():
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if sys.platform == "darwin":
        return {"bytes": value, "source": "ru_maxrss_bytes"}
    return {"bytes": value * 1024, "source": "ru_maxrss_kib"}


def child(mode, lines):
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "input.txt"
        with path.open("w", encoding="utf-8") as target:
            for _ in range(lines):
                target.write("One two one\n")
        size = path.stat().st_size
        gc.collect()
        rss_before = current_rss()
        pypy_before = pypy_gc_snapshot()
        if tracemalloc is not None:
            tracemalloc.start()
        if mode == "full":
            with path.open("r", encoding="utf-8") as source:
                data = source.read()
                counts = count_words(iter_words((data,)))
                rss_during = current_rss()
            closed = source.closed
            del data
        elif mode == "stream":
            with open_word_file(path) as (words, source):
                counts = count_words(words)
                rss_during = current_rss()
            closed = source.closed
        else:
            raise ValueError("unknown mode")
        peak = tracemalloc.get_traced_memory()[1] if tracemalloc is not None else None
        pypy_during = pypy_gc_snapshot()
        gc.collect()
        retained = tracemalloc.get_traced_memory()[0] if tracemalloc is not None else None
        pypy_after = pypy_gc_snapshot()
        rss_after = current_rss()
        if tracemalloc is not None:
            tracemalloc.stop()
        assert closed and counts == {"one": 2 * lines, "two": lines}

        class Link:
            pass

        link = Link()
        link.next = link
        marker = weakref.ref(link)
        del link
        assert marker() is not None
        gc.collect()
        assert marker() is None
        return {"mode": mode, "lines": lines, "input_bytes": size,
                "counts": counts, "closed": closed, "cycle_collected": True,
                "allocation_tracing": ("cpython_tracemalloc" if tracemalloc is not None
                                       else "pypy_gc_stats"),
                "traced_peak_bytes": peak, "traced_retained_after_gc_bytes": retained,
                "pypy_gc": ({"before": pypy_before, "during": pypy_during,
                              "after_gc": pypy_after} if pypy_before is not None else None),
                "current_rss_before_bytes": rss_before["bytes"],
                "current_rss_during_bytes": rss_during["bytes"],
                "current_rss_after_gc_bytes": rss_after["bytes"],
                "current_rss_source": rss_before["source"],
                "peak_rss": peak_rss()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lines", type=int, default=30000)
    parser.add_argument("--mode", choices=("full", "stream"))
    args = parser.parse_args()
    if not 1 <= args.lines <= 100000:
        parser.error("lines must be 1..100000")
    if args.mode:
        print(json.dumps(child(args.mode, args.lines)))
        return
    print(json.dumps({"type": "environment", "python": sys.version,
                      "executable": sys.executable, "page_size": os.sysconf("SC_PAGE_SIZE"),
                      "platform": sys.platform, "lines": args.lines,
                      "implementation": sys.implementation.name,
                      "allocation_tracing": ("cpython_tracemalloc" if tracemalloc is not None
                                             else "pypy_gc_stats"),
                      "measure_scope": "separate child processes per mode, tracing after input write"}))
    for mode in ("full", "stream"):
        result = subprocess.run([sys.executable, __file__, "--mode", mode,
                                 "--lines", str(args.lines)],
                                capture_output=True, text=True, check=True)
        print(result.stdout.strip())


if __name__ == "__main__":
    main()
