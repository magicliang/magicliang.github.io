import argparse
import asyncio
import cProfile
import io
import json
import os
import platform
import pstats
from statistics import median
import sys
from time import perf_counter_ns, process_time_ns

from tasklab import create_store, query, run, submit
from tasklab.async_runner import run_async
from tasklab.process_runner import ProcessTaskRunner
from tasklab.thread_runner import ThreadTaskRunner
from tasklab.workloads import cpu_work


TEXT = "One two one"
TASK_COUNT = 4
EXPECTED = {"one": 2, "two": 1}


def execute(mode, iterations):
    store = create_store()
    task_ids = [submit(store, "word_count", TEXT) for _ in range(TASK_COUNT)]
    if mode == "sequential":
        results = [run(store, task_id,
                       workload=lambda data: cpu_work(data, iterations=iterations))
                   for task_id in task_ids]
    elif mode == "thread":
        with ThreadTaskRunner(store, workers=2, backlog=2) as runner:
            futures = [runner.submit(task_id,
                                     workload=lambda data: cpu_work(data, iterations=iterations))
                       for task_id in task_ids]
            results = [future.result(timeout=30) for future in futures]
    elif mode == "process":
        with ProcessTaskRunner(workers=2) as runner:
            results = [runner.run(store, task_id, iterations=iterations) for task_id in task_ids]
    elif mode == "asyncio":
        async def work():
            tasks = [asyncio.create_task(run_async(store, task_id, iterations=iterations))
                     for task_id in task_ids]
            return await asyncio.gather(*tasks)

        results = asyncio.run(work())
    else:
        raise ValueError("unknown execution mode")
    states = [query(store, task_id)["state"] for task_id in task_ids]
    assert results == [EXPECTED] * TASK_COUNT and states == ["succeeded"] * TASK_COUNT
    return {"completed": len(results), "failed": len([state for state in states if state == "failed"])}


def measure(mode, iterations):
    start_wall, start_cpu = perf_counter_ns(), process_time_ns()
    result = execute(mode, iterations)
    wall_ns, parent_cpu_ns = perf_counter_ns() - start_wall, process_time_ns() - start_cpu
    return {"mode": mode, "wall_ns": wall_ns, "parent_cpu_ns": parent_cpu_ns,
            "tasks_per_second": TASK_COUNT * 1_000_000_000 / wall_ns, **result}


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--samples", type=int, default=5)
    parser.add_argument("--iterations", type=int, default=20000)
    args = parser.parse_args(argv)
    if not 2 <= args.samples <= 20 or args.iterations < 0:
        parser.error("samples must be 2..20 and iterations nonnegative")
    modes = ("sequential", "thread", "process", "asyncio")
    print(json.dumps({"type": "environment", "python": sys.version, "executable": sys.executable,
                      "platform": platform.platform(), "machine": platform.machine(),
                      "pid": os.getpid(), "text": TEXT, "tasks_per_sample": TASK_COUNT,
                      "iterations": args.iterations, "samples": args.samples,
                      "scope": "create store, runner/pool startup, execution, join/shutdown",
                      "process_cpu_scope": "parent process only"}))
    for mode in modes:
        warmup = measure(mode, args.iterations)
        print(json.dumps({"type": "warmup", "mode": mode, "wall_ns": warmup["wall_ns"]}))
        samples = []
        for index in range(args.samples):
            sample = measure(mode, args.iterations)
            sample.update({"type": "sample", "index": index})
            samples.append(sample)
            print(json.dumps(sample))
        walls = [sample["wall_ns"] for sample in samples]
        print(json.dumps({"type": "summary", "mode": mode, "wall_ns_min": min(walls),
                          "wall_ns_median": median(walls), "wall_ns_max": max(walls),
                          "failed_total": sum(sample["failed"] for sample in samples)}))
    profile = cProfile.Profile()
    profile.enable()
    execute("sequential", args.iterations)
    profile.disable()
    output = io.StringIO()
    pstats.Stats(profile, stream=output).sort_stats("cumulative").print_stats(12)
    print("PROFILE_SEQUENTIAL_BEGIN")
    print(output.getvalue(), end="")
    print("PROFILE_SEQUENTIAL_END")


if __name__ == "__main__":
    main()
