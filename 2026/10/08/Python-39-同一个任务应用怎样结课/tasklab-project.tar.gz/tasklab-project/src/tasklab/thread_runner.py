from concurrent.futures import ThreadPoolExecutor
from threading import BoundedSemaphore, Lock

from . import app


class ThreadTaskRunner:
    def __init__(self, store, *, workers=1, backlog=1):
        if type(workers) is not int or type(backlog) is not int or workers < 1 or backlog < 0:
            raise ValueError("workers must be positive and backlog nonnegative")
        self.store = store
        self._slots = BoundedSemaphore(workers + backlog)
        self._lock = Lock()
        self._closed = False
        self._pending = {}
        self._executor = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="tasklab-worker")

    def submit(self, task_id, *, workload=None):
        if not self._slots.acquire(blocking=False):
            raise BufferError("thread queue is full")
        with self._lock:
            if self._closed:
                self._slots.release()
                raise RuntimeError("thread runner is closed")
            try:
                future = self._executor.submit(app.run, self.store, task_id, workload=workload)
            except Exception:
                self._slots.release()
                raise
            self._pending[future] = task_id
        future.add_done_callback(self._finished)
        return future

    def _finished(self, future):
        with self._lock:
            task_id = self._pending.pop(future)
        if future.cancelled():
            app.cancel(self.store, task_id)
        self._slots.release()

    def cancel(self, future):
        with self._lock:
            task_id = self._pending.get(future)
        if task_id is None:
            return {"future_cancelled": False, "request_accepted": False}
        future_cancelled = future.cancel()
        if future_cancelled:
            return {"future_cancelled": True, "request_accepted": True}
        return {"future_cancelled": False, "request_accepted": app.cancel(self.store, task_id)}

    def shutdown(self):
        with self._lock:
            self._closed = True
        self._executor.shutdown(wait=True, cancel_futures=True)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.shutdown()
