import json

from .app import MAX_INPUT_BYTES
from .model import TASK_STATES


class TaskFormatError(ValueError):
    pass


def _unique_fields(pairs):
    fields = dict(pairs)
    if len(fields) != len(pairs):
        raise TaskFormatError("duplicate JSON field")
    return fields


def _reject_constant(value):
    raise TaskFormatError(f"invalid JSON number: {value}")


def decode_task(raw):
    try:
        data = json.loads(raw, object_pairs_hook=_unique_fields, parse_constant=_reject_constant)
    except (ValueError, TypeError, UnicodeError) as error:
        raise TaskFormatError(f"invalid task JSON: {error}") from error
    if type(data) is not dict or set(data) != {
        "version", "id", "kind", "text", "metadata", "state", "result", "error"
    }:
        raise TaskFormatError("unknown or missing task fields")
    if type(data["version"]) is not int or data["version"] != 1:
        raise TaskFormatError("unsupported task version")
    task_id = data["id"]
    if not isinstance(task_id, str) or not task_id.startswith("task-") or not task_id[5:].isdigit():
        raise TaskFormatError("invalid task ID")
    if data["kind"] != "word_count":
        raise TaskFormatError("unknown task kind")
    text = data["text"]
    try:
        text_size = len(text.encode("utf-8")) if isinstance(text, str) else MAX_INPUT_BYTES + 1
    except UnicodeError as error:
        raise TaskFormatError("invalid task text encoding") from error
    if text_size > MAX_INPUT_BYTES:
        raise TaskFormatError("invalid task text")
    metadata = data["metadata"]
    if (type(metadata) is not dict or set(metadata) != {"labels"}
            or type(metadata["labels"]) is not list
            or any(not isinstance(label, str) for label in metadata["labels"])):
        raise TaskFormatError("invalid task labels")
    state, result, error = data["state"], data["result"], data["error"]
    if not isinstance(state, str) or state not in TASK_STATES:
        raise TaskFormatError("invalid task state")
    if result is not None and (type(result) is not dict or any(
        not isinstance(word, str) or type(count) is not int or count < 0
        for word, count in result.items()
    )):
        raise TaskFormatError("invalid task result")
    if error is not None and not isinstance(error, str):
        raise TaskFormatError("invalid task error")
    if ((state == "succeeded") != (result is not None)
            or (state == "failed") != (error is not None)):
        raise TaskFormatError("result or error conflicts with state")
    return task_id, {key: data[key] for key in (
        "kind", "text", "metadata", "state", "result", "error"
    )}


def encode_task(task_id, snapshot):
    document = json.dumps({"version": 1, "id": task_id, **snapshot},
                          ensure_ascii=False, allow_nan=False, sort_keys=True)
    decode_task(document)
    return document
