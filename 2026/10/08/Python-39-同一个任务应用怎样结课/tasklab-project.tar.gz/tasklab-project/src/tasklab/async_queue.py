import asyncio

from . import app
from .async_runner import run_async


class BusyError(Exception):
    pass


class AsyncTaskQueue:
    def __init__(self, store, *, workers=2, waiting=1, wait_event=None):
        if workers < 1 or waiting < 1:
            raise ValueError("workers and waiting must be positive")
        self.store = store
        self._workers_count = workers
        self._queue = asyncio.Queue(maxsize=waiting)
        self._capacity = workers + waiting
        self._wait_event = wait_event
        self._workers = []
        self._admitted = 0
        self._running = 0
        self._accepting = False

    async def start(self):
        if self._workers:
            raise ValueError("queue already started")
        self._accepting = True
        ready = [asyncio.Event() for _ in range(self._workers_count)]
        self._workers = [asyncio.create_task(self._worker(event)) for event in ready]
        await asyncio.gather(*(event.wait() for event in ready))

    def submit_nowait(self, kind, text, *, started_event=None):
        if not self._accepting or self._admitted >= self._capacity or self._queue.full():
            raise BusyError("queue is full or closed")
        task_id = app.submit(self.store, kind, text)
        self._queue.put_nowait((task_id, started_event))
        self._admitted += 1
        return task_id

    def snapshot(self):
        return {"admitted": self._admitted, "running": self._running,
                "queued": self._queue.qsize(), "capacity": self._capacity}

    async def join(self):
        await self._queue.join()

    async def close(self):
        self._accepting = False
        await self.join()
        for _ in self._workers:
            await self._queue.put(None)
        await asyncio.gather(*self._workers)
        self._workers.clear()

    async def _worker(self, ready):
        ready.set()
        while True:
            item = await self._queue.get()
            try:
                if item is None:
                    return
                task_id, started_event = item
                if app.query(self.store, task_id)["state"] == "cancelled":
                    continue
                self._running += 1
                try:
                    await run_async(self.store, task_id, wait_event=self._wait_event,
                                    started_event=started_event)
                except app.TaskExecutionError:
                    pass
                finally:
                    self._running -= 1
            finally:
                if item is not None:
                    self._admitted -= 1
                self._queue.task_done()
