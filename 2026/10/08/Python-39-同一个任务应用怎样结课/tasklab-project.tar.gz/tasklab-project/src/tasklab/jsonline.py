import asyncio
import json
from contextlib import suppress

from . import app
from .async_runner import run_async


class ProtocolError(ValueError):
    pass


def _unique_fields(pairs):
    fields = dict(pairs)
    if len(fields) != len(pairs):
        raise ProtocolError("duplicate field")
    return fields


def _reject_constant(value):
    raise ProtocolError("invalid number")


class LoopbackService:
    def __init__(self, store, *, max_connections=2, max_frame=2048, read_timeout=0.5):
        if max_connections < 1 or max_frame < 1 or read_timeout <= 0:
            raise ValueError("invalid service limits")
        self.store = store
        self.max_frame = max_frame
        self.read_timeout = read_timeout
        self._slots = asyncio.Semaphore(max_connections)
        self._server = None
        self._active = set()
        self._closing = False

    async def start(self):
        if self._server is not None:
            raise ValueError("service already started")
        self._closing = False
        self._server = await asyncio.start_server(self._serve_client, "127.0.0.1", 0,
                                                  limit=self.max_frame + 1, backlog=4)
        return self._server.sockets[0].getsockname()

    async def close(self, *, drain_timeout=1):
        if drain_timeout < 0:
            raise ValueError("drain timeout must be nonnegative")
        server = self._server
        if server is None:
            return 0
        self._server = None
        self._closing = True
        server.close()
        pending = set(self._active)
        if pending:
            _, pending = await asyncio.wait(pending, timeout=drain_timeout)
        cancelled = len(pending)
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        await server.wait_closed()
        return cancelled

    async def _serve_client(self, reader, writer):
        if self._closing:
            writer.close()
            with suppress(ConnectionError):
                await writer.wait_closed()
            return
        current = asyncio.current_task()
        self._active.add(current)
        try:
            await self._handle(reader, writer)
        finally:
            self._active.discard(current)

    def _dispatch(self, request):
        if type(request) is not dict or type(request.get("op")) is not str:
            raise ProtocolError("expected object with op")
        action = request["op"]
        if action == "submit":
            if set(request) != {"op", "kind", "text"}:
                raise ProtocolError("invalid submit fields")
            return {"id": app.submit(self.store, request["kind"], request["text"])}
        if action in {"query", "cancel", "run"}:
            if set(request) != {"op", "id"} or type(request["id"]) is not str:
                raise ProtocolError("invalid task fields")
            if action == "query":
                return {"task": app.query(self.store, request["id"])}
            if action == "cancel":
                return {"accepted": app.cancel(self.store, request["id"]),
                        "task": app.query(self.store, request["id"])}
            return request["id"]
        raise ProtocolError("unknown operation")

    async def _respond(self, writer, response):
        writer.write((json.dumps(response, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8"))
        await asyncio.wait_for(writer.drain(), timeout=self.read_timeout)

    async def _handle(self, reader, writer):
        if self._slots.locked():
            try:
                await self._respond(writer, {"ok": False, "error": "busy"})
            except (ConnectionError, TimeoutError):
                pass
            finally:
                writer.close()
                with suppress(ConnectionError):
                    await writer.wait_closed()
            return
        async with self._slots:
            try:
                try:
                    raw = await asyncio.wait_for(reader.readuntil(b"\n"), self.read_timeout)
                    if len(raw) > self.max_frame:
                        raise ProtocolError("frame too long")
                    request = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_fields,
                                         parse_constant=_reject_constant)
                    response = self._dispatch(request)
                    if request["op"] == "run":
                        result = await run_async(self.store, response)
                        response = {"result": result, "task": app.query(self.store, response)}
                    await self._respond(writer, {"ok": True, **response})
                except asyncio.LimitOverrunError:
                    await self._respond(writer, {"ok": False, "error": "frame too long"})
                except asyncio.IncompleteReadError:
                    await self._respond(writer, {"ok": False, "error": "incomplete frame"})
                except TimeoutError:
                    await self._respond(writer, {"ok": False, "error": "read timeout"})
                except (UnicodeError, ValueError, KeyError, TypeError,
                        app.TaskExecutionError) as error:
                    await self._respond(writer, {"ok": False, "error": str(error)})
            except (ConnectionError, TimeoutError):
                pass
            finally:
                writer.close()
                with suppress(ConnectionError):
                    await writer.wait_closed()
