import json
import sys

from .app import create_store, query, run, submit


def main():
    store = create_store()
    task_id = submit(store, "word_count", "hello hello world")
    if sys.argv[1:] == ["--invalid"]:
        try:
            submit(store, "", "this must not be saved")
        except ValueError as error:
            print(json.dumps({"error": str(error), "task_count": len(store["tasks"])}), file=sys.stderr)
            return 2
        return 1
    if sys.argv[1:]:
        print("usage: python -m tasklab.demo [--invalid]", file=sys.stderr)
        return 2
    run(store, task_id)
    print(json.dumps({"id": task_id, "state": query(store, task_id)["state"], "result": query(store, task_id)["result"]}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
