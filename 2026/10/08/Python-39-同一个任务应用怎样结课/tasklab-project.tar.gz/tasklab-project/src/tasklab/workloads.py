def cpu_work(text, *, iterations):
    if type(iterations) is not int or iterations < 0:
        raise ValueError("iterations must be a nonnegative integer")
    checksum = 0
    for _ in range(iterations):
        for character in text:
            checksum = (checksum * 33 + ord(character)) % 1000000007
    return checksum
