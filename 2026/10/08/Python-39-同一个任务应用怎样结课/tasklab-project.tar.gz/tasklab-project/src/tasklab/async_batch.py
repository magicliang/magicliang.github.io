import asyncio

from .async_runner import run_async


async def run_batch(store, task_ids, *, release_events=None, started_events=None,
                    cleaned_events=None, fail_id=None, timeout_at=None):
    if len(set(task_ids)) != len(task_ids):
        raise ValueError("batch task IDs must be distinct")
    release_events = release_events or {}
    started_events = started_events or {}
    cleaned_events = cleaned_events or {}

    async def worker(task_id):
        try:
            return await run_async(store, task_id, wait_event=release_events.get(task_id),
                                   started_event=started_events.get(task_id),
                                   fail_at="compute" if task_id == fail_id else None)
        finally:
            if task_id in cleaned_events:
                cleaned_events[task_id].set()

    async def execute():
        async with asyncio.TaskGroup() as group:
            tasks = {task_id: group.create_task(worker(task_id)) for task_id in task_ids}
        return {task_id: task.result() for task_id, task in tasks.items()}

    if timeout_at is not None:
        async with asyncio.timeout_at(timeout_at):
            return await execute()
    return await execute()
