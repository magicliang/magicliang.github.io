import argparse
import json
from pathlib import Path

from .app import MAX_INPUT_BYTES, TaskExecutionError
from .database import SQLiteTaskGateway


def main(argv=None):
    parser = argparse.ArgumentParser(description="Persist tasklab jobs in SQLite.")
    parser.add_argument("--db", type=Path, required=True, help="SQLite file path")
    actions = parser.add_subparsers(dest="action", required=True)
    submission = actions.add_parser("submit")
    inputs = submission.add_mutually_exclusive_group(required=True)
    inputs.add_argument("--text")
    inputs.add_argument("--file", type=Path)
    for name in ("run", "query", "cancel"):
        actions.add_parser(name).add_argument("id")
    args = parser.parse_args(argv)

    try:
        gateway = SQLiteTaskGateway(args.db)
        if args.action == "submit":
            if args.file is not None:
                with args.file.open("rb") as source:
                    raw_bytes = source.read(MAX_INPUT_BYTES + 1)
                text = raw_bytes.decode("utf-8", errors="strict")
            else:
                text = args.text
            task_id = gateway.submit("word_count", text)
        else:
            task_id = args.id
            if args.action == "run":
                gateway.run(task_id)
            elif args.action == "cancel":
                accepted = gateway.cancel(task_id)
        response = {"id": task_id, **gateway.query(task_id)}
        if args.action == "cancel":
            response["accepted"] = accepted
    except TaskExecutionError as error:
        parser.exit(1, f"{error}\n")
    except (OSError, ValueError, KeyError, UnicodeError) as error:
        parser.error(str(error))
    print(json.dumps(response, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
