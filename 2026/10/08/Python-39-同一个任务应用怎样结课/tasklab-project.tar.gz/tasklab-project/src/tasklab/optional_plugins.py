from functools import wraps
from typing import ParamSpec, Protocol, TypeVar

Parameters = ParamSpec('Parameters')
ReturnValue = TypeVar('ReturnValue', covariant=True)


class Processor(Protocol[Parameters, ReturnValue]):
    def __call__(self, *args: Parameters.args,
                 **kwargs: Parameters.kwargs) -> ReturnValue: ...


def observed(processor: Processor[Parameters, ReturnValue],
             events: list[str]) -> Processor[Parameters, ReturnValue]:
    @wraps(processor)
    def wrapper(*args: Parameters.args, **kwargs: Parameters.kwargs) -> ReturnValue:
        events.append('entered')
        try:
            return processor(*args, **kwargs)
        finally:
            events.append('exited')
    return wrapper
