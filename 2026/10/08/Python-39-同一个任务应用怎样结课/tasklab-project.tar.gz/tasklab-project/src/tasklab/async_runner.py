import asyncio
from itertools import chain

from . import app
from .pipeline import word_batches
from .workloads import cpu_work


async def run_async(store, task_id, *, wait_event=None, started_event=None,
                    iterations=0, fail_at=None):
    if fail_at not in (None, "compute"):
        raise ValueError("unknown fault injection")
    task = app._start(store, task_id)
    try:
        if started_event is not None:
            started_event.set()
        if wait_event is not None:
            await wait_event.wait()
        if fail_at == "compute":
            raise RuntimeError("synthetic computation failure")
        if iterations:
            cpu_work(task.definition.text, iterations=iterations)
        counts = app.count_words(chain.from_iterable(word_batches((task.definition.text,))))
    except asyncio.CancelledError:
        with task._lock:
            task.state = "cancelled"
        raise
    except Exception as error:
        app._fail(task, error)
        raise app.TaskExecutionError(f"task {task_id} failed") from error
    return app._complete(task, counts)
