from .app import cancel, query, run, submit


def dispatch(store, operation, **payload):
    if not isinstance(operation, str):
        raise TypeError("operation must be a string")
    match operation:
        case "submit":
            if set(payload) not in ({"kind", "text"}, {"kind", "text", "metadata"}):
                raise TypeError("submit expects kind, text, optional metadata")
            return submit(store, payload["kind"], payload["text"], metadata=payload.get("metadata"))
        case "run":
            if set(payload) != {"task_id"}:
                raise TypeError("run expects task_id")
            return run(store, payload["task_id"])
        case "query":
            if set(payload) != {"task_id"}:
                raise TypeError("query expects task_id")
            return query(store, payload["task_id"])
        case "cancel":
            if set(payload) != {"task_id"}:
                raise TypeError("cancel expects task_id")
            return cancel(store, payload["task_id"])
        case _:
            raise ValueError("unknown operation")
