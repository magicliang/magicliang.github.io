from itertools import batched

from .words import iter_words


def word_batches(chunks, *, skip=(), size=64):
    if size < 1:
        raise ValueError("batch size must be positive")
    skipped = frozenset(skip)
    words = (word for word in iter_words(chunks) if word not in skipped)
    return batched(words, size)
