from concurrent.futures import ProcessPoolExecutor
from multiprocessing import get_context
import os
import sys
from threading import Lock

from . import app
from .words import iter_words
from .workloads import cpu_work


_worker_pid = None


def _initialize_worker():
    global _worker_pid
    _worker_pid = os.getpid()


def _execute(text, iterations):
    if _worker_pid != os.getpid():
        raise RuntimeError("process worker was not initialized")
    local = app.create_store()
    task_id = app.submit(local, "word_count", text)
    result = app.run(local, task_id, workload=lambda data: cpu_work(data, iterations=iterations))
    return {"pid": _worker_pid, "interpreter": sys.executable,
            "result": result, "state": app.query(local, task_id)["state"]}


class ProcessTaskRunner:
    def __init__(self, *, workers=2):
        if type(workers) is not int or workers < 1:
            raise ValueError("workers must be positive")
        self._pool = ProcessPoolExecutor(max_workers=workers, mp_context=get_context("spawn"),
                                         initializer=_initialize_worker)
        self._lock = Lock()
        self.traces = []

    def run(self, store, task_id, *, iterations=20000):
        def work(text):
            worker = self._pool.submit(_execute, text, iterations).result(timeout=30)
            if worker["result"] != app.count_words(iter_words((text,))):
                raise ValueError("process result differs from sequential task")
            with self._lock:
                self.traces.append(worker)

        return app.run(store, task_id, workload=work)

    def shutdown(self):
        self._pool.shutdown(wait=True, cancel_futures=True)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.shutdown()
