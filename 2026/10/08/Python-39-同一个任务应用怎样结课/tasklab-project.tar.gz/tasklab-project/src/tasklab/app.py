from itertools import chain
from time import monotonic

from .model import Task, TaskResult
from .pipeline import word_batches

MAX_INPUT_BYTES = 1024


class TaskExecutionError(Exception):
    pass


def create_store():
    return {"next_id": 1, "tasks": {}}


def task_ids(store):
    return tuple(store["tasks"])


def submit(store, kind, text, *, metadata=None):
    if kind != "word_count":
        raise ValueError("only word_count tasks are supported")
    if not isinstance(text, str):
        raise TypeError("text must be a string")
    if len(text.encode("utf-8")) > MAX_INPUT_BYTES:
        raise ValueError("text exceeds 1024 UTF-8 bytes")
    if metadata is None:
        metadata = {"labels": []}
    if (not isinstance(metadata, dict) or set(metadata) != {"labels"}
            or not isinstance(metadata["labels"], list)
            or any(not isinstance(label, str) for label in metadata["labels"])):
        raise ValueError("metadata must contain a list of string labels")
    task_id = f"task-{store['next_id']:04d}"
    store["tasks"][task_id] = Task(kind, text, metadata)
    store["next_id"] += 1
    return task_id


def submit_bytes(store, kind, raw_bytes, *, metadata=None):
    if not isinstance(raw_bytes, bytes):
        raise TypeError("raw_bytes must be bytes")
    if len(raw_bytes) > MAX_INPUT_BYTES:
        raise ValueError("text exceeds 1024 UTF-8 bytes")
    text = raw_bytes.decode("utf-8", errors="strict")
    return submit(store, kind, text, metadata=metadata)


def query(store, task_id):
    return store["tasks"][task_id].snapshot()


def count_words(words):
    counts = {}
    for word in words:
        counts[word] = counts.get(word, 0) + 1
    return counts


def _start(store, task_id, *, clock=monotonic, deadline=None):
    task = store["tasks"][task_id]
    with task._lock:
        if task.state != "queued":
            raise ValueError("only queued tasks can run")
        if deadline is not None and clock() >= deadline:
            raise TimeoutError("task deadline exceeded before start")
        task.state = "running"
    return task


def _fail(task, error):
    with task._lock:
        task.state = "failed"
        task.error = f"{type(error).__name__}: {error}"


def _complete(task, counts):
    with task._lock:
        if task.state == "cancel_requested":
            task.state = "cancelled"
            return None
        task.result = TaskResult(counts)
        task.state = "succeeded"
    return counts.copy()


def run(store, task_id, *, fail_at=None, clock=monotonic, deadline=None, workload=None):
    if fail_at not in (None, "compute"):
        raise ValueError("unknown fault injection")
    task = _start(store, task_id, clock=clock, deadline=deadline)
    try:
        if workload is not None:
            workload(task.definition.text)
        if fail_at == "compute":
            try:
                int("synthetic-not-a-number")
            except ValueError as cause:
                raise RuntimeError("synthetic computation failure") from cause
        counts = count_words(chain.from_iterable(word_batches((task.definition.text,))))
        if deadline is not None and clock() >= deadline:
            raise TimeoutError("task deadline exceeded after compute")
    except Exception as error:
        _fail(task, error)
        raise TaskExecutionError(f"task {task_id} failed") from error
    return _complete(task, counts)


def cancel(store, task_id):
    task = store["tasks"][task_id]
    with task._lock:
        if task.state == "queued":
            task.state = "cancelled"
            return True
        if task.state == "running":
            task.state = "cancel_requested"
            return True
        return task.state == "cancel_requested"
