def iter_words(chunks):
    letters = []
    for chunk in chunks:
        for character in chunk:
            if character.isspace():
                if letters:
                    yield "".join(letters).lower()
                    letters.clear()
            else:
                letters.append(character)
    if letters:
        yield "".join(letters).lower()
