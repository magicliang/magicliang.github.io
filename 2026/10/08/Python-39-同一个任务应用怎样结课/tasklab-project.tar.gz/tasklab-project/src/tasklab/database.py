from contextlib import closing
import json
from pathlib import Path
import sqlite3
from time import monotonic

from . import app
from .model import Task
from .serialization import decode_task, encode_task


class SQLiteTaskGateway:
    def __init__(self, path):
        self.path = Path(path)
        with closing(self._connect()) as connection:
            with connection:
                connection.execute("""CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    version INTEGER NOT NULL,
                    kind TEXT NOT NULL,
                    text TEXT NOT NULL,
                    labels TEXT NOT NULL,
                    state TEXT NOT NULL,
                    result TEXT,
                    error TEXT
                )""")

    def _connect(self):
        connection = sqlite3.connect(self.path, timeout=5)
        connection.row_factory = sqlite3.Row
        return connection

    @staticmethod
    def _number(task_id):
        if not isinstance(task_id, str) or not task_id.startswith("task-"):
            raise KeyError(task_id)
        try:
            number = int(task_id[5:])
        except ValueError as error:
            raise KeyError(task_id) from error
        if number < 1 or f"task-{number:04d}" != task_id:
            raise KeyError(task_id)
        return number

    @staticmethod
    def _snapshot(row):
        task_id = f"task-{row['id']:04d}"
        snapshot = {
            "kind": row["kind"], "text": row["text"],
            "metadata": {"labels": json.loads(row["labels"])},
            "state": row["state"],
            "result": None if row["result"] is None else json.loads(row["result"]),
            "error": row["error"],
        }
        return decode_task(encode_task(task_id, snapshot))[1]

    def _get(self, connection, task_id):
        row = connection.execute("SELECT * FROM tasks WHERE id = ?", (self._number(task_id),)).fetchone()
        if row is None:
            raise KeyError(task_id)
        return row

    def submit(self, kind, text, *, metadata=None):
        store = app.create_store()
        local_id = app.submit(store, kind, text, metadata=metadata)
        snapshot = app.query(store, local_id)
        with closing(self._connect()) as connection:
            with connection:
                cursor = connection.execute(
                    "INSERT INTO tasks (version, kind, text, labels, state) VALUES (1, ?, ?, ?, ?)",
                    (snapshot["kind"], snapshot["text"], json.dumps(snapshot["metadata"]["labels"]),
                     snapshot["state"]),
                )
                task_id = f"task-{cursor.lastrowid:04d}"
        return task_id

    def query(self, task_id):
        with closing(self._connect()) as connection:
            return self._snapshot(self._get(connection, task_id))

    def cancel(self, task_id):
        with closing(self._connect()) as connection:
            with connection:
                connection.execute("BEGIN IMMEDIATE")
                state = self._snapshot(self._get(connection, task_id))["state"]
                if state == "queued":
                    connection.execute("UPDATE tasks SET state = 'cancelled' WHERE id = ?",
                                       (self._number(task_id),))
                    return True
                if state == "running":
                    connection.execute("UPDATE tasks SET state = 'cancel_requested' WHERE id = ?",
                                       (self._number(task_id),))
                    return True
                return state == "cancel_requested"

    def claim(self, task_id):
        with closing(self._connect()) as connection:
            with connection:
                connection.execute("BEGIN IMMEDIATE")
                if self._snapshot(self._get(connection, task_id))["state"] != "queued":
                    raise ValueError("only queued tasks can be claimed")
                connection.execute("UPDATE tasks SET state = 'running' WHERE id = ?",
                                   (self._number(task_id),))

    def recover_running(self):
        with closing(self._connect()) as connection:
            with connection:
                connection.execute("BEGIN IMMEDIATE")
                rows = connection.execute(
                    "SELECT id FROM tasks WHERE state IN ('running', 'cancel_requested')"
                ).fetchall()
                connection.execute("""UPDATE tasks SET state = 'failed',
                    error = 'Interrupted: result unknown; inspect external side effects'
                    WHERE state IN ('running', 'cancel_requested')""")
                return tuple(f"task-{row['id']:04d}" for row in rows)

    def run(self, task_id, *, fail_at=None, clock=monotonic, deadline=None, workload=None):
        if fail_at not in (None, "after_state", "compute"):
            raise ValueError("unknown fault injection")
        failure = None
        result = None
        with closing(self._connect()) as connection:
            with connection:
                connection.execute("BEGIN IMMEDIATE")
                snapshot = self._snapshot(self._get(connection, task_id))
                if snapshot["state"] != "queued":
                    raise ValueError("only queued tasks can run")
                task = Task(snapshot["kind"], snapshot["text"], snapshot["metadata"])
                store = {"next_id": 1, "tasks": {task_id: task}}
                try:
                    result = app.run(store, task_id, fail_at="compute" if fail_at == "compute" else None,
                                     clock=clock, deadline=deadline, workload=workload)
                except app.TaskExecutionError as error:
                    failure = error
                    connection.execute("UPDATE tasks SET state = 'failed', error = ? WHERE id = ?",
                                       (task.error, self._number(task_id)))
                else:
                    connection.execute("UPDATE tasks SET state = 'running' WHERE id = ?",
                                       (self._number(task_id),))
                    if fail_at == "after_state":
                        raise RuntimeError("synthetic failure between state and result")
                    connection.execute("UPDATE tasks SET result = ? WHERE id = ?",
                                       (json.dumps(result, ensure_ascii=False), self._number(task_id)))
                    connection.execute("UPDATE tasks SET state = 'succeeded' WHERE id = ?",
                                       (self._number(task_id),))
        if failure is not None:
            raise failure
        return result
