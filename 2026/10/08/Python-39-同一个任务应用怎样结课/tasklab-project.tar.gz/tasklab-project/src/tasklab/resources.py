from contextlib import contextmanager
from pathlib import Path

from .app import count_words
from .words import iter_words


@contextmanager
def open_word_file(path):
    with Path(path).open("r", encoding="utf-8", errors="strict") as source:
        words = iter_words(source)
        try:
            yield words, source
        finally:
            words.close()


def count_file(path):
    with open_word_file(path) as (words, source):
        return count_words(words)
