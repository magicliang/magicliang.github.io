from dataclasses import dataclass, field
from threading import RLock


TASK_STATES = frozenset({"queued", "running", "succeeded", "failed", "cancel_requested", "cancelled"})


@dataclass(frozen=True)
class TaskDefinition:
    kind: str
    text: str
    labels: tuple[str, ...] = ()


@dataclass
class TaskResult:
    counts: dict[str, int] = field(default_factory=dict)

    def __len__(self):
        return len(self.counts)

    @property
    def total(self):
        return sum(self.counts.values())


class Task:
    def __init__(self, kind, text, metadata):
        self._lock = RLock()
        self.definition = TaskDefinition(kind, text, tuple(metadata["labels"]))
        self._state = "queued"
        self.result = None
        self.error = None

    @property
    def state(self):
        with self._lock:
            return self._state

    @state.setter
    def state(self, value):
        with self._lock:
            if value not in TASK_STATES:
                raise ValueError("unknown task state")
            self._state = value

    def snapshot(self):
        with self._lock:
            if self.state not in TASK_STATES:
                raise ValueError("unknown task state")
            return {
                "kind": self.definition.kind,
                "text": self.definition.text,
                "metadata": {"labels": list(self.definition.labels)},
                "state": self.state,
                "result": None if self.result is None else self.result.counts.copy(),
                "error": self.error,
            }
