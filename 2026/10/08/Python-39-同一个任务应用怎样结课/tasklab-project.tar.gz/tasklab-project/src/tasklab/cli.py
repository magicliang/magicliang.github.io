import argparse
import json
from pathlib import Path

from .app import MAX_INPUT_BYTES, create_store, query, run, submit, submit_bytes


def main(argv=None):
    parser = argparse.ArgumentParser(description="Run one task in memory (no persistence yet).")
    inputs = parser.add_mutually_exclusive_group(required=True)
    inputs.add_argument("--text", help="UTF-8 text to count")
    inputs.add_argument("--file", type=Path, help="UTF-8 input file")
    parser.add_argument("--kind", default="word_count", help="task kind (word_count only)")
    args = parser.parse_args(argv)

    store = create_store()
    try:
        if args.file is not None:
            with args.file.open("rb") as source:
                raw_bytes = source.read(MAX_INPUT_BYTES + 1)
            task_id = submit_bytes(store, args.kind, raw_bytes)
        else:
            task_id = submit(store, args.kind, args.text)
    except (OSError, ValueError, TypeError, UnicodeError) as error:
        parser.error(str(error))

    run(store, task_id)
    print(json.dumps({"id": task_id, **query(store, task_id)}, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
