def suffix_callbacks(suffixes):
    return [lambda text, suffix=suffix: f"{text} {suffix}" for suffix in suffixes]
