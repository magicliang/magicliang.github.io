from . import app


class MemoryTaskGateway:
    def __init__(self) -> None:
        self.store = app.create_store()

    def submit(self, kind: str, text: str) -> str:
        return app.submit(self.store, kind, text)

    def run(self, task_id: str) -> dict[str, int] | None:
        return app.run(self.store, task_id)

    def query(self, task_id: str) -> dict[str, object]:
        return app.query(self.store, task_id)

    def cancel(self, task_id: str) -> bool:
        return app.cancel(self.store, task_id)
