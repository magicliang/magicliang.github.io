from functools import wraps
from time import perf_counter_ns


def timed(records):
    def decorate(function):
        @wraps(function)
        def wrapper(*args, **kwargs):
            started = perf_counter_ns()
            succeeded = False
            try:
                result = function(*args, **kwargs)
                succeeded = True
                return result
            finally:
                records.append({
                    "name": function.__name__,
                    "succeeded": succeeded,
                    "elapsed_ns": perf_counter_ns() - started,
                })

        return wrapper

    return decorate
