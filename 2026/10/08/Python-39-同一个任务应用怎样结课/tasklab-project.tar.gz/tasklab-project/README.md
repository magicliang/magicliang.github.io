# Tasklab：单一累计实验

主线第 00 章起使用人工生成的文本与白名单 `word_count` 任务。`submit` 只接受任务定义，`run` 执行已排队任务，`query` 返回快照，`cancel` 区分请求与任务状态；03 增加可选的 `metadata={"labels": [...]}` 并在提交和查询边界复制受支持的嵌套列表。04 增加严格的 UTF-8 字节入口和 1024 字节的文本限制。06 的受信任内部回调先转换文本再提交，不从任务输入中解析或执行代码。08 的任务 ID 集合为可重读的快照，09–10 的词频计算使用流式词元和批处理；12–15 的任务定义、结果与失败状态仍保留原查询契约，16 用文件作用域核对资源关闭。目前仅有进程内顺序执行，尚无数据库、CLI、并发或网络服务。

17 加入单次执行的 `argparse` CLI：`--text` / `--file` 输入在本进程提交并运行任务，成功只向 stdout 写 JSON，输入错误只向 stderr 写诊断且以 2 退出。CLI 未持久化，不能跨进程查询；前段的“尚无 CLI”指截至 16 的状态。18 增加委托给同一应用的 `TaskGateway` 类型协议，以 Pyright 1.1.404 验证静态正反例，未把 JSON 的动态内容误认为已通过输入校验。19 将内存适配器拆到 `storage.py`，提供 `python -m tasklab` 包入口，验证导入不会创建任务；尚无 SQLite。

20 加入版本 1 的任务 JSON 快照；`encode_task`/`decode_task` 不构造任务实例、不自动执行和落盘。解码必须通过字段、类型、状态关系及编码校验。21 增加 SQLite 仓储与 `python -m tasklab.db_cli --db PATH`（`submit`、`run`、`query`、`cancel`），不同进程可以查询已提交任务，注入写回故障能回滚状态及结果；并发运行、遗留任务恢复和在线迁移均未实现。

22 将同一条取消不变量在内存、真实 SQLite 重开后分别断言，并用受控变异验证测试能捕获“接受取消却不更新状态”。变异测试组故意失败，包裹脚本核实失败后退出 0，原始输出保留在 `evidence/22/`。

23 为顺序任务和 SQLite 仓储加入可注入单调时钟与 deadline，固定开始前/计算后两个检查点；超时不等于抢占执行，实际文件及数据库测试仍然运行。

24 使用仓库外干净 venv 验证源码、包名遮蔽和全部累计测试；系统 CPython 无 `ensurepip`，使用 `--without-pip` 建 venv，并记录 PyPA 引导脚本 SHA-256 与独立安装的 pip 25.2。Python 运行依赖声明为空；源码通过 `PYTHONPATH=src` 运行。25 用 `build` 1.3.0、`setuptools` 80.9.0、`wheel` 0.45.1 构建 wheel/sdist；构建工具和传递依赖的 pip 哈希锁为 `build-requirements.lock`，制品在 `artifacts/`，外部无 pip 的干净 venv 只安装 wheel 并运行生成的 `tasklab` 命令。没有发布 PyPI，也未声称安装 sdist。

26 对同一制品核对 wheel/sdist 元数据、SHA-256 与 Python 目标解析（3.12 候选接受、3.11 候选拒绝），在已装 wheel 的 CPython 3.12.3 上验证中文输入与失败退出。3.11 运行测试、其他架构和发布到任何索引均 `NOT_RUN`，不把 `py3-none-any` 当作无条件兼容声明。

27 在同一 `app.run` 与 SQLite 适配器入口加入可选工作负载钩子：`cpu_work` 是纯 Python 可调迭代，`Event` 可重复固定等待检查点。原有业务输出保持一致；`artifacts/` 暂为 25 冻结的旧制品，27 的代码变动**尚未**重建 wheel 或重装，不能用 25 的干净安装证据证明此后增量。

28 在 `experiments/28_claims.py` 用 Barrier 使两个线程在读取 queued 后都领取同一任务，进程内 Lock 和现有 SQLite 事务分别只允许一次；错误领取函数只在实验中，真实执行仍由原任务入口完成。普通构建的结果不可代替 free-threaded 模式实测。

29 加入 `ThreadTaskRunner`：用线程池与容量信号量同时限制运行和排队数量，任务锁保护共享状态快照；未启动的 Future 可立即取消，运行中 Future 仅能记录业务取消请求，必须等工作单元退出。退出池等待工作者并取消剩余排队任务。此增量仍是源码实验，25 的 wheel 尚未更新。

30 加入 `ProcessTaskRunner`，明确使用 `spawn` 与进程内独立初始化；相同词频/CPU 输入与顺序基线一致，不可序列化参数会在 `Future.result()` 的异常链中暴露。此增量同样没有重建 25 的 wheel；强制终止后是否清理尚未验收。

31–35 增加 `run_async`、`TaskGroup` 批次、有界 `AsyncTaskQueue`、回环 JSON 行服务、受控停机与 SQLite 遗留 `running` 状态恢复。32 用事件确认一个故障任务会取消两个已开始但仍等待的兄弟任务，并等待三者退出路径完成；33 用两个工作者加一个等待槽拒绝第四项；34 区分提交确认与实际结果；35 在关闭开始时设置接入门禁，迟到 handler 只能关闭连接，不能提交新任务，同时分别保留未提交事务强杀回滚与已提交 `running` 的恢复记录；外部副作用没有恰好一次保证。

36–38 固定四种执行方式的词频/CPU 输入及重复采样，分进程测流式/全量分配与 RSS；按 00 源码包 SHA 核对 CPython 3.12 的字节码执行循环与 GIL 符号。另在仓库外自建 CPython 3.13.9 free-threaded，并分别检查构建标志、运行时 GIL 开关及兼容/旧扩展导入；该构建缺 `_sqlite3`，全套测试失败，不能冒充普通基线。39 的干净 wheel 与结课重放以 `RUN.md`、`VERSIONS.md` 及本计划逐篇验收行所列的真实新证据为准；25 的旧 `artifacts/` 仍不代表累计版本。

在本目录执行；默认使用 `PYTHON` 环境变量，未设置时回落到 `python3`。若要复跑历史 Ubuntu/CPython 3.12.3 证据，显式设置 `PYTHON` 为对应解释器路径：

```sh
PYTHON=${PYTHON:-python3}
PYTHONPATH=src "$PYTHON" -m unittest discover -s tests -v
PYTHONPATH=src "$PYTHON" -m tasklab.demo
PYTHONPATH=src "$PYTHON" -m tasklab.demo --invalid
PYTHONPATH=src "$PYTHON" -m tasklab.cli --text 'One two one'
PYTHONPATH=src "$PYTHON" -m tasklab.db_cli --db /tmp/tasklab-example.sqlite submit --text 'One two one'
```

第三条命令按设计以状态码 2 退出，不创建非法任务。原始输出和退出码见 `evidence/00/`。`pyproject.toml` 仅声明项目元数据与直接运行依赖；尚未选择构建前端/后端、解析锁工具或静态检查器。没有外部运行依赖并不等于已经验证了 wheel 安装。

页面局部验收使用仓库已安装的 Hexo 依赖和 Node v22.23.2，传入仓库外**不存在**的临时输出目录：`sh tools/build_selected_pages.sh /tmp/tasklab-pages-new`。它仅复制本系列的正文及导航到临时目录，沿用当前主题/config，并实际生成页面、核对每篇导航链接和引用的 SVG。00、07、10、16 的 `pages.log` 分别记录各次累计页面；全站构建尚未通过，不用局部生成冒充全站成功。

历史冻结基线为 Ubuntu 包提供的 CPython 3.12.3（`python3.12-minimal` 版本 `3.12.3-1ubuntu0.17`）。上游对应 tag 为 `v3.12.3`、commit `f6650f9ad73359051f3e558c2431a109bc016664`；Ubuntu 包含额外补丁，精确源码入口是 Ubuntu 同版本 `.dsc` 指向的原始源码和补丁包（两份压缩包 SHA-256 均已下载校验）。不能将上游 commit 当成安装二进制的全部源码。包版本、来源哈希、二进制哈希、配置、平台、SQLite 和 GIL 证据保存在 00 的 `environment.txt`；源码篇必须以该版本的真实文件及符号核对实现。本次 completion 复跑在 macOS/Python 3.14.4 上补充了当前 RSS 与峰值 RSS 的平台口径，旧 Ubuntu 观察不能冒充本次结果。
