# 历史基线与本次重放的实际版本

2026-10-12 当前结果在 `evidence/completion/`，以下旧 Ubuntu 构建是留存历史，不是当前 macOS 的二进制。

| 本次环境 | 实际版本与依据 |
|---|---|
| 普通构建 | macOS arm64 CPython 3.12.3，Clang 17.0.6；完整 `sys.version`、`CONFIG_ARGS`、二进制 SHA、SQLite 版本见 `acceptance/cpython-environment.stdout` |
| free-threaded | macOS arm64 CPython 3.13.9，Clang 21.1.4；`Py_GIL_DISABLED=1`、初始 GIL false、SQLite 3.50.4；见 `acceptance/freethreaded-environment.stdout`，不代验旧缺扩展构建 |
| PyPy | 官方 PyPy 8.0.0、Python 3.12.14、macOS arm64；发布归档 SHA 936ee357126058e43b374ec055495127c9187e2026144b48dca09cc2dcb9b443；安装业务合同通过，全套失败与范围见 `acceptance/pypy-tests.stderr` |
| 构建与可选依赖 | 主线无运行依赖；构建按 `build-requirements.lock` 哈希安装。可选 Starlette 0.46.2、Uvicorn 0.34.2、HTTPX 0.28.1、NumPy 1.26.4 及全部传递依赖按 `tools/optional-requirements.lock` 哈希安装，实际冻结见 `environment/` |
| 静态与源码参考 | Pyright 1.1.404；四个 CPython 3.12.3 参考文件按固定上游 commit 下载并核对原哈希，见 `additional/source-provenance.json`。这些文件不证明 managed binary 的完整下游源码来源。|

- 普通基线：`/usr/bin/python3.12`，CPython 3.12.3，Ubuntu `python3.12-minimal 3.12.3-1ubuntu0.17`，GCC 13.3.0，Linux x86_64，`Py_GIL_DISABLED=None`。上游 tag `v3.12.3` commit `f6650f9ad73359051f3e558c2431a109bc016664`，Ubuntu `.dsc` 和两归档哈希见 `evidence/00/20261007-baseline/environment.txt`；本机普通二进制 SHA-256 `e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f`。SQLite 3.45.1。
- 源码说明：Ubuntu `3.12.3-1ubuntu0.17` 实际源包通过 `dpkg-source -x` 解包；第 38 篇核对执行循环、生成指令、GIL 相关四个文件与上游原始归档一致，不推断其他文件一致。字节码与实现观察只适用于这个基线。
- 构建前端/后端：`build==1.3.0` / `setuptools.build_meta` (`setuptools==80.9.0`)、`wheel==0.45.1`；构建环境 pip 25.2，传递 `packaging==26.3`、`pyproject_hooks==1.3.3`，`build-requirements.lock` 中钉死轮子 SHA-256。任务应用 `dependencies=[]`；声明范围、锁解析、已安装环境分开记录。Pyright 1.1.404 的静态检查证据在 18。制品未发布。
- free-threaded 补充：仓库外从 Python.org `Python-3.13.9.tar.xz` 构建 `--disable-gil`，源码 tag commit `8183fa5e3f78ca6ab862de7fb8b14f3d929421e0`，归档 SHA-256 `ed5ef34cda36cfa2f3a340f07cac7e7814f91c7f3c411f6d3562323a866c5c66`，二进制 SHA-256 `7b2529b42b4ce47282b0681d12ca5f8b9c9315da29a9d8ada5f9f35cb82208dc`。`Py_GIL_DISABLED=1` 且运行时初始关闭；`_json` 导入后仍关闭，自编无兼容声明的 C 扩展导入时警告并启用 GIL。此手工构建缺 `_sqlite3` 等扩展；全套 88 测试报 4 导入错误和 1 连带失败，不能记全绿。
- Hexo 隔离及第 39 篇全站页面的 Node：`/opt/cloudcli/node/bin/node` v22.16.0；全站仓库外生成 exit=0，Python 40 篇导航/图片/归档检验成功，非 Python 正文仍有 LaTeX Unicode 警告。正文以 Python 3.12 文档分支为语义参考，3.13 free-threading 指南仅用于补充构建对照。
