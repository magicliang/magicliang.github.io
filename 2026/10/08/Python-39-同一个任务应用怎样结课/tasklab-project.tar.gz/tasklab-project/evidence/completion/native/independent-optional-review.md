# Python 可选实验独立短审查（E01/E02/E04/E06/E08）

审查时间：2026-10-12。范围只覆盖当前 root 中的 E01、E02、E04、E06、E08 正文、实现与现有证据；E05 未纳入，因为 discovery 分支仍在修改。本文不修改被审查文件。

## 结论

- E01：通过本轮只读核对。`source/_posts/2026-10-08-Python-E01-描述符和元类何时值得使用.md:20` 声明主线 `Task.state` 的 setter 在 `RLock` 下校验并更新；`examples/python-language/experiments/E01_descriptor.py:12`、`:18` 的候选描述符在 `instance._lock` 下读写。`examples/python-language/evidence/completion/acceptance/installed-E01_descriptor.stdout` 记录错误类型、数据描述符遮蔽实例字典、动态赋值不自动触发 `__set_name__`。未发现锁/描述符正文与实验不一致；限制是该实验没有做并发压力测试，正文也没有把它声明成并发压力证据。
- E02：通过本轮只读核对。`source/_posts/2026-10-08-Python-E02-泛型协议怎样表达插件边界.md:41` 区分 Pyright 静态负例和脚本运行负例；`:43` 明确类型提示不是运行时输入校验。现有证据路径记录静态正反例与 `TypeError`，正文未把注解写成运行时校验。
- E04：通过本轮只读核对。`source/_posts/2026-10-09-Python-E04-换解释器后哪些结论失效.md:14` 写明当前 completion 基线为 CPython 3.12.3、free-threaded CPython 3.13.9、macOS arm64 PyPy 8.0.0；`:24` 披露 PyPy 全套仍有 2 失败、1 跳过。正文没有再沿用旧 Ubuntu/PyPy 失败叙述作为当前事实。
- E06：通过本轮只读核对。`source/_posts/2026-10-09-Python-E06-向量化何时减少-Python-层成本.md:20` 写明输入与结果断言；`:28` 写明 2 次暖机、7 组交错样本且每次校验；`:30` 写明峰值 RSS 是包含解释器和 NumPy 导入的新进程范围。`examples/python-language/evidence/completion/additional/E06-vector.stdout` 中 `order` 为 `alternating`，scalar/vector 各 7 个样本，`memory.*.peak_rss_bytes`、`raw_nbytes`、`selected_nbytes`、`view_owndata=false`、`selected_owndata=true` 均存在。空白域风险未发现新增缺口：当前实现只接受 `a` 到 `z` 单字节词，正文没有把它泛化成任意文本向量化器。

## 发现

### P2 — E08 wheel RECORD 审计缺少路径白名单或路径形态限制

- 位置：`examples/python-language/experiments/E08_audit.py:38-47`；相关正文为 `source/_posts/2026-10-09-Python-E08-如何审计依赖与不可信输入.md:32`。
- 错误主张或缺口：正文报告 `RECORD_valid=true`，当前脚本确实校验每个 RECORD 条目的 digest 和 size，但没有校验 RECORD 条目名必须是安全的相对 POSIX 路径，也没有限制到预期前缀集合。
- 当前实现：`inspect_wheel()` 从 wheel 中找到 `*.dist-info/RECORD` 后逐行 `archive.read(name)`，校验 `sha256` 和长度；对 `name` 本身没有拒绝绝对路径、`..`、空路径组件、反斜杠、重复条目或非预期前缀。
- 实际影响：脚本不会解压这些路径，因而这不是当前运行时目录穿越；但它把“RECORD digest/size 正确”报告成 `RECORD_valid=true`，不能证明 wheel 内容清单满足安全路径契约。若后续读者把该字段理解为完整 RECORD 安全审计，会高估验收强度。
- 最小修复建议：在 `inspect_wheel()` 遍历 RECORD 时加入 `PurePosixPath(name)` 级别检查：拒绝绝对路径、`..`、空组件、反斜杠和重复条目；再按当前 wheel 契约白名单限制为 `tasklab/` 与 `tasklab-0.1.0.dist-info/` 等预期前缀，并比较 RECORD 条目集合与 `archive.namelist()`，除 RECORD 自身的空 digest 行外不得遗漏或多出。

