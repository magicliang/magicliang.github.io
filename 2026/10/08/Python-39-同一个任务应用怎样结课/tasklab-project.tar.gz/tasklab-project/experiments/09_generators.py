import json

from tasklab import create_store, run, submit
from tasklab.words import iter_words


def main():
    read = []

    def chunks():
        for chunk in ("One ", "two ", "one"):
            read.append(chunk)
            yield chunk

    words = iter_words(chunks())
    before_next = list(read)
    first = next(words)
    after_next = list(read)
    remaining = list(words)
    store = create_store()
    task_id = submit(store, "word_count", "One two one")
    result = run(store, task_id)
    print(json.dumps({
        "before_next": before_next,
        "first": first,
        "after_next": after_next,
        "remaining": remaining,
        "result": result,
        "baseline": {"one": 2, "two": 1},
    }, sort_keys=True))


if __name__ == "__main__":
    main()
