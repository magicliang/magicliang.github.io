import json
import os
from pathlib import Path
import subprocess
import sys


root = Path(__file__).resolve().parents[1]
environment = os.environ.copy()
environment["PYTHONPATH"] = str(root / "src")


def invoke(name, command, *, expected_exit):
    outcome = subprocess.run(command, env=environment, capture_output=True, text=True, check=False)
    print(json.dumps({"case": name, "exit": outcome.returncode, "stdout": outcome.stdout,
                      "stderr": outcome.stderr}, ensure_ascii=False))
    assert outcome.returncode == expected_exit
    return outcome


import_code = (
    "import tasklab.app as app; "
    "app.create_store = lambda: (_ for _ in ()).throw(AssertionError('eager task')); "
    "import tasklab.cli, tasklab.storage; "
    "import sys; "
    "print('cached:', tasklab.cli is sys.modules['tasklab.cli'])"
)
imported = invoke("import_only", [sys.executable, "-c", import_code], expected_exit=0)
assert imported.stdout.strip() == "cached: True" and not imported.stderr

entry = invoke("package_entry", [sys.executable, "-m", "tasklab", "--text", "One two one"], expected_exit=0)
assert json.loads(entry.stdout)["result"] == {"one": 2, "two": 1}
assert not entry.stderr

cycle_environment = environment | {"PYTHONPATH": str(root / "fixtures" / "19_cycle")}
cycle = subprocess.run([sys.executable, "-c", "import alpha"], env=cycle_environment,
                       capture_output=True, text=True, check=False)
print(json.dumps({"case": "cycle", "exit": cycle.returncode, "stdout": cycle.stdout,
                  "stderr": cycle.stderr}, ensure_ascii=False))
assert cycle.returncode != 0 and "partially initialized module" in cycle.stderr
assert not cycle.stdout
