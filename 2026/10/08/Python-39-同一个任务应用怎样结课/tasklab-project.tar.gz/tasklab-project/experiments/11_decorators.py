import inspect
import json

from tasklab import create_store, run, submit
from tasklab.metrics import timed


def main():
    store = create_store()
    task_id = submit(store, "word_count", "one one")
    records = []

    @timed(records)
    def execute(task_id, *, expected=None):
        result = run(store, task_id)
        if expected is not None and result != expected:
            raise ValueError("unexpected result")
        return result

    result = execute(task_id, expected={"one": 2})
    try:
        execute("unknown")
    except KeyError as error:
        error_type = type(error).__name__
    print(json.dumps({
        "name": execute.__name__,
        "signature_preserved": inspect.signature(execute) == inspect.signature(execute.__wrapped__),
        "result": result,
        "error": error_type,
        "record_success": [record["succeeded"] for record in records],
        "elapsed_nonnegative": all(record["elapsed_ns"] >= 0 for record in records),
        "record_count": len(records),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
