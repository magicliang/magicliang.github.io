import asyncio
import json

from tasklab import cancel, create_store, query, submit
from tasklab.app import TaskExecutionError
from tasklab.async_batch import run_batch


async def main():
    store = create_store()
    failing = submit(store, "word_count", "One two one")
    siblings = (submit(store, "word_count", "One two one"),
                submit(store, "word_count", "One two one"))
    task_ids = (failing, *siblings)
    started = {task_id: asyncio.Event() for task_id in task_ids}
    cleaned = {task_id: asyncio.Event() for task_id in task_ids}
    fault_gate = asyncio.Event()
    sibling_gates = {task_id: asyncio.Event() for task_id in siblings}
    batch = asyncio.create_task(run_batch(
        store, task_ids,
        release_events={failing: fault_gate, **sibling_gates},
        started_events=started, cleaned_events=cleaned, fail_id=failing))
    await asyncio.gather(*(event.wait() for event in started.values()))
    assert all(query(store, task_id)["state"] == "running" for task_id in started)
    fault_gate.set()
    try:
        await batch
    except* TaskExecutionError as errors:
        assert len(errors.exceptions) == 1
    assert all(event.is_set() for event in cleaned.values())
    assert not any(event.is_set() for event in sibling_gates.values())
    states = {task_id: query(store, task_id)["state"] for task_id in started}
    assert states == {failing: "failed", **{task_id: "cancelled" for task_id in siblings}}
    print(json.dumps({"case": "failed_siblings_cancelled", "states": states,
                      "all_cleaned": True, "siblings_released": False}))

    waiting = submit(store, "word_count", "One two one")
    started_event, cleaned_event, never_released = asyncio.Event(), asyncio.Event(), asyncio.Event()
    try:
        await run_batch(store, (waiting,), release_events={waiting: never_released},
                        started_events={waiting: started_event},
                        cleaned_events={waiting: cleaned_event},
                        timeout_at=asyncio.get_running_loop().time() + 0.1)
    except TimeoutError:
        pass
    else:
        raise AssertionError("batch must time out")
    assert started_event.is_set() and cleaned_event.is_set() and not never_released.is_set()
    assert query(store, waiting)["state"] == "cancelled"
    print(json.dumps({"case": "timeout_joined", "state": "cancelled", "cleaned": True}))

    requested = submit(store, "word_count", "One two one")
    request_started, request_cleaned = asyncio.Event(), asyncio.Event()
    requested_batch = asyncio.create_task(run_batch(
        store, (requested,), release_events={requested: asyncio.Event()},
        started_events={requested: request_started},
        cleaned_events={requested: request_cleaned}))
    await request_started.wait()
    assert cancel(store, requested)
    assert query(store, requested)["state"] == "cancel_requested" and not request_cleaned.is_set()
    requested_batch.cancel()
    try:
        await requested_batch
    except asyncio.CancelledError:
        pass
    else:
        raise AssertionError("parent cancellation must propagate")
    assert request_cleaned.is_set() and query(store, requested)["state"] == "cancelled"
    print(json.dumps({"case": "requested_then_stopped", "before": "cancel_requested",
                      "after": "cancelled", "cleaned": True}))

    normal = submit(store, "word_count", "One two one")
    assert await run_batch(store, (normal,)) == {normal: {"one": 2, "two": 1}}
    print(json.dumps({"case": "normal", "state": query(store, normal)["state"],
                      "result": query(store, normal)["result"]}))


if __name__ == "__main__":
    asyncio.run(main())
