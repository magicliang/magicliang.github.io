import argparse
import json
from pathlib import Path
import runpy
import sys
import time


def load_cpu_work(path):
    return runpy.run_path(str(path))["cpu_work"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workloads", default="src/tasklab/workloads.py")
    args = parser.parse_args()
    cpu_work = load_cpu_work(Path(args.workloads))
    text = "one two one " * 50
    groups = {}
    for warmup in (0, 5, 20, '3seconds'):
        if warmup == '3seconds':
            deadline = time.perf_counter() + 3
            while time.perf_counter() < deadline:
                assert cpu_work(text, iterations=120) == 754902074
        else:
            for _ in range(warmup):
                assert cpu_work(text, iterations=120) == 754902074
        samples = []
        for _ in range(5):
            started = time.perf_counter_ns()
            assert cpu_work(text, iterations=120) == 754902074
            samples.append(time.perf_counter_ns() - started)
        groups[str(warmup)] = samples
    print(json.dumps({"python": sys.version, "executable": sys.executable,
                      "checksum": 754902074, "samples_ns": groups}))


if __name__ == "__main__":
    main()
