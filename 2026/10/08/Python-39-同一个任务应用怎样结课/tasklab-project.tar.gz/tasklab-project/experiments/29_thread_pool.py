import json
from threading import Event, enumerate as active_threads

from tasklab import create_store, query, submit
from tasklab.thread_runner import ThreadTaskRunner
from tasklab.workloads import cpu_work


store = create_store()
running = submit(store, "word_count", "One two one")
pending = submit(store, "word_count", "One two one")
after_cancel = submit(store, "word_count", "One two one")
entered = Event()
release = Event()
exited = Event()


def blocked(text):
    assert text == "One two one"
    entered.set()
    try:
        assert release.wait(5), "worker was not released"
    finally:
        exited.set()


try:
    with ThreadTaskRunner(store, workers=1, backlog=1) as runner:
        running_future = runner.submit(running, workload=blocked)
        assert entered.wait(5)
        pending_future = runner.submit(pending)
        assert not pending_future.running() and not pending_future.done()
        try:
            runner.submit(after_cancel)
        except BufferError as error:
            print(json.dumps({"case": "backpressure", "message": str(error)}))
        else:
            raise AssertionError("third task accepted despite full capacity")

        pending_request = runner.cancel(pending_future)
        assert pending_request == {"future_cancelled": True, "request_accepted": True}
        assert query(store, pending)["state"] == "cancelled"
        running_request = runner.cancel(running_future)
        assert running_request == {"future_cancelled": False, "request_accepted": True}
        assert query(store, running)["state"] == "cancel_requested"
        assert not exited.is_set()
        print(json.dumps({"case": "requests", "pending": pending_request,
                          "running": running_request,
                          "before_release": query(store, running)["state"]}))

        release.set()
        assert running_future.result(timeout=5) is None
        assert exited.wait(5)
        loaded_future = runner.submit(after_cancel,
                                      workload=lambda text: cpu_work(text, iterations=20000))
        assert loaded_future.result(timeout=5) == {"one": 2, "two": 1}
    assert query(store, running)["state"] == "cancelled"
    assert query(store, pending)["result"] is None
    assert query(store, after_cancel)["state"] == "succeeded"
    assert not any(thread.name.startswith("tasklab-worker") for thread in active_threads())
    print(json.dumps({"case": "finished", "states": [query(store, task_id)["state"]
                          for task_id in (running, pending, after_cancel)],
                      "released": exited.is_set(), "workers_remaining": 0}))
finally:
    release.set()
