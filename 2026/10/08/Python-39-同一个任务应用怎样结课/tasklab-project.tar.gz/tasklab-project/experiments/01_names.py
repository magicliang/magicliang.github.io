import json

from tasklab import create_store, query, run, submit


def rebind(words):
    words = ["different"]
    return words


def append(words):
    words.append("world")


def main():
    words = ["hello"]
    alias = words
    replacement = rebind(alias)
    after_rebind = words.copy()
    append(alias)
    after_append = words.copy()

    store = create_store()
    first = submit(store, "word_count", " ".join(words))
    words.append("later")
    second = submit(store, "word_count", " ".join(words))
    run(store, first)
    run(store, second)

    print(json.dumps({
        "same_list_before": alias is words,
        "after_rebind": after_rebind,
        "replacement": replacement,
        "after_append": after_append,
        "first_result": query(store, first)["result"],
        "second_result": query(store, second)["result"],
    }, sort_keys=True))


if __name__ == "__main__":
    main()
