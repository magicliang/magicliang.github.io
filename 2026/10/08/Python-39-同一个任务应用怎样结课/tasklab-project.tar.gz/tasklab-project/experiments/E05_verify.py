import asyncio
import importlib.util
import json
import os
import socket
import sys
import threading
import time


def missing_dependencies() -> list[str]:
    return [name for name in ("starlette", "uvicorn", "httpx") if importlib.util.find_spec(name) is None]


async def lifespan_shutdown_check(create_app) -> dict:
    app = create_app()
    async with app.router.lifespan_context(app):
        stop_event = threading.Event()

        def blocking_worker() -> str:
            while not stop_event.is_set():
                time.sleep(0.01)
            return "stopped"

        worker = asyncio.create_task(asyncio.to_thread(blocking_worker))
        app.state.running_tasks[worker] = stop_event
        await asyncio.sleep(0.05)
        running_before_exit = not worker.done()
    assert stop_event.is_set()
    assert worker.done()
    assert worker.result() == "stopped"
    assert len(app.state.running_tasks) == 0
    return {
        "running_before_exit": running_before_exit,
        "stop_event_set": stop_event.is_set(),
        "worker_done": worker.done(),
        "tracked_tasks_remaining": len(app.state.running_tasks),
    }


async def wait_for_http(client, base_url: str) -> None:
    for _ in range(100):
        try:
            response = await client.get(f"{base_url}/health")
            if response.status_code == 200:
                return
        except Exception:
            pass
        await asyncio.sleep(0.05)
    raise TimeoutError("server did not become ready")


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


async def main_async() -> dict:
    missing = missing_dependencies()
    if missing:
        return {"status": "NOT_RUN", "missing": missing}

    import httpx
    import uvicorn

    from E05_asgi import create_app

    app = create_app()
    port = free_port()
    lifespan_result = await lifespan_shutdown_check(create_app)
    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning", lifespan="on")
    server = uvicorn.Server(config)
    server_task = asyncio.create_task(server.serve())
    base_url = f"http://127.0.0.1:{port}"
    created = {}
    run_result = {}
    query_result = {}
    cancel_result = {}
    bad_results = {}
    disconnect_result = {}
    tracked_tasks_remaining = None
    live_lifespan_result = {}
    server_stopped = False
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            await wait_for_http(client, base_url)
            created_response = await client.post(
                f"{base_url}/tasks", json={"workload": "word_count", "payload": "one two one"}
            )
            created_response.raise_for_status()
            created = created_response.json()
            task_id = created["task_id"]
            run_response = await client.post(f"{base_url}/tasks/{task_id}/run")
            run_response.raise_for_status()
            run_result = run_response.json()
            query_response = await client.get(f"{base_url}/tasks/{task_id}")
            query_response.raise_for_status()
            query_result = query_response.json()

            pending_response = await client.post(
                f"{base_url}/tasks", json={"workload": "word_count", "payload": "cancel me"}
            )
            pending_response.raise_for_status()
            pending_id = pending_response.json()["task_id"]
            cancel_response = await client.post(f"{base_url}/tasks/{pending_id}/cancel")
            cancel_response.raise_for_status()
            cancel_result = cancel_response.json()

            duplicate_key = await client.post(
                f"{base_url}/tasks",
                content=b'{"workload":"word_count","workload":"word_count","payload":"x"}',
                headers={"content-type": "application/json"},
            )
            unknown_workload = await client.post(
                f"{base_url}/tasks", json={"workload": "missing", "payload": "x"}
            )
            bad_payload = await client.post(
                f"{base_url}/tasks", json={"workload": "word_count", "payload": 42}
            )
            extra_field = await client.post(
                f"{base_url}/tasks", json={"workload": "word_count", "payload": "x", "module": "os"}
            )
            bad_uuid = await client.get(f"{base_url}/tasks/not-a-uuid")
            bad_results = {
                "duplicate_key_status": duplicate_key.status_code,
                "unknown_workload_status": unknown_workload.status_code,
                "bad_payload_status": bad_payload.status_code,
                "extra_field_status": extra_field.status_code,
                "bad_uuid_status": bad_uuid.status_code,
            }

            app.state.run_started = asyncio.Event()
            app.state.run_gate = asyncio.Event()
            app.state.cancel_cleaned = asyncio.Event()
            disconnect_task_response = await client.post(
                f"{base_url}/tasks", json={"workload": "word_count", "payload": "disconnect case"}
            )
            disconnect_id = disconnect_task_response.json()["task_id"]
            with socket.create_connection(("127.0.0.1", port), timeout=5) as raw:
                request = (
                    f"POST /tasks/{disconnect_id}/run HTTP/1.1\r\n"
                    f"Host: 127.0.0.1:{port}\r\n"
                    "Content-Length: 0\r\n"
                    "Connection: close\r\n\r\n"
                )
                raw.sendall(request.encode("ascii"))
                await asyncio.wait_for(app.state.run_started.wait(), timeout=5)
                running_state = app.state.store["tasks"][disconnect_id].state
                assert running_state == "running", running_state
            await asyncio.wait_for(app.state.cancel_cleaned.wait(), timeout=5)
            tracked_tasks_remaining = len(app.state.running_tasks)
            disconnect_result = {
                "task_id": disconnect_id,
                "cleanup_count": app.state.cancel_cleanup_count,
                "state_before_close": running_state,
                "state": app.state.store["tasks"][disconnect_id].state,
                "tracked_tasks_remaining": tracked_tasks_remaining,
            }

            live_stop_event = threading.Event()

            def live_blocking_worker() -> str:
                while not live_stop_event.is_set():
                    time.sleep(0.01)
                return "stopped"

            live_worker = asyncio.create_task(asyncio.to_thread(live_blocking_worker))
            app.state.running_tasks[live_worker] = live_stop_event
    finally:
        app.state.run_gate = None if hasattr(app.state, "run_gate") else None
        server.should_exit = True
        await server_task
        server_stopped = True
        if "live_worker" in locals():
            live_lifespan_result = {
                "stop_event_set": live_stop_event.is_set(),
                "worker_done": live_worker.done(),
                "worker_result": live_worker.result() if live_worker.done() and not live_worker.cancelled() else None,
                "tracked_tasks_remaining": len(app.state.running_tasks),
            }
    assert run_result["result"] == {"one": 2, "two": 1}
    assert query_result["state"] == "succeeded"
    assert cancel_result["state"] == "cancelled"
    assert bad_results == {
        "duplicate_key_status": 400,
        "unknown_workload_status": 422,
        "bad_payload_status": 422,
        "extra_field_status": 422,
        "bad_uuid_status": 400,
    }
    assert disconnect_result["cleanup_count"] >= 1
    assert disconnect_result["state_before_close"] == "running"
    assert disconnect_result["state"] == "cancelled"
    assert disconnect_result["tracked_tasks_remaining"] == 0
    assert server_stopped is True
    assert live_lifespan_result == {
        "stop_event_set": True,
        "worker_done": True,
        "worker_result": "stopped",
        "tracked_tasks_remaining": 0,
    }
    assert lifespan_result["tracked_tasks_remaining"] == 0
    assert lifespan_result["worker_done"] is True
    return {
        "status": "PASS",
        "python": sys.executable,
        "pid": os.getpid(),
        "http": {"created": created, "run": run_result, "query": query_result, "cancel": cancel_result},
        "bad_inputs": bad_results,
        "disconnect": disconnect_result,
        "lifespan_shutdown": lifespan_result,
        "live_server_lifespan_shutdown": live_lifespan_result,
        "server_stopped": server_stopped,
    }


def main() -> None:
    print(json.dumps(asyncio.run(main_async()), ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
