import json

from tasklab import create_store, query, run, submit


def main():
    metadata = {"labels": ["short"]}
    shallow = metadata.copy()
    shallow["labels"].append("shared")
    store = create_store()
    first = submit(store, "word_count", "hello", metadata=metadata)
    metadata["labels"].append("later")
    second = submit(store, "word_count", "world", metadata=metadata)
    query(store, first)["metadata"]["labels"].append("outside")
    run(store, first)
    run(store, second)

    first_key = ("label", "short")
    equal_key = tuple(["label", "short"])
    print(json.dumps({
        "shallow_shared": shallow["labels"] is metadata["labels"],
        "first_labels": query(store, first)["metadata"]["labels"],
        "second_labels": query(store, second)["metadata"]["labels"],
        "equal_tuple_keys": first_key == equal_key,
        "equal_tuple_hashes": hash(first_key) == hash(equal_key),
        "lookup": {first_key: "known"}[equal_key],
        "results": [query(store, first)["result"], query(store, second)["result"]],
    }, sort_keys=True))


if __name__ == "__main__":
    main()
