import json

from tasklab import create_store, query, run, submit
from tasklab.model import Task


def main():
    store = create_store()
    first = submit(store, "word_count", "one", metadata={"labels": ["first"]})
    second = submit(store, "word_count", "two", metadata={"labels": ["second"]})
    run(store, first)
    first_task = store["tasks"][first]

    class BrokenTask:
        labels = []

    bad_first = BrokenTask()
    bad_second = BrokenTask()
    bad_first.labels.append("leak")
    print(json.dumps({
        "first_state": query(store, first)["state"],
        "second_state": query(store, second)["state"],
        "first_labels": query(store, first)["metadata"]["labels"],
        "second_labels": query(store, second)["metadata"]["labels"],
        "bound_self": first_task.snapshot.__self__ is first_task,
        "bound_func": first_task.snapshot.__func__ is Task.snapshot,
        "same_snapshot": first_task.snapshot() == Task.snapshot(first_task),
        "shared_class_labels": bad_second.labels,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
