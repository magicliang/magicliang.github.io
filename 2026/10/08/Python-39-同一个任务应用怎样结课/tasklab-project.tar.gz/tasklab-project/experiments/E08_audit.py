import argparse
import asyncio
import base64
import csv
from email.parser import BytesParser
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tempfile
import zipfile

import tasklab
from tasklab import create_store, run, submit_bytes, task_ids
from tasklab.jsonline import LoopbackService
from tasklab.serialization import TaskFormatError, decode_task, encode_task


def read_fixture(root, requested):
    root = Path(root).resolve(strict=True)
    target = (root / requested).resolve(strict=True)
    if not target.is_relative_to(root) or not target.is_file():
        raise ValueError('fixture path must be a regular file inside root')
    with target.open('rb') as source:
        return source.read(1025)


def inspect_wheel(path, expected):
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise ValueError('wheel SHA-256 mismatch')
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)), 'duplicate wheel member'
        for name in names:
            parts = PurePosixPath(name).parts
            assert parts and not name.startswith('/') and '\\' not in name
            assert '..' not in parts and '.' not in name.split('/')
            assert parts[0] in ('tasklab', 'tasklab-0.1.0.dist-info'), name
        metadata_path = next(name for name in archive.namelist() if name.endswith('.dist-info/METADATA'))
        metadata = BytesParser().parsebytes(archive.read(metadata_path))
        assert metadata['Name'] == 'tasklab' and metadata['Version'] == '0.1.0'
        assert metadata['Requires-Python'] == '>=3.12'
        assert not metadata.get_all('Requires-Dist')
        record = next(name for name in archive.namelist() if name.endswith('.dist-info/RECORD'))
        recorded = set()
        for name, digest, size in csv.reader(io.StringIO(archive.read(record).decode())):
            assert name in names and name not in recorded, name
            recorded.add(name)
            if not digest:
                assert name == record
                continue
            payload = archive.read(name)
            algorithm, encoded = digest.split('=', 1)
            assert algorithm == 'sha256'
            assert base64.urlsafe_b64encode(hashlib.sha256(payload).digest()).rstrip(b'=').decode() == encoded
            assert len(payload) == int(size)
        assert recorded == set(names), 'RECORD must cover every wheel member'
    return {'sha256': actual, 'name': metadata['Name'], 'version': metadata['Version'],
            'requires_python': metadata['Requires-Python'], 'runtime_dependencies': [], 'RECORD_valid': True}


async def network_checks():
    store = create_store()
    service = LoopbackService(store)
    address = await service.start()

    async def exchange(frame):
        reader, writer = await asyncio.open_connection(*address)
        try:
            writer.write(frame)
            await writer.drain()
            return json.loads(await asyncio.wait_for(reader.readline(), 3))
        finally:
            writer.close()
            await writer.wait_closed()

    malformed = [b'{"op":"import"}\n', b'{"op":"submit","kind":"shell","text":"a"}\n',
                 b'{"op":"submit","kind":"word_count","text":"a","file":"../secret"}\n',
                 b'{"op":"query","op":"submit","id":"task-0001"}\n',
                 b'{"op":"submit","text":"\xff"}\n', b'x' * 2049 + b'\n']
    rejected = []
    try:
        for frame in malformed:
            before = task_ids(store)
            response = await exchange(frame)
            assert response['ok'] is False and task_ids(store) == before
            rejected.append(response)
        created = await exchange(b'{"op":"submit","kind":"word_count","text":"a b a"}\n')
        task_id = created['id']
        queued = await exchange(json.dumps({'op': 'query', 'id': task_id}).encode() + b'\n')
        assert queued['task']['state'] == 'queued'
        executed = await exchange(json.dumps({'op': 'run', 'id': task_id}).encode() + b'\n')
        assert executed['result'] == {'a': 2, 'b': 1} and executed['task']['state'] == 'succeeded'
        cancelled = await exchange(json.dumps({'op': 'cancel', 'id': task_id}).encode() + b'\n')
        assert cancelled['accepted'] is False
        assert task_ids(store) == (task_id,)
        raw = json.loads(encode_task(task_id, executed['task']))
        for change in ({'kind': 'shell'}, {'file': '../secret'}):
            try:
                decode_task(json.dumps({**raw, **change}))
            except TaskFormatError:
                pass
            else:
                raise AssertionError('unsafe serialized task accepted')
        return {'rejected': rejected, 'task_id': task_id, 'result': executed['result'],
                'state': executed['task']['state'], 'late_cancel': cancelled['accepted']}
    finally:
        await service.close()
        assert not service._active


def fixture_checks():
    with tempfile.TemporaryDirectory() as directory:
        base = Path(directory)
        root = base / 'jobs'
        root.mkdir()
        (base / 'secret.txt').write_text('secret')
        (root / 'escape.txt').symlink_to(base / 'secret.txt')
        (root / 'legal.txt').write_text('a b a')
        store = create_store()
        for requested in ('../secret.txt', 'escape.txt'):
            try:
                read_fixture(root, requested)
            except ValueError:
                pass
            else:
                raise AssertionError('out-of-root fixture accepted')
            assert task_ids(store) == ()
        task_id = submit_bytes(store, 'word_count', read_fixture(root, 'legal.txt'))
        assert run(store, task_id) == {'a': 2, 'b': 1}
        (root / 'large.txt').write_bytes(b'a' * 1025)
        try:
            submit_bytes(store, 'word_count', read_fixture(root, 'large.txt'))
        except ValueError:
            pass
        else:
            raise AssertionError('large fixture accepted')
        assert task_ids(store) == (task_id,)
        return {'rejected_paths': ['../secret.txt', 'escape.txt'], 'legal_task_id': task_id,
                'oversize_rejected': True, 'TOCTOU': 'NOT_RUN; resolve/open is not atomic'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--wheel', required=True, type=Path)
    parser.add_argument('--sha256', required=True)
    args = parser.parse_args()
    assert 'site-packages' in Path(tasklab.__file__).resolve().parts, tasklab.__file__
    print(json.dumps({'module': tasklab.__file__, 'wheel': inspect_wheel(args.wheel, args.sha256),
                      'network': asyncio.run(network_checks()), 'fixtures': fixture_checks()}))


if __name__ == '__main__':
    main()
