import json
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Barrier, Event, Lock, Thread

from tasklab import create_store, query, submit
from tasklab.database import SQLiteTaskGateway


def shared_claims(*, protected):
    store = create_store()
    task_id = submit(store, "word_count", "One two one")
    barrier = Barrier(2)
    lock = Lock()
    claims = []
    errors = []

    def worker():
        try:
            if protected:
                barrier.wait(5)
                with lock:
                    if query(store, task_id)["state"] == "queued":
                        store["tasks"][task_id].state = "running"
                        claims.append(task_id)
            elif query(store, task_id)["state"] == "queued":
                barrier.wait(5)
                store["tasks"][task_id].state = "running"
                claims.append(task_id)
        except Exception as error:
            errors.append(str(error))

    threads = [Thread(target=worker) for _ in range(2)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(5)
    assert not errors and all(not thread.is_alive() for thread in threads)
    assert len(claims) == (1 if protected else 2)
    return {"case": "locked" if protected else "naive", "claims": claims,
            "state": query(store, task_id)["state"]}


for protected in (False, True):
    print(json.dumps(shared_claims(protected=protected)))

with TemporaryDirectory() as directory:
    gateway = SQLiteTaskGateway(Path(directory) / "tasks.sqlite")
    task_id = gateway.submit("word_count", "One two one")
    entered = Event()
    release = Event()
    competing = Event()
    finished = []
    errors = []

    def first():
        def wait(_text):
            entered.set()
            if not release.wait(5):
                raise TimeoutError("database worker not released")

        try:
            finished.append(gateway.run(task_id, workload=wait))
        except Exception as error:
            errors.append(type(error).__name__ + ": " + str(error))

    def second():
        if not entered.wait(5):
            errors.append("first worker did not enter")
            return
        competing.set()
        try:
            finished.append(gateway.run(task_id))
        except Exception as error:
            errors.append(type(error).__name__ + ": " + str(error))

    workers = [Thread(target=first), Thread(target=second)]
    for worker in workers:
        worker.start()
    try:
        assert entered.wait(5) and competing.wait(5)
    finally:
        release.set()
        for worker in workers:
            worker.join(5)
    assert all(not worker.is_alive() for worker in workers)
    assert finished == [{"one": 2, "two": 1}]
    assert len(errors) == 1 and errors[0] == "ValueError: only queued tasks can run"
    assert SQLiteTaskGateway(Path(directory) / "tasks.sqlite").query(task_id)["state"] == "succeeded"
    print(json.dumps({"case": "sqlite", "finished": finished, "errors": errors,
                      "state": gateway.query(task_id)["state"]}))
