from tasklab.optional_plugins import Processor, observed


def wrong_argument_type(number: int) -> None:
    pass


def named(text: str, *, label: str) -> int:
    return len(text) + len(label)


processor: Processor[[str], None] = wrong_argument_type
events: list[str] = []
try:
    observed(named, events)('one', label=42)
finally:
    assert events == ['entered', 'exited']
    print({'events': events})
