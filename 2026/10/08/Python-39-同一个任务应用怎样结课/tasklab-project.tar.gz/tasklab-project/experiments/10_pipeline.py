import json

from tasklab import create_store, run, submit
from tasklab.pipeline import word_batches


def main():
    seen = []

    def chunks():
        for chunk in ("one two ", "one skip "):
            seen.append(chunk)
            yield chunk

    batches = word_batches(chunks(), skip={"skip"}, size=2)
    first = next(batches)
    read_after_first = list(seen)
    rest = list(batches)
    store = create_store()
    baseline = run(store, submit(store, "word_count", "one two one skip"))
    included = list(word_batches(("one two one skip",), size=2))
    print(json.dumps({
        "first": first,
        "read_after_first": read_after_first,
        "rest": rest,
        "read_at_end": seen,
        "filtered_count": {word: sum(group.count(word) for group in [first, *rest]) for word in ("one", "two")},
        "unfiltered_batches": included,
        "baseline": baseline,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
