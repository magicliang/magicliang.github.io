import json
import sys
import tempfile
from pathlib import Path
import tasklab

from tasklab import cancel, create_store, query, run, submit
from tasklab.database import SQLiteTaskGateway


def exercise_memory(store):
    first = submit(store, "word_count", "one two one")
    second = submit(store, "word_count", "one")
    assert run(store, first) == {"one": 2, "two": 1}
    assert cancel(store, second) is True
    assert query(store, first)['state'] == 'succeeded' and query(store, second)['state'] == 'cancelled'
    return {"task_ids": [first, second], "first": query(store, first), "second": query(store, second)}


def exercise_gateway(gateway):
    first = gateway.submit("word_count", "one two one")
    second = gateway.submit("word_count", "one")
    assert gateway.run(first) == {"one": 2, "two": 1}
    assert gateway.cancel(second) is True
    reopened = SQLiteTaskGateway(gateway.path)
    assert reopened.query(first)['state'] == 'succeeded' and reopened.query(second)['state'] == 'cancelled'
    return {"task_ids": [first, second], "reopened": True,
            "first": reopened.query(first), "second": reopened.query(second)}


def main():
    package = Path(tasklab.__file__).resolve()
    assert 'site-packages' in package.parts and package.is_relative_to(Path(sys.prefix).resolve()), package
    memory = exercise_memory(create_store())
    with tempfile.TemporaryDirectory() as directory:
        sqlite = exercise_gateway(SQLiteTaskGateway(Path(directory) / "tasks.db"))
    print(json.dumps({"python": sys.version, "module": str(package), "memory": memory, "sqlite": sqlite},
                     ensure_ascii=False))


if __name__ == "__main__":
    main()
