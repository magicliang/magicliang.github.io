import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

from tasklab.database import SQLiteTaskGateway


with TemporaryDirectory() as directory:
    path = Path(directory) / "tasklab.sqlite"
    gateway = SQLiteTaskGateway(path)
    failed = gateway.submit("word_count", "one two one")
    try:
        gateway.run(failed, fail_at="after_state")
    except RuntimeError as error:
        print(json.dumps({"case": "fault", "message": str(error),
                          "snapshot_after_reopen": SQLiteTaskGateway(path).query(failed)}))
    else:
        raise AssertionError("fault was not injected")
    assert SQLiteTaskGateway(path).query(failed)["state"] == "queued"
    assert SQLiteTaskGateway(path).query(failed)["result"] is None
    assert gateway.run(failed) == {"one": 2, "two": 1}

    environment = os.environ.copy()
    environment["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
    for action, arguments in (("query", [failed]), ("submit", ["--text", "two"]),
                              ("cancel", ["task-0002"]), ("query", ["task-0002"]),
                              ("run", [failed])):
        outcome = subprocess.run([sys.executable, "-m", "tasklab.db_cli", "--db", str(path),
                                  action, *arguments], env=environment, capture_output=True,
                                 text=True, check=False)
        print(json.dumps({"case": action, "arguments": arguments, "exit": outcome.returncode,
                          "stdout": outcome.stdout, "stderr": outcome.stderr}, ensure_ascii=False))
        assert outcome.returncode == (2 if action == "run" else 0)
        if outcome.returncode:
            assert not outcome.stdout and "only queued" in outcome.stderr
        else:
            assert not outcome.stderr

    assert SQLiteTaskGateway(path).query(failed)["result"] == {"one": 2, "two": 1}
    assert SQLiteTaskGateway(path).query("task-0002")["state"] == "cancelled"
