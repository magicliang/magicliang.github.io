import json
import statistics
import sys
import time
import resource
import subprocess
from pathlib import Path

from tasklab import create_store, query, run, submit
from tasklab.app import count_words
from tasklab.pipeline import word_batches


def make_texts():
    return ["a b a c " * 40 for _ in range(256)]


def scalar_counts(texts):
    return count_words(word for batch in word_batches(texts) for word in batch)


def vector_counts(texts):
    import numpy as np
    words = []
    for text in texts:
        if any(ord(char) > 127 for char in text):
            raise ValueError("vector path only accepts ASCII text and whitespace")
        for word in text.split():
            if len(word) != 1 or not ("a" <= word <= "z"):
                raise ValueError("vector path only accepts single-letter ascii words")
            words.append(word)
    raw = " ".join(words).encode("ascii")
    view = np.frombuffer(raw, dtype=np.uint8)
    mask = (view >= ord("a")) & (view <= ord("z"))
    selected = view[mask]
    bins = np.bincount(selected - ord("a"), minlength=26)
    return ({chr(ord("a") + index): int(count)
             for index, count in enumerate(bins) if count},
            {"view_owndata": bool(view.flags.owndata),
             "raw_nbytes": len(raw),
             "selected_owndata": bool(selected.flags.owndata),
             "selected_nbytes": int(selected.nbytes)})


def main():
    import numpy as np
    if len(sys.argv) == 2 and sys.argv[1] in ('--memory-scalar', '--memory-vector'):
        function = scalar_counts if sys.argv[1] == '--memory-scalar' else lambda texts: vector_counts(texts)[0]
        assert function(make_texts()) == {"a": 20480, "b": 10240, "c": 10240}
        peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        print(json.dumps({'peak_rss_bytes': int(peak if sys.platform == 'darwin' else peak * 1024),
                          'scope': 'fresh process including interpreter and NumPy import'}))
        return
    texts = make_texts()
    expected = {"a": 20480, "b": 10240, "c": 10240}
    assert scalar_counts(texts) == expected
    try:
        vector, allocation = vector_counts(texts)
        vector_available = True
    except ModuleNotFoundError as error:
        vector, allocation = None, {"not_run": str(error)}
        vector_available = False
    if vector_available:
        assert vector == expected
        for bad in (["aa b"], ["a β"], ["a !"], ["a\u00a0b"]):
            try:
                vector_counts(bad)
            except ValueError:
                pass
            else:
                raise AssertionError("invalid vector input accepted")
    scalar_samples = []
    vector_samples = []
    for _ in range(2):
        scalar_counts(texts)
        if vector_available:
            vector_counts(texts)
    for index in range(7):
        functions = [('scalar', scalar_counts), ('vector', lambda texts: vector_counts(texts)[0])]
        if index % 2:
            functions.reverse()
        for name, function in functions:
            started = time.perf_counter_ns()
            assert function(texts) == expected
            (scalar_samples if name == 'scalar' else vector_samples).append(time.perf_counter_ns() - started)
    store = create_store()
    task_id = submit(store, "word_count", "a b a c")
    assert run(store, task_id) == {"a": 2, "b": 1, "c": 1}
    memory = {}
    for mode in ('scalar', 'vector'):
        result = subprocess.run([sys.executable, str(Path(__file__).resolve()), '--memory-' + mode],
                                check=True, capture_output=True, text=True)
        memory[mode] = json.loads(result.stdout)
    print(json.dumps({"python": sys.version, "numpy_version": np.__version__, "numpy_module": np.__file__,
                      "samples_ns": {'scalar': scalar_samples, 'vector': vector_samples},
                      "warmup_calls": 2, "order": "alternating", "memory": memory,
                      "scalar_median_ns": statistics.median(scalar_samples),
                      "vector": "PASS" if vector_available else "NOT_RUN",
                      "vector_median_ns": statistics.median(vector_samples) if vector_samples else None,
                      "allocation": allocation, "task": query(store, task_id)},
                     ensure_ascii=False))


if __name__ == "__main__":
    main()
