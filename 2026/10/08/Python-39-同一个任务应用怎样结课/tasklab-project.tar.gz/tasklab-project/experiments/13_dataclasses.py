import json
from dataclasses import FrozenInstanceError, dataclass, field

from tasklab import create_store, query, run, submit
from tasklab.model import TaskDefinition, TaskResult


@dataclass(frozen=True)
class FrozenExample:
    labels: list[str] = field(default_factory=list)


def main():
    first = TaskResult()
    second = TaskResult()
    first.counts["one"] = 1
    definition = TaskDefinition("word_count", "one", ("first",))
    same_value = TaskDefinition("word_count", "one", ("first",))
    frozen = FrozenExample()
    frozen.labels.append("still mutable")
    try:
        frozen.labels = []
    except FrozenInstanceError as error:
        assignment_error = type(error).__name__
    store = create_store()
    task_id = submit(store, "word_count", "one", metadata={"labels": ["first"]})
    result = run(store, task_id)
    print(json.dumps({
        "distinct_defaults": first.counts is not second.counts,
        "second_counts": second.counts,
        "equal_definitions": definition == same_value,
        "different_definition_objects": definition is not same_value,
        "deep_mutation": frozen.labels,
        "assignment_error": assignment_error,
        "task_result": result,
        "snapshot": query(store, task_id),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
