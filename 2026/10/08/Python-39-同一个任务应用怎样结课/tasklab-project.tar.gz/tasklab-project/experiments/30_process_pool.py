from concurrent.futures import ProcessPoolExecutor
import json
from multiprocessing import get_context
import os
import pickle

from tasklab import create_store, query, run, submit
from tasklab.process_runner import ProcessTaskRunner
from tasklab.workloads import cpu_work


SERIALIZATION_ERRORS = (AttributeError, pickle.PicklingError, TypeError)


def is_serialization_failure(error):
    if isinstance(error, SERIALIZATION_ERRORS):
        return True
    cause = getattr(error, "__cause__", None)
    return isinstance(cause, SERIALIZATION_ERRORS) or "pickl" in repr(error).lower()


def main():
    store = create_store()
    text = "One two one"
    sequential = submit(store, "word_count", text)
    processed = submit(store, "word_count", text)
    baseline = run(store, sequential, workload=lambda data: cpu_work(data, iterations=20000))

    with ProcessTaskRunner(workers=2) as runner:
        result = runner.run(store, processed, iterations=20000)
        assert result == baseline == {"one": 2, "two": 1}
        assert query(store, processed)["state"] == "succeeded"
        assert len(runner.traces) == 1
        child = runner.traces[0]
        assert child["pid"] != os.getpid() and child["result"] == result
        print(json.dumps({"case": "spawn", "parent_pid": os.getpid(),
                          "worker": child, "parent_state": query(store, processed)["state"],
                          "start_method": "spawn"}))

    with ProcessPoolExecutor(max_workers=1, mp_context=get_context("spawn")) as executor:
        try:
            executor.submit(lambda value: value, "one").result(timeout=15)
        except Exception as error:
            assert is_serialization_failure(error)
            print(json.dumps({"case": "unpicklable", "error_type": type(error).__name__,
                              "error": str(error)}))
        else:
            raise AssertionError("local lambda unexpectedly serialized")


if __name__ == "__main__":
    main()
