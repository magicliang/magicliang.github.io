import asyncio
import json
from pathlib import Path
import signal
import sys
import tempfile

from tasklab import create_store
from tasklab.database import SQLiteTaskGateway
from tasklab.jsonline import LoopbackService


async def wait_for_active_handler(service):
    for _ in range(100):
        if service._active:
            return
        await asyncio.sleep(0.01)
    raise AssertionError("handler did not become active")


async def main():
    service = LoopbackService(create_store(), read_timeout=10)
    host, port = await service.start()
    reader, writer = await asyncio.open_connection(host, port)
    writer.write(b'{"op":"submit"')
    await writer.drain()
    await wait_for_active_handler(service)
    cancelled_handlers = await service.close(drain_timeout=0)
    assert cancelled_handlers == 1 and await reader.read() == b""
    writer.close()
    await writer.wait_closed()
    print(json.dumps({"case": "bounded_drain", "cancelled_handlers": cancelled_handlers,
                      "active_after_close": len(service._active)}))

    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "tasks.db"
        gateway = SQLiteTaskGateway(path)
        claimed = gateway.submit("word_count", "One two one")
        uncommitted = gateway.submit("word_count", "One two one")
        worker = Path(__file__).with_name("35_worker.py")
        for task_id, mode in ((claimed, "claimed"), (uncommitted, "transaction")):
            process = await asyncio.create_subprocess_exec(
                sys.executable, str(worker), str(path), task_id, mode,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            try:
                line = await asyncio.wait_for(process.stdout.readline(), 3)
                assert line
                if mode == "claimed":
                    assert gateway.query(task_id)["state"] == "running"
                    process.kill()
                assert await asyncio.wait_for(process.wait(), 3) == -signal.SIGKILL
                print(json.dumps({"case": mode, "child_exit": process.returncode,
                                  "ready_line": line.decode().strip()}))
            finally:
                if process.returncode is None:
                    process.kill()
                    await process.wait()
        reopened = SQLiteTaskGateway(path)
        before = [reopened.query(task_id)["state"] for task_id in (claimed, uncommitted)]
        assert before == ["running", "queued"]
        assert reopened.recover_running() == (claimed,)
        after = [reopened.query(task_id)["state"] for task_id in (claimed, uncommitted)]
        assert after == ["failed", "queued"]
        assert reopened.run(uncommitted) == {"one": 2, "two": 1}
        print(json.dumps({"case": "restart", "task_ids": [claimed, uncommitted],
                          "before": before, "after_recovery": after,
                          "replayed_queued": reopened.query(uncommitted)["state"]}))


if __name__ == "__main__":
    asyncio.run(main())
