import argparse
import base64
import csv
import hashlib
import io
import json
import tempfile
import zipfile
from pathlib import Path

from E08_audit import inspect_wheel


def sha256_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def record_row(name, payload):
    digest = base64.urlsafe_b64encode(hashlib.sha256(payload).digest()).rstrip(b'=').decode()
    return [name, f'sha256={digest}', str(len(payload))]


def read_wheel(path):
    with zipfile.ZipFile(path) as archive:
        return [(info.filename, archive.read(info.filename)) for info in archive.infolist()]


def write_wheel(path, entries):
    with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, payload in entries:
            archive.writestr(name, payload)


def rebuild_record(entries, *, omit=()):
    omit = set(omit)
    record_name = next(name for name, _ in entries if name.endswith('.dist-info/RECORD'))
    rows = []
    for name, payload in entries:
        if name in omit:
            continue
        if name == record_name:
            rows.append([name, '', ''])
        else:
            rows.append(record_row(name, payload))
    buffer = io.StringIO()
    writer = csv.writer(buffer, lineterminator='\n')
    writer.writerows(rows)
    return record_name, buffer.getvalue().encode()


def with_rebuilt_record(entries, *, omit=()):
    record_name, record_payload = rebuild_record(entries, omit=omit)
    return [(name, record_payload if name == record_name else payload) for name, payload in entries]


def write_case(directory, name, entries, *, omit_record_entries=()):
    path = directory / f'{name}.whl'
    rebuilt = with_rebuilt_record(entries, omit=omit_record_entries)
    write_wheel(path, rebuilt)
    return path


def assert_rejected(label, path):
    expected = sha256_file(path)
    try:
        inspect_wheel(path, expected)
    except (AssertionError, ValueError, KeyError) as exc:
        return {'case': label, 'status': 'PASS', 'exception': type(exc).__name__, 'message': str(exc)}
    raise AssertionError(f'{label} wheel was accepted')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--wheel', required=True, type=Path)
    args = parser.parse_args()

    real_sha = sha256_file(args.wheel)
    positive = inspect_wheel(args.wheel, real_sha)
    base_entries = read_wheel(args.wheel)

    with tempfile.TemporaryDirectory() as temp:
        directory = Path(temp)
        cases = []

        outside_entries = base_entries + [('../outside.py', b'print("escape")\n')]
        cases.append(assert_rejected('parent-directory-member', write_case(directory, 'parent-directory-member', outside_entries)))

        other_prefix_entries = base_entries + [('otherpkg/__init__.py', b'')]
        cases.append(assert_rejected('other-package-prefix', write_case(directory, 'other-package-prefix', other_prefix_entries)))

        duplicate_entries = base_entries + [base_entries[0]]
        cases.append(assert_rejected('duplicate-member', write_case(directory, 'duplicate-member', duplicate_entries)))

        missing_name, _ = next((name, payload) for name, payload in base_entries if name.startswith('tasklab/') and not name.endswith('/'))
        missing_record_path = write_case(directory, 'record-missing-member', base_entries, omit_record_entries={missing_name})
        cases.append(assert_rejected('record-missing-member', missing_record_path))

    print(json.dumps({'positive': positive, 'negative': cases}, ensure_ascii=False, sort_keys=True))


if __name__ == '__main__':
    main()
