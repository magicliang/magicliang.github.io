import asyncio
from contextlib import asynccontextmanager
import json
import threading
import time
from typing import Any

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse, PlainTextResponse
from starlette.routing import Route

from tasklab import cancel, create_store, query, run, submit
from tasklab.jsonline import _reject_constant, _unique_fields


class JsonError(ValueError):
    pass


async def read_json(request: Request, limit: int = 4096) -> dict[str, Any]:
    chunks: list[bytes] = []
    size = 0
    async for chunk in request.stream():
        size += len(chunk)
        if size > limit:
            raise JsonError("request body too large")
        chunks.append(chunk)
    data = b"".join(chunks)
    if not data:
        return {}
    try:
        value = json.loads(
            data.decode("utf-8"),
            object_pairs_hook=_unique_fields,
            parse_constant=_reject_constant,
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
        raise JsonError(str(error)) from error
    if not isinstance(value, dict):
        raise JsonError("json body must be an object")
    return value


def problem(message: str, status_code: int) -> JSONResponse:
    return JSONResponse({"error": message}, status_code=status_code)


def get_store(request: Request):
    return request.app.state.store


def task_id_param(request: Request) -> str:
    task_id = request.path_params["task_id"]
    if not isinstance(task_id, str) or not task_id.startswith("task-"):
        raise ValueError("invalid task id")
    return task_id


async def create_task(request: Request) -> JSONResponse:
    try:
        body = await read_json(request)
        if set(body) != {"workload", "payload"}:
            return problem("body must contain workload and payload only", 422)
        workload = body.get("workload")
        payload = body.get("payload")
        if not isinstance(workload, str) or not workload:
            return problem("workload must be a nonempty string", 422)
        task_id = submit(get_store(request), workload, payload)
        snapshot = query(get_store(request), task_id)
        return JSONResponse({"task_id": task_id, **snapshot}, status_code=201)
    except JsonError as error:
        return problem(str(error), 400)
    except (TypeError, ValueError) as error:
        return problem(str(error), 422)


async def get_task(request: Request) -> JSONResponse:
    try:
        task_id = task_id_param(request)
        return JSONResponse(query(get_store(request), task_id))
    except ValueError as error:
        return problem(str(error), 400)
    except KeyError:
        return problem("task not found", 404)


async def run_task(request: Request) -> JSONResponse:
    try:
        task_id = task_id_param(request)
        gate = getattr(request.app.state, "run_gate", None)
        started = getattr(request.app.state, "run_started", None)
        store = get_store(request)
        loop = asyncio.get_running_loop()
        cancel_event = threading.Event()

        def checkpoint(text: str) -> None:
            if started is not None:
                loop.call_soon_threadsafe(started.set)
            if gate is None:
                return
            while not gate.is_set() and not cancel_event.is_set():
                time.sleep(0.01)
            if cancel_event.is_set():
                cancel(store, task_id)

        worker = asyncio.create_task(asyncio.to_thread(run, store, task_id, workload=checkpoint))
        request.app.state.running_tasks[worker] = cancel_event
        worker.add_done_callback(lambda task: request.app.state.running_tasks.pop(task, None))
        while not worker.done():
            if await request.is_disconnected():
                cancel_event.set()
                request.app.state.cancel_cleanup_count += 1
                await worker
                cleaned = getattr(request.app.state, "cancel_cleaned", None)
                if cleaned is not None:
                    cleaned.set()
                return problem("client disconnected", 499)
            await asyncio.sleep(0.01)
        result = await worker
        return JSONResponse({"task_id": str(task_id), "result": result})
    except asyncio.CancelledError:
        cleanup = getattr(request.app.state, "cancel_cleanup_count", None)
        if cleanup is not None:
            request.app.state.cancel_cleanup_count = cleanup + 1
        if "cancel_event" in locals():
            cancel_event.set()
        if "worker" in locals() and worker is not None:
            await asyncio.gather(asyncio.shield(worker), return_exceptions=True)
        raise
    except RuntimeError as error:
        return problem(str(error), 409)
    except ValueError as error:
        return problem(str(error), 400)
    except KeyError:
        return problem("task not found", 404)


async def cancel_task(request: Request) -> JSONResponse:
    try:
        task_id = task_id_param(request)
        cancel(get_store(request), task_id)
        return JSONResponse(query(get_store(request), task_id))
    except ValueError as error:
        return problem(str(error), 400)
    except KeyError:
        return problem("task not found", 404)


async def health(request: Request) -> PlainTextResponse:
    return PlainTextResponse("ok")



@asynccontextmanager
async def lifespan(app: Starlette):
    app.state.running_tasks = {}
    try:
        yield
    finally:
        items = list(app.state.running_tasks.items())
        for task, cancel_event in items:
            cancel_event.set()
        if items:
            await asyncio.gather(*(asyncio.shield(task) for task, _ in items), return_exceptions=True)
        app.state.running_tasks.clear()


def create_app() -> Starlette:
    app = Starlette(
        lifespan=lifespan,
        routes=[
            Route("/health", health, methods=["GET"]),
            Route("/tasks", create_task, methods=["POST"]),
            Route("/tasks/{task_id}", get_task, methods=["GET"]),
            Route("/tasks/{task_id}/run", run_task, methods=["POST"]),
            Route("/tasks/{task_id}/cancel", cancel_task, methods=["POST"]),
        ]
    )
    app.state.store = create_store()
    app.state.cancel_cleanup_count = 0
    if not hasattr(app.state, "running_tasks"):
        app.state.running_tasks = {}
    return app


app = create_app()
