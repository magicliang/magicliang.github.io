import json

from tasklab import create_store, query, submit


def unsafe_submit(store, label, labels=[]):
    labels.append(label)
    return submit(store, "word_count", label, metadata={"labels": labels})


def safe_submit(store, label, *, labels=None):
    selected = [] if labels is None else labels.copy()
    selected.append(label)
    return submit(store, "word_count", label, metadata={"labels": selected})


def main():
    store = create_store()
    unsafe_first = unsafe_submit(store, "first")
    unsafe_second = unsafe_submit(store, "second")
    safe_first = safe_submit(store, "third")
    safe_second = safe_submit(store, "fourth")
    before = len(store["tasks"])
    try:
        submit(store, "word_count", "wrong", {"labels": []})
    except TypeError as error:
        signature_error = type(error).__name__
    print(json.dumps({
        "unsafe_first": query(store, unsafe_first)["metadata"]["labels"],
        "unsafe_second": query(store, unsafe_second)["metadata"]["labels"],
        "safe_first": query(store, safe_first)["metadata"]["labels"],
        "safe_second": query(store, safe_second)["metadata"]["labels"],
        "signature_error": signature_error,
        "task_count_preserved": len(store["tasks"]) == before,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
