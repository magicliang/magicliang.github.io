import os
import signal
import sys

from tasklab.database import SQLiteTaskGateway


def main():
    path, task_id, mode = sys.argv[1:]
    gateway = SQLiteTaskGateway(path)
    if mode == "claimed":
        gateway.claim(task_id)
        print("claimed running", flush=True)
        signal.pause()
    elif mode == "transaction":
        def crash(_text):
            print("inside uncommitted run", flush=True)
            os.kill(os.getpid(), signal.SIGKILL)

        gateway.run(task_id, workload=crash)
    else:
        raise ValueError("unknown worker mode")


if __name__ == "__main__":
    main()
