import argparse
from concurrent.futures import ThreadPoolExecutor
import ctypes
import dis
import hashlib
import json
from pathlib import Path
import sys
import sysconfig

from tasklab.app import count_words


SOURCE_FILES = {
    "Python/ceval.c": ("353e9790230e79831b848e46a7149d5496c0a1cdf900e49e86b82dcc7d2eef95",
                       "_PyEval_EvalFrameDefault(", '#include "generated_cases.c.h"'),
    "Python/generated_cases.c.h": (
        "2921e577226f404a00a7e19eaabb2ee58fbeeefb69f02f13e6901ffce0cf595f",
        "TARGET(BINARY_OP)", "TARGET(FOR_ITER)", "TARGET(CALL)"),
    "Python/ceval_gil.c": (
        "a9621cb0c267f50cb3cb30631e3cf8fa7bd6733f929273f0c7b9b55c9c7d5ceb",
        "take_gil(PyThreadState *tstate)", "drop_gil(struct _ceval_state *ceval"),
    "Include/internal/pycore_gil.h": (
        "cf455aacd5651e5b43547ebe69bb324eab84238d92665df53c1df32434bd0d9b",
        "struct _gil_runtime_state"),
}


def inspect_runtime():
    bytecode = [instruction.opname for instruction in dis.get_instructions(count_words)]
    assert "BINARY_OP" in bytecode and "FOR_ITER" in bytecode
    gil_check = ctypes.pythonapi.PyGILState_Check
    gil_check.restype = ctypes.c_int
    with ThreadPoolExecutor(max_workers=1) as executor:
        worker_gil = executor.submit(gil_check).result()
    return {"python": sys.version, "executable": sys.executable,
            "py_gil_disabled_build_config": sysconfig.get_config_var("Py_GIL_DISABLED"),
            "is_gil_enabled_api": hasattr(sys, "_is_gil_enabled"),
            "gil_held_at_main_probe": gil_check(), "gil_held_at_worker_probe": worker_gil,
            "opcode_names": bytecode, "count_words_result": count_words(iter(("one", "two", "one")))}


def inspect_source(source):
    files = []
    for name, (sha, *symbols) in SOURCE_FILES.items():
        path = source / name
        content = path.read_bytes()
        digest = hashlib.sha256(content).hexdigest()
        assert digest == sha, f"source mismatch: {name}"
        text = content.decode("utf-8")
        for symbol in symbols:
            assert symbol in text, f"missing source symbol: {name} {symbol}"
        files.append({"path": name, "sha256": digest, "symbols": symbols})
    return files


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, type=Path)
    args = parser.parse_args()
    print(json.dumps({"type": "runtime", **inspect_runtime()}))
    print(json.dumps({"type": "source", "files": inspect_source(args.source)}))


if __name__ == "__main__":
    main()
