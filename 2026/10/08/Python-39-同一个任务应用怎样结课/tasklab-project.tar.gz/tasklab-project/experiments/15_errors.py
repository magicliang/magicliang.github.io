import json
import sys
import traceback

from tasklab import TaskExecutionError, create_store, query, run, submit


def main():
    store = create_store()
    previous = submit(store, "word_count", "one")
    try:
        submit(store, "", "invalid")
    except ValueError as error:
        input_error = type(error).__name__
    failed = submit(store, "word_count", "two")
    try:
        run(store, failed, fail_at="compute")
    except TaskExecutionError as error:
        execution_error = type(error).__name__
        cause = type(error.__cause__).__name__
        root_cause = type(error.__cause__.__cause__).__name__
        traceback.print_exception(error, file=sys.stderr)
    print(json.dumps({
        "input_error": input_error,
        "execution_error": execution_error,
        "cause": cause,
        "root_cause": root_cause,
        "previous_state": query(store, previous)["state"],
        "failed_state": query(store, failed)["state"],
        "failed_error": query(store, failed)["error"],
        "failed_result": query(store, failed)["result"],
    }, sort_keys=True))


if __name__ == "__main__":
    main()
