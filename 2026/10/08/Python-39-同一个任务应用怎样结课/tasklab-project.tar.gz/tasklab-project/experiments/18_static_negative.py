from tasklab.typed import MemoryTaskGateway, TaskGateway


service: TaskGateway = MemoryTaskGateway()
service.submit("word_count", 42)
