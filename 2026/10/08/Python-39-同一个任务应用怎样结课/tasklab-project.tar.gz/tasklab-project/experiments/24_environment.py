import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys


root = Path(__file__).resolve().parents[1]
assert sys.prefix != sys.base_prefix, "experiment must run inside venv"
environment = os.environ.copy()
environment["PYTHONPATH"] = str(root / "src")
positive = subprocess.run(
    [sys.executable, "-c", "import tasklab; print(tasklab.__file__); from tasklab import submit"],
    capture_output=True, text=True, env=environment, check=False,
)
print(json.dumps({"case": "real_package", "exit": positive.returncode,
                  "stdout": positive.stdout, "stderr": positive.stderr}, ensure_ascii=False))
assert positive.returncode == 0 and not positive.stderr
assert str(root / "src" / "tasklab" / "__init__.py") in positive.stdout

environment["PYTHONPATH"] = os.pathsep.join((str(root / "fixtures" / "24_shadow"), str(root / "src")))
shadow = subprocess.run(
    [sys.executable, "-c", "import tasklab; print(tasklab.__file__); from tasklab import submit"],
    capture_output=True, text=True, env=environment, check=False,
)
print(json.dumps({"case": "shadow_module", "exit": shadow.returncode,
                  "stdout": shadow.stdout, "stderr": shadow.stderr}, ensure_ascii=False))
assert shadow.returncode == 1 and "cannot import name 'submit'" in shadow.stderr
assert str(root / "fixtures" / "24_shadow" / "tasklab.py") in shadow.stdout
print(json.dumps({"interpreter": sys.executable, "venv_prefix": sys.prefix,
                  "base_prefix": sys.base_prefix, "package_origin": positive.stdout.strip()}, ensure_ascii=False))
