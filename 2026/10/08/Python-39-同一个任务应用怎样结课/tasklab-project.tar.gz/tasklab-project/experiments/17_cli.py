import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory


environment = os.environ.copy()
environment["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")


def invoke(name, *arguments, expected_exit):
    outcome = subprocess.run(
        [sys.executable, "-m", "tasklab.cli", *map(str, arguments)],
        capture_output=True, text=True, env=environment, check=False,
    )
    print(json.dumps({
        "case": name, "exit": outcome.returncode, "stdout": outcome.stdout,
        "stderr": outcome.stderr,
    }, ensure_ascii=False))
    assert outcome.returncode == expected_exit, name
    if expected_exit:
        assert not outcome.stdout and "error:" in outcome.stderr, name
    else:
        assert not outcome.stderr, name
    return outcome


with TemporaryDirectory() as directory:
    path = Path(directory) / "input.txt"
    path.write_text("One two one", encoding="utf-8")
    text = invoke("text", "--text", "One two one", expected_exit=0)
    file = invoke("file", "--file", path, expected_exit=0)
    assert json.loads(file.stdout) == json.loads(text.stdout)
    assert json.loads(text.stdout)["result"] == {"one": 2, "two": 1}
    invoke("missing", "--file", Path(directory) / "missing", expected_exit=2)
    path.write_bytes(b"\xff")
    invoke("invalid_utf8", "--file", path, expected_exit=2)
    path.write_bytes(b"a" * 1025)
    invoke("too_large", "--file", path, expected_exit=2)
    invoke("exclusive", "--text", "one", "--file", path, expected_exit=2)
    invoke("unknown_kind", "--kind", "unknown", "--text", "one", expected_exit=2)
    help_outcome = invoke("help", "--help", expected_exit=0)
    assert "--file" in help_outcome.stdout

print(json.dumps({"cases": 8, "verified": True}))
