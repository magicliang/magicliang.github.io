import json

from tasklab import create_store, query, run, submit
from tasklab.transforms import suffix_callbacks


def late_callbacks(suffixes):
    return [lambda text: f"{text} {suffix}" for suffix in suffixes]


def run_callbacks(store, callbacks):
    results = []
    for callback in callbacks:
        task_id = submit(store, "word_count", callback("hello"))
        run(store, task_id)
        results.append(query(store, task_id)["result"])
    return results


def main():
    store = create_store()
    suffixes = ["red", "blue", "green"]
    wrong = run_callbacks(store, late_callbacks(suffixes))
    right = run_callbacks(store, suffix_callbacks(suffixes))
    print(json.dumps({"late": wrong, "bound": right, "task_count": len(store["tasks"])}, sort_keys=True))


if __name__ == "__main__":
    main()
