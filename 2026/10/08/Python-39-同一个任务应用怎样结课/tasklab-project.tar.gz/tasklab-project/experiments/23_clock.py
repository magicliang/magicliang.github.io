import json
from pathlib import Path
from tempfile import TemporaryDirectory

from tasklab import TaskExecutionError, create_store, query, run, submit
from tasklab.database import SQLiteTaskGateway
from tasklab.resources import open_word_file


store = create_store()
task_id = submit(store, "word_count", "One two one")
try:
    run(store, task_id, clock=lambda: 5, deadline=5)
except TimeoutError as error:
    print(json.dumps({"case": "before_start", "message": str(error),
                      "state": query(store, task_id)["state"]}))
else:
    raise AssertionError("missed before-start deadline")

with TemporaryDirectory() as directory:
    path = Path(directory) / "input.txt"
    path.write_text("One two one", encoding="utf-8")
    with open_word_file(path) as (words, source):
        assert next(words) == "one"
    assert source.closed
    database = Path(directory) / "tasklab.sqlite"
    gateway = SQLiteTaskGateway(database)
    task_id = gateway.submit("word_count", path.read_text(encoding="utf-8"))
    samples = iter((1, 6))
    try:
        gateway.run(task_id, clock=lambda: next(samples), deadline=5)
    except TaskExecutionError as error:
        print(json.dumps({"case": "after_compute", "cause": str(error.__cause__),
                          "snapshot_after_reopen": SQLiteTaskGateway(database).query(task_id),
                          "file_closed": source.closed}))
    else:
        raise AssertionError("missed after-compute deadline")
    assert SQLiteTaskGateway(database).query(task_id)["state"] == "failed"
    successful = gateway.submit("word_count", path.read_text(encoding="utf-8"))
    assert gateway.run(successful, clock=lambda: 1, deadline=5) == {"one": 2, "two": 1}
    print(json.dumps({"case": "normal", "snapshot_after_reopen":
                      SQLiteTaskGateway(database).query(successful)}, ensure_ascii=False))
