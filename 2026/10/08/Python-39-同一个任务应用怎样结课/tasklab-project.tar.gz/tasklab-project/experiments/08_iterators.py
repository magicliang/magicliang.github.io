import json

from tasklab import create_store, submit, task_ids


def main():
    store = create_store()
    for text in ("first", "second", "third"):
        submit(store, "word_count", text)
    collection = task_ids(store)
    iterator = iter(collection)
    first = next(iterator)
    rest = list(iterator)
    exhausted = list(iterator)
    again = list(iter(collection))
    submit(store, "word_count", "fourth")
    print(json.dumps({
        "first": first,
        "rest": rest,
        "exhausted": exhausted,
        "again": again,
        "snapshot_after_new_submit": list(collection),
        "fresh_collection": list(task_ids(store)),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
