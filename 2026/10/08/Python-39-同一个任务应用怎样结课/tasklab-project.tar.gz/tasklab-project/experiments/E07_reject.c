#include <Python.h>

static PyObject *
ping(PyObject *self, PyObject *args)
{
    Py_RETURN_NONE;
}

static PyMethodDef methods[] = {
    {"ping", ping, METH_NOARGS, "Return None."},
    {NULL, NULL, 0, NULL}
};

static PyModuleDef_Slot slots[] = {
    {Py_mod_multiple_interpreters, Py_MOD_MULTIPLE_INTERPRETERS_NOT_SUPPORTED},
#if PY_VERSION_HEX >= 0x030D0000
    {Py_mod_gil, Py_MOD_GIL_NOT_USED},
#endif
    {0, NULL}
};

static struct PyModuleDef definition = {
    PyModuleDef_HEAD_INIT,
    "_rejectinterp",
    NULL,
    0,
    methods,
    slots,
    NULL,
    NULL,
    NULL
};

PyMODINIT_FUNC
PyInit__rejectinterp(void)
{
    return PyModuleDef_Init(&definition);
}
