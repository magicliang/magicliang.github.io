import argparse
import json

from tasklab.model import TASK_STATES, Task


class StateField:
    def __set_name__(self, owner, name):
        self.name = name
        self.storage_name = '_state'

    def __get__(self, instance, owner=None):
        if instance is None:
            return self
        with instance._lock:
            return getattr(instance, self.storage_name)

    def __set__(self, instance, value):
        with instance._lock:
            if value not in TASK_STATES:
                raise ValueError('unknown task state')
            setattr(instance, self.storage_name, value)


class Candidate(Task):
    state = StateField()


class NamedClasses(type):
    def __new__(metaclass, name, bases, namespace):
        namespace['declared_name'] = name
        return super().__new__(metaclass, name, bases, namespace)


class MetaclassExample(Candidate, metaclass=NamedClasses):
    state = StateField()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--invalid', action='store_true')
    args = parser.parse_args()
    reference = Task('word_count', 'one', {'labels': []})
    candidate = Candidate('word_count', 'one', {'labels': []})
    if args.invalid:
        candidate.state = 'unknown'
    for state in ('queued', 'running', 'succeeded'):
        reference.state = candidate.state = state
        assert reference.snapshot() == candidate.snapshot()
    errors = []
    for value, expected in (('unknown', ValueError), ([], TypeError), (None, ValueError)):
        observed_errors = []
        for task in (reference, candidate):
            task.state = 'running'
            try:
                task.state = value
            except expected as error:
                observed_errors.append((type(error).__name__, str(error)))
            else:
                raise AssertionError('invalid state accepted')
            assert task.state == 'running'
        assert observed_errors[0] == observed_errors[1]
        errors.append(observed_errors[0])
    candidate.state = 'succeeded'
    candidate.__dict__['state'] = 'shadow'
    assert candidate.state == 'succeeded'
    late = StateField()
    Candidate.late = late
    assert not hasattr(late, 'name')
    try:
        candidate.late
    except AttributeError:
        pass
    else:
        raise AssertionError('late descriptor initialized automatically')
    late.__set_name__(Candidate, 'late')
    assert late.name == 'late' and candidate.late == 'succeeded'
    assert MetaclassExample.declared_name == 'MetaclassExample'
    assert MetaclassExample.state.name == 'state'
    print(json.dumps({'errors': errors, 'data_descriptor_shadows_dict': True,
                      'late_set_name_automatic': False,
                      'metaclass_name': MetaclassExample.declared_name}))


if __name__ == '__main__':
    main()
