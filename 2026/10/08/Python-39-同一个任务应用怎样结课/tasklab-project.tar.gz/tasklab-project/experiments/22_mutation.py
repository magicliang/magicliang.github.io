import json
from unittest import TestLoader, TextTestRunner
from unittest.mock import patch

from tasklab.database import SQLiteTaskGateway


suite = TestLoader().discover("tests", pattern="test_invariants.py")
with patch.object(SQLiteTaskGateway, "cancel", return_value=True):
    result = TextTestRunner(verbosity=2).run(suite)

assert not result.wasSuccessful(), "test suite failed to catch broken cancellation"
assert len(result.failures) == 1 and not result.errors
print(json.dumps({"broken_rule": "cancel accepts without changing SQLite state",
                  "detected_failures": len(result.failures), "errors": len(result.errors)}))
