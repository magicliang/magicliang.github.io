from tasklab.optional_plugins import Processor, observed


def named(text: str, *, label: str) -> int:
    return len(text) + len(label)


def plugin(text: str) -> int:
    return len(text)


events: list[str] = []
processor: Processor[[str], int] = observed(plugin, events)
assert processor('one') == 3
assert observed(named, events)('one', label='two') == 6
assert events == ['entered', 'exited', 'entered', 'exited']
print({'result': 3, 'events': events})
