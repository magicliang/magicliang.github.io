#include <Python.h>

static PyObject *ping(PyObject *self, PyObject *args) {
    Py_RETURN_NONE;
}

static PyMethodDef methods[] = {
    {"ping", ping, METH_NOARGS, NULL},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef definition = {
    PyModuleDef_HEAD_INIT,
    "legacyprobe",
    NULL,
    -1,
    methods
};

PyMODINIT_FUNC PyInit_legacyprobe(void) {
    return PyModule_Create(&definition);
}
