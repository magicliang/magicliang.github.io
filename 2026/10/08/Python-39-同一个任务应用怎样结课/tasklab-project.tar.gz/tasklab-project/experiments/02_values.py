import json

from tasklab import create_store, query, run, submit


def main():
    store = create_store()
    empty = submit(store, "word_count", "")
    run(store, empty)

    rejected = {}
    for value in (0, False, None):
        try:
            submit(store, "word_count", value)
        except TypeError as error:
            rejected[type(value).__name__] = str(error)

    first_text = "hello world"
    second_text = " ".join(["hello", "world"])
    first = submit(store, "word_count", first_text)
    second = submit(store, "word_count", second_text)
    run(store, first)
    run(store, second)
    zero = 0
    print(json.dumps({
        "empty_state": query(store, empty)["state"],
        "empty_result": query(store, empty)["result"],
        "rejected": rejected,
        "zero_equals_false": zero == False,
        "zero_is_false": zero is False,
        "texts_equal": first_text == second_text,
        "results_equal": query(store, first)["result"] == query(store, second)["result"],
        "task_count": len(store["tasks"]),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
