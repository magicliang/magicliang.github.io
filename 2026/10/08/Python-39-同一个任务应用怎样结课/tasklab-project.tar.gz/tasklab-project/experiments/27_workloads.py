import json
from threading import Event, Thread
from time import perf_counter_ns

from tasklab import create_store, query, run, submit
from tasklab.workloads import cpu_work


text = "One two one"
store = create_store()
plain = submit(store, "word_count", text)
cpu_task = submit(store, "word_count", text)
wait_task = submit(store, "word_count", text)
baseline = run(store, plain)

started = perf_counter_ns()
checksum = cpu_work(text, iterations=20000)
after_work = perf_counter_ns()
cpu_result = run(store, cpu_task, workload=lambda input_text: cpu_work(input_text, iterations=20000))
after_task = perf_counter_ns()
assert cpu_result == baseline
print(json.dumps({"case": "cpu", "checksum": checksum, "work_ns": after_work - started,
                  "task_ns": after_task - after_work, "result": cpu_result}))

entered = Event()
release = Event()
completed = Event()
state = {}


def wait_for_release(_text):
    state["entered_ns"] = perf_counter_ns()
    entered.set()
    if not release.wait(5):
        raise TimeoutError("release not set")
    state["released_ns"] = perf_counter_ns()


def execute():
    try:
        state["result"] = run(store, wait_task, workload=wait_for_release)
    finally:
        state["ended_ns"] = perf_counter_ns()
        completed.set()


worker = Thread(target=execute)
worker.start()
try:
    assert entered.wait(5) and query(store, wait_task)["state"] == "running"
    state["observed_ns"] = perf_counter_ns()
    assert not completed.is_set()
finally:
    release.set()
    worker.join(5)
assert not worker.is_alive() and completed.is_set()
assert state["result"] == baseline
assert state["entered_ns"] <= state["observed_ns"] <= state["released_ns"] <= state["ended_ns"]
print(json.dumps({"case": "wait", "timeline_ns": state,
                  "final_state": query(store, wait_task)["state"]}))
