import json

from tasklab import create_store, query, run, submit
from tasklab.serialization import TaskFormatError, decode_task, encode_task


store = create_store()
task_id = submit(store, "word_count", "一 二 一", metadata={"labels": ["示例"]})
run(store, task_id)
document = encode_task(task_id, query(store, task_id))
restored_id, snapshot = decode_task(document)
assert restored_id == task_id and snapshot == query(store, task_id)
print(json.dumps({"case": "round_trip", "document": document,
                  "restored": snapshot}, ensure_ascii=False))

for name, change in (
    ("missing_version", lambda data: data.pop("version")),
    ("unknown_version", lambda data: data.update(version=2)),
    ("wrong_text", lambda data: data.update(text=42)),
    ("wrong_result", lambda data: data.update(result={"一": True})),
    ("state_conflict", lambda data: data.update(state="cancelled")),
    ("extra_field", lambda data: data.update(command="run")),
):
    payload = json.loads(document)
    change(payload)
    try:
        decode_task(json.dumps(payload, ensure_ascii=False))
    except TaskFormatError as error:
        print(json.dumps({"case": name, "rejected": str(error)}, ensure_ascii=False))
    else:
        raise AssertionError(f"{name} was accepted")

for name, raw in (("malformed", "{"), ("duplicate", '{"version":1,"version":2}'),
                  ("nonfinite", document.replace('"version": 1', '"version": NaN'))):
    try:
        decode_task(raw)
    except TaskFormatError as error:
        print(json.dumps({"case": name, "rejected": str(error)}, ensure_ascii=False))
    else:
        raise AssertionError(f"{name} was accepted")
