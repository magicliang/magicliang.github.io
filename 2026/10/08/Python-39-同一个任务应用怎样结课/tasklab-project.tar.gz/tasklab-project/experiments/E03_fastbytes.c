#define PY_SSIZE_T_CLEAN
#include <Python.h>

static PyObject *fast_checksum(PyObject *self, PyObject *args) {
    PyObject *data;
    PyObject *iterations_object;
    Py_buffer view;
    Py_ssize_t iterations;
    long long checksum = 0;

    if (!PyArg_ParseTuple(args, "OO", &data, &iterations_object)) {
        return NULL;
    }
    if (!PyBytes_CheckExact(data)) {
        PyErr_SetString(PyExc_TypeError, "data must be exact bytes");
        return NULL;
    }
    if (!PyLong_CheckExact(iterations_object)) {
        PyErr_SetString(PyExc_TypeError, "iterations must be an int");
        return NULL;
    }
    iterations = PyLong_AsSsize_t(iterations_object);
    if (iterations == -1 && PyErr_Occurred()) {
        return NULL;
    }
    if (iterations < 0) {
        PyErr_SetString(PyExc_ValueError, "iterations must be nonnegative");
        return NULL;
    }
    if (PyObject_GetBuffer(data, &view, PyBUF_SIMPLE) < 0) {
        return NULL;
    }
    for (Py_ssize_t round = 0; round < iterations; round++) {
        const unsigned char *bytes = (const unsigned char *)view.buf;
        for (Py_ssize_t index = 0; index < view.len; index++) {
            checksum = (checksum * 33 + bytes[index]) % 1000000007;
        }
    }
    PyBuffer_Release(&view);
    return PyLong_FromLongLong(checksum);
}

static PyMethodDef methods[] = {
    {"checksum", fast_checksum, METH_VARARGS, "Compute the tasklab ASCII checksum."},
    {NULL, NULL, 0, NULL}
};

static PyModuleDef_Slot slots[] = {
#if PY_VERSION_HEX >= 0x030D0000
    {Py_mod_gil, Py_MOD_GIL_NOT_USED},
#endif
    {0, NULL}
};

static struct PyModuleDef module = {
    PyModuleDef_HEAD_INIT,
    "_fastbytes",
    NULL,
    0,
    methods,
    slots,
    NULL,
    NULL,
    NULL
};

PyMODINIT_FUNC PyInit__fastbytes(void) {
    return PyModuleDef_Init(&module);
}

