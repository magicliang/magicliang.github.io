import json

from tasklab import create_store
from tasklab.dispatch import dispatch


def main():
    store = create_store()
    task_ids = [dispatch(store, "submit", kind="word_count", text=text) for text in ("", "  ", "word")]
    for task_id in task_ids:
        dispatch(store, "run", task_id=task_id)
    results = [dispatch(store, "query", task_id=task_id)["result"] for task_id in task_ids]
    before = len(store["tasks"])
    try:
        dispatch(store, "remove", task_id=task_ids[0])
    except ValueError as error:
        unknown_error = type(error).__name__
    try:
        dispatch(store, "submit", kind="word_count", text=None)
    except TypeError as error:
        input_error = type(error).__name__
    print(json.dumps({
        "all_results": [result for result in results if result is not None],
        "lost_by_truthiness": [result for result in results if result],
        "states": [dispatch(store, "query", task_id=task_id)["state"] for task_id in task_ids],
        "unknown_error": unknown_error,
        "input_error": input_error,
        "task_count_preserved": before == len(store["tasks"]),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
