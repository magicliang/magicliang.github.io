import asyncio
import json

from tasklab import create_store, query, submit
from tasklab.async_runner import run_async


async def main():
    text = "One two one"
    store = create_store()
    task_id = submit(store, "word_count", text)
    coroutine = run_async(store, task_id)
    assert query(store, task_id)["state"] == "queued"
    task = asyncio.create_task(coroutine)
    assert query(store, task_id)["state"] == "queued"
    assert await task == {"one": 2, "two": 1}
    print(json.dumps({"case": "lazy", "before_await": "queued", "after_await": query(store, task_id)}))

    waiting_id = submit(store, "word_count", text)
    release = asyncio.Event()
    waiting = asyncio.create_task(run_async(store, waiting_id, wait_event=release))
    order = []

    async def heartbeat_during_wait():
        await asyncio.sleep(0)
        order.append("heartbeat_during_wait")

    heartbeat_task = asyncio.create_task(heartbeat_during_wait())
    await asyncio.sleep(0)
    assert query(store, waiting_id)["state"] == "running" and not waiting.done()
    await heartbeat_task
    assert order == ["heartbeat_during_wait"] and not waiting.done()
    release.set()
    assert await waiting == {"one": 2, "two": 1}
    print(json.dumps({"case": "cooperative_wait", "order": order,
                      "state": query(store, waiting_id)["state"]}))

    cpu_id = submit(store, "word_count", text)
    gate = asyncio.Event()
    order = []

    async def heartbeat():
        await gate.wait()
        order.append("heartbeat")

    async def compute():
        order.append("cpu_start")
        gate.set()
        result = await run_async(store, cpu_id, iterations=20000)
        order.append("cpu_end")
        return result

    heartbeat_task = asyncio.create_task(heartbeat())
    cpu_task = asyncio.create_task(compute())
    result = await cpu_task
    await heartbeat_task
    assert order == ["cpu_start", "cpu_end", "heartbeat"]
    assert result == {"one": 2, "two": 1}
    print(json.dumps({"case": "cpu_blocks_loop", "order": order,
                      "state": query(store, cpu_id)["state"], "result": result}))


if __name__ == "__main__":
    asyncio.run(main())
