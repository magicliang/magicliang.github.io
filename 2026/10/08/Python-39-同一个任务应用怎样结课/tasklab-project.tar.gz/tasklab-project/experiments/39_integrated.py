import asyncio
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory

import tasklab
from tasklab import cancel, create_store, query, run, submit
from tasklab.async_queue import AsyncTaskQueue
from tasklab.async_runner import run_async
from tasklab.database import SQLiteTaskGateway
from tasklab.jsonline import LoopbackService
from tasklab.process_runner import ProcessTaskRunner
from tasklab.thread_runner import ThreadTaskRunner
from tasklab.workloads import cpu_work


TEXT = "One two one"
EXPECTED = {"one": 2, "two": 1}


async def network(store):
    service = LoopbackService(store)
    host, port = await service.start()

    async def request(action):
        reader, writer = await asyncio.open_connection(host, port)
        writer.write(json.dumps(action).encode("utf-8") + b"\n")
        await writer.drain()
        reply = json.loads(await reader.readline())
        writer.close()
        await writer.wait_closed()
        return reply

    try:
        submitted = await request({"op": "submit", "kind": "word_count", "text": TEXT})
        task_id = submitted["id"]
        assert (await request({"op": "query", "id": task_id}))["task"]["state"] == "queued"
        completed = await request({"op": "run", "id": task_id})
        assert completed["result"] == EXPECTED and completed["task"]["state"] == "succeeded"
        waiting = (await request({"op": "submit", "kind": "word_count", "text": TEXT}))["id"]
        assert (await request({"op": "cancel", "id": waiting}))["task"]["state"] == "cancelled"
    finally:
        assert await service.close() == 0
    return {"result": completed["result"], "closed": True}


async def concurrent():
    store = create_store()
    task_id = submit(store, "word_count", TEXT)
    assert await run_async(store, task_id) == EXPECTED
    queue = AsyncTaskQueue(store, workers=1, waiting=1)
    await queue.start()
    queued = queue.submit_nowait("word_count", TEXT)
    await queue.close()
    assert query(store, queued)["result"] == EXPECTED
    return {"async": query(store, task_id)["state"],
            "queue": query(store, queued)["state"]}


def main():
    package = Path(tasklab.__file__).resolve()
    assert "site-packages" in str(package) and str(Path(sys.prefix)) in str(package)
    store = create_store()
    sequential = submit(store, "word_count", TEXT)
    assert run(store, sequential) == EXPECTED
    rejected = submit(store, "word_count", TEXT)
    assert cancel(store, rejected) and query(store, rejected)["state"] == "cancelled"
    with ThreadTaskRunner(store, workers=1, backlog=1) as runner:
        threaded = submit(store, "word_count", TEXT)
        assert runner.submit(threaded,
                             workload=lambda text: cpu_work(text, iterations=500)).result() == EXPECTED
    with ProcessTaskRunner(workers=1) as runner:
        processed = submit(store, "word_count", TEXT)
        assert runner.run(store, processed, iterations=500) == EXPECTED
    with TemporaryDirectory() as directory:
        gateway = SQLiteTaskGateway(Path(directory) / "tasks.db")
        persisted = gateway.submit("word_count", TEXT)
        assert SQLiteTaskGateway(gateway.path).run(persisted) == EXPECTED
        assert gateway.query(persisted)["state"] == "succeeded"
        left = gateway.submit("word_count", TEXT)
        gateway.claim(left)
        assert gateway.recover_running() == (left,)
        assert gateway.query(left)["state"] == "failed"
    print(json.dumps({"installed_package": str(package), "interpreter": sys.executable,
                      "sync": "succeeded", "thread": query(store, threaded)["state"],
                      "process": query(store, processed)["state"],
                      "sqlite_recovered": "failed", "async": asyncio.run(concurrent()),
                      "network": asyncio.run(network(create_store()))}, ensure_ascii=False))


if __name__ == "__main__":
    main()
