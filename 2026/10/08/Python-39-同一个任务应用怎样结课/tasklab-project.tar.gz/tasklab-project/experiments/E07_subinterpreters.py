import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys
from time import perf_counter_ns

from tasklab import create_store, query, run, submit
from tasklab.process_runner import ProcessTaskRunner
from tasklab.thread_runner import ThreadTaskRunner
from tasklab.workloads import cpu_work


TEXT = "one two one " * 50
ITERATIONS = 120
EXPECTED_RESULT = {"one": 100, "two": 50}
EXPECTED_CHECKSUM = 754902074


def run_local():
    store = create_store()
    task_id = submit(store, "word_count", TEXT)
    checksum = cpu_work(TEXT, iterations=ITERATIONS)
    result = run(store, task_id)
    return {"pid": os.getpid(), "task_id": task_id, "result": result,
            "state": query(store, task_id)["state"], "checksum": checksum}


def run_thread():
    store = create_store()
    task_id = submit(store, "word_count", TEXT)
    before = query(store, task_id)["state"]
    with ThreadTaskRunner(store) as runner:
        future = runner.submit(task_id, workload=lambda text: cpu_work(text, iterations=ITERATIONS))
        result = future.result(timeout=10)
    return {"pid": os.getpid(), "task_id": task_id, "state_before": before,
            "state_after": query(store, task_id)["state"], "result": result,
            "checksum": cpu_work(TEXT, iterations=ITERATIONS)}


def run_process():
    store = create_store()
    task_id = submit(store, "word_count", TEXT)
    with ProcessTaskRunner(workers=1) as runner:
        result = runner.run(store, task_id, iterations=ITERATIONS)
        trace = runner.traces[-1]
    return {"pid": os.getpid(), "task_id": task_id, "state": query(store, task_id)["state"],
            "result": result, "worker": trace,
            "checksum": cpu_work(TEXT, iterations=ITERATIONS)}


def run_subinterpreter(extension):
    import _xxsubinterpreters as interpreters

    read_fd, write_fd = os.pipe()
    interp = interpreters.create()
    code = "\n".join((
        "import builtins, json, os, sys",
        "from tasklab import create_store, query, run, submit",
        "from tasklab.workloads import cpu_work",
        f"text = {TEXT!r}",
        "store = create_store()",
        'task_id = submit(store, "word_count", text)',
        f"checksum = cpu_work(text, iterations={ITERATIONS})",
        "result = run(store, task_id)",
        'builtins.tasklab_subinterpreter_marker = "child-only"',
        'payload = {"pid": os.getpid(), "task_id": task_id, "result": result,',
        '           "state": query(store, task_id)["state"], "checksum": checksum,',
        '           "has_parent_marker": hasattr(builtins, "tasklab_parent_marker")}',
        f"os.write({write_fd}, json.dumps(payload, sort_keys=True).encode('utf-8'))",
    ))
    builtins_marker = "__not_set__"
    extension_result = {"status": "NOT_RUN"}
    previous_parent_marker = "__not_set__"
    try:
        import builtins
        previous_parent_marker = getattr(builtins, "tasklab_parent_marker", "__not_set__")
        builtins.tasklab_parent_marker = "parent-only"
        interpreters.run_string(interp, code)
        os.close(write_fd)
        with os.fdopen(read_fd, "rb") as reader:
            result = json.loads(reader.read().decode("utf-8"))
        builtins_marker = getattr(builtins, "tasklab_subinterpreter_marker", "__not_set__")
        if extension is not None:
            extension_result = check_extension_rejected(interpreters, interp, extension)
        return {"pid": os.getpid(), "interpreter_id": int(interp), "result": result,
                "parent_has_child_marker": builtins_marker != "__not_set__",
                "bytes_shareable": interpreters.is_shareable(b"payload"),
                "list_shareable": interpreters.is_shareable([b"payload"]),
                "extension": extension_result}
    finally:
        try:
            if previous_parent_marker == "__not_set__":
                try:
                    del builtins.tasklab_parent_marker
                except AttributeError:
                    pass
            else:
                builtins.tasklab_parent_marker = previous_parent_marker
            interpreters.destroy(interp)
        finally:
            for fd in (read_fd, write_fd):
                try:
                    os.close(fd)
                except OSError:
                    pass


def check_extension_rejected(interpreters, interp, extension):
    code = "\n".join((
        "import importlib.util, json",
        f"path = {str(extension)!r}",
        'spec = importlib.util.spec_from_file_location("_rejectinterp", path)',
        "module = importlib.util.module_from_spec(spec)",
        "try:",
        "    spec.loader.exec_module(module)",
        "except BaseException as error:",
        '    payload = {"loaded": False, "error_type": type(error).__name__, "error": str(error)}',
        "else:",
        '    payload = {"loaded": True}',
        "raise RuntimeError(json.dumps(payload, sort_keys=True))",
    ))
    try:
        interpreters.run_string(interp, code)
    except interpreters.RunFailedError as error:
        message = str(error)
        start = message.find("{")
        if start >= 0:
            return json.loads(message[start:])
        return {"loaded": False, "error_type": "RunFailedError", "error": message}
    return {"loaded": True}


def validate_local(payload):
    assert payload["result"] == EXPECTED_RESULT
    assert payload["state"] == "succeeded"
    assert payload["checksum"] == EXPECTED_CHECKSUM


def validate_thread(payload):
    assert payload["state_before"] == "queued"
    assert payload["state_after"] == "succeeded"
    assert payload["result"] == EXPECTED_RESULT
    assert payload["checksum"] == EXPECTED_CHECKSUM


def validate_process(payload):
    assert payload["state"] == "succeeded"
    assert payload["result"] == EXPECTED_RESULT
    assert payload["checksum"] == EXPECTED_CHECKSUM
    assert payload["worker"]["result"] == EXPECTED_RESULT
    assert payload["worker"]["state"] == "succeeded"
    assert payload["worker"]["pid"] != payload["pid"]


def validate_subinterpreter(payload, extension_required):
    child = payload["result"]
    assert child["result"] == EXPECTED_RESULT
    assert child["state"] == "succeeded"
    assert child["checksum"] == EXPECTED_CHECKSUM
    assert child["has_parent_marker"] is False
    assert payload["parent_has_child_marker"] is False
    assert payload["bytes_shareable"] is True
    assert payload["list_shareable"] is False
    if extension_required:
        assert payload["extension"]["loaded"] is False
        assert "does not support loading in subinterpreters" in payload["extension"].get("error", "")


def timed(callable_, validator, *, repeats=5, warmups=1):
    warmup_ns = []
    last = None
    for _ in range(warmups):
        start = perf_counter_ns()
        last = callable_()
        warmup_ns.append(perf_counter_ns() - start)
        validator(last)
    samples = []
    for _ in range(repeats):
        start = perf_counter_ns()
        last = callable_()
        samples.append(perf_counter_ns() - start)
        validator(last)
    return {"warmup_ns": warmup_ns, "samples_ns": samples, "last": last}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--reject-extension", type=Path)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    result = {
        "python": sys.version,
        "executable": sys.executable,
        "sample_contract": "one warmup call is validated before five timed samples; every sample validates result, checksum and isolation fields",
        "local": timed(run_local, validate_local),
        "thread": timed(run_thread, validate_thread),
        "process": timed(run_process, validate_process),
        "subinterpreter": timed(lambda: run_subinterpreter(args.reject_extension),
                                lambda payload: validate_subinterpreter(payload, args.reject_extension is not None)),
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(result)


if __name__ == "__main__":
    main()
