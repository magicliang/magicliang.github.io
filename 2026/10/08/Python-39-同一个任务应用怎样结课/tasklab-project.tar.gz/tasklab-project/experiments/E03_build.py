import argparse
import json
from pathlib import Path
import shlex
import subprocess
import sys
import sysconfig


def build(source: Path, output_dir: Path):
    output_dir.mkdir(parents=True, exist_ok=True)
    suffix = sysconfig.get_config_var("EXT_SUFFIX")
    include = sysconfig.get_path("include")
    cc = shlex.split(sysconfig.get_config_var("CC") or "cc")
    cflags = shlex.split(sysconfig.get_config_var("CFLAGS") or "")
    ldshared = shlex.split(sysconfig.get_config_var("LDSHARED") or "cc -shared")
    stem = source.stem
    obj = output_dir / f"{stem}.o"
    ext = output_dir / f"{stem}{suffix}"
    compile_cmd = [*cc, *cflags, "-I", include, "-c", str(source), "-o", str(obj)]
    link_cmd = [*ldshared, str(obj), "-o", str(ext)]
    subprocess.run(compile_cmd, check=True)
    subprocess.run(link_cmd, check=True)
    return {"source": str(source), "object": str(obj), "extension": str(ext),
            "python": sys.version, "py_gil_disabled": sysconfig.get_config_var("Py_GIL_DISABLED"),
            "compile": compile_cmd, "link": link_cmd}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.source, args.out), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
