import json

from tasklab.typed import MemoryTaskGateway, TaskGateway


service: TaskGateway = MemoryTaskGateway()
task_id = service.submit("word_count", "One two one")
assert service.run(task_id) == {"one": 2, "two": 1}
assert service.query(task_id)["state"] == "succeeded"

untrusted = json.loads('{"kind":"word_count","text":42}')
other = MemoryTaskGateway()
try:
    other.submit(untrusted["kind"], untrusted["text"])
except TypeError as error:
    print(f"runtime_rejected: {type(error).__name__}: {error}")
else:
    raise AssertionError("invalid JSON text was accepted")
assert other.store["tasks"] == {}
print(f"static_positive: {task_id} {service.query(task_id)['result']}")
