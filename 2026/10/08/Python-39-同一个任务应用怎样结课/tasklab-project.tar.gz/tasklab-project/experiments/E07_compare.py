import argparse
import json
from pathlib import Path
import subprocess
import sys


def run(command, cwd):
    completed = subprocess.run(command, cwd=cwd, text=True, capture_output=True)
    return {"command": command, "returncode": completed.returncode,
            "stdout": completed.stdout, "stderr": completed.stderr}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    experiments = args.repo / "experiments"
    build = run([sys.executable, str(experiments / "E03_build.py"),
                 str(experiments / "E07_reject.c"), "--out", str(args.out)], args.repo)
    extension = None
    if build["returncode"] == 0:
        extension = json.loads(build["stdout"])["extension"]
    compare_cmd = [sys.executable, str(experiments / "E07_subinterpreters.py"), "--json"]
    if extension is not None:
        compare_cmd.extend(["--reject-extension", extension])
    compare = run(compare_cmd, args.repo)
    print(json.dumps({"build": build, "compare": compare}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
