import json
from pathlib import Path
from tempfile import TemporaryDirectory

from tasklab import create_store, run, submit
from tasklab.resources import count_file, open_word_file


def main():
    with TemporaryDirectory() as directory:
        path = Path(directory) / "generated.txt"
        path.write_text("One two one", encoding="utf-8")
        normal = count_file(path)
        with open_word_file(path) as (words, early_source):
            first = next(words)
        early_closed = early_source.closed
        try:
            with open_word_file(path) as (words, failure_source):
                next(words)
                raise RuntimeError("synthetic consumer error")
        except RuntimeError as error:
            failure = str(error)
        failure_closed = failure_source.closed
        store = create_store()
        baseline = run(store, submit(store, "word_count", "One two one"))
        print(json.dumps({
            "normal": normal,
            "first": first,
            "early_closed": early_closed,
            "failure_closed": failure_closed,
            "failure_propagated": failure,
            "matches_task_baseline": normal == baseline,
        }, sort_keys=True))


if __name__ == "__main__":
    main()
