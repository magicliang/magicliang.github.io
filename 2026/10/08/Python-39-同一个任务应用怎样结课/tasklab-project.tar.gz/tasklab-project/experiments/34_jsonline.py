import asyncio
import json

from tasklab import create_store, task_ids
from tasklab.jsonline import LoopbackService


async def main():
    store = create_store()
    service = LoopbackService(store, max_frame=2048)
    host, port = await service.start()

    async def request(document):
        reader, writer = await asyncio.open_connection(host, port)
        writer.write(json.dumps(document, ensure_ascii=False).encode("utf-8") + b"\n")
        await writer.drain()
        reply = json.loads(await reader.readline())
        writer.close()
        await writer.wait_closed()
        return reply

    try:
        submitted = await request({"op": "submit", "kind": "word_count", "text": "One two one"})
        task_id = submitted["id"]
        before = await request({"op": "query", "id": task_id})
        assert before["task"]["state"] == "queued"
        completed = await request({"op": "run", "id": task_id})
        assert completed["result"] == {"one": 2, "two": 1}
        assert completed["task"]["state"] == "succeeded"
        print(json.dumps({"case": "ack_vs_result", "submit": submitted,
                          "query_before_run": before["task"]["state"],
                          "run": completed["result"]}))

        reader, writer = await asyncio.open_connection(host, port)
        writer.write(b'{"op":"submit","kind":"word_count","text":"One')
        await writer.drain()
        assert len(task_ids(store)) == 1
        writer.write(b' two one"}\n')
        partial = json.loads(await reader.readline())
        assert partial["ok"] and len(task_ids(store)) == 2
        writer.close()
        await writer.wait_closed()

        reader, writer = await asyncio.open_connection(host, port)
        writer.write(b'a' * 3000 + b'\n')
        too_long = json.loads(await reader.readline())
        assert too_long["error"] == "frame too long"
        writer.close()
        await writer.wait_closed()
        print(json.dumps({"case": "framing", "partial_then_complete": partial["ok"],
                          "oversize": too_long["error"], "task_count": len(task_ids(store))}))
    finally:
        await service.close()


if __name__ == "__main__":
    asyncio.run(main())
