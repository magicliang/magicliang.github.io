import argparse
import importlib.util
import json
from pathlib import Path
from statistics import median
from time import perf_counter_ns
import subprocess
import sys
import threading
import sysconfig
import tracemalloc

from tasklab import create_store, query, run, submit
from tasklab.workloads import cpu_work


def load_extension(path):
    spec = importlib.util.spec_from_file_location("_fastbytes", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load extension from {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class PythonFallbackExtension:
    name = "python-fallback"

    @staticmethod
    def checksum(data, iterations):
        if type(data) is not bytes:
            raise TypeError("a bytes-like object is required")
        if type(iterations) is not int:
            raise TypeError("iterations must be an int")
        if iterations < 0:
            raise ValueError("iterations must be nonnegative")
        if iterations > sys.maxsize:
            raise OverflowError("iterations too large")
        return cpu_work(data.decode("ascii"), iterations=iterations)


def compute(text, iterations, extension):
    try:
        data = text.encode("ascii")
    except UnicodeEncodeError:
        return cpu_work(text, iterations=iterations)
    return extension.checksum(data, iterations)


def timed(callable_, expected, repeats=5, warmups=1):
    warmup_values = []
    result = None
    for _ in range(warmups):
        start = perf_counter_ns()
        result = callable_()
        warmup_values.append(perf_counter_ns() - start)
        assert result == expected, (result, expected)
    values = []
    for _ in range(repeats):
        start = perf_counter_ns()
        result = callable_()
        values.append(perf_counter_ns() - start)
        assert result == expected, (result, expected)
    return {"warmup_runs": warmups, "warmup_ns": warmup_values,
            "samples_ns": values, "median_ns": median(values), "last_result": result}


def run_checks(extension):
    positive = []
    for text in ("one two one", "", "e one", "ASCII\tspace\n"):
        for iterations in (0, 1, 13):
            expected = cpu_work(text, iterations=iterations)
            actual = compute(text, iterations, extension)
            assert actual == expected, (text, iterations, actual, expected)
            positive.append({"text": text, "iterations": iterations, "result": actual})
    for text in ("é one", "漢字 A"):
        assert compute(text, 13, extension) == cpu_work(text, iterations=13)
        positive.append({"text": text, "iterations": 13, "result": "python-fallback"})

    negative = []
    class BytesChild(bytes):
        pass
    for value in (bytearray(b"one"), "one", BytesChild(b"one")):
        try:
            extension.checksum(value, 1)
        except TypeError as error:
            negative.append({"input": type(value).__name__, "error": str(error)})
        else:
            raise AssertionError("mutable or text input was accepted")
    for iterations in (True, -1, 10 ** 100):
        try:
            extension.checksum(b"one", iterations)
        except (OverflowError, TypeError, ValueError) as error:
            negative.append({"iterations": repr(iterations), "error": str(error)})
        else:
            raise AssertionError("bad iteration count was accepted")

    store = create_store()
    task_id = submit(store, "word_count", "one two one")
    result = run(store, task_id, workload=lambda text: compute(text, 13, extension))
    assert result == {"one": 2, "two": 1}
    assert query(store, task_id)["state"] == "succeeded"
    return {"positive": positive, "negative": negative, "task_state": query(store, task_id)}


def concurrent_read_probe(extension):
    data = ("one two one " * 50).encode("ascii")
    iterations = 120
    barrier = threading.Barrier(3)
    results = []
    errors = []
    lock = threading.Lock()

    def worker():
        try:
            barrier.wait(timeout=5)
            value = extension.checksum(data, iterations)
            with lock:
                results.append(value)
        except BaseException as error:
            with lock:
                errors.append(f"{type(error).__name__}: {error}")

    threads = [threading.Thread(target=worker) for _ in range(2)]
    before = getattr(sys, "_is_gil_enabled", lambda: None)()
    for thread in threads:
        thread.start()
    barrier.wait(timeout=5)
    for thread in threads:
        thread.join(timeout=10)
    after = getattr(sys, "_is_gil_enabled", lambda: None)()
    expected = cpu_work(data.decode("ascii"), iterations=iterations)
    assert errors == [], errors
    assert results == [expected, expected] or sorted(results) == [expected, expected]
    return {"results": results, "expected": expected, "errors": errors,
            "gil_enabled_before": before, "gil_enabled_after": after}


def legacy_gil_probe(path):
    if path is None:
        return {"status": "NOT_RUN", "reason": "legacy extension path was not supplied"}
    code = (
        "import importlib.util, json, sys; "
        "path = sys.argv[1]; "
        "state = {'before': getattr(sys, '_is_gil_enabled', lambda: None)()}; "
        "spec = importlib.util.spec_from_file_location('legacyprobe', path); "
        "module = importlib.util.module_from_spec(spec); "
        "spec.loader.exec_module(module); "
        "state['after'] = getattr(sys, '_is_gil_enabled', lambda: None)(); "
        "print(json.dumps(state, sort_keys=True))"
    )
    completed = subprocess.run([sys.executable, "-c", code, str(path)],
                               text=True, capture_output=True)
    if completed.returncode != 0:
        return {"status": "FAIL", "returncode": completed.returncode,
                "stdout": completed.stdout.strip(), "stderr": completed.stderr.strip()}
    state = json.loads(completed.stdout)
    assert state == {"before": False, "after": True}, state
    return {"status": "PASS", "returncode": completed.returncode,
            "stdout": completed.stdout.strip(),
            "stderr": completed.stderr.strip(),
            "assertion": "sys._is_gil_enabled changed from false to true"}


def refcount_probe(extension):
    data = b"one two one"
    before = sys.getrefcount(data)
    tracemalloc.start()
    for _ in range(10000):
        extension.checksum(data, 2)
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    after = sys.getrefcount(data)
    assert before == after, (before, after)
    return {"before": before, "after": after, "tracemalloc_current": current,
            "tracemalloc_peak": peak}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--extension", type=Path)
    parser.add_argument("--legacy-extension", type=Path)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    gil_enabled_before_import = getattr(sys, "_is_gil_enabled", lambda: None)()
    extension = load_extension(args.extension) if args.extension else PythonFallbackExtension()
    gil_enabled_after_import = getattr(sys, "_is_gil_enabled", lambda: None)()
    payload = "one two one " * 50
    iterations = 120
    expected_timing = cpu_work(payload, iterations=iterations)
    result = {
        "python": sys.version,
        "executable": sys.executable,
        "py_gil_disabled": sysconfig.get_config_var("Py_GIL_DISABLED"),
        "extension": str(args.extension) if args.extension else "NOT_RUN; Python fallback used because extension path was not supplied",
        "gil_enabled_before_import": gil_enabled_before_import,
        "gil_enabled_after_import": gil_enabled_after_import,
        "checks": run_checks(extension),
        "timing": {
            "python": timed(lambda: cpu_work(payload, iterations=iterations), expected_timing),
            "extension": timed(lambda: compute(payload, iterations, extension), expected_timing),
        },
        "refcount": refcount_probe(extension),
        "concurrent_read": concurrent_read_probe(extension),
        "legacy_gil": legacy_gil_probe(args.legacy_extension),
        "gil_enabled_after": getattr(sys, "_is_gil_enabled", lambda: None)(),
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(result)


if __name__ == "__main__":
    main()
