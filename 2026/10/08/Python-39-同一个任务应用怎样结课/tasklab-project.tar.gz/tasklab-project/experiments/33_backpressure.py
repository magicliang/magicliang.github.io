import asyncio
import json

from tasklab import cancel, create_store, query, task_ids
from tasklab.async_queue import AsyncTaskQueue, BusyError


async def main():
    store = create_store()
    gate = asyncio.Event()
    queue = AsyncTaskQueue(store, workers=2, waiting=1, wait_event=gate)
    await queue.start()
    started = [asyncio.Event(), asyncio.Event()]
    first = queue.submit_nowait("word_count", "One two one", started_event=started[0])
    await started[0].wait()
    second = queue.submit_nowait("word_count", "One two one", started_event=started[1])
    await started[1].wait()
    third = queue.submit_nowait("word_count", "One two one")
    before = queue.snapshot()
    assert before == {"admitted": 3, "running": 2, "queued": 1, "capacity": 3}
    try:
        queue.submit_nowait("word_count", "One two one")
    except BusyError:
        rejected = True
    else:
        raise AssertionError("admission must be bounded")
    assert len(task_ids(store)) == 3
    print(json.dumps({"case": "slow_consumer", "snapshot": before,
                      "rejected": rejected, "task_count": len(task_ids(store))}))

    assert cancel(store, third) and query(store, third)["state"] == "cancelled"
    assert queue.snapshot()["admitted"] == 3
    gate.set()
    await queue.join()
    assert queue.snapshot()["admitted"] == 0
    assert query(store, first)["state"] == query(store, second)["state"] == "succeeded"
    assert query(store, third)["result"] is None
    fourth = queue.submit_nowait("word_count", "One two one")
    await queue.close()
    assert query(store, fourth)["state"] == "succeeded"
    print(json.dumps({"case": "capacity_released", "snapshot": queue.snapshot(),
                      "states": [query(store, task_id)["state"]
                                 for task_id in (first, second, third, fourth)]}))


if __name__ == "__main__":
    asyncio.run(main())
