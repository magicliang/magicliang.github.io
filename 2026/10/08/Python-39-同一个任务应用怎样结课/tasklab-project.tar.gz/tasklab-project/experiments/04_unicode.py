import json

from tasklab import create_store, query, run, submit, submit_bytes


def main():
    store = create_store()
    text = "你好 世界"
    task_id = submit_bytes(store, "word_count", text.encode("utf-8"))
    run(store, task_id)
    rejections = []
    for raw_bytes in (b"\xff", ("汉" * 342).encode("utf-8")):
        try:
            submit_bytes(store, "word_count", raw_bytes)
        except (UnicodeDecodeError, ValueError) as error:
            rejections.append(type(error).__name__)
    try:
        int("12x")
    except ValueError as error:
        numeric_error = type(error).__name__
    print(json.dumps({
        "characters": len(text),
        "utf8_bytes": len(text.encode("utf-8")),
        "round_trip": text.encode("utf-8").decode("utf-8") == text,
        "result": query(store, task_id)["result"],
        "rejections": rejections,
        "numeric_error": numeric_error,
        "task_count": len(store["tasks"]),
        "next_id": submit(store, "word_count", "ok"),
    }, sort_keys=True, ensure_ascii=False))


if __name__ == "__main__":
    main()
