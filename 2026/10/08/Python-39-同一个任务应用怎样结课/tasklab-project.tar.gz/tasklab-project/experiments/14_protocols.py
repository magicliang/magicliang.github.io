import json

from tasklab import create_store, query, run, submit
from tasklab.model import TaskResult


def main():
    store = create_store()
    task_id = submit(store, "word_count", "one one two")
    counts = run(store, task_id)
    task = store["tasks"][task_id]
    result = task.result
    try:
        task.state = "ghost"
    except ValueError as error:
        invalid_error = type(error).__name__
    print(json.dumps({
        "repr": repr(result),
        "distinct_words": len(result),
        "direct_len": TaskResult.__len__(result),
        "total_words": result.total,
        "counts": counts,
        "invalid_error": invalid_error,
        "state_after_rejection": query(store, task_id)["state"],
    }, sort_keys=True))


if __name__ == "__main__":
    main()
