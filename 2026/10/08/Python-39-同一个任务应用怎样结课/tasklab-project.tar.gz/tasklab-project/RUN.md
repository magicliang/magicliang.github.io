# tasklab 累计工程的重放入口

仓库内的完成状态只看 `writing-plans/Python-从对象模型到并发与工程实践-系列写作计划.md`；本文件仅说明重放命令，不建立另一份逐篇进度表。默认命令使用 `PYTHON` 环境变量，未设置时回落到 `python3`；需要复跑历史 Ubuntu/CPython 3.12.3 证据时，显式设置 `PYTHON` 为对应解释器路径。只处理固定白名单词频任务，不提供不可信代码执行。

```sh
cd examples/python-language
PYTHON=${PYTHON:-python3}
PYTHONPATH=src "$PYTHON" -m unittest discover -s tests -v
```

`experiments/39_integrated.py` 故意要求安装在独立环境，从源码树带 `PYTHONPATH` 运行会触发安装位置断言，不能把这个预期失败当作安装验收。新制品需从当前源码使用冻结的 `build==1.3.0`、`setuptools==80.9.0`、`wheel==0.45.1` 和 `build-requirements.lock` 准备的构建环境重建；25 的旧 `artifacts/` 不能代表 27 之后的代码。下面命令只假设已有一个带 pip 和固定构建工具的构建解释器：

```sh
cd examples/python-language
PROJECT_ROOT=$(pwd)
BUILD_PYTHON=${BUILD_PYTHON:-python3}
PYTHON=${PYTHON:-python3}
"$BUILD_PYTHON" -m build --no-isolation --outdir /tmp/tasklab-new-dist
"$PYTHON" -m venv --without-pip /tmp/tasklab-new-venv
"$BUILD_PYTHON" -m pip --python /tmp/tasklab-new-venv/bin/python install --no-deps /tmp/tasklab-new-dist/tasklab-0.1.0-py3-none-any.whl
cd /tmp
env -u PYTHONPATH /tmp/tasklab-new-venv/bin/python "$PROJECT_ROOT/experiments/39_integrated.py"
env -u PYTHONPATH /tmp/tasklab-new-venv/bin/python -m unittest discover -s "$PROJECT_ROOT/tests" -v
```

若从文章素材的归档解包，把 `PROJECT_ROOT` 设为解包得到的 `tasklab-project/`；建议另用一个此前不存在的制品输出目录和虚拟环境。`tasklab` 命令与模块必须从新 venv 的 `site-packages` 装入，不设置 `PYTHONPATH`。目标 venv 没装 pip 仍能由独立的 pip 工具执行安装；构建工具的版本、锁定哈希与目标解释器分别核对。

局部页面验收可在仓库根执行 `PATH=/opt/cloudcli/node/bin:$PATH sh examples/python-language/tools/build_selected_pages.sh /tmp/new-absent-output-dir`，脚本拒绝已存在目录并检查每个 Python 导航链接和 SVG。它不等于全站生成。free-threaded 补充实验见 38 的证据及 `VERSIONS.md`，不能将 3.12 普通构建结果替代为 3.13.9t 的 SQLite 或扩展兼容测试。
