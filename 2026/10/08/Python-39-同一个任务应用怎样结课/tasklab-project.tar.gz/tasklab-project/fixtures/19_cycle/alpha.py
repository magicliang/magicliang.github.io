from beta import ready


ready = True
