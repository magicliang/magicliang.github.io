sentinel = "shadow module, not the tasklab package"
