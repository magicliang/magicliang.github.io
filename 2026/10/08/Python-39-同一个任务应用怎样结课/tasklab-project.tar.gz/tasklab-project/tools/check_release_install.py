import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

import tasklab


assert str(Path(sys.prefix)) in str(Path(tasklab.__file__))
command = Path(sys.prefix) / "bin" / "tasklab"
environment = os.environ.copy()
environment.pop("PYTHONPATH", None)


def invoke(database, *arguments, expected_exit):
    outcome = subprocess.run([command, "--db", database, *map(str, arguments)],
                             env=environment, capture_output=True, text=True, check=False)
    print(json.dumps({"case": list(map(str, arguments)), "exit": outcome.returncode,
                      "stdout": outcome.stdout, "stderr": outcome.stderr}, ensure_ascii=False))
    assert outcome.returncode == expected_exit
    if expected_exit:
        assert not outcome.stdout and outcome.stderr
    else:
        assert not outcome.stderr
    return json.loads(outcome.stdout) if not expected_exit else None


with TemporaryDirectory() as directory:
    database = str(Path(directory) / "matrix.sqlite")
    bad = Path(directory) / "bad.txt"
    bad.write_bytes(b"\xff")
    good = invoke(database, "submit", "--text", "字 字", expected_exit=0)
    finished = invoke(database, "run", good["id"], expected_exit=0)
    assert finished["result"] == {"字": 2}
    assert invoke(database, "query", good["id"], expected_exit=0) == finished
    invoke(database, "submit", "--file", bad, expected_exit=2)
    assert invoke(database, "query", good["id"], expected_exit=0) == finished

print(json.dumps({"python": sys.version.split()[0], "interpreter": sys.executable,
                  "module": tasklab.__file__, "PYTHONPATH": environment.get("PYTHONPATH")},
                 ensure_ascii=False))
