import json
from pathlib import Path
import sys
import tarfile
import zipfile


directory = Path(sys.argv[1])
wheel, = directory.glob("tasklab-0.1.0-*.whl")
source, = directory.glob("tasklab-0.1.0.tar.gz")
with zipfile.ZipFile(wheel) as archive:
    wheel_files = set(archive.namelist())
    entry_point, = (name for name in wheel_files if name.endswith(".dist-info/entry_points.txt"))
    assert "tasklab = tasklab.db_cli:main" in archive.read(entry_point).decode()
    assert "tasklab/database.py" in wheel_files and "tasklab/cli.py" in wheel_files
    assert "tasklab/serialization.py" in wheel_files
    assert not any(name.startswith(("tests/", "fixtures/")) for name in wheel_files)

with tarfile.open(source, "r:gz") as archive:
    source_files = set(archive.getnames())
    assert "tasklab-0.1.0/pyproject.toml" in source_files
    assert "tasklab-0.1.0/src/tasklab/db_cli.py" in source_files
    assert "tasklab-0.1.0/README.md" in source_files

print(json.dumps({"wheel": wheel.name, "wheel_files": len(wheel_files),
                  "sdist": source.name, "sdist_files": len(source_files),
                  "console_script": "tasklab = tasklab.db_cli:main"}, sort_keys=True))
