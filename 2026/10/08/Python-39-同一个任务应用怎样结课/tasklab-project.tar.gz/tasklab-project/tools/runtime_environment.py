from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import platform
import sqlite3
import sys
import sysconfig


def main():
    binary = Path(sys.executable).resolve()
    runtime_gil = sys._is_gil_enabled() if hasattr(sys, '_is_gil_enabled') else 'API_UNAVAILABLE'
    with ThreadPoolExecutor(max_workers=1) as executor:
        thread_result = executor.submit(lambda: sum(range(100))).result()
    assert thread_result == 4950
    with sqlite3.connect(':memory:') as connection:
        assert connection.execute('select 1').fetchone() == (1,)
    print(json.dumps({'python': sys.version, 'implementation': platform.python_implementation(),
                      'executable': str(binary), 'executable_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
                      'platform': platform.platform(), 'compiler': platform.python_compiler(),
                      'config_args': sysconfig.get_config_var('CONFIG_ARGS'),
                      'py_gil_disabled_build': sysconfig.get_config_var('Py_GIL_DISABLED'),
                      'runtime_gil_enabled': runtime_gil, 'sqlite': sqlite3.sqlite_version,
                      'sqlite_module': sqlite3.__file__, 'thread_result': thread_result,
                      'source_provenance': 'binary distribution; exact downstream source commit not inferred'}))


if __name__ == '__main__':
    main()
