import json
import os
from pathlib import Path
import subprocess
import sys
import sqlite3
from tempfile import TemporaryDirectory

import tasklab


assert "site-packages" in str(Path(tasklab.__file__))
assert str(Path(sys.prefix)) in str(Path(tasklab.__file__))
console = Path(sys.prefix) / "bin" / "tasklab"
environment = os.environ.copy()
environment.pop("PYTHONPATH", None)


def invoke(database, *arguments, expected_exit):
    outcome = subprocess.run([console, "--db", database, *arguments], env=environment,
                             capture_output=True, text=True, check=False)
    print(json.dumps({"command": arguments, "exit": outcome.returncode,
                      "stdout": outcome.stdout, "stderr": outcome.stderr}, ensure_ascii=False))
    assert outcome.returncode == expected_exit
    if expected_exit:
        assert not outcome.stdout and outcome.stderr
    else:
        assert not outcome.stderr
    return json.loads(outcome.stdout) if not expected_exit else None


with TemporaryDirectory() as directory:
    database = str(Path(directory) / "tasklab.sqlite")
    submitted = invoke(database, "submit", "--text", "One two one", expected_exit=0)
    assert submitted["state"] == "queued"
    task_id = submitted["id"]
    finished = invoke(database, "run", task_id, expected_exit=0)
    assert finished["result"] == {"one": 2, "two": 1}
    assert invoke(database, "query", task_id, expected_exit=0) == finished
    cancelled = invoke(database, "submit", "--text", "two", expected_exit=0)
    assert invoke(database, "cancel", cancelled["id"], expected_exit=0)["state"] == "cancelled"
    invoke(database, "run", task_id, expected_exit=2)
    invoke(database, "submit", "--kind", "shell", "--text", "one", expected_exit=2)
    with sqlite3.connect(database) as connection:
        rows = connection.execute('SELECT id, state, result FROM tasks ORDER BY id').fetchall()
        assert len(rows) == 2 and [row[1] for row in rows] == ['succeeded', 'cancelled']
        integrity = connection.execute('PRAGMA integrity_check').fetchone()[0]
        assert integrity == 'ok'
        print(json.dumps({'sqlite_rows': rows, 'integrity': integrity}))

print(json.dumps({"installed_package": tasklab.__file__, "console": str(console),
                  "python": sys.executable, "PYTHONPATH": environment.get("PYTHONPATH")}))
