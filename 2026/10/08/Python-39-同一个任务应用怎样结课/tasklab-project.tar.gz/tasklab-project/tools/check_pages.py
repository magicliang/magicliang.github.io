import json
import sys
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.images = []
        self.links = []
        self.ids = set()

    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        if 'id' in attributes:
            self.ids.add(attributes['id'])
        if tag == "img":
            image = attributes.get("data-lazy-src", attributes.get("src"))
            if image is not None:
                self.images.append(image)
        if tag == "a" and "href" in attributes:
            self.links.append(attributes["href"])


def main(source_dir, public_dir):
    nav_file = public_dir / "python-language/index.html"
    if not nav_file.is_file():
        raise FileNotFoundError(nav_file)
    nav = Links()
    nav.feed(nav_file.read_text(encoding="utf-8"))
    verified = []
    for post in sorted(source_dir.glob("????-??-??-Python-*.md")):
        date = post.stem[:10].replace("-", "/")
        slug = post.stem[11:]
        page_path = f"/{date}/{slug}/"
        page = public_dir / date / slug / "index.html"
        if not page.is_file():
            raise FileNotFoundError(page)
        if page_path not in [unquote(urlsplit(link).path) for link in nav.links]:
            raise AssertionError(f"navigation missing {page_path}")
        page_links = Links()
        page_links.feed(page.read_text(encoding="utf-8"))
        body = page.read_text(encoding='utf-8')
        assert '预测题' in body and '变更题' in body and '答案' in body, post.name
        assets = list((source_dir / post.stem).glob('*.svg'))
        assert len(assets) == 1, (post.name, 'missing chapter figure')
        checked_links = 0
        for link in page_links.links:
            parts = urlsplit(link)
            if parts.scheme or parts.netloc or not parts.path.startswith('/'):
                continue
            path = unquote(parts.path)
            if '/Python-' not in path and path != '/python-language/':
                continue
            target = public_dir / path.lstrip('/')
            if path.endswith('/'):
                target = target / 'index.html'
            assert target.is_file(), (post.name, link)
            if parts.fragment:
                target_links = Links()
                target_links.feed(target.read_text(encoding='utf-8'))
                assert unquote(parts.fragment) in target_links.ids, (post.name, link)
            checked_links += 1
        for asset in sorted((source_dir / post.stem).glob("*.svg")):
            asset_path = page_path + asset.name
            if asset_path not in [unquote(urlsplit(image).path) for image in page_links.images]:
                raise AssertionError(f"image tag missing {asset_path}")
            if not (public_dir / asset_path.lstrip("/")).is_file():
                raise FileNotFoundError(asset_path)
        verified.append({"chapter": slug.split("-")[1], "page": page_path,
                         "python_links": checked_links,
                         "assets": len(list((source_dir / post.stem).glob("*.svg")))})
    assert len(verified) == 48
    print(json.dumps({"navigation": "/python-language/", "verified": verified}, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: python tools/check_pages.py SOURCE_POSTS PUBLIC_DIR")
    main(Path(sys.argv[1]), Path(sys.argv[2]))
