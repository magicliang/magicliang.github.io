import hashlib
from email.parser import Parser
import json
from pathlib import Path
import sys
import tarfile
import zipfile


wheel = Path(sys.argv[1])
source = Path(sys.argv[2])
with zipfile.ZipFile(wheel) as archive:
    metadata_file, = (name for name in archive.namelist() if name.endswith(".dist-info/METADATA"))
    wheel_file, = (name for name in archive.namelist() if name.endswith(".dist-info/WHEEL"))
    metadata = Parser().parsestr(archive.read(metadata_file).decode())
    wheel_data = archive.read(wheel_file).decode()
    assert metadata["Name"] == "tasklab" and metadata["Version"] == "0.1.0"
    assert metadata["Requires-Python"] == ">=3.12"
    assert not metadata.get_all("Requires-Dist")
    assert "Tag: py3-none-any" in wheel_data

with tarfile.open(source, "r:gz") as archive:
    data = archive.extractfile("tasklab-0.1.0/PKG-INFO").read().decode()
    source_metadata = Parser().parsestr(data)
    assert source_metadata["Name"] == metadata["Name"]
    assert source_metadata["Version"] == metadata["Version"]
    assert source_metadata["Requires-Python"] == metadata["Requires-Python"]

print(json.dumps({"version": metadata["Version"], "requires_python": metadata["Requires-Python"],
                  "wheel_tag": "py3-none-any", "runtime_dependencies": [],
                  "wheel_sha256": hashlib.sha256(wheel.read_bytes()).hexdigest(),
                  "sdist_sha256": hashlib.sha256(source.read_bytes()).hexdigest()}, sort_keys=True))
