#!/bin/sh
set -eu

if [ "$#" -ne 1 ] || [ -e "$1" ]; then
    echo 'usage: sh tools/build_selected_pages.sh NEW_ABSOLUTE_OUTPUT_DIR' >&2
    exit 2
fi

case "$1" in
    /*) output_dir=$1 ;;
    *) echo 'output directory must be absolute' >&2; exit 2 ;;
esac

root=$(CDPATH= cd -- "$(dirname "$0")/../../.." && pwd)
case "$output_dir/" in
    "$root/"*) echo 'output directory must be outside the repository' >&2; exit 2 ;;
esac

mkdir -p "$output_dir/source/_posts" "$output_dir/source/python-language"
cp "$root"/source/_posts/????-??-??-Python-*.md "$output_dir/source/_posts/"
for asset_dir in "$root"/source/_posts/????-??-??-Python-*/; do
    if [ -d "$asset_dir" ]; then
        cp -a "${asset_dir%/}" "$output_dir/source/_posts/"
    fi
done
cp "$root/source/python-language/index.md" "$output_dir/source/python-language/index.md"
if [ -d "$root/source/img" ]; then
    cp -a "$root/source/img" "$output_dir/source/"
fi
cp "$root/_config.yml" "$root/_config.butterfly.yml" "$root/package.json" "$output_dir/"
ln -s "$root/node_modules" "$output_dir/node_modules"
ln -s "$root/scripts" "$output_dir/scripts"

(cd "$output_dir" && "$root/node_modules/.bin/hexo" generate)
"${PYTHON:-python3}" "$root/examples/python-language/tools/check_pages.py" "$output_dir/source/_posts" "$output_dir/public"
