# 累计任务服务：第 22 章

本快照对应 Go 22《HTTP提交查询与非法输入怎样表达》。当前源码以本目录实际文件和 `CURRENT-SHA256SUMS` 为准；`evidence/` 下的旧输出是写作过程历史证据，不冒充本次解包复跑。

## 历史阶段说明

以下文字由早期累计快照继承，描述当时阶段；其中的能力限制和证据路径不作为本篇当前能力总览。本篇复跑步骤以 RUN.md 为准。

22 在**同一** `taskExecutor` 和 `TaskStore` 上增加 `taskHTTPService` 的标准库 HTTP 适配层：`POST /tasks` 接受 JSON 文本后立即返回 202 与任务 ID，`GET /tasks/{id}` 查询受锁保护的状态快照，`GET /health` 只表明适配层可应答（不代表可继续接受任务）。输入大小为原工程 65536 字节、JSON 只允许 `text` 字段且内容非空；满队列/关闭拒绝 503 且删掉未接受的预置记录。请求 context 不拥有后台任务，客户端拿到 202 并关闭响应体后，worker 仍由服务 context 管理。真实 loopback HTTP 正反请求、业务 FAILED 对照在 `http_tasks_test.go`，尚未把监听端口或 `http.Server.Shutdown` 接到 CLI；后者在 23–24 对照。数据库和跨进程持久化未引入。

本目录是全系列的**唯一累计工程**。21 将第 20 章的 worker 处理逻辑移入同一个 `taskExecutor`：Mutex 登记并发 Submit 中的发送者；`Close` 唯一拥有输入 channel 的关闭权，先通知在途发送者停止，再等它们退出后关输入；重复关闭和提交/关闭竞争不会对已关闭 channel 发送。`Wait` 等工作者、输出收集者结束；`Shutdown` 在 Close 前请求取消，但对不合作工作仍须等实际退出。批量 CLI 仍使用同一个执行器，另外等待其单生产者结束。受控测试验证优雅 Close 的已接受任务到达成功终态、取消 Shutdown 的已接受任务到达取消终态；不保证未接受任务拥有业务结果。00–20 的快照分别在同名博文素材包。

CLI `--workers`、`--queue-capacity` 仍可选 1–128，默认 1/1；批量输入使用可取消的等待策略。内部拒绝策略返回 `ErrQueueFull`，关闭后 Submit 返回 `ErrExecutorClosed`。`Close` 的**返回**才保证没有在途提交者；调用 Close 与一次在途发送竞争时，该发送仍可能在 Close 返回之前成功。`--batch` 先构造完整输入切片、内存记录及等长结果切片，**不是端到端有界输入**。还没有 HTTP/SQL 或跨进程语义。

需要 Linux amd64 的 Go 1.27.1，或在自己的平台安装同一 patch 版本；不得用较早语言版本的观察冒充本章证据。仓库内源码 tag/SHA 和二进制来源见 `VERSIONS.md`。

```sh
cd examples/go-language
GOTOOLCHAIN=local go version
GOTOOLCHAIN=local go test -count=1 ./...
GOTOOLCHAIN=local go test -count=1 -run '^TestHTTP' -v .
GOTOOLCHAIN=local go list ./...
GOTOOLCHAIN=local go list -m all
GOTOOLCHAIN=local go run . --text 'Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'Go|one two|Go' --workers 2 --queue-capacity 1
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go' --drop-first --append again
GOTOOLCHAIN=local go run . --batch 'Go|one two' --lookup 'task[0]'
GOTOOLCHAIN=local go run . --batch 'Go|one two' --list-ids
printf '%s' '{"text":"Go 写 Go"}' | GOTOOLCHAIN=local go run . --stdin --input-json --json
GOTOOLCHAIN=local go run . --file /tmp/taskstats-input.txt --json
printf 'Go 写 Go' > /tmp/taskstats-input.txt
GOTOOLCHAIN=local go run . --file /tmp/taskstats-input.txt
GOTOOLCHAIN=local go run . --text '  '
GOTOOLCHAIN=local go run ./testdata/shadow.go
GOTOOLCHAIN=local go run ./testdata/assign.go
GOTOOLCHAIN=local go run ./testdata/loop-declare.go
GOTOOLCHAIN=local go run ./testdata/loop-assign.go
GOTOOLCHAIN=local go run ./testdata/defer-order.go
GOTOOLCHAIN=local go run ./testdata/defer-loop.go
GOTOOLCHAIN=local go run ./testdata/slice-append.go
GOTOOLCHAIN=local go test -count=1 -v ./testdata/slice-alias-bug_test.go
GOTOOLCHAIN=local go run ./testdata/nil-map-write.go
GOTOOLCHAIN=local go build ./testdata/nonaddressable-receiver.go
GOTOOLCHAIN=local go build ./testdata/interface-value-error.go
GOTOOLCHAIN=local go run ./testdata/typed-nil.go
GOTOOLCHAIN=local go build -o /tmp/recover-outside-defer ./testdata/recover-outside-defer.go
/tmp/recover-outside-defer
GOTOOLCHAIN=local go build ./testdata/invalid-summarizer.go
GOTOOLCHAIN=local go build ./testdata/invalid-type-operation.go
```

纯空白文本及文件打开失败的**应用进程**预期退出 2；`go run` 外层状态不能代替应用退出码，应改用编译所得二进制检查。14 的输入超限、坏 JSON、stdout 部分写入分别返回应用退出 2；已经接受的输出字节不能由本 CLI 撤销，不能称写出具有事务原子性。文件由 `readAndClose` 关闭；调用方拥有的 stdin/stdout 不由本函数关闭。13 两份故意编译失败例子及更早反例仍隔离在 `testdata/`。最新 14 结果见 `writing-plans/go-language/evidence/14/`，00–13 的冻结快照留在对应正文素材包。
