# 累计任务服务：第 19 章

本快照对应 Go 19《WaitGroup-Once与atomic各负责什么》。当前源码以本目录实际文件和 `CURRENT-SHA256SUMS` 为准；`evidence/` 下的旧输出是写作过程历史证据，不冒充本次解包复跑。

## 历史阶段说明

以下文字由早期累计快照继承，描述当时阶段；其中的能力限制和证据路径不作为本篇当前能力总览。本篇复跑步骤以 RUN.md 为准。

本目录是全系列的**唯一累计工程**。19 将生产者/消费者的退出等待改成 `sync.WaitGroup`（在启动前 Add，排空输出后 Wait），单任务统计的 `done` 依旧负责其自身确认；CLI 配置经同次运行的 `sync.Once` 缓存初始化与错误，受控并发测试证明初始化仅执行一次；`TaskStore` 的独立终态数量用 `atomic.Uint64` 统计，但按 ID 的状态、计数结果和取消请求仍由同一把 Mutex 保护。无锁测试替身即使把终态计数改为 atomic，`go test -race` 仍报告 TaskRecord 竞争。输入尚在内存，仍只有一个消费者，不宣称 WaitGroup 是服务退出协议或原子计数可以代替状态锁。00–18 的快照分别在同名博文素材包。

需要 Linux amd64 的 Go 1.27.1，或在自己的平台安装同一 patch 版本；不得用较早语言版本的观察冒充本章证据。仓库内源码 tag/SHA 和二进制来源见 `VERSIONS.md`。

```sh
cd examples/go-language
GOTOOLCHAIN=local go version
GOTOOLCHAIN=local go test -count=1 ./...
GOTOOLCHAIN=local go list ./...
GOTOOLCHAIN=local go list -m all
GOTOOLCHAIN=local go run . --text 'Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go' --drop-first --append again
GOTOOLCHAIN=local go run . --batch 'Go|one two' --lookup 'task[0]'
GOTOOLCHAIN=local go run . --batch 'Go|one two' --list-ids
printf '%s' '{"text":"Go 写 Go"}' | GOTOOLCHAIN=local go run . --stdin --input-json --json
GOTOOLCHAIN=local go run . --file /tmp/taskstats-input.txt --json
printf 'Go 写 Go' > /tmp/taskstats-input.txt
GOTOOLCHAIN=local go run . --file /tmp/taskstats-input.txt
GOTOOLCHAIN=local go run . --text '  '
GOTOOLCHAIN=local go run ./testdata/shadow.go
GOTOOLCHAIN=local go run ./testdata/assign.go
GOTOOLCHAIN=local go run ./testdata/loop-declare.go
GOTOOLCHAIN=local go run ./testdata/loop-assign.go
GOTOOLCHAIN=local go run ./testdata/defer-order.go
GOTOOLCHAIN=local go run ./testdata/defer-loop.go
GOTOOLCHAIN=local go run ./testdata/slice-append.go
GOTOOLCHAIN=local go test -count=1 -v ./testdata/slice-alias-bug_test.go
GOTOOLCHAIN=local go run ./testdata/nil-map-write.go
GOTOOLCHAIN=local go build ./testdata/nonaddressable-receiver.go
GOTOOLCHAIN=local go build ./testdata/interface-value-error.go
GOTOOLCHAIN=local go run ./testdata/typed-nil.go
GOTOOLCHAIN=local go build -o /tmp/recover-outside-defer ./testdata/recover-outside-defer.go
/tmp/recover-outside-defer
GOTOOLCHAIN=local go build ./testdata/invalid-summarizer.go
GOTOOLCHAIN=local go build ./testdata/invalid-type-operation.go
```

纯空白文本及文件打开失败的**应用进程**预期退出 2；`go run` 外层状态不能代替应用退出码，应改用编译所得二进制检查。14 的输入超限、坏 JSON、stdout 部分写入分别返回应用退出 2；已经接受的输出字节不能由本 CLI 撤销，不能称写出具有事务原子性。文件由 `readAndClose` 关闭；调用方拥有的 stdin/stdout 不由本函数关闭。13 两份故意编译失败例子及更早反例仍隔离在 `testdata/`。最新 14 结果见 `writing-plans/go-language/evidence/14/`，00–13 的冻结快照留在对应正文素材包。
