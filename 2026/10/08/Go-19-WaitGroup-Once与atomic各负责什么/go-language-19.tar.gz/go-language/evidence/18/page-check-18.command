python3 writing-plans/go-language/scripts/check_page_00.py /tmp/go-language-hexo-18.eUocM4/public 18
