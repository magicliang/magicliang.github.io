tar -C /tmp/go-language-18-pack.MhK6ND -czf /home/admin/workspace/my-blogs/source/_posts/2026-10-08-Go-18-共享任务状态怎样避免竞争与终态反转/go-language-18.tar.gz go-language
