sha256sum '/home/admin/workspace/my-blogs/writing-plans/go-language/evidence/18/http-archive.body'
