# Kotlin 累计实验版本账本

00 基线，核验日期：2026-10-07（UTC）。仅以下组合已在当前主机 `clean test`、合法/非法 CLI 和字节码检查中实际运行。后续依赖在**引入时**另列源码 SHA；不预填尚未运行的工具版本。

| 对象 | 冻结值与依据 | 已确认范围 |
|---|---|---|
| Kotlin Gradle Plugin / 编译器 / stdlib | `2.2.21`，`build.gradle.kts` 和 `runtimeClasspath`；上游源码 tag `v2.2.21` → `2146684dcba708e5a304758b41a9e4ec9c7eff71`（`git ls-remote`） | 实际编译、测试、运行；未追踪源码内部实现 |
| languageVersion / apiVersion / jvmTarget | `2.2` / `2.2` / `21`，显式 compilerOptions；`javap -verbose` 显示 class major `65` | 指定输出目标并验证生成物；不等同运行 JVM 的全部能力 |
| Gradle Wrapper | `8.14`，revision 与上游 tag `v8.14.0` SHA 均为 `34c560e3be961658a6fbcd7170ec2443a228b109`（`git ls-remote`） | `./gradlew --version` 为 8.14；自带 Kotlin 为 `2.0.21`，不是本程序编译器 |
| Gradle 分发包 | 官方 SHA-256 `61ad310d3c7d3e5da131b76bbf22b5a4c0786e9d892dae8c1658d4b484de3caa`；镜像下载后本地 `sha256sum -c` 通过；Wrapper properties 固定同值 | 当前网络无法解析官方 GitHub 重定向；使用华为云镜像作为下载地址，仅以官方 SHA 校验其字节 |
| Wrapper JAR | 本次 Gradle 8.14 `wrapper` 任务生成，SHA-256 `7d3a4ac4de1c32b59bc6a4eb8ecb8e612ccd0cf1ae1e99f66902da64df296172` | 本地校验指纹，尚未与公开 wrapper JAR 清单独立对照 |
| JDK / toolchain | Ubuntu OpenJDK `21.0.12.1+1-1-24.04.4-Ubuntu`，`/usr/lib/jvm/java-21-openjdk-amd64`，x86_64；toolchain 21 | Gradle launcher/daemon 与执行进程使用 JDK 21；`jvmTarget` 不是“当前 JDK 版本” |
| 测试 | `kotlin("test-junit5")` 随插件 `2.2.21`；JUnit Platform Launcher `1.12.2` | 已跑 JUnit 行为测试；运行时完整传递版本可查 `testRuntimeClasspath` |

参考：[Kotlin Gradle 兼容表](https://kotlinlang.org/docs/gradle-configure-project.html)（2026-10-07 查阅，`2.2.20–2.2.21` 与 Gradle `7.6.3–8.14`）、[Kotlin 命令行编译](https://kotlinlang.org/docs/command-line.html)、[Gradle Wrapper 8.14 文档](https://docs.gradle.org/8.14/userguide/gradle_wrapper.html)、[Gradle 8.14 官方 SHA 文件](https://services.gradle.org/distributions/gradle-8.14-bin.zip.sha256)。滚动文档只用于交叉校验选型，成功构建与运行见原始证据。协程/序列化/Ktor/数据库 **NOT_RUN**。
