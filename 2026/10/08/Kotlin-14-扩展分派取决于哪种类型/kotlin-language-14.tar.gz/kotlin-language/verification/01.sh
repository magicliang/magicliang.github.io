#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/01"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

if ! run environment bash -c 'date -u && uname -a && java -version && ./gradlew --version'; then
    exit 1
fi
if ! run build ./gradlew --offline --no-daemon --console=plain clean test; then
    exit 1
fi
run testsuite cat build/test-results/test/TEST-example.tasks.TaskSettingsTest.xml || exit 1
run regression cat build/test-results/test/TEST-example.tasks.MainTest.xml || exit 1

scratch="$(mktemp -d /tmp/kotlin-01-rejected-XXXXXX)"
mkdir -p "$scratch/gradle/wrapper" "$scratch/src/main/kotlin"
cp build.gradle.kts settings.gradle.kts gradlew "$scratch/"
cp gradle/wrapper/* "$scratch/gradle/wrapper/"
cp verification/01-val-reassignment.kt "$scratch/src/main/kotlin/"
run rejected bash -c 'cd "$1" && ./gradlew --offline --no-daemon --console=plain compileKotlin' _ "$scratch"
rejected_status=$?

{
    printf 'environment_exit=0\nbuild_exit=0\ntestsuite_exit=0\nregression_exit=0\nrejected_exit=%s\n' "$rejected_status"
    grep -F 'tests="2" skipped="0" failures="0" errors="0"' "$evidence/testsuite.txt" >/dev/null && echo 'new_behavior_tests=PASS' || echo 'new_behavior_tests=FAIL'
    grep -F 'tests="2" skipped="0" failures="0" errors="0"' "$evidence/regression.txt" >/dev/null && echo 'chapter00_regression=PASS' || echo 'chapter00_regression=FAIL'
    grep -F "'val' cannot be reassigned." "$evidence/rejected.txt" >/dev/null && echo 'compiler_rejects_reassignment=PASS' || echo 'compiler_rejects_reassignment=FAIL'
} > "$evidence/assertions.txt"

test "$rejected_status" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
