#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/02"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && ./gradlew --version' || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test || exit 1
run suite00 cat build/test-results/test/TEST-example.tasks.MainTest.xml || exit 1
run suite01 cat build/test-results/test/TEST-example.tasks.TaskSettingsTest.xml || exit 1
run suite02 cat build/test-results/test/TEST-example.tasks.CommandParserTest.xml || exit 1
run batch ./gradlew --offline --no-daemon --console=plain run --args='batch alpha beta' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=batch
invalid_status=$?

scratch="$(mktemp -d /tmp/kotlin-02-rejected-XXXXXX)"
mkdir -p "$scratch/gradle/wrapper" "$scratch/src/main/kotlin"
cp build.gradle.kts settings.gradle.kts gradlew "$scratch/"
cp gradle/wrapper/* "$scratch/gradle/wrapper/"
cp verification/02-unstable-smartcast.kt "$scratch/src/main/kotlin/"
run rejected bash -c 'cd "$1" && ./gradlew --offline --no-daemon --console=plain compileKotlin' _ "$scratch"
rejected_status=$?

{
    printf 'environment_exit=0\nbuild_exit=0\nbatch_exit=0\ninvalid_exit=%s\nrejected_exit=%s\n' "$invalid_status" "$rejected_status"
    for suite in suite00 suite01 suite02; do
        grep -F 'tests="2" skipped="0" failures="0" errors="0"' "$evidence/$suite.txt" >/dev/null && echo "$suite=PASS" || echo "$suite=FAIL"
    done
    grep -F 'TASK inputs accepted (not persisted): 2' "$evidence/batch.txt" >/dev/null && echo 'batch_count=PASS' || echo 'batch_count=FAIL'
    grep -F 'Usage: batch <task text>...' "$evidence/invalid.txt" >/dev/null && echo 'invalid_diagnostic=PASS' || echo 'invalid_diagnostic=FAIL'
    grep -F 'open or custom getter' "$evidence/rejected.txt" >/dev/null && echo 'unstable_getter_rejected=PASS' || echo 'unstable_getter_rejected=FAIL'
    grep -F 'mutable property that could be mutated concurrently' "$evidence/rejected.txt" >/dev/null && echo 'mutable_property_rejected=PASS' || echo 'mutable_property_rejected=FAIL'
} > "$evidence/assertions.txt"

test "$invalid_status" -ne 0 && test "$rejected_status" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
