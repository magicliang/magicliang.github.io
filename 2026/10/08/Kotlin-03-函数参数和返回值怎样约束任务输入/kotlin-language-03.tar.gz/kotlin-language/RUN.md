# 运行与复核

运行环境：JDK 21；Gradle Wrapper 8.14；Kotlin Gradle Plugin、编译器和 stdlib 2.2.21。精确 SHA、文档出处和已执行结果见 `../../writing-plans/kotlin/VERSIONS.md` 与 `../../writing-plans/kotlin/verification/00/`。Gradle Wrapper 固定分发包 SHA-256，即使从镜像下载也必须先通过校验。

```bash
cd examples/kotlin-language
bash verification/00.sh
bash verification/01.sh
bash verification/02.sh
bash verification/03.sh
```

脚本保存环境、clean test、合法/非法 CLI、字节码、依赖解析、测试报告的命令、原始输出、退出码和断言。`invalid` 的退出码预期非零。脚本依赖本仓库相对目录结构；若只拿到打包工程，请进入解包后的 `kotlin-language` 并运行 `./gradlew --no-daemon clean test`，随后分别运行 `./gradlew run --args='submit nightly-index'` 与 `./gradlew run --args=submit`。这是本机 JDK/Gradle 的实际运行，不包括 HTTP、数据库、协程或重启恢复。

01 的 `verification/01-val-reassignment.kt` 是特意放在默认源码集之外的失败样本；不要复制进 `src/main/kotlin` 的正常构建。若只有独立压缩包，版本账本位于解包根目录的 `VERSIONS.md`，实验原始输出位于 `verification/00/` 与 `verification/01/`。

02 的 `verification/02-unstable-smartcast.kt` 同样是隔离的编译失败样本，覆盖自定义 getter 与可变属性。打包快照的主工程可用 `./gradlew --offline --no-daemon clean test` 复核已缓存依赖的环境；不应把 `batch` 的本地计数或当前命令行输出理解为后台任务已入队。

03 的 `verification/03-java-named-args.kt` 演示 Java 方法无法从 Kotlin 使用命名实参，同样不能复制进正常工程。`TaskProposalTest` 验证 `taskProposal` 缺省与显式参数、`Unit` 动作、`Nothing` 异常和可空结果；`taskProposal` 目前没有接入 CLI，测试通过也不表示已经创建或运行任务。只有独立包时从根目录用 `./gradlew --offline --no-daemon clean test` 验证累计源码；相应原始证据在包内 `verification/03/`。
