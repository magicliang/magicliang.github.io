# Kotlin 累计任务系统

从 00 开始逐篇扩展的 Kotlin/JVM 合成任务实验。当前 `submit` 只验证一条命令行输入并打印“输入已接收”提示；**没有排队、执行、持久化或后台任务**，不能把提示当成提交成功的持久证据。

01 增加 `TaskSettings` 的标签与重试上限实验。`val labels` 仍公开一个可变列表，专用于验证别名和对象可变性；这不是线程安全接口，06 再区分只读视图与真正的快照。该设置还没有接入 00 的 CLI，不要从测试通过推断 CLI 已支持重试。

02 将 CLI 增加 `help` 与 `batch` 的输入分支；`batch` 的数量只是校验期间的局部计数，不是排队任务数。`TaskTextSource` 用可控 getter 验证“先读入局部 `val` 再作非空判断”，尚未从网络或文件读取数据。

要求 JDK 21 与可访问 Maven Central/Gradle 分发包的网络；版本和校验值见 `../../writing-plans/kotlin/VERSIONS.md`。在本目录运行：

```bash
./gradlew --no-daemon clean test
./gradlew --no-daemon run --args='submit nightly-index'
./gradlew --no-daemon run --args='submit'
```

最后一条应以非零退出并打印 `Usage: submit <task text>`。完整的版本、命令、退出码、原始输出和断言由 `verification/00.sh` 写入 `../../writing-plans/kotlin/verification/00/`。Wrapper 包固定官方 SHA-256，但 `distributionUrl` 使用可从当前环境访问的第三方镜像；验收脚本另行核对下载内容校验和。

01 运行 `bash verification/01.sh`，检验 00 回归、`val`/`var` 别名、数字溢出与隔离的编译拒绝样本；对应记录见 `../../writing-plans/kotlin/verification/01/`。01 快照及下载校验文件放在 01 正文的同名素材目录。

02 运行 `bash verification/02.sh`，复跑 00–02 的行为测试、真实 CLI 的 `batch` 正反例，以及独立编译拒绝的智能转换样本；原始证据见 `../../writing-plans/kotlin/verification/02/`。`verification/02-unstable-smartcast.kt` 不参与正常工程构建。

03 增加 `taskProposal` 的参数与返回边界实验：缺省/显式 `retries`、命名参数、`vararg` 和空白/非法输入分别有断言。它只构造可读的合成文本预览，不产生任务对象，也不启动执行器。运行 `bash verification/03.sh`，Java 方法的非法命名调用单独放在默认源码集之外。

04 在同一工程新增 `TaskText.kt`：`inputMetrics` 分别计数 UTF-16 代码单元、Unicode 码点和 UTF-8 编码字节；`validTaskId` 与 `containsTaskId` 分别验证完整匹配和子串搜索。运行 `bash verification/04.sh`，保留 00–03 回归。计数函数尚未接入 CLI；`submit` 中包含 emoji 仅说明原有输入路径接收了该文本，不说明已做 UTF-8 长度校验，更不是已落库。

05 用 `Map<String, String?>` 模拟一个可选备注字段：先检查键是否存在，再区分显式 null、空串和普通值；`noteDisplayLength` 展示安全调用与 Elvis 可能合并显示结果，`unsafeNoteLength` 专用于测试 `!!` 的失败路径。测试中的 `lateinit` 和隔离编译拒绝样本不能当成生产初始化策略。运行 `bash verification/05.sh`，确认 00–05 回归、失败诊断与旧 CLI；备注尚未接入 CLI。

06 的 `TaskQuery` 同时提供原可变列表的只读视图与 `toList()` 副本；`TaskQueryTest` 在原对象变动后分别检查 `List`、`Set`、`Map` 的只读别名与结构快照，并证明快照仍共享可变 `StringBuilder` 元素。运行 `bash verification/06.sh`，保留 00–05 回归。查询尚未接入 CLI，也不是跨线程一致快照。

07 的 `TaskLabelRules` 用函数类型传递同步标签转换/筛选，测试捕获局部 `var` 的调用时读取、急切 map/filter 次数，以及 `return@forEach` 与 inline `forEach` 非局部返回的区别；非 inline 回调中非法裸 `return` 仍在隔离样本中。运行 `bash verification/07.sh`，保留 00–06 回归。没有把规则接入 CLI 或启动协程。
