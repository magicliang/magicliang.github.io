package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"strings"
)

func run(args []string, stdout, stderr io.Writer) int {
	return runWithInput(args, os.Stdin, stdout, stderr)
}

func runWithInput(args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	flags := flag.NewFlagSet("taskstats", flag.ContinueOnError)
	flags.SetOutput(stderr)
	text := flags.String("text", "", "text to count")
	batch := flags.String("batch", "", "texts separated by |")
	inputFile := flags.String("file", "", "path to one text input")
	fromStdin := flags.Bool("stdin", false, "read one text input from stdin")
	inputJSON := flags.Bool("input-json", false, "decode file or stdin as a JSON object with text")
	jsonOutput := flags.Bool("json", false, "encode results as JSON")
	appendText := flags.String("append", "", "append one batch item")
	dropFirst := flags.Bool("drop-first", false, "omit the first batch item")
	lookup := flags.String("lookup", "", "look up one batch task ID")
	listIDs := flags.Bool("list-ids", false, "list batch task IDs in submission order")
	maxWords := flags.Int("max-words", 3, "maximum number of words")
	timeout := flags.Duration("timeout", 0, "maximum time to process tasks (0 stops immediately)")
	if err := flags.Parse(args); err != nil {
		return 2
	}
	config := Config{MaxWords: *maxWords}
	if err := validateConfig(config); err != nil {
		fmt.Fprintln(stderr, err)
		return 2
	}
	textProvided, batchProvided, fileProvided, stdinProvided, appendProvided, dropProvided, lookupProvided, listProvided := false, false, false, false, false, false, false, false
	flags.Visit(func(option *flag.Flag) {
		if option.Name == "text" {
			textProvided = true
		}
		if option.Name == "batch" {
			batchProvided = true
		}
		if option.Name == "file" {
			fileProvided = true
		}
		if option.Name == "stdin" {
			stdinProvided = *fromStdin
		}
		if option.Name == "append" {
			appendProvided = true
		}
		if option.Name == "drop-first" {
			dropProvided = true
		}
		if option.Name == "lookup" {
			lookupProvided = true
		}
		if option.Name == "list-ids" {
			listProvided = true
		}
	})
	selectedModes := 0
	for _, provided := range []bool{textProvided, batchProvided, fileProvided, stdinProvided} {
		if provided {
			selectedModes++
		}
	}
	if flags.NArg() != 0 || selectedModes != 1 || !batchProvided && (appendProvided || dropProvided || lookupProvided || listProvided) || lookupProvided && listProvided || *inputJSON && !(fileProvided || stdinProvided) {
		fmt.Fprintln(stderr, "usage: taskstats (--text 'text' | --batch 'text|text' [--append text] [--drop-first] [--lookup ID | --list-ids] | --file path | --stdin) [--input-json] [--json] [--max-words N]")
		return 2
	}
	taskText := *text
	if fileProvided {
		var err error
		taskText, err = readTaskFile(*inputFile)
		if err != nil {
			if errors.Is(err, ErrInvalidInput) {
				fmt.Fprintf(stderr, "input exceeds %d bytes\n", maxInputBytes)
			} else {
				fmt.Fprintln(stderr, "read file: task execution failed")
			}
			return 2
		}
	}
	if stdinProvided {
		var err error
		taskText, err = readBounded(stdin)
		if err != nil {
			if errors.Is(err, ErrInvalidInput) {
				fmt.Fprintf(stderr, "input exceeds %d bytes\n", maxInputBytes)
			} else {
				fmt.Fprintln(stderr, "read stdin: task execution failed")
			}
			return 2
		}
	}
	if *inputJSON {
		var err error
		taskText, err = decodeJSONText(taskText)
		if err != nil {
			fmt.Fprintln(stderr, "invalid JSON input")
			return 2
		}
	}
	tasks := []string{taskText}
	if batchProvided {
		tasks = prepareBatch(strings.Split(*batch, "|"), *appendText, appendProvided, *dropFirst)
		if len(tasks) == 0 {
			fmt.Fprintln(stderr, "usage: taskstats: batch must contain at least one item")
			return 2
		}
	}
	ctx := context.Background()
	timeoutProvided := false
	flags.Visit(func(option *flag.Flag) {
		if option.Name == "timeout" {
			timeoutProvided = true
		}
	})
	if timeoutProvided {
		var cancel context.CancelFunc
		ctx, cancel = context.WithTimeout(ctx, *timeout)
		defer cancel()
	}
	store := newTaskStore(tasks)
	results, processingError := processTasksContextUsingStore(ctx, tasks, config.MaxWords, analyzeTaskAsyncContext, store)
	if processingError != nil {
		if errors.Is(processingError, context.DeadlineExceeded) {
			fmt.Fprintln(stderr, "task deadline exceeded")
		} else {
			fmt.Fprintln(stderr, "task canceled")
		}
		return 2
	}
	records := make([]TaskRecord, 0, len(tasks))
	for position, outcome := range results {
		counts, err := outcome.counts, outcome.err
		if err != nil {
			if errors.Is(err, context.Canceled) {
				fmt.Fprintln(stderr, "task canceled")
				return 2
			}
			if !errors.Is(err, ErrInvalidInput) {
				fmt.Fprintln(stderr, "task execution failed")
				return 2
			}
			if strings.TrimSpace(tasks[position]) == "" {
				fmt.Fprintln(stderr, "usage: taskstats: text must not be empty")
			} else {
				fmt.Fprintf(stderr, "word count %d exceeds max-words %d\n", counts.Words, config.MaxWords)
			}
			return 2
		}
		record, _ := store.Lookup(fmt.Sprintf("task[%d]", position))
		records = append(records, record)
	}
	var output strings.Builder
	selected := records
	var ids []string
	if batchProvided && (lookupProvided || *listIDs) {
		tasks := newBatchTasks(records)
		if lookupProvided {
			description, err := describeTask(tasks, *lookup)
			if err != nil {
				if errors.Is(err, ErrTaskNotFound) {
					fmt.Fprintln(stderr, "task not found:", *lookup)
				} else {
					fmt.Fprintln(stderr, "task execution failed")
				}
				return 2
			}
			fmt.Fprintln(&output, description)
			if *jsonOutput {
				record, _ := tasks.Lookup(*lookup)
				selected = []TaskRecord{record}
			}
		} else {
			ids = tasks.IDs()
			for _, id := range ids {
				fmt.Fprintln(&output, id)
			}
		}
	} else {
		for position, summary := range Summaries(records) {
			if batchProvided {
				fmt.Fprintf(&output, "%s ", records[position].ID)
			}
			fmt.Fprintln(&output, summary)
		}
	}
	payload := []byte(output.String())
	if *jsonOutput {
		var err error
		if *listIDs {
			payload, err = json.Marshal(ids)
		} else {
			payload, err = jsonRecords(selected)
		}
		if err != nil {
			fmt.Fprintln(stderr, "output encoding failed")
			return 2
		}
		payload = append(payload, '\n')
	}
	if err := writeResponse(stdout, payload); err != nil {
		fmt.Fprintln(stderr, "output write failed")
		return 2
	}
	return 0
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}
