sed -n "48,64p;139,176p;472,526p" /tmp/go-language-toolchain-1.27.1/go/doc/go_mem.html
