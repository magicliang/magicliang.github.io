# 18 受控竞争与 CLI 验证

`environment.txt` 记录 Go 1.27.1、linux/amd64、`CGO_ENABLED=1` 和 gcc。每组 `.command`、`.stdout`、`.stderr`、`.exit` 是实际命令、双流与进程退出码。`unsafe` 仅在专门设置 `TASKSTATS_UNSAFE_RACE=1` 后让同一 `TestStoreRaceScenario` 使用测试内无锁替身，实际报告 `WARNING: DATA RACE`，退出 1；`safe` 去掉该环境变量，用真实 `TaskStore` 同场景退出 0；`race-full` 是两包本次执行过的测试，没有报告。`store-repeat` 重复受控竞争和取消闸门 50 次，不能代替 race detector。`batch`、`json`、`deadline`、`invalid` 是旧 CLI 的真实回归，deadline/invalid 按约定退出 2。`spec-memory`、`doc-mutex` 保存工具链一手来源。

同名素材目录的 `unpack-*` 为归档解包复跑，`package-*`、`hexo-*`、`page-*`、`http-*` 是素材/页面/下载的实际验收；隔离页面不代替 Go 测试。此章没有全站构建、其他平台、多 worker、SQL、HTTP 或发布，均 `NOT_RUN`。无报告不能外推所有并发路径安全；race 反例测试替身不是生产存储代码。
