go test -count=50 -run "TestStoreRaceScenario|TestStoreOnlyOneClaim|TestCancelDuringCalculationKeepsTerminalStatus" -v .
