# 累计任务服务：第 18 章

本快照对应 Go 18《共享任务状态怎样避免竞争与终态反转》。当前源码以本目录实际文件和 `CURRENT-SHA256SUMS` 为准；`evidence/` 下的旧输出是写作过程历史证据，不冒充本次解包复跑。

## 历史阶段说明

以下文字由早期累计快照继承，描述当时阶段；其中的能力限制和证据路径不作为本篇当前能力总览。本篇复跑步骤以 RUN.md 为准。

本目录是全系列的**唯一累计工程**。18 在相同队列的接收和完成路径引入 `TaskStore`，将任务记录值保存在一把 `sync.Mutex` 保护的 map 内：同一 ID 仅能被领取一次；`RUNNING` 接到取消请求只记录 `CancelRequested`，不立即冒充 `CANCELED` 终态；工作者处理结束后的提交点决定 `SUCCEEDED` / `FAILED` / `CANCELED`，终态不能反转。返回的查询结果是副本，不让调用者越过锁改内部状态。`store_test.go` 以同一测试场景和两种存储实现跑 race 反例/正例：仅设置 `TASKSTATS_UNSAFE_RACE=1` 的隔离测试替身无锁，正常生产实现有锁；无锁反例不能并入正常测试验收。没有多 worker、HTTP、SQL 或外部副作用回滚。00–17 的工程快照在各章博文素材包。

需要 Linux amd64 的 Go 1.27.1，或在自己的平台安装同一 patch 版本；不得用较早语言版本的观察冒充本章证据。仓库内源码 tag/SHA 和二进制来源见 `VERSIONS.md`。

```sh
cd examples/go-language
GOTOOLCHAIN=local go version
GOTOOLCHAIN=local go test -count=1 ./...
GOTOOLCHAIN=local go list ./...
GOTOOLCHAIN=local go list -m all
GOTOOLCHAIN=local go run . --text 'Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go' --drop-first --append again
GOTOOLCHAIN=local go run . --batch 'Go|one two' --lookup 'task[0]'
GOTOOLCHAIN=local go run . --batch 'Go|one two' --list-ids
printf '%s' '{"text":"Go 写 Go"}' | GOTOOLCHAIN=local go run . --stdin --input-json --json
GOTOOLCHAIN=local go run . --file /tmp/taskstats-input.txt --json
printf 'Go 写 Go' > /tmp/taskstats-input.txt
GOTOOLCHAIN=local go run . --file /tmp/taskstats-input.txt
GOTOOLCHAIN=local go run . --text '  '
GOTOOLCHAIN=local go run ./testdata/shadow.go
GOTOOLCHAIN=local go run ./testdata/assign.go
GOTOOLCHAIN=local go run ./testdata/loop-declare.go
GOTOOLCHAIN=local go run ./testdata/loop-assign.go
GOTOOLCHAIN=local go run ./testdata/defer-order.go
GOTOOLCHAIN=local go run ./testdata/defer-loop.go
GOTOOLCHAIN=local go run ./testdata/slice-append.go
GOTOOLCHAIN=local go test -count=1 -v ./testdata/slice-alias-bug_test.go
GOTOOLCHAIN=local go run ./testdata/nil-map-write.go
GOTOOLCHAIN=local go build ./testdata/nonaddressable-receiver.go
GOTOOLCHAIN=local go build ./testdata/interface-value-error.go
GOTOOLCHAIN=local go run ./testdata/typed-nil.go
GOTOOLCHAIN=local go build -o /tmp/recover-outside-defer ./testdata/recover-outside-defer.go
/tmp/recover-outside-defer
GOTOOLCHAIN=local go build ./testdata/invalid-summarizer.go
GOTOOLCHAIN=local go build ./testdata/invalid-type-operation.go
```

纯空白文本及文件打开失败的**应用进程**预期退出 2；`go run` 外层状态不能代替应用退出码，应改用编译所得二进制检查。14 的输入超限、坏 JSON、stdout 部分写入分别返回应用退出 2；已经接受的输出字节不能由本 CLI 撤销，不能称写出具有事务原子性。文件由 `readAndClose` 关闭；调用方拥有的 stdin/stdout 不由本函数关闭。13 两份故意编译失败例子及更早反例仍隔离在 `testdata/`。最新 14 结果见 `writing-plans/go-language/evidence/14/`，00–13 的冻结快照留在对应正文素材包。
