package main

import (
	"context"
	"fmt"

	"example.com/go-language-task/stats"
)

type queuedTask struct {
	position int
	text     string
}

type taskOutcome struct {
	position int
	counts   stats.Counts
	err      error
}

func processTasks(tasks []string, maxWords int) []taskOutcome {
	results, _ := processTasksContext(context.Background(), tasks, maxWords)
	return results
}

func processTasksUsing(tasks []string, maxWords int, analyze func(string) stats.Counts) []taskOutcome {
	results, _ := processTasksContextUsing(context.Background(), tasks, maxWords, func(_ context.Context, text string, limit int) (stats.Counts, error) {
		return analyzeTaskAsyncUsing(text, limit, analyze)
	})
	return results
}

func sendTask(ctx context.Context, inputs chan<- queuedTask, task queuedTask) error {
	select {
	case <-ctx.Done():
		return ctx.Err()
	case inputs <- task:
		return nil
	}
}

func receiveTask(ctx context.Context, inputs <-chan queuedTask) (queuedTask, bool) {
	select {
	case <-ctx.Done():
		return queuedTask{}, false
	case task, ok := <-inputs:
		return task, ok
	}
}

func processTasksContext(ctx context.Context, tasks []string, maxWords int) ([]taskOutcome, error) {
	return processTasksContextUsingStore(ctx, tasks, maxWords, analyzeTaskAsyncContext, nil)
}

func processTasksContextUsing(ctx context.Context, tasks []string, maxWords int, analyze func(context.Context, string, int) (stats.Counts, error)) ([]taskOutcome, error) {
	return processTasksContextUsingStore(ctx, tasks, maxWords, analyze, nil)
}

func processTasksContextUsingStore(ctx context.Context, tasks []string, maxWords int, analyze func(context.Context, string, int) (stats.Counts, error), store *TaskStore) ([]taskOutcome, error) {
	inputs := make(chan queuedTask, 1)
	outputs := make(chan taskOutcome)
	producerDone := make(chan struct{})
	workerDone := make(chan struct{})
	go func() {
		defer close(producerDone)
		defer close(inputs)
		for position, text := range tasks {
			if err := sendTask(ctx, inputs, queuedTask{position: position, text: text}); err != nil {
				return
			}
		}
	}()
	go func() {
		defer close(workerDone)
		defer close(outputs)
		for {
			task, ok := receiveTask(ctx, inputs)
			if !ok || ctx.Err() != nil {
				return
			}
			id := fmt.Sprintf("task[%d]", task.position)
			if store != nil && !store.Start(id) {
				select {
				case <-ctx.Done():
					return
				case outputs <- taskOutcome{position: task.position, err: context.Canceled}:
				}
				continue
			}
			counts, err := analyze(ctx, task.text, maxWords)
			if store != nil {
				switch {
				case err == nil:
					if !store.Complete(id, counts) {
						err = context.Canceled
					}
				case ctx.Err() == nil:
					if !store.Fail(id) {
						err = context.Canceled
					}
				}
			}
			select {
			case <-ctx.Done():
				return
			case outputs <- taskOutcome{position: task.position, counts: counts, err: err}:
			}
		}
	}()
	results := make([]taskOutcome, len(tasks))
	for result := range outputs {
		results[result.position] = result
	}
	<-producerDone
	<-workerDone
	if err := ctx.Err(); err != nil {
		if store != nil {
			store.CancelOpen()
		}
		return nil, err
	}
	return results, nil
}
