package main

import (
	"context"
	"os"
	"testing"

	"example.com/go-language-task/stats"
)

type recordTransitions interface {
	Start(string) bool
	Complete(string, stats.Counts) bool
	Cancel(string) bool
	Lookup(string) (TaskRecord, bool)
}

type unprotectedStore struct {
	record TaskRecord
}

func (store *unprotectedStore) Start(id string) bool {
	if store.record.ID != id || store.record.Status != StatusQueued {
		return false
	}
	store.record.Status = StatusRunning
	return true
}

func (store *unprotectedStore) Complete(id string, counts stats.Counts) bool {
	if store.record.ID != id || store.record.Status != StatusRunning {
		return false
	}
	if store.record.CancelRequested {
		store.record.Status = StatusCanceled
		return false
	}
	store.record.MarkSucceeded(counts)
	return true
}

func (store *unprotectedStore) Cancel(id string) bool {
	if store.record.ID != id || store.record.Status != StatusRunning || store.record.CancelRequested {
		return false
	}
	store.record.CancelRequested = true
	return true
}

func (store *unprotectedStore) Lookup(id string) (TaskRecord, bool) {
	return store.record, store.record.ID == id
}

func TestStoreRaceScenario(t *testing.T) {
	var store recordTransitions = newTaskStore([]string{"Go"})
	if os.Getenv("TASKSTATS_UNSAFE_RACE") == "1" {
		store = &unprotectedStore{record: newTaskRecord("task[0]")}
	}
	if !store.Start("task[0]") {
		t.Fatal("initial claim failed")
	}
	start := make(chan struct{})
	done := make(chan struct{}, 64)
	for index := 0; index < cap(done); index++ {
		go func(position int) {
			<-start
			if position%2 == 0 {
				store.Complete("task[0]", stats.Counts{Words: 1, Bytes: 2, Runes: 2})
			} else {
				store.Cancel("task[0]")
			}
			store.Lookup("task[0]")
			done <- struct{}{}
		}(index)
	}
	close(start)
	for index := 0; index < cap(done); index++ {
		<-done
	}
	record, ok := store.Lookup("task[0]")
	if !ok || record.Status != StatusSucceeded && record.Status != StatusCanceled || record.Status == StatusSucceeded && record.Words != 1 || record.Status == StatusCanceled && record.Words != 0 {
		t.Fatalf("inconsistent terminal snapshot: %+v ok=%t", record, ok)
	}
	if store.Complete("task[0]", stats.Counts{Words: 9}) || store.Cancel("task[0]") {
		t.Fatal("terminal status was reversed")
	}
	t.Logf("terminal=%s words=%d after 64 racing operations; reversal rejected", record.Status, record.Words)
}

func TestStoreSnapshotAndFailure(t *testing.T) {
	store := newTaskStore([]string{"Go"})
	first, ok := store.Lookup("task[0]")
	if !ok || first.Status != StatusQueued || !store.Start("task[0]") || store.Start("task[0]") || !store.Fail("task[0]") {
		t.Fatal("queued -> running -> failed transition failed")
	}
	snapshot, _ := store.Lookup("task[0]")
	if snapshot.Status != StatusFailed || store.Complete("task[0]", stats.Counts{Words: 1}) || store.Cancel("task[0]") || first.Status != StatusQueued {
		t.Fatalf("failed snapshot or copied value changed: first=%+v last=%+v", first, snapshot)
	}
	if _, ok := store.Lookup("task[missing]"); ok {
		t.Fatal("missing task was accepted")
	}
}

func TestStoreOnlyOneClaim(t *testing.T) {
	store := newTaskStore([]string{"Go"})
	start := make(chan struct{})
	claimed := make(chan bool, 32)
	for index := 0; index < cap(claimed); index++ {
		go func() {
			<-start
			claimed <- store.Start("task[0]")
		}()
	}
	close(start)
	successes := 0
	for index := 0; index < cap(claimed); index++ {
		if <-claimed {
			successes++
		}
	}
	if successes != 1 {
		t.Fatalf("concurrent successful claims=%d; want 1", successes)
	}
	store.CancelOpen()
	record, _ := store.Lookup("task[0]")
	if record.Status != StatusCanceled || store.Complete("task[0]", stats.Counts{Words: 1}) {
		t.Fatalf("cancel after claim failed: %+v", record)
	}
	t.Logf("claim successes=%d; canceled after owner stopped", successes)
}

func TestCancelDuringCalculationKeepsTerminalStatus(t *testing.T) {
	store := newTaskStore([]string{"Go"})
	started := make(chan struct{})
	release := make(chan struct{})
	returned := make(chan []taskOutcome)
	go func() {
		results, _ := processTasksContextUsingStore(context.Background(), []string{"Go"}, 3, func(_ context.Context, text string, _ int) (stats.Counts, error) {
			close(started)
			<-release
			return stats.Analyze(text), nil
		}, store)
		returned <- results
	}()
	<-started
	running, _ := store.Lookup("task[0]")
	if running.Status != StatusRunning || !store.Cancel("task[0]") {
		t.Fatalf("running status/cancel failed: %+v", running)
	}
	requested, _ := store.Lookup("task[0]")
	if requested.Status != StatusRunning || !requested.CancelRequested {
		t.Fatalf("request was falsely committed as exit: %+v", requested)
	}
	close(release)
	results := <-returned
	terminal, _ := store.Lookup("task[0]")
	if terminal.Status != StatusCanceled || terminal.Words != 0 || len(results) != 1 || results[0].err != context.Canceled {
		t.Fatalf("terminal=%+v results=%+v", terminal, results)
	}
	t.Logf("running -> canceled; late completion rejected: status=%s words=%d", terminal.Status, terminal.Words)
}
