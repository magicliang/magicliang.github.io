#!/usr/bin/env bash
set -u
root=$(cd "$(dirname "$0")/../../.." && pwd)
evidence="$root/writing-plans/go-language/evidence/23"
mkdir -p "$evidence"
export PATH="/tmp/go-language-toolchain-1.27.1/go/bin:$PATH"
export GOTOOLCHAIN=local GOWORK=off GOMAXPROCS=2 CGO_ENABLED=1
cd "$root/examples/go-language" || exit 1
date -Ins > "$evidence/environment.txt"
uname -smr >> "$evidence/environment.txt"
go version >> "$evidence/environment.txt"
go env GOOS GOARCH GOTOOLCHAIN GOWORK GOMAXPROCS CGO_ENABLED CC GOMOD >> "$evidence/environment.txt"
gcc --version | head -1 >> "$evidence/environment.txt"

capture() {
  local name=$1 command=$2 exit_code
  printf '%s\n' "$command" > "$evidence/$name.command"
  bash -c "$command" > "$evidence/$name.stdout" 2> "$evidence/$name.stderr"
  exit_code=$?
  printf '%s\n' "$exit_code" > "$evidence/$name.exit"
  printf '%s exit=%s\n' "$name" "$exit_code"
}

capture doc-request-context 'go doc net/http.Request.Context'
capture doc-server-shutdown 'go doc net/http.Server.Shutdown'
capture doc-cancel 'go doc context.CancelFunc'
capture doc-mux 'go doc net/http.ServeMux'
capture tidy 'go mod tidy -diff'
capture focused "go test -count=1 -run 'TestHTTPExplicitCancel|TestHTTPQueuedCancel|TestHTTPClientCancel' -v ."
capture repeat "go test -count=30 -run 'TestHTTPExplicitCancel|TestHTTPQueuedCancel|TestHTTPClientCancel' -v ."
capture tests 'go test -count=1 -v ./...'
capture race "go test -race -count=1 -run 'TestHTTPExplicitCancel|TestHTTPQueuedCancel|TestHTTPClientCancel' -v ."
capture race-full 'go test -race -count=1 ./...'
capture build 'go build -o /tmp/go-language-23-taskstats .'
capture cli-batch "/tmp/go-language-23-taskstats --batch 'Go|one two|Go' --workers 2 --queue-capacity 1"
capture cli-timeout '/tmp/go-language-23-taskstats --text Go --timeout 0s --workers 2'
capture module 'go list -m all'
