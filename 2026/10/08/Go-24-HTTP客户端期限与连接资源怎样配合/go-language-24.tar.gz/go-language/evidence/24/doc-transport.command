go doc net/http.Transport
