# 24 原始实验索引

`environment.txt` 记录实际 Go 1.27.1、平台、GCC/CGO、module；每项 `.command/.stdout/.stderr/.exit` 是实际命令、原始双流和进程退出码。`doc-*` 是本版 HTTP Client.Timeout、Response.Body、net.Dialer.Timeout、Transport 和 NewRequestWithContext 一手资料。`focused`/`repeat` 用 loopback 合成下游验证 40 次交替 200/503 的响应体排空与新连接数、4097 字节错误体、真实慢首字节请求超时及**模拟**阻塞拨号、下游超时使已接受任务 FAILED、单任务取消传到下游；四条用例各重跑 20 次。模拟拨号期限不是 OS 真实 TCP 连通性/超时测量，该项仍 `NOT_RUN`。`race`/`race-full` 本机结果只覆盖运行过的路径。CLI 零期限预期退出 2。归档解包与静态页面证据完成后补充，页面 200 不替代真实下游与 Go 验证。
