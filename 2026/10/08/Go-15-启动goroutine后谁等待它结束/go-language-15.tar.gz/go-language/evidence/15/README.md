# 15 原始实验索引

`environment.txt` 记本次工具链、环境和平台。每个 `名称.command` 为实际执行的命令，`名称.stdout` 和 `名称.stderr` 为原始双流，`名称.exit` 为进程退出码；同名文件必须一起阅读。`tests` 为两个包的完整回归；`gated-repeat` 在同样闸门测试上重复 30 次（不是不同机器的性能试验）。`premature` 是教学反例：程序退出 0，但第一次只确认开始，并没有确认完成。`invalid`、`missing` 退出 2 是预期业务错误，不是测试失败。`spec`、`memory` 保存固定工具链一手文档片段。`hexo-*`、`page-*`、`http-*` 与 `unpack-*` 在对应验收后再记录，生成页面不替代 Go 实验。

目前仅同一命令行调用栈的计算者由调用者等待，未运行 race 检测（本次 `CGO_ENABLED=0`）、其他 OS/架构、长期压力、HTTP、SQL、生产发布；官方 Gitiles SHA 交叉验证 `NOT_RUN`。参阅 `writing-plans/go-language/research/15.md` 的规范/观察分层。
