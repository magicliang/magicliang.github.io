package main

import "fmt"

type missingError struct{}

func (*missingError) Error() string { return "missing" }

func incorrectSuccess() error {
	var failure *missingError
	return failure
}

func correctSuccess() error {
	return nil
}

func main() {
	bad := incorrectSuccess()
	badPointer, badType := bad.(*missingError)
	fmt.Printf("bad: error-is-nil=%t type-ok=%t pointer-is-nil=%t\n", bad == nil, badType, badPointer == nil)
	good := correctSuccess()
	goodPointer, goodType := good.(*missingError)
	fmt.Printf("good: error-is-nil=%t type-ok=%t pointer-is-nil=%t\n", good == nil, goodType, goodPointer == nil)
}
