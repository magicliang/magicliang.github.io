package main

import "fmt"

func main() {
	maxWords := 3
	requested := 1
	if requested > 0 {
		maxWords := requested
		_ = maxWords
	}
	fmt.Printf("max-words=%d\n", maxWords)
}
