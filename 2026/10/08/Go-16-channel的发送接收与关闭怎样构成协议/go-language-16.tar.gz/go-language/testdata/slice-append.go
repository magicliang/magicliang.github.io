package main

import "fmt"

func main() {
	spare := make([]string, 1, 2)
	spare[0] = "first"
	otherView := spare[:2]
	otherView[1] = "guard"
	withSpare := append(spare, "added")
	fmt.Printf("spare: appended=%q other-view=%q\n", withSpare[1], otherView[1])

	full := []string{"first"}
	withNewArray := append(full, "added")
	withNewArray[0] = "changed"
	fmt.Printf("full: appended=%q original=%q\n", withNewArray[0], full[0])
}
