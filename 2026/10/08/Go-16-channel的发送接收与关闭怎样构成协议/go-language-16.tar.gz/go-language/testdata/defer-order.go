package main

import "fmt"

func calculate() (result int) {
	result = 1
	defer fmt.Println("argument", result)
	defer func() {
		fmt.Println("closure", result)
		result = 3
	}()
	return 2
}

func main() {
	fmt.Println("return", calculate())
}
