package main

import "fmt"

func main() {
	started := make(chan struct{})
	release := make(chan struct{})
	done := make(chan struct{})
	go func() {
		close(started)
		<-release
		close(done)
	}()
	<-started
	select {
	case <-done:
		fmt.Println("completed")
	default:
		fmt.Println("started does not mean completed")
	}
	close(release)
	<-done
	fmt.Println("completion confirmed")
}
