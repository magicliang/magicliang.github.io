package main

func main() {
	var positions map[string]int
	positions["task[0]"] = 0
}
