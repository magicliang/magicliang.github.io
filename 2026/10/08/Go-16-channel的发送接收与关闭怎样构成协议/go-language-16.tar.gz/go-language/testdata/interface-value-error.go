package main

type lookup interface {
	find(string) bool
}

type tasks struct{}

func (*tasks) find(string) bool {
	return true
}

var _ lookup = tasks{}

func main() {}
