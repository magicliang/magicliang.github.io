package main

func main() {
	queue := make(chan int, 1)
	close(queue)
	queue <- 1
}
