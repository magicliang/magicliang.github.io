package main

type hasSummary interface {
	Summary() string
}

func summaries[T hasSummary](records []T) []string {
	return make([]string, len(records))
}

func main() {
	_ = summaries([]int{1})
}
