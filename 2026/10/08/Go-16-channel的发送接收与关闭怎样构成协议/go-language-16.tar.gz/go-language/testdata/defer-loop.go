package main

import (
	"fmt"
	"os"
	"strings"
)

func descriptorCount(prefix string) int {
	entries, err := os.ReadDir("/proc/self/fd")
	if err != nil {
		panic(err)
	}
	count := 0
	for _, entry := range entries {
		target, err := os.Readlink("/proc/self/fd/" + entry.Name())
		if err == nil && strings.Contains(target, prefix) {
			count++
		}
	}
	return count
}

func accumulate(prefix string) int {
	before := descriptorCount(prefix)
	for index := 0; index < 3; index++ {
		file, err := os.CreateTemp("", prefix)
		if err != nil {
			panic(err)
		}
		defer os.Remove(file.Name())
		defer file.Close()
	}
	return descriptorCount(prefix) - before
}

func main() {
	prefix := fmt.Sprintf("go-language-defer-%d-", os.Getpid())
	before := descriptorCount(prefix)
	during := accumulate(prefix)
	after := descriptorCount(prefix)
	fmt.Printf("inside-open=%d after-open=%d\n", during, after-before)
}
