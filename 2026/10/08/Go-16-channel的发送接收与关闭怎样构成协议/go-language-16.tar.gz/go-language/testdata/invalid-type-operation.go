package main

type hasSummary interface {
	Summary() string
}

func words[T hasSummary](value T) int {
	return value.Words
}

func main() {}
