package main

type record struct{}

func (*record) markSucceeded() {}

func newRecord() record {
	return record{}
}

func main() {
	newRecord().markSucceeded()
}
