package main

import "fmt"

func main() {
	fmt.Printf("recover-outside-defer=%v\n", recover())
	panic("unhandled failure")
}
