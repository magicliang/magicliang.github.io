package main

import (
	"reflect"
	"testing"
)

func TestAppendAfterResliceMutatesCallerArray(t *testing.T) {
	backing := []string{"one", "two", "guard", "spare"}
	input := backing[:2:4]
	items := input[1:]
	items = append(items, "three")
	if !reflect.DeepEqual(items, []string{"two", "three"}) {
		t.Fatalf("items = %v", items)
	}
	if !reflect.DeepEqual(backing, []string{"one", "two", "guard", "spare"}) {
		t.Fatalf("input backing array modified: %v", backing)
	}
}
