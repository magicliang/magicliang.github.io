package main

import "fmt"

func main() {
	values := []string{"A", "B", "C"}
	var readers []func() string
	for _, value := range values {
		readers = append(readers, func() string { return value })
	}
	fmt.Println(readers[0](), readers[1](), readers[2]())
}
