package main

import "testing"

func TestValidateConfig(t *testing.T) {
	for _, testCase := range []struct {
		name    string
		config  Config
		wantErr bool
	}{
		{name: "zero value", config: Config{}, wantErr: true},
		{name: "positive", config: Config{MaxWords: 3}},
		{name: "negative", config: Config{MaxWords: -1}, wantErr: true},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			if err := validateConfig(testCase.config); (err != nil) != testCase.wantErr {
				t.Errorf("validateConfig(%+v) error = %v; wantErr %t", testCase.config, err, testCase.wantErr)
			}
		})
	}
}
