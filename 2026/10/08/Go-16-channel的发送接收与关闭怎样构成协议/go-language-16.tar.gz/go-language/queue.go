package main

import "example.com/go-language-task/stats"

type queuedTask struct {
	position int
	text     string
}

type taskOutcome struct {
	position int
	counts   stats.Counts
	err      error
}

func processTasks(tasks []string, maxWords int) []taskOutcome {
	return processTasksUsing(tasks, maxWords, stats.Analyze)
}

func processTasksUsing(tasks []string, maxWords int, analyze func(string) stats.Counts) []taskOutcome {
	inputs := make(chan queuedTask, 1)
	outputs := make(chan taskOutcome)
	go func() {
		defer close(inputs)
		for position, text := range tasks {
			inputs <- queuedTask{position: position, text: text}
		}
	}()
	go func() {
		defer close(outputs)
		for task := range inputs {
			counts, err := analyzeTaskAsyncUsing(task.text, maxWords, analyze)
			outputs <- taskOutcome{position: task.position, counts: counts, err: err}
		}
	}()
	results := make([]taskOutcome, len(tasks))
	for result := range outputs {
		results[result.position] = result
	}
	return results
}
