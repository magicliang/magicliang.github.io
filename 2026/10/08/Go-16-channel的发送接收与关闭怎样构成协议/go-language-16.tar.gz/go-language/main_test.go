package main

import (
	"bytes"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestRun(t *testing.T) {
	filePath := filepath.Join(t.TempDir(), "input.txt")
	if err := os.WriteFile(filePath, []byte("Go 写 Go"), 0600); err != nil {
		t.Fatal(err)
	}
	for _, testCase := range []struct {
		name          string
		args          []string
		code          int
		output        string
		errorContains string
	}{
		{name: "valid", args: []string{"--text", "Go 写 Go"}, code: 0, output: "words=3 bytes=9 runes=7\n"},
		{name: "explicit limit", args: []string{"--text", "Go", "--max-words", "1"}, code: 0, output: "words=1 bytes=2 runes=2\n"},
		{name: "batch", args: []string{"--batch", "one two|Go 写 Go"}, code: 0, output: "task[0] words=2 bytes=7 runes=7\ntask[1] words=3 bytes=9 runes=7\n"},
		{name: "batch edit", args: []string{"--batch", "one two|Go 写 Go", "--drop-first", "--append", "again"}, code: 0, output: "task[0] words=3 bytes=9 runes=7\ntask[1] words=1 bytes=5 runes=5\n"},
		{name: "lookup zero", args: []string{"--batch", "Go|one two", "--lookup", "task[0]"}, code: 0, output: "task[0] words=1 bytes=2 runes=2\n"},
		{name: "lookup unknown", args: []string{"--batch", "Go|one two", "--lookup", "task[missing]"}, code: 2, errorContains: "task not found:"},
		{name: "list IDs", args: []string{"--batch", "Go|one two", "--list-ids"}, code: 0, output: "task[0]\ntask[1]\n"},
		{name: "lookup list conflict", args: []string{"--batch", "Go", "--lookup", "task[0]", "--list-ids"}, code: 2, errorContains: "usage:"},
		{name: "lookup on text", args: []string{"--text", "Go", "--lookup", "task[0]"}, code: 2, errorContains: "usage:"},
		{name: "unknown cannot mask bad batch", args: []string{"--batch", "Go|", "--lookup", "task[missing]"}, code: 2, errorContains: "text must not be empty"},
		{name: "batch empty after drop", args: []string{"--batch", "Go", "--drop-first"}, code: 2, errorContains: "batch must contain at least one item"},
		{name: "batch empty append", args: []string{"--batch", "Go", "--append", ""}, code: 2, errorContains: "text must not be empty"},
		{name: "edit on file", args: []string{"--file", filePath, "--append", "Go"}, code: 2, errorContains: "usage:"},
		{name: "file", args: []string{"--file", filePath}, code: 0, output: "words=3 bytes=9 runes=7\n"},
		{name: "missing file", args: []string{"--file", filepath.Join(t.TempDir(), "missing.txt")}, code: 2, errorContains: "read file:"},
		{name: "file and batch", args: []string{"--file", filePath, "--batch", "Go"}, code: 2, errorContains: "usage:"},
		{name: "empty", args: []string{"--text", "  "}, code: 2, errorContains: "usage:"},
		{name: "empty batch", args: []string{"--batch", ""}, code: 2, errorContains: "usage:"},
		{name: "middle empty", args: []string{"--batch", "Go||Go"}, code: 2, errorContains: "text must not be empty"},
		{name: "both modes", args: []string{"--text", "Go", "--batch", "Go"}, code: 2, errorContains: "usage:"},
		{name: "batch second over limit", args: []string{"--batch", "one two|one two three four"}, code: 2, errorContains: "exceeds max-words"},
		{name: "unknown flag", args: []string{"--invalid"}, code: 2, errorContains: "flag provided"},
		{name: "extra argument", args: []string{"--text", "Go", "extra"}, code: 2, errorContains: "usage:"},
		{name: "zero limit", args: []string{"--text", "Go 写 Go", "--max-words", "0"}, code: 2, errorContains: "max-words must be positive"},
		{name: "invalid config before empty", args: []string{"--text", " ", "--max-words", "0"}, code: 2, errorContains: "max-words must be positive"},
		{name: "negative limit", args: []string{"--text", "Go", "--max-words", "-1"}, code: 2, errorContains: "max-words must be positive"},
		{name: "over limit", args: []string{"--text", "one two three four"}, code: 2, errorContains: "exceeds max-words"},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			var stdout, stderr bytes.Buffer
			if got := run(testCase.args, &stdout, &stderr); got != testCase.code {
				t.Errorf("exit code = %d; want %d", got, testCase.code)
			}
			if got := stdout.String(); got != testCase.output {
				t.Errorf("stdout = %q; want %q", got, testCase.output)
			}
			if !strings.Contains(stderr.String(), testCase.errorContains) || (testCase.code == 0 && stderr.Len() != 0) {
				t.Errorf("unexpected stderr: %q", stderr.String())
			}
		})
	}
}
