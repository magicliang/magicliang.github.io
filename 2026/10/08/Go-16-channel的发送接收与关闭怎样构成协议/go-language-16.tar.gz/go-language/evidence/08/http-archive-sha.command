sha256sum /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/08/http-archive.body
