curl -fsS -o /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/08/http-post.body -w %{http_code} http://127.0.0.1:18979/2026/10/07/Go-08-任务记录的复制与指针更新/
