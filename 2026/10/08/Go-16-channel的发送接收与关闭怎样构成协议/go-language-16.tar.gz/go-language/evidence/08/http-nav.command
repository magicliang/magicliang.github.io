curl -fsS -o /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/08/http-nav.body -w %{http_code} http://127.0.0.1:18979/go-language/
