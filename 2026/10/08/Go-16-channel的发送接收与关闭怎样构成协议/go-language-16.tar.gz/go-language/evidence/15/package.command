tar -C /tmp/go-language-15-pack.NYQN0L -czf /home/admin/workspace/my-blogs/source/_posts/2026-10-08-Go-15-启动goroutine后谁等待它结束/go-language-15.tar.gz go-language
