sed -n "6962,6995p" /tmp/go-language-toolchain-1.27.1/go/doc/go_spec.html
