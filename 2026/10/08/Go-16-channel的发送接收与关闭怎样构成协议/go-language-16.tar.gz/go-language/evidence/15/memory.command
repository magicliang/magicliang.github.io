sed -n "395,414p" /tmp/go-language-toolchain-1.27.1/go/doc/go_mem.html
