sha256sum /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/15/http-archive.body
