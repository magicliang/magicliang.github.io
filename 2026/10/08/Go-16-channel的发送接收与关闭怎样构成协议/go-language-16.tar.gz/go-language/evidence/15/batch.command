/tmp/go-language-15-taskstats --batch "Go|one two"
