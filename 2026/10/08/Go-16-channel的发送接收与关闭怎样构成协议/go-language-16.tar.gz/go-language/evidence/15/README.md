# 15 原始实验索引

`environment.txt` 记本次工具链、环境和平台。每个 `名称.command` 为实际执行的命令，`名称.stdout` 和 `名称.stderr` 为原始双流，`名称.exit` 为进程退出码；同名文件必须一起阅读。`tests` 为两个包的完整回归；`gated-repeat` 在同样闸门测试上重复 30 次（不是不同机器的性能试验）。`premature` 是教学反例：程序退出 0，但第一次只确认开始，并没有确认完成。`invalid`、`missing` 退出 2 是预期业务错误，不是测试失败。`spec`、`memory` 保存固定工具链一手文档片段。

素材目录的 `unpack-*` 保存独立解包复跑；本目录 `package.*`、`hexo-*`、`page-*`、`http-*` 保存打包、隔离 Hexo 生成、页面链接与本地静态 HTTP 四资源 200 的实际检查。下载包 `http-archive.body` 的 SHA-256 与素材 `SHA256SUMS` 相同。页面检查曾直接比较百分号编码的链接文字而误报一次，后按 URL 解码及文件存在性断言修正并复跑退出 0；HTTP 第一次记录脚本在 zsh 中误将局部变量命名为保留参数 `path`，导致四次 `curl` 均无法启动、退出 127；原始错误保存在 `http-*-attempt1.*`，后续 `http-*` 是更正后成功记录。生成页面不替代 Go 实验。

目前仅同一命令行调用栈的计算者由调用者等待，未运行 race 检测（本次 `CGO_ENABLED=0`）、其他 OS/架构、长期压力、HTTP、SQL、生产发布；官方 Gitiles SHA 交叉验证 `NOT_RUN`。参阅 `writing-plans/go-language/research/15.md` 的规范/观察分层。
