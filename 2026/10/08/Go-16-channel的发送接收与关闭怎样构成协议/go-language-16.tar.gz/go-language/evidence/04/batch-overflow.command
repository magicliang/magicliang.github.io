/tmp/go-language-04-taskstats --batch one two|one two three four
