/tmp/go-language-04-taskstats --batch Go||Go
