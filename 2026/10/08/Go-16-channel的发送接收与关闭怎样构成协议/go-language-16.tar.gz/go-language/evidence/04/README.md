# 04 原始证据索引

`environment.txt` 冻结工具链及 `go.mod` 的语言版本。`.command`、`.stdout`、`.stderr`、`.exit` 保存每项实际命令与退出码。

- `test.*`、`build.*`、`single.*`、`batch.*`：两包测试与编译退出 0，单次 CLI 旧输出保留，批量逐项输出序号与统计数值。
- `batch-empty.*`、`batch-overflow.*`、`both-modes.*`：任一项目非法或两种模式同时使用均退出 2，stdout 为空，即使前一项已经在内存中计算；不表示有数据库事务或任务执行回滚。
- `loop-declare.*`、`loop-assign.*`：同一 Go 1.27.1 下，无 goroutine，`:=` 每轮声明给出 `A B C`，向预声明变量赋值给出 `C C C`；两次程序退出都为 0。后者是“意图捕获每轮值”时的语义反例，不是假装命令发生编译错误。

04 同名素材包已含当章完整累计工程及 00–04 原始 Go 证据；同目录 `unpack-*` 记录实际解包复跑、SHA-256 检查、两包测试及正反批次/循环对照。`hexo-isolated.*` 用仓库原配置/主题只载入 Go 00–04，生成退出 0；`page-check-00/01/02/03/04.*` 验证各篇页面、导航与复制后的归档摘要均通过。04 的 `http-post/nav/archive/sums.*` 均为本地静态 HTTP 200 / curl 退出 0，下载摘要吻合。这里没有运行任务服务 HTTP API，完整仓库对 04 的新内容生成仍 `NOT_RUN`。
