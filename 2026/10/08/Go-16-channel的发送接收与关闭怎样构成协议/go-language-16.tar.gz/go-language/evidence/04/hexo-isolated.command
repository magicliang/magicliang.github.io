PATH=/home/admin/.nvm/versions/node/v22.23.2/bin:$PATH hexo generate --force --bail (original config/theme/deps, Go 00–04 source only)
