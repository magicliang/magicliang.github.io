curl -fsS -o http-post.body -w %{http_code} http://127.0.0.1:18975/2026/10/07/Go-04-循环变量为何影响批量任务/
