/tmp/go-language-04-taskstats --text Go --batch Go
