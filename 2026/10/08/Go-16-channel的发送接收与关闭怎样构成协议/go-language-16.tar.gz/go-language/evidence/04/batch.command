/tmp/go-language-04-taskstats --batch one two|Go 写 Go
