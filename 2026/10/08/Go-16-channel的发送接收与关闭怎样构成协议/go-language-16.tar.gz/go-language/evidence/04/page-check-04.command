python3 writing-plans/go-language/scripts/check_page_00.py '/tmp/go-language-hexo-VCDnJ0/public' 04
