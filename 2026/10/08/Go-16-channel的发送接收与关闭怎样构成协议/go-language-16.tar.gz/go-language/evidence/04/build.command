go build -o /tmp/go-language-04-taskstats .
