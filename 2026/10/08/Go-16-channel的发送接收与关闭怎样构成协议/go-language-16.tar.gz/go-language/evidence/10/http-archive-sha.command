sha256sum /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/10/http-archive.body
