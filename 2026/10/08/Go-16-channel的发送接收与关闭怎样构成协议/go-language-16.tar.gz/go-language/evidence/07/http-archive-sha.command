sha256sum /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/07/http-archive.body
