In temporary minimal Hexo site: PATH=/home/admin/.nvm/versions/node/v22.23.2/bin:$PATH hexo generate --bail (symlinked root config/theme/dependencies and Go post/assets/navigation only)
