PATH=/home/admin/.nvm/versions/node/v22.23.2/bin:$PATH npm run build
