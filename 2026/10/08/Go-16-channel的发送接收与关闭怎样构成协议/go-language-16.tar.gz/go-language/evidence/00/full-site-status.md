# 全站生成状态：00 已验证；01 未纳入

`PATH=/home/admin/.nvm/versions/node/v22.23.2/bin:$PATH npm run build` 与其他两个会话的全站构建并行，一度只输出 `INFO Start processing`，曾试图终止本轮一个 Hexo 子进程。随后本轮构建**实际完成**，`hexo-build.exit=0`，日志最后一行 `4435 files generated in 59 s`。最初提交 00 时日志仍未收齐，因此旧提交中的状态快照为 `NOT_RUN`；本文件记录随后观察到的最终结果，不把先前中间判断当结论。

00 正文也存在于该次 `public/` 全站输出，经 `writing-plans/go-language/evidence/01/full-page-00.*` 检查正文、导航和归档链接均通过。构建启动时 01 尚不存在，`public/` 没有 01 页面，`evidence/01/full-page-01.*` 明确失败；**不能**用全站 00 的退出 0 声称 01 已在全站生成。01 在 `/tmp` 中的独立 Hexo 临时站点用仓库原配置、主题及 `node_modules` 生成并检查，HTTP 页面与资产检查通过；01 的全站生成仍 `NOT_RUN`。并行站点变动对整个仓库其他页面的回归并未逐一检查。
