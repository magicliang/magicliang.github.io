curl -fsS -o http-archive.body -w %{http_code} http://127.0.0.1:18971/2026/10/07/Go-00-从一个任务看懂Go工程/go-language-00.tar.gz
