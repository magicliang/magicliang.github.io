git ls-remote https://gitee.com/mirrors/go.git refs/tags/go1.27.1
