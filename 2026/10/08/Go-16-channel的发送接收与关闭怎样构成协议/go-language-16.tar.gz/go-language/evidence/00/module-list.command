go list -m all
