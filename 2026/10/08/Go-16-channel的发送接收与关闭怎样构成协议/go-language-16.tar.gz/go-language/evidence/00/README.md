# 00 原始证据索引

每项命令的 `.command`、`.stdout`、`.stderr`、`.exit` 分别保存命令、原始标准输出、原始标准错误和退出码；`GOTOOLCHAIN=local GOMAXPROCS=2 CGO_ENABLED=0` 见 `environment.txt`。临时 CLI 二进制位于 `/tmp/go-language-00-taskstats`，不提交。

- `toolchain-sha.*`：官方压缩包 SHA-256 验证，退出 0；`source-sha.*`：Go 镜像 tag Git SHA，退出 0。
- `go-version.*`、`go-env.*`、`platform.*`、`resource-limits.*`：环境；`initial-resource-limits.txt` 保留首次尝试 cgroup v2 文件不存在的原始错误，随后按真实 cgroup v1 修正。
- `initial-test.*`：初次 `go.mod` 冗余指令导致退出 1；修正后的 `tidy-check.*`、`module-list.*`、`test.*`、`build.*`、`binary-metadata.*` 均退出 0。
- `cli-ascii.*`、`cli-chinese.*` 退出 0；`cli-invalid.*`、`cli-unknown.*` 退出 2，错误输出在 stderr。
- `mutation.diff` 和 `mutation.*`：只改**临时副本**的计数实现，`go test` 退出 1 且断言失败；累计工程随后保持通过状态。
- `initial-hexo-isolated.*` 的生成退出 0，但实页检查发现模板标签嵌入 Markdown 链接后产生无效 `!--swig...` 地址；改用相对素材路径和明确的站内路径后，`hexo-isolated.*` 生成退出 0，`page-check.*` 逐个检查正文、导航、素材及生成后 SHA-256，退出 0。`initial-page-check.*` 保留检查器最初误将两处相同下载链接算作失败的原始记录。
- `http-post.*`、`http-nav.*`、`http-archive.*`、`http-sums.*` 是本地 127.0.0.1 静态页面请求的原始 body、HTTP 状态码和 curl 退出码，均为 200 / 0；下载归档 SHA 与正文素材一致。`hexo-build.*` 的全站尝试后续完成且退出 0，过程与 01 未纳入的边界详见 `full-site-status.md`。

原始 Go/CLI 命令只证明当前输入与环境；本地静态页面 HTTP 200 不等于未来的任务服务 HTTP 实验。任务服务的 HTTP、SQL、并发、race 和云端发布均未运行，不在这里宣称通过。
