In temporary minimal Hexo site: PATH=/home/admin/.nvm/versions/node/v22.23.2/bin:$PATH hexo generate --force --bail (root config/theme/deps and only Go article/assets/navigation)
