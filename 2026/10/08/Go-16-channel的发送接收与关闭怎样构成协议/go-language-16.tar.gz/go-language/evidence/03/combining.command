/tmp/go-language-03-taskstats --text é
