curl -fsS -o http-nav.body -w %{http_code} http://127.0.0.1:18974/go-language/
