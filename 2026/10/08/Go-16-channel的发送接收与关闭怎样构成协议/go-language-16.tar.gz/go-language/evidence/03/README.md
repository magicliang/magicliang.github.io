# 03 原始证据索引

版本环境见 `environment.txt`；每项 `.command`、`.stdout`、`.stderr`、`.exit` 保存实际命令、双流和退出码。`test.*`、`build.*` 退出 0；ASCII、中文、结合符正例 `ascii.*`、`chinese.*`、`combining.*` 退出 0；空串 CLI `empty.*` 及缩小字段上限的 `max-words.*` 退出 2。`TestAnalyze/Empty` 在统计包内断言空串的三个计数都是 0；CLI 因入口契约拒绝空串，两者不矛盾。

故意误把字节数算作码点数的临时副本差异见 `rune-as-byte.diff`，同样的两包测试退出 1：中文与结合符断言检测出错误；并未把错误版本写进累计工程。`doc-runes.*`、`doc-count.*` 保留冻结版本的标准库文档命令及原始输出。

03 同名素材包包含完整累计工程、`RUN.md`/`VERSIONS.md` 和 00–03 原始 Go 实验；素材目录 `unpack-*` 证明从包内独立解压后 Go 1.27.1 上测试/构建通过，正反 CLI 退出码符合规则。`hexo-isolated.*` 用原配置与主题只加载 Go 00–03，生成退出 0，`page-check-00/01/02/03.*` 验证各页双向导航与归档摘要。`http-post/nav/archive/sums.*` 的本地静态 HTTP 响应均 200，curl 退出 0，下载摘要匹配。实际任务服务的 HTTP、SQL 与全仓纳入 03 的生成仍 `NOT_RUN`。
