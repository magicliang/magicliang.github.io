curl -fsS -o http-sums.body -w %{http_code} http://127.0.0.1:18974/2026/10/07/Go-03-byte-rune-和字段数怎样区分/SHA256SUMS
