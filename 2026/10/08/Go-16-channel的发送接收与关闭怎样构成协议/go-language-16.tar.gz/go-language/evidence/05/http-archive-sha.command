sha256sum /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/05/http-archive.body
