GOTOOLCHAIN=local go run ./testdata/defer-loop.go (initial total /proc/self/fd count; later rejected as ownership metric)
