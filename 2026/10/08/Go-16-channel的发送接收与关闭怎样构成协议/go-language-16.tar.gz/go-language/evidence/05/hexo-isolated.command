PATH=/home/admin/.nvm/versions/node/v22.23.2/bin:$PATH hexo generate --force --bail (isolated site Go 00-05 only)
