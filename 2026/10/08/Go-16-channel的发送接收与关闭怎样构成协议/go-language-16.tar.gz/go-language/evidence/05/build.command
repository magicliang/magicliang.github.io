go build -o /tmp/go-language-05-bTjFeJ/taskstats .
