/tmp/go-language-05-bTjFeJ/taskstats --batch one\ two\|Go\ 写\ Go
