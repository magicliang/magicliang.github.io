curl -fsS -o /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/05/http-archive.body -w %{http_code} http://127.0.0.1:18976/2026/10/07/Go-05-defer-何时关闭任务输入/go-language-05.tar.gz
