go doc -src os.Open
