/tmp/go-language-05-bTjFeJ/taskstats --file /tmp/go-language-05-bTjFeJ/input.txt
