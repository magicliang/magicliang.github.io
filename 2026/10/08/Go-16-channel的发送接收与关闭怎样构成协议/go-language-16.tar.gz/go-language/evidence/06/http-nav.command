curl -fsS -o /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/06/http-nav.body -w %{http_code} http://127.0.0.1:18977/go-language/
