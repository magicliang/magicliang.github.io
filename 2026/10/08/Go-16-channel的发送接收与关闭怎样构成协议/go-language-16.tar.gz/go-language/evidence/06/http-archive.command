curl -fsS -o /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/06/http-archive.body -w %{http_code} http://127.0.0.1:18977/2026/10/07/Go-06-slice-复制为何仍会改写任务输入/go-language-06.tar.gz
