sha256sum /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/06/http-archive.body
