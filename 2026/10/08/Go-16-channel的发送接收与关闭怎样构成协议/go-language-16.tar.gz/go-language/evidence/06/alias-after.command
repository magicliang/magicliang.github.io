go test -count=1 -run TestPrepareBatchDoesNotChangeInput -v .
