# 02 原始证据索引

环境见 `environment.txt`。每项 `.command`、`.stdout`、`.stderr`、`.exit` 分别保存原始命令、双流与退出码。

- `go-version.*`、`tidy-check.*`、`test.*`、`build.*`：工具链与双包测试、编译，退出均为 0；`test.stdout` 同时含配置零值、显式值、错误输入和原有 CLI、统计断言。
- `default.*`、`explicit.*`：正例输出 `words=3`、`words=1`，退出 0；`zero.*`、`negative.*`、`overflow.*`：错误配置或超限，标准输出空，标准错误记录具体原因，退出 2。
- `shadow.*` 与 `assignment.*`：相同初值 3 和请求值 1，`:=` 错误遮蔽打印 3、`=` 正确赋值打印 1，两者进程均退出 0。前者结果不符合请求值，是语义反例，不是用非零退出码冒充反例。

02 素材包已包含截至本章的完整累计工程、`RUN.md`/`VERSIONS.md` 和 00–02 原始 Go 证据。素材目录的 `unpack-*` 记录实际解包复跑及 SHA-256 校验，退出码符合原实验。

`hexo-isolated.*` 使用仓库原配置、主题和依赖，仅加载 Go 00–02，生成退出 0；`page-check-00/01/02.*` 从生成后的实际 HTML 核对正文、导航、素材与复制后的摘要，均退出 0。`http-post.*`、`http-nav.*`、`http-archive.*`、`http-sums.*` 用本地静态 HTTP 访问本章页面、导航与两个素材文件，HTTP 200 且 curl 退出 0；下载归档摘要吻合。这些 HTTP 请求不是尚未实现的任务服务 API。全仓对包含 02 的生成与页面回归仍 `NOT_RUN`。
