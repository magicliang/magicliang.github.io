/tmp/go-language-02-taskstats --text one two three four
