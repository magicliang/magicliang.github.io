curl -fsS -o http-sums.body -w %{http_code} http://127.0.0.1:18973/2026/10/07/Go-02-零值和作用域如何改变配置/SHA256SUMS
