/tmp/go-language-02-taskstats --text Go 写 Go --max-words 0
