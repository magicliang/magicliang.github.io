curl -fsS -o /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/13/http-sums.body -w %{http_code} http://127.0.0.1:18984/2026/10/07/Go-13-泛型约束能替结果集合省下什么/SHA256SUMS
