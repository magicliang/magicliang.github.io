sha256sum /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/13/http-archive.body
