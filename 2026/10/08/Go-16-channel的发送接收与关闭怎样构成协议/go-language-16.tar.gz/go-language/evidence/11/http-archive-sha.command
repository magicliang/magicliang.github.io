sha256sum /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/11/http-archive.body
