PATH=/home/admin/.nvm/versions/node/v22.23.2/bin:$PATH ./node_modules/.bin/hexo generate --force --bail (isolated Go 00-09)
