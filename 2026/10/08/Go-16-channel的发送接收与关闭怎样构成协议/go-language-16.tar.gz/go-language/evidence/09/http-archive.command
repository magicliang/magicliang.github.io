curl -fsS -o /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/09/http-archive.body -w %{http_code} http://127.0.0.1:18980/2026/10/07/Go-09-接口由谁需要的方法决定/go-language-09.tar.gz
