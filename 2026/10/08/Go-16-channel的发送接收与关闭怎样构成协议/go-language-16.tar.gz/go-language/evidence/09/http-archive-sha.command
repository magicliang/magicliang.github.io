sha256sum /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/09/http-archive.body
