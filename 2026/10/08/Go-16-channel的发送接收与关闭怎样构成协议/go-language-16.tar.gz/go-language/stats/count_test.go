package stats

import "testing"

func TestCountWords(t *testing.T) {
	for _, testCase := range []struct {
		name string
		text string
		want int
	}{
		{name: "ASCII", text: "one two", want: 2},
		{name: "Chinese", text: "Go 写 Go", want: 3},
		{name: "Whitespace", text: "\t \n", want: 0},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			if got := CountWords(testCase.text); got != testCase.want {
				t.Errorf("CountWords(%q) = %d; want %d", testCase.text, got, testCase.want)
			}
		})
	}
}

func TestAnalyze(t *testing.T) {
	for _, testCase := range []struct {
		name string
		text string
		want Counts
	}{
		{name: "ASCII", text: "one two", want: Counts{Words: 2, Bytes: 7, Runes: 7}},
		{name: "Chinese", text: "Go 写 Go", want: Counts{Words: 3, Bytes: 9, Runes: 7}},
		{name: "Empty", text: "", want: Counts{}},
		{name: "Combining mark", text: "e\u0301", want: Counts{Words: 1, Bytes: 3, Runes: 2}},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			if got := Analyze(testCase.text); got != testCase.want {
				t.Errorf("Analyze(%q) = %+v; want %+v", testCase.text, got, testCase.want)
			}
		})
	}
}
