package stats

import (
	"strings"
	"unicode/utf8"
)

type Counts struct {
	Words int
	Bytes int
	Runes int
}

func CountWords(text string) int {
	return len(strings.Fields(text))
}

func Analyze(text string) Counts {
	return Counts{
		Words: CountWords(text),
		Bytes: len(text),
		Runes: utf8.RuneCountInString(text),
	}
}
