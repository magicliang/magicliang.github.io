package main

func prepareBatch(input []string, appended string, appendRequested, dropFirst bool) []string {
	owned := make([]string, len(input))
	copy(owned, input)
	if dropFirst {
		owned = owned[1:]
	}
	if appendRequested {
		owned = append(owned, appended)
	}
	return owned
}
