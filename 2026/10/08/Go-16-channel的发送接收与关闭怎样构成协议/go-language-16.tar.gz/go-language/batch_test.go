package main

import (
	"reflect"
	"testing"
)

func TestPrepareBatchDoesNotChangeInput(t *testing.T) {
	backing := []string{"one", "two", "guard", "spare"}
	input := backing[:2:4]
	prepared := prepareBatch(input, "three", true, true)
	if !reflect.DeepEqual(prepared, []string{"two", "three"}) {
		t.Fatalf("prepared = %v", prepared)
	}
	if !reflect.DeepEqual(backing, []string{"one", "two", "guard", "spare"}) {
		t.Fatalf("input backing array modified: %v", backing)
	}
	prepared[0] = "changed"
	if input[1] != "two" {
		t.Fatalf("prepared aliases input: input = %v", input)
	}
}

func TestArrayValueCopiesElements(t *testing.T) {
	original := [2]string{"one", "two"}
	cloned := original
	cloned[0] = "changed"
	if original[0] != "one" {
		t.Fatalf("array copy changed original: %v", original)
	}
}
