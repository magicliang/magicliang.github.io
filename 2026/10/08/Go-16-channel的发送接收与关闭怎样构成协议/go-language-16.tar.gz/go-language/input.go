package main

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
)

const maxInputBytes = 64 * 1024

func readInputFile(path string) (string, error) {
	file, err := os.Open(path)
	if err != nil {
		return "", err
	}
	return readAndClose(file)
}

func readAndClose(input io.ReadCloser) (text string, err error) {
	defer func() {
		if closeErr := input.Close(); err == nil && closeErr != nil {
			err = closeErr
		}
	}()
	return readBounded(input)
}

func readBounded(input io.Reader) (string, error) {
	content, err := io.ReadAll(io.LimitReader(input, maxInputBytes+1))
	if err != nil {
		return "", err
	}
	if len(content) > maxInputBytes {
		return "", fmt.Errorf("input exceeds %d bytes: %w", maxInputBytes, ErrInvalidInput)
	}
	return string(content), nil
}

func decodeJSONText(text string) (string, error) {
	var input struct {
		Text string `json:"text"`
	}
	if err := json.Unmarshal([]byte(text), &input); err != nil {
		return "", fmt.Errorf("decode JSON input: %w: %w", ErrInvalidInput, err)
	}
	return input.Text, nil
}
