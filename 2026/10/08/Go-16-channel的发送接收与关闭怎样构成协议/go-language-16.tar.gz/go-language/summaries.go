package main

type HasSummary interface {
	Summary() string
}

func Summaries[T HasSummary](records []T) []string {
	lines := make([]string, len(records))
	for position, record := range records {
		lines[position] = record.Summary()
	}
	return lines
}
