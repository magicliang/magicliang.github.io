# 累计任务服务：第 16 章

本快照对应 Go 16《channel的发送接收与关闭怎样构成协议》。当前源码以本目录实际文件和 `CURRENT-SHA256SUMS` 为准；`evidence/` 下的旧输出是写作过程历史证据，不冒充本次解包复跑。

## 历史阶段说明

以下文字由早期累计快照继承，描述当时阶段；其中的能力限制和证据路径不作为本篇当前能力总览。本篇复跑步骤以 RUN.md 为准。

本目录是全系列的**唯一累计工程**。16 在第 15 章受控统计上增加一位生产者、一个容量为 1 的输入 channel 和一位消费者；生产者独自关闭输入，消费者排空后关闭输出，CLI 排空所有结果后再检查最早出现的错误并输出。15 的单任务完成信号仍由 `analyzeTaskAsyncUsing` 使用；没有并行 worker pool。`queue_test.go` 用闸门检查排空、空输入与空/满/nil/关闭通道的区别，`testdata/send-after-close.go` 是单独构建运行的 panic 反例。CLI 批次参数仍已经整体存在内存中，容量 1 不是全流程内存限制，也不是 20 章将实现的有界执行器。00–15 的快照分别冻结在对应博文素材包。

需要 Linux amd64 的 Go 1.27.1，或在自己的平台安装同一 patch 版本；不得用较早语言版本的观察冒充本章证据。仓库内源码 tag/SHA 和二进制来源见 `VERSIONS.md`。

```sh
cd examples/go-language
GOTOOLCHAIN=local go version
GOTOOLCHAIN=local go test -count=1 ./...
GOTOOLCHAIN=local go list ./...
GOTOOLCHAIN=local go list -m all
GOTOOLCHAIN=local go run . --text 'Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go' --drop-first --append again
GOTOOLCHAIN=local go run . --batch 'Go|one two' --lookup 'task[0]'
GOTOOLCHAIN=local go run . --batch 'Go|one two' --list-ids
printf '%s' '{"text":"Go 写 Go"}' | GOTOOLCHAIN=local go run . --stdin --input-json --json
GOTOOLCHAIN=local go run . --file /tmp/taskstats-input.txt --json
printf 'Go 写 Go' > /tmp/taskstats-input.txt
GOTOOLCHAIN=local go run . --file /tmp/taskstats-input.txt
GOTOOLCHAIN=local go run . --text '  '
GOTOOLCHAIN=local go run ./testdata/shadow.go
GOTOOLCHAIN=local go run ./testdata/assign.go
GOTOOLCHAIN=local go run ./testdata/loop-declare.go
GOTOOLCHAIN=local go run ./testdata/loop-assign.go
GOTOOLCHAIN=local go run ./testdata/defer-order.go
GOTOOLCHAIN=local go run ./testdata/defer-loop.go
GOTOOLCHAIN=local go run ./testdata/slice-append.go
GOTOOLCHAIN=local go test -count=1 -v ./testdata/slice-alias-bug_test.go
GOTOOLCHAIN=local go run ./testdata/nil-map-write.go
GOTOOLCHAIN=local go build ./testdata/nonaddressable-receiver.go
GOTOOLCHAIN=local go build ./testdata/interface-value-error.go
GOTOOLCHAIN=local go run ./testdata/typed-nil.go
GOTOOLCHAIN=local go build -o /tmp/recover-outside-defer ./testdata/recover-outside-defer.go
/tmp/recover-outside-defer
GOTOOLCHAIN=local go build ./testdata/invalid-summarizer.go
GOTOOLCHAIN=local go build ./testdata/invalid-type-operation.go
```

纯空白文本及文件打开失败的**应用进程**预期退出 2；`go run` 外层状态不能代替应用退出码，应改用编译所得二进制检查。14 的输入超限、坏 JSON、stdout 部分写入分别返回应用退出 2；已经接受的输出字节不能由本 CLI 撤销，不能称写出具有事务原子性。文件由 `readAndClose` 关闭；调用方拥有的 stdin/stdout 不由本函数关闭。13 两份故意编译失败例子及更早反例仍隔离在 `testdata/`。最新 14 结果见 `writing-plans/go-language/evidence/14/`，00–13 的冻结快照留在对应正文素材包。
