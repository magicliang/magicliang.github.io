package main

import (
	"errors"
	"testing"

	"example.com/go-language-task/stats"
)

func TestQueueDrainsBeforeReturning(t *testing.T) {
	started := make(chan struct{})
	release := make(chan struct{})
	returned := make(chan []taskOutcome)
	go func() {
		returned <- processTasksUsing([]string{"Go", "one two", ""}, 3, func(text string) stats.Counts {
			if text == "Go" {
				close(started)
				<-release
			}
			return stats.Analyze(text)
		})
	}()
	<-started
	select {
	case <-returned:
		t.Fatal("returned while first item was blocked")
	default:
		t.Log("producer started; first worker blocked; no results published")
	}
	close(release)
	results := <-returned
	if len(results) != 3 || results[0].position != 0 || results[1].position != 1 || results[2].position != 2 || results[0].counts.Words != 1 || results[1].counts.Words != 2 || !errors.Is(results[2].err, ErrInvalidInput) {
		t.Fatalf("drained results: %+v", results)
	}
	t.Logf("drained: %d results; first=%d second=%d last invalid=%t", len(results), results[0].counts.Words, results[1].counts.Words, errors.Is(results[2].err, ErrInvalidInput))
}

func TestQueueEmptyInputTerminates(t *testing.T) {
	results := processTasks(nil, 3)
	if len(results) != 0 {
		t.Fatalf("empty queue produced: %+v", results)
	}
	t.Log("empty producer closed input; worker closed output; drained 0")
}

func TestChannelEmptyFullNilAndClosed(t *testing.T) {
	queue := make(chan int, 1)
	select {
	case <-queue:
		t.Fatal("empty queue received a value")
	default:
		t.Log("empty: receive is not ready")
	}
	queue <- 7
	select {
	case queue <- 8:
		t.Fatal("full queue accepted another value")
	default:
		t.Log("full: send is not ready")
	}
	var disabled chan int
	select {
	case disabled <- 1:
		t.Fatal("nil channel accepted send")
	case <-disabled:
		t.Fatal("nil channel accepted receive")
	default:
		t.Log("nil: neither send nor receive is ready")
	}
	close(queue)
	value, ok := <-queue
	if value != 7 || !ok {
		t.Fatalf("buffered value lost: value=%d ok=%t", value, ok)
	}
	value, ok = <-queue
	if value != 0 || ok {
		t.Fatalf("closed queue not drained: value=%d ok=%t", value, ok)
	}
	t.Logf("closed: first value=%d ok=true; drained value=%d ok=%t", 7, value, ok)
}
