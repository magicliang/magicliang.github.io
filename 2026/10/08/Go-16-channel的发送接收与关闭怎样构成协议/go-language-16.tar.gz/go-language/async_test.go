package main

import (
	"bytes"
	"errors"
	"strings"
	"testing"

	"example.com/go-language-task/stats"
)

func TestAsyncWaitsForWorkBeforePublishingResult(t *testing.T) {
	started := make(chan struct{})
	release := make(chan struct{})
	returned := make(chan struct{})
	var stdout, stderr bytes.Buffer
	var code int
	go func() {
		counts, err := analyzeTaskAsyncUsing("Go 写 Go", 3, func(text string) stats.Counts {
			close(started)
			<-release
			return stats.Analyze(text)
		})
		if err != nil {
			stderr.WriteString(err.Error())
		} else {
			stdout.WriteString(TaskResult{Counts: counts}.Summary())
		}
		code = 0
		close(returned)
	}()
	<-started
	select {
	case <-returned:
		t.Fatal("result published before worker was released")
	default:
		t.Log("started: worker blocked; caller has not returned")
	}
	close(release)
	<-returned
	if code != 0 || stdout.String() != "words=3 bytes=9 runes=7" || stderr.Len() != 0 {
		t.Fatalf("code=%d stdout=%q stderr=%q", code, stdout.String(), stderr.String())
	}
	t.Logf("released: code=%d stdout=%q stderr=%q", code, stdout.String(), stderr.String())
}

func TestAsyncPreservesValidationErrors(t *testing.T) {
	counts, err := analyzeTaskAsync("one two", 1)
	if counts.Words != 2 || !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("counts=%+v err=%v", counts, err)
	}
	var stdout, stderr bytes.Buffer
	if code := run([]string{"--batch", "Go|"}, &stdout, &stderr); code != 2 || stdout.Len() != 0 || !strings.Contains(stderr.String(), "text must not be empty") {
		t.Fatalf("stdout=%q stderr=%q", stdout.String(), stderr.String())
	}
	t.Logf("validation: counts=%+v err=%v; CLI stderr=%q", counts, err, stderr.String())
}
