package main

import (
	"errors"
	"reflect"
	"testing"

	"example.com/go-language-task/stats"
)

type lookupStub struct {
	record TaskRecord
	found  bool
}

func (stub lookupStub) Lookup(string) (TaskRecord, bool) {
	return stub.record, stub.found
}

var _ TaskLookup = lookupStub{}
var _ TaskLookup = (*BatchTasks)(nil)

func TestTaskLookup(t *testing.T) {
	record := newTaskRecord("task[0]")
	record.MarkSucceeded(stats.Counts{Words: 1, Bytes: 2, Runes: 2})
	tasks := newBatchTasks([]TaskRecord{record})
	if got, err := describeTask(tasks, "task[0]"); err != nil || got != "task[0] words=1 bytes=2 runes=2" {
		t.Fatalf("real lookup = %q, err = %v", got, err)
	}
	if _, found := tasks.Lookup("task[missing]"); found {
		t.Fatal("missing ID was found")
	}
	if got := tasks.IDs(); !reflect.DeepEqual(got, []string{"task[0]"}) {
		t.Fatalf("IDs = %v", got)
	}
	if got, err := describeTask(lookupStub{record: record, found: true}, "task[0]"); err != nil || got != "task[0] words=1 bytes=2 runes=2" {
		t.Fatalf("stub lookup = %q, err = %v", got, err)
	}
	if got, err := describeTask(lookupStub{}, "task[missing]"); err == nil || got != "" {
		t.Fatalf("stub missing lookup = %q, err = %v", got, err)
	}
}

func TestLookupErrorInterface(t *testing.T) {
	record := newTaskRecord("task[0]")
	tasks := newBatchTasks([]TaskRecord{record})
	_, err := lookupRecord(tasks, "task[0]")
	if err != nil {
		t.Fatalf("successful lookup error = %v", err)
	}
	if failure, ok := err.(*missingTaskError); ok || failure != nil {
		t.Fatalf("successful lookup has unexpected error type: %T", err)
	}
	_, err = lookupRecord(tasks, "task[missing]")
	var failure *missingTaskError
	if !errors.Is(err, ErrTaskNotFound) || !errors.As(err, &failure) || failure == nil || failure.id != "task[missing]" {
		t.Fatalf("missing task error = %T %v", err, err)
	}
	if _, direct := err.(*missingTaskError); direct {
		t.Fatalf("wrapped error exposed as direct assertion: %T", err)
	}
	var nilPointer *missingTaskError
	var broken error = nilPointer
	brokenFailure, ok := broken.(*missingTaskError)
	if broken == nil || !ok || brokenFailure != nil {
		t.Fatalf("typed nil shape: errorIsNil=%t typeOK=%t pointerIsNil=%t", broken == nil, ok, brokenFailure == nil)
	}
}
