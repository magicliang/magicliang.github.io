package main

import (
	"bytes"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestErrorKinds(t *testing.T) {
	if err := validateConfig(Config{}); !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("invalid config error = %v", err)
	}
	if _, err := analyzeTask(" ", 3); !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("empty text error = %v", err)
	}
	if counts, err := analyzeTask("one two three four", 3); counts.Words != 4 || !errors.Is(err, ErrInvalidInput) {
		t.Fatalf("over-limit result = %+v, %v", counts, err)
	}
	if _, err := analyzeTask("Go", 3); err != nil {
		t.Fatalf("valid input error = %v", err)
	}
	path := filepath.Join(t.TempDir(), "missing.txt")
	_, err := readTaskFile(path)
	var pathError *os.PathError
	if !errors.Is(err, ErrExecutionFailed) || !errors.As(err, &pathError) || !errors.Is(err, os.ErrNotExist) {
		t.Fatalf("file error chain = %T %v", err, err)
	}
	var stdout, stderr bytes.Buffer
	if code := run([]string{"--file", path}, &stdout, &stderr); code != 2 || stdout.Len() != 0 || stderr.String() != "read file: task execution failed\n" || strings.Contains(stderr.String(), path) {
		t.Fatalf("public file error = %q %q code=%d", stdout.String(), stderr.String(), code)
	}
}
