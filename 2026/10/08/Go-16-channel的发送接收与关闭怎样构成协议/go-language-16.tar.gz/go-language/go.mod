module example.com/go-language-task

go 1.27.1
