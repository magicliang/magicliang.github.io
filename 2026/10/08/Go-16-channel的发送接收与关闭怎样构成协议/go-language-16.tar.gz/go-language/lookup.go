package main

import "fmt"

type TaskLookup interface {
	Lookup(id string) (TaskRecord, bool)
}

type BatchTasks struct {
	records   []TaskRecord
	positions map[string]int
}

func newBatchTasks(records []TaskRecord) *BatchTasks {
	return &BatchTasks{records: records, positions: indexTasks(records)}
}

func (tasks *BatchTasks) Lookup(id string) (TaskRecord, bool) {
	position, found := tasks.positions[id]
	if !found {
		return TaskRecord{}, false
	}
	return tasks.records[position], true
}

func (tasks *BatchTasks) IDs() []string {
	return orderedTaskIDs(tasks.positions)
}

func describeTask(source TaskLookup, id string) (string, error) {
	record, err := lookupRecord(source, id)
	if err != nil {
		return "", err
	}
	return fmt.Sprintf("%s %s", record.ID, record.Summary()), nil
}
