package main

import (
	"reflect"
	"testing"

	"example.com/go-language-task/stats"
)

func TestSummaries(t *testing.T) {
	first := newTaskRecord("task[0]")
	first.MarkSucceeded(stats.Counts{Words: 1, Bytes: 2, Runes: 2})
	records := []TaskRecord{first}
	want := []string{"words=1 bytes=2 runes=2"}
	if got := Summaries(records); !reflect.DeepEqual(got, want) {
		t.Fatalf("record summaries = %v", got)
	}
	resultValues := []TaskResult{first.TaskResult}
	if got := Summaries(resultValues); !reflect.DeepEqual(got, want) {
		t.Fatalf("result summaries = %v", got)
	}
	interfaceValues := []HasSummary{first}
	if got := Summaries(interfaceValues); !reflect.DeepEqual(got, want) {
		t.Fatalf("interface summaries = %v", got)
	}
	if got := Summaries([]TaskRecord{}); len(got) != 0 {
		t.Fatalf("empty summaries = %v", got)
	}
}
