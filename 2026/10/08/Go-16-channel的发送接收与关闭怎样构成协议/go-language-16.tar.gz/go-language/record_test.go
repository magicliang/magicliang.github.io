package main

import (
	"testing"

	"example.com/go-language-task/stats"
)

var _ interface{ Summary() string } = TaskRecord{}
var _ interface{ MarkSucceeded(stats.Counts) } = (*TaskRecord)(nil)

func TestTaskRecordCopyAndPointerReceiver(t *testing.T) {
	record := newTaskRecord("task[0]")
	snapshot := record
	record.MarkSucceeded(stats.Counts{Words: 1, Bytes: 2, Runes: 2})
	if snapshot.Status != StatusQueued || snapshot.Words != 0 {
		t.Fatalf("copied snapshot changed: %+v", snapshot)
	}
	if record.Status != StatusSucceeded || record.Words != 1 {
		t.Fatalf("original record was not updated: %+v", record)
	}
	if got := record.Summary(); got != "words=1 bytes=2 runes=2" {
		t.Fatalf("promoted Summary() = %q", got)
	}
	copyOfSucceeded := record
	copyOfSucceeded.MarkSucceeded(stats.Counts{Words: 2})
	if record.Words != 1 || copyOfSucceeded.Words != 2 {
		t.Fatalf("two record values share state: %+v %+v", record, copyOfSucceeded)
	}
}
