package main

import (
	"sort"
)

func indexTasks(records []TaskRecord) map[string]int {
	positions := make(map[string]int, len(records))
	for position, record := range records {
		positions[record.ID] = position
	}
	return positions
}

func orderedTaskIDs(positions map[string]int) []string {
	ids := make([]string, 0, len(positions))
	for id := range positions {
		ids = append(ids, id)
	}
	sort.Slice(ids, func(left, right int) bool {
		return positions[ids[left]] < positions[ids[right]]
	})
	return ids
}
