package main

import (
	"errors"
	"io"
	"strings"
	"testing"
)

type trackedReader struct {
	io.Reader
	closeCalls int
	closeErr   error
}

func (reader *trackedReader) Close() error {
	reader.closeCalls++
	return reader.closeErr
}

type failedReader struct {
	err error
}

func (reader failedReader) Read([]byte) (int, error) {
	return 0, reader.err
}

func TestReadAndClose(t *testing.T) {
	closeError := errors.New("close failure")
	readError := errors.New("read failure")
	for _, testCase := range []struct {
		name       string
		reader     io.Reader
		closeError error
		wantText   string
		wantError  error
	}{
		{name: "success", reader: strings.NewReader("Go 写 Go"), wantText: "Go 写 Go"},
		{name: "close error", reader: strings.NewReader("Go"), closeError: closeError, wantText: "Go", wantError: closeError},
		{name: "read and close error", reader: failedReader{err: readError}, closeError: closeError, wantError: readError},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			input := &trackedReader{Reader: testCase.reader, closeErr: testCase.closeError}
			text, err := readAndClose(input)
			if text != testCase.wantText || err != testCase.wantError || input.closeCalls != 1 {
				t.Fatalf("text=%q err=%v closeCalls=%d; want text=%q err=%v closeCalls=1", text, err, input.closeCalls, testCase.wantText, testCase.wantError)
			}
		})
	}
}
