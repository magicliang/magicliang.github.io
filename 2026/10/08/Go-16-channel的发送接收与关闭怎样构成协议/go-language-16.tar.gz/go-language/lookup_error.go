package main

import "fmt"

type missingTaskError struct {
	id string
}

func (failure *missingTaskError) Error() string {
	return "task not found: " + failure.id
}

func (failure *missingTaskError) Unwrap() error {
	return ErrTaskNotFound
}

func lookupRecord(source TaskLookup, id string) (TaskRecord, error) {
	record, found := source.Lookup(id)
	if !found {
		return TaskRecord{}, fmt.Errorf("lookup %q: %w", id, &missingTaskError{id: id})
	}
	return record, nil
}
