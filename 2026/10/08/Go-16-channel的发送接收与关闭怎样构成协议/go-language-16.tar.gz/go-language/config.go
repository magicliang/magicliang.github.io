package main

import "fmt"

type Config struct {
	MaxWords int
}

func validateConfig(config Config) error {
	if config.MaxWords <= 0 {
		return fmt.Errorf("max-words must be positive: %w", ErrInvalidInput)
	}
	return nil
}
