package main

import "example.com/go-language-task/stats"

func analyzeTaskAsync(text string, maxWords int) (stats.Counts, error) {
	return analyzeTaskAsyncUsing(text, maxWords, stats.Analyze)
}

func analyzeTaskAsyncUsing(text string, maxWords int, analyze func(string) stats.Counts) (stats.Counts, error) {
	done := make(chan struct{})
	var counts stats.Counts
	var err error
	go func() {
		defer close(done)
		counts, err = analyzeTaskUsing(text, maxWords, analyze)
	}()
	<-done
	return counts, err
}
