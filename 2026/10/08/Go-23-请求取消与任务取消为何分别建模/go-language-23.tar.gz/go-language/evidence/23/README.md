# 23 原始实验索引

`environment.txt` 记录真实 Go 1.27.1、平台、GCC/CGO 和 module；每组 `.command/.stdout/.stderr/.exit` 保存命令、原始双流和退出码。`doc-*` 为本版入站 Request.Context、http.Server.Shutdown、context.CancelFunc 与 ServeMux 一手 API。`focused`/`repeat` 用真实 loopback HTTP 与受控闸门验证主动取消、排队取消、客户端请求取消、Server.Shutdown 与业务 Close 的差别；`repeat` 重跑 30 次。`tests` 完整两包，`race` 与 `race-full` 本机实跑，无报告只限覆盖路径。CLI `--timeout 0s` 预期退出 2，不是编译失败。独立包、页面和 HTTP 静态资源的证据完成后补充；不能用页面 200 代替 Go/任务 HTTP 实验。
