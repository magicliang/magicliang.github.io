# 运行与复核

运行环境：JDK 21；Gradle Wrapper 8.14；Kotlin Gradle Plugin、编译器和 stdlib 2.2.21。精确 SHA、文档出处和已执行结果见 `../../writing-plans/kotlin/VERSIONS.md` 与 `../../writing-plans/kotlin/verification/00/`。Gradle Wrapper 固定分发包 SHA-256，即使从镜像下载也必须先通过校验。

```bash
cd examples/kotlin-language
bash verification/00.sh
bash verification/01.sh
bash verification/02.sh
bash verification/03.sh
bash verification/04.sh
bash verification/05.sh
bash verification/06.sh
bash verification/07.sh
bash verification/08.sh
bash verification/09.sh
```

脚本保存环境、clean test、合法/非法 CLI、字节码、依赖解析、测试报告的命令、原始输出、退出码和断言。`invalid` 的退出码预期非零。脚本依赖本仓库相对目录结构；若只拿到打包工程，请进入解包后的 `kotlin-language` 并运行 `./gradlew --no-daemon clean test`，随后分别运行 `./gradlew run --args='submit nightly-index'` 与 `./gradlew run --args=submit`。这是本机 JDK/Gradle 的实际运行，不包括 HTTP、数据库、协程或重启恢复。

01 的 `verification/01-val-reassignment.kt` 是特意放在默认源码集之外的失败样本；不要复制进 `src/main/kotlin` 的正常构建。若只有独立压缩包，版本账本位于解包根目录的 `VERSIONS.md`，实验原始输出位于 `verification/00/` 与 `verification/01/`。

02 的 `verification/02-unstable-smartcast.kt` 同样是隔离的编译失败样本，覆盖自定义 getter 与可变属性。打包快照的主工程可用 `./gradlew --offline --no-daemon clean test` 复核已缓存依赖的环境；不应把 `batch` 的本地计数或当前命令行输出理解为后台任务已入队。

03 的 `verification/03-java-named-args.kt` 演示 Java 方法无法从 Kotlin 使用命名实参，同样不能复制进正常工程。`TaskProposalTest` 验证 `taskProposal` 缺省与显式参数、`Unit` 动作、`Nothing` 异常和可空结果；`taskProposal` 目前没有接入 CLI，测试通过也不表示已经创建或运行任务。只有独立包时从根目录用 `./gradlew --offline --no-daemon clean test` 验证累计源码；相应原始证据在包内 `verification/03/`。

04 的 `TaskTextTest` 对中文、增补字符和组合字符比较三种计数，并断言正则整串匹配与子串搜索的区别。`verification/04/` 保存五组 2/2 测试、Unicode CLI 正反输入的命令与退出码；源码尚未调用 `inputMetrics` 检查 CLI。独立包从 `kotlin-language/` 运行 `./gradlew --offline --no-daemon --console=plain clean test`，预期依赖已缓存在本机；无缓存则先准备依赖，不能把离线解析失败记成测试失败。

05 的 `OptionalTaskNoteTest` 区分缺键/null/空串/普通值与 `!!`、未初始化 `lateinit` 的失败路径；`verification/05-nonnull-rejection.kt` 在默认源码集外展示非空声明拒绝 null。`verification/05/` 保存六组 2/2、CLI 正反和独立编译的退出码、原始输出与断言；这些结果不说明 CLI 已解析备注。

06 的 `TaskQueryTest` 用同一列表、集合和映射的可变别名证明读接口仍可观察变化；复制结构不能复制内部可变对象。`verification/06/` 保存七组 2/2、旧 CLI 正反的原始证据，尚未验证并发查询或底层存储。

07 的 `TaskLabelRulesTest` 断言同步 lambda 调用时读取的可变捕获值、急切规则调用次数、局部/非局部返回；隔离 `verification/07-nonlocal-return.kt` 验证非 inline 回调不能直接非局部 `return`。`verification/07/` 保存八组 2/2 与编译拒绝、旧 CLI 正反原始记录；规则尚未接入 CLI。

08 的 `TaskLabelPipelineTest` 记录急切 List 与 `List.asSequence()` 的 map/filter/take 轨迹和重复终端收集；`verification/08/` 保存九组 2/2、旧 CLI 正反的原始证据。没有以一次运行时间得出性能结论。

09 的 `TaskTest` 检查 Task 构造顺序、属性访问器与 lazy 的首次求值、未初始化 `lateinit` 访问异常及开放成员在基类构造期的派生字段风险；`verification/09/` 保存十组 2/2 和旧 CLI 正反原始证据。并非 CLI 中已创建任务。
