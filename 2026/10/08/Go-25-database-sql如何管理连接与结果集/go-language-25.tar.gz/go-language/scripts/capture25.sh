#!/usr/bin/env bash
set -u
root=$(cd "$(dirname "$0")/../../.." && pwd)
evidence="$root/writing-plans/go-language/evidence/25"
mkdir -p "$evidence"
export PATH="/tmp/go-language-toolchain-1.27.1/go/bin:$PATH"
export GOTOOLCHAIN=local GOWORK=off GOMAXPROCS=2 CGO_ENABLED=1 GOPROXY=https://goproxy.cn
if [[ -z ${GO_LANGUAGE_SQL_DSN:-} ]]; then
  echo 'set GO_LANGUAGE_SQL_DSN to an isolated PostgreSQL 16 database' >&2
  exit 2
fi
cd "$root/examples/go-language" || exit 1
date -Ins > "$evidence/environment.txt"
uname -smr >> "$evidence/environment.txt"
go version >> "$evidence/environment.txt"
go env GOOS GOARCH GOTOOLCHAIN GOWORK GOMAXPROCS CGO_ENABLED CC GOPROXY GOMOD >> "$evidence/environment.txt"
/usr/lib/postgresql/16/bin/postgres --version >> "$evidence/environment.txt"
gcc --version | head -1 >> "$evidence/environment.txt"

capture() {
  local name=$1 command=$2 exit_code
  printf '%s\n' "$command" > "$evidence/$name.command"
  bash -c "$command" > "$evidence/$name.stdout" 2> "$evidence/$name.stderr"
  exit_code=$?
  printf '%s\n' "$exit_code" > "$evidence/$name.exit"
  printf '%s exit=%s\n' "$name" "$exit_code"
}

capture doc-db 'go doc database/sql.DB'
capture doc-open 'go doc database/sql.Open'
capture doc-query 'go doc database/sql.DB.QueryContext'
capture doc-rows 'go doc database/sql.Rows.Close'
capture doc-scan 'go doc database/sql.Rows.Scan'
capture tidy 'go mod tidy -diff'
capture verify 'go mod verify'
capture focused "go test -count=15 -run 'TestSQL' -v ."
capture tests 'go test -count=1 -v ./...'
capture race 'go test -race -count=1 ./...'
capture build 'go build -o /tmp/go-language-25-taskstats .'
capture cli-batch "/tmp/go-language-25-taskstats --batch 'Go|one two|Go' --workers 2 --queue-capacity 1"
capture cli-timeout '/tmp/go-language-25-taskstats --text Go --timeout 0s --workers 2'
capture module 'go list -m all'
