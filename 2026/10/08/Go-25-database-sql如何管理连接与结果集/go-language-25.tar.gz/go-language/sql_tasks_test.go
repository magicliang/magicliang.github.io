package main

import (
	"context"
	"database/sql"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
	"time"
)

func openSQLTestDatabase(t *testing.T) *sql.DB {
	t.Helper()
	dsn := os.Getenv("GO_LANGUAGE_SQL_DSN")
	if dsn == "" {
		t.Skip("set GO_LANGUAGE_SQL_DSN to run against a real isolated PostgreSQL database")
	}
	db, err := sql.Open("postgres", dsn)
	if err != nil {
		t.Fatal(err)
	}
	db.SetMaxOpenConns(1)
	t.Cleanup(func() { db.Close() })
	return db
}

func TestSQLAcceptedTaskPersistedBeforeWorkerClaim(t *testing.T) {
	db := openSQLTestDatabase(t)
	ctx := context.Background()
	service, err := newTaskHTTPServiceWithSQL(ctx, 1, 2, 3, db)
	if err != nil {
		t.Fatal(err)
	}
	defer service.Close()
	if _, err := db.ExecContext(ctx, "TRUNCATE go_tasks"); err != nil {
		t.Fatal(err)
	}
	server := httptest.NewServer(service.Handler())
	defer server.Close()
	status, _, body := postTask(t, server.Client(), server.URL, `{"text":"Go"}`, "application/json")
	if status != http.StatusAccepted || !strings.Contains(body, `"task[0]"`) {
		t.Fatalf("submit status=%d body=%q", status, body)
	}
	record, text, err := service.sqlStore.Lookup(ctx, "task[0]")
	if err != nil || record.ID != "task[0]" || text != "Go" {
		t.Fatalf("SQL accepted row=%+v text=%q error=%v", record, text, err)
	}
	service.Close()
	if status, result := getTask(t, server.Client(), server.URL, "task[0]"); status != http.StatusOK || result.Status != StatusSucceeded {
		t.Fatalf("HTTP result status=%d record=%+v", status, result)
	}
	queuedRecord, _, err := service.sqlStore.Lookup(ctx, "task[0]")
	if err != nil || queuedRecord.Status != StatusQueued {
		t.Fatalf("SQL status before terminal mirroring=%+v error=%v", queuedRecord, err)
	}
	if _, _, err := service.sqlStore.Lookup(ctx, "missing"); !errors.Is(err, ErrSQLTaskNotFound) {
		t.Fatalf("SQL missing lookup error=%v", err)
	}
	t.Logf("POST=202; SQL id=%s text=%s initial-status=%s; HTTP eventual=SUCCEEDED; SQL terminal mirroring NOT_RUN", record.ID, text, record.Status)
}

func TestSQLConnectionFailureAndScanError(t *testing.T) {
	db := openSQLTestDatabase(t)
	ctx := context.Background()
	broken, err := sql.Open("postgres", "host=127.0.0.1 port=1 user=admin dbname=postgres connect_timeout=1 sslmode=disable")
	if err != nil {
		t.Fatal(err)
	}
	defer broken.Close()
	if _, err := newSQLTaskRepository(ctx, broken); err == nil {
		t.Fatal("sql.Open is not proof that a connection succeeds")
	}
	repository, err := newSQLTaskRepository(ctx, db)
	if err != nil {
		t.Fatal(err)
	}
	if err := repository.InsertQueued(ctx, "invalid-scan", "Go"); err != nil {
		t.Fatal(err)
	}
	defer repository.DeleteQueued(ctx, "invalid-scan")
	rows, err := db.QueryContext(ctx, "SELECT NULL FROM go_tasks WHERE id=$1", "invalid-scan")
	if err != nil {
		t.Fatal(err)
	}
	if !rows.Next() {
		t.Fatal("expected actual SQL row")
	}
	var count int
	if err := rows.Scan(&count); err == nil {
		t.Fatal("scanning SQL NULL into int must fail")
	}
	if err := rows.Close(); err != nil {
		t.Fatal(err)
	}
	if err := db.PingContext(ctx); err != nil {
		t.Fatalf("pool after scan error and Rows.Close: %v", err)
	}
	t.Log("unreachable PostgreSQL PingContext failed; real NULL->int scan failed; connection returned after Rows.Close")
}

func TestSQLHTTPDoesNotAcceptWithoutDatabase(t *testing.T) {
	db := openSQLTestDatabase(t)
	service, err := newTaskHTTPServiceWithSQL(context.Background(), 1, 1, 3, db)
	if err != nil {
		t.Fatal(err)
	}
	defer service.Close()
	server := httptest.NewServer(service.Handler())
	defer server.Close()
	if err := db.Close(); err != nil {
		t.Fatal(err)
	}
	status, _, _ := postTask(t, server.Client(), server.URL, `{"text":"Go"}`, "application/json")
	if status != http.StatusServiceUnavailable {
		t.Fatalf("database unavailable: submit status=%d", status)
	}
	if status, _ := getTask(t, server.Client(), server.URL, "task[0]"); status != http.StatusNotFound {
		t.Fatalf("unaccepted task should not exist in memory: status=%d", status)
	}
	t.Log("closed DB: POST=503 and GET=404; no accepted in-memory task")
}

func TestSQLRowsCloseReleasesPoolSlot(t *testing.T) {
	db := openSQLTestDatabase(t)
	ctx := context.Background()
	if _, err := newSQLTaskRepository(ctx, db); err != nil {
		t.Fatal(err)
	}
	rows, err := db.QueryContext(ctx, "SELECT generate_series(1, 1000)")
	if err != nil {
		t.Fatal(err)
	}
	defer rows.Close()
	if !rows.Next() {
		t.Fatal("expected first database row")
	}
	waitContext, cancel := context.WithTimeout(ctx, 50*time.Millisecond)
	defer cancel()
	if _, err := db.ExecContext(waitContext, "SELECT 1"); !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("held Rows should occupy only pool slot: %v", err)
	}
	if err := rows.Close(); err != nil {
		t.Fatal(err)
	}
	if _, err := db.ExecContext(ctx, "SELECT 1"); err != nil {
		t.Fatalf("released pool slot: %v", err)
	}
	t.Log("single pool slot blocked while result set stayed open; Rows.Close released it for the next query")
}
