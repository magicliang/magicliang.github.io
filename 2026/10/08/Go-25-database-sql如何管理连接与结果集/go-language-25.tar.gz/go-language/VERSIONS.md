# 00 冻结版本

| 项目 | 本次实测 / 冻结 |
|---|---|
| OS/架构 | Ubuntu 24.04.4 LTS，Linux x86_64 |
| 工具链 | `go version go1.27.1 linux/amd64` |
| 官方二进制 | `https://dl.google.com/go/go1.27.1.linux-amd64.tar.gz`，SHA-256 `63d339f0da5ab53635a56f2490a7984dfe12dfcff22ad749f63edaf590168445` |
| 源码 | tag `go1.27.1`，Git SHA `862c888e612ac346c7c4d99c9392bdfd265f33b0`，由 Gitee 的 Go 镜像 `git ls-remote` 查询；官方 Gitiles 不可达，未完成对官方 Git 远端的交叉验证 |
| module | `example.com/go-language-task`，`go 1.27.1`；未写 `toolchain` 指令（同版指令被 `go mod tidy` 移除）；仅标准库，无 `go.sum` |
| 运行方式 | `GOTOOLCHAIN=local` 禁止静默切换下载的工具链 |

环境变量、资源限制和模块图的原始命令输出见 `writing-plans/go-language/evidence/00/`；压缩副本见本章文章素材。非 Go 依赖在首次引入时另行冻结。

01 延用 Go 1.27.1、`go.mod` 与标准库依赖，未添加第三方模块。`GOWORK=off` 的干净目录验证记录在 `writing-plans/go-language/evidence/01/`；`go list ./...` 显示 `example.com/go-language-task` 和 `example.com/go-language-task/stats` 两个 package，`go list -m all` 仍只显示一个 module。01 的独立压缩快照见同名正文素材目录；00 的冻结快照不随这里的代码变动。

02 沿用相同 Go 1.27.1、`go.mod` 和标准库依赖，没有新增外部版本。`Config{}` 的 `MaxWords` 语言零值为 0，而 CLI 用 `flag.Int` 显式设默认 3：二者不是一回事。`--max-words` 非正数错误在统计前返回，超出正上限要在统计后才判断；实测输出与退出码在 `writing-plans/go-language/evidence/02/`。

03 继续沿用同一工具链和标准库；新计数使用本版 `src/unicode/utf8/utf8.go:447` 的 `RuneCountInString`（同一源码 tag/SHA）。字段数来自 `strings.Fields`，字节数来自 `len(text)`，码点数来自 `utf8.RuneCountInString(text)`；没有引入图素簇分段库。03 的中文、空串、结合符输入与隔离副本错误计数结果见 `writing-plans/go-language/evidence/03/`。

04 沿用 Go 1.27.1、`go.mod` 的 `go 1.27.1` 和标准库，没有额外依赖。在该语言版本下 `for _, value := range ...` 每轮有独立声明变量，而预先声明再用 `for _, value = range ...` 是给同一变量赋值；两种短程序的实际输出在 `writing-plans/go-language/evidence/04/`，并对照本版 `doc/go_spec.html` 的 range clause。不使用旧版本工具链推测跨版本行为。

05 沿用 Go 1.27.1 与标准库，没有额外依赖。`defer` 和 `return` 规则对照本版 `doc/go_spec.html` 的 Defer statements/Return statements；文件输入使用本版 `os.Open`、`io.ReadAll`、`io.ReadCloser.Close`，退出码与原始输出见 `writing-plans/go-language/evidence/05/`。`/proc/self/fd` 计数只在 Linux amd64 的这次进程中观察；不能当作其他系统的文件描述符数量。

06 继续使用同一 Go 1.27.1 工具链和标准库；无新增外部版本。slice 与数组语义按本版 `doc/go_spec.html` 中 Array types、Slice types、Appending and copying slices、Representation of values 核对；`testdata/slice-append.go`、`slice-alias-bug_test.go` 和根包正反测试原始结果见 `writing-plans/go-language/evidence/06/`。

07 继续使用 Go 1.27.1 和标准库，没有新模块。map 类型、索引表达式、range 遍历顺序按本版 `doc/go_spec.html` 的 Map types、Index expressions、For statements with range clause 核对，排序 API 用本版 `go doc sort.Slice` 核对；实际命令、原始双流与退出码见 `writing-plans/go-language/evidence/07/`。

08 继续沿用 Go 1.27.1 和标准库，没有新模块。结构体嵌入、方法提升、值与指针接收者按本版 `doc/go_spec.html` 中 Struct types、Method sets、Method declarations 与 Calls 核对；本次实际编译失败、两包测试、CLI 回归与工具环境见 `writing-plans/go-language/evidence/08/`。

09 沿用 Go 1.27.1、标准库与单一 module；没有引入外部依赖。本版 `doc/go_spec.html` 的 Interface types、Implementing an interface、Method sets 规定值/指针的方法集关系；根包及独立编译失败反例、原始环境和命令在 `writing-plans/go-language/evidence/09/`。

10 沿用 Go 1.27.1 与标准库，仍无外部依赖。本版 `doc/go_spec.html` 中 Variables、Type assertions、Comparison operators 核对接口动态类型/动态值与 nil 比较；`writing-plans/go-language/evidence/10/` 保存隔离 typed nil 反例、真实缺失/成功查询的运行环境、命令、双流和退出码。

11 沿用 Go 1.27.1 与标准库；`fmt.Errorf` 多个 `%w`、`errors.Is`/`errors.As` 按本版 `go doc` 核对，标准库源码实现参考 tag/SHA 与实际 `src/fmt/errors.go:16`（多 `%w` 对应的 `Unwrap() []error`）；本章仅依赖公开 API 契约作调用层判断，原始输出保存在 `writing-plans/go-language/evidence/11/`。

12 延用 Go 1.27.1 与标准库。本版 `doc/go_spec.html` 的 Defer statements、Handling panics 规定 panic 展开仍执行 defer，recover 必须由同一 goroutine 的延迟函数直接调用才会得到 panic 值。`writing-plans/go-language/evidence/12/` 保留一份先前注入未实际调用的失败测试及修复后复跑结果，不把失败测试当作本章验收通过。

13 继续使用 Go 1.27.1、原 module 和标准库，没有新增依赖。本版 `doc/go_spec.html` 中 Type parameter declarations、Instantiations 规定类型参数的约束和可用操作；正例/编译失败反例的原始命令、环境、输出和退出码在 `writing-plans/go-language/evidence/13/`。没有据此推算运行成本。

14 继续使用 Go 1.27.1 及标准库，没有第三方依赖。`io.LimitReader`、`io.ReadAll`、`io.Writer` 与 `encoding/json.Unmarshal` 按本版 `go doc` 核对；JSON 输出经 `json.Marshal`，读取上限为本工程选定的 65536 字节，不是 Go 默认限制。具体运行环境、短读/部分写出测试、无效 JSON、超限及解包重跑结果在 `writing-plans/go-language/evidence/14/`。

15 延用 Go 1.27.1、原 module 与标准库，没有新增外部依赖。本版 `doc/go_spec.html` 的 Go statements 规定 `go` 调用不等待返回；`doc/go_mem.html` 的 Channel communication 规定 close 到观察关闭的 receive 的同步边。`async.go` 的完成信号仅用于单任务调用者等待、发布结果；不表示队列/取消/服务关闭，原始命令和正反例见 `writing-plans/go-language/evidence/15/`。源码镜像 SHA 沿用上表；本章只引用规范/内存模型，不基于 runtime 实现推出调度顺序。

16 延用 Go 1.27.1、原 module 与标准库，无新依赖。本版 `doc/go_spec.html` Channel types、Send statements、Receive operator、Close 与 `doc/go_mem.html` Channel communication 分别支撑空/满/nil/关闭及同步语义；工程里唯一生产者关闭输入，唯一消费者在排空后关闭输出。`writing-plans/go-language/evidence/16/` 有真实边界测试、独立 panic 二进制、CLI 回归及命令原始结果；`go run` 的非零包装码与直接可执行程序的业务退出码需分开。镜像 SHA 沿用 00，官方 Gitiles 仍未核验；本章不对运行时内部调度作源码结论。

17 沿用 Go 1.27.1、原 module 和标准库，不新增外部依赖。`go doc context.Context`/`context.WithTimeout`/`context.Canceled`/`context.DeadlineExceeded`、`go doc unicode.IsSpace` 为本版公开 API 契约，记录在 `writing-plans/go-language/evidence/17/`。取消请求通过 `ctx.Done` 传播，但 `queue.go` 等待生产者、消费者和子统计完成后才返回；CLI `--timeout` 只从输入准备后计时，文件/标准输入读取不受此截止时间控制。固定源码镜像 SHA 与上表一致，不把 context 包实现细节当规范保证，官方 Gitiles 核验仍 `NOT_RUN`。

18 沿用 Go 1.27.1、原 module 和标准库，无第三方依赖；`sync.Mutex` 和内存模型固定文档在 `writing-plans/go-language/evidence/18/`。本章新增 `CGO_ENABLED=1` + `/usr/bin/gcc` (Ubuntu 13.3.0) 执行 Go race detector：同一受控测试的无锁替身触发 `WARNING: DATA RACE`（预期退出 1），有锁真实存储及根包两包回归无报告（退出 0）。后者只说明本次执行路径未报告，不等于全路径安全；此环境与 17 及更早章节 `CGO_ENABLED=0` 的非 race 实验不同。版本源码镜像 SHA 沿用 00，官方 Gitiles 交叉核验仍 `NOT_RUN`，未推断 mutex 运行时实现。

19 沿用同一 Go 1.27.1/标准库/module，race 运行延用本机 `CGO_ENABLED=1`/gcc 13.3.0，`sync.WaitGroup`、`sync.Once`、`sync/atomic.Uint64` 文档用本版 `go doc` 核对；具体命令、环境和结果见 `writing-plans/go-language/evidence/19/`。`atomic.Uint64` 是与记录状态分离的终态累计数，不保证它与另一个 `Lookup` 快照在同一瞬间可见。无锁替身也使用 atomic 计数，其 `TaskRecord` 仍实测触发 race（预期退出 1）；有锁生产代码本轮两包 race 退出 0，不能外推未执行路径。源码镜像 SHA 沿用 00，官方交叉核验仍 `NOT_RUN`。

20 沿用 Go 1.27.1/module/标准库，无新增外部依赖；本版 `doc/go_spec.html` Channel types 与 Send statements、`doc/go_mem.html` Channel communication 和本版 `go doc context.Context`、`sync.WaitGroup` 核对约束；原始文本摘录、运行环境、两包完整测试、本轮 race、50 次闸门和 CLI 正反结果见 `writing-plans/go-language/evidence/20/`。本次 race 无报告只限执行过的路径，不证明所有路径安全。源码 tag/SHA 沿用 00 的镜像证据，官方 Gitiles 核验仍 `NOT_RUN`；不推测 runtime 调度内部。HTTP/SQL、其他平台和发布 `NOT_RUN`。

21 沿用冻结 Go 1.27.1/module/标准库，无外部依赖。`doc/go_spec.html` Send statements、`go doc context.CancelFunc`、`sync.Mutex`、`sync.WaitGroup` 对应一手契约及原始文件见 `writing-plans/go-language/evidence/21/`。同一路径的三次并发 Close/多 Submit 与闸门取消测试、100 次复跑、两包完整与 race、独立向已关闭 channel 发送的 panic 反例（预期退出 2）都有原始命令/双流/退出码。官方 Gitiles 交叉核验仍 `NOT_RUN`，不依据 runtime 私有调度实现推断关闭顺序；本轮 race 无报告只限执行到的路径。真实 HTTP/SQL、其他平台和发布 `NOT_RUN`。

22 沿用固定 Go 1.27.1、原 module 与标准库，不新增第三方库；标准库 `net/http.ServeMux`、`Request.PathValue`、`Request.Context`、`MaxBytesReader`、`httptest.NewServer` 及 `json.Decoder.DisallowUnknownFields` 均按此版 `go doc` 核对。本章 `httptest` 通过真实 loopback 连接请求同一 worker/store；完整命令、双流、退出码在 `writing-plans/go-language/evidence/22/`。本机 race 退出 0、无报告只适用于本轮覆盖路径。源码 tag/SHA 沿用 00 镜像查询，官方 Gitiles 交叉核验、SQL、其他平台和发布 `NOT_RUN`；本章 HTTP 适配层已实跑，但常驻端口与 HTTP 服务关闭协议仍 `NOT_RUN`。

23 延用固定 Go 1.27.1、原 module 与标准库，不新增第三方依赖。本版 `go doc net/http.Request.Context`、`net/http.Server.Shutdown`、`context.CancelFunc` 与 `ServeMux` 的原始命令/双流/退出码见 `writing-plans/go-language/evidence/23/`。真实 loopback 请求主动取消、客户端取消、排队/运行中差异与真正 `Server.Shutdown` 对照均有受控闸门、30 次复跑、两包回归与本机 race 证据；无 race 报告只限所跑路径。固定源码镜像 SHA 沿用 00，官方 Gitiles 交叉核验仍 `NOT_RUN`；常驻 HTTP 监听 CLI、跨连接长期资源负载、SQL、其他平台和发布仍 `NOT_RUN`。

24 继续 Go 1.27.1/标准库/原 module，没有新外部依赖；`net/http.Client.Timeout`、`Response.Body`、`Transport`、`NewRequestWithContext`、`net.Dialer.Timeout` 都按本版 `go doc` 核对。固定工具/本机测试的环境与 40 次复用、真实慢响应期限、模拟拨号 30ms、任务取消传播、20 次重复及两包 race 原始结果在 `writing-plans/go-language/evidence/24/`。实际 OS 黑洞 TCP 拨号超时、长时间堆/连接规模变化、常驻 HTTP 监听、SQL、其他平台和发布 `NOT_RUN`；本轮未报告 race 仅限执行路径。源码镜像完整 SHA 沿用 00，官方 Gitiles 交叉核验仍 `NOT_RUN`。

25 沿用 Go 1.27.1，新增 `github.com/lib/pq v1.12.3`（`go.mod`/`go.sum` 冻结）。本地隔离 PostgreSQL 16.15 的 `postgres --version` 和真实 `SELECT version()`、驱动镜像版本/下载、固定版 `database/sql` 文档、真连接/扫描/结果集测试及 Go 回归双流记录在 `writing-plans/go-language/evidence/25/`；Go 官方源码镜像 SHA 沿用 00，官方 Gitiles 核验仍 `NOT_RUN`。HTTP 可选 SQL 先写入 QUEUED 再进入内存执行器；worker 终态尚未回写数据库，SQL 不能声称是完整业务状态来源；重启恢复、其他平台和发布 `NOT_RUN`，本机 race 无报告只限实际路径。
