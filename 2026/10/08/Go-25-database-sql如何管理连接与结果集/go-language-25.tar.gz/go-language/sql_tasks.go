package main

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	_ "github.com/lib/pq"
)

var ErrSQLTaskNotFound = errors.New("SQL task not found")

type sqlTaskRepository struct {
	db *sql.DB
}

func newSQLTaskRepository(ctx context.Context, db *sql.DB) (*sqlTaskRepository, error) {
	if err := db.PingContext(ctx); err != nil {
		return nil, fmt.Errorf("ping SQL database: %w", err)
	}
	_, err := db.ExecContext(ctx, `CREATE TABLE IF NOT EXISTS go_tasks (
		id TEXT PRIMARY KEY,
		input_text TEXT NOT NULL,
		status TEXT NOT NULL CHECK (status IN ('QUEUED','RUNNING','SUCCEEDED','FAILED','CANCELED')),
		cancel_requested BOOLEAN NOT NULL DEFAULT FALSE,
		words INTEGER NOT NULL DEFAULT 0,
		bytes INTEGER NOT NULL DEFAULT 0,
		runes INTEGER NOT NULL DEFAULT 0
	)`)
	if err != nil {
		return nil, fmt.Errorf("prepare SQL task table: %w", err)
	}
	return &sqlTaskRepository{db: db}, nil
}

func (repository *sqlTaskRepository) InsertQueued(ctx context.Context, id, text string) error {
	_, err := repository.db.ExecContext(ctx, `INSERT INTO go_tasks (id, input_text, status) VALUES ($1, $2, $3)`, id, text, StatusQueued)
	if err != nil {
		return fmt.Errorf("insert queued SQL task: %w", err)
	}
	return nil
}

func (repository *sqlTaskRepository) DeleteQueued(ctx context.Context, id string) error {
	_, err := repository.db.ExecContext(ctx, `DELETE FROM go_tasks WHERE id = $1 AND status = $2`, id, StatusQueued)
	if err != nil {
		return fmt.Errorf("delete unaccepted SQL task: %w", err)
	}
	return nil
}

func (repository *sqlTaskRepository) Lookup(ctx context.Context, id string) (record TaskRecord, text string, err error) {
	rows, err := repository.db.QueryContext(ctx, `SELECT id, input_text, status, cancel_requested, words, bytes, runes FROM go_tasks WHERE id = $1`, id)
	if err != nil {
		return TaskRecord{}, "", fmt.Errorf("query SQL task: %w", err)
	}
	defer func() { err = errors.Join(err, rows.Close()) }()
	if !rows.Next() {
		if err := rows.Err(); err != nil {
			return TaskRecord{}, "", fmt.Errorf("read SQL task: %w", err)
		}
		return TaskRecord{}, "", ErrSQLTaskNotFound
	}
	if err := rows.Scan(&record.ID, &text, &record.Status, &record.CancelRequested, &record.Words, &record.Bytes, &record.Runes); err != nil {
		return TaskRecord{}, "", fmt.Errorf("scan SQL task: %w", err)
	}
	if err := rows.Err(); err != nil {
		return TaskRecord{}, "", fmt.Errorf("read SQL task: %w", err)
	}
	return record, text, nil
}

func newTaskHTTPServiceWithSQL(ctx context.Context, workers, queueCapacity, maxWords int, db *sql.DB) (*taskHTTPService, error) {
	repository, err := newSQLTaskRepository(ctx, db)
	if err != nil {
		return nil, err
	}
	service := newTaskHTTPService(ctx, workers, queueCapacity, maxWords)
	service.sqlStore = repository
	return service, nil
}
