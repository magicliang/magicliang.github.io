import hashlib
import html.parser
import pathlib
import sys
from urllib.parse import unquote, urlparse


class LinkParser(html.parser.HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        if tag == "a":
            href = dict(attrs).get("href")
            if href is not None:
                self.links.append(href)


public = pathlib.Path(sys.argv[1])
chapter = sys.argv[2] if len(sys.argv) > 2 else "00"
slug = {
    "00": "2026/10/07/Go-00-从一个任务看懂Go工程",
    "01": "2026/10/07/Go-01-package-module-与依赖如何分工",
    "02": "2026/10/07/Go-02-零值和作用域如何改变配置",
    "03": "2026/10/07/Go-03-byte-rune-和字段数怎样区分",
    "04": "2026/10/07/Go-04-循环变量为何影响批量任务",
    "05": "2026/10/07/Go-05-defer-何时关闭任务输入",
    "06": "2026/10/07/Go-06-slice-复制为何仍会改写任务输入",
    "07": "2026/10/07/Go-07-map-的零值为什么不能表示任务不存在",
    "08": "2026/10/07/Go-08-任务记录的复制与指针更新",
    "09": "2026/10/07/Go-09-接口由谁需要的方法决定",
    "10": "2026/10/07/Go-10-接口里的nil指针为何不是nil",
    "11": "2026/10/07/Go-11-错误包装后怎样保持可判断",
    "12": "2026/10/07/Go-12-panic时清理和recover的边界",
    "13": "2026/10/07/Go-13-泛型约束能替结果集合省下什么",
    "14": "2026/10/07/Go-14-有限输入和JSON输出的资源边界",
    "15": "2026/10/08/Go-15-启动goroutine后谁等待它结束",
    "16": "2026/10/08/Go-16-channel的发送接收与关闭怎样构成协议",
    "17": "2026/10/08/Go-17-取消请求发出后工作是否真的退出",
    "18": "2026/10/08/Go-18-共享任务状态怎样避免竞争与终态反转",
    "19": "2026/10/08/Go-19-WaitGroup-Once与atomic各负责什么",
    "20": "2026/10/08/Go-20-有界worker-pool怎样限制并发与排队",
}[chapter]
archive = f"go-language-{chapter}.tar.gz"
post = public / slug / "index.html"
navigation = public / "go-language/index.html"
for page in (post, navigation):
    assert page.is_file(), f"missing page: {page}"

post_links = LinkParser()
post_links.feed(post.read_text())
navigation_links = LinkParser()
navigation_links.feed(navigation.read_text())


def resolve(href, parent):
    parsed = urlparse(href)
    assert parsed.scheme in ("", "https")
    path = unquote(parsed.path)
    if not path.startswith("/"):
        path = "/" + str((pathlib.PurePosixPath(parent) / path))
    result = public / path.lstrip("/")
    return result / "index.html" if path.endswith("/") else result


for name in (archive, "SHA256SUMS", "RUN.md") if chapter == "20" else (archive, "SHA256SUMS"):
    candidates = [resolve(href, f"/{slug}") for href in post_links.links if name in href]
    assert candidates and all(candidate.is_file() for candidate in candidates), f"broken {name}: {candidates}"
    print(f"asset link OK: {name}")

assert any(resolve(href, f"/{slug}") == navigation for href in post_links.links)
assert any(resolve(href, "/go-language") == post for href in navigation_links.links)
print("navigation links OK")

digest, filename = (post.parent / "SHA256SUMS").read_text().strip().split()
assert filename == archive
assert hashlib.sha256((post.parent / filename).read_bytes()).hexdigest() == digest
expected_content = "peak=2" if chapter == "20" else "initializer calls=1" if chapter == "19" else "words=2" if chapter in ("16", "18") else "words=3"
assert expected_content in post.read_text()
if chapter == "15":
    assert "started does not mean completed" in post.read_text()
    assert any("Go-14-有限输入和JSON输出的资源边界" in unquote(href) and resolve(href, f"/{slug}").is_file() for href in post_links.links)
if chapter == "16":
    assert "send on closed channel" in post.read_text()
    assert any("Go-15-启动goroutine后谁等待它结束" in unquote(href) and resolve(href, f"/{slug}").is_file() for href in post_links.links)
if chapter == "17":
    assert "task deadline exceeded" in post.read_text()
    assert any("Go-16-channel的发送接收与关闭怎样构成协议" in unquote(href) and resolve(href, f"/{slug}").is_file() for href in post_links.links)
if chapter == "18":
    assert "WARNING: DATA RACE" in post.read_text()
    assert any("Go-17-取消请求发出后工作是否真的退出" in unquote(href) and resolve(href, f"/{slug}").is_file() for href in post_links.links)
if chapter == "19":
    assert "WARNING: DATA RACE" in post.read_text()
    assert any("Go-18-共享任务状态怎样避免竞争与终态反转" in unquote(href) and resolve(href, f"/{slug}").is_file() for href in post_links.links)
if chapter == "20":
    assert "ErrQueueFull" in post.read_text()
    assert any("Go-19-WaitGroup-Once与atomic各负责什么" in unquote(href) and resolve(href, f"/{slug}").is_file() for href in post_links.links)
print(f"rendered archive SHA-256 OK: {digest}")
print(f"rendered {chapter} content OK")
