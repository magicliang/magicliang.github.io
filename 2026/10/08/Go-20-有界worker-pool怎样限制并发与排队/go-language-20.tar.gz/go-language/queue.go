package main

import (
	"context"
	"errors"
	"fmt"
	"sync"

	"example.com/go-language-task/stats"
)

type queuedTask struct {
	position int
	text     string
}

type taskOutcome struct {
	position int
	counts   stats.Counts
	err      error
}

var ErrQueueFull = errors.New("task queue full")

func processTasks(tasks []string, maxWords int) []taskOutcome {
	results, _ := processTasksContext(context.Background(), tasks, maxWords)
	return results
}

func processTasksUsing(tasks []string, maxWords int, analyze func(string) stats.Counts) []taskOutcome {
	results, _ := processTasksContextUsing(context.Background(), tasks, maxWords, func(_ context.Context, text string, limit int) (stats.Counts, error) {
		return analyzeTaskAsyncUsing(text, limit, analyze)
	})
	return results
}

func sendTask(ctx context.Context, inputs chan<- queuedTask, task queuedTask) error {
	select {
	case <-ctx.Done():
		return ctx.Err()
	case inputs <- task:
		return nil
	}
}

func submitTask(ctx context.Context, inputs chan<- queuedTask, task queuedTask, rejectFull bool) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	if !rejectFull {
		return sendTask(ctx, inputs, task)
	}
	select {
	case inputs <- task:
		return nil
	default:
		return ErrQueueFull
	}
}

func receiveTask(ctx context.Context, inputs <-chan queuedTask) (queuedTask, bool) {
	select {
	case <-ctx.Done():
		return queuedTask{}, false
	case task, ok := <-inputs:
		return task, ok
	}
}

func processTasksContext(ctx context.Context, tasks []string, maxWords int) ([]taskOutcome, error) {
	return processTasksContextUsingStore(ctx, tasks, maxWords, analyzeTaskAsyncContext, nil)
}

func processTasksContextUsing(ctx context.Context, tasks []string, maxWords int, analyze func(context.Context, string, int) (stats.Counts, error)) ([]taskOutcome, error) {
	return processTasksContextUsingStore(ctx, tasks, maxWords, analyze, nil)
}

func processTasksContextUsingStore(ctx context.Context, tasks []string, maxWords int, analyze func(context.Context, string, int) (stats.Counts, error), store *TaskStore) ([]taskOutcome, error) {
	return processTasksContextWithLimits(ctx, tasks, maxWords, analyze, store, 1, 1, false)
}

func processTasksContextWithLimits(ctx context.Context, tasks []string, maxWords int, analyze func(context.Context, string, int) (stats.Counts, error), store *TaskStore, workerCount, queueCapacity int, rejectFull bool) ([]taskOutcome, error) {
	if workerCount < 1 || queueCapacity < 1 {
		return nil, fmt.Errorf("worker count and queue capacity must be positive")
	}
	workCtx, cancel := context.WithCancel(ctx)
	defer cancel()
	inputs := make(chan queuedTask, queueCapacity)
	outputs := make(chan taskOutcome)
	var workers sync.WaitGroup
	workers.Add(workerCount + 1)
	producerError := make(chan error, 1)
	go func() {
		defer workers.Done()
		defer close(inputs)
		for position, text := range tasks {
			if err := submitTask(workCtx, inputs, queuedTask{position: position, text: text}, rejectFull); err != nil {
				producerError <- err
				cancel()
				return
			}
		}
		producerError <- nil
	}()
	for range workerCount {
		go func() {
			defer workers.Done()
			for {
				task, ok := receiveTask(workCtx, inputs)
				if !ok || workCtx.Err() != nil {
					return
				}
				id := fmt.Sprintf("task[%d]", task.position)
				if store != nil && !store.Start(id) {
					select {
					case <-workCtx.Done():
						return
					case outputs <- taskOutcome{position: task.position, err: context.Canceled}:
					}
					continue
				}
				counts, err := analyze(workCtx, task.text, maxWords)
				if store != nil {
					if workCtx.Err() != nil {
						store.Cancel(id)
					}
					switch {
					case err == nil:
						if !store.Complete(id, counts) {
							err = context.Canceled
						}
					case workCtx.Err() == nil:
						if !store.Fail(id) {
							err = context.Canceled
						}
					}
				}
				select {
				case <-workCtx.Done():
					return
				case outputs <- taskOutcome{position: task.position, counts: counts, err: err}:
				}
			}
		}()
	}
	go func() {
		workers.Wait()
		close(outputs)
	}()
	results := make([]taskOutcome, len(tasks))
	for result := range outputs {
		results[result.position] = result
	}
	submitError := <-producerError
	if err := ctx.Err(); err != nil {
		if store != nil {
			store.CancelOpen()
		}
		return nil, err
	}
	if submitError != nil {
		if store != nil {
			store.CancelOpen()
		}
		return nil, submitError
	}
	return results, nil
}
