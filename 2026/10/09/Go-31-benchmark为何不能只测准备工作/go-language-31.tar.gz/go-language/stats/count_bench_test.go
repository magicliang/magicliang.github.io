package stats

import (
	"strings"
	"testing"
)

func TestCountWordsMatchesFields(t *testing.T) {
	for _, text := range []string{
		"", "\t \n", "Go one two", "你好 Go", "e\u0301",
		"\u00a0\u2003one\r\ntwo\v", "\xff Go", "\u200bGo", strings.Repeat("Go one two 你好 ", 64),
	} {
		if got, want := CountWords(text), len(strings.Fields(text)); got != want {
			t.Fatalf("CountWords(%q)=%d; Fields=%d", text, got, want)
		}
	}
}

func BenchmarkTaskCountWords(b *testing.B) {
	text := strings.Repeat("Go one two 你好 ", 64)
	want := len(strings.Fields(text))
	b.ReportAllocs()
	for b.Loop() {
		if got := CountWords(text); got != want {
			b.Fatalf("CountWords=%d want=%d", got, want)
		}
	}
}

func FuzzCountWordsMatchesFields(f *testing.F) {
	for _, text := range []string{"", "Go one two", "你好 Go", "\xff Go", "\u00a0\u2003one\r\ntwo\v", "\u200bGo"} {
		f.Add(text)
	}
	f.Fuzz(func(t *testing.T, text string) {
		if len(text) > 4096 {
			return
		}
		if got, want := CountWords(text), len(strings.Fields(text)); got != want {
			t.Fatalf("CountWords(%q)=%d; Fields=%d", text, got, want)
		}
	})
}
