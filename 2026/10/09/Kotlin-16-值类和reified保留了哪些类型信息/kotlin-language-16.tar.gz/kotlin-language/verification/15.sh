#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/15"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && ./gradlew --version' || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test || exit 1
for suite in MainTest TaskSettingsTest CommandParserTest TaskProposalTest TaskTextTest OptionalTaskNoteTest TaskQueryTest TaskLabelRulesTest TaskLabelPipelineTest TaskTest TaskRecordTest TaskStoreTest TaskStateTest SubmissionDecisionTest TaskFormattingTest TaskStatePortsTest; do
    run "$suite" cat "build/test-results/test/TEST-example.tasks.$suite.xml" || exit 1
done
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit
invalid_result=$?

scratch="$(mktemp -d /tmp/kotlin-15-rejected-XXXXXX)"
mkdir -p "$scratch/gradle/wrapper" "$scratch/src/main/kotlin"
cp build.gradle.kts settings.gradle.kts gradlew "$scratch/"
cp gradle/wrapper/* "$scratch/gradle/wrapper/"
cp src/main/kotlin/example/tasks/TaskState.kt src/main/kotlin/example/tasks/TaskStore.kt verification/15-invalid-generic-checks.kt "$scratch/src/main/kotlin/"
run rejected bash -c 'cd "$1" && ./gradlew --offline --no-daemon --console=plain compileKotlin' _ "$scratch"
rejected_result=$?

{
    printf 'build_exit=0\nvalid_exit=0\ninvalid_exit=%s\nrejected_exit=%s\n' "$invalid_result" "$rejected_result"
    for suite in MainTest TaskSettingsTest CommandParserTest TaskProposalTest TaskTextTest OptionalTaskNoteTest TaskQueryTest TaskLabelRulesTest TaskLabelPipelineTest TaskTest TaskRecordTest TaskStoreTest TaskStateTest SubmissionDecisionTest TaskFormattingTest TaskStatePortsTest; do
        grep -F 'tests="2" skipped="0" failures="0" errors="0"' "$evidence/$suite.txt" >/dev/null && echo "$suite=PASS" || echo "$suite=FAIL"
    done
    grep -F 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" >/dev/null && echo 'valid_cli=PASS' || echo 'valid_cli=FAIL'
    grep -F 'Usage: submit <task text>' "$evidence/invalid.txt" >/dev/null && echo 'invalid_cli=PASS' || echo 'invalid_cli=FAIL'
    grep -F 'Cannot check for instance of erased type' "$evidence/rejected.txt" >/dev/null && echo 'erased_type_check_rejected=PASS' || echo 'erased_type_check_rejected=FAIL'
    grep -F "Receiver type 'MutableList<out TaskState>' contains out projection" "$evidence/rejected.txt" >/dev/null && echo 'projected_write_rejected=PASS' || echo 'projected_write_rejected=FAIL'
} > "$evidence/assertions.txt"

test "$invalid_result" -ne 0 && test "$rejected_result" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
