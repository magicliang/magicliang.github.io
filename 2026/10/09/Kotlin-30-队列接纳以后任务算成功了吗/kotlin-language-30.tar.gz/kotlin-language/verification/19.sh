#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/19"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && ./gradlew --version' || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test || exit 1
for suite in MainTest TaskSettingsTest CommandParserTest TaskProposalTest TaskTextTest OptionalTaskNoteTest TaskQueryTest TaskLabelRulesTest TaskLabelPipelineTest TaskTest TaskRecordTest TaskStoreTest TaskStateTest SubmissionDecisionTest TaskFormattingTest TaskStatePortsTest TypedTaskIdTest TaskDraftTest TaskMetadataTest JavaInputBoundaryTest; do
    run "$suite" cat "build/test-results/test/TEST-example.tasks.$suite.xml" || exit 1
done
run java-bytecode javap -p -classpath build/classes/java/main example.tasks.JavaInputPort || exit 1
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit
invalid_result=$?

{
    printf 'build_exit=0\njava_bytecode_exit=0\nvalid_exit=0\ninvalid_exit=%s\n' "$invalid_result"
    for suite in MainTest TaskSettingsTest CommandParserTest TaskProposalTest TaskTextTest OptionalTaskNoteTest TaskQueryTest TaskLabelRulesTest TaskLabelPipelineTest TaskTest TaskRecordTest TaskStoreTest TaskStateTest SubmissionDecisionTest TaskFormattingTest TaskStatePortsTest TypedTaskIdTest TaskDraftTest TaskMetadataTest JavaInputBoundaryTest; do
        grep -F 'tests="2" skipped="0" failures="0" errors="0"' "$evidence/$suite.txt" >/dev/null && echo "$suite=PASS" || echo "$suite=FAIL"
    done
    grep -F 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" >/dev/null && echo 'valid_cli=PASS' || echo 'valid_cli=FAIL'
    grep -F 'Usage: submit <task text>' "$evidence/invalid.txt" >/dev/null && echo 'invalid_cli=PASS' || echo 'invalid_cli=FAIL'
    grep -F 'java.util.List<java.lang.String> labels(boolean)' "$evidence/java-bytecode.txt" >/dev/null && echo 'unannotated_java_signature=PASS' || echo 'unannotated_java_signature=FAIL'
} > "$evidence/assertions.txt"

test "$invalid_result" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
