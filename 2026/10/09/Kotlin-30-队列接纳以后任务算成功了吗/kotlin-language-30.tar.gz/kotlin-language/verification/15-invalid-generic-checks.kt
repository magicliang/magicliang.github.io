package example.tasks

fun invalidGenericChecks(states: MutableList<out TaskState>, unknown: Any) {
    states.add(TaskState.Running)
    if (unknown is List<String>) println(unknown.size)
}
