package example.tasks

fun nestedParentAccess(): TaskDraft = taskDraft {
    id = TaskId("task-1")
    text = "alpha"
    label {
        value = "urgent"
        text = "overwritten"
    }
}
