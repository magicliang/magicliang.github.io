#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/16"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && ./gradlew --version' || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test || exit 1
for suite in MainTest TaskSettingsTest CommandParserTest TaskProposalTest TaskTextTest OptionalTaskNoteTest TaskQueryTest TaskLabelRulesTest TaskLabelPipelineTest TaskTest TaskRecordTest TaskStoreTest TaskStateTest SubmissionDecisionTest TaskFormattingTest TaskStatePortsTest TypedTaskIdTest; do
    run "$suite" cat "build/test-results/test/TEST-example.tasks.$suite.xml" || exit 1
done
run bytecode javap -p -c -classpath build/classes/kotlin/main example.tasks.TaskId example.tasks.TypedTaskIdKt || exit 1
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit
invalid_result=$?

scratch="$(mktemp -d /tmp/kotlin-16-rejected-XXXXXX)"
mkdir -p "$scratch/gradle/wrapper" "$scratch/src/main/kotlin"
cp gradlew "$scratch/"
sed '/implementation(project(":domain"))/d' build.gradle.kts > "$scratch/build.gradle.kts"
sed '/include(":domain")/d' settings.gradle.kts > "$scratch/settings.gradle.kts"
cp gradle/wrapper/* "$scratch/gradle/wrapper/"
cp domain/src/main/kotlin/example/tasks/TaskState.kt domain/src/main/kotlin/example/tasks/TaskStore.kt src/main/kotlin/example/tasks/SubmissionDecision.kt src/main/kotlin/example/tasks/TypedTaskId.kt verification/16-invalid-types.kt "$scratch/src/main/kotlin/"
run rejected bash -c 'cd "$1" && ./gradlew --offline --no-daemon --console=plain compileKotlin' _ "$scratch"
rejected_result=$?

{
    printf 'build_exit=0\nbytecode_exit=0\nvalid_exit=0\ninvalid_exit=%s\nrejected_exit=%s\n' "$invalid_result" "$rejected_result"
    for suite in MainTest TaskSettingsTest CommandParserTest TaskProposalTest TaskTextTest OptionalTaskNoteTest TaskQueryTest TaskLabelRulesTest TaskLabelPipelineTest TaskTest TaskRecordTest TaskStoreTest TaskStateTest SubmissionDecisionTest TaskFormattingTest TaskStatePortsTest TypedTaskIdTest; do
        grep -F 'tests="2" skipped="0" failures="0" errors="0"' "$evidence/$suite.txt" >/dev/null && echo "$suite=PASS" || echo "$suite=FAIL"
    done
    grep -F 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" >/dev/null && echo 'valid_cli=PASS' || echo 'valid_cli=FAIL'
    grep -F 'Usage: submit <task text>' "$evidence/invalid.txt" >/dev/null && echo 'invalid_cli=PASS' || echo 'invalid_cli=FAIL'
    grep -F 'Cannot check for instance of erased type' "$evidence/rejected.txt" >/dev/null && echo 'noninline_generic_check_rejected=PASS' || echo 'noninline_generic_check_rejected=FAIL'
    grep -F 'Argument type mismatch' "$evidence/rejected.txt" >/dev/null && echo 'raw_string_id_rejected=PASS' || echo 'raw_string_id_rejected=FAIL'
    grep -F 'box-impl' "$evidence/bytecode.txt" >/dev/null && echo 'generated_box_symbol=PASS' || echo 'generated_box_symbol=FAIL'
} > "$evidence/assertions.txt"

test "$invalid_result" -ne 0 && test "$rejected_result" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
