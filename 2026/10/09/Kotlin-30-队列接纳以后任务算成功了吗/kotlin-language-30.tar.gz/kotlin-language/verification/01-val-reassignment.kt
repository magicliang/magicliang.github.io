fun changeLabelReference() {
    val labels = mutableListOf("first")
    labels = mutableListOf("next")
}
