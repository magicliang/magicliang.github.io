#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/03"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && ./gradlew --version' || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test || exit 1
for suite in MainTest TaskSettingsTest CommandParserTest TaskProposalTest; do
    run "$suite" cat "build/test-results/test/TEST-example.tasks.$suite.xml" || exit 1
done
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit
invalid_status=$?

scratch="$(mktemp -d /tmp/kotlin-03-rejected-XXXXXX)"
mkdir -p "$scratch/gradle/wrapper" "$scratch/src/main/kotlin"
cp gradlew "$scratch/"
sed '/implementation(project(":domain"))/d' build.gradle.kts > "$scratch/build.gradle.kts"
sed '/include(":domain")/d' settings.gradle.kts > "$scratch/settings.gradle.kts"
cp gradle/wrapper/* "$scratch/gradle/wrapper/"
cp verification/03-java-named-args.kt "$scratch/src/main/kotlin/"
run rejected bash -c 'cd "$1" && ./gradlew --offline --no-daemon --console=plain compileKotlin' _ "$scratch"
rejected_status=$?

{
    printf 'build_exit=0\nvalid_exit=0\ninvalid_exit=%s\nrejected_exit=%s\n' "$invalid_status" "$rejected_status"
    for suite in MainTest TaskSettingsTest CommandParserTest TaskProposalTest; do
        grep -F 'tests="2" skipped="0" failures="0" errors="0"' "$evidence/$suite.txt" >/dev/null && echo "$suite=PASS" || echo "$suite=FAIL"
    done
    grep -F 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" >/dev/null && echo 'valid_cli=PASS' || echo 'valid_cli=FAIL'
    grep -F 'Usage: submit <task text>' "$evidence/invalid.txt" >/dev/null && echo 'invalid_cli=PASS' || echo 'invalid_cli=FAIL'
    grep -F 'None of the following candidates is applicable:' "$evidence/rejected.txt" >/dev/null && grep -F 'static fun max(p0: Int, p1: Int): Int' "$evidence/rejected.txt" >/dev/null && echo 'java_named_rejected=PASS' || echo 'java_named_rejected=FAIL'
} > "$evidence/assertions.txt"

test "$invalid_status" -ne 0 && test "$rejected_status" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
