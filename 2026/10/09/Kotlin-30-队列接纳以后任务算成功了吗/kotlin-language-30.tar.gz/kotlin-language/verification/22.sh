#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/22"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && ./gradlew --version' || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test || exit 1
suite_count=0
for xml in build/test-results/test/TEST-example.tasks.*.xml; do
    suite="${xml##*/}"
    suite="${suite#TEST-example.tasks.}"
    suite="${suite%.xml}"
    run "$suite" cat "$xml" || exit 1
    ((suite_count+=1))
done
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit
invalid_result=$?

scratch="$(mktemp -d /tmp/kotlin-22-rejected-XXXXXX)"
mkdir -p "$scratch/gradle/wrapper" "$scratch/src/main/kotlin"
cp gradlew "$scratch/"
cp gradle/wrapper/* "$scratch/gradle/wrapper/"
sed '/implementation(project(":domain"))/d' build.gradle.kts > "$scratch/build.gradle.kts"
sed '/include(":domain")/d' settings.gradle.kts > "$scratch/settings.gradle.kts"
cp domain/src/main/kotlin/example/tasks/TaskState.kt domain/src/main/kotlin/example/tasks/TaskStore.kt verification/22-incomplete-state.kt "$scratch/src/main/kotlin/"
run rejected bash -c 'cd "$1" && ./gradlew --offline --no-daemon --console=plain compileKotlin' _ "$scratch"
rejected_result=$?

regression_root="$(mktemp -d /tmp/kotlin-22-regression-XXXXXX)"
mkdir -p "$regression_root/examples" "$regression_root/writing-plans/kotlin/verification"
tar -C .. --exclude build --exclude .gradle --exclude .kotlin -cf - kotlin-language | tar -C "$regression_root/examples" -xf - || exit 1
run regression-16 bash "$regression_root/examples/kotlin-language/verification/16.sh" || exit 1
cp "$regression_root/writing-plans/kotlin/verification/16/rejected.txt" "$evidence/regression-16-rejected.txt"
cp "$regression_root/writing-plans/kotlin/verification/16/assertions.txt" "$evidence/regression-16-assertions.txt"

{
    printf 'build_exit=0\nsuite_count=%s\nvalid_exit=0\ninvalid_exit=%s\nrejected_exit=%s\nregression_16_exit=0\n' "$suite_count" "$invalid_result" "$rejected_result"
    for xml in build/test-results/test/TEST-example.tasks.*.xml; do
        suite="${xml##*/}"
        suite="${suite#TEST-example.tasks.}"
        suite="${suite%.xml}"
        grep -F 'tests="2" skipped="0" failures="0" errors="0"' "$evidence/$suite.txt" >/dev/null && echo "$suite=PASS" || echo "$suite=FAIL"
    done
    grep -F 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" >/dev/null && echo 'valid_cli=PASS' || echo 'valid_cli=FAIL'
    grep -F 'Usage: submit <task text>' "$evidence/invalid.txt" >/dev/null && echo 'invalid_cli=PASS' || echo 'invalid_cli=FAIL'
    grep -F "'when' expression must be exhaustive" "$evidence/rejected.txt" >/dev/null && echo 'incomplete_when_rejected=PASS' || echo 'incomplete_when_rejected=FAIL'
    grep -F 'raw_string_id_rejected=PASS' "$evidence/regression-16-assertions.txt" >/dev/null && echo 'previous_negative_contract=PASS' || echo 'previous_negative_contract=FAIL'
    grep -F 'rejected_exit=1' "$evidence/regression-16-assertions.txt" >/dev/null && echo 'previous_expected_failure_exit=PASS' || echo 'previous_expected_failure_exit=FAIL'
} > "$evidence/assertions.txt"

test "$suite_count" -eq 23 && test "$invalid_result" -ne 0 && test "$rejected_result" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
