#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/20"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && javac -version && ./gradlew --version' || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test || exit 1
for suite in MainTest TaskSettingsTest CommandParserTest TaskProposalTest TaskTextTest OptionalTaskNoteTest TaskQueryTest TaskLabelRulesTest TaskLabelPipelineTest TaskTest TaskRecordTest TaskStoreTest TaskStateTest SubmissionDecisionTest TaskFormattingTest TaskStatePortsTest TypedTaskIdTest TaskDraftTest TaskMetadataTest JavaInputBoundaryTest TaskJavaApiConsumerTest; do
    run "$suite" cat "build/test-results/test/TEST-example.tasks.$suite.xml" || exit 1
done
run bytecode javap -p -classpath build/classes/kotlin/main example.tasks.TaskJavaApi || exit 1
run observer-bytecode javap -p -classpath build/classes/kotlin/main example.tasks.TaskJavaObserver || exit 1
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit
invalid_result=$?

scratch="$(mktemp -d /tmp/kotlin-20-java-rejected-XXXXXX)"
mkdir -p "$scratch/example/tasks"
cp verification/20-invalid-java-overload.java "$scratch/example/tasks/InvalidJavaOverload.java"
run rejected javac --release 21 -classpath build/classes/kotlin/main:build/classes/java/main -d "$scratch" "$scratch/example/tasks/InvalidJavaOverload.java"
rejected_result=$?

{
    printf 'build_exit=0\nbytecode_exit=0\nobserver_bytecode_exit=0\nvalid_exit=0\ninvalid_exit=%s\nrejected_exit=%s\n' "$invalid_result" "$rejected_result"
    for suite in MainTest TaskSettingsTest CommandParserTest TaskProposalTest TaskTextTest OptionalTaskNoteTest TaskQueryTest TaskLabelRulesTest TaskLabelPipelineTest TaskTest TaskRecordTest TaskStoreTest TaskStateTest SubmissionDecisionTest TaskFormattingTest TaskStatePortsTest TypedTaskIdTest TaskDraftTest TaskMetadataTest JavaInputBoundaryTest TaskJavaApiConsumerTest; do
        grep -F 'tests="2" skipped="0" failures="0" errors="0"' "$evidence/$suite.txt" >/dev/null && echo "$suite=PASS" || echo "$suite=FAIL"
    done
    grep -F 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" >/dev/null && echo 'valid_cli=PASS' || echo 'valid_cli=FAIL'
    grep -F 'Usage: submit <task text>' "$evidence/invalid.txt" >/dev/null && echo 'invalid_cli=PASS' || echo 'invalid_cli=FAIL'
    grep -F 'cannot be applied to given types' "$evidence/rejected.txt" >/dev/null && echo 'default_without_overload_rejected=PASS' || echo 'default_without_overload_rejected=FAIL'
    grep -F 'throws java.io.IOException' "$evidence/bytecode.txt" >/dev/null && echo 'checked_exception_signature=PASS' || echo 'checked_exception_signature=FAIL'
    grep -F 'getCategory()' "$evidence/bytecode.txt" >/dev/null && echo 'java_static_property_getter=PASS' || echo 'java_static_property_getter=FAIL'
    grep -F 'implementationMarker' "$evidence/bytecode.txt" >/dev/null && echo 'internal_jvm_symbol=PASS' || echo 'internal_jvm_symbol=FAIL'
    grep -F 'default java.lang.String describe(java.lang.String)' "$evidence/observer-bytecode.txt" >/dev/null && echo 'default_interface_method=PASS' || echo 'default_interface_method=FAIL'
} > "$evidence/assertions.txt"

test "$invalid_result" -ne 0 && test "$rejected_result" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
