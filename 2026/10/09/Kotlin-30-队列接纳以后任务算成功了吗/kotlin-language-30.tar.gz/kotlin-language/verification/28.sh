#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/28"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && ./gradlew --version' || exit 1
run dependencies ./gradlew --offline --no-daemon --console=plain dependencies --configuration testRuntimeClasspath || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test || exit 1
suite_count=0
for xml in build/test-results/test/TEST-example.tasks.*.xml; do
    suite="${xml##*/}"
    suite="${suite#TEST-example.tasks.}"
    suite="${suite%.xml}"
    run "$suite" cat "$xml" || exit 1
    ((suite_count+=1))
done
run bytecode javap -classpath build/classes/kotlin/main -p -s example.tasks.TaskFailureBoundaryKt || exit 1
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit
invalid_result=$?

{
    printf 'build_exit=0\nsuite_count=%s\nvalid_exit=0\ninvalid_exit=%s\n' "$suite_count" "$invalid_result"
    for xml in build/test-results/test/TEST-example.tasks.*.xml; do
        suite="${xml##*/}"
        suite="${suite#TEST-example.tasks.}"
        suite="${suite%.xml}"
        case "$suite" in
            CancellableTaskRunTest|TaskFailureBoundaryTest) expected=4 ;;
            BlockingTaskStepTest|ManagedTaskServiceTest) expected=3 ;;
            *) expected=2 ;;
        esac
        grep -F "tests=\"$expected\" skipped=\"0\" failures=\"0\" errors=\"0\"" "$evidence/$suite.txt" >/dev/null && echo "$suite=PASS" || echo "$suite=FAIL"
    done
    for pair in 'ordinary_launch_parent_failed=true sibling_cleaned=true' 'supervised_launch_handler=true sibling_completed=true' 'supervised_async_awaiter_failed=true sibling_completed=true' 'cancellation_rethrown=true ordinary_failure_captured=true'; do
        grep -F "$pair" "$evidence/TaskFailureBoundaryTest.txt" >/dev/null && echo "tree_$pair=PASS" || echo "tree_$pair=FAIL"
    done
    grep -F 'VIRTUAL cancelled_before_lease_delivery=true lost_lease_close=1' "$evidence/CancellableTaskRunTest.txt" >/dev/null && echo 'resource_regression=PASS' || echo 'resource_regression=FAIL'
    grep -F 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" >/dev/null && echo 'valid_cli=PASS' || echo 'valid_cli=FAIL'
    grep -F 'Usage: submit <task text>' "$evidence/invalid.txt" >/dev/null && echo 'invalid_cli=PASS' || echo 'invalid_cli=FAIL'
} > "$evidence/assertions.txt"

test "$suite_count" -eq 30 && test "$invalid_result" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
