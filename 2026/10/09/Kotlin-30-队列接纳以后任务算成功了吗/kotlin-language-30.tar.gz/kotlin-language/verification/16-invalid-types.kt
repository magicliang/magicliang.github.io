package example.tasks

fun <State : TaskState> erasedStateCheck(value: Any): Boolean = value is State

fun wrongTaskId(store: TaskStore): Result<SubmissionDecision> = submitTyped(store, "raw-id", "alpha")
