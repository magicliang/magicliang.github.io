package example.tasks

@TaskCategory("invalid-target")
fun invalidMetadataTarget(): Unit = Unit
