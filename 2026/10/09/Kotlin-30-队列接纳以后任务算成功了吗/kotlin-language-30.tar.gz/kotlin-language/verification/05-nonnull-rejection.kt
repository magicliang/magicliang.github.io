package example.tasks

val invalidNote: String = null
