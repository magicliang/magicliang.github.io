#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/21"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && javac -version && ./gradlew --version' || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test || exit 1
for suite in MainTest TaskSettingsTest CommandParserTest TaskProposalTest TaskTextTest OptionalTaskNoteTest TaskQueryTest TaskLabelRulesTest TaskLabelPipelineTest TaskTest TaskRecordTest TaskStoreTest TaskStateTest SubmissionDecisionTest TaskFormattingTest TaskStatePortsTest TypedTaskIdTest TaskDraftTest TaskMetadataTest JavaInputBoundaryTest TaskJavaApiConsumerTest ModuleBoundaryTest; do
    run "$suite" cat "build/test-results/test/TEST-example.tasks.$suite.xml" || exit 1
done
run app-dependencies ./gradlew --offline --no-daemon --console=plain :dependencies --configuration runtimeClasspath || exit 1
run domain-dependencies ./gradlew --offline --no-daemon --console=plain :domain:dependencies --configuration runtimeClasspath || exit 1
run app-bytecode javap -verbose -classpath build/classes/kotlin/main example.tasks.MainKt || exit 1
run domain-bytecode javap -verbose -classpath domain/build/classes/kotlin/main example.tasks.TaskState || exit 1
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit
invalid_result=$?

scratch="$(mktemp -d /tmp/kotlin-21-domain-classpath-XXXXXX)"
mkdir -p "$scratch/example/tasks"
cp verification/21-domain-classpath.java "$scratch/example/tasks/RequiresDomain.java"
run missing-domain javac --release 21 -classpath build/classes/kotlin/main -d "$scratch" "$scratch/example/tasks/RequiresDomain.java"
missing_result=$?
run with-domain javac --release 21 -classpath build/classes/kotlin/main:domain/build/classes/kotlin/main -d "$scratch" "$scratch/example/tasks/RequiresDomain.java" || exit 1

{
    printf 'build_exit=0\napp_dependencies_exit=0\ndomain_dependencies_exit=0\napp_bytecode_exit=0\ndomain_bytecode_exit=0\nvalid_exit=0\ninvalid_exit=%s\nmissing_domain_exit=%s\nwith_domain_exit=0\n' "$invalid_result" "$missing_result"
    for suite in MainTest TaskSettingsTest CommandParserTest TaskProposalTest TaskTextTest OptionalTaskNoteTest TaskQueryTest TaskLabelRulesTest TaskLabelPipelineTest TaskTest TaskRecordTest TaskStoreTest TaskStateTest SubmissionDecisionTest TaskFormattingTest TaskStatePortsTest TypedTaskIdTest TaskDraftTest TaskMetadataTest JavaInputBoundaryTest TaskJavaApiConsumerTest ModuleBoundaryTest; do
        grep -F 'tests="2" skipped="0" failures="0" errors="0"' "$evidence/$suite.txt" >/dev/null && echo "$suite=PASS" || echo "$suite=FAIL"
    done
    grep -F 'project :domain' "$evidence/app-dependencies.txt" >/dev/null && echo 'app_depends_on_domain=PASS' || echo 'app_depends_on_domain=FAIL'
    grep -F 'org.jetbrains.kotlin:kotlin-stdlib:2.2.21' "$evidence/domain-dependencies.txt" >/dev/null && echo 'domain_stdlib=PASS' || echo 'domain_stdlib=FAIL'
    grep -F 'major version: 65' "$evidence/app-bytecode.txt" >/dev/null && echo 'app_target_21=PASS' || echo 'app_target_21=FAIL'
    grep -F 'major version: 65' "$evidence/domain-bytecode.txt" >/dev/null && echo 'domain_target_21=PASS' || echo 'domain_target_21=FAIL'
    grep -F 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" >/dev/null && echo 'valid_cli=PASS' || echo 'valid_cli=FAIL'
    grep -F 'Usage: submit <task text>' "$evidence/invalid.txt" >/dev/null && echo 'invalid_cli=PASS' || echo 'invalid_cli=FAIL'
    grep -F 'cannot find symbol' "$evidence/missing-domain.txt" >/dev/null && echo 'missing_domain_classpath_rejected=PASS' || echo 'missing_domain_classpath_rejected=FAIL'
} > "$evidence/assertions.txt"

test "$invalid_result" -ne 0 && test "$missing_result" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
