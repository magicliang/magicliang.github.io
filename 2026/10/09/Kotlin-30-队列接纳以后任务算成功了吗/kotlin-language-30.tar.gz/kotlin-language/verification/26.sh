#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/26"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && ./gradlew --version' || exit 1
run dependencies ./gradlew --offline --no-daemon --console=plain dependencies --configuration testRuntimeClasspath || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test || exit 1
suite_count=0
for xml in build/test-results/test/TEST-example.tasks.*.xml; do
    suite="${xml##*/}"
    suite="${suite#TEST-example.tasks.}"
    suite="${suite%.xml}"
    run "$suite" cat "$xml" || exit 1
    ((suite_count+=1))
done
run bytecode javap -classpath build/classes/kotlin/main -p -s example.tasks.BlockingTaskStepKt || exit 1
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit
invalid_result=$?

{
    printf 'build_exit=0\nsuite_count=%s\nvalid_exit=0\ninvalid_exit=%s\n' "$suite_count" "$invalid_result"
    for xml in build/test-results/test/TEST-example.tasks.*.xml; do
        suite="${xml##*/}"
        suite="${suite#TEST-example.tasks.}"
        suite="${suite%.xml}"
        if [[ "$suite" == BlockingTaskStepTest || "$suite" == ManagedTaskServiceTest ]]; then
            expected=3
        else
            expected=2
        fi
        grep -F "tests=\"$expected\" skipped=\"0\" failures=\"0\" errors=\"0\"" "$evidence/$suite.txt" >/dev/null && echo "$suite=PASS" || echo "$suite=FAIL"
    done
    grep -F 'REAL caller_probe=kotlin-26-caller io_queued=1' "$evidence/BlockingTaskStepTest.txt" >/dev/null && echo 'real_isolated_worker=PASS' || echo 'real_isolated_worker=FAIL'
    grep -F 'CONTEXT worker_before=null propagated=request-26 worker_after=null' "$evidence/BlockingTaskStepTest.txt" >/dev/null && echo 'thread_local_restore=PASS' || echo 'thread_local_restore=FAIL'
    grep -F 'REAL cancelled_before_release=true blocked_exit_after_release=true' "$evidence/BlockingTaskStepTest.txt" >/dev/null && echo 'cancel_does_not_release_block=PASS' || echo 'cancel_does_not_release_block=FAIL'
    grep -F 'TREE owner_stop_joined=true task_cancelled=true child_cleaned=true new_start_rejected=true' "$evidence/ManagedTaskServiceTest.txt" >/dev/null && echo 'owner_regression=PASS' || echo 'owner_regression=FAIL'
    grep -F 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" >/dev/null && echo 'valid_cli=PASS' || echo 'valid_cli=FAIL'
    grep -F 'Usage: submit <task text>' "$evidence/invalid.txt" >/dev/null && echo 'invalid_cli=PASS' || echo 'invalid_cli=FAIL'
} > "$evidence/assertions.txt"

test "$suite_count" -eq 28 && test "$invalid_result" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
