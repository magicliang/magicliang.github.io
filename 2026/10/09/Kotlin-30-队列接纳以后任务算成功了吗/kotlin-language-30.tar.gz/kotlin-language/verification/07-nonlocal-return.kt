package example.tasks

fun invokeCallback(callback: () -> Unit) {
    callback()
}

fun invalidNonLocalReturn() {
    invokeCallback { return }
}
