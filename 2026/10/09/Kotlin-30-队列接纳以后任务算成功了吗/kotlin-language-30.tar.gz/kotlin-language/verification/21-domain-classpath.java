package example.tasks;

final class RequiresDomain {
    TaskStore store;
}
