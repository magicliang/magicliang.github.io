class UnstableTaskText(private val read: () -> String?) {
    val text: String?
        get() = read()
}

fun invalidLength(source: UnstableTaskText): Int {
    if (source.text != null) {
        return source.text.length
    }
    return 0
}

class MutableTaskText(var text: String?)

fun invalidMutableLength(source: MutableTaskText): Int {
    if (source.text != null) {
        return source.text.length
    }
    return 0
}
