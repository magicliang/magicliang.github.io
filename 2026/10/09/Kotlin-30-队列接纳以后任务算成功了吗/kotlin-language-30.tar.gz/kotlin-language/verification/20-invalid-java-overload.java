package example.tasks;

public final class InvalidJavaOverload {
    public static String call() {
        return TaskJavaApi.describeWithoutOverloads("task-1");
    }
}
