package example.tasks

fun invalidJavaNamedArgument(): Int = java.lang.Math.max(a = 1, b = 2)
