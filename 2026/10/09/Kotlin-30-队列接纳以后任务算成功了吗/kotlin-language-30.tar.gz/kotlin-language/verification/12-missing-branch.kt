package example.tasks

fun invalidStateDescription(state: TaskState): String = when (state) {
    TaskState.Queued -> "queued"
    TaskState.Running -> "running"
    is TaskState.Succeeded -> "succeeded"
    TaskState.Cancelled -> "cancelled"
}
