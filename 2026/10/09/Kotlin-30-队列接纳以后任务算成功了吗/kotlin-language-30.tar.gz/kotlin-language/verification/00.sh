#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/00"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

if ! run environment bash -c 'date -u && uname -a && java -version && ./gradlew --version'; then
    printf 'ENVIRONMENT=FAIL\n' > "$evidence/assertions.txt"
    exit 1
fi

if ! run build ./gradlew --console=plain --no-daemon clean test; then
    printf 'BUILD=FAIL\n' > "$evidence/assertions.txt"
    exit 1
fi
if ! run valid ./gradlew --console=plain --no-daemon run --args='submit nightly-index'; then
    printf 'RUN=FAIL\n' > "$evidence/assertions.txt"
    exit 1
fi
run invalid ./gradlew --console=plain --no-daemon run --args=submit
invalid_status=$?
run bytecode javap -verbose -classpath build/classes/kotlin/main example.tasks.MainKt
bytecode_status=$?
run dependencies ./gradlew --console=plain --no-daemon dependencies --configuration runtimeClasspath
dependencies_status=$?
run compiler-dependencies ./gradlew --console=plain --no-daemon dependencies --configuration kotlinCompilerClasspath
compiler_status=$?
run testsuite cat build/test-results/test/TEST-example.tasks.MainTest.xml
testsuite_status=$?

{
    printf 'environment_exit=0\nbuild_exit=0\nvalid_exit=0\ninvalid_exit=%s\nbytecode_exit=%s\ndependencies_exit=%s\ncompiler_exit=%s\ntestsuite_exit=%s\n' "$invalid_status" "$bytecode_status" "$dependencies_status" "$compiler_status" "$testsuite_status"
    grep -F 'TASK input accepted (not persisted): nightly-index' "$evidence/valid.txt" >/dev/null && echo 'valid_output=PASS' || echo 'valid_output=FAIL'
    grep -F 'Usage: submit <task text>' "$evidence/invalid.txt" >/dev/null && echo 'invalid_diagnostic=PASS' || echo 'invalid_diagnostic=FAIL'
    grep -F 'major version: 65' "$evidence/bytecode.txt" >/dev/null && echo 'jdk21_bytecode=PASS' || echo 'jdk21_bytecode=FAIL'
    grep -F 'org.jetbrains.kotlin:kotlin-stdlib:2.2.21' "$evidence/dependencies.txt" >/dev/null && echo 'stdlib_version=PASS' || echo 'stdlib_version=FAIL'
    grep -F 'org.jetbrains.kotlin:kotlin-compiler-embeddable:2.2.21' "$evidence/compiler-dependencies.txt" >/dev/null && echo 'compiler_version=PASS' || echo 'compiler_version=FAIL'
    grep -F 'tests="2" skipped="0" failures="0" errors="0"' "$evidence/testsuite.txt" >/dev/null && echo 'behavior_tests=PASS' || echo 'behavior_tests=FAIL'
} > "$evidence/assertions.txt"

test "$invalid_status" -ne 0 && test "$bytecode_status" -eq 0 && test "$dependencies_status" -eq 0 && test "$compiler_status" -eq 0 && test "$testsuite_status" -eq 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
