package example.tasks

fun incompleteStateLabel(state: TaskState): String = when (state) {
    TaskState.Queued -> "queued"
    TaskState.Running -> "running"
    is TaskState.Succeeded -> "succeeded"
    is TaskState.Failed -> "failed"
}
