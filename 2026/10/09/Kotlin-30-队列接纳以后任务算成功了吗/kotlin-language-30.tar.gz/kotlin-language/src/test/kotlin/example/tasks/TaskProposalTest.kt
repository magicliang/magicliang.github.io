package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNull

class TaskProposalTest {
    @Test
    fun distinguishesDefaultsNamedArgumentsAndExpandedVarargs() {
        assertEquals("TASK proposal (not submitted): alpha; retries=2; labels=none", taskProposal("alpha"))
        assertEquals(
            "TASK proposal (not submitted): alpha; retries=4; labels=one,two",
            taskProposal(labels = arrayOf("one", "two"), text = "alpha", retries = 4),
        )
        assertEquals(
            "TASK proposal (not submitted): beta; retries=0; labels=urgent",
            taskProposal("beta", 0, *arrayOf("urgent")),
        )
    }

    @Test
    fun distinguishesMissingResultInvalidInputAndUnitAction() {
        assertNull(taskProposal("   "))
        assertEquals("Retries out of range: 6", assertFailsWith<IllegalArgumentException> {
            taskProposal("alpha", retries = 6)
        }.message)
        assertFailsWith<IllegalArgumentException> { taskProposal(" ", retries = 6) }
        assertFailsWith<IllegalArgumentException> { taskProposal("alpha", labels = arrayOf("")) }

        val received = mutableListOf<String>()
        val result: Unit = emitProposal(null, received::add)
        assertEquals(Unit, result)
        assertEquals(listOf("No proposal: blank task text"), received)
    }
}
