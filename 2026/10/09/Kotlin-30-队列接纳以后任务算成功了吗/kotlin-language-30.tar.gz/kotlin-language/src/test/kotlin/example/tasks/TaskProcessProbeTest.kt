package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotEquals
import kotlin.test.assertTrue

class TaskProcessProbeTest {
    @Test
    fun fixedJdkVersionProcessExitsSuccessfully() {
        val probe = probeJdkProcess(true)
        assertEquals(0, probe.exitCode)
        assertTrue(probe.output.contains("version"))
        println("PROCESS java_version_exit=${probe.exitCode} output=${probe.output.lineSequence().first()}")
    }

    @Test
    fun fixedInvalidOptionExitsWithFailureAndOutput() {
        val probe = probeJdkProcess(false)
        assertNotEquals(0, probe.exitCode)
        assertTrue(probe.output.isNotBlank())
        println("PROCESS invalid_option_exit=${probe.exitCode} output=${probe.output.lineSequence().first()}")
    }
}
