package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class TaskStateTest {
    @Test
    fun classifiesAndAdvancesOnlyAllowedSequentialStates() {
        assertEquals(TaskStage.WAITING, taskStage(TaskState.Queued))
        val running = advanceTask(TaskState.Queued, TaskSignal.Start)
        assertEquals(TaskState.Running, running)
        assertEquals(TaskStage.ACTIVE, taskStage(running))
        val success = advanceTask(running, TaskSignal.Success("indexed"))
        assertEquals(TaskState.Succeeded("indexed"), success)
        assertEquals(TaskStage.TERMINAL, taskStage(success))
        assertEquals(TaskState.Failed("disk"), advanceTask(running, TaskSignal.Failure("disk")))
        assertEquals(TaskState.Cancelled, advanceTask(TaskState.Queued, TaskSignal.Cancel))
        assertEquals(TaskState.Cancelled, advanceTask(running, TaskSignal.Cancel))
    }

    @Test
    fun rejectsInvalidOrTerminalOverwritesAndConflictingDuplicateIds() {
        val running = advanceTask(TaskState.Queued, TaskSignal.Start)
        assertFailsWith<IllegalStateException> { advanceTask(TaskState.Queued, TaskSignal.Success("early")) }
        assertFailsWith<IllegalStateException> { advanceTask(running, TaskSignal.Start) }
        assertFailsWith<IllegalStateException> {
            advanceTask(advanceTask(running, TaskSignal.Cancel), TaskSignal.Success("late"))
        }
        assertFailsWith<IllegalStateException> {
            advanceTask(advanceTask(running, TaskSignal.Success("done")), TaskSignal.Cancel)
        }
        assertFailsWith<IllegalStateException> {
            advanceTask(advanceTask(running, TaskSignal.Failure("error")), TaskSignal.Start)
        }

        val store: TaskStore = InMemoryTaskStore.empty()
        assertTrue(acceptSubmission(store, "task-1", "alpha"))
        assertFalse(acceptSubmission(store, "task-1", "alpha"))
        assertFailsWith<IllegalArgumentException> { acceptSubmission(store, "task-1", "other") }
        assertEquals("alpha", store.find("task-1"))
    }
}
