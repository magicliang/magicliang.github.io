package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

private open class BaseTaskTrace(private val events: MutableList<String>) {
    init {
        events.add("base:${description()}")
    }

    open fun description(): String = "base"
}

private class DerivedTaskTrace(private val events: MutableList<String>) : BaseTaskTrace(events) {
    private val detail: String = "ready"

    init {
        events.add("derived:$detail")
    }

    override fun description(): String = detail
}

class TaskTest {
    @Test
    fun constructorSetterAndLazyInitializationHaveDistinctTiming() {
        val events = mutableListOf<String>()
        val task = Task(" alpha ", events)
        assertEquals("alpha", task.text)
        assertEquals("alpha", task.displayName)
        assertEquals(listOf("normalize:alpha", "init:alpha"), events)
        assertFailsWith<UninitializedPropertyAccessException> { task.owner }
        task.owner = "worker"
        assertEquals("worker", task.owner)

        task.displayName = " visible "
        assertEquals("visible", task.displayName)
        assertEquals("task:alpha", task.label)
        assertEquals("task:alpha", task.label)
        assertEquals(listOf("normalize:alpha", "init:alpha", "set:visible", "lazy:alpha"), events)
        assertFailsWith<IllegalArgumentException> { task.displayName = " " }
        assertEquals("visible", task.displayName)
    }

    @Test
    fun constructorRejectsBlankTextAndOpenDispatchSeesUninitializedDerivedField() {
        val events = mutableListOf<String>()
        assertEquals("Task text must not be blank", assertFailsWith<IllegalArgumentException> {
            Task(" ", events)
        }.message)
        assertEquals(listOf("normalize:", "init:"), events)

        val dispatchEvents = mutableListOf<String>()
        DerivedTaskTrace(dispatchEvents)
        assertEquals(listOf("base:null", "derived:ready"), dispatchEvents)
    }
}
