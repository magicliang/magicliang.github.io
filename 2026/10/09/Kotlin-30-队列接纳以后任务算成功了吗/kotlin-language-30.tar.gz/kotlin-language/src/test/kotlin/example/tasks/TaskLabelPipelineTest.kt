package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class TaskLabelPipelineTest {
    private val labels = listOf("Queued", "Urgent", "Quiet", "Later")

    @Test
    fun listPipelineEvaluatesBeforeTakeResultIsReturned() {
        val trace = mutableListOf<String>()
        val result = eagerTaskLabels(labels, trace::add)
        assertEquals(listOf("queued"), result)
        assertEquals(
            listOf(
                "map:Queued", "map:Urgent", "map:Quiet", "map:Later",
                "filter:queued", "filter:urgent", "filter:quiet", "filter:later",
            ),
            trace,
        )
    }

    @Test
    fun listBackedSequenceDefersAndRepeatsPerTraversal() {
        val trace = mutableListOf<String>()
        val sequence = lazyTaskLabels(labels, trace::add)
        assertTrue(trace.isEmpty())
        assertEquals(listOf("queued"), sequence.toList())
        assertEquals(listOf("map:Queued", "filter:queued"), trace)
        assertEquals(listOf("queued"), sequence.toList())
        assertEquals(
            listOf("map:Queued", "filter:queued", "map:Queued", "filter:queued"),
            trace,
        )
    }
}
