package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue
import kotlin.test.assertFailsWith

class TaskStoreTest {
    @Test
    fun interfaceHasOneActualInMemoryReplacementPoint() {
        val first: TaskStore = InMemoryTaskStore.empty()
        val second: TaskStore = InMemoryTaskStore.empty()
        assertNull(first.find("task-1"))
        assertTrue(first.putIfAbsent("task-1", "alpha"))
        assertFalse(first.putIfAbsent("task-1", "replaced"))
        assertEquals("alpha", first.find("task-1"))
        assertNull(second.find("task-1"))
        assertTrue(TaskTextRules.valid("alpha"))
        assertFalse(TaskTextRules.valid(" "))
        assertFailsWith<IllegalArgumentException> { first.put("task-2", " ") }
        assertNull(first.find("task-2"))
    }

    @Test
    fun delegatedDefaultCallUsesDelegateNotWrappersOverride() {
        val events = mutableListOf<String>()
        val store = AuditedTaskStore(InMemoryTaskStore.empty(), events)
        store.put("direct", "alpha")
        assertEquals(listOf("attempt:direct"), events)
        assertEquals("direct", store.lastAttemptedId)
        assertTrue(store.putIfAbsent("delegated", "beta"))
        assertEquals("beta", store.find("delegated"))
        assertEquals(listOf("attempt:direct"), events)
        assertEquals("direct", store.lastAttemptedId)
        assertFailsWith<IllegalArgumentException> { store.put("failed", " ") }
        assertEquals(listOf("attempt:direct", "attempt:failed"), events)
        assertNull(store.find("failed"))
    }
}
