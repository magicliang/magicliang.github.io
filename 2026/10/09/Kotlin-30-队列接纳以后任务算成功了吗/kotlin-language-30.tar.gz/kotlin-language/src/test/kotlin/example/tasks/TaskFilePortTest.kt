package example.tasks

import java.io.IOException
import java.io.Reader
import java.io.StringReader
import java.io.Writer
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertSame

private class CountedReader(text: String) : StringReader(text) {
    var closes: Int = 0

    override fun close() {
        closes++
        super.close()
    }
}

private class FailingTaskReader(val failure: IOException) : Reader() {
    var closes: Int = 0
    private var delivered: Boolean = false

    override fun read(buffer: CharArray, offset: Int, length: Int): Int {
        if (delivered) throw failure
        val text = "task-x\tpartial\n"
        text.toCharArray().copyInto(buffer, offset)
        delivered = true
        return text.length
    }

    override fun close() {
        closes++
    }
}

class TaskFilePortTest {
    @Test
    fun closesReadersOnEofAndEarlyReturnWhileRealFileRoundTrips() {
        val eof = CountedReader("task-1\talpha\n")
        assertEquals(TaskFileImport(listOf(TaskFileRow("task-1", "alpha")), false), readTaskRows(eof))
        assertEquals(1, eof.closes)

        val early = CountedReader("task-2\t中文\n#stop\ntask-3\tignored\n")
        assertEquals(TaskFileImport(listOf(TaskFileRow("task-2", "中文")), true), readTaskRows(early))
        assertEquals(1, early.closes)

        val directory = Files.createTempDirectory("kotlin-23-rows-")
        val path = directory.resolve("tasks.tsv")
        try {
            val rows = listOf(TaskFileRow("task-1", "alpha"), TaskFileRow("task-2", "中文"))
            exportTaskFile(path, rows)
            assertEquals(TaskFileImport(rows, false), importTaskFile(path))
            val store = InMemoryTaskStore.empty()
            assertEquals(listOf(SubmissionDecision.Accepted, SubmissionDecision.Accepted), rows.map {
                submitValidated(store, it.id, it.text).getOrThrow()
            })
            assertEquals("中文", store.find("task-2"))
            println("FILE round_trip=2 eof_close=${eof.closes} early_close=${early.closes} stored=task-2")
        } finally {
            Files.deleteIfExists(path)
            Files.deleteIfExists(directory)
        }
    }

    @Test
    fun closesOnReadFailureAndPreservesOldFileOnStagedWriteFailure() {
        val readFailure = IOException("synthetic read failed")
        val failing = FailingTaskReader(readFailure)
        assertSame(readFailure, assertFailsWith<IOException> { readTaskRows(failing) })
        assertEquals(1, failing.closes)

        val directory = Files.createTempDirectory("kotlin-23-failure-")
        val path = directory.resolve("tasks.tsv")
        val original = "task-1\toriginal\n"
        var stagedWriter: Writer? = null
        val writeFailure = IOException("synthetic staged write failed")
        try {
            Files.writeString(path, original, StandardCharsets.UTF_8)
            assertSame(writeFailure, assertFailsWith<IOException> {
                exportTaskFile(path, listOf(TaskFileRow("task-1", "replacement"))) { writer, _ ->
                    stagedWriter = writer
                    writer.write("task-1\tpartial")
                    throw writeFailure
                }
            })
            assertFailsWith<IOException> { stagedWriter!!.write("after close") }
            assertEquals(original, Files.readString(path, StandardCharsets.UTF_8))
            Files.list(directory).use { files -> assertEquals(listOf(path), files.toList()) }
            println("FILE failure_close=${failing.closes} staged_writer_closed=true old_content_preserved=true")
        } finally {
            Files.deleteIfExists(path)
            Files.deleteIfExists(directory)
        }
    }
}
