package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNull

class TaskMetadataTest {
    @Test
    fun runtimeAnnotationIsVisibleButSourceHintIsNot() {
        assertEquals("draft", taskCategoryOf(TaskDraft::class.java))
        assertNull(TaskDraft::class.java.getAnnotation(TaskDraftHint::class.java))
        assertNull(taskCategoryOf(TaskState.Queued::class.java))
    }

    @Test
    fun metadataReadDoesNotRunDraftValidation() {
        val raw = TaskDraft(TaskId("task-1"), " ", listOf(" "))
        assertEquals("draft", taskCategoryOf(raw.javaClass))
        assertEquals(" ", raw.text)
        assertFailsWith<IllegalArgumentException> { makeTaskDraft(raw.id, raw.text, raw.labels) }
    }
}
