package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNull
import kotlin.test.assertSame
import kotlin.test.assertTrue

class TypedTaskIdTest {
    @Test
    fun taskIdRejectsBlankAndNeedsExplicitBoundaryConversion() {
        assertFailsWith<IllegalArgumentException> { TaskId(" ") }
        val taskId = TaskId("task-1")
        val boxedAsAny: Any = taskId
        assertTrue(boxedAsAny is TaskId)
        assertEquals(taskId, boxedAsAny)

        val store = InMemoryTaskStore.empty()
        assertEquals(SubmissionDecision.Accepted, submitTyped(store, taskId, "alpha").getOrThrow())
        assertEquals("alpha", store.find(taskId.value))
        assertEquals(SubmissionDecision.Reused, submitTyped(store, taskId, "alpha").getOrThrow())
    }

    @Test
    fun reifiedStateCheckDoesNotVerifyNestedListElements() {
        val failure = TaskState.Failed("disk")
        val states: List<TaskState> = listOf(TaskState.Queued, failure)
        assertSame(failure, firstStateOfType<TaskState.Failed>(states))
        assertNull(firstStateOfType<TaskState.Succeeded>(states))

        val wrongElements: Any = listOf(123)
        assertTrue(isElementType<List<String>>(wrongElements))
        assertEquals(false, (wrongElements as List<*>).all { it is String })
    }
}
