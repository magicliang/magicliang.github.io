package example.tasks

import java.util.concurrent.atomic.AtomicInteger
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest

class TaskConcurrentIndexTest {
    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun twoReadersOfSameOldValueLoseAnUpdateButMutexPreservesBoth() = runTest {
        val id = TaskId("task-29")
        val unsafeCounts = mutableMapOf<TaskId, Int>()
        val firstRead = CompletableDeferred<Int>()
        val secondRead = CompletableDeferred<Int>()
        val release = CompletableDeferred<Unit>()
        val first = async {
            val old = unsafeCounts.getOrDefault(id, 0)
            firstRead.complete(old)
            release.await()
            unsafeCounts[id] = old + 1
        }
        val second = async {
            val old = unsafeCounts.getOrDefault(id, 0)
            secondRead.complete(old)
            release.await()
            unsafeCounts[id] = old + 1
        }
        assertEquals(0, firstRead.await())
        assertEquals(0, secondRead.await())
        release.complete(Unit)
        first.await()
        second.await()
        assertEquals(1, unsafeCounts[id])

        val protected = TaskAttemptIndex()
        val protectedGate = CompletableDeferred<Unit>()
        val protectedFirst = async { protectedGate.await(); protected.record(id) }
        val protectedSecond = async { protectedGate.await(); protected.record(id) }
        runCurrent()
        assertFalse(protectedFirst.isCompleted)
        protectedGate.complete(Unit)
        assertEquals(setOf(1, 2), setOf(protectedFirst.await(), protectedSecond.await()))
        assertEquals(2, protected.count(id))
        println("VIRTUAL unsafe_read_0_twice=true unsafe_count=1 mutex_count=2")
    }

    @Test
    fun atomicCounterAloneCannotGuardBusinessStateAndCountTogether() = runTest {
        val id = TaskId("task-29-state")
        val unsafeState = mutableMapOf<TaskId, TaskState>(id to TaskState.Running)
        val atomicCounter = AtomicInteger()
        val firstSawRunning = CompletableDeferred<Boolean>()
        val secondSawRunning = CompletableDeferred<Boolean>()
        val release = CompletableDeferred<Unit>()
        val first = async {
            val allowed = unsafeState[id] == TaskState.Running
            firstSawRunning.complete(allowed)
            release.await()
            if (allowed) {
                atomicCounter.incrementAndGet()
                unsafeState[id] = TaskState.Succeeded("completed:${id.value}")
            }
            allowed
        }
        val second = async {
            val allowed = unsafeState[id] == TaskState.Running
            secondSawRunning.complete(allowed)
            release.await()
            if (allowed) {
                atomicCounter.incrementAndGet()
                unsafeState[id] = TaskState.Succeeded("completed:${id.value}")
            }
            allowed
        }
        assertTrue(firstSawRunning.await())
        assertTrue(secondSawRunning.await())
        release.complete(Unit)
        assertTrue(first.await())
        assertTrue(second.await())
        assertEquals(2, atomicCounter.get())
        assertEquals(TaskState.Succeeded("completed:${id.value}"), unsafeState[id])

        val protected = TaskCompletionIndex()
        protected.start(id)
        val protectedGate = CompletableDeferred<Unit>()
        val protectedFirst = async { protectedGate.await(); protected.completeOnce(id) }
        val protectedSecond = async { protectedGate.await(); protected.completeOnce(id) }
        protectedGate.complete(Unit)
        assertEquals(setOf(true, false), setOf(protectedFirst.await(), protectedSecond.await()))
        assertEquals(TaskState.Succeeded("completed:${id.value}") to 1, protected.snapshot(id))
        println("VIRTUAL atomic_field_count=2 business_task_count=1 protected_accepts=1 protected_count=1")
    }
}
