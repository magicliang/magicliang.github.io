package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertSame

class TaskContractTest {
    @Test
    fun transitionMatrixDistinguishesAcceptedAndRejectedSignals() {
        data class Case(val state: TaskState, val signal: TaskSignal, val expected: TaskState?)

        val cases = listOf(
            Case(TaskState.Queued, TaskSignal.Start, TaskState.Running),
            Case(TaskState.Queued, TaskSignal.Cancel, TaskState.Cancelled),
            Case(TaskState.Running, TaskSignal.Success("done"), TaskState.Succeeded("done")),
            Case(TaskState.Running, TaskSignal.Failure("synthetic"), TaskState.Failed("synthetic")),
            Case(TaskState.Running, TaskSignal.Cancel, TaskState.Cancelled),
            Case(TaskState.Queued, TaskSignal.Success("too early"), null),
            Case(TaskState.Succeeded("done"), TaskSignal.Cancel, null),
            Case(TaskState.Failed("synthetic"), TaskSignal.Start, null),
            Case(TaskState.Cancelled, TaskSignal.Success("late"), null),
        )

        for (case in cases) {
            if (case.expected == null) {
                assertFailsWith<IllegalStateException>("${case.state} / ${case.signal}") {
                    advanceTask(case.state, case.signal)
                }
            } else {
                assertEquals(case.expected, advanceTask(case.state, case.signal), "${case.state} / ${case.signal}")
            }
        }
    }

    @Test
    fun rejectedDuplicateIsNotAThrownStoreFailure() {
        val store = InMemoryTaskStore.empty()
        assertEquals(SubmissionDecision.Accepted, submitValidated(store, "task-22", "alpha").getOrThrow())
        assertEquals(SubmissionDecision.Reused, submitValidated(store, "task-22", "alpha").getOrThrow())
        val rejected = submitValidated(store, "task-22", "other")
        assertEquals(SubmissionDecision.Rejected("Task ID already belongs to another text"), rejected.getOrThrow())
        assertEquals("alpha", store.find("task-22"))

        val outage = IllegalStateException("synthetic outage")
        val unavailable = object : TaskStore {
            override fun put(id: String, text: String): Unit = throw outage
            override fun find(id: String): String? = throw outage
        }
        assertSame(outage, submitValidated(unavailable, "task-22", "alpha").exceptionOrNull())
    }
}
