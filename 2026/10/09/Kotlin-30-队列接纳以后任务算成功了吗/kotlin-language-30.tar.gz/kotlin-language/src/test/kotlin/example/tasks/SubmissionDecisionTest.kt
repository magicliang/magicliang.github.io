package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNull
import kotlin.test.assertSame

private class UnavailableTaskStore(val outage: IllegalStateException) : TaskStore {
    override fun put(id: String, text: String): Unit = throw outage

    override fun find(id: String): String? = throw outage
}

class SubmissionDecisionTest {
    @Test
    fun inputRejectionAndTaskFailureHaveDifferentMeaning() {
        val store = InMemoryTaskStore.empty()
        assertEquals(
            SubmissionDecision.Rejected("Task ID and text must not be blank"),
            submitValidated(store, " ", "alpha").getOrThrow(),
        )
        assertNull(store.find(" "))
        assertEquals(SubmissionDecision.Accepted, submitValidated(store, "task-1", "alpha").getOrThrow())
        assertEquals(SubmissionDecision.Reused, submitValidated(store, "task-1", "alpha").getOrThrow())
        assertEquals(
            SubmissionDecision.Rejected("Task ID already belongs to another text"),
            submitValidated(store, "task-1", "other").getOrThrow(),
        )
        assertEquals("alpha", store.find("task-1"))

        val failedTask = advanceTask(TaskState.Running, TaskSignal.Failure("worker rejected task"))
        assertEquals(TaskState.Failed("worker rejected task"), failedTask)
        assertEquals(TaskStage.TERMINAL, taskStage(failedTask))
    }

    @Test
    fun injectedStoreFailureRetainsOriginalCauseInsteadOfBecomingNull() {
        val outage = IllegalStateException("synthetic store unavailable")
        val result = submitValidated(UnavailableTaskStore(outage), "task-1", "alpha")
        assertSame(outage, result.exceptionOrNull())
        val thrown = assertFailsWith<IllegalStateException> { result.getOrThrow() }
        assertSame(outage, thrown)

        val competingStore = object : TaskStore {
            override fun put(id: String, text: String) = Unit

            private var reads = 0

            override fun find(id: String): String? = if (++reads == 1) null else "other"

            override fun putIfAbsent(id: String, text: String): Boolean = false
        }
        assertEquals(
            SubmissionDecision.Rejected("Task ID already belongs to another text"),
            submitValidated(competingStore, "task-1", "alpha").getOrThrow(),
        )
    }
}
