package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertSame

class TaskFormattingTest {
    @Test
    fun staticReceiverTypeSelectsExtensionWhileRealMemberWins() {
        val failed = TaskState.Failed("disk")
        val general: TaskState = failed
        assertEquals("failed:disk", failed.statusLabel())
        assertEquals("terminal", general.statusLabel())
        assertEquals("task-1:terminal", formatTaskState("task-1", failed))

        class Holder(val value: String) {
            fun label(): String = "member:$value"
        }
        fun Holder.label(): String = "extension:$value"
        assertEquals("member:x", Holder("x").label())
    }

    @Test
    fun scopeFunctionsKeepDifferentReceiverAndResultShapes() {
        val failed = TaskState.Failed("disk")
        val letResult = failed.let { state -> "let:${state.reason}" }
        val runResult = failed.run { "run:$reason" }
        val sideEffects = mutableListOf<String>()
        val applyResult = failed.apply { sideEffects.add("apply:$reason") }
        val alsoResult = failed.also { state -> sideEffects.add("also:${state.reason}") }

        assertEquals("let:disk", letResult)
        assertEquals("run:disk", runResult)
        assertSame(failed, applyResult)
        assertSame(failed, alsoResult)
        assertEquals(listOf("apply:disk", "also:disk"), sideEffects)
    }
}
