package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class JavaInputBoundaryTest {
    @Test
    fun validatesJavaTextAndElementsBeforeBuildingDraft() {
        val store = InMemoryTaskStore.empty()
        assertEquals(
            SubmissionDecision.Rejected("Java task text is null"),
            submitJavaInput(store, absent = true, nullLabel = false).getOrThrow(),
        )
        assertEquals(
            SubmissionDecision.Rejected("Java task labels contain null"),
            submitJavaInput(store, absent = false, nullLabel = true).getOrThrow(),
        )
        assertEquals(SubmissionDecision.Accepted, submitJavaInput(store, false, false).getOrThrow())
        assertEquals("index", store.find("java-task"))
    }

    @Test
    fun unsafePlatformUsageThrowsButJavaSamCallbackIsSynchronous() {
        assertFailsWith<NullPointerException> { JavaInputPort.taskText(true).length }
        val trustedLabels: List<String> = JavaInputPort.labels(true)
        assertFailsWith<NullPointerException> { trustedLabels[1].length }

        val events = mutableListOf<String>()
        JavaInputPort.dispatch("index") { text -> events.add("called:$text") }
        assertEquals(listOf("called:index"), events)
    }
}
