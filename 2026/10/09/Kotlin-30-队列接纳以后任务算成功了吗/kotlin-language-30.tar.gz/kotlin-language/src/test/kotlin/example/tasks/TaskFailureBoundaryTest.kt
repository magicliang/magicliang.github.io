package example.tasks

import java.util.concurrent.CancellationException
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.withTimeout

class TaskFailureBoundaryTest {
    @Test
    fun ordinaryScopePropagatesLaunchFailureAndCleansSibling() = runBlocking {
        val siblingStarted = CompletableDeferred<Unit>()
        val siblingCleaned = CompletableDeferred<Unit>()
        val failure = IllegalStateException("injected task-28 failure")
        val observed = assertFailsWith<IllegalStateException> {
            coroutineScope {
                launch {
                    try {
                        siblingStarted.complete(Unit)
                        awaitCancellation()
                    } finally {
                        siblingCleaned.complete(Unit)
                    }
                }
                launch {
                    siblingStarted.await()
                    throw failure
                }
            }
        }
        assertEquals(failure.message, observed.message)
        assertTrue(siblingCleaned.isCompleted)
        println("TREE ordinary_launch_parent_failed=true sibling_cleaned=true")
    }

    @Test
    fun supervisedLaunchReportsFailureWithoutCancellingSibling() = runBlocking {
        val observed = CompletableDeferred<Throwable>()
        val handler = CoroutineExceptionHandler { _, failure -> observed.complete(failure) }
        val failure = IllegalStateException("injected task-28 failure")
        supervisorScope {
            val siblingStarted = CompletableDeferred<Unit>()
            val releaseSibling = CompletableDeferred<Unit>()
            val sibling = launch {
                siblingStarted.complete(Unit)
                releaseSibling.await()
            }
            siblingStarted.await()
            val failed = launch(handler) { throw failure }
            failed.join()
            assertTrue(failed.isCancelled)
            assertFalse(sibling.isCompleted)
            assertEquals(failure.message, withTimeout(5_000) { observed.await() }.message)
            releaseSibling.complete(Unit)
            sibling.join()
        }
        println("TREE supervised_launch_handler=true sibling_completed=true")
    }

    @Test
    fun supervisedAsyncDeliversFailureToAwaiter() = runBlocking {
        val failure = IllegalStateException("injected task-28 failure")
        supervisorScope {
            val siblingStarted = CompletableDeferred<Unit>()
            val releaseSibling = CompletableDeferred<Unit>()
            val sibling = async {
                siblingStarted.complete(Unit)
                releaseSibling.await()
                "survived"
            }
            siblingStarted.await()
            val failed = async { throw failure }
            assertEquals(failure.message, assertFailsWith<IllegalStateException> { failed.await() }.message)
            assertFalse(sibling.isCompleted)
            releaseSibling.complete(Unit)
            assertEquals("survived", sibling.await())
        }
        println("TREE supervised_async_awaiter_failed=true sibling_completed=true")
    }

    @Test
    fun cancellationMustNotBeReducedToOrdinaryResultFailure() = runBlocking {
        val cancellation = CancellationException("task-28 cancelled")
        val swallowed = runCatching<TaskState> { throw cancellation }
        assertTrue(swallowed.isFailure)
        assertEquals(TaskState.Succeeded("incorrect-default"), swallowed.getOrDefault(TaskState.Succeeded("incorrect-default")))
        val observed = assertFailsWith<CancellationException> {
            captureTaskFailure(TaskId("task-28")) { throw cancellation }
        }
        assertEquals(cancellation.message, observed.message)
        val failure = IllegalStateException("task-28 broken")
        val failureResult = captureTaskFailure(TaskId("task-28")) { throw failure }
        assertEquals(failure.message, failureResult.exceptionOrNull()?.message)
        println("RESULT cancellation_rethrown=true ordinary_failure_captured=true")
    }
}
