package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.runTest

class ManagedTaskServiceTest {
    @Test
    fun parentWaitsForChildBeforeDeliveringBusinessSuccess() = runTest {
        val childStarted = CompletableDeferred<Unit>()
        val releaseChild = CompletableDeferred<Unit>()
        val result = async {
            executeManagedTask(TaskId("task-25")) {
                launch {
                    childStarted.complete(Unit)
                    releaseChild.await()
                }
            }
        }
        childStarted.await()
        assertFalse(result.isCompleted)
        releaseChild.complete(Unit)
        assertEquals(TaskState.Succeeded("completed:task-25"), result.await())
        println("TREE child_started=true parent_before_gate=false parent_after_gate=${result.isCompleted}")
    }

    @Test
    fun childFailureCancelsSiblingInSameTaskTree() = runTest {
        val siblingStarted = CompletableDeferred<Unit>()
        val siblingCleaned = CompletableDeferred<Unit>()
        val failure = IllegalStateException("injected child failure")
        supervisorScope {
            val result = async {
                executeManagedTask(TaskId("task-25-fail")) {
                    launch {
                        try {
                            siblingStarted.complete(Unit)
                            awaitCancellation()
                        } finally {
                            siblingCleaned.complete(Unit)
                        }
                    }
                    launch {
                        siblingStarted.await()
                        throw failure
                    }
                }
            }
            val observed = assertFailsWith<IllegalStateException> { result.await() }
            assertEquals(failure.message, observed.message)
            assertTrue(observed === failure || observed.cause === failure)
            assertTrue(siblingCleaned.isCompleted)
        }
        println("TREE child_failure_chain_contains_original=true sibling_cleanup=true")
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun ownerStopsAndJoinsWaitingTasks() = runTest {
        val service = ManagedTaskService(StandardTestDispatcher(testScheduler))
        val childStarted = CompletableDeferred<Unit>()
        val childCleaned = CompletableDeferred<Unit>()
        val result = service.start(TaskId("task-25-stop")) {
            launch {
                try {
                    childStarted.complete(Unit)
                    awaitCancellation()
                } finally {
                    childCleaned.complete(Unit)
                }
            }
        }
        childStarted.await()
        assertFalse(result.isCompleted)
        service.stop()
        assertTrue(result.isCancelled)
        assertTrue(childCleaned.isCompleted)
        assertFailsWith<IllegalStateException> { service.start(TaskId("too-late")) {} }
        println("TREE owner_stop_joined=true task_cancelled=true child_cleaned=true new_start_rejected=true")
    }
}
