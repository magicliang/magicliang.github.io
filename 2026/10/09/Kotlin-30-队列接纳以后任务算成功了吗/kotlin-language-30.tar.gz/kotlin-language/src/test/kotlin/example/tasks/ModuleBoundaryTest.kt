package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class ModuleBoundaryTest {
    @Test
    fun applicationCallsDomainTransition() {
        val running = advanceTask(TaskState.Queued, TaskSignal.Start)
        assertEquals(TaskState.Running, running)
        assertEquals(TaskStage.ACTIVE, taskStage(running))
    }

    @Test
    fun applicationCallsDomainStoreWithoutChangingSubmissionContract() {
        val store = InMemoryTaskStore.empty()
        assertTrue(acceptSubmission(store, "task-21", "draft"))
        assertFalse(acceptSubmission(store, "task-21", "draft"))
        assertEquals("draft", store.find("task-21"))
    }
}
