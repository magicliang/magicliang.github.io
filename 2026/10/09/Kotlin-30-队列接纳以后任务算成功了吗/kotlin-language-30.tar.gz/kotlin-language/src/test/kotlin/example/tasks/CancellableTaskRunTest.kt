package example.tasks

import java.util.concurrent.CancellationException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.coroutineContext
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.withTimeout

class CancellableTaskRunTest {
    @Test
    fun cooperativeLoopStopsAtNextCheckButUncheckedLoopKeepsWorking() = runBlocking {
        val executor = ThreadPoolExecutor(1, 1, 0, TimeUnit.MILLISECONDS, LinkedBlockingQueue()) { task ->
            Thread(task, "kotlin-27-loop")
        }
        val dispatcher = executor.asCoroutineDispatcher()
        val releaseCooperative = CountDownLatch(1)
        val releaseUnchecked = CountDownLatch(1)
        try {
            val cooperativeEntered = CountDownLatch(1)
            val cooperativeSteps = AtomicInteger()
            val cooperative = launch(dispatcher) {
                repeat(3) {
                    coroutineContext.ensureActive()
                    cooperativeEntered.countDown()
                    releaseCooperative.await()
                    cooperativeSteps.incrementAndGet()
                }
            }
            assertTrue(cooperativeEntered.await(5, TimeUnit.SECONDS))
            cooperative.cancel()
            releaseCooperative.countDown()
            cooperative.join()
            assertEquals(1, cooperativeSteps.get())

            val uncheckedEntered = CountDownLatch(1)
            val uncheckedSteps = AtomicInteger()
            val unchecked = launch(dispatcher) {
                repeat(3) {
                    uncheckedEntered.countDown()
                    releaseUnchecked.await()
                    uncheckedSteps.incrementAndGet()
                }
            }
            assertTrue(uncheckedEntered.await(5, TimeUnit.SECONDS))
            unchecked.cancel()
            releaseUnchecked.countDown()
            unchecked.join()
            assertEquals(3, uncheckedSteps.get())
            println("REAL cooperative_steps=${cooperativeSteps.get()} unchecked_steps=${uncheckedSteps.get()}")
        } finally {
            releaseCooperative.countDown()
            releaseUnchecked.countDown()
            dispatcher.close()
            assertTrue(executor.awaitTermination(5, TimeUnit.SECONDS))
        }
    }

    @Test
    fun completionAndCancellationOrderCloseTheirLeasesOnce() = runTest {
        val completedCloses = AtomicInteger()
        val completedEntered = CompletableDeferred<Unit>()
        val completeGate = CompletableDeferred<Unit>()
        val completed = async {
            executeWithLease(TaskId("task-27-win"), { AutoCloseable { completedCloses.incrementAndGet() } }, {
                completedEntered.complete(Unit)
                completeGate.await()
            })
        }
        completedEntered.await()
        assertFalse(completed.isCompleted)
        completeGate.complete(Unit)
        assertEquals(TaskState.Succeeded("completed:task-27-win"), completed.await())
        completed.cancel()
        assertFalse(completed.isCancelled)
        assertEquals(1, completedCloses.get())

        val cancelledCloses = AtomicInteger()
        val cancelledEntered = CompletableDeferred<Unit>()
        val cancelGate = CompletableDeferred<Unit>()
        val cancelled = async {
            executeWithLease(TaskId("task-27-lose"), { AutoCloseable { cancelledCloses.incrementAndGet() } }, {
                cancelledEntered.complete(Unit)
                cancelGate.await()
            })
        }
        cancelledEntered.await()
        cancelled.cancelAndJoin()
        assertFailsWith<CancellationException> { cancelled.await() }
        assertFalse(cancelGate.isCompleted)
        assertEquals(1, cancelledCloses.get())
        println("VIRTUAL complete_first_close=1 cancel_first_close=1 late_cancel_ignored=true")
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun virtualTimeoutRunsCleanupButDoesNotProveExternalIoStopped() = runTest {
        val closes = AtomicInteger()
        val cleanupCalls = AtomicInteger()
        assertFailsWith<TimeoutCancellationException> {
            withTimeout(100) {
                executeWithLease(TaskId("task-27-timeout"), { AutoCloseable { closes.incrementAndGet() } }, {
                    delay(1_000)
                }, {
                    delay(2)
                    cleanupCalls.incrementAndGet()
                })
            }
        }
        assertEquals(1, cleanupCalls.get())
        assertEquals(1, closes.get())
        assertTrue(testScheduler.currentTime >= 100)
        println("VIRTUAL timeout_time=${testScheduler.currentTime} cleanup=1 close=1")
    }

    @Test
    fun leaseDeliveredAfterCancellationIsReturnedToProducer() = runTest {
        val registered = CompletableDeferred<Unit>()
        val closes = AtomicInteger()
        var deliver: ((AutoCloseable) -> Unit)? = null
        val cancelled = async {
            executeWithLease(TaskId("task-27-lost"), {
                acquireCancellableLease { callback ->
                    deliver = callback
                    registered.complete(Unit)
                }
            }, {})
        }
        registered.await()
        cancelled.cancelAndJoin()
        deliver!!(AutoCloseable { closes.incrementAndGet() })
        assertEquals(1, closes.get())
        println("VIRTUAL cancelled_before_lease_delivery=true lost_lease_close=1")
    }
}
