package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class CommandParserTest {
    @Test
    fun parsesExpressionsAndCountsOnlyValidatedInputs() {
        assertEquals("TASK input accepted (not persisted): alpha", parseCommand(arrayOf("submit", "alpha")))
        assertEquals("Usage: submit <task text>", parseCommand(arrayOf("help")))
        assertEquals("TASK inputs accepted (not persisted): 2", parseCommand(arrayOf("batch", "alpha", "beta")))
        assertEquals("Usage: batch <task text>...", assertFailsWith<IllegalArgumentException> {
            parseCommand(arrayOf("batch", "alpha", ""))
        }.message)
        assertFailsWith<IllegalArgumentException> { parseCommand(arrayOf("batch")) }
        assertFailsWith<IllegalArgumentException> { parseCommand(arrayOf("unknown")) }
    }

    @Test
    fun readsUnstablePropertyOncePerCheck() {
        var reads = 0
        val source = TaskTextSource {
            reads++
            if (reads == 1) "payload" else null
        }

        assertEquals(7, textLength(source))
        assertEquals(1, reads)
        assertEquals(0, textLength(source))
        assertEquals(2, reads)
    }
}
