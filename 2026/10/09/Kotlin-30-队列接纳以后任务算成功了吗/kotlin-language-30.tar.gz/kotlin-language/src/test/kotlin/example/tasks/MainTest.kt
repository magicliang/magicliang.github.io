package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class MainTest {
    @Test
    fun acceptsSyntheticTask() {
        assertEquals("nightly-index", submitTask(arrayOf("submit", "nightly-index")))
        assertEquals("检索任务", submitTask(arrayOf("submit", "检索任务")))
    }

    @Test
    fun rejectsMissingAndBlankInput() {
        assertEquals(
            "Usage: submit <task text>",
            assertFailsWith<IllegalArgumentException> { submitTask(arrayOf("submit")) }.message,
        )
        assertFailsWith<IllegalArgumentException> { submitTask(arrayOf("submit", "")) }
        assertFailsWith<IllegalArgumentException> { submitTask(arrayOf("unknown", "task")) }
    }
}
