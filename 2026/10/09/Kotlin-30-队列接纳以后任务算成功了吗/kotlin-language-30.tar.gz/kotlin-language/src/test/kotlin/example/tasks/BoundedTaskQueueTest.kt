package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest

class BoundedTaskQueueTest {
    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun boundedSendWaitsForSpaceAndCancelledSenderDoesNotInsert() = runTest {
        val queue = BoundedTaskQueue(1)
        queue.enqueue(TaskId("task-30-first"))
        val nextSender = async { queue.enqueue(TaskId("task-30-second")) }
        runCurrent()
        assertFalse(nextSender.isCompleted)

        val entered = CompletableDeferred<Unit>()
        val release = CompletableDeferred<Unit>()
        val processing = async {
            queue.consumeOne { id ->
                entered.complete(Unit)
                release.await()
                executeManagedTask(id) {}
            }
        }
        entered.await()
        nextSender.await()
        assertFalse(processing.isCompleted)
        release.complete(Unit)
        assertEquals(TaskState.Succeeded("completed:task-30-first"), processing.await())
        queue.close()
        assertEquals(TaskState.Succeeded("completed:task-30-second"), queue.consumeOne { id -> executeManagedTask(id) {} })
        assertNull(queue.consumeOne { id -> executeManagedTask(id) {} })

        val cancelledQueue = BoundedTaskQueue(1)
        cancelledQueue.enqueue(TaskId("task-30-kept"))
        val cancelledSender = async { cancelledQueue.enqueue(TaskId("task-30-cancelled")) }
        runCurrent()
        assertFalse(cancelledSender.isCompleted)
        cancelledSender.cancelAndJoin()
        cancelledQueue.close()
        assertEquals(TaskState.Succeeded("completed:task-30-kept"), cancelledQueue.consumeOne { id -> executeManagedTask(id) {} })
        assertNull(cancelledQueue.consumeOne { id -> executeManagedTask(id) {} })
        println("CHANNEL full_pending=true slot_freed_send_done=true process_pending=true cancelled_sender_dropped=true")
    }

    @Test
    fun closeRejectsNewSendButDrainsAcceptedWork() = runTest {
        val queue = BoundedTaskQueue(1)
        assertTrue(queue.tryEnqueue(TaskId("task-30-drain")).isSuccess)
        queue.close()
        assertFalse(queue.tryEnqueue(TaskId("too-late")).isSuccess)
        assertEquals(TaskState.Succeeded("completed:task-30-drain"), queue.consumeOne { id -> executeManagedTask(id) {} })
        assertNull(queue.consumeOne { id -> executeManagedTask(id) {} })
        println("CHANNEL close_rejects_new=true accepted_item_drained=true terminal_receive_empty=true")
    }

    @Test
    fun consumerFailureDoesNotUndoSendAndCancelReportsUndeliveredItem() = runTest {
        val queue = BoundedTaskQueue(1)
        val failure = IllegalStateException("injected task-30 consumer failure")
        assertTrue(queue.tryEnqueue(TaskId("task-30-failed")).isSuccess)
        supervisorScope {
            val consumer = async { queue.consumeOne { throw failure } }
            assertEquals(failure.message, assertFailsWith<IllegalStateException> { consumer.await() }.message)
        }
        queue.close()
        assertNull(queue.consumeOne { id -> executeManagedTask(id) {} })

        val dropped = mutableListOf<TaskId>()
        val abortedQueue = BoundedTaskQueue(1) { dropped += it }
        abortedQueue.enqueue(TaskId("task-30-undelivered"))
        abortedQueue.cancel()
        assertEquals(listOf(TaskId("task-30-undelivered")), dropped)
        println("CHANNEL send_accepted_consumer_failed=true cancel_undelivered=1")
    }
}
