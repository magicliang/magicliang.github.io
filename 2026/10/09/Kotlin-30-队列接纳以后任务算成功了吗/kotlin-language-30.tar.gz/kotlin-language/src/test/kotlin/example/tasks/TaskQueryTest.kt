package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertSame

class TaskQueryTest {
    @Test
    fun readOnlyInterfacesStillObserveMutableAliases() {
        val labels = mutableListOf("queued", "urgent")
        val view: List<String> = taskLabelsView(labels)
        val snapshot: List<String> = taskLabelsSnapshot(labels)
        assertSame(labels, view)
        labels.add("running")
        assertEquals(listOf("queued", "urgent", "running"), view)
        assertEquals(listOf("queued", "urgent"), snapshot)

        val ids = mutableSetOf("task-1")
        val readOnlyIds: Set<String> = ids
        val idsSnapshot = ids.toSet()
        ids.add("task-2")
        assertEquals(setOf("task-1", "task-2"), readOnlyIds)
        assertEquals(setOf("task-1"), idsSnapshot)

        val statuses = mutableMapOf("task-1" to "queued")
        val readOnlyStatuses: Map<String, String> = statuses
        val statusSnapshot = statuses.toMap()
        statuses["task-1"] = "running"
        assertEquals("running", readOnlyStatuses["task-1"])
        assertEquals("queued", statusSnapshot["task-1"])
    }

    @Test
    fun copyingACollectionDoesNotCopyMutableElements() {
        val note = StringBuilder("queued")
        val original = mutableListOf(note, StringBuilder("urgent"))
        val snapshot = original.toList()
        original.removeAt(1)
        note.append("!")
        assertEquals(1, original.size)
        assertEquals(2, snapshot.size)
        assertSame(note, snapshot[0])
        assertEquals("queued!", snapshot[0].toString())
    }
}
