package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class TaskDraftTest {
    @Test
    fun nestedReceiverNeedsExplicitParentButMatchesOrdinaryFunction() {
        val draft = taskDraft {
            id = TaskId("task-1")
            text = "initial"
            label {
                value = " urgent "
                this@taskDraft.text = " alpha "
            }
        }
        val ordinary = makeTaskDraft(TaskId("task-1"), " alpha ", listOf(" urgent "))
        assertEquals(ordinary, draft)
        assertEquals("alpha", draft.text)
        assertEquals(listOf("urgent"), draft.labels)
    }

    @Test
    fun bothFormsRejectMissingOrBlankDataBeforeSubmission() {
        assertFailsWith<IllegalArgumentException> { taskDraft { text = "alpha" } }
        assertFailsWith<IllegalArgumentException> {
            taskDraft { id = TaskId("task-1"); text = " "; label { value = "urgent" } }
        }
        assertFailsWith<IllegalArgumentException> {
            taskDraft { id = TaskId("task-1"); text = "alpha"; label { value = " " } }
        }
        assertFailsWith<IllegalArgumentException> { makeTaskDraft(TaskId("task-1"), "alpha", listOf(" ")) }
    }
}
