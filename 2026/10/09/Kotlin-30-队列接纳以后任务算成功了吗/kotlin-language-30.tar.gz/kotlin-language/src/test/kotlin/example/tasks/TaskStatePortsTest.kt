package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertSame

class TaskStatePortsTest {
    @Test
    fun sourceWidensAndSinkNarrowsWithoutExposingWrongDirection() {
        val failure = TaskState.Failed("disk")
        val concreteSource: TaskStateSource<TaskState.Failed> = FixedTaskStateSource(failure)
        val broadSource: TaskStateSource<TaskState> = concreteSource
        assertSame(failure, broadSource.current())

        val recorded = RecordedTaskStateSink()
        val failureSink: TaskStateSink<TaskState.Failed> = recorded
        failureSink.accept(failure)
        assertEquals(listOf(failure), recorded.snapshot())
    }

    @Test
    fun starProjectedRowsNeedEachNestedValueChecked() {
        val failure = TaskState.Failed("disk")
        val unknown: List<*> = listOf(listOf(TaskState.Queued, failure))
        assertEquals(listOf(listOf(TaskState.Queued, failure)), verifyStateRows(unknown))
        assertFailsWith<IllegalArgumentException> { verifyStateRows(listOf(listOf("not a state"))) }
        assertFailsWith<IllegalArgumentException> { verifyStateRows(listOf("not a row")) }
        assertFailsWith<IllegalArgumentException> { verifyStateRows(listOf(listOf(null))) }
    }
}
