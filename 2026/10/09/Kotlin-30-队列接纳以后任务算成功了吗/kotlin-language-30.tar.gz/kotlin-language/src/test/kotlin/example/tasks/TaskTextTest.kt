package example.tasks

import java.lang.Character
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class TaskTextTest {
    @Test
    fun distinguishesUtf16CodePointsAndEncodedBytes() {
        assertEquals("utf16=1; codePoints=1; utf8=3", inputMetrics("中"))
        assertEquals("utf16=2; codePoints=1; utf8=4", inputMetrics("🙂"))
        assertEquals("utf16=2; codePoints=2; utf8=3", inputMetrics("e\u0301"))
        assertTrue(Character.isHighSurrogate("🙂"[0]))
        assertTrue(Character.isLowSurrogate("🙂"[1]))
        assertEquals(0x1F642, "🙂".codePointAt(0))
    }

    @Test
    fun distinguishesWholeMatchFromSubstringSearch() {
        assertTrue(validTaskId("a_3"))
        assertFalse(validTaskId("id:a_3"))
        assertTrue(containsTaskId("id:a_3"))
        assertFalse(validTaskId("任务"))
        assertFalse(validTaskId("a!"))
        assertFalse(validTaskId(""))
    }
}
