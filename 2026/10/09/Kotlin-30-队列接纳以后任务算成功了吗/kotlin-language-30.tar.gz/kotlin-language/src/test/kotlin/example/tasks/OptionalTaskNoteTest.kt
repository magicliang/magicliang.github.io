package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class OptionalTaskNoteTest {
    @Test
    fun distinguishesAbsentNullEmptyAndPresentFields() {
        assertEquals("missing", noteStatus(emptyMap()))
        assertEquals("explicit-null", noteStatus(mapOf("note" to null)))
        assertEquals("empty", noteStatus(mapOf("note" to "")))
        assertEquals("value:hello", noteStatus(mapOf("note" to "hello")))
        assertEquals("value: ", noteStatus(mapOf("note" to " ")))
        assertEquals(0, noteDisplayLength(null))
        assertEquals(0, noteDisplayLength(""))
        assertEquals(5, noteDisplayLength("hello"))
    }

    @Test
    fun showsUnsafeAssertionAndPrematureInitializationFailures() {
        assertEquals(5, unsafeNoteLength("hello"))
        assertFailsWith<NullPointerException> { unsafeNoteLength(null) }

        class LateNote {
            lateinit var value: String
        }

        val lateNote = LateNote()
        assertFailsWith<UninitializedPropertyAccessException> { lateNote.value }
        lateNote.value = "ready"
        assertEquals("ready", lateNote.value)
    }
}
