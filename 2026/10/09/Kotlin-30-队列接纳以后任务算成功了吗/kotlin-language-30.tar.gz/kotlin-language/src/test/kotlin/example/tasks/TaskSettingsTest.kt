package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertSame

class TaskSettingsTest {
    @Test
    fun readOnlyReferenceStillPointsToMutableLabels() {
        val settings = TaskSettings("synthetic")
        val firstReference = settings.labels

        settings.labels.add("manual")
        assertSame(firstReference, settings.labels)
        assertEquals(listOf("synthetic", "manual"), firstReference)

        var selected = settings
        selected = TaskSettings("another")
        assertEquals(listOf("another"), selected.labels)
        assertEquals(listOf("synthetic", "manual"), firstReference)
    }

    @Test
    fun widensBeforeAddingAndRejectsInvalidRetryLimit() {
        val settings = TaskSettings("synthetic")
        settings.retryLimit = Int.MAX_VALUE

        assertEquals(2_147_483_648L, settings.maxAttempts())
        assertEquals(Int.MIN_VALUE, settings.retryLimit + 1)
        assertFailsWith<ArithmeticException> { Math.addExact(settings.retryLimit, 1) }

        settings.retryLimit = -1
        assertEquals(
            "retryLimit must be non-negative",
            assertFailsWith<IllegalArgumentException> { settings.maxAttempts() }.message,
        )
    }
}
