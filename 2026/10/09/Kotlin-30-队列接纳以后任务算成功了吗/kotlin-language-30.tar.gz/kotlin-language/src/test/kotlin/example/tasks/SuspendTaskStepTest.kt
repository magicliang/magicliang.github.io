package example.tasks

import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.Continuation
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest

class SuspendTaskStepTest {
    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun immediateSuspendAndDelayedStepHaveDifferentVirtualTimelines() = runTest {
        val immediate = executeSyntheticTask(TaskId("task-24")) {}
        assertEquals(TaskState.Succeeded("completed:task-24"), immediate)
        assertEquals(0, testScheduler.currentTime)

        val delayed = async {
            executeSyntheticTask(TaskId("task-24")) { delay(1_000) }
        }
        runCurrent()
        assertFalse(delayed.isCompleted)
        advanceTimeBy(999)
        runCurrent()
        assertFalse(delayed.isCompleted)
        advanceTimeBy(1)
        runCurrent()
        assertEquals(TaskState.Succeeded("completed:task-24"), delayed.await())
        assertEquals(1_000, testScheduler.currentTime)
        println("VIRTUAL immediate_time=0 delay_completion_time=${testScheduler.currentTime}")
    }

    @Test
    fun actualSuspensionFreesSingleWorkerButBlockingInSuspendOccupiesIt() = runBlocking {
        val executor = ThreadPoolExecutor(1, 1, 0, TimeUnit.MILLISECONDS, LinkedBlockingQueue()) { task ->
            Thread(task, "kotlin-24-worker")
        }
        val dispatcher = executor.asCoroutineDispatcher()
        val suspendedEntry = CountDownLatch(1)
        val continuation = AtomicReference<Continuation<Unit>?>()
        val blockingEntry = CountDownLatch(1)
        val blockingGate = CountDownLatch(1)
        try {
            val suspended = launch(dispatcher) {
                val result = executeSyntheticTask(TaskId("suspended")) {
                    suspendCoroutine<Unit> { resumePoint ->
                        continuation.set(resumePoint)
                        suspendedEntry.countDown()
                    }
                }
                assertEquals(TaskState.Succeeded("completed:suspended"), result)
            }
            assertTrue(suspendedEntry.await(5, TimeUnit.SECONDS))
            val freeWorkerProbe = executor.submit<String> { Thread.currentThread().name }
            assertEquals("kotlin-24-worker", freeWorkerProbe.get(5, TimeUnit.SECONDS))
            continuation.getAndSet(null)!!.resume(Unit)
            suspended.join()

            val blocked = launch(dispatcher) {
                val result = executeSyntheticTask(TaskId("blocked")) {
                    blockingEntry.countDown()
                    blockingGate.await()
                }
                assertEquals(TaskState.Succeeded("completed:blocked"), result)
            }
            assertTrue(blockingEntry.await(5, TimeUnit.SECONDS))
            val queuedProbe = executor.submit<String> { Thread.currentThread().name }
            assertFalse(queuedProbe.isDone)
            assertEquals(1, executor.queue.size)
            println("REAL suspended_worker_probe=${freeWorkerProbe.get()} blocked_queue_size=${executor.queue.size}")
            blockingGate.countDown()
            assertEquals("kotlin-24-worker", queuedProbe.get(5, TimeUnit.SECONDS))
            blocked.join()
        } finally {
            blockingGate.countDown()
            continuation.getAndSet(null)?.resume(Unit)
            dispatcher.close()
            assertTrue(executor.awaitTermination(5, TimeUnit.SECONDS))
        }
    }
}
