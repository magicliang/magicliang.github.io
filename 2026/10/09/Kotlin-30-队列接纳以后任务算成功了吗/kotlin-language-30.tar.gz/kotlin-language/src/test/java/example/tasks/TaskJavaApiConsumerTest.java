package example.tasks;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.util.Arrays;
import org.junit.jupiter.api.Test;

public final class TaskJavaApiConsumerTest {
    @Test
    public void defaultOverloadIsOnlyAvailableWithExplicitJvmOverloads() {
        assertEquals("task-1:draft", TaskJavaApi.describe("task-1"));
        assertEquals("task-1:running", TaskJavaApi.describe("task-1", "running"));
        assertEquals("task-1:running", TaskJavaApi.describeWithoutOverloads("task-1", "running"));
        assertThrows(NullPointerException.class, () -> TaskJavaApi.describe(null));
        assertEquals("tasks", TaskJavaApi.getCategory());
        assertTrue(Arrays.stream(TaskJavaApi.class.getDeclaredMethods())
                .anyMatch(method -> method.getName().startsWith("implementationMarker")));

        TaskJavaObserver observer = new TaskJavaObserver() {};
        assertEquals("observed:task-1", observer.describe("task-1"));
    }

    @Test
    public void declaredCheckedExceptionCanBeCaughtByJavaCaller() {
        try {
            TaskJavaApi.readTask("task-1");
            throw new AssertionError("Expected IOException");
        } catch (IOException failure) {
            assertTrue(failure.getMessage().contains("synthetic task read failed: task-1"));
        }
    }
}
