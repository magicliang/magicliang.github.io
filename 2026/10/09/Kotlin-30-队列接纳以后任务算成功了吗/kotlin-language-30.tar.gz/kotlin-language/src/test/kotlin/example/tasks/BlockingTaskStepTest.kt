package example.tasks

import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import kotlinx.coroutines.asContextElement
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext

class BlockingTaskStepTest {
    @Test
    fun dedicatedBlockingWorkerLeavesCallerWorkerAvailable() = runBlocking {
        val callerExecutor = worker("kotlin-26-caller")
        val ioExecutor = worker("kotlin-26-blocking")
        val callerDispatcher = callerExecutor.asCoroutineDispatcher()
        val ioDispatcher = ioExecutor.asCoroutineDispatcher()
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        try {
            val result = async(callerDispatcher) {
                executeBlockingTask(TaskId("task-26"), ioDispatcher) {
                    assertTrue(Thread.currentThread().name.startsWith("kotlin-26-blocking"))
                    entered.countDown()
                    release.await()
                }
            }
            assertTrue(entered.await(5, TimeUnit.SECONDS))
            val callerProbe = callerExecutor.submit<String> { Thread.currentThread().name }
            assertEquals("kotlin-26-caller", callerProbe.get(5, TimeUnit.SECONDS))
            val blockedProbe = ioExecutor.submit<String> { Thread.currentThread().name }
            assertFalse(blockedProbe.isDone)
            assertEquals(1, ioExecutor.queue.size)
            println("REAL caller_probe=${callerProbe.get()} io_queued=${ioExecutor.queue.size}")
            release.countDown()
            assertEquals("kotlin-26-blocking", blockedProbe.get(5, TimeUnit.SECONDS))
            assertEquals(TaskState.Succeeded("completed:task-26"), result.await())
        } finally {
            release.countDown()
            callerDispatcher.close()
            ioDispatcher.close()
            assertTrue(callerExecutor.awaitTermination(5, TimeUnit.SECONDS))
            assertTrue(ioExecutor.awaitTermination(5, TimeUnit.SECONDS))
        }
    }

    @Test
    fun threadLocalNeedsExplicitContextElementAndRestoresWorkerValue() = runBlocking {
        val ioExecutor = worker("kotlin-26-context")
        val ioDispatcher = ioExecutor.asCoroutineDispatcher()
        val requestId = ThreadLocal<String>()
        requestId.set("request-26")
        try {
            val before = withContext(ioDispatcher) { requestId.get() }
            val during = withContext(ioDispatcher + requestId.asContextElement("request-26")) {
                requestId.get()
            }
            val after = withContext(ioDispatcher) { requestId.get() }
            assertEquals(null, before)
            assertEquals("request-26", during)
            assertEquals(null, after)
            assertEquals("request-26", requestId.get())
            println("CONTEXT worker_before=$before propagated=$during worker_after=$after")
        } finally {
            requestId.remove()
            ioDispatcher.close()
            assertTrue(ioExecutor.awaitTermination(5, TimeUnit.SECONDS))
        }
    }

    @Test
    fun cancellationDoesNotAutomaticallyReleaseBlockedThread() = runBlocking {
        val ioExecutor = worker("kotlin-26-cancel")
        val ioDispatcher = ioExecutor.asCoroutineDispatcher()
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val exited = CountDownLatch(1)
        try {
            val task = async(Dispatchers.Default) {
                executeBlockingTask(TaskId("task-26-cancel"), ioDispatcher) {
                    try {
                        entered.countDown()
                        release.await()
                    } finally {
                        exited.countDown()
                    }
                }
            }
            assertTrue(entered.await(5, TimeUnit.SECONDS))
            task.cancel()
            assertEquals(1L, exited.count)
            release.countDown()
            assertTrue(exited.await(5, TimeUnit.SECONDS))
            task.join()
            println("REAL cancelled_before_release=true blocked_exit_after_release=true")
        } finally {
            release.countDown()
            ioDispatcher.close()
            assertTrue(ioExecutor.awaitTermination(5, TimeUnit.SECONDS))
        }
    }

    private fun worker(name: String) = ThreadPoolExecutor(
        1, 1, 0, TimeUnit.MILLISECONDS, LinkedBlockingQueue(),
    ) { work -> Thread(work, name) }
}
