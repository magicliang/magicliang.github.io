package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotEquals
import kotlin.test.assertSame
import kotlin.test.assertTrue

class TaskRecordTest {
    @Test
    fun copySharesMutableLabelsButExcludesBodyProperty() {
        val original = TaskRecord("task-1", mutableListOf("queued"))
        original.reviewed = true
        val duplicate = original.copy()
        assertTrue(original == duplicate)
        assertFalse(original === duplicate)
        assertSame(original.labels, duplicate.labels)
        assertFalse(duplicate.reviewed)
        val (id, labels) = duplicate
        assertEquals("task-1", id)
        assertSame(original.labels, labels)

        original.labels.add("urgent")
        assertEquals(listOf("queued", "urgent"), duplicate.labels)
        duplicate.labels.remove("queued")
        assertEquals(listOf("urgent"), original.labels)
    }

    @Test
    fun mutatingHashKeyBreaksLookupAndArrayUsesContentComparison() {
        val record = TaskRecord("task-2", mutableListOf("queued"))
        val records = hashSetOf(record)
        val initialHash = record.hashCode()
        assertTrue(records.contains(record))
        record.labels.add("running")
        assertNotEquals(initialHash, record.hashCode())
        assertTrue(records.any { it === record })
        assertFalse(records.contains(record))

        val first = arrayOf("queued")
        val second = arrayOf("queued")
        assertFalse(first == second)
        assertTrue(first.contentEquals(second))
    }
}
