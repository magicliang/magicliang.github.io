package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class TaskLabelRulesTest {
    @Test
    fun capturedVariableIsReadWhenEagerPipelineExecutes() {
        var prefix = "u"
        var normalized = 0
        var accepted = 0
        val normalize: (String) -> String = { label ->
            normalized++
            label.lowercase()
        }
        val accept: (String) -> Boolean = { label ->
            accepted++
            label.startsWith(prefix)
        }
        prefix = "q"
        val labels = listOf("Queued", "Urgent")
        assertEquals(listOf("queued"), selectTaskLabels(labels, normalize, accept))
        assertEquals(2, normalized)
        assertEquals(2, accepted)
        prefix = "u"
        assertEquals(listOf("urgent"), selectTaskLabels(labels, normalize, accept))
        assertEquals(4, normalized)
        assertEquals(4, accepted)
    }

    @Test
    fun labelledReturnSkipsOnlyOneIterationWhileInlineReturnExitsFunction() {
        assertEquals(listOf("queued", "urgent"), nonBlankTaskLabels(listOf("queued", " ", "urgent")))
        val visited = mutableListOf<String>()
        val found = firstMatchingTaskLabel(listOf("queued", "urgent", "later")) { label ->
            visited.add(label)
            label == "urgent"
        }
        assertEquals("urgent", found)
        assertEquals(listOf("queued", "urgent"), visited)
        assertNull(firstMatchingTaskLabel(listOf("queued")) { it == "urgent" })
    }
}
