package example.tasks

fun eagerTaskLabels(labels: List<String>, record: (String) -> Unit): List<String> =
    labels.map { label ->
        record("map:$label")
        label.lowercase()
    }.filter { label ->
        record("filter:$label")
        label.startsWith("q")
    }.take(1)

fun lazyTaskLabels(labels: List<String>, record: (String) -> Unit): Sequence<String> =
    labels.asSequence().map { label ->
        record("map:$label")
        label.lowercase()
    }.filter { label ->
        record("filter:$label")
        label.startsWith("q")
    }.take(1)
