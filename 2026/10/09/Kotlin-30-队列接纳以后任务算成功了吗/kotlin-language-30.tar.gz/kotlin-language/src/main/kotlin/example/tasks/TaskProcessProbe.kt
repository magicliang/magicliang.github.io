package example.tasks

import java.io.IOException
import java.nio.file.Path
import java.util.concurrent.TimeUnit

data class TaskProcessProbe(val exitCode: Int, val output: String)

fun probeJdkProcess(valid: Boolean): TaskProcessProbe {
    val executable = Path.of(System.getProperty("java.home"), "bin", "java").toString()
    val argument = if (valid) "-version" else "--kotlin-task-invalid-switch"
    val process = ProcessBuilder(executable, argument).redirectErrorStream(true).start()
    try {
        process.outputStream.close()
        if (!process.waitFor(10, TimeUnit.SECONDS)) throw IOException("JDK probe did not exit before deadline")
        val output = process.inputStream.bufferedReader().use { it.readText() }
        return TaskProcessProbe(process.exitValue(), output)
    } finally {
        if (process.isAlive) {
            process.destroyForcibly()
            process.waitFor(10, TimeUnit.SECONDS)
        }
        process.inputStream.close()
        process.errorStream.close()
    }
}
