package example.tasks

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext

suspend fun executeBlockingTask(
    id: TaskId,
    ioDispatcher: CoroutineDispatcher,
    operation: () -> Unit,
): TaskState = executeManagedTask(id) {
    withContext(ioDispatcher) { operation() }
}
