package example.tasks

@Target(AnnotationTarget.CLASS)
@Retention(AnnotationRetention.RUNTIME)
annotation class TaskCategory(val name: String)

@Target(AnnotationTarget.CLASS)
@Retention(AnnotationRetention.SOURCE)
annotation class TaskDraftHint(val note: String)

fun taskCategoryOf(type: Class<*>): String? = type.getAnnotation(TaskCategory::class.java)?.name
