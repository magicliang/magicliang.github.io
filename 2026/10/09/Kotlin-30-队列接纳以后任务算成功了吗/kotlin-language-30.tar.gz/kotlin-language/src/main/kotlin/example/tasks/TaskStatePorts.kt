package example.tasks

interface TaskStateSource<out State : TaskState> {
    fun current(): State
}

class FixedTaskStateSource<out State : TaskState>(private val state: State) : TaskStateSource<State> {
    override fun current(): State = state
}

interface TaskStateSink<in State : TaskState> {
    fun accept(state: State)
}

class RecordedTaskStateSink : TaskStateSink<TaskState> {
    private val entries = mutableListOf<TaskState>()

    override fun accept(state: TaskState) {
        entries.add(state)
    }

    fun snapshot(): List<TaskState> = entries.toList()
}

fun verifyStateRows(rows: List<*>): List<List<TaskState>> = rows.map { row ->
    require(row is List<*>) { "Each row must be a list" }
    row.map { state ->
        require(state is TaskState) { "Each value must be a task state" }
        state
    }
}
