package example.tasks

fun submitJavaInput(store: TaskStore, absent: Boolean, nullLabel: Boolean): Result<SubmissionDecision> =
    runCatching {
        val text: String? = JavaInputPort.taskText(absent)
        if (text == null) return@runCatching SubmissionDecision.Rejected("Java task text is null")

        val inputLabels: List<String?>? = JavaInputPort.labels(nullLabel)
        if (inputLabels == null || inputLabels.any { it == null }) {
            return@runCatching SubmissionDecision.Rejected("Java task labels contain null")
        }

        val draft = makeTaskDraft(TaskId("java-task"), text, inputLabels.map { requireNotNull(it) })
        submitValidated(store, draft.id.value, draft.text).getOrThrow()
    }
