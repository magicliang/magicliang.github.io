package example.tasks

fun inputMetrics(text: String): String =
    "utf16=${text.length}; codePoints=${text.codePointCount(0, text.length)}; utf8=${text.toByteArray(Charsets.UTF_8).size}"

private val taskIdPattern = Regex("[a-z][a-z0-9_-]{0,11}")

fun validTaskId(text: String): Boolean = taskIdPattern.matches(text)

fun containsTaskId(text: String): Boolean = taskIdPattern.containsMatchIn(text)
