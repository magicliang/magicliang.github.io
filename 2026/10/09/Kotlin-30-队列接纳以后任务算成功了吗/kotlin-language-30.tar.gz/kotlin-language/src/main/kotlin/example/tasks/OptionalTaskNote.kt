package example.tasks

fun noteStatus(fields: Map<String, String?>): String {
    if (!fields.containsKey("note")) return "missing"
    val note: String? = fields["note"]
    return when {
        note == null -> "explicit-null"
        note.isEmpty() -> "empty"
        else -> "value:$note"
    }
}

fun noteDisplayLength(note: String?): Int = note?.length ?: 0

fun unsafeNoteLength(note: String?): Int = note!!.length
