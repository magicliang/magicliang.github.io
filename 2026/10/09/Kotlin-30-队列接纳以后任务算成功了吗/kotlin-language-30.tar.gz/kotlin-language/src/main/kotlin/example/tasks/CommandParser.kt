package example.tasks

fun parseCommand(args: Array<String>): String {
    return when (args.firstOrNull()) {
        "submit" -> "TASK input accepted (not persisted): ${submitTask(args)}"
        "help" -> {
            require(args.size == 1) { "Usage: help" }
            "Usage: submit <task text>"
        }
        "batch" -> {
            require(args.size > 1) { "Usage: batch <task text>..." }
            var accepted = 0
            for (task in args.drop(1)) {
                require(task.isNotBlank()) { "Usage: batch <task text>..." }
                accepted++
            }
            "TASK inputs accepted (not persisted): $accepted"
        }
        else -> throw IllegalArgumentException("Usage: submit <task text>")
    }
}

class TaskTextSource(private val read: () -> String?) {
    val text: String?
        get() = read()
}

fun textLength(source: TaskTextSource): Int {
    val captured = source.text
    return if (captured != null) captured.length else 0
}
