package example.tasks

import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

suspend fun acquireCancellableLease(register: ((AutoCloseable) -> Unit) -> Unit): AutoCloseable =
    suspendCancellableCoroutine { continuation ->
        register { lease ->
            continuation.resume(lease) { _, unclaimedLease, _ -> unclaimedLease.close() }
        }
    }

suspend fun executeWithLease(
    id: TaskId,
    acquire: suspend () -> AutoCloseable,
    step: suspend () -> Unit,
    cleanup: suspend () -> Unit = {},
): TaskState {
    val lease = acquire()
    try {
        return executeManagedTask(id) { step() }
    } finally {
        try {
            withContext(NonCancellable) { cleanup() }
        } finally {
            lease.close()
        }
    }
}
