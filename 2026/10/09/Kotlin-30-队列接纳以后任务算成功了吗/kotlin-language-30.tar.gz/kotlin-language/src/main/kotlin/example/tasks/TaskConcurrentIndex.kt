package example.tasks

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class TaskAttemptIndex {
    private val mutex = Mutex()
    private val attempts = mutableMapOf<TaskId, Int>()

    suspend fun record(id: TaskId): Int = mutex.withLock {
        val next = attempts.getOrDefault(id, 0) + 1
        attempts[id] = next
        next
    }

    suspend fun count(id: TaskId): Int = mutex.withLock { attempts.getOrDefault(id, 0) }
}

class TaskCompletionIndex {
    private val mutex = Mutex()
    private val states = mutableMapOf<TaskId, TaskState>()
    private val completed = mutableMapOf<TaskId, Int>()

    suspend fun start(id: TaskId) = mutex.withLock {
        check(id !in states) { "Task already started: ${id.value}" }
        states[id] = advanceTask(TaskState.Queued, TaskSignal.Start)
    }

    suspend fun completeOnce(id: TaskId): Boolean = mutex.withLock {
        val previous = states[id]
        if (previous != TaskState.Running) {
            false
        } else {
            states[id] = advanceTask(previous, TaskSignal.Success("completed:${id.value}"))
            completed[id] = completed.getOrDefault(id, 0) + 1
            true
        }
    }

    suspend fun snapshot(id: TaskId): Pair<TaskState?, Int> = mutex.withLock {
        states[id] to completed.getOrDefault(id, 0)
    }
}
