package example.tasks

import java.util.concurrent.CancellationException

suspend fun captureTaskFailure(id: TaskId, step: suspend () -> Unit): Result<TaskState> =
    try {
        Result.success(executeManagedTask(id) { step() })
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (failure: Exception) {
        Result.failure(failure)
    }
