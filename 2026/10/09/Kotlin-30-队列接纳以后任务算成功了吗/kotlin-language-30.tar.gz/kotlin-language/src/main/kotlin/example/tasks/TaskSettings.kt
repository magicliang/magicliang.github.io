package example.tasks

class TaskSettings(taskLabel: String) {
    val labels: MutableList<String> = mutableListOf(taskLabel)
    var retryLimit: Int = 0

    fun maxAttempts(): Long {
        require(retryLimit >= 0) { "retryLimit must be non-negative" }
        return retryLimit.toLong() + 1
    }
}
