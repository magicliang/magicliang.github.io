package example.tasks

import java.io.IOException

object TaskJavaApi {
    @get:JvmStatic
    val category: String = "tasks"

    internal fun implementationMarker(): String = "internal-only"

    @JvmStatic
    @JvmOverloads
    fun describe(id: String, label: String = "draft"): String = "${TaskId(id).value}:$label"

    @JvmStatic
    fun describeWithoutOverloads(id: String, label: String = "draft"): String = "${TaskId(id).value}:$label"

    @JvmStatic
    @Throws(IOException::class)
    fun readTask(id: String): String = throw IOException("synthetic task read failed: $id")
}
