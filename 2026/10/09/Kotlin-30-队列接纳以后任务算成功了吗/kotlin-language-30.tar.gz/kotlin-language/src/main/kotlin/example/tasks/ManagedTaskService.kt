package example.tasks

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.coroutineScope

suspend fun executeManagedTask(id: TaskId, step: suspend CoroutineScope.() -> Unit): TaskState {
    val running = advanceTask(TaskState.Queued, TaskSignal.Start)
    coroutineScope { step() }
    return advanceTask(running, TaskSignal.Success("completed:${id.value}"))
}

class ManagedTaskService(dispatcher: CoroutineDispatcher) {
    private val owner = SupervisorJob()
    private val scope = CoroutineScope(owner + dispatcher)

    fun start(id: TaskId, step: suspend CoroutineScope.() -> Unit): Deferred<TaskState> {
        check(owner.isActive) { "Task service has stopped" }
        return scope.async { executeManagedTask(id, step) }
    }

    suspend fun stop() {
        owner.cancelAndJoin()
    }
}
