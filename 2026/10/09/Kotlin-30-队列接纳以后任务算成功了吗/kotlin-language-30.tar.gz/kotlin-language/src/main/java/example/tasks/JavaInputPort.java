package example.tasks;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public final class JavaInputPort {
    private JavaInputPort() {
    }

    public static String taskText(boolean absent) {
        return absent ? null : "index";
    }

    public static List<String> labels(boolean includeNull) {
        return includeNull ? Arrays.asList("urgent", null) : Arrays.asList("urgent");
    }

    public static void dispatch(String text, Consumer<String> consumer) {
        consumer.accept(text);
    }
}
