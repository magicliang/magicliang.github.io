package example.tasks

@JvmInline
value class TaskId(val value: String) {
    init {
        require(value.isNotBlank()) { "Task ID must not be blank" }
    }
}

fun submitTyped(store: TaskStore, id: TaskId, text: String): Result<SubmissionDecision> =
    submitValidated(store, id.value, text)

inline fun <reified State : TaskState> firstStateOfType(states: List<TaskState>): State? =
    states.filterIsInstance<State>().firstOrNull()

inline fun <reified Element> isElementType(value: Any): Boolean = value is Element
