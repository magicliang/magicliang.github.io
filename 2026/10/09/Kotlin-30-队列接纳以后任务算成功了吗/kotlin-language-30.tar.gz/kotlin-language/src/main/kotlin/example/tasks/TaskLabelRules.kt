package example.tasks

fun selectTaskLabels(
    labels: List<String>,
    normalize: (String) -> String,
    accept: (String) -> Boolean,
): List<String> = labels.map(normalize).filter(accept)

fun nonBlankTaskLabels(labels: List<String>): List<String> {
    val retained = mutableListOf<String>()
    labels.forEach { label ->
        if (label.isBlank()) return@forEach
        retained.add(label)
    }
    return retained
}

fun firstMatchingTaskLabel(labels: List<String>, accept: (String) -> Boolean): String? {
    labels.forEach { label ->
        if (accept(label)) return label
    }
    return null
}
