package example.tasks

fun TaskState.statusLabel(): String = when (this) {
    TaskState.Queued -> "queued"
    TaskState.Running -> "running"
    is TaskState.Succeeded, is TaskState.Failed, TaskState.Cancelled -> "terminal"
}

fun TaskState.Failed.statusLabel(): String = "failed:$reason"

fun formatTaskState(taskId: String, state: TaskState): String =
    state.statusLabel().let { label -> "$taskId:$label" }
