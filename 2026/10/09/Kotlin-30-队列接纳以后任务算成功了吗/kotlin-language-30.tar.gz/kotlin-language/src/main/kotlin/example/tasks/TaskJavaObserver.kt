package example.tasks

interface TaskJavaObserver {
    fun describe(id: String): String = "observed:$id"
}
