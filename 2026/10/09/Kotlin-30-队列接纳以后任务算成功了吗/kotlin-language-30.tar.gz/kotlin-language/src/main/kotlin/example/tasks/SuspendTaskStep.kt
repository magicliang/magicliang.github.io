package example.tasks

suspend fun executeSyntheticTask(id: TaskId, step: suspend () -> Unit): TaskState {
    val running = advanceTask(TaskState.Queued, TaskSignal.Start)
    step()
    return advanceTask(running, TaskSignal.Success("completed:${id.value}"))
}
