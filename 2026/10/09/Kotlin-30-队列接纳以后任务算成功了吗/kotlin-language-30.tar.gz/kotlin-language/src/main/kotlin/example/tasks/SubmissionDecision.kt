package example.tasks

sealed interface SubmissionDecision {
    data object Accepted : SubmissionDecision
    data object Reused : SubmissionDecision
    data class Rejected(val reason: String) : SubmissionDecision
}

fun submitValidated(store: TaskStore, id: String, text: String): Result<SubmissionDecision> =
    runCatching {
        if (id.isBlank() || text.isBlank()) {
            return@runCatching SubmissionDecision.Rejected("Task ID and text must not be blank")
        }
        val existing = store.find(id)
        when {
            existing == text -> SubmissionDecision.Reused
            existing != null -> SubmissionDecision.Rejected("Task ID already belongs to another text")
            store.putIfAbsent(id, text) -> SubmissionDecision.Accepted
            store.find(id) == text -> SubmissionDecision.Reused
            else -> SubmissionDecision.Rejected("Task ID already belongs to another text")
        }
    }
