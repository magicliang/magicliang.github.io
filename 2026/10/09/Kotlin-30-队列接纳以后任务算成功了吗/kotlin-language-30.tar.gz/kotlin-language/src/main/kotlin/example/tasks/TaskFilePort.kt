package example.tasks

import java.io.Reader
import java.io.Writer
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption

data class TaskFileRow(val id: String, val text: String)

data class TaskFileImport(val rows: List<TaskFileRow>, val stoppedEarly: Boolean)

fun readTaskRows(reader: Reader): TaskFileImport = reader.buffered().use { lines ->
    val rows = mutableListOf<TaskFileRow>()
    var line = lines.readLine()
    while (line != null) {
        if (line == "#stop") return@use TaskFileImport(rows, true)
        val fields = line.split('\t', limit = 2)
        require(fields.size == 2 && fields[0].isNotBlank() && fields[1].isNotBlank() && '\t' !in fields[1]) {
            "Invalid task row"
        }
        rows.add(TaskFileRow(fields[0], fields[1]))
        line = lines.readLine()
    }
    TaskFileImport(rows, false)
}

fun importTaskFile(path: Path): TaskFileImport = readTaskRows(Files.newBufferedReader(path, StandardCharsets.UTF_8))

fun writeTaskRows(writer: Writer, rows: List<TaskFileRow>) {
    require(rows.all { it.id.isNotBlank() && it.text.isNotBlank() && "\t" !in it.id && "\t" !in it.text && "\n" !in it.id && "\n" !in it.text && "\r" !in it.id && "\r" !in it.text }) {
        "Invalid task row"
    }
    rows.forEach { writer.append(it.id).append('\t').append(it.text).append('\n') }
}

fun exportTaskFile(
    path: Path,
    rows: List<TaskFileRow>,
    writeStaged: (Writer, List<TaskFileRow>) -> Unit = ::writeTaskRows,
) {
    val target = path.toAbsolutePath()
    val staged = Files.createTempFile(target.parent, ".kotlin-task-", ".tmp")
    try {
        Files.newBufferedWriter(staged, StandardCharsets.UTF_8).use { writer -> writeStaged(writer, rows) }
        Files.move(staged, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
    } finally {
        Files.deleteIfExists(staged)
    }
}
