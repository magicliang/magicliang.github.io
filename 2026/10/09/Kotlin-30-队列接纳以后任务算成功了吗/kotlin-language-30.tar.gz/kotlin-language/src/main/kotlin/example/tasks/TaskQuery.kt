package example.tasks

fun taskLabelsView(backing: MutableList<String>): List<String> = backing

fun taskLabelsSnapshot(backing: List<String>): List<String> = backing.toList()
