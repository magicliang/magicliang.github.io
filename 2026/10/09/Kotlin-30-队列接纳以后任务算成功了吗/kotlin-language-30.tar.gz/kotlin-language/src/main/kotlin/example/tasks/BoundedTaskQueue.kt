package example.tasks

import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ChannelResult

class BoundedTaskQueue(capacity: Int, onUndelivered: (TaskId) -> Unit = {}) {
    init {
        require(capacity > 0)
    }

    private val channel = Channel<TaskId>(capacity, onUndeliveredElement = onUndelivered)

    suspend fun enqueue(id: TaskId) {
        channel.send(id)
    }

    fun tryEnqueue(id: TaskId): ChannelResult<Unit> = channel.trySend(id)

    suspend fun consumeOne(process: suspend (TaskId) -> TaskState): TaskState? {
        val id = channel.receiveCatching().getOrNull() ?: return null
        return process(id)
    }

    fun close() {
        channel.close()
    }

    fun cancel() {
        channel.cancel()
    }
}
