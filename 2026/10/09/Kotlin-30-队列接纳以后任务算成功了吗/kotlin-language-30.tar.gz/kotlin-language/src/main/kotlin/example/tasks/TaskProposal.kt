package example.tasks

fun taskProposal(text: String, retries: Int = 2, vararg labels: String): String? {
    if (retries !in 0..5) rejectRetries(retries)
    require(labels.all(String::isNotBlank)) { "Labels must not be blank" }
    if (text.isBlank()) return null
    val suffix = if (labels.isEmpty()) "none" else labels.joinToString(",")
    return "TASK proposal (not submitted): $text; retries=$retries; labels=$suffix"
}

fun rejectRetries(retries: Int): Nothing = throw IllegalArgumentException("Retries out of range: $retries")

fun emitProposal(proposal: String?, emit: (String) -> Unit): Unit {
    emit(proposal ?: "No proposal: blank task text")
}
