package example.tasks

private fun normalizeTaskText(rawText: String, events: MutableList<String>): String {
    val normalized = rawText.trim()
    events.add("normalize:$normalized")
    return normalized
}

class Task(rawText: String, private val events: MutableList<String>) {
    val text: String = normalizeTaskText(rawText, events)

    init {
        events.add("init:$text")
        require(text.isNotEmpty()) { "Task text must not be blank" }
    }

    var displayName: String = text
        set(value) {
            require(value.isNotBlank()) { "Display name must not be blank" }
            field = value.trim()
            events.add("set:$field")
        }

    lateinit var owner: String

    val label: String by lazy {
        events.add("lazy:$text")
        "task:$text"
    }
}
