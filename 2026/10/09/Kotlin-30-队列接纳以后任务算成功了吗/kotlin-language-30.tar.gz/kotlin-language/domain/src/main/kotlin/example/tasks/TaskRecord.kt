package example.tasks

data class TaskRecord(val id: String, val labels: MutableList<String>) {
    var reviewed: Boolean = false
}
