package example.tasks

sealed interface TaskState {
    data object Queued : TaskState
    data object Running : TaskState
    data class Succeeded(val result: String) : TaskState
    data class Failed(val reason: String) : TaskState
    data object Cancelled : TaskState
}

sealed interface TaskSignal {
    data object Start : TaskSignal
    data class Success(val result: String) : TaskSignal
    data class Failure(val reason: String) : TaskSignal
    data object Cancel : TaskSignal
}

enum class TaskStage {
    WAITING, ACTIVE, TERMINAL
}

fun taskStage(state: TaskState): TaskStage = when (state) {
    TaskState.Queued -> TaskStage.WAITING
    TaskState.Running -> TaskStage.ACTIVE
    is TaskState.Succeeded, is TaskState.Failed, TaskState.Cancelled -> TaskStage.TERMINAL
}

fun advanceTask(state: TaskState, signal: TaskSignal): TaskState = when (state) {
    TaskState.Queued -> when (signal) {
        TaskSignal.Start -> TaskState.Running
        TaskSignal.Cancel -> TaskState.Cancelled
        is TaskSignal.Success, is TaskSignal.Failure -> rejectTransition(state, signal)
    }
    TaskState.Running -> when (signal) {
        is TaskSignal.Success -> TaskState.Succeeded(signal.result)
        is TaskSignal.Failure -> TaskState.Failed(signal.reason)
        TaskSignal.Cancel -> TaskState.Cancelled
        TaskSignal.Start -> rejectTransition(state, signal)
    }
    is TaskState.Succeeded, is TaskState.Failed, TaskState.Cancelled -> rejectTransition(state, signal)
}

private fun rejectTransition(state: TaskState, signal: TaskSignal): Nothing =
    throw IllegalStateException("Illegal task transition: $state / $signal")

fun acceptSubmission(store: TaskStore, id: String, text: String): Boolean {
    val existing = store.find(id)
    if (existing != null) {
        require(existing == text) { "Task ID already belongs to another text" }
        return false
    }
    return store.putIfAbsent(id, text)
}
