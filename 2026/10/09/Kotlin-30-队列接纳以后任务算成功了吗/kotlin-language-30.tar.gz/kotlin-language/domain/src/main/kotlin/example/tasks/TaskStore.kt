package example.tasks

import kotlin.properties.Delegates

interface TaskStore {
    fun put(id: String, text: String)

    fun find(id: String): String?

    fun putIfAbsent(id: String, text: String): Boolean {
        if (find(id) != null) return false
        put(id, text)
        return true
    }
}

object TaskTextRules {
    fun valid(text: String): Boolean = text.isNotBlank()
}

class InMemoryTaskStore private constructor() : TaskStore {
    private val tasks = mutableMapOf<String, String>()

    override fun put(id: String, text: String) {
        require(id.isNotBlank()) { "Task ID must not be blank" }
        require(TaskTextRules.valid(text)) { "Task text must not be blank" }
        tasks[id] = text
    }

    override fun find(id: String): String? = tasks[id]

    companion object {
        fun empty(): InMemoryTaskStore = InMemoryTaskStore()
    }
}

class AuditedTaskStore(private val delegate: TaskStore, private val events: MutableList<String>) : TaskStore by delegate {
    var lastAttemptedId: String? by Delegates.observable(null) { _, _, next ->
        events.add("attempt:$next")
    }

    override fun put(id: String, text: String) {
        lastAttemptedId = id
        delegate.put(id, text)
    }
}
