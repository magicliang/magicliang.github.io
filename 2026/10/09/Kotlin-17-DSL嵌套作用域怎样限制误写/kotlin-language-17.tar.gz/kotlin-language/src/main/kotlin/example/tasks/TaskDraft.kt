package example.tasks

@DslMarker
annotation class TaskDraftDsl

data class TaskDraft(val id: TaskId, val text: String, val labels: List<String>)

fun makeTaskDraft(id: TaskId, text: String, labels: List<String>): TaskDraft {
    require(text.isNotBlank()) { "Task text must not be blank" }
    val normalizedLabels = labels.map { it.trim() }
    require(normalizedLabels.all { it.isNotEmpty() }) { "Task label must not be blank" }
    return TaskDraft(id, text.trim(), normalizedLabels)
}

@TaskDraftDsl
class TaskLabelBuilder {
    var value: String = ""

    fun build(): String = value
}

@TaskDraftDsl
class TaskDraftBuilder {
    var id: TaskId? = null
    var text: String? = null
    private val labels = mutableListOf<String>()

    fun label(block: TaskLabelBuilder.() -> Unit) {
        labels.add(TaskLabelBuilder().apply(block).build())
    }

    fun build(): TaskDraft = makeTaskDraft(
        requireNotNull(id) { "Task ID required" },
        requireNotNull(text) { "Task text required" },
        labels,
    )
}

fun taskDraft(block: TaskDraftBuilder.() -> Unit): TaskDraft = TaskDraftBuilder().apply(block).build()
