package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime"
	"net/http"
	"strings"
	"sync"
	"time"

	"example.com/go-language-task/stats"
)

type taskHTTPService struct {
	mu                sync.Mutex
	closed            bool
	nextID            int
	store             *TaskStore
	sqlStore          *sqlTaskRepository
	sqlRequestTimeout time.Duration
	recoveryDone      <-chan struct{}
	executor          *taskExecutor
	cancels           map[string]context.CancelFunc
}

func newTaskHTTPService(ctx context.Context, workers, queueCapacity, maxWords int) *taskHTTPService {
	return newTaskHTTPServiceUsing(ctx, workers, queueCapacity, maxWords, analyzeTaskAsyncContext)
}

func newTaskHTTPServiceUsing(ctx context.Context, workers, queueCapacity, maxWords int, analyze func(context.Context, string, int) (stats.Counts, error)) *taskHTTPService {
	store := newTaskStore(nil)
	service := &taskHTTPService{store: store, cancels: make(map[string]context.CancelFunc)}
	service.executor = newTaskExecutorWithDone(ctx, 0, maxWords, workers, queueCapacity, analyze, store, service.forgetCancel)
	return service
}

func (service *taskHTTPService) forgetCancel(id string) {
	service.mu.Lock()
	delete(service.cancels, id)
	service.mu.Unlock()
}

func (service *taskHTTPService) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /tasks", service.create)
	mux.HandleFunc("GET /tasks/{id}", service.lookup)
	mux.HandleFunc("POST /tasks/{id}/cancel", service.cancelTask)
	mux.HandleFunc("GET /health", func(output http.ResponseWriter, request *http.Request) {
		writeHTTPJSON(output, http.StatusOK, struct {
			Status string `json:"status"`
		}{Status: "ok"})
	})
	return mux
}

func (service *taskHTTPService) Close() {
	service.mu.Lock()
	service.closed = true
	service.mu.Unlock()
	service.executor.Close()
	if service.recoveryDone != nil {
		<-service.recoveryDone
	}
	service.executor.Wait()
	service.mu.Lock()
	for id, cancel := range service.cancels {
		cancel()
		delete(service.cancels, id)
	}
	service.mu.Unlock()
}

func (service *taskHTTPService) cancelTask(output http.ResponseWriter, request *http.Request) {
	id := request.PathValue("id")
	requestContext, cancelRequest := service.sqlContext(request.Context())
	defer cancelRequest()
	service.mu.Lock()
	if service.sqlStore != nil {
		_, _, lookupError := service.sqlStore.Lookup(requestContext, id)
		if lookupError != nil {
			service.mu.Unlock()
			if errors.Is(lookupError, ErrSQLTaskNotFound) {
				writeHTTPError(output, http.StatusNotFound, "task not found")
			} else {
				writeHTTPError(output, http.StatusServiceUnavailable, "task database unavailable")
			}
			return
		}
		accepted, cancelError := service.sqlStore.Cancel(requestContext, id)
		if cancelError != nil {
			service.mu.Unlock()
			writeHTTPError(output, http.StatusServiceUnavailable, "task database unavailable")
			return
		}
		if !accepted {
			service.mu.Unlock()
			writeHTTPError(output, http.StatusConflict, "task already terminal or cancel requested")
			return
		}
		if cancel := service.cancels[id]; cancel != nil {
			cancel()
		}
		record, _, lookupError := service.sqlStore.Lookup(requestContext, id)
		service.mu.Unlock()
		if lookupError != nil {
			writeHTTPError(output, http.StatusServiceUnavailable, "task cancellation recorded; lookup unavailable")
			return
		}
		writeHTTPJSON(output, http.StatusAccepted, jsonRecord(record))
		return
	}
	_, exists := service.store.Lookup(id)
	if !exists {
		service.mu.Unlock()
		writeHTTPError(output, http.StatusNotFound, "task not found")
		return
	}
	if !service.store.Cancel(id) {
		service.mu.Unlock()
		writeHTTPError(output, http.StatusConflict, "task already terminal or cancel requested")
		return
	}
	service.cancels[id]()
	record, _ := service.store.Lookup(id)
	service.mu.Unlock()
	writeHTTPJSON(output, http.StatusAccepted, jsonRecord(record))
}

func (service *taskHTTPService) create(output http.ResponseWriter, request *http.Request) {
	mediaType, parameters, err := mime.ParseMediaType(request.Header.Get("Content-Type"))
	if err != nil || mediaType != "application/json" || parameters["charset"] != "" && !strings.EqualFold(parameters["charset"], "utf-8") {
		writeHTTPError(output, http.StatusUnsupportedMediaType, "expected application/json")
		return
	}
	body := http.MaxBytesReader(output, request.Body, maxInputBytes)
	defer body.Close()
	decoder := json.NewDecoder(body)
	decoder.DisallowUnknownFields()
	var input struct {
		Text string `json:"text"`
	}
	if err := decoder.Decode(&input); err != nil {
		var tooLarge *http.MaxBytesError
		if errors.As(err, &tooLarge) {
			writeHTTPError(output, http.StatusRequestEntityTooLarge, "request body too large")
		} else {
			writeHTTPError(output, http.StatusBadRequest, "invalid JSON input")
		}
		return
	}
	var extra any
	if err := decoder.Decode(&extra); !errors.Is(err, io.EOF) {
		var tooLarge *http.MaxBytesError
		if errors.As(err, &tooLarge) {
			writeHTTPError(output, http.StatusRequestEntityTooLarge, "request body too large")
		} else {
			writeHTTPError(output, http.StatusBadRequest, "expected one JSON object")
		}
		return
	}
	if strings.TrimSpace(input.Text) == "" {
		writeHTTPError(output, http.StatusBadRequest, "text must not be empty")
		return
	}
	requestContext, cancelRequest := service.sqlContext(request.Context())
	defer cancelRequest()
	service.mu.Lock()
	if service.closed {
		service.mu.Unlock()
		writeHTTPError(output, http.StatusServiceUnavailable, "task service closed")
		return
	}
	id := fmt.Sprintf("task[%d]", service.nextID)
	position := service.nextID
	if service.sqlStore != nil {
		if err := service.sqlStore.InsertQueued(requestContext, id, input.Text); err != nil {
			service.mu.Unlock()
			writeHTTPError(output, http.StatusServiceUnavailable, "task database unavailable")
			return
		}
	}
	service.nextID++
	service.store.Add(id)
	taskContext, cancel := context.WithCancel(service.executor.ctx)
	err = service.executor.Submit(context.Background(), queuedTask{position: position, text: input.Text, ctx: taskContext, cancel: cancel}, true)
	if err != nil {
		cancel()
		service.store.RemoveQueued(id)
		if service.sqlStore != nil {
			cleanupContext, cleanupCancel := context.WithTimeout(context.Background(), 2*time.Second)
			cleanupError := service.sqlStore.DeleteQueued(cleanupContext, id)
			cleanupCancel()
			if cleanupError != nil {
				service.mu.Unlock()
				writeHTTPError(output, http.StatusInternalServerError, "task rejection database cleanup uncertain")
				return
			}
		}
	} else {
		service.cancels[id] = cancel
	}
	service.mu.Unlock()
	if err != nil {
		writeHTTPError(output, http.StatusServiceUnavailable, "task queue unavailable")
		return
	}
	output.Header().Set("Location", "/tasks/"+id)
	writeHTTPJSON(output, http.StatusAccepted, struct {
		ID string `json:"id"`
	}{ID: id})
}

func (service *taskHTTPService) lookup(output http.ResponseWriter, request *http.Request) {
	if service.sqlStore != nil {
		requestContext, cancelRequest := service.sqlContext(request.Context())
		defer cancelRequest()
		record, _, err := service.sqlStore.Lookup(requestContext, request.PathValue("id"))
		if errors.Is(err, ErrSQLTaskNotFound) {
			writeHTTPError(output, http.StatusNotFound, "task not found")
			return
		}
		if err != nil {
			writeHTTPError(output, http.StatusServiceUnavailable, "task database unavailable")
			return
		}
		writeHTTPJSON(output, http.StatusOK, jsonRecord(record))
		return
	}
	record, exists := service.store.Lookup(request.PathValue("id"))
	if !exists {
		writeHTTPError(output, http.StatusNotFound, "task not found")
		return
	}
	writeHTTPJSON(output, http.StatusOK, jsonRecord(record))
}

func (service *taskHTTPService) sqlContext(requestContext context.Context) (context.Context, context.CancelFunc) {
	if service.sqlStore == nil || service.sqlRequestTimeout <= 0 {
		return requestContext, func() {}
	}
	return context.WithTimeout(requestContext, service.sqlRequestTimeout)
}

func writeHTTPJSON(output http.ResponseWriter, status int, value any) {
	output.Header().Set("Content-Type", "application/json")
	output.WriteHeader(status)
	json.NewEncoder(output).Encode(value)
}

func writeHTTPError(output http.ResponseWriter, status int, message string) {
	writeHTTPJSON(output, status, struct {
		Error string `json:"error"`
	}{Error: message})
}
