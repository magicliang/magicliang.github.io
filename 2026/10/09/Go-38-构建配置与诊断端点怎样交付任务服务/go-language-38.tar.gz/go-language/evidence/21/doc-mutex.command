go doc sync.Mutex
