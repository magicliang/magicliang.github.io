sha256sum '/tmp/go-language-hexo-21.vObInt/downloaded-go-language-21.tar.gz'
