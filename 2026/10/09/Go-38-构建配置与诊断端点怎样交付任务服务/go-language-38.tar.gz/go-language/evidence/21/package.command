tar --exclude='*/http-archive.body' -C '/tmp/go-language-21-pack.CJMy8l' -czf '/home/admin/workspace/my-blogs/source/_posts/2026-10-08-Go-21-服务关闭怎样完成停止接收取消与等待/go-language-21.tar.gz' go-language
