go build -o /tmp/go-language-21-send-after-close ./testdata/send-after-close.go
