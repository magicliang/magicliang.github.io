psql -h 127.0.0.1 -p 36807 -U admin -d postgres -Atc 'select version()'
