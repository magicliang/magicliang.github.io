/usr/lib/postgresql/16/bin/initdb -D '/tmp/go-language-25-pg.FabEdN' -A trust -U admin --no-instructions
