timeout 30s go list -m -versions github.com/lib/pq
