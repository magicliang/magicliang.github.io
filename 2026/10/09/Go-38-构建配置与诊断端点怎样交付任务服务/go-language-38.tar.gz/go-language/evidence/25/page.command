cd '/home/admin/workspace/my-blogs' && python3 writing-plans/go-language/scripts/check_page_00.py '/tmp/go-language-hexo-25.1H89bG/public' 25
