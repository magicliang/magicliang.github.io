sha256sum '/home/admin/workspace/my-blogs/writing-plans/go-language/evidence/25/http-archive.body'
