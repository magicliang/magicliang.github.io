psql -h 127.0.0.1 -p 46515 -U admin -d postgres -Atc 'select version(), current_database()'
