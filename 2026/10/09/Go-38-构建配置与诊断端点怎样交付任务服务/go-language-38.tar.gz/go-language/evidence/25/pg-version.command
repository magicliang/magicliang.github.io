/usr/lib/postgresql/16/bin/postgres --version
