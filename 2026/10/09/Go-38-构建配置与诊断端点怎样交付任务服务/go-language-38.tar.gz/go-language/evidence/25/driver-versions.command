go list -m -versions github.com/lib/pq
