go doc database/sql.Rows.Close
