/usr/lib/postgresql/16/bin/pg_ctl -D '/tmp/go-language-25-pg.FabEdN' -m fast stop
