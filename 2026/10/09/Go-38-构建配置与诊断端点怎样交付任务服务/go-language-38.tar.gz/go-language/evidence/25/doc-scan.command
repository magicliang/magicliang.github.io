go doc database/sql.Rows.Scan
