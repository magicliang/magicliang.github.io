tar --exclude='*/http-archive.body' -C '/tmp/go-language-25-pack.BoJOAJ' -czf '/home/admin/workspace/my-blogs/source/_posts/2026-10-08-Go-25-database-sql如何管理连接与结果集/go-language-25.tar.gz' go-language
