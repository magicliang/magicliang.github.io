timeout 60s go get github.com/lib/pq@v1.12.3
