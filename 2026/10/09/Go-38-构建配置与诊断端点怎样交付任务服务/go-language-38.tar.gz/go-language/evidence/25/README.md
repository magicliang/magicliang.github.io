# 25 真实 SQL 实验索引

`environment.txt`、`pg-version.*`、`pg-init.*`、`pg-start.*`、`pg-query.*` 与 `pg-port.txt` 固定本次隔离 PostgreSQL 16.15、本地端口及启动时的原始双流/退出码。`driver-versions.*` 是直连代理失败的真实输出，`driver-mirror.*`、`driver-get.*` 是镜像成功与固定 `lib/pq v1.12.3`；`go.mod`/`go.sum` 固定实际依赖。

`doc-*`、`tidy`、`verify`、`focused`、`tests`、`race`、`build`、`cli-*`、`module` 每项保留 `.command/.stdout/.stderr/.exit`。`focused` 包含真实 SQL 存查、连接不可用、扫描 NULL 错误与关闭 Rows 后容量恢复 15 次；`race` 无报告只限实际执行的路径。CLI 零期限退出 2 是预期失败，原始双流在案。隔离 PostgreSQL 仅监听 127.0.0.1、采用一次性数据目录；不是对公共服务器的实测。

`package`、`archive-sha`、`sha` 对应完整包和实际摘要；同名素材目录 `unpack-*` 在**新目录、新数据库、新模块缓存**中实际验证包摘要、数据库版本与启动/停止、15 次 SQL 正反、完整两包和 race、CLI 正反的命令/双流/退出码。`hexo`、`page` 和 `http-*` 对应隔离 Hexo 页面、导航及素材链接/摘要检查，另有本地静态 HTTP 正文/导航/包/SHA/RUN 五次 200、实际下载包哈希和二进制一致对照；这些不代替 SQL 实验。`http-server.exit=124` 表示 45 秒到时停止静态服务，不是构建失败。本章没有 SQL 终态自动回写、事务领取或崩溃恢复，不把 POST 202、SQL QUEUED 和任务 SUCCEEDED 当成同一个事实；其他平台、全站构建和发布 `NOT_RUN`。
