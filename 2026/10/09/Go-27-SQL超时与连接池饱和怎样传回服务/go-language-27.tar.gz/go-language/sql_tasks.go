package main

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	"example.com/go-language-task/stats"

	_ "github.com/lib/pq"
)

var ErrSQLTaskNotFound = errors.New("SQL task not found")
var ErrSQLTaskNotRunning = errors.New("SQL task is not running")

type sqlTaskRepository struct {
	db *sql.DB
}

func newSQLTaskRepository(ctx context.Context, db *sql.DB) (*sqlTaskRepository, error) {
	if err := db.PingContext(ctx); err != nil {
		return nil, fmt.Errorf("ping SQL database: %w", err)
	}
	_, err := db.ExecContext(ctx, `CREATE TABLE IF NOT EXISTS go_tasks (
		id TEXT PRIMARY KEY,
		input_text TEXT NOT NULL,
		status TEXT NOT NULL CHECK (status IN ('QUEUED','RUNNING','SUCCEEDED','FAILED','CANCELED')),
		cancel_requested BOOLEAN NOT NULL DEFAULT FALSE,
		words INTEGER NOT NULL DEFAULT 0,
		bytes INTEGER NOT NULL DEFAULT 0,
		runes INTEGER NOT NULL DEFAULT 0
	)`)
	if err != nil {
		return nil, fmt.Errorf("prepare SQL task table: %w", err)
	}
	return &sqlTaskRepository{db: db}, nil
}

func (repository *sqlTaskRepository) InsertQueued(ctx context.Context, id, text string) error {
	_, err := repository.db.ExecContext(ctx, `INSERT INTO go_tasks (id, input_text, status) VALUES ($1, $2, $3)`, id, text, StatusQueued)
	if err != nil {
		return fmt.Errorf("insert queued SQL task: %w", err)
	}
	return nil
}

func (repository *sqlTaskRepository) DeleteQueued(ctx context.Context, id string) error {
	_, err := repository.db.ExecContext(ctx, `DELETE FROM go_tasks WHERE id = $1 AND status = $2`, id, StatusQueued)
	if err != nil {
		return fmt.Errorf("delete unaccepted SQL task: %w", err)
	}
	return nil
}

func (repository *sqlTaskRepository) Lookup(ctx context.Context, id string) (record TaskRecord, text string, err error) {
	rows, err := repository.db.QueryContext(ctx, `SELECT id, input_text, status, cancel_requested, words, bytes, runes FROM go_tasks WHERE id = $1`, id)
	if err != nil {
		return TaskRecord{}, "", fmt.Errorf("query SQL task: %w", err)
	}
	defer func() { err = errors.Join(err, rows.Close()) }()
	if !rows.Next() {
		if err := rows.Err(); err != nil {
			return TaskRecord{}, "", fmt.Errorf("read SQL task: %w", err)
		}
		return TaskRecord{}, "", ErrSQLTaskNotFound
	}
	if err := rows.Scan(&record.ID, &text, &record.Status, &record.CancelRequested, &record.Words, &record.Bytes, &record.Runes); err != nil {
		return TaskRecord{}, "", fmt.Errorf("scan SQL task: %w", err)
	}
	if err := rows.Err(); err != nil {
		return TaskRecord{}, "", fmt.Errorf("read SQL task: %w", err)
	}
	return record, text, nil
}

func (repository *sqlTaskRepository) Claim(ctx context.Context, id string) (bool, error) {
	tx, err := repository.db.BeginTx(ctx, nil)
	if err != nil {
		return false, fmt.Errorf("begin SQL claim: %w", err)
	}
	defer tx.Rollback()
	result, err := tx.ExecContext(ctx, `UPDATE go_tasks SET status=$2 WHERE id=$1 AND status=$3`, id, StatusRunning, StatusQueued)
	if err != nil {
		return false, fmt.Errorf("claim SQL task: %w", err)
	}
	changed, err := result.RowsAffected()
	if err != nil {
		return false, fmt.Errorf("check SQL claim: %w", err)
	}
	if changed == 0 {
		return false, nil
	}
	if err := tx.Commit(); err != nil {
		return false, fmt.Errorf("commit SQL claim: %w", err)
	}
	return true, nil
}

func (repository *sqlTaskRepository) Finish(ctx context.Context, id string, counts stats.Counts, succeeded bool) (TaskStatus, error) {
	tx, err := repository.db.BeginTx(ctx, nil)
	if err != nil {
		return "", fmt.Errorf("begin SQL finish: %w", err)
	}
	defer tx.Rollback()
	terminal := StatusFailed
	if succeeded {
		terminal = StatusSucceeded
	}
	var status TaskStatus
	err = tx.QueryRowContext(ctx, `UPDATE go_tasks SET
		status=CASE WHEN cancel_requested THEN $2 ELSE $3 END,
		words=CASE WHEN cancel_requested OR $3 <> $4 THEN 0 ELSE $5 END,
		bytes=CASE WHEN cancel_requested OR $3 <> $4 THEN 0 ELSE $6 END,
		runes=CASE WHEN cancel_requested OR $3 <> $4 THEN 0 ELSE $7 END
		WHERE id=$1 AND status=$8 RETURNING status`, id, StatusCanceled, terminal, StatusSucceeded,
		counts.Words, counts.Bytes, counts.Runes, StatusRunning).Scan(&status)
	if errors.Is(err, sql.ErrNoRows) {
		return "", ErrSQLTaskNotRunning
	}
	if err != nil {
		return "", fmt.Errorf("finish SQL task: %w", err)
	}
	if err := tx.Commit(); err != nil {
		return "", fmt.Errorf("commit SQL finish: %w", err)
	}
	return status, nil
}

func (repository *sqlTaskRepository) Cancel(ctx context.Context, id string) (bool, error) {
	result, err := repository.db.ExecContext(ctx, `UPDATE go_tasks SET
		status=CASE WHEN status=$2 THEN $3 ELSE status END,
		cancel_requested=CASE WHEN status=$4 THEN TRUE ELSE cancel_requested END
		WHERE id=$1 AND status IN ($2,$4) AND NOT cancel_requested`, id, StatusQueued, StatusCanceled, StatusRunning)
	if err != nil {
		return false, fmt.Errorf("cancel SQL task: %w", err)
	}
	changed, err := result.RowsAffected()
	if err != nil {
		return false, fmt.Errorf("check SQL cancel: %w", err)
	}
	return changed == 1, nil
}

func (repository *sqlTaskRepository) CancelOpen(ctx context.Context) error {
	_, err := repository.db.ExecContext(ctx, `UPDATE go_tasks SET status=$1, cancel_requested=TRUE WHERE status IN ($2,$3)`, StatusCanceled, StatusQueued, StatusRunning)
	if err != nil {
		return fmt.Errorf("cancel open SQL tasks: %w", err)
	}
	return nil
}

func newTaskHTTPServiceWithSQL(ctx context.Context, workers, queueCapacity, maxWords int, db *sql.DB) (*taskHTTPService, error) {
	return newTaskHTTPServiceWithSQLUsing(ctx, workers, queueCapacity, maxWords, db, analyzeTaskAsyncContext)
}

func newTaskHTTPServiceWithSQLUsing(ctx context.Context, workers, queueCapacity, maxWords int, db *sql.DB, analyze func(context.Context, string, int) (stats.Counts, error)) (*taskHTTPService, error) {
	repository, err := newSQLTaskRepository(ctx, db)
	if err != nil {
		return nil, err
	}
	service := newTaskHTTPServiceUsing(ctx, workers, queueCapacity, maxWords, analyze)
	service.sqlStore = repository
	service.sqlRequestTimeout = 2 * time.Second
	service.executor.sqlStore = repository
	return service, nil
}
