# 累计任务服务：第 27 章

本快照对应 Go 27《SQL超时与连接池饱和怎样传回服务》。当前源码以本目录实际文件和 `CURRENT-SHA256SUMS` 为准；`evidence/` 下的旧输出是写作过程历史证据，不冒充本次解包复跑。

## 历史阶段说明

以下文字由早期累计快照继承，描述当时阶段；其中的能力限制和证据路径不作为本篇当前能力总览。本篇复跑步骤以 RUN.md 为准。

26 在可选 PostgreSQL 路径把领取、终态及 HTTP 查询/取消切到同一 SQL 记录：`Claim` 事务内条件更新 QUEUED→RUNNING，双连接竞争只有一个成功；`Finish` 事务内以 RUNNING 条件一次更新终态和三个统计字段，失败分析/取消清零，二次提交返回独立的状态不匹配错误。RUNNING 取消先记请求，再等分析器退出提交 CANCELED；排队项直接取消，Shutdown 不能抢先报终态。独立数据库事务中的故意 `SELECT 1/0` 验证回滚不留下半份结果，不能替代所有生产故障注入。SQL 模式下原内存输入队列只用于本进程唤醒，GET 读数据库；崩溃恢复、外部副作用去重、SQL 资源饱和预算尚未实现，参见 `writing-plans/go-language/evidence/26/`。

25 在同一 `taskHTTPService` 增加可选 `newTaskHTTPServiceWithSQL`：实际 PostgreSQL 用固定 `github.com/lib/pq v1.12.3` 驱动，`PingContext` 检查连接，先插入任务 ID、原文和 QUEUED，成功后才把任务交给原有 worker；SQL 不可用则 POST 503 且内存中没有已接受任务。`sqlTaskRepository.Lookup` 真实扫描表行并关闭 `Rows`；受控测试也验证扫描错误与关闭结果集后容量恢复。**本章只持久化最初的 QUEUED**，运行中/结果/终态仍在原 `TaskStore`，SQL 查询不是最终状态来源；事务领取、状态一致性、重启恢复留到 26–28，不能以本章 202 宣称持久化任务已完成。SQL 证据必须设置 `GO_LANGUAGE_SQL_DSN` 并连接隔离的真实 PostgreSQL；未设置环境变量时集成测试会 Skip。

24 可让**同一个任务服务**的分析器在本地统计前先向合成下游发 GET：`newTaskHTTPServiceWithDownstream` 复用原队列、状态与取消协议，不另造一个执行器。`probeDownstream` 把任务 context 传给出站请求，限制读取 4096 字节响应，并在所有成功/错误状态路径上关闭响应体；超限返回明确错误。调用者应复用拥有连接池的 `http.Client`，分别配置 `net.Dialer.Timeout`（只预算建连）和 `http.Client.Timeout`（覆盖整个请求、重定向及响应体读取），完成后归还闲置连接。合成服务器上的 40 次交替 200/503 和 4097 字节反例、慢响应期限、模拟拨号期限及取消传播由 `downstream_test.go` 验收；仅接入 HTTP adapter 的可选构造入口，CLI 尚未添加常驻 HTTP 监听/下游配置。OS 真实 TCP 超时测量和 SQL 尚 `NOT_RUN`。

23 在同一 `taskHTTPService` 加 `POST /tasks/{id}/cancel`。已接收 HTTP 任务的 context 是从服务执行器派生、由服务持有的逐任务 context，不绑定即将结束的提交请求。排队项取消可立即提交 `CANCELED` 而不运行分析器；运行中只先记录 `CancelRequested` 与发出通知，等分析器返回后再提交终态。请求取消返回 202 不等于工作退出，重复/终态取消 409、缺失 404。已完成任务的 context 和取消函数由原 worker 路径清理。真实 loopback HTTP 闸门与 `http.Server.Shutdown` 对照验证：客户端在收到 202 后取消自己的请求不会取消已接受任务；HTTP server 结束请求/连接不等于服务执行器的 worker 已退出，业务 `Close` 还需要自己等待。`http_cancel_test.go` 和 `writing-plans/go-language/evidence/23/` 给出正反实验；CLI 常驻 HTTP 端口、外部数据库及发布仍未实现。

22 在**同一** `taskExecutor` 和 `TaskStore` 上增加 `taskHTTPService` 的标准库 HTTP 适配层：`POST /tasks` 接受 JSON 文本后立即返回 202 与任务 ID，`GET /tasks/{id}` 查询受锁保护的状态快照，`GET /health` 只表明适配层可应答（不代表可继续接受任务）。输入大小为原工程 65536 字节、JSON 只允许 `text` 字段且内容非空；满队列/关闭拒绝 503 且删掉未接受的预置记录。请求 context 不拥有后台任务，客户端拿到 202 并关闭响应体后，worker 仍由服务 context 管理。真实 loopback HTTP 正反请求、业务 FAILED 对照在 `http_tasks_test.go`，尚未把监听端口或 `http.Server.Shutdown` 接到 CLI；后者在 23–24 对照。数据库和跨进程持久化未引入。

本目录是全系列的**唯一累计工程**。21 将第 20 章的 worker 处理逻辑移入同一个 `taskExecutor`：Mutex 登记并发 Submit 中的发送者；`Close` 唯一拥有输入 channel 的关闭权，先通知在途发送者停止，再等它们退出后关输入；重复关闭和提交/关闭竞争不会对已关闭 channel 发送。`Wait` 等工作者、输出收集者结束；`Shutdown` 在 Close 前请求取消，但对不合作工作仍须等实际退出。批量 CLI 仍使用同一个执行器，另外等待其单生产者结束。受控测试验证优雅 Close 的已接受任务到达成功终态、取消 Shutdown 的已接受任务到达取消终态；不保证未接受任务拥有业务结果。00–20 的快照分别在同名博文素材包。

CLI `--workers`、`--queue-capacity` 仍可选 1–128，默认 1/1；批量输入使用可取消的等待策略。内部拒绝策略返回 `ErrQueueFull`，关闭后 Submit 返回 `ErrExecutorClosed`。`Close` 的**返回**才保证没有在途提交者；调用 Close 与一次在途发送竞争时，该发送仍可能在 Close 返回之前成功。`--batch` 先构造完整输入切片、内存记录及等长结果切片，**不是端到端有界输入**。还没有 HTTP/SQL 或跨进程语义。

需要 Linux amd64 的 Go 1.27.1，或在自己的平台安装同一 patch 版本；不得用较早语言版本的观察冒充本章证据。仓库内源码 tag/SHA 和二进制来源见 `VERSIONS.md`。

```sh
cd examples/go-language
GOTOOLCHAIN=local go version
GOTOOLCHAIN=local go test -count=1 ./...
GOTOOLCHAIN=local go test -count=1 -run '^TestHTTP' -v .
GOTOOLCHAIN=local go list ./...
GOTOOLCHAIN=local go list -m all
GOTOOLCHAIN=local go run . --text 'Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'Go|one two|Go' --workers 2 --queue-capacity 1
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go' --drop-first --append again
GOTOOLCHAIN=local go run . --batch 'Go|one two' --lookup 'task[0]'
GOTOOLCHAIN=local go run . --batch 'Go|one two' --list-ids
printf '%s' '{"text":"Go 写 Go"}' | GOTOOLCHAIN=local go run . --stdin --input-json --json
GOTOOLCHAIN=local go run . --file /tmp/taskstats-input.txt --json
printf 'Go 写 Go' > /tmp/taskstats-input.txt
GOTOOLCHAIN=local go run . --file /tmp/taskstats-input.txt
GOTOOLCHAIN=local go run . --text '  '
GOTOOLCHAIN=local go run ./testdata/shadow.go
GOTOOLCHAIN=local go run ./testdata/assign.go
GOTOOLCHAIN=local go run ./testdata/loop-declare.go
GOTOOLCHAIN=local go run ./testdata/loop-assign.go
GOTOOLCHAIN=local go run ./testdata/defer-order.go
GOTOOLCHAIN=local go run ./testdata/defer-loop.go
GOTOOLCHAIN=local go run ./testdata/slice-append.go
GOTOOLCHAIN=local go test -count=1 -v ./testdata/slice-alias-bug_test.go
GOTOOLCHAIN=local go run ./testdata/nil-map-write.go
GOTOOLCHAIN=local go build ./testdata/nonaddressable-receiver.go
GOTOOLCHAIN=local go build ./testdata/interface-value-error.go
GOTOOLCHAIN=local go run ./testdata/typed-nil.go
GOTOOLCHAIN=local go build -o /tmp/recover-outside-defer ./testdata/recover-outside-defer.go
/tmp/recover-outside-defer
GOTOOLCHAIN=local go build ./testdata/invalid-summarizer.go
GOTOOLCHAIN=local go build ./testdata/invalid-type-operation.go
```

纯空白文本及文件打开失败的**应用进程**预期退出 2；`go run` 外层状态不能代替应用退出码，应改用编译所得二进制检查。14 的输入超限、坏 JSON、stdout 部分写入分别返回应用退出 2；已经接受的输出字节不能由本 CLI 撤销，不能称写出具有事务原子性。文件由 `readAndClose` 关闭；调用方拥有的 stdin/stdout 不由本函数关闭。13 两份故意编译失败例子及更早反例仍隔离在 `testdata/`。最新 14 结果见 `writing-plans/go-language/evidence/14/`，00–13 的冻结快照留在对应正文素材包。

SQL HTTP 路径在 27 增加请求级数据库期限：池满等待及语句执行受同一个 context 约束，但 worker 的 SQL 写入、业务完成及服务锁等待不受此预算覆盖。正反实测在 `writing-plans/go-language/evidence/27/`，无 DSN 会 Skip。
