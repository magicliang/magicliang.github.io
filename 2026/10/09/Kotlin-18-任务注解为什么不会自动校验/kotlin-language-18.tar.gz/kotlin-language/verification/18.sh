#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/18"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && ./gradlew --version' || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test || exit 1
for suite in MainTest TaskSettingsTest CommandParserTest TaskProposalTest TaskTextTest OptionalTaskNoteTest TaskQueryTest TaskLabelRulesTest TaskLabelPipelineTest TaskTest TaskRecordTest TaskStoreTest TaskStateTest SubmissionDecisionTest TaskFormattingTest TaskStatePortsTest TypedTaskIdTest TaskDraftTest TaskMetadataTest; do
    run "$suite" cat "build/test-results/test/TEST-example.tasks.$suite.xml" || exit 1
done
run bytecode javap -p -v -classpath build/classes/kotlin/main example.tasks.TaskDraft || exit 1
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit
invalid_result=$?

scratch="$(mktemp -d /tmp/kotlin-18-rejected-XXXXXX)"
mkdir -p "$scratch/gradle/wrapper" "$scratch/src/main/kotlin"
cp build.gradle.kts settings.gradle.kts gradlew "$scratch/"
cp gradle/wrapper/* "$scratch/gradle/wrapper/"
cp src/main/kotlin/example/tasks/TaskState.kt src/main/kotlin/example/tasks/TaskStore.kt src/main/kotlin/example/tasks/SubmissionDecision.kt src/main/kotlin/example/tasks/TypedTaskId.kt src/main/kotlin/example/tasks/TaskDraft.kt src/main/kotlin/example/tasks/TaskMetadata.kt verification/18-invalid-annotation-target.kt "$scratch/src/main/kotlin/"
run rejected bash -c 'cd "$1" && ./gradlew --offline --no-daemon --console=plain compileKotlin' _ "$scratch"
rejected_result=$?

{
    printf 'build_exit=0\nbytecode_exit=0\nvalid_exit=0\ninvalid_exit=%s\nrejected_exit=%s\n' "$invalid_result" "$rejected_result"
    for suite in MainTest TaskSettingsTest CommandParserTest TaskProposalTest TaskTextTest OptionalTaskNoteTest TaskQueryTest TaskLabelRulesTest TaskLabelPipelineTest TaskTest TaskRecordTest TaskStoreTest TaskStateTest SubmissionDecisionTest TaskFormattingTest TaskStatePortsTest TypedTaskIdTest TaskDraftTest TaskMetadataTest; do
        grep -F 'tests="2" skipped="0" failures="0" errors="0"' "$evidence/$suite.txt" >/dev/null && echo "$suite=PASS" || echo "$suite=FAIL"
    done
    grep -F 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" >/dev/null && echo 'valid_cli=PASS' || echo 'valid_cli=FAIL'
    grep -F 'Usage: submit <task text>' "$evidence/invalid.txt" >/dev/null && echo 'invalid_cli=PASS' || echo 'invalid_cli=FAIL'
    grep -F 'not applicable to target' "$evidence/rejected.txt" >/dev/null && echo 'class_annotation_on_function_rejected=PASS' || echo 'class_annotation_on_function_rejected=FAIL'
    grep -F 'RuntimeVisibleAnnotations:' "$evidence/bytecode.txt" >/dev/null && echo 'runtime_annotation_in_class=PASS' || echo 'runtime_annotation_in_class=FAIL'
} > "$evidence/assertions.txt"

test "$invalid_result" -ne 0 && test "$rejected_result" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
