package blog.libraries;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class Chapter00Test {
    private static Product product(String merchant, String id, String price) {
        return new Product(merchant, id, new BigDecimal(price));
    }

    @Test
    void preservesBusinessOrderAndMerchantScopedIdentity() {
        Product first = product("shop-b", "p-1", "12.00");
        Product second = product("shop-a", "p-1", "7.50");
        Product third = product("shop-b", "p-2", "0");
        List<Product> input = new ArrayList<>(Arrays.asList(first, second, third));
        Map<String, List<Product>> result = Catalog.groupByMerchant(input);
        assertEquals(Arrays.asList("shop-b", "shop-a"), new ArrayList<>(result.keySet()));
        assertEquals(Arrays.asList(first, third), result.get("shop-b"));
        assertEquals(Arrays.asList(second), result.get("shop-a"));
        assertEquals(new BigDecimal("0.00"), third.getPrice());
        input.clear();
        assertEquals(2, result.get("shop-b").size());
        assertThrows(UnsupportedOperationException.class, () -> result.clear());
        assertThrows(UnsupportedOperationException.class, () -> result.get("shop-b").clear());
        System.out.println("C00 order=[shop-b, shop-a], sizes=[2, 1], same-id-across-merchants=accepted, zero-price=0.00, source-clear=isolated");
    }

    @Test
    void rejectsOnlyDuplicatesWithinTheSameMerchant() {
        assertThrows(IllegalArgumentException.class, () -> Catalog.groupByMerchant(Arrays.asList(
                product("shop-a", "p-1", "1.00"), product("shop-a", "p-1", "2.00"))));
        assertEquals(0, Catalog.groupByMerchant(new ArrayList<>()).size());
        System.out.println("C00 same-merchant-duplicate=rejected, empty-catalog=accepted");
    }

    @Test
    void rejectsInvalidDataWithoutRoundingOrSilentlyTrimming() {
        assertThrows(NullPointerException.class, () -> product(null, "p-1", "1.00"));
        assertThrows(IllegalArgumentException.class, () -> product("shop-a", "", "1.00"));
        assertThrows(IllegalArgumentException.class, () -> product("shop-a", "p-1", "-0.01"));
        assertThrows(ArithmeticException.class, () -> product("shop-a", "p-1", "1.001"));
        assertThrows(NullPointerException.class, () -> Catalog.groupByMerchant(null));
        assertThrows(NullPointerException.class, () -> Catalog.groupByMerchant(Arrays.asList((Product) null)));
        Product spaces = product(" shop-a ", " ", "1.000");
        assertEquals(" shop-a ", spaces.getMerchantId());
        assertEquals(" ", spaces.getProductId());
        assertEquals(new BigDecimal("1.00"), spaces.getPrice());
        System.out.println("C00 null/empty/negative/non-exact-price=rejected, identifier-normalization=none, 1.000=1.00");
    }
}
