# Java 常用类库实验：00–02

首批商品目录与契约比较。源码目标 Java 8，验证环境限定 Zulu 8u472 和 Corretto 21.0.11；后续章节尚未实现。

## 运行

安装 JDK 8 或 JDK 21，在本目录执行：

```bash
./mvnw -B -ntp -s .mvn/settings.xml clean verify
./mvnw -B -ntp -s .mvn/settings.xml -Dtest=Chapter01Test test
./mvnw -B -ntp -s .mvn/settings.xml org.apache.maven.plugins:maven-dependency-plugin:3.8.1:tree
```

Windows 使用 `mvnw.cmd`。首次运行需要连接 Maven Central；Wrapper 下载 Maven 3.9.14。切换 JDK 后使用 `clean verify`，用 `./mvnw -v` 检查实际工具链。

测试中的 U+180E 比较明确限定 Java 8/21；其他 Java 版本不会被当成本批的已验证环境。现代 `String.isBlank`、`List.copyOf` 通过反射比较；Java 8 记录 API 不适用，JDK 21 实际执行。不要用测试方法数推断所有分支覆盖。

## 结构与结果

| 文件 | 契约或场景 | 8/21 结果 |
|---|---|---|
| `Product.java`、`Catalog.java` | JDK 商品目录；商户内唯一、遇见顺序、精确金额、隔离返回容器 | 基线 3 项各通过 |
| `Chapter01Test.java` | 17 行字符表、缺失/null/空串、U+180E、SKU 语法 | 20 项各通过 |
| `Chapter02Test.java` | 容器与元素修改传播、null、复用观察、现代 copyOf | 6 项各通过 |

每个 JDK 总计 29 项，0 失败、0 错误、0 跳过；现代 API 的 Java 8 分支为不适用。日志、XML 和解析依赖树见 `evidence/00/`，各章源码研究和事实账本见 `evidence/01/`、`evidence/02/`。XML 中含本机目录和运行环境，用于研究追溯，不要求复跑目录完全相同。

基线标识符只拒绝 null/空串，不 trim，不作 SKU 语法校验。第 01 篇的 `requireSku` 是独立的严格语法实验；并未集成到 `Product`。第 03 篇的相等/哈希契约尚未加入。

直接依赖 Guava 33.5.0-jre、Commons Lang 3.20.0、JUnit Jupiter 5.13.4。未来候选类库不预装。当前 `pom.xml` 仅有一个模块，不需要数据库、Docker 或框架。

未运行：性能基准、并发一致性/发布实验、JDK 11/17/25、Windows/Linux、后续 03–39 与 E01–E08。

## 下载和完整性

博文第 00 篇提供整份首批工程附件，包含源码、Wrapper、版本配置、README 和原始证据，不包含 target 或本地依赖缓存。校验下载附件可使用博文附件中的 SHA-256。`evidence/00/artifact-checksums.sha256` 记录本次参与比较的 Guava、Commons Lang 二进制及配置/源码文件，用于版本追溯。
