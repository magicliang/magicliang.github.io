# Chapter 02 claim ledger

Scope: list container ownership, element aliases, immutable copy reuse. Audience: Java developers designing return-value contracts. Angle: sequential mutation matrix plus identity observation; no performance ranking, concurrency stress result, or GC claim.

Research date: 2026-10-02. Guava tag v33.5.0; directly checked checkout HEAD 8868c096cfdabbe38170b6e395369c315cfb72a1.

| Claim | Primary source | Evidence / risk | Action |
|---|---|---|---|
| unmodifiableList is a live read-through view | https://docs.oracle.com/javase/8/docs/api/java/util/Collections.html#unmodifiableList-java.util.List- | DOC_VERIFIED; wrapper does not eliminate original alias | sourceEditsReachViewButNotCopies |
| ArrayList collection constructor copies reference sequence | https://docs.oracle.com/javase/8/docs/api/java/util/ArrayList.html#ArrayList-java.util.Collection- | DOC_VERIFIED; no recursive object copy | sourceEditsReachViewButNotCopies; allContainersShareMutableElement |
| Guava shallow immutability, null hostility | https://guava.dev/releases/33.5.0-jre/api/docs/com/google/common/collect/ImmutableCollection.html | DOC_VERIFIED; thread-safe container is not mutable element synchronization | unsupportedWritesAndMutableCopy; nullPolicyDiffers |
| copyOf may reuse full immutable input | https://github.com/google/guava/blob/8868c096cfdabbe38170b6e395369c315cfb72a1/guava/src/com/google/common/collect/ImmutableList.java#L258-L265 | SOURCE_VERIFIED; identity is implementation observation, not API guarantee | immutableReuseIsVersionSpecificObservation |
| subList length 1 is singleton optimization; length 2 of 3 takes partial view | Same pinned file, L455–505 | SOURCE_VERIFIED; do not infer heap size/GC from identity | test uses subList(0,2), no GC claim |
| upstream tests separate source mutation/null/reuse | https://github.com/google/guava/blob/8868c096cfdabbe38170b6e395369c315cfb72a1/guava-tests/test/com/google/common/collect/ImmutableListTest.java | SOURCE_VERIFIED; testCopyOf_collection_general, collectionContainingNull, shortcut_immutableList; upstream suite not executed | cite reviewed source, not upstream LAB_VERIFIED |
| JDK List.copyOf requires Java 10+; null rejection and shallow values | https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/List.html#copyOf(java.util.Collection) | DOC_VERIFIED; modern API absent in Java 8 | modernJdkCopyOfIndependentComparison via reflection |
| volatile publication and final semantics differ from element immutability | https://docs.oracle.com/javase/specs/jls/se8/html/jls-17.html#jls-17.4.5 and #jls-17.5 | DOC_VERIFIED; sequential tests cannot demonstrate visibility | no concurrency success claim |

## Retrieval rounds

1. `site.guava.dev releases 33.5.0 ImmutableList copyOf immutableCollection isPartialView`; `site.docs.oracle.com/javase/8/docs/api/java/util/Collections.html unmodifiableList read through`: current version docs found; read primary docs.
2. Reverse checks: `site.guava.dev/releases/33.5.0-jre "copyOf" "thread" "mutable"`; `site.github.com/google/guava "ImmutableListTest" "copyOf" "Same"`; `site.docs.oracle.com/javase/8/docs/api/java/util/ArrayList.html "collection" "order"`. Explicitly checked counterclaims “copyOf always allocates” and “immutable container freezes elements”; both rejected by documented contracts/source.
3. Direct checkout inspection with `git -C /tmp/java-baseline-guava-3350 rev-parse HEAD`, `rg -n 'copyOf\(|isPartialView|testCopyOf|test.*ubList' ...` and `sed -n '245,315p' .../ImmutableList.java`; found singleton-subList exception and changed test range before runtime validation.

Captured source assertions: `source-check.json`. Browser GitHub tag pages returned cache miss, ordinary curl had DNS failure; pinned checkout and an escalated raw fetch supplied source successfully. No conclusions are based on search snippets alone.
