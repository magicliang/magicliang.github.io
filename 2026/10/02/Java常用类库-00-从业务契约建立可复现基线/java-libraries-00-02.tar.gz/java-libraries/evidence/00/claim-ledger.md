# 00 核心结论账本

| 结论 | 证据 | 状态与边界 |
|---|---|---|
| 商户内商品唯一，跨商户同编号合法；保持遇见顺序 | Product/Catalog + Chapter00Test + 两JDK XML/日志 | LAB_VERIFIED；只有本批明确输入契约 |
| 金额非负、两位小数且不舍入；1.000成功/1.001拒绝 | BigDecimal Java8官方setScale文档 + Chapter00Test | DOC_VERIFIED/LAB_VERIFIED |
| 返回容器隔离原输入，当前Product值不可变 | 类定义、只读字段类型与3项基线测试；02元素反例 | SOURCE_VERIFIED/LAB_VERIFIED；不得扩展至任意可变对象图 |
| 固定依赖与插件能在本次8/21执行 | pom、wrapper、两JDK Maven verify日志、依赖树 | LAB_VERIFIED；未验证其他发行版/平台 |
| 测试绿色不证明所有分支被执行 | Java8现代API输出NOT_AVAILABLE/NOT_APPLICABLE；21实际输出 | LAB_VERIFIED；0 skipped只针对测试方法计数 |
| 字节码为Java8目标 | JDK21 javap Product.class major version 52 | LAB_VERIFIED；不等同所有Java8 API兼容性 |
| 源码提交能解释机制，不能证明本机vendor构建来源 | 冻结Git提交与实际java-version分别保存 | 证据边界；未校验本机JDK源码构建提交 |
| TreeMap/舍入模式练习会使特定断言失败 | 公开契约与代码推导 | NOT_RUN；未进行突变实验 |

官方资料：Java8 BigDecimal/Collections 文档；Guava README固定提交8868c096cfdabbe38170b6e395369c315cfb72a1；Lang pom固定提交598dfc163b8b410fb3bb8794521206ec8dcec82a；JUnit5.13.4文档；Maven3.9.14发行说明与Wrapper/Compiler/Surefire版本文档。文章保留直接链接。
