# 第 00 篇落盘前扫描

顺序：anti-ai-tone → anti-persona-fabrication。

1. 2026-10-02，`check_prose.py --profile tech /tmp/java-libraries-00-draft.md --json`：3214 汉字，0 errors、0 warnings。人工检查材料支撑、段落推进、工程与证据的区别。
2. 随后扫描第一人称、虚构经历、拟人化、说书人腔：无命中；全文连读确认没有捏造作者行动、情绪或身份。再落盘到 source。

这是写作风格检查，不是技术正确性证明。
