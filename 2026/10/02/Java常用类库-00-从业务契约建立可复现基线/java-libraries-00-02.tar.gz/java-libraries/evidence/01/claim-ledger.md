# Chapter 01 claim ledger

Scope: missing/null/empty/blank contracts; bounded SKU rejection; Java 8 syntax with Java 21 comparison.
Angle: independent expected tables reveal non-inclusion among whitespace sets; loss of identity from silent normalization.
Audience: Java developers reviewing utility replacement and JDK upgrades.

| Claim | Source | Evidence | Risk/action |
|---|---|---|---|
| null and empty are distinct, missing field is a separate state | Chapter01Test.absenceIsNotAnEmptyValue; Guava Strings versioned Javadoc | Map containsKey/get assertions; conversion assertions | Map fixture does not prove JSON framework behavior |
| trim accepts code units <= U+0020 | https://docs.oracle.com/javase/8/docs/api/java/lang/String.html#trim-- | contract read; NUL/EM SPACE opposing tests | not generalized to Unicode whitespace |
| Java whitespace excludes three NBSP characters and includes U+001C | https://docs.oracle.com/javase/8/docs/api/java/lang/Character.html#isWhitespace-int- | explicit table, independent boolean expectations | JDK database varies; exact runtimes recorded by parent |
| Guava whitespace is char based fixed table in this build | https://github.com/google/guava/blob/8868c096cfdabbe38170b6e395369c315cfb72a1/guava/src/com/google/common/base/CharMatcher.java#L1232-L1266 | source-inspection.txt, independently read git HEAD and owning source | no generic Unicode normalization claim |
| Commons blank delegates to Character.isWhitespace(char) and accepts null | https://github.com/apache/commons-lang/blob/598dfc163b8b410fb3bb8794521206ec8dcec82a/src/main/java/org/apache/commons/lang3/StringUtils.java#L3480-L3515 | source-inspection.txt includes same-version Javadoc and implementation | moving Commons website not used as version proof |
| Strings null/empty transformations do not trim | https://guava.dev/releases/33.5.0-jre/api/docs/com/google/common/base/Strings.html | Strings delegates to Platform; source-inspection.txt followup | lossy boundary must be chosen by application |
| U+180E changed from Zs to Cf in Unicode 6.3 | https://www.unicode.org/versions/Unicode6.3.0/ | web read notable changes; explicit 8/21 test | finite regression rather than all-Unicode proof |
| String.isBlank available since 11 | https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/lang/String.html#isBlank() | API since and whitespace codepoint contract read | reflection comparison unavailable on 8, not counted as executed there |
| ASCII SKU is rejected unchanged if malformed | Chapter01Test.identifiersAreRejectedWithoutSilentRepair | 8 invalid fixtures and identity assertion for valid input; trim collision assertions | bounded example, not production integration |

## Research rounds

1. Read Java 8 Character/String docs and sought frozen Guava/Commons Javadoc.
2. Verified source tag and SHA owning paths; read local frozen git checkouts directly (HEAD captured in source-inspection.txt).
3. Reverse search Unicode whitespace history found 6.3 U+180E category change; added independently expected JDK 8/21 experiment.
4. Validated source line anchors using actual local files, since web parser line numbers remove blank lines.

Some CharMatcher/Commons hosted HTML requests returned Internal Error. Exact-version source Javadoc was read instead; no successful HTTP retrieval is claimed for those attempts. Shell raw GitHub curl failed DNS; no empty downloads are treated as evidence.

Runtime evidence: independently read both captured XML reports (20/0/0/0 each) and stdout. Exact invocation/scenarios/artifacts are in acceptance.md; matrices contain actual printed values.
