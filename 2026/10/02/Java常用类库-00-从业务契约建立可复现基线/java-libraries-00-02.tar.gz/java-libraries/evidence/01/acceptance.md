# Chapter 01 acceptance evidence

Working directory: examples/java-libraries.

## Exact centralized invocations

Executed by the root agent with zsh `set -o pipefail`; this chapter agent independently reads captured stdout and Surefire XML before making claims.

```sh
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home MAVEN_USER_HOME="$PWD/.maven-user-home" ./mvnw -B -ntp -s .mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify | tee evidence/00/jdk8-verify.stdout.txt
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn MAVEN_USER_HOME="$PWD/.maven-user-home" ./mvnw -B -ntp -s .mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify | tee evidence/00/jdk21-verify.stdout.txt
```

| Scenario | Binary observable | Artifact |
|---|---|---|
| 17 input rows, all five character contracts and Guava empty contract | independent expected values hold; no failures | jdk8-Chapter01Test.xml, jdk8-matrix.txt; jdk21-Chapter01Test.xml, jdk21-matrix.txt |
| Missing field, explicit null, empty, null API contracts | map existence assertions and expected exceptions hold | same XML, absence output row |
| SKU valid identity and 8 invalid inputs | original reference returned, all eight throw IllegalArgumentException | same XML, sku output row |
| Unicode U+180E history | JDK8 Java/Commons true; JDK21 Java/Commons false; Guava false on both | same XML, U+180E output row |
| Source binding | recorded local git HEAD equals frozen SHA, implementation and Javadoc directly read | source-inspection.txt |
| Prose scans before source publication | anti-ai errors=0 and warnings=0; persona no hits, manual checks complete | anti-ai-tone.json, anti-persona-fabrication.json |

No exhaustive Unicode sweep, performance claim, JSON framework integration or production ingestion was tested. Java8 String.isBlank comparison is explicitly NOT_AVAILABLE; only JDK21 can execute that API.

Fresh readback: both XML reports have tests=20, failures=0, errors=0, skipped=0. XML properties independently confirm Azul 1.8.0_472 and Amazon 21.0.11. Both centralized stdout logs contain BUILD SUCCESS.

Final article: source/_posts/2026-10-02-Java常用类库-01-null-empty与blank的语义边界.md, 3,341 Han characters including frontmatter, 148 lines. Same-name assets contain both matrices. Hexo build is owned by root; no build pass claimed by this lane.

Post-review correction: replaced unpublished main-branch test links with chapter 00 downloadable project post_link; runnable command includes `-s .mvn/settings.xml`. Final source text received anti-ai-tone then anti-persona-fabrication before publication. No Java test code changed.
