"""Stable driver authority despite duplicate spatial candidates and stale messages."""
import hashlib
import json
import pathlib
import tempfile
import time
from dispatch import Conflict, Store


def authority_worker(driver):
    # Logical API ownership only; the prototype retains one shared SQL authority.
    return int.from_bytes(hashlib.sha256(driver.encode()).digest()[:8],'big')%5


results=[]
with tempfile.TemporaryDirectory() as tmp:
    root=pathlib.Path(tmp)
    for initially_accepted in [False,True]:
        now=[1000]
        store=Store(root/(str(initially_accepted)+'.sqlite'),clock_ms=lambda:now[0])
        store.initialize(['moving-driver'])
        first=store.offer('old-request','old-offer','moving-driver','old-order')
        cached_offer=dict(first)
        stale_outbox=dict(store.pending_events()[0])
        source_owner=authority_worker('moving-driver')
        cells={'station-A':{'moving-driver'},'station-B':{'moving-driver'}}
        now[0]=2000
        destination_owner=authority_worker(next(iter(cells['station-B'])))
        assert source_owner==destination_owner
        try:
            store.offer('during-migration','conflicting-offer','moving-driver','other-order')
            raise AssertionError('migration duplicated driver authority')
        except Conflict:
            pass
        cached_accept_response=None
        if initially_accepted:
            assert store.accept(first['id'],'moving-driver',first['generation'])==1
            cached_accept_response={'state':'accepted','offer_id':first['id'],'generation':first['generation']}
        cancel_started=time.monotonic()
        cancelled=store.release(first['id'],first['generation'])
        cancellation_acknowledged=time.monotonic()
        assert cancelled==1
        accept_started=time.monotonic()
        stale_ack=store.accept(stale_outbox['id'],stale_outbox['driver_id'],stale_outbox['generation'])
        accept_returned=time.monotonic()
        assert accept_started>=cancellation_acknowledged
        assert stale_ack==0
        assert cached_offer['state']==stale_outbox['state']=='offered'
        assert store.rows()[0]['state']=='cancelled'
        now[0]=2500
        replacement=store.offer('new-request','new-offer','moving-driver','new-order')
        assert replacement['generation']==2
        after_replacement=store.accept(first['id'],'moving-driver',first['generation'])
        old_cancel=store.release(first['id'],first['generation'])
        assert (after_replacement,old_cancel)==(0,0)
        now[0]=replacement['expires_ms']
        deadline_ack=store.accept(replacement['id'],'moving-driver',replacement['generation'])
        assert deadline_ack==0
        rows=store.rows()
        effective=[x for x in rows if x['state']=='accepted' or (x['state']=='offered' and x['expires_ms']>now[0])]
        assert len(effective)<=1
        results.append({'scenario':'migration and post-cancellation stale accept','initially_accepted':initially_accepted,
                        'source_authority_worker':source_owner,'destination_authority_worker':destination_owner,
                        'spatial_cells':{key:sorted(value) for key,value in cells.items()},'cached_state':cached_offer['state'],'cached_accept_response':cached_accept_response,
                        'cancel_started_monotonic':cancel_started,'cancellation_acknowledged_monotonic':cancellation_acknowledged,
                        'accept_started_monotonic':accept_started,'accept_returned_monotonic':accept_returned,
                        'cancel_rows':cancelled,'stale_outbox_accept_rows':stale_ack,'old_accept_after_replacement_rows':after_replacement,
                        'old_cancel_after_replacement_rows':old_cancel,'exact_deadline_accept_rows':deadline_ack,'rows':rows})
print(json.dumps({'pass':True,'results':results,'boundary':'spatial cells are labels; shared local SQLite authority, not a real map or distributed database'},indent=2))
