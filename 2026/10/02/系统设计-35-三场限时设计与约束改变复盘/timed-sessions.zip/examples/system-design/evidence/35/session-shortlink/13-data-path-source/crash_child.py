"""Exit without cleanup at one specified transaction boundary."""
import json
import os
import sys

from shortlink import Service

path, action, event, code = sys.argv[1:]


def crash(selected):
    if selected == event:
        print(json.dumps({'fault': 'os._exit', 'event': selected, 'exit_code': 73}), flush=True)
        os._exit(73)


service = Service(path, clock=lambda: 1000, candidate=lambda: 'fixed-code', hook=crash)
if action == 'create':
    service.create('alice', 'request-1', 'https://example.org/a', 2000)
elif action == 'revoke':
    service.revoke('alice', code)
else:
    raise ValueError(action)
raise SystemExit('fault hook was not reached')
