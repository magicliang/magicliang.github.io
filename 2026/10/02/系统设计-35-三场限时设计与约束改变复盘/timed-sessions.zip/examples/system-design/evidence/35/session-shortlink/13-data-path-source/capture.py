"""Run once, retain exact command, both streams, exit status and source hashes."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import platform
import sqlite3
import subprocess
import time

LAB = Path(__file__).resolve().parent
ROOT = LAB.parents[2]
EVIDENCE = ROOT / "evidence/35/session-shortlink"


def capture(name, command):
    folder = EVIDENCE / name
    folder.mkdir(exist_ok=False)
    started_ns = time.monotonic_ns()
    started_utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
    sources = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
               for p in sorted(LAB.glob("*.py"))}
    snapshot = folder / "source"
    snapshot.mkdir()
    for relative, expected in sources.items():
        source = ROOT / relative
        data = source.read_bytes()
        assert hashlib.sha256(data).hexdigest() == expected
        (snapshot / source.name).write_bytes(data)
    result = subprocess.run(command, cwd=LAB, capture_output=True, text=True)
    ended_ns = time.monotonic_ns()
    (folder / "stdout.log").write_text(result.stdout)
    (folder / "stderr.log").write_text(result.stderr)
    receipt = {"command": command, "cwd": str(LAB), "exit_code": result.returncode,
               "started_utc": started_utc,
               "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "started_monotonic_ns": started_ns, "finished_monotonic_ns": ended_ns,
               "elapsed_s": (ended_ns - started_ns) / 1e9,
               "python": platform.python_version(), "sqlite": sqlite3.sqlite_version,
               "source_sha256": sources,
               "output_sha256": {key: hashlib.sha256(value.encode()).hexdigest()
                                 for key, value in {"stdout.log": result.stdout, "stderr.log": result.stderr}.items()}}
    (folder / "run.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(receipt, ensure_ascii=False, indent=2))
    print(result.stdout, end="")
    print(result.stderr, end="")
    return result.returncode


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    raise SystemExit(capture(args.name, args.command))
