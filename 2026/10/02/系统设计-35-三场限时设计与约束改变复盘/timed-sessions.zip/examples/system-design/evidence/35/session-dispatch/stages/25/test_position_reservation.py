import concurrent.futures
import json
import pathlib
import tempfile
import threading
import time
from dispatch import Conflict, Store
from position import LatestPositions, Position

clock_ms=lambda:time.time_ns()//1_000_000
with tempfile.TemporaryDirectory() as tmp:
    store=Store(pathlib.Path(tmp)/'freshness.sqlite')
    store.initialize(['d'])
    positions=LatestPositions()
    epoch=positions.open_session('d')
    sample=clock_ms()-4900
    positions.report('d',Position(epoch,1,sample,0,clock_ms(),1.0,2.0))
    assert positions.eligible('d',clock_ms())
    deadline=sample+5000
    attempted=threading.Event()
    observation={'position_valid_until_ms':deadline}
    def reserve():
        attempted.set()
        try:
            observation['offer']=store.offer('r','o','d','order',position_valid_until_ms=positions.values['d'].valid_until_ms)
            observation['reserved']=True
        except Conflict:
            observation['reserved']=False
        observation['finished_ms']=clock_ms()
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        with store.transaction():
            pending=pool.submit(reserve)
            assert attempted.wait(timeout=2)
            start=time.monotonic()
            time.sleep(0.25)
            observation['fault_injection_wait_s']=time.monotonic()-start
        pending.result(timeout=5)
    print(json.dumps(observation,indent=2),flush=True)
    assert observation['finished_ms']>deadline
    assert observation['reserved'] is False, 'position expired while reservation waited for write lock'
