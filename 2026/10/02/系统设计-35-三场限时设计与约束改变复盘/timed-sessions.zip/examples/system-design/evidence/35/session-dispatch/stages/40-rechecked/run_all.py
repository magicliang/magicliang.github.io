"""Run each distinct regression once; no timers or throughput claims."""
import json
import pathlib
import subprocess
import sys
import time

lab=pathlib.Path(__file__).resolve().parent
results=[]
for name,expected in [('naive.py',1),('test_dispatch.py',0),('lock_clock.py',0),('test_position.py',0),('test_position_reservation.py',0),('test_recovery.py',0),('test_retry_expiry.py',0),('test_transitions.py',0),('spatial_authority_naive.py',1),('cancel_cache_naive.py',1),('hotspot.py',0),('test_migration_cancel.py',0)]:
    command=[sys.executable,str(lab/name)]
    started=time.monotonic()
    result=subprocess.run(command,text=True,capture_output=True)
    item={'file':name,'command':command,'exit_code':result.returncode,'expected_exit':expected,
          'elapsed_s':time.monotonic()-started,'stdout':result.stdout,'stderr':result.stderr}
    results.append(item)
    valid=result.returncode==expected
    if expected==1 and valid:
        observed=json.loads(result.stdout)
        if name=='naive.py':
            valid=observed['active_offers_for_one_driver']==2
        elif name=='spatial_authority_naive.py':
            valid=observed['effective_assignments_for_driver']==2
        elif name=='cancel_cache_naive.py':
            valid=observed['updated_rows']==1 and observed['authoritative_rows'][0]['state']=='accepted'
        valid=valid and 'AssertionError:' in result.stderr
    item['binary_observable_verified']=valid
    if not valid:
        print(json.dumps({'pass':False,'results':results},indent=2))
        raise SystemExit(1)
print(json.dumps({'pass':True,'results':results},indent=2))
