import concurrent.futures
import json
import pathlib
import tempfile
import threading
from dispatch import Conflict, Store


def scenario_race(root):
    store = Store(root/'race.sqlite', clock_ms=lambda:1000)
    store.initialize(['driver-1'])
    ready = threading.Barrier(12)
    def claim(index):
        ready.wait(timeout=10)
        try:
            return store.offer(f'req-{index}',f'offer-{index}','driver-1',f'order-{index}')
        except Conflict:
            return None
    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
        results = list(pool.map(claim,range(12)))
    winners = [x for x in results if x is not None]
    assert len(winners)==1, winners
    assert len(store.rows())==1
    return {'scenario':'12 simultaneous SQLite connections offer same driver','winners':len(winners),'rows':store.rows()}


def scenario_late(root):
    now = [1000]
    store = Store(root/'late.sqlite', clock_ms=lambda:now[0])
    store.initialize(['driver-1'])
    old = store.offer('r1','a1','driver-1','order-1')
    now[0] = 6000
    deadline_accept = store.accept('a1','driver-1',old['generation'])
    current = store.offer('r2','a2','driver-1','order-2')
    now[0] = 6001
    old_accept = store.accept('a1','driver-1',old['generation'])
    new_accept = store.accept('a2','driver-1',current['generation'])
    now[0] = 100000
    try:
        store.offer('r3','a3','driver-1','order-3')
        accepted_expired = True
    except Conflict:
        accepted_expired = False
    assert (deadline_accept,old_accept,new_accept,accepted_expired)==(0,0,1,False)
    assert store.rows()[1]['state']=='accepted'
    return {'scenario':'deadline equality, old acknowledgment after re-offer, accepted retention','deadline_accept_rows':deadline_accept,'stale_ack_rows':old_accept,'current_ack_rows':new_accept,'accepted_slot_reoffered':accepted_expired,'rows':store.rows()}


def scenario_order_race(root):
    store=Store(root/'order-race.sqlite',clock_ms=lambda:1000)
    store.initialize(['d1','d2'])
    ready=threading.Barrier(2)
    def claim(driver):
        ready.wait(timeout=5)
        try:
            return store.offer('r-'+driver,'o-'+driver,driver,'same-order')
        except Conflict:
            return None
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        winners=[x for x in pool.map(claim,['d1','d2']) if x is not None]
    assert len(winners)==1
    loser=({'d1','d2'}-{winners[0]['driver_id']}).pop()
    free=store.offer('r-free','o-free',loser,'different-order')
    assert free['generation']==1, 'failed transaction consumed generation'
    old=winners[0]
    assert store.release(old['id'],old['generation'])==1
    new=store.offer('r-next','o-next',old['driver_id'],'new-order')
    assert store.release(old['id'],old['generation'])==0
    assert store.accept(old['id'],old['driver_id'],old['generation'])==0
    assert store.accept(new['id'],new['driver_id'],new['generation'])==1
    return {'scenario':'two drivers for one order; rollback and stale release',
            'winners':len(winners),'loser_next_generation':free['generation'],
            'stale_release_rows':0,'stale_accept_rows':0,'new_accept_rows':1,'rows':store.rows()}


if __name__=='__main__':
    with tempfile.TemporaryDirectory() as tmp:
        results = [scenario_race(pathlib.Path(tmp)),scenario_late(pathlib.Path(tmp)),scenario_order_race(pathlib.Path(tmp))]
    print(json.dumps({'pass':True,'results':results},indent=2))
