import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

from shortlink import Service


class RetentionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'links.db'
        self.now = 1000
        self.service = Service(self.path, clock=lambda: self.now)

    def test_expired_mapping_purged_but_retry_result_retained(self):
        old = self.service.create('alice', 'key', 'https://example.org/a', 1100).body['code']
        self.now = 1100
        self.assertEqual({'requests_deleted': 0, 'links_deleted': 1}, self.service.purge())
        replay = self.service.create('alice', 'key', 'https://example.org/a', 1100)
        self.assertEqual((200, old), (replay.status, replay.body['code']))
        self.assertEqual(404, self.service.resolve(old).status)

    def test_counter_prevents_old_code_reactivation_after_full_purge(self):
        old = self.service.create('alice', 'key', 'https://example.org/a', 1100).body['code']
        self.now += Service.MAX_LIFETIME
        purged = self.service.purge()
        reopened = Service(self.path, clock=lambda: self.now)
        new = reopened.create('bob', 'key', 'https://example.org/b', self.now + 100).body['code']
        observation = {'scenario': 'purge_then_reopen', 'old_code': old, 'new_code': new,
                       'old_status': reopened.resolve(old).status,
                       'new_status': reopened.resolve(new).status, 'purged': purged}
        print(json.dumps(observation))
        self.assertNotEqual(old, new)
        self.assertEqual(404, reopened.resolve(old).status)
        self.assertEqual(302, reopened.resolve(new).status)
        self.assertEqual({'requests_deleted': 1, 'links_deleted': 1}, purged)
        with sqlite3.connect(self.path) as db:
            self.assertEqual((1, 2), db.execute('SELECT count(*), max(value) FROM counters').fetchone())

    def test_purge_batch_does_not_remove_live_links(self):
        expired = [self.service.create('alice', f'k{i}', f'https://example.org/{i}', 1100).body['code']
                   for i in range(3)]
        live = self.service.create('alice', 'live', 'https://example.org/live', 2000).body['code']
        self.now = 1100
        self.assertEqual(2, self.service.purge(limit=2)['links_deleted'])
        with sqlite3.connect(self.path) as db:
            self.assertEqual(2, db.execute('SELECT count(*) FROM links').fetchone()[0])
        self.assertEqual(302, self.service.resolve(live).status)
        self.assertTrue(all(self.service.resolve(code).status == 404 for code in expired))


if __name__ == '__main__':
    unittest.main(verbosity=2)
