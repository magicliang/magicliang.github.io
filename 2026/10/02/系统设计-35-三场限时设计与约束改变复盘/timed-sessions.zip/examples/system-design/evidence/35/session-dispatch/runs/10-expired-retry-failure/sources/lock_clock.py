"""Real lock wait: a pre-lock timestamp can authorize an already expired offer."""
import concurrent.futures
import json
import pathlib
import tempfile
import threading
import time
from dispatch import Store


def clock_ms():
    return time.time_ns()//1_000_000


with tempfile.TemporaryDirectory() as tmp:
    store = Store(pathlib.Path(tmp)/'clock.sqlite')
    store.initialize(['driver-1'])
    now = clock_ms()
    offer = store.offer('r1','a1','driver-1','order-1')
    with store.transaction() as db:
        deadline = clock_ms()+100
        db.execute('UPDATE offer SET expires_ms=? WHERE id=\'a1\'',(deadline,))
    attempted = threading.Event()
    observed = {}
    def confirm():
        observed['sampled_before_lock_ms'] = clock_ms()
        attempted.set()
        observed['updated_rows'] = store.accept('a1','driver-1',offer['generation'])
        observed['returned_ms'] = clock_ms()
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        with store.transaction():
            job = pool.submit(confirm)
            assert attempted.wait(timeout=2)
            waited_from = time.monotonic()
            # Real fault injection, not design-session padding.
            time.sleep(0.25)
            observed['fault_injection_wait_s'] = time.monotonic()-waited_from
        job.result(timeout=5)
    observed.update(deadline_ms=deadline,rows=store.rows(),scenario='confirm blocks behind SQLite write lock until after deadline')
    print(json.dumps(observed,indent=2),flush=True)
    assert observed['sampled_before_lock_ms']<deadline<observed['returned_ms']
    assert observed['updated_rows']==0, 'stale pre-lock time accepted an expired offer'
