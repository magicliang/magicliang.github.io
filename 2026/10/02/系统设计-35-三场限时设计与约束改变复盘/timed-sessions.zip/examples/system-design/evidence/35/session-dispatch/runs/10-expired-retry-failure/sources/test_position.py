import json
from position import LatestPositions, Position

store=LatestPositions()
epoch=store.open_session('d')
new=Position(epoch,2,10000,100,10100,1.0,2.0)
assert store.report('d',new)
old=Position(epoch,1,9500,100,10200,9.0,9.0)
assert not store.report('d',old)
assert store.values['d']==new
assert store.eligible('d',14900)
assert not store.eligible('d',14901)
late=Position(epoch,3,10001,100,20000,1.1,2.1)
assert store.report('d',late)
naive_age=20000-late.received_ms
assert naive_age==0
assert not store.eligible('d',20000)
epoch2=store.open_session('d')
assert not store.report('d',Position(epoch,999,21000,100,21100,3.0,4.0))
assert store.report('d',Position(epoch2,1,21000,100,21100,3.0,4.0))
assert store.eligible('d',21100)
print(json.dumps({'pass':True,'out_of_order_rejected':True,'conservative_deadline_ms':14900,'late_report_naive_age_ms':naive_age,'late_report_sample_age_upper_ms':10099,'late_report_eligible':False,'old_session_rejected':True,'new_session_eligible':True},indent=2))
