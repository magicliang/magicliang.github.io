"""Local state model. now_ms is trusted test/server time, never a client timestamp."""
import contextlib
import sqlite3
import time

SCHEMA = '''
CREATE TABLE driver(id TEXT PRIMARY KEY, generation INTEGER NOT NULL DEFAULT 0);
CREATE TABLE offer(
 id TEXT PRIMARY KEY,
 request_id TEXT NOT NULL UNIQUE,
 driver_id TEXT NOT NULL REFERENCES driver(id),
 order_id TEXT NOT NULL,
 generation INTEGER NOT NULL,
 state TEXT NOT NULL CHECK(state IN ('offered','accepted','expired','cancelled','completed')),
 created_ms INTEGER NOT NULL,
 expires_ms INTEGER NOT NULL CHECK(expires_ms > created_ms)
);
CREATE TABLE outbox(
 event_id TEXT PRIMARY KEY,
 offer_id TEXT NOT NULL REFERENCES offer(id),
 kind TEXT NOT NULL CHECK(kind='offered'),
 delivered INTEGER NOT NULL DEFAULT 0 CHECK(delivered IN (0,1))
);
CREATE UNIQUE INDEX one_live_offer_per_driver ON offer(driver_id)
 WHERE state IN ('offered','accepted');
CREATE UNIQUE INDEX one_live_offer_per_order ON offer(order_id)
 WHERE state IN ('offered','accepted');
'''


class Conflict(Exception):
    pass


class Store:
    def __init__(self, path, clock_ms=None):
        self.path = path
        self.clock_ms = clock_ms or (lambda: time.time_ns()//1_000_000)

    def connect(self):
        db = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        return db

    def initialize(self, drivers):
        with contextlib.closing(self.connect()) as db:
            db.executescript(SCHEMA)
            db.executemany('INSERT INTO driver(id) VALUES(?)', ((x,) for x in drivers))

    @contextlib.contextmanager
    def transaction(self):
        with contextlib.closing(self.connect()) as db:
            db.execute('BEGIN IMMEDIATE')
            try:
                yield db
            except BaseException:
                db.rollback()
                raise
            else:
                db.commit()

    def offer(self, request_id, offer_id, driver_id, order_id):
        with self.transaction() as db:
            now_ms = self.clock_ms()
            previous = db.execute('SELECT * FROM offer WHERE request_id=?', (request_id,)).fetchone()
            if previous:
                if (previous['driver_id'], previous['order_id']) != (driver_id, order_id):
                    raise Conflict('idempotency key reused with different payload')
                return dict(previous)
            db.execute('''UPDATE offer SET state='expired'
                          WHERE state='offered' AND expires_ms<=?
                          AND (driver_id=? OR order_id=?)''', (now_ms, driver_id, order_id))
            generation = db.execute('''UPDATE driver SET generation=generation+1 WHERE id=?
                AND NOT EXISTS(SELECT 1 FROM offer WHERE driver_id=? AND state IN ('offered','accepted'))
                RETURNING generation''', (driver_id, driver_id)).fetchone()
            if generation is None:
                raise Conflict('driver unavailable')
            try:
                db.execute('INSERT INTO offer VALUES(?,?,?,?,?,\'offered\',?,?)',
                           (offer_id, request_id, driver_id, order_id, generation[0], now_ms, now_ms+5000))
            except sqlite3.IntegrityError as error:
                raise Conflict('order or offer identity unavailable') from error
            db.execute("INSERT INTO outbox(event_id,offer_id,kind) VALUES(?,?, 'offered')",
                       (offer_id+':offered', offer_id))
            return dict(db.execute('SELECT * FROM offer WHERE id=?', (offer_id,)).fetchone())

    def accept(self, offer_id, driver_id, generation):
        with self.transaction() as db:
            now_ms = self.clock_ms()
            changed = db.execute('''UPDATE offer SET state='accepted'
                WHERE id=? AND driver_id=? AND generation=? AND state='offered' AND expires_ms>?
                AND generation=(SELECT generation FROM driver WHERE id=?)''',
                (offer_id, driver_id, generation, now_ms, driver_id)).rowcount
            return changed

    def release(self, offer_id, generation, terminal='cancelled'):
        if terminal not in ('cancelled', 'completed'):
            raise ValueError('invalid terminal state')
        with self.transaction() as db:
            return db.execute('''UPDATE offer SET state=? WHERE id=? AND generation=?
                                 AND state IN ('offered','accepted')''',
                              (terminal, offer_id, generation)).rowcount

    def pending_events(self):
        with contextlib.closing(self.connect()) as db:
            return [dict(row) for row in db.execute('''SELECT outbox.event_id, offer.* FROM outbox
                JOIN offer ON outbox.offer_id=offer.id WHERE delivered=0 ORDER BY event_id''')]

    def mark_delivered(self, event_id):
        with self.transaction() as db:
            return db.execute('UPDATE outbox SET delivered=1 WHERE event_id=? AND delivered=0',
                              (event_id,)).rowcount

    def rows(self):
        with contextlib.closing(self.connect()) as db:
            return [dict(row) for row in db.execute('SELECT * FROM offer ORDER BY id')]
