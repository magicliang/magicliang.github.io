# 数据路径与故障边界

最小服务保留一个 SQL 权威。一次创建先用 BEGIN IMMEDIATE 进入写事务，查询 owner 与 request_key；已有记录时比较请求指纹，返回原短码或冲突；没有记录时尝试 INSERT links，遇到短码唯一键冲突最多重新生成五次，然后 INSERT requests 并 COMMIT。请求指纹包含精确目标 URL 与绝对到期秒数，因此客户端重试必须复用原过期时间，不能每次重新计算相对 TTL。

```mermaid
sequenceDiagram
    participant C as 创建客户端
    participant A as API
    participant D as SQL权威
    C->>A: POST target, expires_at, request_key
    A->>D: BEGIN IMMEDIATE
    A->>D: 查询幂等键并写 links + requests
    A->>D: COMMIT
    D-->>A: 已提交
    A--xC: 响应丢失
    C->>A: 原键和原正文重试
    A->>D: 读取原请求记录
    D-->>A: 原 code
    A-->>C: 200, 原 code
```

failures-02 实际启动了四个独立子进程，在创建与撤销的 COMMIT 前后执行 os._exit(73)。创建提交前终止后两表均无新行；提交后终止后重试得到原 code。撤销提交前终止后仍可重定向，客户端未收到成功，应重试；撤销提交后终止后重读返回 404，重复撤销不再增加 version。这些结果覆盖进程退出，不覆盖机器断电、文件系统失效或三副本选主。

同幂等键的十二路连接在屏障后同时请求。相同正文得到一次 201、十一次 200，只有一个短码和一条 links 记录；不同正文得到一次 201、十一次 409。已读出旧状态的请求在撤销确认后才返回 302 的交错被单独复现，新请求则返回 404。当前撤销契约以新请求开始时间为边界，不声称网络上已经发出的重定向能够回收。

读路径每次创建新连接并执行单条 SELECT，检查 revoked_at 与 expires_at，权威不可读时返回 503。unsafe-07 实测了三个反例：跳过权威的热缓存仍返回 302；复用撤销前已开启的 WAL 读事务仍看到 revoked_at=NULL；直接删除墓碑和幂等记录后重用短码，会让旧 URL 指向另一个所有者。第三个反例说明“30 天活跃数据”不足以描述长期短码防复用成本，物理清理方案仍待补齐。

HTTP 适配只绑定 127.0.0.1，X-Lab-Owner 是测试身份夹具，不构成认证实现。实际 HTTP 客户端验证了 302、Location、Cache-Control: no-store、撤销后无 Location、到期边界及提交后断开连接重试。数字类型、非 ASCII、空白与非法端口输入返回 400；选择 ASCII 合约可避免 Location 头编码含糊，国际化 URL 的预编码交给调用方。本地适配没有 TLS、代理缓存、浏览器或生产认证测试。

第 12 篇与其实验作为先修材料读取；未读取第 35 篇现成答案。规范复核使用 [SQLite 隔离](https://www.sqlite.org/isolation.html)、[事务](https://www.sqlite.org/lang_transaction.html)、[RFC 9111 no-store](https://www.rfc-editor.org/rfc/rfc9111#section-5.2.2.5) 和 [RFC 9110 Content-Length](https://www.rfc-editor.org/rfc/rfc9110.html#section-8.6)。最后一项复核后移除了 204 响应的 Content-Length，并通过 http-wire-08 四项完整协议回归。

截至此记录，仍未接收新的约束。后续设计工作是计算幂等表、索引与防复用记录的成本，并判断三副本部署的确认点和单库故障边界；不会把 SQLite 文件持久化称为三副本验证。
