import json
import pathlib
import subprocess
import sys
import tempfile
from dispatch import Conflict, Store

LAB=pathlib.Path(__file__).resolve().parent
results=[]
with tempfile.TemporaryDirectory() as tmp:
    root=pathlib.Path(tmp)
    for point,expected_exit,expected_count in [('before',23,0),('after',24,1)]:
        path=root/(point+'.sqlite')
        store=Store(path,clock_ms=lambda:1100)
        store.initialize(['driver-1'])
        command=[sys.executable,str(LAB/'crash_child.py'),str(path),point]
        child=subprocess.run(command,text=True,capture_output=True)
        before_retry=store.rows()
        outbox=store.pending_events()
        assert child.returncode==expected_exit
        assert len(before_retry)==len(outbox)==expected_count
        retried=store.offer('request-1','new-generated-id','driver-1','order-1')
        assert len(store.rows())==len(store.pending_events())==1
        if point=='after':
            assert retried['id']=='offer-1'
            assert retried['generation']==1
        try:
            store.offer('request-1','different-id','driver-1','different-order')
            raise AssertionError('idempotency key changed payload')
        except Conflict:
            pass
        first_ack=store.accept(retried['id'],'driver-1',retried['generation'])
        duplicate_ack=store.accept(retried['id'],'driver-1',retried['generation'])
        assert (first_ack,duplicate_ack)==(1,0)
        assert store.rows()[0]['state']=='accepted'
        events=store.pending_events()
        received_ids=set()
        applications=0
        # First delivery succeeds, publisher loses its acknowledgment and retries.
        for event in events+events:
            if event['event_id'] not in received_ids:
                received_ids.add(event['event_id'])
                applications+=1
        assert applications==1
        assert store.mark_delivered(events[0]['event_id'])==1
        assert store.mark_delivered(events[0]['event_id'])==0
        assert store.pending_events()==[]
        results.append({'scenario':point+' commit process crash','command':command,'child_exit':child.returncode,
                        'child_stdout':child.stdout,'child_stderr':child.stderr,'rows_after_crash':before_retry,
                        'pending_events_after_crash':outbox,'retry':retried,'first_ack_rows':first_ack,
                        'duplicate_ack_rows':duplicate_ack,'authoritative_retry_state':'accepted',
                        'local_duplicate_deliveries':2,'local_effects':applications})
print(json.dumps({'pass':True,'results':results,'boundary':'real process exit and SQLite recovery; delivery deduplication is in-memory model, not network proof'},indent=2))
