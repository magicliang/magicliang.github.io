from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import threading
import unittest

from shortlink import Service


class FailureTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'links.db'
        self.service = Service(self.path, clock=lambda: 1000)

    def test_concurrent_same_key_returns_one_code(self):
        barrier = threading.Barrier(12, timeout=10)
        def create(_):
            barrier.wait()
            return self.service.create('alice', 'same-key', 'https://example.org/a', 2000)
        with ThreadPoolExecutor(max_workers=12) as pool:
            replies = list(pool.map(create, range(12)))
        statuses = [r.status for r in replies]
        codes = {r.body['code'] for r in replies}
        with sqlite3.connect(self.path) as db:
            rows = db.execute('SELECT count(*) FROM links').fetchone()[0]
        observation = {'scenario': 'concurrent_identical', 'created': statuses.count(201),
                       'replayed': statuses.count(200), 'distinct_codes': len(codes), 'rows': rows}
        print(json.dumps(observation))
        self.assertEqual((1, 11, 1, 1), (statuses.count(201), statuses.count(200), len(codes), rows))

    def test_concurrent_same_key_different_payload_conflicts(self):
        barrier = threading.Barrier(12, timeout=10)
        def create(i):
            barrier.wait()
            return self.service.create('alice', 'same-key', f'https://example.org/{i}', 2000)
        with ThreadPoolExecutor(max_workers=12) as pool:
            replies = list(pool.map(create, range(12)))
        statuses = [r.status for r in replies]
        print(json.dumps({'scenario': 'concurrent_different', 'created': statuses.count(201),
                          'conflicts': statuses.count(409)}))
        self.assertEqual((1, 11), (statuses.count(201), statuses.count(409)))

    def crash(self, action, event, code='unused'):
        result = subprocess.run([sys.executable, str(Path(__file__).with_name('crash_child.py')),
                                 str(self.path), action, event, code], capture_output=True, text=True)
        print(result.stdout.strip())
        self.assertEqual(73, result.returncode, result.stderr)

    def test_process_death_before_create_commit_rolls_back(self):
        self.crash('create', 'before_create_commit')
        with sqlite3.connect(self.path) as db:
            self.assertEqual(0, db.execute('SELECT count(*) FROM links').fetchone()[0])
            self.assertEqual(0, db.execute('SELECT count(*) FROM requests').fetchone()[0])
        self.assertEqual(201, self.service.create('alice', 'request-1', 'https://example.org/a', 2000).status)

    def test_process_death_after_create_commit_replays(self):
        self.crash('create', 'after_create_commit')
        reply = self.service.create('alice', 'request-1', 'https://example.org/a', 2000)
        self.assertEqual(200, reply.status)
        self.assertEqual('fixed-code', reply.body['code'])
        self.assertEqual(302, self.service.resolve('fixed-code').status)

    def test_process_death_before_revoke_commit_does_not_ack(self):
        code = self.service.create('alice', 'request-1', 'https://example.org/a', 2000).body['code']
        self.crash('revoke', 'before_revoke_commit', code)
        self.assertEqual(302, self.service.resolve(code).status)
        self.assertEqual(204, self.service.revoke('alice', code).status)
        self.assertEqual(404, self.service.resolve(code).status)

    def test_process_death_after_revoke_commit_remains_revoked(self):
        code = self.service.create('alice', 'request-1', 'https://example.org/a', 2000).body['code']
        self.crash('revoke', 'after_revoke_commit', code)
        self.assertEqual(404, self.service.resolve(code).status)
        self.assertEqual(204, self.service.revoke('alice', code).status)
        with sqlite3.connect(self.path) as db:
            self.assertEqual(2, db.execute('SELECT version FROM links WHERE code=?', (code,)).fetchone()[0])

    def test_inflight_read_may_finish_after_revoke_ack(self):
        read_done, allow_response = threading.Event(), threading.Event()
        code = self.service.create('alice', 'request-1', 'https://example.org/a', 2000).body['code']
        def hold(event):
            if event == 'after_resolve_read':
                read_done.set()
                if not allow_response.wait(5):
                    raise TimeoutError('test scheduler did not release read')
        self.service.hook = hold
        with ThreadPoolExecutor(max_workers=1) as pool:
            response = pool.submit(self.service.resolve, code)
            try:
                self.assertTrue(read_done.wait(5))
                self.assertEqual(204, self.service.revoke('alice', code).status)
                self.assertEqual(404, self.service.resolve(code).status)
            finally:
                allow_response.set()
            inflight = response.result(timeout=5)
        print(json.dumps({'scenario': 'inflight_boundary', 'inflight_status': inflight.status,
                          'new_request_status': self.service.resolve(code).status}))
        self.assertEqual(302, inflight.status)


if __name__ == '__main__':
    unittest.main(verbosity=2)
