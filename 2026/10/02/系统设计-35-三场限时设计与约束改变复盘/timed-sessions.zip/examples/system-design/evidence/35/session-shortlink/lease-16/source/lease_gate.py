"""Finite local model of leases and an independent durable revocation journal.

The clock is injected to explore boundaries, not to measure distributed clocks.
The journal must outlive restored link snapshots. The model has no consensus.
"""
from contextlib import closing
from dataclasses import dataclass
import sqlite3

from shortlink import Reply, Service


@dataclass(frozen=True)
class Lease:
    code: str
    target: str
    expires_at: float


class LeaseAuthority:
    def __init__(self, service, journal_path, clock, lease_seconds=1.0, clock_error=0.05):
        self.service = service
        self.journal_path = str(journal_path)
        self.clock = clock
        self.lease_seconds = lease_seconds
        self.clock_error = clock_error
        self.ready = False
        self.grant_queries = 0
        with closing(self.journal()) as db:
            db.execute('CREATE TABLE IF NOT EXISTS revocations '
                       '(code TEXT PRIMARY KEY NOT NULL, confirm_after REAL NOT NULL)')
        self.recover()

    def journal(self):
        db = sqlite3.connect(self.journal_path, isolation_level=None, timeout=3)
        db.execute('PRAGMA synchronous=FULL')
        return db

    def recover(self):
        self.ready = False
        try:
            with closing(self.journal()) as journal:
                journal.execute('BEGIN IMMEDIATE')
                revoked = journal.execute('SELECT code FROM revocations').fetchall()
                with closing(self.service.connect()) as links:
                    links.execute('BEGIN IMMEDIATE')
                    links.executemany('UPDATE links SET revoked_at=COALESCE(revoked_at,?), '
                                      'version=CASE WHEN revoked_at IS NULL THEN version+1 ELSE version END '
                                      'WHERE code=?', [(int(self.clock()), code) for (code,) in revoked])
                    links.execute('COMMIT')
                journal.execute('COMMIT')
            self.ready = True
        except sqlite3.Error:
            return False
        return True

    def grant(self, code):
        self.grant_queries += 1
        if not self.ready:
            return None
        try:
            with closing(self.journal()) as db:
                db.execute('BEGIN IMMEDIATE')
                if db.execute('SELECT 1 FROM revocations WHERE code=?', (code,)).fetchone():
                    db.execute('ROLLBACK')
                    return None
                # Deadline is anchored before the read; a delayed reply cannot extend it.
                issued = self.clock()
                with closing(self.service.connect()) as links:
                    row = links.execute('SELECT target,expires_at,revoked_at FROM links WHERE code=?',
                                        (code,)).fetchone()
                if not row or row[2] is not None or row[1] <= issued:
                    db.execute('ROLLBACK')
                    return None
                lease = Lease(code, row[0], min(issued + self.lease_seconds, row[1]))
                db.execute('COMMIT')
                return lease
        except sqlite3.Error:
            self.ready = False
            return None

    def revoke(self, owner, code):
        if not self.ready:
            return Reply(503)
        try:
            with closing(self.journal()) as db:
                db.execute('BEGIN IMMEDIATE')
                with closing(self.service.connect()) as links:
                    row = links.execute('SELECT owner FROM links WHERE code=?', (code,)).fetchone()
                if not row or row[0] != owner:
                    db.execute('ROLLBACK')
                    return Reply(404)
                # Ledger first: a crash before updating links still blocks future grants.
                deadline = self.clock() + self.lease_seconds + 2 * self.clock_error
                db.execute('INSERT OR IGNORE INTO revocations(code,confirm_after) VALUES(?,?)',
                           (code, deadline))
                deadline = db.execute('SELECT confirm_after FROM revocations WHERE code=?', (code,)).fetchone()[0]
                db.execute('COMMIT')
            self.service.revoke(owner, code)
            if self.clock() < deadline:
                return Reply(202, {'state': 'pending', 'confirm_after': deadline})
            return Reply(204)
        except sqlite3.Error:
            self.ready = False
            return Reply(503)


class Reader:
    def __init__(self, authority, clock, clock_error=0.05):
        self.authority = authority
        self.clock = clock
        self.clock_error = clock_error
        self.connected = True
        self.clock_trusted = True
        self.cache = {}

    def resolve(self, code):
        if not self.clock_trusted:
            return Reply(503)
        lease = self.cache.get(code)
        if lease is None or self.clock() + self.clock_error >= lease.expires_at:
            if not self.connected:
                return Reply(503)
            lease = self.authority.grant(code)
            if lease is None:
                return Reply(503)
            self.cache[code] = lease
        if self.clock() + self.clock_error >= lease.expires_at:
            return Reply(503)
        return Reply(302, headers={'Location': lease.target, 'Cache-Control': 'no-store'})
