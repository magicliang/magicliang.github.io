"""Run each distinct regression once; no timers or throughput claims."""
import json
import pathlib
import subprocess
import sys
import time

lab=pathlib.Path(__file__).resolve().parent
results=[]
for name,expected in [('naive.py',1),('test_dispatch.py',0),('lock_clock.py',0),('test_position.py',0),('test_position_reservation.py',0),('test_recovery.py',0),('test_retry_expiry.py',0),('test_transitions.py',0)]:
    command=[sys.executable,str(lab/name)]
    started=time.monotonic()
    result=subprocess.run(command,text=True,capture_output=True)
    item={'file':name,'command':command,'exit_code':result.returncode,'expected_exit':expected,
          'elapsed_s':time.monotonic()-started,'stdout':result.stdout,'stderr':result.stderr}
    results.append(item)
    if result.returncode!=expected:
        print(json.dumps({'pass':False,'results':results},indent=2))
        raise SystemExit(1)
print(json.dumps({'pass':True,'results':results},indent=2))
