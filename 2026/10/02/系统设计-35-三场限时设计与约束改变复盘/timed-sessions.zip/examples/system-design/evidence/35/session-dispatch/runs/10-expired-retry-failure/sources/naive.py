"""Deliberately broken check-then-write; the invariant assertion must fail."""
import concurrent.futures
import json
import pathlib
import sqlite3
import tempfile
import threading


def reproduce():
    with tempfile.TemporaryDirectory() as tmp:
        path = pathlib.Path(tmp)/'naive.sqlite'
        with sqlite3.connect(path) as db:
            db.executescript('CREATE TABLE driver(id PRIMARY KEY, state, owner);'
                             'INSERT INTO driver VALUES(1,"idle",NULL);'
                             'CREATE TABLE offer(id PRIMARY KEY,driver_id,state);')
        ready = threading.Barrier(2)
        def claim(offer):
            with sqlite3.connect(path, timeout=5) as db:
                available = db.execute('SELECT state FROM driver WHERE id=1').fetchone()[0]=='idle'
                ready.wait(timeout=5)
                if available:
                    db.execute('INSERT INTO offer VALUES(?,1,"offered")',(offer,))
                    db.execute('UPDATE driver SET state="offered",owner=? WHERE id=1',(offer,))
                    return True
                return False
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            outcomes = list(pool.map(claim, ('A','B')))
        with sqlite3.connect(path) as db:
            offers = db.execute('SELECT * FROM offer ORDER BY id').fetchall()
            slot = db.execute('SELECT * FROM driver').fetchall()
        print(json.dumps({'scenario':'two real threads read idle before either commits',
                          'outcomes':outcomes,'offers':offers,'driver':slot,
                          'active_offers_for_one_driver':len(offers)},indent=2),flush=True)
        assert len(offers)<=1, 'one driver now has two valid offers'


if __name__=='__main__':
    reproduce()
