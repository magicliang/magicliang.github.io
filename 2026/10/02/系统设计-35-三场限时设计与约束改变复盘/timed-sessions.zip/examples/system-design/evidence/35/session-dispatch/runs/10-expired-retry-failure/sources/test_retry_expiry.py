import json
import pathlib
import tempfile
from dispatch import Store

with tempfile.TemporaryDirectory() as tmp:
    now=[1000]
    store=Store(pathlib.Path(tmp)/'retry.sqlite',clock_ms=lambda:now[0])
    store.initialize(['d'])
    first=store.offer('request-1','offer-1','d','order-1')
    now[0]=6000
    retried=store.offer('request-1','unused-new-id','d','order-1')
    print(json.dumps({'scenario':'same idempotency key retried exactly at expiry','first':first,'retried':retried},indent=2),flush=True)
    assert retried['id']==first['id']
    assert retried['generation']==first['generation']
    assert retried['state']=='expired','retry reports raw offered state after its deadline'
