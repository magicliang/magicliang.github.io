"""Create a non-overwriting stage snapshot at its actual capture time."""
import datetime
import hashlib
import json
import pathlib
import shutil
import sys
import time

LAB = pathlib.Path(__file__).resolve().parent
ROOT = LAB.parents[4]
EVIDENCE = ROOT/'examples/system-design/evidence/35/session-dispatch'
start = json.loads((EVIDENCE/'00-start.json').read_text())
stage, decision = sys.argv[1:]
now = time.monotonic()
destination = EVIDENCE/'stages'/stage
destination.mkdir(parents=True, exist_ok=False)
artifacts = {}
for source in sorted(LAB.rglob('*')):
    if source.is_file() and '__pycache__' not in source.parts:
        target = destination/source.relative_to(LAB)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        artifacts[str(target.relative_to(ROOT))] = hashlib.sha256(target.read_bytes()).hexdigest()
receipt = {'author':'AI assistant','stage':stage,'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'captured_monotonic':now,'elapsed_s':now-start['start_monotonic'],'decision':decision,'sha256':artifacts}
(destination/'stage.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
