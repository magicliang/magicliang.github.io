import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

from lease_gate import LeaseAuthority, Reader
from shortlink import Service


class LeaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.now = 1000.0
        self.service = Service(self.root / 'links.db', clock=lambda: self.now)
        self.code = self.service.create('alice', 'key', 'https://example.org/a', 2000).body['code']
        self.authority = LeaseAuthority(self.service, self.root / 'revocations.db', lambda: self.now)
        self.reader = Reader(self.authority, lambda: self.now)

    def test_partitioned_reader_stops_before_revoke_confirmation(self):
        self.assertEqual(302, self.reader.resolve(self.code).status)
        self.reader.connected = False
        self.now = 1000.2
        pending = self.authority.revoke('alice', self.code)
        self.assertEqual(202, pending.status)
        self.assertEqual(302, self.reader.resolve(self.code).status)
        self.now = 1001.31
        confirmed = self.authority.revoke('alice', self.code)
        denied = self.reader.resolve(self.code)
        print(json.dumps({'scenario':'partition_after_revoke', 'pending':pending.status,
                          'confirmed':confirmed.status,'partitioned_new_request':denied.status,
                          'confirm_after':pending.body['confirm_after']}))
        self.assertEqual(204, confirmed.status)
        self.assertEqual(503, denied.status)
        self.assertNotIn('Location', denied.headers)

    def test_journal_recovery_prevents_old_snapshot_resurrection(self):
        backup_path = self.root / 'old.db'
        with sqlite3.connect(self.service.path) as source, sqlite3.connect(backup_path) as backup:
            source.backup(backup)
        self.assertEqual(202, self.authority.revoke('alice', self.code).status)
        self.now = 1002
        self.assertEqual(204, self.authority.revoke('alice', self.code).status)
        restored_service = Service(backup_path, clock=lambda: self.now)
        self.assertEqual(302, restored_service.resolve(self.code).status)
        restored = LeaseAuthority(restored_service, self.root / 'revocations.db', lambda: self.now)
        reader = Reader(restored, lambda: self.now)
        self.assertTrue(restored.ready)
        self.assertEqual(404, restored_service.resolve(self.code).status)
        self.assertEqual(503, reader.resolve(self.code).status)
        print(json.dumps({'scenario':'fenced_restore', 'unsafe_before_replay':302,
                          'after_replay':restored_service.resolve(self.code).status,
                          'lease_path':reader.resolve(self.code).status}))

    def test_missing_journal_table_never_marks_recovery_ready(self):
        journal_path = Path(self.authority.journal_path)
        journal_path.rename(journal_path.with_suffix('.offline'))
        journal_path.mkdir()
        self.assertFalse(self.authority.recover())
        self.assertFalse(self.authority.ready)
        self.assertIsNone(self.authority.grant(self.code))

    def test_clock_uncertainty_fails_closed_even_with_hot_lease(self):
        self.assertEqual(302, self.reader.resolve(self.code).status)
        self.reader.clock_trusted = False
        self.assertEqual(503, self.reader.resolve(self.code).status)

    def test_hot_key_requests_amortize_authority_reads(self):
        codes = [self.service.create('alice', f'cold-{i}', f'https://example.org/{i}', 2000).body['code']
                 for i in range(2000)]
        readers = [Reader(self.authority, lambda: self.now) for _ in range(20)]
        statuses = [readers[i % 20].resolve(self.code).status for i in range(18000)]
        statuses += [readers[i % 20].resolve(code).status for i, code in enumerate(codes)]
        print(json.dumps({'scenario':'fixed_clock_20000_request_set','requests':len(statuses),
                          'hot_requests':18000,'holders':20,'grant_queries':self.authority.grant_queries,
                          'given_capacity_per_s':5000,'measured_throughput':False}))
        self.assertEqual(20000, statuses.count(302))
        self.assertEqual(2020, self.authority.grant_queries)


if __name__ == '__main__':
    unittest.main(verbosity=2)
