"""Verify captured bytes and monotonic ordering, without treating reports as proof."""
import hashlib
import json
import pathlib
import sys

lab=pathlib.Path(__file__).resolve().parent
root=lab.parents[4]
ev=root/'examples/system-design/evidence/35/session-dispatch'
checked=0
runs=[]
for path in sorted((ev/'runs').glob('*/invocation.json')):
    invocation=json.loads(path.read_text())
    assert invocation['ended_monotonic']>=invocation['started_monotonic']
    assert invocation['source_sha256_before']==invocation['source_sha256_after']
    assert (path.parent/'stdout.txt').exists()
    assert (path.parent/'stderr.txt').exists()
    assert (path.parent/'stdout.txt').stat().st_size>0 or (path.parent/'stderr.txt').stat().st_size>0
    for source,digest in invocation['source_sha256_before'].items():
        relative=pathlib.Path(source).relative_to(lab.relative_to(root))
        archived=path.parent/'sources'/relative
        assert archived.is_file(), str(archived)
        assert hashlib.sha256(archived.read_bytes()).hexdigest()==digest,str(archived)
        checked+=1
    runs.append({'run':path.parent.name,'exit':invocation['exit_code'],'elapsed_s':invocation['elapsed_s']})
stages=[]
for path in sorted((ev/'stages').glob('*/stage.json')):
    stage=json.loads(path.read_text())
    for source,digest in stage['sha256'].items():
        assert hashlib.sha256((root/source).read_bytes()).hexdigest()==digest,source
        checked+=1
    stages.append({'stage':stage['stage'],'elapsed_s':stage['elapsed_s']})
if '--complete' in sys.argv:
    assert [x['stage'] for x in stages]==['05','13','25','40','45']
    assert stages[-1]['elapsed_s']>=2700
    constraint=json.loads((ev/'constraint.json').read_text())
    assert 1500<=constraint['received_elapsed_s']<stages[-1]['elapsed_s']
print(json.dumps({'pass':True,'mode':'complete' if '--complete' in sys.argv else 'partial',
                  'hashes_verified':checked,'runs':runs,'stages':stages},indent=2))
