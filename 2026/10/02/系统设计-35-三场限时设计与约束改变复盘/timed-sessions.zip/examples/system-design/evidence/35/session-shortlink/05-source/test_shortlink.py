import sqlite3
import tempfile
import unittest
from pathlib import Path

from shortlink import Service


class ShortlinkTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'links.db'
        self.now = 1000
        self.service = Service(self.path, clock=lambda: self.now)

    def create(self, key='request-1', target='https://example.org/a'):
        return self.service.create('alice', key, target, 2000)

    def test_create_redirect_expire(self):
        created = self.create()
        self.assertEqual(201, created.status)
        code = created.body['code']
        reply = self.service.resolve(code)
        self.assertEqual(302, reply.status)
        self.assertEqual('https://example.org/a', reply.headers['Location'])
        self.assertEqual('no-store', reply.headers['Cache-Control'])
        self.now = 1999
        self.assertEqual(302, self.service.resolve(code).status)
        self.now = 2000
        self.assertEqual(404, self.service.resolve(code).status)

    def test_same_key_same_payload_replays_one_row(self):
        first, second = self.create(), self.create()
        self.assertEqual([201, 200], [first.status, second.status])
        self.assertEqual(first.body['code'], second.body['code'])
        with sqlite3.connect(self.path) as db:
            self.assertEqual((1, 1), (db.execute('SELECT count(*) FROM links').fetchone()[0],
                                      db.execute('SELECT count(*) FROM requests').fetchone()[0]))

    def test_same_key_different_payload_conflicts(self):
        first = self.create()
        self.assertEqual(409, self.create(target='https://example.org/b').status)
        self.assertEqual('https://example.org/a', self.service.resolve(first.body['code']).headers['Location'])

    def test_revocation_is_owner_scoped_and_retry_safe(self):
        code = self.create().body['code']
        self.assertEqual(404, self.service.revoke('mallory', code).status)
        self.assertEqual(302, self.service.resolve(code).status)
        self.assertEqual(204, self.service.revoke('alice', code).status)
        self.assertEqual(204, self.service.revoke('alice', code).status)
        self.assertEqual(404, self.service.resolve(code).status)
        self.assertEqual(code, self.create().body['code'])
        self.assertEqual(404, self.service.resolve(code).status)
        with sqlite3.connect(self.path) as db:
            self.assertEqual(2, db.execute('SELECT version FROM links').fetchone()[0])

    def test_rollback_before_commit_leaves_no_orphan(self):
        def fail(event):
            if event == 'after_link_insert':
                raise RuntimeError('crash before request row')
        self.service.hook = fail
        with self.assertRaisesRegex(RuntimeError, 'crash'):
            self.create()
        with sqlite3.connect(self.path) as db:
            self.assertEqual(0, db.execute('SELECT count(*) FROM links').fetchone()[0])
            self.assertEqual(0, db.execute('SELECT count(*) FROM requests').fetchone()[0])
        self.service.hook = lambda event: None
        self.assertEqual(201, self.create().status)

    def test_response_loss_after_commit_can_retry(self):
        def fail(event):
            if event == 'after_create_commit':
                raise ConnectionError('response lost')
        self.service.hook = fail
        with self.assertRaisesRegex(ConnectionError, 'response lost'):
            self.create()
        reopened = Service(self.path, clock=lambda: self.now)
        replay = reopened.create('alice', 'request-1', 'https://example.org/a', 2000)
        self.assertEqual(200, replay.status)
        self.assertEqual(302, reopened.resolve(replay.body['code']).status)

    def test_candidate_collision_retries_without_overwrite(self):
        candidates = iter(['collision', 'collision', 'different'])
        self.service.candidate = lambda: next(candidates)
        first = self.create()
        second = self.create('request-2', 'https://example.org/b')
        self.assertEqual('collision', first.body['code'])
        self.assertEqual('different', second.body['code'])
        self.assertEqual('https://example.org/a', self.service.resolve('collision').headers['Location'])

    def test_invalid_urls_do_not_enter_location(self):
        for target in ['javascript:alert(1)', 'https://example.org/\r\nX-Foo:bar',
                       'https://user:password@example.org/a', 'https://[invalid']:
            with self.subTest(target=target):
                self.assertEqual(400, self.create(target=target).status)


if __name__ == '__main__':
    unittest.main(verbosity=2)
