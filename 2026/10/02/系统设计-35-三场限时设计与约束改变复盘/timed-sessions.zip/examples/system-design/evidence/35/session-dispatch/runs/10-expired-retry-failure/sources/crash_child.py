"""Crash at an explicit transaction boundary, using a separate Python process."""
import contextlib
import json
import os
import sys
from dispatch import Store


class CrashBeforeCommit(Store):
    @contextlib.contextmanager
    def transaction(self):
        with super().transaction() as db:
            yield db
            print(json.dumps({'fault':'os._exit before commit','pid':os.getpid()}),flush=True)
            os._exit(23)


path, point = sys.argv[1:]
store = (CrashBeforeCommit if point=='before' else Store)(path,clock_ms=lambda:1000)
result = store.offer('request-1','offer-1','driver-1','order-1')
print(json.dumps({'fault':'os._exit after commit before HTTP response','pid':os.getpid(),'offer':result}),flush=True)
os._exit(24)
