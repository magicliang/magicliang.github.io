"""Counterexample: independently owning a driver in each spatial-cell database."""
import json
import pathlib
import tempfile
from dispatch import Store

with tempfile.TemporaryDirectory() as tmp:
    path=pathlib.Path(tmp)
    cell_a=Store(path/'cell-a.sqlite',clock_ms=lambda:1000)
    cell_b=Store(path/'cell-b.sqlite',clock_ms=lambda:2000)
    for cell in [cell_a,cell_b]:
        cell.initialize(['moving-driver'])
    old=cell_a.offer('ra','oa','moving-driver','order-a')
    # Position moves to B while A's invitation still has four seconds left.
    new=cell_b.offer('rb','ob','moving-driver','order-b')
    live=[row for store in [cell_a,cell_b] for row in store.rows() if row['state'] in ('offered','accepted')]
    print(json.dumps({'scenario':'driver moves spatial cell during valid invitation','source_cell_offer':old,'destination_cell_offer':new,'effective_assignments_for_driver':len(live),'model_now_ms':2000},indent=2),flush=True)
    assert len(live)<=1,'cell-owned independent authority duplicated the same driver'
