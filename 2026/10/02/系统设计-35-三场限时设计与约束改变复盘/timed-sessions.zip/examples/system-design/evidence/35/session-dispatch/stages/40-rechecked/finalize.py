"""Write a receipt only after the real 45-minute checkpoint exists."""
import datetime
import hashlib
import json
import pathlib
import platform
import sqlite3
import time

lab=pathlib.Path(__file__).resolve().parent
root=lab.parents[4]
ev=root/'examples/system-design/evidence/35/session-dispatch'
start=json.loads((ev/'00-start.json').read_text())
constraint=json.loads((ev/'constraint.json').read_text())
stages=[json.loads((ev/'stages'/x/'stage.json').read_text()) for x in ['05','13','25','40-rechecked','45']]
assert stages[-1]['elapsed_s']>=2700
runs=[]
for path in sorted((ev/'runs').glob('*/invocation.json')):
    data=json.loads(path.read_text())
    runs.append({'path':str(path.relative_to(root)),'command':data['command'],'exit_code':data['exit_code'],
                 'elapsed_s':data['elapsed_s'],'stdout':str((path.parent/'stdout.txt').relative_to(root)),
                 'stderr':str((path.parent/'stderr.txt').relative_to(root))})
end=time.monotonic()
receipt={'author':'AI assistant','kind':'real wall-clock AI written design with local experiments',
         'start_utc':start['start_utc'],'start_monotonic':start['start_monotonic'],
         'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ended_monotonic':end,
         'elapsed_s':end-start['start_monotonic'],'minimum_45_minutes_reached':end-start['start_monotonic']>=2700,
         'stage_00_recorded_elapsed_s':start['recorded_monotonic']-start['start_monotonic'],
         'stages':[{'stage':s['stage'],'elapsed_s':s['elapsed_s'],'deviation_s':s['elapsed_s']-int(s['stage'].split('-')[0])*60,
                    'path':str((ev/'stages'/s['stage']/'stage.json').relative_to(root))} for s in stages],
         'additional_early_checkpoint':{'path':str((ev/'stages/40/stage.json').relative_to(root)),'elapsed_s':2389.987304167007,'deviation_s':-10.012695832993,'note':'Preserved original; required 40-minute evidence uses later 40-rechecked snapshot.'},
         'constraint':constraint,'constraint_time_semantics':'First UTC/monotonic sample persisted immediately after the constraint message was presented to this agent; transport delivery latency is not separately instrumented.',
         'python':platform.python_version(),'sqlite':sqlite3.sqlite_version,
         'test_and_command_process_elapsed_s':sum(r['elapsed_s'] for r in runs),
         'active_reasoning_seconds':None,'intentional_idle_timer_waits':0,
         'timing_limit':'Session wall time includes tool round trips, drafting and review. Active reasoning duration is not instrumented; command runtime is not design duration. Real 0.25s sleeps inject SQLite lock faults, not session padding.',
         'stderr_encoding':'Empty stderr is represented by the literal marker (empty stderr); nonempty stderr is captured verbatim.',
         'runs':runs,'claims_file':str((ev/'claims.json').relative_to(root)),
         'source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(lab.rglob('*')) if p.is_file() and '__pycache__' not in p.parts},
         'not_proven':['human oral interview ability','production 1000 QPS or 300 QPS per matcher','real map behavior','cross-host database consensus or physical sharding','power loss durability','real push-delivery exactly-once'],
         'prior_35_answer_read':False,'commit_performed_by_child':False,'push_performed':False}
with (ev/'receipt.json').open('x') as f:
    json.dump(receipt,f,ensure_ascii=False,indent=2)
print(json.dumps({'receipt':str((ev/'receipt.json').relative_to(root)),'elapsed_s':receipt['elapsed_s'],'run_count':len(runs)},indent=2))
