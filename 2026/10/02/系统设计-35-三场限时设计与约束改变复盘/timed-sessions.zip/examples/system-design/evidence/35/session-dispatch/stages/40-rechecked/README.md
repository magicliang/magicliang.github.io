# 第 35 篇：派单 AI 计时书面设计

原始题为 20 万司机每 5 秒上报 100 B 最新位置、100 次派单/s、位置最多旧 5 秒、邀约有效 5 秒。第 25 分钟附近收到的新增约束为 1,000 次派单/s、80% 请求来自一个火车站单元、司机跨单元迁移、取消确认后新 accept 必须拒绝。单匹配器 300 次/s 是给定教学假设。

执行全部本地回归：

```bash
python3 examples/system-design/labs/35/session-dispatch/run_all.py
```

生成一次新的不可覆盖命令证据：

```bash
python3 examples/system-design/labs/35/session-dispatch/capture.py manual-replay-001 python3 examples/system-design/labs/35/session-dispatch/run_all.py
```

相同证据标签不会覆盖旧运行。`naive.py`、`spatial_authority_naive.py`、`cancel_cache_naive.py` 故意保留反例，单独运行预期退出 1；总入口会额外校验对应的二进制可判定结果，确认是两个有效邀约或已取消状态被复活，而非任意异常。

设计材料为 `design.md`、`invariants.md`、`revised-design.md`。证据在仓库相对路径 `examples/system-design/evidence/35/session-dispatch/`，阶段冻结文件位于 `stages/`，每次运行含 invocation、stdout、stderr 和实际源码快照。空 stderr 用字面标记 `(empty stderr)` 保存，原始退出码和执行时间在 invocation 内；参数错误运行可能只有 stderr 非空。

`dispatch.py` 是单一 SQLite 权威数据库的状态模型，`position.py` 是本地最新位置与时间边界模型。空间单元在实验里是标签，不是真实地图；通知去重是本地接收端模型，不是真实推送服务；`hotspot.py` 是固定输入的路由算术，不是吞吐压测。裸 Store 状态原语允许不传位置期限，仅验证状态的测试使用这个入口；完整匹配调用必须传入由可信位置数据计算的有效期限。

时间记录描述 AI assistant 的真实工具与设计会话。回放上述命令只重跑本地实验，不会重现原始 45 分钟过程，也不能用来证明任何人的口述表现。最终是否满足时间门槛以 `receipt.json` 中的真实起止、阶段偏差和证据列表为准。
