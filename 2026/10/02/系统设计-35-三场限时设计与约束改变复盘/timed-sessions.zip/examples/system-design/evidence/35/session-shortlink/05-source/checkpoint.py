"""Append-only wall-clock checkpoints for the AI design exercise."""
import argparse
import datetime
import hashlib
import json
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
EVIDENCE = ROOT / "evidence/35/session-shortlink"
LAB = Path(__file__).resolve().parent


def clock():
    return {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "monotonic_ns": time.monotonic_ns()}


def hashes():
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(LAB.glob("*.py"))}


def record(name, note_path, minute=None):
    now = clock()
    start = json.loads((EVIDENCE / "00-start.json").read_text())
    elapsed = (now["monotonic_ns"] - start["start_monotonic_ns"]) / 1e9
    if minute is not None and elapsed < minute * 60:
        raise ValueError("checkpoint cannot be recorded before its actual deadline")
    notes = Path(note_path).read_text()
    payload = {"actor": "AI assistant", **now, "elapsed_s": elapsed,
               "scheduled_minute": minute,
               "lateness_s": None if minute is None else elapsed - minute * 60,
               "notes": notes, "source_sha256": hashes()}
    path = EVIDENCE / (name + ".json")
    with path.open("x") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(json.dumps({"path": str(path), "utc": now["utc"], "elapsed_s": elapsed}, ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("note_path")
    parser.add_argument("--minute", type=int)
    args = parser.parse_args()
    record(args.name, args.note_path, args.minute)
