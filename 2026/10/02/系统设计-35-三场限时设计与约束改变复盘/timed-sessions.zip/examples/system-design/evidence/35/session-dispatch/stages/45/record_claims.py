"""Validate each claimed observable from the captured final scenario invocation."""
import json
import pathlib

lab=pathlib.Path(__file__).resolve().parent
root=lab.parents[4]
ev=root/'examples/system-design/evidence/35/session-dispatch'
run=ev/'runs/27-final-scenario-regression'
invocation=json.loads((run/'invocation.json').read_text())
report=json.loads((run/'stdout.txt').read_text())
assert invocation['exit_code']==0 and report['pass'] is True
results={item['file']:item for item in report['results']}
for item in results.values():
    assert item['binary_observable_verified'] is True
claims=[]

def add(criterion,scenario,file,observable,passed):
    assert passed,criterion
    claims.append({'criterion':criterion,'scenario':scenario,'command':results[file]['command'],
                   'runner_command':invocation['command'],'binary_observable':observable,
                   'artifact':str((run/'stdout.txt').relative_to(root)),
                   'invocation':str((run/'invocation.json').relative_to(root)),'pass':True})

state=json.loads(results['test_dispatch.py']['stdout'])['results']
add('driver exclusivity','12 simultaneous connections compete for same driver','test_dispatch.py',
    {'winners':state[0]['winners']},state[0]['winners']==1)
add('old confirmation cannot take new offer; exact deadline is expired','expire old invitation then create next generation','test_dispatch.py',
    {k:state[1][k] for k in ['deadline_accept_rows','stale_ack_rows','current_ack_rows','accepted_slot_reoffered']},
    (state[1]['deadline_accept_rows'],state[1]['stale_ack_rows'],state[1]['current_ack_rows'],state[1]['accepted_slot_reoffered'])==(0,0,1,False))
position=json.loads(results['test_position.py']['stdout'])
add('position age from sample, ordered updates and session fence','late arrival and stale sequence/session','test_position.py',position,
    position['late_report_eligible'] is False and position['old_session_rejected'] is True)
locked=json.loads(results['test_position_reservation.py']['stdout'])
add('position freshness checked after lock wait','eligible position expires behind SQLite write lock','test_position_reservation.py',locked,
    locked['reserved'] is False and locked['finished_ms']>locked['position_valid_until_ms'])
clock=json.loads(results['lock_clock.py']['stdout'])
add('confirmation time sampled after lock wait','confirmation waits past invite deadline','lock_clock.py',clock,
    clock['updated_rows']==0 and clock['returned_ms']>clock['deadline_ms'])
recovery=json.loads(results['test_recovery.py']['stdout'])['results']
add('transaction and notification-event crash recovery','separate process exits before or after commit','test_recovery.py',
    [{'child_exit':x['child_exit'],'offers_after_crash':len(x['rows_after_crash']),'events_after_crash':len(x['pending_events_after_crash']),'retry_id':x['retry']['id']} for x in recovery],
    [x['child_exit'] for x in recovery]==[23,24] and [len(x['rows_after_crash']) for x in recovery]==[0,1]
    and [len(x['pending_events_after_crash']) for x in recovery]==[0,1] and recovery[1]['retry']['id']=='offer-1')
hot=json.loads(results['hotspot.py']['stdout'])
add('hotspot arithmetic and routing revision','1000 requests, 800 in one cell, supplied capacity 300 per worker','hotspot.py',hot,
    hot['ideal_min_matchers']==4 and hot['single_owner_station_queue_growth_per_s']==500
    and max(hot['order_owners_5'].values())<=300 and max(hot['order_owners_after_one_failure_4'].values())<=300)
migration=json.loads(results['test_migration_cancel.py']['stdout'])['results']
add('stable authority and post-cancellation rejection','driver appears in two cells; cancelled offered and accepted rows; stale cache and outbox','test_migration_cancel.py',
    [{'previously_accepted':x['initially_accepted'],'stale_ack_rows':x['stale_outbox_accept_rows'],
      'old_ack_after_replacement':x['old_accept_after_replacement_rows'],'deadline_ack_rows':x['exact_deadline_accept_rows'],
      'cancel_return_monotonic':x['cancellation_acknowledged_monotonic'],'accept_start_monotonic':x['accept_started_monotonic'],
      'same_driver_authority':x['source_authority_worker']==x['destination_authority_worker']} for x in migration],
    all(x['stale_outbox_accept_rows']==x['old_accept_after_replacement_rows']==x['exact_deadline_accept_rows']==0
        and x['accept_started_monotonic']>=x['cancellation_acknowledged_monotonic']
        and x['source_authority_worker']==x['destination_authority_worker'] for x in migration))
for name in ['naive.py','spatial_authority_naive.py','cancel_cache_naive.py']:
    add('negative control observes actual forbidden state',name,name,json.loads(results[name]['stdout']),
        results[name]['exit_code']==1 and results[name]['binary_observable_verified'])
stage=json.loads((ev/'stages/45/stage.json').read_text())
assert stage['elapsed_s']>=2700
claims.append({'criterion':'real 45-minute AI written session','scenario':'monotonic start to final immutable checkpoint',
               'command':stage['invocation'],
               'binary_observable':{'elapsed_s':stage['elapsed_s'],'at_least_2700':True},
               'artifact':str((ev/'stages/45/stage.json').relative_to(root)),'pass':True})
with (ev/'claims.json').open('x') as f:
    json.dump({'author':'AI assistant','claims':claims},f,ensure_ascii=False,indent=2)
print(json.dumps({'pass':True,'claim_count':len(claims),'artifact':str((ev/'claims.json').relative_to(root))},indent=2))
