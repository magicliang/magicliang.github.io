import concurrent.futures
import json
import pathlib
import tempfile
import threading
from dispatch import Conflict, Store


def scenario_race(root):
    store = Store(root/'race.sqlite')
    store.initialize(['driver-1'])
    ready = threading.Barrier(12)
    def claim(index):
        ready.wait(timeout=10)
        try:
            return store.offer(f'req-{index}',f'offer-{index}','driver-1',f'order-{index}',1000)
        except Conflict:
            return None
    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
        results = list(pool.map(claim,range(12)))
    winners = [x for x in results if x is not None]
    assert len(winners)==1, winners
    assert len(store.rows())==1
    return {'scenario':'12 simultaneous SQLite connections offer same driver','winners':len(winners),'rows':store.rows()}


def scenario_late(root):
    store = Store(root/'late.sqlite')
    store.initialize(['driver-1'])
    old = store.offer('r1','a1','driver-1','order-1',1000)
    deadline_accept = store.accept('a1','driver-1',old['generation'],6000)
    current = store.offer('r2','a2','driver-1','order-2',6000)
    old_accept = store.accept('a1','driver-1',old['generation'],6001)
    new_accept = store.accept('a2','driver-1',current['generation'],6001)
    try:
        store.offer('r3','a3','driver-1','order-3',100000)
        accepted_expired = True
    except Conflict:
        accepted_expired = False
    assert (deadline_accept,old_accept,new_accept,accepted_expired)==(0,0,1,False)
    assert store.rows()[1]['state']=='accepted'
    return {'scenario':'deadline equality, old acknowledgment after re-offer, accepted retention','deadline_accept_rows':deadline_accept,'stale_ack_rows':old_accept,'current_ack_rows':new_accept,'accepted_slot_reoffered':accepted_expired,'rows':store.rows()}


if __name__=='__main__':
    with tempfile.TemporaryDirectory() as tmp:
        results = [scenario_race(pathlib.Path(tmp)),scenario_late(pathlib.Path(tmp))]
    print(json.dumps({'pass':True,'results':results},indent=2))
