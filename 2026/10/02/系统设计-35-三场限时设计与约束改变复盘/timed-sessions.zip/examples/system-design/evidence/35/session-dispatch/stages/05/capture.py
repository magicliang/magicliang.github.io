"""Capture a real invocation without overwriting an earlier evidence run."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[5]
LAB = pathlib.Path(__file__).resolve().parent
EVIDENCE = ROOT / 'examples/system-design/evidence/35/session-dispatch'


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def hashes():
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(LAB.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}


if __name__ == '__main__':
    label, *command = sys.argv[1:]
    if not command:
        raise SystemExit('usage: capture.py LABEL COMMAND [ARGS]')
    destination = EVIDENCE / 'runs' / label
    destination.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    result = {'command': command, 'cwd': str(ROOT), 'started_utc': utc(),
              'started_monotonic': started, 'source_sha256_before': hashes()}
    completed = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
    (destination/'stdout.txt').write_text(completed.stdout)
    (destination/'stderr.txt').write_text(completed.stderr or '(empty stderr)\n')
    result.update(ended_utc=utc(), ended_monotonic=time.monotonic(),
                  elapsed_s=time.monotonic()-started, exit_code=completed.returncode,
                  source_sha256_after=hashes(), author='AI assistant')
    (destination/'invocation.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))
    print(completed.stdout, end='')
    print(completed.stderr, end='', file=sys.stderr)
    raise SystemExit(completed.returncode)
