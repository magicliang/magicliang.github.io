import http.client
import json
from pathlib import Path
import tempfile
import threading
import unittest

from http_adapter import make_server
from shortlink import Service


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.now = 1000
        self.service = Service(Path(self.tmp.name) / 'links.db', clock=lambda: self.now)
        self.server = make_server(self.service)
        self.thread = threading.Thread(target=self.server.serve_forever, kwargs={'poll_interval': 0.01})
        self.thread.start()
        self.addCleanup(self.cleanup)

    def cleanup(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)
        self.tmp.cleanup()

    def request(self, method, path, payload=None, owner='alice', key='request-1'):
        connection = http.client.HTTPConnection(*self.server.server_address, timeout=3)
        try:
            data = None if payload is None else json.dumps(payload)
            connection.request(method, path, data, {'X-Lab-Owner': owner, 'Idempotency-Key': key,
                                                    'Content-Type': 'application/json'})
            response = connection.getresponse()
            raw = response.read()
            observed = {'method': method, 'path': path, 'status': response.status,
                        'headers': {k.lower(): v for k, v in response.getheaders()},
                        'body': json.loads(raw) if raw else None}
            print(json.dumps({'http': observed}))
            return observed
        finally:
            connection.close()

    def test_real_http_create_replay_redirect_revoke(self):
        payload = {'target': 'https://example.org/a', 'expires_at': 2000}
        created = self.request('POST', '/links', payload)
        self.assertEqual(201, created['status'])
        code = created['body']['code']
        replay = self.request('POST', '/links', payload)
        self.assertEqual((200, code), (replay['status'], replay['body']['code']))
        redirect = self.request('GET', '/r/' + code)
        self.assertEqual(302, redirect['status'])
        self.assertEqual('https://example.org/a', redirect['headers']['location'])
        self.assertEqual('no-store', redirect['headers']['cache-control'])
        denied = self.request('DELETE', '/links/' + code, owner='mallory')
        self.assertEqual(404, denied['status'])
        deleted = self.request('DELETE', '/links/' + code)
        self.assertEqual(204, deleted['status'])
        self.assertIsNone(deleted['body'])
        denied = self.request('GET', '/r/' + code)
        self.assertEqual(404, denied['status'])
        self.assertNotIn('location', denied['headers'])

    def test_real_http_disconnect_after_commit_replays(self):
        def lose_response(event):
            if event == 'after_create_commit':
                raise ConnectionError('injected lost HTTP response')
        self.service.hook = lose_response
        payload = {'target': 'https://example.org/a', 'expires_at': 2000}
        with self.assertRaises(http.client.RemoteDisconnected):
            self.request('POST', '/links', payload)
        self.service.hook = lambda event: None
        replay = self.request('POST', '/links', payload)
        self.assertEqual(200, replay['status'])
        self.assertEqual(302, self.request('GET', '/r/' + replay['body']['code'])['status'])

    def test_real_http_expiry_boundary(self):
        created = self.request('POST', '/links', {'target': 'https://example.org/a', 'expires_at': 1001})
        self.now = 1001
        denied = self.request('GET', '/r/' + created['body']['code'])
        self.assertEqual(404, denied['status'])
        self.assertNotIn('location', denied['headers'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
