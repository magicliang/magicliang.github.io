"""Restore an old SQLite backup and expose unsafe recovery. Expected exit: 2."""
import json
from pathlib import Path
import sqlite3
import tempfile

from shortlink import Service

with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    authority_path, backup_path = root / 'authority.db', root / 'old-backup.db'
    authority = Service(authority_path, clock=lambda: 1000)
    old = authority.create('alice', 'key-a', 'https://example.org/a', 2000).body['code']
    with sqlite3.connect(authority_path) as source, sqlite3.connect(backup_path) as backup:
        source.backup(backup)
    revoke = authority.revoke('alice', old)
    later = authority.create('alice', 'key-b', 'https://example.org/b', 2000).body['code']
    restored = Service(backup_path, clock=lambda: 1000)
    restored_old = restored.resolve(old)
    reused = restored.create('bob', 'key-c', 'https://example.org/c', 2000).body['code']
    result = {'scenario': 'serve_old_backup_without_recovery_fence',
              'revoke_ack': revoke.status, 'live_old_status': authority.resolve(old).status,
              'restored_old_status': restored_old.status,
              'committed_later_code': later, 'restored_reallocated_code': reused,
              'revocation_resurrected': restored_old.status == 302,
              'highwater_reused': later == reused,
              'boundary': 'Directly starting an out-of-date backup is unsupported recovery, not an API operation.'}
    print(json.dumps(result, indent=2))
    assert result['revoke_ack'] == 204 and result['live_old_status'] == 404
    assert result['revocation_resurrected'] and result['highwater_reused']
    print('EXPECTED_REJECTION: old backups need a recovery fence and replay before serving')
    raise SystemExit(2)
