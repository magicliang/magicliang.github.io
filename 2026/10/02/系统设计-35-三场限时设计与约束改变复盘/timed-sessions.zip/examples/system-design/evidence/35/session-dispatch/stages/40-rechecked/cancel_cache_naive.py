"""Unique live-driver indexing alone cannot prevent resurrecting a cancelled offer."""
import json
import pathlib
import tempfile
import time
from dispatch import Store

with tempfile.TemporaryDirectory() as tmp:
    store=Store(pathlib.Path(tmp)/'cancel.sqlite',clock_ms=lambda:1000)
    store.initialize(['d'])
    cached=store.offer('r','o','d','order')
    assert store.release('o',1)==1
    cancelled_at=time.monotonic()
    accept_started=time.monotonic()
    with store.transaction() as db:
        if cached['state']=='offered':
            changed=db.execute("UPDATE offer SET state='accepted' WHERE id=? AND generation=?",('o',1)).rowcount
        else:
            changed=0
    print(json.dumps({'scenario':'cache-authorized accept after cancellation acknowledgment','cached_state':cached['state'],
                      'cancellation_acknowledged_monotonic':cancelled_at,'accept_started_monotonic':accept_started,
                      'updated_rows':changed,'authoritative_rows':store.rows()},indent=2),flush=True)
    assert accept_started>=cancelled_at
    assert changed==0,'cached offered state resurrected a committed cancellation'
