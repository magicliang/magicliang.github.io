"""Unsafe acknowledgement and lease refresh paths. Expected exit: 2."""
import json
from pathlib import Path
import tempfile

from lease_gate import Lease, LeaseAuthority, Reader
from shortlink import Service

with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    now = [1000.0]
    service = Service(root / 'links.db', clock=lambda: now[0])
    code = service.create('alice', 'key', 'https://example.org/a', 2000).body['code']
    authority = LeaseAuthority(service, root / 'revocations.db', lambda: now[0], bootstrap=True)
    reader = Reader(authority, lambda: now[0])
    reader.resolve(code)
    old_lease = reader.cache[code]
    reader.connected = False
    now[0] = 1000.1
    premature_ack = service.revoke('alice', code)
    after_bad_ack = reader.resolve(code)
    authority.revoke('alice', code)
    now[0] = 1002.0
    confirmed = authority.revoke('alice', code)
    correct = reader.resolve(code)
    stale_if_error_target = old_lease.target
    # Delayed delivery must preserve the original deadline. Resetting it is unsafe.
    reader.cache[code] = Lease(code, old_lease.target, now[0] + authority.lease_seconds)
    reset_deadline = reader.resolve(code)
    observations = [
        {'scenario':'ack_at_database_commit_with_outstanding_lease', 'ack':premature_ack.status,
         'post_ack_new_request':after_bad_ack.status, 'violation':after_bad_ack.status == 302},
        {'scenario':'stale_if_error_after_lease_expiry', 'correct_status':correct.status,
         'unsafe_target':stale_if_error_target, 'violation':correct.status == 503 and bool(stale_if_error_target)},
        {'scenario':'reset_lease_deadline_on_delayed_receipt', 'confirmed':confirmed.status,
         'unsafe_post_ack_status':reset_deadline.status, 'violation':reset_deadline.status == 302},
    ]
    for row in observations:
        print(json.dumps(row))
    assert all(row['violation'] for row in observations)
    print('EXPECTED_REJECTION: premature acknowledgement, stale fallback and reset deadline violate contract')
    raise SystemExit(2)
