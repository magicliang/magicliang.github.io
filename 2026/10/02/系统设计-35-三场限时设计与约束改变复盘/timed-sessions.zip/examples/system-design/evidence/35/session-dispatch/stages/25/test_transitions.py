"""Exercise the documented terminal-state table against actual SQLite updates."""
import json
import pathlib
import tempfile
from dispatch import Store

results=[]
with tempfile.TemporaryDirectory() as tmp:
    for state in ['offered','accepted','expired','cancelled','completed']:
        for operation in ['accept','cancelled','completed']:
            store=Store(pathlib.Path(tmp)/(state+'-'+operation+'.sqlite'),clock_ms=lambda:1000)
            store.initialize(['d'])
            store.offer('r','o','d','order')
            with store.transaction() as db:
                db.execute('UPDATE offer SET state=?',(state,))
            if operation=='accept':
                changed=store.accept('o','d',1)
                expected=int(state=='offered')
            else:
                changed=store.release('o',1,terminal=operation)
                expected=int(state=='accepted' or (state=='offered' and operation=='cancelled'))
            results.append({'initial':state,'operation':operation,'changed_rows':changed,'expected_rows':expected})
print(json.dumps({'pass':all(x['changed_rows']==x['expected_rows'] for x in results),'transitions':results},indent=2),flush=True)
assert all(x['changed_rows']==x['expected_rows'] for x in results), 'implementation violates documented transition table'
