"""Loopback-only protocol adapter; X-Lab-Owner is a fixture, not authentication."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import re
import sqlite3

from shortlink import Reply

CODE = re.compile(r'^[A-Za-z0-9_-]{1,64}$')


def make_server(service):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.1'

        def log_message(self, *args):
            pass

        def send_reply(self, reply):
            data = b'' if reply.status == 204 else json.dumps(reply.body).encode()
            self.send_response(reply.status)
            for key, value in reply.headers.items():
                self.send_header(key, value)
            if reply.status != 204:
                self.send_header('Content-Length', str(len(data)))
            self.send_header('Content-Type', 'application/json')
            self.send_header('Connection', 'close')
            self.end_headers()
            if data:
                self.wfile.write(data)
            self.close_connection = True

        def do_POST(self):
            if self.path != '/links':
                return self.send_reply(Reply(404))
            try:
                size = int(self.headers.get('Content-Length', '0'))
                if not 0 < size <= 4096:
                    return self.send_reply(Reply(400, {'error': 'invalid content length'}))
                body = json.loads(self.rfile.read(size))
                owner = self.headers.get('X-Lab-Owner', '')
                key = self.headers.get('Idempotency-Key', '')
                if not isinstance(body, dict):
                    return self.send_reply(Reply(400))
                reply = service.create(owner, key, body.get('target'), body.get('expires_at'))
                self.send_reply(reply)
            except (ValueError, TypeError):
                self.send_reply(Reply(400))
            except sqlite3.Error:
                self.send_reply(Reply(503, {'error': 'authority unavailable'}))
            except ConnectionError:
                self.close_connection = True

        def do_GET(self):
            code = self.path.removeprefix('/r/')
            if not self.path.startswith('/r/') or not CODE.fullmatch(code):
                return self.send_reply(Reply(404))
            self.send_reply(service.resolve(code))

        def do_DELETE(self):
            code = self.path.removeprefix('/links/')
            if not self.path.startswith('/links/') or not CODE.fullmatch(code):
                return self.send_reply(Reply(404))
            try:
                self.send_reply(service.revoke(self.headers.get('X-Lab-Owner', ''), code))
            except sqlite3.Error:
                self.send_reply(Reply(503, {'error': 'authority unavailable'}))
            except ConnectionError:
                self.close_connection = True

    return ThreadingHTTPServer(('127.0.0.1', 0), Handler)
