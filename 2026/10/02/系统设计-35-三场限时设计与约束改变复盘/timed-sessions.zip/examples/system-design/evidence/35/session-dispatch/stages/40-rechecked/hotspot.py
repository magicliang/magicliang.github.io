"""Deterministic load arithmetic; this is not a throughput benchmark."""
import collections
import hashlib
import json
import math
import sys

TOTAL=1000
HOT=800
CAPACITY=300
orders=[{'id':f'order-{i}','cell':'station' if i<HOT else f'cold-{i%3}'} for i in range(TOTAL)]

def counts(workers,by_cell):
    output=collections.Counter({i:0 for i in range(workers)})
    for order in orders:
        key=order['cell'] if by_cell else order['id']
        owner=int.from_bytes(hashlib.sha256(key.encode()).digest()[:8],'big')%workers
        output[owner]+=1
    return dict(sorted(output.items()))

result={'kind':'teaching arithmetic and deterministic key-routing model',
        'requests_per_s':TOTAL,'station_requests_per_s':HOT,'capacity_per_matcher_per_s_assumed':CAPACITY,
        'ideal_min_matchers':math.ceil(TOTAL/CAPACITY),'ideal_min_hot_workers':math.ceil(HOT/CAPACITY),
        'single_owner_station_queue_growth_per_s':HOT-CAPACITY,
        'naive_cell_owners_4':counts(4,True),'order_owners_5':counts(5,False),
        'order_owners_after_one_failure_4':counts(4,False),
        'normal_ideal_utilization_5':TOTAL/(5*CAPACITY),'one_failed_ideal_utilization_4':TOTAL/(4*CAPACITY),
        'limitations':['fixture distribution only, not adversarial hash skew guarantee','candidate lookup and authority database capacities unmeasured','300 per second is supplied assumption, not measured QPS']}
print(json.dumps(result,indent=2),flush=True)
if '--naive' in sys.argv:
    assert max(result['naive_cell_owners_4'].values())<=CAPACITY,'one hot cell still overloads one matcher'
else:
    assert max(result['order_owners_5'].values())<=CAPACITY
    assert max(result['order_owners_after_one_failure_4'].values())<=CAPACITY
