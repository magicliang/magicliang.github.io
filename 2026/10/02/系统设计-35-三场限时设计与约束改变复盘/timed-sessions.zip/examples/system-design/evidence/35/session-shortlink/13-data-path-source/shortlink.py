"""Single-authority short-link experiment. No throughput or replication claim."""
from contextlib import closing
from dataclasses import dataclass, field
import hashlib
import json
import secrets
import sqlite3
import string
import time
from urllib.parse import urlsplit


@dataclass(frozen=True)
class Reply:
    status: int
    body: dict = field(default_factory=dict)
    headers: dict = field(default_factory=lambda: {"Cache-Control": "no-store"})


class Service:
    MAX_LIFETIME = 30 * 86400

    def __init__(self, path, clock=time.time, candidate=None, hook=None):
        self.path = str(path)
        self.clock = clock
        self.candidate = candidate or self.random_code
        self.hook = hook or (lambda event: None)
        with closing(self.connect()) as db:
            db.executescript("""
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS links (
                    code TEXT PRIMARY KEY NOT NULL,
                    owner TEXT NOT NULL,
                    target TEXT NOT NULL,
                    expires_at INTEGER NOT NULL,
                    revoked_at INTEGER,
                    version INTEGER NOT NULL DEFAULT 1
                );
                CREATE TABLE IF NOT EXISTS requests (
                    owner TEXT NOT NULL,
                    request_key TEXT NOT NULL,
                    fingerprint TEXT NOT NULL,
                    code TEXT NOT NULL REFERENCES links(code),
                    PRIMARY KEY (owner, request_key)
                );
            """)

    def connect(self):
        db = sqlite3.connect(self.path, isolation_level=None, timeout=3)
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA synchronous=FULL")
        return db

    @staticmethod
    def random_code():
        alphabet = string.ascii_letters + string.digits
        return "".join(secrets.choice(alphabet) for _ in range(10))

    def create(self, owner, request_key, target, expires_at):
        if not owner or not request_key or len(request_key) > 128:
            return Reply(400, {"error": "owner and bounded request key required"})
        if not isinstance(target, str) or not target.isascii():
            return Reply(400, {"error": "target must be an ASCII HTTP URL"})
        try:
            url = urlsplit(target)
            url.port  # Validate the optional port without contacting the target.
            valid_target = (url.scheme in {"https", "http"} and url.hostname
                            and not url.username and not url.password
                            and len(target.encode()) <= 2048
                            and not any(ord(c) <= 32 or ord(c) == 127 for c in target))
        except (TypeError, ValueError):
            valid_target = False
        if not valid_target or type(expires_at) is not int:
            return Reply(400, {"error": "invalid target or expiry"})
        fingerprint = hashlib.sha256(json.dumps(
            [target, expires_at], separators=(",", ":"), ensure_ascii=False
        ).encode()).hexdigest()
        with closing(self.connect()) as db:
            try:
                db.execute("BEGIN IMMEDIATE")
                old = db.execute(
                    "SELECT fingerprint, code FROM requests WHERE owner=? AND request_key=?",
                    (owner, request_key)).fetchone()
                if old:
                    db.execute("ROLLBACK")
                    if old[0] != fingerprint:
                        return Reply(409, {"error": "idempotency key reused with different payload"})
                    return Reply(200, {"code": old[1], "replayed": True})
                now = int(self.clock())
                if not now < expires_at <= now + self.MAX_LIFETIME:
                    db.execute("ROLLBACK")
                    return Reply(400, {"error": "expiry outside allowed lifetime"})
                for _ in range(5):
                    code = self.candidate()
                    try:
                        db.execute("INSERT INTO links(code,owner,target,expires_at) VALUES(?,?,?,?)",
                                   (code, owner, target, expires_at))
                        break
                    except sqlite3.IntegrityError:
                        continue
                else:
                    db.execute("ROLLBACK")
                    return Reply(503, {"error": "candidate collision budget exhausted"})
                self.hook("after_link_insert")
                db.execute("INSERT INTO requests(owner,request_key,fingerprint,code) VALUES(?,?,?,?)",
                           (owner, request_key, fingerprint, code))
                self.hook("before_create_commit")
                db.execute("COMMIT")
                self.hook("after_create_commit")
                return Reply(201, {"code": code, "replayed": False})
            except BaseException:
                if db.in_transaction:
                    db.execute("ROLLBACK")
                raise

    def resolve(self, code):
        try:
            with closing(self.connect()) as db:
                row = db.execute("SELECT target, expires_at, revoked_at FROM links WHERE code=?",
                                 (code,)).fetchone()
            if row is None or row[2] is not None or row[1] <= self.clock():
                return Reply(404)
            self.hook("after_resolve_read")
            return Reply(302, headers={"Location": row[0], "Cache-Control": "no-store"})
        except sqlite3.Error:
            return Reply(503, {"error": "authority unavailable"})

    def revoke(self, owner, code):
        with closing(self.connect()) as db:
            try:
                db.execute("BEGIN IMMEDIATE")
                row = db.execute("SELECT revoked_at FROM links WHERE code=? AND owner=?",
                                 (code, owner)).fetchone()
                if row is None:
                    db.execute("ROLLBACK")
                    return Reply(404)
                if row[0] is None:
                    db.execute("UPDATE links SET revoked_at=?, version=version+1 WHERE code=?",
                               (int(self.clock()), code))
                self.hook("before_revoke_commit")
                db.execute("COMMIT")
                self.hook("after_revoke_commit")
                return Reply(204)
            except BaseException:
                if db.in_transaction:
                    db.execute("ROLLBACK")
                raise
