"""Pure arithmetic with explicit inputs; no production throughput inference."""
import json

records = 20 * 86400 * 30
result = {
    'inputs': {'reads_per_s': 2000, 'creates_per_s_upper_bound': 20,
               'record_B_mean_assumption': 400, 'retention_days': 30, 'copies': 3},
    'live_records_upper_bound': records,
    'mapping_raw_B': records * 400,
    'mapping_three_copies_B': records * 400 * 3,
    'mapping_three_copies_GiB': records * 400 * 3 / 1024**3,
    'redirect_payload_if_500B_response_B_per_s': 2000 * 500,
    'strict_gate_reads_per_s_with_99_percent_target_cache_hit': 2000,
    'target_cache_misses_per_s_at_99_percent': 2000 * 0.01,
    'hot_key_reads_per_s_if_50_percent_share': 2000 * 0.5,
    'request_record_sensitivity_three_copies_B': {str(size): records * size * 3
                                               for size in [128, 256, 400]},
    'permanent_tombstone_growth_B_per_year_if_32B_each_three_copies': 20 * 86400 * 365 * 32 * 3,
    'counter_metadata_growth_per_year': 'constant row count; integer value grows',
    'index_and_log_reserve_sensitivity_B': {str(factor): records * 400 * 3 * factor
                                          for factor in [1.5, 2, 3]},
    'latency_to_inflight_using_L_equals_lambda_W': {str(ms): 2000 * ms / 1000
                                                  for ms in [10, 50, 100, 200]},
    'random_code_collision_expected_pairs': {
        str(length): records * (records - 1) / (2 * 62**length) for length in [8, 10, 12]},
    'limits': ['All 20 writes/s are treated as creates for storage upper bound.',
               '400 B is an assumed mean, not maximum URL or measured row size.',
               'Response size, hot-key share, request row sizes and reserves are sensitivity inputs.',
               'No steady-state throughput, latency SLO, replication or failover is established.']
}
assert result['live_records_upper_bound'] == 51_840_000
assert result['mapping_three_copies_B'] == 62_208_000_000
assert result['strict_gate_reads_per_s_with_99_percent_target_cache_hit'] == 2000
print(json.dumps(result, ensure_ascii=False, indent=2))
