"""A bounded local read-path sample, deliberately not a production capacity test."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import platform
import sqlite3
import statistics
import tempfile
import time

from shortlink import Service

ROWS = 10000
REQUESTS = 4000
WORKERS = 8

with tempfile.TemporaryDirectory() as tmp:
    path = Path(tmp) / 'links.db'
    service = Service(path, clock=lambda: 1000)
    with sqlite3.connect(path) as db:
        db.executemany('INSERT INTO links(code,owner,target,expires_at) VALUES(?,?,?,?)',
                       [(f'fixture-{i}', 'owner', 'https://example.org/' + 'a' * 330, 2000)
                        for i in range(ROWS)])
        plan = db.execute('EXPLAIN QUERY PLAN SELECT target,expires_at,revoked_at FROM links WHERE code=?',
                          ('fixture-42',)).fetchall()
        db.commit()
        db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
        page_count = db.execute('PRAGMA page_count').fetchone()[0]
        page_size = db.execute('PRAGMA page_size').fetchone()[0]
    def read(i):
        start = time.perf_counter_ns()
        response = service.resolve(f'fixture-{(i * 7919) % ROWS}')
        return response.status, (time.perf_counter_ns() - start) / 1e6
    started = time.perf_counter_ns()
    with ThreadPoolExecutor(max_workers=WORKERS) as pool:
        observations = list(pool.map(read, range(REQUESTS)))
    elapsed = (time.perf_counter_ns() - started) / 1e9
    latencies = sorted(duration for status, duration in observations)
    statuses = [status for status, duration in observations]
    result = {'scenario': 'bounded_local_uniform_read_sample', 'fixture_rows': ROWS,
              'requests': REQUESTS, 'workers': WORKERS, 'elapsed_s': elapsed,
              'completed_per_s': REQUESTS / elapsed, 'status_302_count': statuses.count(302),
              'mean_call_ms': statistics.mean(latencies), 'p99_call_ms': latencies[int(0.99 * (REQUESTS-1))],
              'query_plan': plan, 'fixture_db_bytes': page_count * page_size,
              'fixture_db_bytes_per_row': page_count * page_size / ROWS,
              'os': platform.platform(), 'cpu_architecture': platform.machine(),
              'limits': ['Application function calls, not HTTP or TLS.',
                         'Ten thousand resident fixture rows, not 51.84 million live rows.',
                         'Closed-loop executor: completion rate is not an offered-load SLO.',
                         'No simultaneous writes, replication, failover or disk-pressure workload.',
                         'Machine is shared with other work; one sample is not capacity certification.']}
    print(json.dumps(result, indent=2))
    assert result['status_302_count'] == REQUESTS
    assert any('SEARCH links USING INDEX' in str(row) for row in plan)
