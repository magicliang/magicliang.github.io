"""Executable, deliberately unsafe read and cleanup paths. Expected exit: 2."""
import json
from pathlib import Path
import sqlite3
import tempfile

from shortlink import Service


def main():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / 'links.db'
        service = Service(path, clock=lambda: 1000, candidate=lambda: 'never-reuse')
        code = service.create('alice', 'first', 'https://example.org/alice', 2000).body['code']
        cached = service.resolve(code)
        reader = sqlite3.connect(path, isolation_level=None)
        reader.execute('BEGIN')
        reader.execute('SELECT revoked_at FROM links WHERE code=?', (code,)).fetchone()
        service.revoke('alice', code)
        stale_row = reader.execute('SELECT revoked_at FROM links WHERE code=?', (code,)).fetchone()
        fresh = service.resolve(code)
        observations = [
            {'scenario': 'positive_cache_skips_authority', 'unsafe_status': cached.status,
             'fresh_status': fresh.status, 'violation_observed': cached.status == 302 and fresh.status == 404},
            {'scenario': 'long_lived_authority_snapshot', 'unsafe_revoked_at': stale_row[0],
             'fresh_status': fresh.status, 'violation_observed': stale_row[0] is None and fresh.status == 404},
        ]
        reader.execute('ROLLBACK')
        reader.close()
        with sqlite3.connect(path) as db:
            db.execute('DELETE FROM requests')
            db.execute('DELETE FROM links')
        new = service.create('bob', 'different', 'https://example.org/bob', 2000)
        reused = service.resolve(code)
        observations.append({'scenario': 'delete_tombstone_and_reuse_code', 'new_status': new.status,
                             'old_url_status': reused.status, 'old_url_target': reused.headers.get('Location'),
                             'violation_observed': reused.status == 302 and reused.headers.get('Location') == 'https://example.org/bob'})
        for item in observations:
            print(json.dumps(item))
        assert all(item['violation_observed'] for item in observations)
        print('EXPECTED_REJECTION: three deliberately unsafe paths violate revocation or non-reuse')
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
