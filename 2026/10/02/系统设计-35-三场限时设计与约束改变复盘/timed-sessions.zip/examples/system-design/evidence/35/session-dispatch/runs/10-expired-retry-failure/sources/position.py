"""Latest-position model with conservative sample age and session fencing."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Position:
    session: int
    seq: int
    sampled_server_ms: int
    uncertainty_ms: int
    received_ms: int
    x: float
    y: float


class LatestPositions:
    def __init__(self):
        self.sessions = {}
        self.values = {}

    def open_session(self, driver):
        self.sessions[driver] = self.sessions.get(driver,0)+1
        self.values.pop(driver,None)
        return self.sessions[driver]

    def report(self, driver, position):
        if position.session != self.sessions.get(driver):
            return False
        if position.uncertainty_ms < 0:
            raise ValueError('unknown clock uncertainty is ineligible')
        if position.sampled_server_ms-position.uncertainty_ms > position.received_ms:
            return False
        current = self.values.get(driver)
        if current and position.seq <= current.seq:
            return False
        self.values[driver] = position
        return True

    def eligible(self, driver, now_ms):
        value = self.values.get(driver)
        if value is None:
            return False
        age_upper_ms = now_ms-value.sampled_server_ms+value.uncertainty_ms
        return 0 <= age_upper_ms <= 5000
