import json

seats = 50_000
hold_requests_per_second = 500
availability_reads_per_second = 5000
hold_seconds = 300
commit_budget_per_second = 800
cases = []
for admitted in [320, 400, 500]:
    for conversion in [0, 0.5, 1]:
        required = admitted * (1 + conversion)
        cases.append({'new_hold_admissions_per_second': admitted, 'payment_fraction': conversion,
                      'base_commits_per_second': required,
                      'headroom_commits_per_second': commit_budget_per_second - required,
                      'base_within_budget': required <= commit_budget_per_second})
assert next(row for row in cases if row['new_hold_admissions_per_second'] == 500 and row['payment_fraction'] == 1)['base_within_budget'] is False
assert next(row for row in cases if row['new_hold_admissions_per_second'] == 320 and row['payment_fraction'] == 1)['headroom_commits_per_second'] == 160
order_payload_bytes = seats * 1024
print(json.dumps({'scenario': 'given_capacity_arithmetic',
                  'inputs': {'seats': seats, 'hold_request_per_second': hold_requests_per_second,
                             'read_request_per_second': availability_reads_per_second,
                             'hold_seconds': hold_seconds, 'given_commit_per_second': commit_budget_per_second},
                  'requests_in_one_hold_window': hold_requests_per_second * hold_seconds,
                  'no_payment_first_fill_seconds': seats / hold_requests_per_second,
                  'no_payment_steady_reclaim_upper_success_per_second': seats / hold_seconds,
                  'one_order_per_seat_payload_MiB': order_payload_bytes / 1024 ** 2,
                  'three_copy_payload_MiB': 3 * order_payload_bytes / 1024 ** 2,
                  'two_generations_three_copy_payload_MiB': 6 * order_payload_bytes / 1024 ** 2,
                  'cases': cases,
                  'excluded_costs': ['failed or replay transactions', 'expiry workers', 'refund processing', 'indexes and WAL', 'durability replication overhead'],
                  'scope': 'arithmetic on supplied bounds, not measured server capacity', 'pass': True}, indent=2))
