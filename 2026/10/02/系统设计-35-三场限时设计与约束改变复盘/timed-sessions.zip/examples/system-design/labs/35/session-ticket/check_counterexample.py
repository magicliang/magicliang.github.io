from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import sqlite3
import threading

root = Path(os.environ['TICKET_RUN_DIR'])
path = root / 'unsafe-check-then-write.sqlite'
with sqlite3.connect(path) as db:
    db.executescript("CREATE TABLE seats(id PRIMARY KEY, state, owner); INSERT INTO seats VALUES(1,'FREE',NULL); CREATE TABLE sales(order_id PRIMARY KEY, seat_id);")
barrier = threading.Barrier(2)


def unsafe_sale(order_id):
    with sqlite3.connect(path, timeout=5) as db:
        observed = db.execute('SELECT state FROM seats WHERE id=1').fetchone()[0]
    barrier.wait()
    if observed == 'FREE':
        with sqlite3.connect(path, timeout=5) as db:
            db.execute("UPDATE seats SET state='SOLD',owner=? WHERE id=1", (order_id,))
            db.execute('INSERT INTO sales VALUES(?,1)', (order_id,))
        return {'order': order_id, 'read': observed, 'response': 'sold'}
    return {'order': order_id, 'read': observed, 'response': 'conflict'}


with ThreadPoolExecutor(max_workers=2) as pool:
    trace = list(pool.map(unsafe_sale, ['order-A', 'order-B']))
with sqlite3.connect(path) as db:
    count = db.execute('SELECT count(*) FROM sales WHERE seat_id=1').fetchone()[0]
    seat = db.execute('SELECT * FROM seats').fetchone()
assert count == 2
assert all(item['read'] == 'FREE' and item['response'] == 'sold' for item in trace)
print(json.dumps({'scenario': 'unsafe_read_then_unconditional_write', 'trace': trace, 'paid_orders_for_one_seat': count,
                  'seat_row': seat, 'invariant_violated': True,
                  'meaning': 'negative witness, not the TicketStore implementation', 'witness_reproduced': True}, indent=2))
