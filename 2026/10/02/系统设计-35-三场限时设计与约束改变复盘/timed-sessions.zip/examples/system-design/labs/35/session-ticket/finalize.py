import hashlib
import json
import platform
import sqlite3
from pathlib import Path

from record import EVIDENCE, LAB, hashes, stamp, write_json

end = stamp()
if end['elapsed_seconds'] < 2700:
    raise SystemExit('The actual 45-minute window has not elapsed')
start = json.loads((EVIDENCE / '00-start.json').read_text())
constraint = json.loads((EVIDENCE / '25-constraint-received.json').read_text())
stages = []
for name in ['00-initial', '05-scope-capacity', '13-state-and-failures', '25-before-injection', '40-revised-protocol', '45-final']:
    path = EVIDENCE / 'stages' / name
    receipt = json.loads((path / 'receipt.json').read_text())
    for source, expected in receipt['source_sha256'].items():
        assert hashlib.sha256((path / 'source' / source).read_bytes()).hexdigest() == expected, (name, source)
    stages.append({'name': name, 'receipt': str((path / 'receipt.json').relative_to(EVIDENCE)),
                   'draft': str((path / 'source' / 'design.md').relative_to(EVIDENCE)),
                   'utc': receipt['utc'], 'elapsed_seconds': receipt['elapsed_seconds'],
                   'nominal_minutes': receipt['nominal_minutes'], 'delay_seconds': receipt['delay_seconds']})
assert stages[3]['elapsed_seconds'] < constraint['received']['elapsed_seconds']
suite_path = EVIDENCE / 'runs' / '22-full-protocol-suite'
suite = json.loads((suite_path / 'stdout.txt').read_text())
assert suite['pass'] is True and suite['scenario_count'] == 14
suite_command = json.loads((suite_path / 'command.json').read_text())
for name in ['tickets.py', 'capture_protocol.py']:
    assert hashes()[name] == suite_command['source_sha256'][name], name
criteria = []
for case in suite['cases']:
    case_dir = suite_path / Path(case['script']).stem
    raw = case_dir / 'stdout.txt'
    run = json.loads((case_dir / 'command-result.json').read_text())
    assert raw.stat().st_size > 0 and run['exit_code'] == 0
    result = json.loads(raw.read_text())
    observed = result.get('pass', result.get('witness_reproduced'))
    assert observed is True
    criteria.append({'scenario': case['scenario'], 'invocation': run['argv'],
                     'cwd': run['cwd'], 'binary_observable': {'field': 'pass' if 'pass' in result else 'witness_reproduced', 'value': True},
                     'stdout': str(raw.relative_to(EVIDENCE)),
                     'command_exit_hash': str((case_dir / 'command-result.json').relative_to(EVIDENCE))})
failed = []
recorded_command_seconds = 0
for path in sorted((EVIDENCE / 'runs').iterdir()):
    command = json.loads((path / 'command.json').read_text())
    result = json.loads((path / 'result.json').read_text())
    recorded_command_seconds += result['finished']['elapsed_seconds'] - command['elapsed_seconds']
    for source, expected in command['source_sha256'].items():
        assert hashlib.sha256((path / 'source' / source).read_bytes()).hexdigest() == expected, (path.name, source)
    assert (path / 'stdout.txt').exists() and (path / 'stderr.txt').exists()
    if result['exit_code']:
        assert (path / 'stderr.txt').stat().st_size > 0
        failed.append({'run': path.name, 'exit_code': result['exit_code'], 'stderr': str((path / 'stderr.txt').relative_to(EVIDENCE))})
assert {row['run'] for row in failed} == {'06-expired-view-red', '09-identity-red', '18-injected-capture-protocol'}
receipt = {'executor': 'AI', 'environment': {'python': platform.python_version(), 'sqlite': sqlite3.sqlite_version, 'platform': platform.platform()}, 'scope': 'written design and local executable verification',
           'verdict': 'LOCAL_SCENARIOS_VERIFIED_WITH_TIMING_LIMITATIONS',
           'start': start, 'end': end, 'elapsed_wall_clock_seconds': end['elapsed_seconds'],
           'stages': stages, 'constraint_receipt': constraint,
           'timing_disclosure': {'zero_minute_clock_record': '00-start.json',
                                'initial_readable_draft_delay_seconds': stages[0]['delay_seconds'],
                                'exact_zero_minute_design_snapshot': False,
                                'intentional_idle_sleep_calls': 0,
                                'breaks_recorded': [],
                                'recorded_command_runtime_seconds': recorded_command_seconds,
                                'tool_dispatch_and_model_scheduling_wait_seconds': 'not separately measured',
                                'pure_effective_design_seconds': 'not independently measured; do not equate with wall clock'},
           'criteria': criteria, 'preserved_failed_runs': failed,
           'capacity': {'original_500_full_conversion_commit_per_second': 1000,
                        'revised_success_inventory_commits': 4,
                        'revised_500_full_conversion_commit_per_second': 2000,
                        'revised_new_hold_admission_per_second': 160,
                        'main_path_commit_per_second': 640, 'recovery_reserve_commit_per_second': 160,
                        'capacity_type': 'given bound plus observed local transaction count, no production throughput claim'},
           'unverified': ['real payment channel NOT_RUN', 'real money NOT_RUN', 'replicated DB failover NOT_RUN',
                          'distributed admission NOT_RUN', '5000 req/s or 5000 reads/s load NOT_RUN',
                          'PINNED release after terminal provider proof NOT_IMPLEMENTED; current prototype retains the seat',
                          'human oral interview ability NOT_ASSESSED'],
           'current_source_sha256': hashes(),
           'evidence_integrity': 'all frozen source hashes and command receipts checked; empty stderr is a legitimate raw stream'}
write_json(EVIDENCE / 'receipt.json', receipt)
manifest = {}
for path in sorted(EVIDENCE.rglob('*')):
    if path.is_file():
        manifest[str(path.relative_to(EVIDENCE))] = {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
write_json(EVIDENCE / 'manifest.json', manifest)
print(json.dumps({'receipt': str(EVIDENCE / 'receipt.json'), 'manifest_files': len(manifest),
                  'scenarios': len(criteria), 'elapsed_seconds': end['elapsed_seconds'], 'pass': True}, indent=2))
