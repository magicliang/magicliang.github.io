from contextlib import closing
import json
import os
from pathlib import Path
import sqlite3

from tickets import TicketStore

root = Path(os.environ['TICKET_RUN_DIR'])
store = TicketStore(root / 'timeout.sqlite', clock=lambda: 1000, timeout=0)
store.initialize(2)
order = store.hold('alice', 'one', 1)
errors = []
with closing(store.connect()) as blocker:
    blocker.execute('BEGIN IMMEDIATE')
    for operation in [lambda: store.hold('bob', 'two', 2), lambda: store.pay('payment', order['id'])]:
        try:
            operation()
        except sqlite3.OperationalError as error:
            errors.append({'type': type(error).__name__, 'message': str(error), 'code': error.sqlite_errorcode})
        else:
            raise AssertionError('locked writer returned success')
    assert store.rows('ledger') == []
    assert len(store.rows('orders')) == 1
    blocker.execute("UPDATE seats SET state='SOLD' WHERE id=1")
    assert store.rows('seats')[0]['state'] == 'HELD'
    blocker.rollback()
assert [error['code'] for error in errors] == [sqlite3.SQLITE_BUSY] * 2
assert store.pay('payment', order['id']) == 'BOOKED'
assert store.hold('bob', 'two', 2) is not None
assert len(store.rows('ledger')) == 1
print(json.dumps({'scenario': 'busy_timeout_no_false_success_and_retry', 'errors': errors,
                  'uncommitted_sale_invisible': True, 'post_unlock_retries_succeeded': True,
                  'ledger_rows': 1, 'pass': True}, indent=2))
