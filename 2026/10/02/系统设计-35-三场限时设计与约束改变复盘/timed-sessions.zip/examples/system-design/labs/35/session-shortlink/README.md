# 第 35 篇：短链限时设计实验

本目录保存 AI 执行者的一场书面设计演进。会话时钟与应用测试时钟分开：检查点使用操作系统 UTC 和 monotonic_ns，单元测试通过 clock 参数控制到期边界。记录不代表人的口述、面试表现或 45 分钟连续人工思考。

所有实验使用 Python 标准库与本机 SQLite；创建临时数据库，HTTP 场景只绑定 127.0.0.1 的临时端口，不访问 Location 指向的目标站。X-Lab-Owner 是身份夹具，未实现生产认证。schema 为本实验新建数据库定义，没有提供旧库迁移。

从仓库根目录运行完整测试：

```bash
python3 -m unittest discover -s examples/system-design/labs/35/session-shortlink -p 'test_*.py' -v
```

记录新的原始输出、退出码、版本与源文件快照；每次使用尚不存在的记录名：

```bash
python3 examples/system-design/labs/35/session-shortlink/capture.py manual-check-001 python3 -m unittest discover -p 'test_*.py' -v
```

`capture.py` 在实验目录内执行命令，输出写入 `examples/system-design/evidence/35/session-shortlink/<记录名>/`。stdout 与 stderr 分开保存；unittest 的通过清单通常在 stderr.log。source/ 保存本次运行对应的源码，run.json 记录 SHA-256。已有记录名会报错，不覆盖历史输出。

三个反例脚本故意启用错误路径，并在成功观察到错误行为后退出 2：

```bash
python3 examples/system-design/labs/35/session-shortlink/counterexamples.py
python3 examples/system-design/labs/35/session-shortlink/recovery_counterexample.py
python3 examples/system-design/labs/35/session-shortlink/lease_counterexamples.py
```

`capacity.py` 计算带单位的容量与敏感性；`load_sample.py` 只做一万行、4000 次函数调用的有限读样本。样本速率不是生产吞吐验收，不含 HTTP、混合写负载、全量数据、三副本或故障切换。

初始实现以一个 SQL 权威支持创建、重试、撤销和到期。创建确认在 links、requests 与序号事务提交后；新请求每次读取新状态，权威不可读则拒绝跳转。默认短码由持久化序号生成，可枚举；它只作为公开标识。到期清理不删除高水位；幂等结果保留 30 天。恢复旧备份会破坏这些保证，因此恢复环境必须完成历史追平后才能接入流量。

阶段文件位于 evidence 目录的 00-start、05-baseline、13-data-path 等记录中，包含实际记录时间。早期 source 快照故意保留当时方案，不能用当前源码替代。新的约束只有在父执行者实际发来后才进入后续方案；最终采用的修订与结果以本场结束 receipt 为准。

追加约束后的 `lease_gate.py` 是有限本地模型，未接入前述 HTTP 适配器。它表达短期读租约、202 待撤销确认、到期后的 204 确认、分区入口失败关闭，以及独立撤销日志重放。初始 HTTP 适配器保留基线语义，不能直接配合租约缓存上线。测试的 connected 与 clock_trusted 是显式模型输入，不是真实网络隔离或时钟检测器。

新约束方案及推导见 `examples/system-design/evidence/35/session-shortlink/35-constraint-revision.md`。固定时钟下 20000 个请求集合产生 2020 次租约查询，验证的是请求合并次数，不能换写成每秒吞吐。5000/s 是题给能力；实现没有生产限流器、三副本共识、跨主机时钟监控、完整恢复高水位或日志压缩。
