import json
import os
from pathlib import Path
import signal
import subprocess
import sys

from capture_protocol import CaptureStore, FakeChannel

root = Path(os.environ['TICKET_RUN_DIR'])
results = []
for index, point in enumerate(['after_authorize', 'after_pin_before_capture', 'after_capture_before_local_commit', 'after_authorize']):
    inventory = root / f'inventory-{index}.sqlite'
    provider = root / f'provider-{index}.sqlite'
    channel = FakeChannel(provider)
    channel.initialize()
    store = CaptureStore(inventory, channel, clock=lambda: 1000)
    store.initialize()
    order = store.hold('alice', 'one', 1)
    key = 'intent-' + str(index)
    store.start_payment(order['id'], key)
    argv = [sys.executable, 'capture_crash_worker.py', str(inventory), str(provider), key, point]
    child = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    try:
        line = child.stdout.readline()
        assert json.loads(line)['checkpoint'] == point, line
        child.kill()
        stdout, stderr = child.communicate(timeout=5)
    finally:
        if child.poll() is None:
            child.kill()
            child.communicate(timeout=5)
    (root / f'child-{index}-stdout.txt').write_text(line + stdout)
    (root / f'child-{index}-stderr.txt').write_text(stderr)
    assert child.returncode == -signal.SIGKILL
    restarted = CaptureStore(inventory, FakeChannel(provider), clock=lambda: 1000)
    assert restarted.pending_keys() == [key]
    store = restarted
    before = {'seat': store.rows('seats')[0], 'intent': store.intent(key), 'channel': channel.query(key)}
    if index == 3:
        store.clock = lambda: 1300
        replacement = store.hold('bob', 'after-expiry', 1)
        assert replacement
        recovery = store.recover(key)
        assert recovery == 'VOIDED'
        assert channel.records()[0]['capture_count'] == 0
        assert store.rows('seats')[0]['hold_id'] == replacement['hold_id']
        assert store.rows('ledger') == []
    else:
        if point != 'after_authorize':
            store.clock = lambda: 5000
            assert store.expire(order['hold_id']) is False
            assert store.hold('bob', 'cannot-steal', 1) is None
        recovery = store.recover(key)
        assert recovery == 'BOOKED'
        assert channel.records()[0]['capture_count'] == len(store.rows('ledger')) == 1
        assert store.recover(key) == 'BOOKED'
    assert store.pending_keys() == []
    results.append({'argv': argv, 'worker_exit': child.returncode, 'checkpoint': point,
                    'before_recovery': before, 'recovery': recovery, 'channel': channel.records(),
                    'ledger_rows': len(store.rows('ledger'))})
print(json.dumps({'scenario': 'authorization_capture_process_crash_recovery', 'cases': results,
                  'real_channel': 'NOT_RUN', 'scope': 'two local SQLite databases and real killed subprocesses', 'pass': True}, indent=2))
