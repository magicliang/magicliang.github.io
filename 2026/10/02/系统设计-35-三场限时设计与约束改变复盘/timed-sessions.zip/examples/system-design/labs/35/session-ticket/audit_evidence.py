import hashlib
import json
from pathlib import Path
import sqlite3

from record import EVIDENCE

verified_sources = 0
runs = []
for directory in sorted((EVIDENCE / 'runs').iterdir()):
    if not (directory / 'result.json').exists():
        continue
    command = json.loads((directory / 'command.json').read_text())
    result = json.loads((directory / 'result.json').read_text())
    for source, expected in command['source_sha256'].items():
        actual = hashlib.sha256((directory / 'source' / source).read_bytes()).hexdigest()
        assert actual == expected, (directory.name, source)
        verified_sources += 1
    for stream in ['stdout', 'stderr']:
        assert (directory / (stream + '.txt')).stat().st_size == result[stream + '_bytes']
    assert result['finished']['elapsed_seconds'] >= command['elapsed_seconds']
    runs.append({'run': directory.name, 'exit_code': result['exit_code']})
for directory in sorted((EVIDENCE / 'stages').iterdir()):
    receipt = json.loads((directory / 'receipt.json').read_text())
    assert receipt['elapsed_seconds'] >= receipt['nominal_minutes'] * 60
    for source, expected in receipt['source_sha256'].items():
        assert hashlib.sha256((directory / 'source' / source).read_bytes()).hexdigest() == expected
        verified_sources += 1
databases = list(EVIDENCE.rglob('*.sqlite'))
for path in databases:
    connection = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)
    try:
        assert connection.execute('PRAGMA integrity_check').fetchone()[0] == 'ok', path
    finally:
        connection.close()
expected_failures = {'06-expired-view-red', '09-identity-red', '18-injected-capture-protocol'}
assert {row['run'] for row in runs if row['exit_code']} == expected_failures
print(json.dumps({'scenario': 'artifact_integrity_audit', 'frozen_source_hashes_verified': verified_sources,
                  'completed_runs': runs, 'sqlite_integrity_checked': len(databases),
                  'expected_original_failures_preserved': sorted(expected_failures), 'pass': True}, indent=2))
