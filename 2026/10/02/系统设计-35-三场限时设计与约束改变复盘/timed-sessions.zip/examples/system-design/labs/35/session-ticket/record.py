import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

LAB = Path(__file__).resolve().parent
EVIDENCE = LAB.parents[2] / "evidence" / "35" / "session-ticket"


def stamp():
    start = json.loads((EVIDENCE / "00-start.json").read_text())
    monotonic = time.monotonic_ns()
    return {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "monotonic_ns": monotonic,
            "elapsed_seconds": (monotonic - start["monotonic_ns"]) / 1e9}


def hashes():
    return {str(p.relative_to(LAB)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(LAB.rglob("*"))
            if p.is_file() and "__pycache__" not in p.parts}


def write_json(path, value):
    with path.open("x") as output:
        json.dump(value, output, ensure_ascii=False, indent=2)
        output.write("\n")


def event(kind, detail):
    row = {**stamp(), "kind": kind, **detail}
    with (EVIDENCE / "journal.jsonl").open("a") as output:
        output.write(json.dumps(row, ensure_ascii=False) + "\n")
    return row


def stage(label, minutes):
    directory = EVIDENCE / "stages" / label
    directory.mkdir(parents=True, exist_ok=False)
    before = stamp()
    if before["elapsed_seconds"] < minutes * 60:
        directory.rmdir()
        raise SystemExit("Refusing a snapshot before the actual milestone")
    shutil.copytree(LAB, directory / "source", ignore=shutil.ignore_patterns("__pycache__"))
    receipt = {**before, "nominal_minutes": minutes,
               "delay_seconds": before["elapsed_seconds"] - minutes * 60,
               "source_sha256": hashes(), "executor": "AI"}
    write_json(directory / "receipt.json", receipt)
    event("stage_saved", {"label": label, "path": str(directory)})
    print(json.dumps(receipt, ensure_ascii=False))


def run(label, argv):
    directory = EVIDENCE / "runs" / label
    directory.mkdir(parents=True, exist_ok=False)
    before = stamp()
    source = hashes()
    shutil.copytree(LAB, directory / "source", ignore=shutil.ignore_patterns("__pycache__"))
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", TICKET_RUN_DIR=str(directory))
    write_json(directory / "command.json", {"argv": argv, "cwd": str(LAB), **before,
                                            "source_sha256": source})
    with (directory / "stdout.txt").open("xb") as stdout, (directory / "stderr.txt").open("xb") as stderr:
        process = subprocess.run(argv, cwd=LAB, env=env, stdout=stdout, stderr=stderr)
    result = {"exit_code": process.returncode, "finished": stamp(),
              "stdout_bytes": (directory / "stdout.txt").stat().st_size,
              "stderr_bytes": (directory / "stderr.txt").stat().st_size,
              "source_sha256_after": hashes()}
    write_json(directory / "result.json", result)
    event("command_finished", {"label": label, "exit_code": process.returncode,
                                "started": before, "path": str(directory)})
    print((directory / "stdout.txt").read_text())
    print((directory / "stderr.txt").read_text())
    print(json.dumps(result))
    return process.returncode


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="operation", required=True)
    snapshot = sub.add_parser("stage")
    snapshot.add_argument("label")
    snapshot.add_argument("minutes", type=int)
    command = sub.add_parser("run")
    command.add_argument("label")
    command.add_argument("argv", nargs=argparse.REMAINDER)
    note = sub.add_parser("note")
    note.add_argument("text")
    args = parser.parse_args()
    if args.operation == "stage":
        stage(args.label, args.minutes)
    elif args.operation == "run":
        raise SystemExit(run(args.label, args.argv))
    else:
        print(json.dumps(event("work_note", {"text": args.text}), ensure_ascii=False))
