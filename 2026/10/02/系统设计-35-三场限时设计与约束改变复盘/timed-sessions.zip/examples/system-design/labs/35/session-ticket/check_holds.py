from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import sqlite3
import threading

from tickets import Conflict, TicketStore

directory = Path(os.environ["TICKET_RUN_DIR"])
store = TicketStore(directory / "holds.sqlite", clock=lambda: 1000)
store.initialize(2)
barrier = threading.Barrier(16)


def contender(index):
    barrier.wait()
    return store.hold(f"buyer-{index}", f"request-{index}", 1)


with ThreadPoolExecutor(max_workers=16) as pool:
    results = list(pool.map(contender, range(16)))
winners = [row for row in results if row]
assert len(winners) == 1, winners
winner = winners[0]
retry = store.hold(winner["buyer"], winner["request_key"], 1)
assert retry == winner
assert len(store.rows("orders")) == 1
try:
    store.hold(winner["buyer"], winner["request_key"], 2)
except Conflict:
    mismatch_rejected = True
else:
    raise AssertionError("same buyer key accepted a different seat")
other = store.hold("independent-buyer", winner["request_key"], 2)
assert other and other["id"] != winner["id"]
store.clock = lambda: 1299
assert store.hold("reclaimer", "reclaim", 1) is None
store.clock = lambda: 1300
replacement = store.hold("reclaimer", "reclaim", 1)
assert replacement and replacement["hold_id"] != winner["hold_id"]
old = next(row for row in store.rows("orders") if row["id"] == winner["id"])
assert old["state"] == "EXPIRED"
assert store.rows("seats")[0]["hold_id"] == replacement["hold_id"]
with store.connect() as db:
    integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
assert integrity == "ok"
print(json.dumps({"scenario": "atomic_holds_retry_reclaim", "sqlite": sqlite3.sqlite_version,
                  "contenders": 16, "winners": len(winners), "same_request_same_order": retry == winner,
                  "same_key_other_seat_rejected": mismatch_rejected,
                  "same_key_other_buyer_allowed": bool(other), "expiry_equal_reclaimed": bool(replacement),
                  "old_order": old, "replacement": replacement,
                  "seats": store.rows("seats"), "integrity": integrity, "pass": True}, indent=2))
