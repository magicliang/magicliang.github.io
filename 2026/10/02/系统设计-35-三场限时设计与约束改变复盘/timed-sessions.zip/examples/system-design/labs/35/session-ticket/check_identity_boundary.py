import json
import os
from pathlib import Path

from tickets import TicketStore

root = Path(os.environ['TICKET_RUN_DIR'])
store = TicketStore(root / 'identity-boundary.sqlite', clock=lambda: 1000)
store.initialize(2)
first = store.hold('alice', 'one', 1)
second = store.hold('bob', 'two', 2)
rejected = []
for payment_id in [None, '', '   ', 42]:
    try:
        store.pay(payment_id, first['id'])
    except ValueError:
        rejected.append(repr(payment_id))
    else:
        raise AssertionError({'invalid_payment_id_accepted': payment_id,
                              'payments': store.rows('payments'), 'ledger': store.rows('ledger')})
assert store.rows('payments') == [] and store.rows('ledger') == []
for amount in [None, 0, -1, True, '10000']:
    try:
        store.pay('invalid-amount', first['id'], amount)
    except ValueError:
        rejected.append(repr(amount))
    else:
        raise AssertionError({'invalid_amount_accepted': amount})
assert store.pay('one-payment', first['id']) == 'BOOKED'
try:
    store.pay('one-payment', second['id'])
except ValueError:
    pass
else:
    raise AssertionError('same payment identity booked a second order')
assert len(store.rows('ledger')) == 1
assert store.order(second['id'])['state'] == 'HELD'
print(json.dumps({'scenario': 'required_payment_identity_and_amount', 'rejected': rejected,
                  'one_payment_cannot_book_second_order': True, 'ledger_rows': 1, 'pass': True}, indent=2))
