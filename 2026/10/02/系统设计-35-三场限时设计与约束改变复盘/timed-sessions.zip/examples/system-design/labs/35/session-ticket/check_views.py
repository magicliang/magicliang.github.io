import json
import os
from pathlib import Path

from tickets import TicketStore

root = Path(os.environ['TICKET_RUN_DIR'])
store = TicketStore(root / 'views.sqlite', clock=lambda: 1000)
store.initialize(2)
original = store.hold('alice', 'same-key', 1)
store.clock = lambda: 1300
retry = store.hold('alice', 'same-key', 1)
assert retry['state'] == 'EXPIRED', {'issue': 'expired retry displayed HELD', 'returned': retry}
assert retry['id'] == original['id'] and retry['expires_at'] == original['expires_at']
assert store.order(original['id'])['state'] == 'EXPIRED'
assert store.availability() == 2
replacement = store.hold('alice', 'new-key', 1)
assert replacement['id'] != original['id']
assert store.availability() == 1
assert store.pay('payment', replacement['id']) == 'BOOKED'
store.clock = lambda: 999999
assert store.availability() == 1
assert store.order(replacement['id'])['state'] == 'PAID'
assert store.order(original['id'])['state'] == 'EXPIRED'
assert len(store.rows('orders')) == 2
print(json.dumps({'scenario': 'read_views_and_expired_idempotent_retry', 'expired_retry': retry,
                  'same_order_no_lease_extension': True, 'sold_not_available_after_expiry': True,
                  'order_count': 2, 'pass': True}, indent=2))
