import json
import sys

from tickets import TicketStore

path, order_id, point = sys.argv[1:]
store = TicketStore(path, clock=lambda: 1000)


def rendezvous(actual):
    if actual == point:
        print(json.dumps({'checkpoint': actual}), flush=True)
        sys.stdin.readline()


result = store.pay('crash-payment', order_id, checkpoint=rendezvous)
rendezvous('after_commit_before_response')
print(json.dumps({'response': result}), flush=True)
