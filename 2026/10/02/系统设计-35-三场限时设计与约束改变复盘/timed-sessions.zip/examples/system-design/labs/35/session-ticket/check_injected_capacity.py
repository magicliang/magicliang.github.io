import json
import os
from pathlib import Path

from capture_protocol import CaptureStore, FakeChannel

root = Path(os.environ['TICKET_RUN_DIR'])
commits = []


class CommitObservedStore(CaptureStore):
    def connect(self):
        db = super().connect()
        db.set_trace_callback(lambda sql: commits.append(sql) if sql == 'COMMIT' else None)
        return db


channel = FakeChannel(root / 'channel.sqlite')
channel.initialize()
store = CommitObservedStore(root / 'inventory.sqlite', channel, clock=lambda: 1000)
store.initialize()
commits.clear()
counts = {}
order = store.hold('alice', 'one', 1)
counts['hold'] = len(commits)
store.start_payment(order['id'], 'intent')
counts['authorization_intent'] = len(commits) - counts['hold']
assert store.recover('intent') == 'BOOKED'
counts['pin_and_final_ledger'] = len(commits) - counts['hold'] - counts['authorization_intent']
assert counts == {'hold': 1, 'authorization_intent': 1, 'pin_and_final_ledger': 2}
assert len(commits) == 4
safe_budget = 800
reserve = 160
new_hold_budget = (safe_budget - reserve) // len(commits)
assert new_hold_budget == 160
inputs = [1] * 4500 + list(range(2, 502))
pending_seats = set()
admitted = []
rejected_hot = 0
rejected_global = 0
for seat in inputs:
    if seat in pending_seats:
        rejected_hot += 1
    elif len(admitted) >= new_hold_budget:
        rejected_global += 1
    else:
        pending_seats.add(seat)
        admitted.append(seat)
assert len(inputs) == 5000 and len(admitted) == 160
assert admitted.count(1) == 1
assert rejected_hot == 4499 and rejected_global == 341
print(json.dumps({'scenario': 'injected_hotspot_admission_budget_and_observed_commit_weight',
                  'observed_inventory_commits_per_success': len(commits), 'commit_breakdown': counts,
                  'old_protocol_500_full_conversion_commit_per_second': 1000,
                  'new_protocol_500_full_conversion_commit_per_second': 2000,
                  'new_protocol_5000_unlimited_full_conversion_commit_per_second': 20000,
                  'admitted_new_holds_per_second_design_budget': new_hold_budget,
                  'new_protocol_budget_commit_per_second': new_hold_budget * len(commits),
                  'recovery_reserve_commit_per_second': reserve,
                  'single_hot_seat_model': {'inputs': len(inputs), 'hot_inputs': 4500, 'admitted': len(admitted),
                                             'hot_admitted': admitted.count(1), 'hot_rejected': rejected_hot,
                                             'global_rejected': rejected_global},
                  'scope': 'COMMIT weight observed on SQLite; offered rates supplied; admission is a finite model, not deployed limiter or load test',
                  'pass': True}, indent=2))
