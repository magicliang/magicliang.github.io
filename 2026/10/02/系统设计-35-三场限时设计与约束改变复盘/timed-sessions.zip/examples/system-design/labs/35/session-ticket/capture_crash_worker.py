import json
import sys

from capture_protocol import CaptureStore, FakeChannel

inventory, provider, key, point = sys.argv[1:]
store = CaptureStore(inventory, FakeChannel(provider), clock=lambda: 1000)


def rendezvous(actual):
    if actual == point:
        print(json.dumps({'checkpoint': actual}), flush=True)
        sys.stdin.readline()


print(json.dumps({'result': store.recover(key, checkpoint=rendezvous)}), flush=True)
