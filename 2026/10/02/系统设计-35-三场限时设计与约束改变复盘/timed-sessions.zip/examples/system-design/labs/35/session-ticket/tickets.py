import sqlite3
import time
import uuid
from contextlib import closing, contextmanager


class Conflict(ValueError):
    pass


class TicketStore:
    def __init__(self, path, clock=time.time, timeout=5):
        self.path = path
        self.clock = clock
        self.timeout = timeout

    def connect(self):
        db = sqlite3.connect(self.path, timeout=self.timeout, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        return db

    def initialize(self, count=1):
        with closing(self.connect()) as db:
            db.executescript("""
                CREATE TABLE seats (
                    id INTEGER PRIMARY KEY,
                    state TEXT NOT NULL CHECK (state IN ('FREE','HELD','PINNED','SOLD')),
                    hold_id TEXT,
                    expires_at INTEGER,
                    CHECK ((state='FREE' AND hold_id IS NULL AND expires_at IS NULL)
                        OR (state IN ('HELD','PINNED','SOLD') AND hold_id IS NOT NULL AND expires_at IS NOT NULL))
                );
                CREATE TABLE orders (
                    id TEXT PRIMARY KEY NOT NULL,
                    buyer TEXT NOT NULL,
                    request_key TEXT NOT NULL,
                    seat_id INTEGER NOT NULL REFERENCES seats(id),
                    hold_id TEXT NOT NULL UNIQUE,
                    expires_at INTEGER NOT NULL,
                    state TEXT NOT NULL CHECK (state IN ('HELD','CAPTURE_PENDING','EXPIRED','PAID')),
                    amount_cents INTEGER NOT NULL CHECK (amount_cents>0),
                    currency TEXT NOT NULL,
                    UNIQUE(buyer,request_key)
                );
                CREATE UNIQUE INDEX one_paid_order_per_seat ON orders(seat_id) WHERE state='PAID';
                CREATE TABLE payments (
                    id TEXT PRIMARY KEY NOT NULL,
                    order_id TEXT NOT NULL REFERENCES orders(id),
                    amount_cents INTEGER NOT NULL CHECK (amount_cents>0),
                    currency TEXT NOT NULL,
                    result TEXT NOT NULL CHECK (result IN ('BOOKED','REFUND_PENDING'))
                );
                CREATE TABLE ledger (
                    payment_id TEXT PRIMARY KEY NOT NULL REFERENCES payments(id),
                    order_id TEXT NOT NULL UNIQUE REFERENCES orders(id),
                    amount_cents INTEGER NOT NULL CHECK (amount_cents>0)
                );
                CREATE TABLE refunds (
                    payment_id TEXT PRIMARY KEY NOT NULL REFERENCES payments(id),
                    reason TEXT NOT NULL,
                    state TEXT NOT NULL CHECK (state IN ('PENDING','DONE'))
                );
            """)
            db.execute("BEGIN")
            db.executemany("INSERT INTO seats VALUES(?,'FREE',NULL,NULL)",
                           [(i,) for i in range(1, count + 1)])
            db.commit()

    @contextmanager
    def transaction(self):
        db = self.connect()
        try:
            db.execute("BEGIN IMMEDIATE")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def require_identity(value, field):
        if not isinstance(value, str) or not value.strip():
            raise ValueError(field + " must be a nonempty string")

    def hold(self, buyer, request_key, seat_id):
        self.require_identity(buyer, "buyer")
        self.require_identity(request_key, "request_key")
        if type(seat_id) is not int or seat_id <= 0:
            raise ValueError("seat_id must be a positive integer")
        with self.transaction() as db:
            now = int(self.clock())
            previous = db.execute("SELECT * FROM orders WHERE buyer=? AND request_key=?",
                                  (buyer, request_key)).fetchone()
            if previous:
                if previous["seat_id"] != seat_id:
                    raise Conflict("request key reused for another seat")
                return self.order_view(previous, now)
            seat = db.execute("SELECT * FROM seats WHERE id=?", (seat_id,)).fetchone()
            if not seat:
                raise KeyError(seat_id)
            hold_id, order_id = uuid.uuid4().hex, uuid.uuid4().hex
            changed = db.execute("""UPDATE seats SET state='HELD',hold_id=?,expires_at=?
                WHERE id=? AND (state='FREE' OR (state='HELD' AND expires_at<=?))""",
                                 (hold_id, now + 300, seat_id, now)).rowcount
            if not changed:
                return None
            if seat["hold_id"]:
                db.execute("UPDATE orders SET state='EXPIRED' WHERE hold_id=? AND state='HELD'",
                           (seat["hold_id"],))
            db.execute("INSERT INTO orders VALUES(?,?,?,?,?,?,'HELD',10000,'CNY')",
                       (order_id, buyer, request_key, seat_id, hold_id, now + 300))
            return dict(db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone())

    def pay(self, payment_id, order_id, amount_cents=10000, currency="CNY", checkpoint=None):
        self.require_identity(payment_id, "payment_id")
        self.require_identity(order_id, "order_id")
        self.require_identity(currency, "currency")
        if type(amount_cents) is not int or amount_cents <= 0:
            raise ValueError("amount_cents must be a positive integer")
        with self.transaction() as db:
            now = int(self.clock())
            previous = db.execute("SELECT * FROM payments WHERE id=?", (payment_id,)).fetchone()
            identity = (order_id, amount_cents, currency)
            if previous:
                old_identity = (previous["order_id"], previous["amount_cents"], previous["currency"])
                if old_identity != identity:
                    raise Conflict("payment id changed order, amount or currency")
                return previous["result"]
            order = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
            if not order:
                raise KeyError(order_id)
            amount_matches = (amount_cents, currency) == (order["amount_cents"], order["currency"])
            sold = 0
            if amount_matches and order["state"] == "HELD":
                sold = db.execute("UPDATE seats SET state='SOLD' WHERE id=? AND state='HELD' "
                                  "AND hold_id=? AND expires_at>?",
                                  (order["seat_id"], order["hold_id"], now)).rowcount
            if checkpoint:
                checkpoint("after_seat_update")
            result = "BOOKED" if sold else "REFUND_PENDING"
            db.execute("INSERT INTO payments VALUES(?,?,?,?,?)",
                       (payment_id, order_id, amount_cents, currency, result))
            if sold:
                db.execute("INSERT INTO ledger VALUES(?,?,?)", (payment_id, order_id, amount_cents))
                db.execute("UPDATE orders SET state='PAID' WHERE id=?", (order_id,))
            else:
                reason = "amount_mismatch" if not amount_matches else "no_live_hold_or_already_paid"
                db.execute("INSERT INTO refunds VALUES(?,?,'PENDING')", (payment_id, reason))
                db.execute("UPDATE orders SET state='EXPIRED' WHERE id=? AND state='HELD' AND expires_at<=?",
                           (order_id, now))
            if checkpoint:
                checkpoint("before_commit")
            return result

    def expire(self, hold_id):
        with self.transaction() as db:
            now = int(self.clock())
            freed = db.execute("UPDATE seats SET state='FREE',hold_id=NULL,expires_at=NULL "
                               "WHERE hold_id=? AND state='HELD' AND expires_at<=?",
                               (hold_id, now)).rowcount
            if freed:
                db.execute("UPDATE orders SET state='EXPIRED' WHERE hold_id=? AND state='HELD'",
                           (hold_id,))
            return bool(freed)

    @staticmethod
    def order_view(row, now):
        result = dict(row)
        if result["state"] == "HELD" and result["expires_at"] <= now:
            result["state"] = "EXPIRED"
        return result

    def order(self, order_id):
        with closing(self.connect()) as db:
            row = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
            if not row:
                raise KeyError(order_id)
            return self.order_view(row, int(self.clock()))

    def availability(self):
        with closing(self.connect()) as db:
            return db.execute("SELECT count(*) FROM seats WHERE state='FREE' "
                              "OR (state='HELD' AND expires_at<=?)",
                              (int(self.clock()),)).fetchone()[0]

    def rows(self, table):
        if table not in {"seats", "orders", "payments", "ledger", "refunds"}:
            raise ValueError(table)
        with closing(self.connect()) as db:
            return [dict(row) for row in db.execute(f"SELECT * FROM {table}")]
