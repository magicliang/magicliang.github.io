from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import threading
from types import SimpleNamespace

from capture_protocol import CapabilityMissing, CaptureStore, ExternalUnknown, FakeChannel
from tickets import TicketStore

root = Path(os.environ['TICKET_RUN_DIR'])
observations = {}


def fresh(name, **channel_options):
    channel = FakeChannel(root / (name + '-channel.sqlite'), **channel_options)
    channel.initialize()
    store = CaptureStore(root / (name + '-inventory.sqlite'), channel, clock=lambda: 1000)
    store.initialize()
    order = store.hold('alice', 'one', 1)
    store.start_payment(order['id'], name)
    return store, channel, order


store, channel, order = fresh('capture-unknown', unknown_after='capture')
assert store.recover('capture-unknown') == 'EXTERNAL_UNKNOWN_RETRY_SAME_KEY'
assert channel.query('capture-unknown') == 'CAPTURED'
assert store.rows('seats')[0]['state'] == 'PINNED'
assert store.rows('ledger') == []
store.clock = lambda: 5000
assert store.expire(order['hold_id']) is False
assert store.hold('bob', 'after-old-expiry', 1) is None
channel.query_unknown = True
assert store.recover('capture-unknown') == 'EXTERNAL_UNKNOWN_RETRY_SAME_KEY'
assert store.rows('seats')[0]['state'] == 'PINNED'
channel.query_unknown = False
assert store.recover('capture-unknown') == 'BOOKED'
assert store.recover('capture-unknown') == 'BOOKED'
assert len(store.rows('ledger')) == 1 and channel.records()[0]['capture_count'] == 1
observations['captured_result_unknown'] = {'pinned_while_unknown': True, 'old_expiry_cannot_release': True,
                                           'capture_count': 1, 'ledger_count': 1}

store, channel, order = fresh('late-authorization', unknown_after='authorize')
assert store.recover('late-authorization') == 'EXTERNAL_UNKNOWN_RETRY_SAME_KEY'
assert channel.query('late-authorization') == 'AUTHORIZED'
store.clock = lambda: 1300
replacement = store.hold('bob', 'new', 1)
assert replacement
assert store.recover('late-authorization') == 'VOIDED'
assert channel.query('late-authorization') == 'VOIDED'
assert channel.records()[0]['capture_count'] == 0
assert store.rows('seats')[0]['hold_id'] == replacement['hold_id']
assert store.rows('ledger') == []
observations['late_authorization'] = {'authorization_voided': True, 'actual_captures': 0, 'replacement_preserved': True}

store, channel, order = fresh('authorize-unknown', unknown_after='authorize')
assert store.recover('authorize-unknown') == 'EXTERNAL_UNKNOWN_RETRY_SAME_KEY'
assert store.recover('authorize-unknown') == 'BOOKED'
assert channel.records()[0]['capture_count'] == 1
observations['authorization_response_lost'] = 'query existing authorization then pin and capture once'

store, channel, order = fresh('concurrent-recovery')
barrier = threading.Barrier(16)


def recover(_):
    barrier.wait()
    return store.recover('concurrent-recovery')


with ThreadPoolExecutor(max_workers=16) as pool:
    results = list(pool.map(recover, range(16)))
assert all(result in {'BOOKED', 'EXTERNAL_UNKNOWN_KEEP_PINNED'} for result in results), results
assert store.recover('concurrent-recovery') == 'BOOKED'
assert len(store.rows('ledger')) == 1 and channel.records()[0]['capture_count'] == 1
observations['concurrent_recovery'] = {'workers': len(results), 'outcomes': results, 'captures': 1, 'ledger': 1}

class AdvancedDuringAuthorize(FakeChannel):
    def authorize(self, key, amount, currency):
        super().authorize(key, amount, currency)
        assert self.other_worker.recover(key) == 'BOOKED'
        return self.query(key)


channel = AdvancedDuringAuthorize(root / 'interleaved-channel.sqlite')
channel.initialize()
store = CaptureStore(root / 'interleaved-inventory.sqlite', channel, clock=lambda: 1000)
channel.other_worker = store
store.initialize()
order = store.hold('alice', 'one', 1)
store.start_payment(order['id'], 'interleaved')
assert store.recover('interleaved') == 'BOOKED'
assert channel.records()[0]['capture_count'] == 1 and len(store.rows('ledger')) == 1
observations['authorization_returned_already_captured'] = 'fresh local intent prevents stale-state false violation'

capabilities = ['separate_authorize_capture', 'durable_idempotency', 'query_by_key', 'terminal_void']
rejections = []
for missing in capabilities:
    options = {item: True for item in capabilities}
    options[missing] = False
    try:
        CaptureStore(root / 'must-not-initialize.sqlite', SimpleNamespace(**options))
    except CapabilityMissing as error:
        rejections.append(str(error))
    else:
        raise AssertionError('unsupported channel accepted')
assert len(rejections) == 4
try:
    store.pay('direct-charge', order['id'])
except CapabilityMissing:
    pass
else:
    raise AssertionError('strong protocol accepted direct charge callback')
observations['capability_refusals'] = rejections

legacy = TicketStore(root / 'charge-first-negative.sqlite', clock=lambda: 1000)
legacy.initialize()
old = legacy.hold('alice', 'old', 1)
channel = FakeChannel(root / 'charge-first-channel.sqlite')
channel.initialize()
channel.authorize('charged-old', 10000, 'CNY')
assert channel.capture('charged-old') == 'CAPTURED'
legacy.clock = lambda: 1300
new = legacy.hold('bob', 'new', 1)
assert new
assert legacy.pay('charged-old', old['id']) == 'REFUND_PENDING'
assert legacy.rows('seats')[0]['hold_id'] == new['hold_id']
assert channel.query('charged-old') == 'CAPTURED' and legacy.rows('ledger') == []
observations['charge_first_negative_witness'] = {'actual_fake_channel_capture': True,
                                                'charged_customer_has_seat': False,
                                                'refund_pending_does_not_satisfy_promise': True}
print(json.dumps({'scenario': 'authorization_pin_capture_unknown_and_strong_promise_refusal',
                  'observations': observations, 'real_channel': 'NOT_RUN', 'pass': True}, indent=2))
