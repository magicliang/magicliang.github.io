import itertools
import json
import os
from pathlib import Path

from tickets import TicketStore

root = Path(os.environ['TICKET_RUN_DIR'])
all_cases = []


def invariant(store):
    rows = {name: store.rows(name) for name in ['seats', 'orders', 'payments', 'ledger', 'refunds']}
    paid = [order for order in rows['orders'] if order['state'] == 'PAID']
    sold = [seat for seat in rows['seats'] if seat['state'] == 'SOLD']
    booked = [payment for payment in rows['payments'] if payment['result'] == 'BOOKED']
    refundable = [payment for payment in rows['payments'] if payment['result'] == 'REFUND_PENDING']
    assert len(paid) <= 1, rows
    assert len(paid) == len(sold) == len(booked) == len(rows['ledger']), rows
    assert {payment['id'] for payment in refundable} == {refund['payment_id'] for refund in rows['refunds']}, rows
    if paid:
        assert sold[0]['hold_id'] == paid[0]['hold_id'], rows
        assert booked[0]['order_id'] == paid[0]['id'] == rows['ledger'][0]['order_id'], rows
    return {'paid': len(paid), 'sold': len(sold), 'ledger': len(rows['ledger']), 'refunds': len(refundable)}


for index, actions in enumerate(itertools.permutations(['old_pay', 'advance', 'reclaim', 'old_expire'])):
    if actions.index('advance') > actions.index('reclaim'):
        continue
    clock = {'now': 1000}
    store = TicketStore(root / f'schedule-{index:02}.sqlite', clock=lambda: clock['now'])
    store.initialize()
    old = store.hold('alice', 'old', 1)
    clock['now'] = 1299
    new = None
    trace = []
    for action in actions:
        if action == 'old_pay':
            outcome = store.pay('old-payment', old['id'])
        elif action == 'advance':
            clock['now'] = 1300
            outcome = clock['now']
        elif action == 'reclaim':
            new = store.hold('bob', 'new', 1)
            outcome = 'HELD' if new else 'CONFLICT'
        else:
            outcome = store.expire(old['hold_id'])
        trace.append({'action': action, 'now': clock['now'], 'outcome': outcome, 'invariant': invariant(store)})
    if new:
        assert store.pay('new-payment', new['id']) == 'BOOKED'
        expected = 'new-payment'
    else:
        expected = 'old-payment'
    final = invariant(store)
    assert final['paid'] == 1
    assert store.rows('ledger')[0]['payment_id'] == expected
    first = store.pay('old-payment', old['id'])
    second = store.pay('old-payment', old['id'])
    assert first == second
    assert invariant(store) == final
    all_cases.append({'actions': actions, 'trace': trace, 'winner': expected, 'final': final})
assert len(all_cases) == 12
assert {row['winner'] for row in all_cases} == {'old-payment', 'new-payment'}
print(json.dumps({'scenario': 'bounded_real_sqlite_boundary_schedules', 'cases': all_cases,
                  'schedules_checked': len(all_cases), 'invariant_checks': len(all_cases) * 6,
                  'scope': '12 enumerated schedules, not an exhaustive distributed-system proof', 'pass': True}, indent=2))
