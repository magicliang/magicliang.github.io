from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import threading

from tickets import Conflict, TicketStore

root = Path(os.environ['TICKET_RUN_DIR'])
observations = {}


def fresh(name, count=1):
    store = TicketStore(root / (name + '.sqlite'), clock=lambda: 1000)
    store.initialize(count)
    return store


store = fresh('late-reacquire')
old = store.hold('alice', 'first', 1)
store.clock = lambda: 1300
new = store.hold('alice', 'second', 1)
assert store.pay('old-payment', old['id']) == 'REFUND_PENDING'
assert store.pay('old-payment', old['id']) == 'REFUND_PENDING'
assert store.expire(old['hold_id']) is False
assert store.rows('seats')[0]['hold_id'] == new['hold_id']
assert store.pay('new-payment', new['id']) == 'BOOKED'
assert store.pay('new-payment', new['id']) == 'BOOKED'
assert store.pay('another-payment', new['id']) == 'REFUND_PENDING'
assert len(store.rows('ledger')) == 1
assert len(store.rows('refunds')) == 2
assert next(row for row in store.rows('orders') if row['id'] == new['id'])['state'] == 'PAID'
assert store.hold('other', 'r', 1) is None
observations['same_buyer_old_hold_fenced'] = {table: store.rows(table) for table in ('seats', 'orders', 'payments', 'ledger', 'refunds')}

store = fresh('expiry-boundary')
order = store.hold('alice', 'boundary', 1)
store.clock = lambda: 1300
assert store.pay('at-equal', order['id']) == 'REFUND_PENDING'
assert store.expire(order['hold_id']) is True
assert store.expire(order['hold_id']) is False
assert store.rows('seats')[0]['state'] == 'FREE'
observations['expiry_equal'] = 'REFUND_PENDING; cleanup releases exactly once'

store = fresh('duplicate-callback')
order = store.hold('alice', 'one', 1)
barrier = threading.Barrier(24)


def duplicate(_):
    barrier.wait()
    return store.pay('stable-payment', order['id'])


with ThreadPoolExecutor(max_workers=24) as pool:
    results = list(pool.map(duplicate, range(24)))
assert results == ['BOOKED'] * 24
assert len(store.rows('payments')) == len(store.rows('ledger')) == 1
for args in [('stable-payment', 'other-order', 10000, 'CNY'),
             ('stable-payment', order['id'], 1, 'CNY'),
             ('stable-payment', order['id'], 10000, 'USD')]:
    try:
        store.pay(*args)
    except Conflict:
        pass
    else:
        raise AssertionError(args)
assert len(store.rows('payments')) == len(store.rows('ledger')) == 1
observations['duplicate_callbacks'] = {'callbacks': len(results), 'payments': 1, 'ledger': 1, 'identity_conflicts_rejected': 3}

store = fresh('amount-mismatch')
order = store.hold('alice', 'wrong-amount', 1)
assert store.pay('underpayment', order['id'], 1) == 'REFUND_PENDING'
assert store.rows('seats')[0]['state'] == 'HELD'
assert len(store.rows('ledger')) == 0
assert store.pay('right-payment', order['id']) == 'BOOKED'
observations['wrong_amount'] = {'refund_obligations': store.rows('refunds'), 'ledger': store.rows('ledger')}

for point in ['after_seat_update', 'before_commit']:
    store = fresh('rollback-' + point)
    order = store.hold('alice', 'fault', 1)

    def fail(stage):
        if stage == point:
            raise RuntimeError('injected failure at ' + point)

    try:
        store.pay('retry-payment', order['id'], checkpoint=fail)
    except RuntimeError as failure:
        observed = str(failure)
    else:
        raise AssertionError('failure hook not reached')
    assert store.rows('seats')[0]['state'] == 'HELD'
    assert not store.rows('payments') and not store.rows('ledger')
    assert store.pay('retry-payment', order['id']) == 'BOOKED'
    assert len(store.rows('ledger')) == 1
    observations[point] = {'injected': observed, 'retry': 'BOOKED', 'ledger_rows': 1}

print(json.dumps({'scenario': 'payment_identity_expiry_and_rollback', 'observations': observations, 'pass': True}, indent=2))
