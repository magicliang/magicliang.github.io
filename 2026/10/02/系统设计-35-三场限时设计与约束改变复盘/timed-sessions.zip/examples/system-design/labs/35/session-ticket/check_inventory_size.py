from contextlib import closing
import json
import os
from pathlib import Path

from tickets import TicketStore

root = Path(os.environ['TICKET_RUN_DIR'])
store = TicketStore(root / 'fifty-thousand-seats.sqlite', clock=lambda: 1000)
store.initialize(50_000)
assert store.availability() == 50_000
first = store.hold('first', 'one', 1)
last = store.hold('last', 'last', 50_000)
assert store.availability() == 49_998
assert store.pay('first-payment', first['id']) == 'BOOKED'
try:
    store.hold('outside', 'outside', 50_001)
except KeyError:
    pass
else:
    raise AssertionError('nonexistent seat was held')
with closing(store.connect()) as db:
    inventory = db.execute('SELECT count(*),min(id),max(id) FROM seats').fetchone()
    integrity = db.execute('PRAGMA integrity_check').fetchone()[0]
    violations = db.execute('PRAGMA foreign_key_check').fetchall()
assert tuple(inventory) == (50_000, 1, 50_000)
assert integrity == 'ok' and violations == []
assert len(store.rows('orders')) == 2 and len(store.rows('ledger')) == 1
print(json.dumps({'scenario': 'fifty_thousand_inventory_rows', 'inventory_count_min_max': list(inventory),
                  'available_after_two_holds_and_one_sale': store.availability(),
                  'missing_seat_rejected': True, 'integrity': integrity, 'foreign_key_violations': violations,
                  'scope': 'inventory cardinality and boundary IDs, not 500 req/s or 5000 read/s load proof', 'pass': True}, indent=2))
