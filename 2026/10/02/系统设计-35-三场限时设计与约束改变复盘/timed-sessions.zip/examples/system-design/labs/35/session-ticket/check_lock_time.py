from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
import json
import os
from pathlib import Path
import sqlite3
import threading

from tickets import TicketStore

root = Path(os.environ['TICKET_RUN_DIR'])
path = root / 'lock-time.sqlite'
clock = {'now': 1000}
store = TicketStore(path, clock=lambda: clock['now'])
store.initialize(2)
order = store.hold('alice', 'waiting-payment', 1)
other = store.hold('bob', 'other', 2)
begin_attempted = threading.Event()
clock_reads = []


class TracedStore(TicketStore):
    def connect(self):
        db = super().connect()
        db.set_trace_callback(lambda sql: begin_attempted.set() if sql == 'BEGIN IMMEDIATE' else None)
        return db


def observed_clock():
    clock_reads.append(clock['now'])
    return clock['now']


waiting = TracedStore(path, clock=observed_clock)
clock['now'] = 1299
with closing(store.connect()) as blocker:
    blocker.execute('BEGIN IMMEDIATE')
    with ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(waiting.pay, 'waiting', order['id'])
        assert begin_attempted.wait(timeout=3)
        assert clock_reads == []
        clock['now'] = 1300
        blocker.commit()
        result = future.result(timeout=3)
assert result == 'REFUND_PENDING'
assert clock_reads == [1300]
assert store.rows('ledger') == []
with closing(store.connect()) as db:
    db.execute('BEGIN IMMEDIATE')
    db.execute("UPDATE orders SET state='PAID' WHERE id=?", (order['id'],))
    try:
        db.execute("INSERT INTO orders VALUES('second-paid','eve','r',1,'second-hold',1500,'PAID',10000,'CNY')")
    except sqlite3.IntegrityError as error:
        uniqueness_error = str(error)
    else:
        raise AssertionError('schema accepted two paid orders on one seat')
    db.rollback()
assert store.rows('ledger') == []
print(json.dumps({'scenario': 'transaction_time_after_lock_and_paid_seat_constraint',
                  'started_request_at': 1299, 'expires_at': 1300, 'clock_samples': clock_reads,
                  'clock_unread_while_lock_blocked': True, 'result': result,
                  'second_paid_order_rejected': uniqueness_error,
                  'schema_probe_rolled_back': True, 'pass': True}, indent=2))
