# 第三场票务书面设计实验

执行者为 AI。`design.md` 保存演进中的设计；阶段初稿位于 `../../../evidence/35/session-ticket/stages/`，真实起点在 `00-start.json`。阶段标记使用实际 UTC 和 monotonic elapsed，不回填标称分钟数。

从仓库根目录复现全部本地场景，给每次执行使用一个未存在的标签：

```bash
python3 examples/system-design/labs/35/session-ticket/record.py run reproduction-01 python3 run_all.py
```

`record.py` 保存原始参数数组、工作目录、stdout、stderr、退出码与源文件快照。`run_all.py` 为每个检查建立独立目录并保留 SQLite 数据库。重复标签会失败，已有证据不会被覆盖。`check_counterexample.py` 专门运行错误实现；它成功的含义是观察到两个销售记录的反例。

SQLite 模型只覆盖一个场次的单席订单，价格固定为实验值 10000 分、币种 CNY。生产渠道验签、付款、退款、缓存服务、分布式复制、HTTP 认证和真实压测均未接入。`BOOKED` 表示本地账本与销售状态已一起提交，`REFUND_PENDING` 表示本地退款义务已保存，不能解释为真实资金动作完成。

`check_holds.py` 验证争抢、原键重试和到期重领；`check_payments.py` 验证重复与迟到支付；`check_crashes.py` 会创建并杀死自己的子进程，检查本地 SQLite 进程恢复。其余检查覆盖边界操作顺序、锁后取时、读视图、非法身份、写锁超时、五万席数量和题设容量算术。

新增强承诺的实现为 `capture_protocol.py`：`CaptureStore` 通过持久化意图推进授权、PINNED、捕获确认，`FakeChannel` 使用另一份本地 SQLite 数据库模拟幂等授权与捕获。`check_capture_protocol.py` 同时保留先扣后退款不满足承诺的反例；`check_capture_crashes.py` 覆盖授权与捕获之间的进程终止；`check_injected_capacity.py` 直接数出成功路径四次库存提交。外部结果未知会保留库存，真实渠道始终标记 NOT_RUN。

本次交付的验收明细见证据目录 `receipt.json`，包括每个场景的命令、退出码、二元结果和原始输出路径；`manifest.json` 记录证据文件的大小与SHA-256。历史失败不能删除，也不能用当前重跑结果替换冻结阶段。`audit_evidence.py` 校验已完成运行的源快照、原始流大小和数据库完整性。
