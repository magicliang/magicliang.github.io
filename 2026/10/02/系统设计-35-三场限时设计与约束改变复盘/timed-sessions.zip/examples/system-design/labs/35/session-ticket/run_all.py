import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(os.environ['TICKET_RUN_DIR'])
results = []
for script in sorted(Path('.').glob('check_*.py')):
    target = root / script.stem
    target.mkdir()
    argv = [sys.executable, str(script)]
    begin = time.monotonic_ns()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    child = subprocess.run(argv, env=dict(os.environ, TICKET_RUN_DIR=str(target)), capture_output=True)
    (target / 'stdout.txt').write_bytes(child.stdout)
    (target / 'stderr.txt').write_bytes(child.stderr)
    receipt = {'argv': argv, 'cwd': str(Path.cwd()), 'started_utc': started,
               'elapsed_seconds': (time.monotonic_ns() - begin) / 1e9,
               'exit_code': child.returncode, 'script_sha256': hashlib.sha256(script.read_bytes()).hexdigest(),
               'engine_sha256': hashlib.sha256(Path('tickets.py').read_bytes()).hexdigest()}
    (target / 'command-result.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if child.returncode:
        print(child.stdout.decode(), file=sys.stderr)
        print(child.stderr.decode(), file=sys.stderr)
        raise SystemExit(child.returncode)
    data = json.loads(child.stdout)
    binary = data.get('pass', data.get('witness_reproduced', False))
    assert binary is True, data
    results.append({'script': str(script), 'scenario': data['scenario'], 'binary_observable': binary,
                    'stdout': str(target / 'stdout.txt'), 'exit_code': child.returncode})
print(json.dumps({'scenario': 'full_relevant_suite', 'cases': results, 'scenario_count': len(results),
                  'pass': True}, indent=2))
