import json
import os
from pathlib import Path
import signal
import subprocess
import sys

from tickets import TicketStore

root = Path(os.environ['TICKET_RUN_DIR'])
observations = []
for point in ['after_seat_update', 'before_commit', 'after_commit_before_response']:
    path = root / (point + '.sqlite')
    store = TicketStore(path, clock=lambda: 1000)
    store.initialize()
    order = store.hold('alice', 'one', 1)
    argv = [sys.executable, 'crash_worker.py', str(path), order['id'], point]
    process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, text=True)
    line = process.stdout.readline()
    assert json.loads(line)['checkpoint'] == point, line
    os.kill(process.pid, signal.SIGKILL)
    stdout, stderr = process.communicate(timeout=5)
    (root / (point + '-worker-stdout.txt')).write_text(line + stdout)
    (root / (point + '-worker-stderr.txt')).write_text(stderr)
    assert process.returncode == -signal.SIGKILL
    before_retry = {table: store.rows(table) for table in ('seats', 'orders', 'payments', 'ledger')}
    expected = 'SOLD' if point == 'after_commit_before_response' else 'HELD'
    assert before_retry['seats'][0]['state'] == expected, before_retry
    assert len(before_retry['ledger']) == (1 if expected == 'SOLD' else 0)
    result = store.pay('crash-payment', order['id'])
    assert result == 'BOOKED'
    assert len(store.rows('payments')) == len(store.rows('ledger')) == 1
    assert store.rows('seats')[0]['state'] == 'SOLD'
    with store.connect() as db:
        integrity = db.execute('PRAGMA integrity_check').fetchone()[0]
        mode = db.execute('PRAGMA journal_mode').fetchone()[0]
    assert integrity == 'ok'
    observations.append({'checkpoint': point, 'argv': argv, 'worker_exit': process.returncode,
                         'before_retry': before_retry, 'retry': result, 'ledger_after_retry': 1,
                         'integrity': integrity, 'journal_mode': mode})
print(json.dumps({'scenario': 'real_process_kill_and_sqlite_recovery', 'observations': observations,
                  'scope': 'process SIGKILL on local SQLite, not machine power loss or replicated DB recovery',
                  'pass': True}, indent=2))
