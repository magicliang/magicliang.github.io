from contextlib import closing
import sqlite3

from tickets import Conflict, TicketStore


class ExternalUnknown(RuntimeError):
    pass


class CapabilityMissing(ValueError):
    pass


class FakeChannel:
    separate_authorize_capture = True
    durable_idempotency = True
    query_by_key = True
    terminal_void = True

    def __init__(self, path, unknown_after=None, query_unknown=False):
        self.path = path
        self.unknown_after = unknown_after
        self.query_unknown = query_unknown

    def initialize(self):
        with sqlite3.connect(self.path) as db:
            db.execute('CREATE TABLE channel_payments(id TEXT PRIMARY KEY NOT NULL, amount INTEGER, currency TEXT, state TEXT, capture_count INTEGER)')

    def query(self, key):
        if self.query_unknown:
            raise ExternalUnknown('provider query unavailable')
        with closing(sqlite3.connect(self.path)) as db:
            row = db.execute('SELECT state FROM channel_payments WHERE id=?', (key,)).fetchone()
            return row[0] if row else 'NOT_FOUND'

    def authorize(self, key, amount, currency):
        with closing(sqlite3.connect(self.path)) as db:
            with db:
                db.execute('BEGIN IMMEDIATE')
                previous = db.execute('SELECT amount,currency,state FROM channel_payments WHERE id=?', (key,)).fetchone()
                if previous:
                    if tuple(previous[:2]) != (amount, currency):
                        raise Conflict('authorization identity changed')
                    result = previous[2]
                else:
                    db.execute("INSERT INTO channel_payments VALUES(?,?,?,'AUTHORIZED',0)", (key, amount, currency))
                    result = 'AUTHORIZED'
        self.maybe_unknown('authorize')
        return result

    def capture(self, key):
        with closing(sqlite3.connect(self.path)) as db:
            with db:
                db.execute('BEGIN IMMEDIATE')
                row = db.execute('SELECT state FROM channel_payments WHERE id=?', (key,)).fetchone()
                if not row or row[0] not in ('AUTHORIZED', 'CAPTURED'):
                    raise Conflict('capture requires live authorization')
                if row[0] == 'AUTHORIZED':
                    db.execute("UPDATE channel_payments SET state='CAPTURED',capture_count=1 WHERE id=?", (key,))
        self.maybe_unknown('capture')
        return 'CAPTURED'

    def void(self, key):
        with closing(sqlite3.connect(self.path)) as db:
            with db:
                db.execute('BEGIN IMMEDIATE')
                row = db.execute('SELECT state FROM channel_payments WHERE id=?', (key,)).fetchone()
                if row and row[0] == 'CAPTURED':
                    raise Conflict('captured payment cannot be voided')
                if row:
                    db.execute("UPDATE channel_payments SET state='VOIDED' WHERE id=?", (key,))
                else:
                    db.execute("INSERT INTO channel_payments VALUES(?,0,'NONE','VOIDED',0)", (key,))
        self.maybe_unknown('void')
        return 'VOIDED'

    def maybe_unknown(self, operation):
        if self.unknown_after == operation:
            self.unknown_after = None
            raise ExternalUnknown(operation + ' result lost after provider commit')

    def records(self):
        with closing(sqlite3.connect(self.path)) as db:
            db.row_factory = sqlite3.Row
            return [dict(row) for row in db.execute('SELECT * FROM channel_payments')]


class CaptureStore(TicketStore):
    def __init__(self, path, channel, **kwargs):
        for capability in ('separate_authorize_capture', 'durable_idempotency', 'query_by_key', 'terminal_void'):
            if getattr(channel, capability, False) is not True:
                raise CapabilityMissing('Cannot promise captured funds guarantee a seat: missing ' + capability)
        super().__init__(path, **kwargs)
        self.channel = channel

    def initialize(self, count=1):
        super().initialize(count)
        with closing(self.connect()) as db:
            db.execute('CREATE TABLE intents(id TEXT PRIMARY KEY NOT NULL, order_id TEXT NOT NULL UNIQUE REFERENCES orders(id), state TEXT NOT NULL)')

    def pay(self, *args, **kwargs):
        raise CapabilityMissing('Direct charge callbacks do not satisfy the captured-funds seat guarantee')

    def intent(self, key):
        with closing(self.connect()) as db:
            row = db.execute('SELECT * FROM intents WHERE id=?', (key,)).fetchone()
            if not row:
                raise KeyError(key)
            return dict(row)

    def pending_keys(self):
        with closing(self.connect()) as db:
            return [row[0] for row in db.execute("SELECT id FROM intents WHERE state NOT IN ('CAPTURED','VOIDED') ORDER BY id")]

    def start_payment(self, order_id, key):
        self.require_identity(key, 'intent_key')
        with self.transaction() as db:
            row = db.execute('SELECT * FROM intents WHERE id=? OR order_id=?', (key, order_id)).fetchone()
            if row:
                if row['id'] != key or row['order_id'] != order_id:
                    raise Conflict('one stable intent per order')
                return dict(row)
            order = db.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()
            if not order or order['state'] != 'HELD' or order['expires_at'] <= int(self.clock()):
                raise Conflict('authorization requires a live hold')
            db.execute("INSERT INTO intents VALUES(?,?,'AUTH_REQUESTED')", (key, order_id))
            return {'id': key, 'order_id': order_id, 'state': 'AUTH_REQUESTED'}

    def pin_after_authorization(self, key):
        with self.transaction() as db:
            intent = db.execute('SELECT * FROM intents WHERE id=?', (key,)).fetchone()
            if intent['state'] != 'AUTH_REQUESTED':
                return intent['state']
            order = db.execute('SELECT * FROM orders WHERE id=?', (intent['order_id'],)).fetchone()
            pinned = db.execute("UPDATE seats SET state='PINNED' WHERE id=? AND hold_id=? AND state='HELD' AND expires_at>?",
                                (order['seat_id'], order['hold_id'], int(self.clock()))).rowcount
            state = 'CAPTURE_READY' if pinned else 'VOID_REQUIRED'
            db.execute('UPDATE intents SET state=? WHERE id=?', (state, key))
            if pinned:
                db.execute("UPDATE orders SET state='CAPTURE_PENDING' WHERE id=?", (order['id'],))
            return state

    def finish_capture(self, key):
        with self.transaction() as db:
            intent = db.execute('SELECT * FROM intents WHERE id=?', (key,)).fetchone()
            if intent['state'] == 'CAPTURED':
                return 'BOOKED'
            if intent['state'] != 'CAPTURE_READY':
                raise Conflict('capture observed without durable inventory reservation')
            order = db.execute('SELECT * FROM orders WHERE id=?', (intent['order_id'],)).fetchone()
            sold = db.execute("UPDATE seats SET state='SOLD' WHERE id=? AND hold_id=? AND state='PINNED'",
                              (order['seat_id'], order['hold_id'])).rowcount
            if sold != 1:
                raise Conflict('pinned seat missing; stop and reconcile')
            db.execute("INSERT INTO payments VALUES(?,?,?,?,'BOOKED')", (key, order['id'], order['amount_cents'], order['currency']))
            db.execute('INSERT INTO ledger VALUES(?,?,?)', (key, order['id'], order['amount_cents']))
            db.execute("UPDATE orders SET state='PAID' WHERE id=?", (order['id'],))
            db.execute("UPDATE intents SET state='CAPTURED' WHERE id=?", (key,))
            return 'BOOKED'

    def recover(self, key, checkpoint=None):
        intent = self.intent(key)
        if intent['state'] in ('CAPTURED', 'VOIDED'):
            return 'BOOKED' if intent['state'] == 'CAPTURED' else 'VOIDED'
        try:
            external = self.channel.query(key)
            intent = self.intent(key)
            if intent['state'] == 'AUTH_REQUESTED':
                order = self.order(intent['order_id'])
                if external == 'NOT_FOUND':
                    external = self.channel.authorize(key, order['amount_cents'], order['currency'])
                if checkpoint:
                    checkpoint('after_authorize')
                if external == 'CAPTURED':
                    current = self.intent(key)
                    if current['state'] in ('CAPTURE_READY', 'CAPTURED'):
                        return self.finish_capture(key)
                    raise Conflict('provider charged before inventory pin; strong promise violated')
                if external == 'AUTHORIZED':
                    self.pin_after_authorization(key)
                elif external == 'VOIDED':
                    with self.transaction() as db:
                        db.execute("UPDATE intents SET state='VOIDED' WHERE id=? AND state='AUTH_REQUESTED'", (key,))
                    return 'VOIDED'
            intent = self.intent(key)
            if intent['state'] == 'VOID_REQUIRED':
                self.channel.void(key)
                with self.transaction() as db:
                    db.execute("UPDATE intents SET state='VOIDED' WHERE id=? AND state='VOID_REQUIRED'", (key,))
                return 'VOIDED'
            if intent['state'] == 'CAPTURE_READY':
                if checkpoint:
                    checkpoint('after_pin_before_capture')
                if external == 'AUTHORIZED':
                    external = self.channel.capture(key)
                if external == 'CAPTURED':
                    if checkpoint:
                        checkpoint('after_capture_before_local_commit')
                    return self.finish_capture(key)
                return 'EXTERNAL_UNKNOWN_KEEP_PINNED'
            if intent['state'] == 'CAPTURED':
                return 'BOOKED'
            return intent['state']
        except ExternalUnknown:
            return 'EXTERNAL_UNKNOWN_RETRY_SAME_KEY'
