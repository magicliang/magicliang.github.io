#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ "$#" -eq 0 ]; then
  set -- 00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18
fi
total=$#
for chapter in "$@"; do
  case "$chapter" in
    [0-4][0-9]) ;;
    *) printf 'Invalid chapter: %s\n' "$chapter" >&2; exit 2 ;;
  esac
  destination="evidence/${chapter}/local-20261002"
  mkdir -p "$destination"
  if ./mvnw -B -q compile exec:java -Dexec.mainClass="blog.spring.Chapter${chapter}" > "$destination/run.txt" 2>&1; then
    printf '0\n' > "$destination/exit-code.txt"
  else
    result=$?
    printf '%s\n' "$result" > "$destination/exit-code.txt"
    cat "$destination/run.txt"
    exit "$result"
  fi
  cat "$destination/run.txt"
done
printf 'ALL %s CHAPTERS PASS\n' "$total"
