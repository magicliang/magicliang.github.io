package blog.spring.mvc;

import java.io.*;
import java.net.*;
import java.net.http.*;
import java.net.http.HttpRequest;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.aopalliance.intercept.MethodInterceptor;
import org.apache.catalina.startup.Tomcat;
import org.apache.tomcat.util.descriptor.web.*;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.context.annotation.*;
import org.springframework.core.MethodParameter;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.http.*;
import org.springframework.http.converter.*;
import org.springframework.http.server.*;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.async.*;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.method.annotation.HandlerMethodValidationException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.*;
import org.springframework.web.servlet.config.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.*;

public class MvcLab {
    static final List<String> TRACE = new CopyOnWriteArrayList<>();
    static final ExecutorService PRODUCER = Executors.newFixedThreadPool(2);
    static final AtomicInteger ACTIVE = new AtomicInteger();
    static volatile CountDownLatch release = new CountDownLatch(1);
    static volatile CountDownLatch streamClosed = new CountDownLatch(1);
    static final AtomicBoolean disconnectDetected = new AtomicBoolean();
    static final AtomicBoolean lateAccepted = new AtomicBoolean(true);
    static int checks;
    static String base;
    static final HttpClient CLIENT = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3)).build();
    static void trace(String value) { String line = value + " thread=" + Thread.currentThread().getName(); TRACE.add(line); System.out.println("TRACE " + line); }
    static void check(boolean pass, String name) { if (!pass) throw new AssertionError(name); checks++; System.out.println("CHECK PASS " + name); }
    static boolean seen(String value) { return TRACE.stream().anyMatch(s -> s.startsWith(value)); }
    static HttpResponse<String> call(String method, String path, String body, String type, String accept) throws Exception {
        var builder = HttpRequest.newBuilder(URI.create(base + path)).timeout(Duration.ofSeconds(12));
        if (type != null) builder.header("Content-Type", type);
        if (accept != null) builder.header("Accept", accept);
        var response = CLIENT.send(builder.method(method, body == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofString(body)).build(), HttpResponse.BodyHandlers.ofString());
        System.out.println("HTTP " + method + " " + path + " status=" + response.statusCode() + " content-type=" + response.headers().firstValue("Content-Type").orElse("none") + " body=" + response.body());
        return response;
    }
    static HttpResponse<String> get(String path) throws Exception { return call("GET", path, null, null, null); }
    public interface Greeting { String say(); }
    @Configuration @EnableWebMvc
    public static class Config implements WebMvcConfigurer {
        @Bean public Api api(Greeting greeting) { return new Api(greeting); }
        @Bean public Errors errors() { return new Errors(); }
        @Bean public Greeting greeting() {
            var factory = new ProxyFactory((Greeting) () -> "hello");
            factory.addAdvice((MethodInterceptor) invocation -> { trace("aop-enter"); try { return invocation.proceed(); } finally { trace("aop-exit"); } });
            return (Greeting) factory.getProxy();
        }
        @Bean public ThreadPoolTaskExecutor mvcExecutor() { var e = new ThreadPoolTaskExecutor(); e.setCorePoolSize(2); e.setMaxPoolSize(2); e.setQueueCapacity(8); e.setThreadNamePrefix("mvc-task-"); e.setWaitForTasksToCompleteOnShutdown(false); return e; }
        @Override public void configureAsyncSupport(AsyncSupportConfigurer config) { config.setTaskExecutor(mvcExecutor()).setDefaultTimeout(2000); }
        @Override public void addInterceptors(InterceptorRegistry registry) {
            registry.addInterceptor(new AsyncHandlerInterceptor() {
                @Override public boolean preHandle(HttpServletRequest r, HttpServletResponse s, Object h) { trace("pre " + r.getDispatcherType() + " " + r.getRequestURI() + " context=" + (org.springframework.web.context.request.RequestContextHolder.getRequestAttributes() != null)); return true; }
                @Override public void postHandle(HttpServletRequest r, HttpServletResponse s, Object h, ModelAndView m) { trace("post " + r.getDispatcherType()); }
                @Override public void afterCompletion(HttpServletRequest r, HttpServletResponse s, Object h, Exception ex) { trace("complete " + r.getDispatcherType()); }
                @Override public void afterConcurrentHandlingStarted(HttpServletRequest r, HttpServletResponse s, Object h) { trace("concurrent " + r.getDispatcherType()); }
            });
        }
        @Override public void configureViewResolvers(ViewResolverRegistry registry) {
            registry.viewResolver((name, locale) -> "receipt".equals(name) ? new View() {
                public String getContentType() { return "text/html"; }
                public void render(Map<String, ?> model, HttpServletRequest r, HttpServletResponse s) throws Exception { s.setContentType("text/html;charset=UTF-8"); s.getWriter().write("<p>receipt</p>"); }
            } : null);
        }
    }
    public static class Order {
        @NotBlank private String name;
        @Min(1) private int quantity;
        private boolean admin;
        public String getName() { return name; } public void setName(String value) { name = value; }
        public int getQuantity() { return quantity; } public void setQuantity(int value) { quantity = value; }
        public boolean isAdmin() { return admin; } public void setAdmin(boolean value) { admin = value; }
    }
    public static class Broken { public String getValue() { throw new IllegalStateException("serializer failed"); } }
    @Controller
    public static class Api {
        private final Greeting greeting;
        Api(Greeting greeting) { this.greeting = greeting; }
        @InitBinder("order") public void bind(WebDataBinder binder) { binder.setAllowedFields("name", "quantity"); }
        @GetMapping("/hello") @ResponseBody public String hello() { trace("handler"); return greeting.say(); }
        @RequestMapping("/container-error") @ResponseBody public ResponseEntity<Map<String,Object>> error(HttpServletRequest request) { return ResponseEntity.status(500).body(Map.of("dispatch", request.getDispatcherType().name())); }
        @GetMapping("/async") @ResponseBody public Callable<String> async() { trace("handler-async"); return () -> { trace("callable"); return "async-ok"; }; }
        @GetMapping("/path/{id}") @ResponseBody public String path(@PathVariable String id) { return id; }
        @PostMapping(path="/json", consumes="application/json") @ResponseBody public Order json(@RequestBody Order order) { return order; }
        @GetMapping("/number") @ResponseBody public Map<String,Object> number(@RequestParam int n) { return Map.of("n", n); }
        @GetMapping("/optional") @ResponseBody public Map<String,Object> optional(@RequestParam(required=false) String n) { return Map.of("value", n == null ? "<missing>" : n); }
        @GetMapping("/repeated") @ResponseBody public List<String> repeated(@RequestParam List<String> tag) { return tag; }
        @PostMapping("/form") @ResponseBody public Map<String,Object> form(@ModelAttribute("order") Order order, BindingResult result) { return Map.of("name", order.getName() == null ? "<missing>" : order.getName(), "quantity", order.getQuantity(), "admin", order.isAdmin(), "suppressed", result.getSuppressedFields(), "errors", result.getFieldErrorCount()); }
        @PostMapping("/valid") @ResponseBody public Order valid(@Valid @RequestBody Order order) { return order; }
        @GetMapping("/minimum") @ResponseBody public int minimum(@RequestParam @Min(1) int n) { return n; }
        @GetMapping("/business") @ResponseBody public String business() { throw new Conflict(); }
        @GetMapping("/entity") public ResponseEntity<Map<String,String>> entity() { return ResponseEntity.status(201).header("X-Order", "7").body(Map.of("id", "7")); }
        @GetMapping("/object") @ResponseBody public Map<String,String> object() { return Map.of("id", "7"); }
        @GetMapping("/nothing") @ResponseBody public Object nothing() { return null; }
        @GetMapping("/view") public String view() { return "receipt"; }
        @GetMapping("/broken") @ResponseBody public Broken broken() { return new Broken(); }
        @GetMapping("/stream") public ResponseEntity<StreamingResponseBody> stream() { return ResponseEntity.ok().contentType(MediaType.TEXT_PLAIN).body(out -> { out.write("first\n".getBytes(StandardCharsets.UTF_8)); out.flush(); throw new IOException("failure after flush"); }); }
        @GetMapping("/async-fail") @ResponseBody public Callable<String> asyncFail() { return () -> { throw new Conflict(); }; }
        @GetMapping("/deferred") @ResponseBody public DeferredResult<String> deferred() { var result = new DeferredResult<String>(2000L); PRODUCER.submit(() -> result.setResult("deferred-ok")); return result; }
        @GetMapping("/timeout") @ResponseBody public DeferredResult<String> timeout(@RequestParam(defaultValue="false") boolean cancel) {
            var result = new DeferredResult<String>(100L);
            var task = PRODUCER.submit(() -> { ACTIVE.incrementAndGet(); trace("producer-start"); try { release.await(); lateAccepted.set(result.setResult("late")); } catch (InterruptedException e) { trace("producer-interrupted"); Thread.currentThread().interrupt(); } finally { ACTIVE.decrementAndGet(); trace("producer-cleanup"); } });
            result.onTimeout(() -> { trace("timeout active=" + ACTIVE.get()); if (cancel) task.cancel(true); });
            result.onCompletion(() -> trace("deferred-complete active=" + ACTIVE.get()));
            return result;
        }
        @GetMapping("/disconnect") public ResponseEntity<StreamingResponseBody> disconnect() {
            return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM).body(out -> {
                ACTIVE.incrementAndGet(); byte[] bytes = new byte[65536];
                try { for (int i = 0; i < 1024; i++) { out.write(bytes); out.flush(); } }
                catch (IOException e) { disconnectDetected.set(true); trace("disconnect-io " + e.getClass().getSimpleName()); throw e; }
                finally { ACTIVE.decrementAndGet(); streamClosed.countDown(); trace("disconnect-cleanup"); }
            });
        }
    }
    public static class Conflict extends RuntimeException {}
    @ControllerAdvice
    public static class Errors implements ResponseBodyAdvice<Object> {
        @ExceptionHandler({MethodArgumentTypeMismatchException.class, MissingServletRequestParameterException.class, HttpMessageNotReadableException.class, MethodArgumentNotValidException.class, HandlerMethodValidationException.class})
        public ResponseEntity<Map<String,String>> bad(Exception ex) { return ResponseEntity.badRequest().body(Map.of("code", ex.getClass().getSimpleName())); }
        @ExceptionHandler(Conflict.class) public ResponseEntity<Map<String,String>> conflict() { return ResponseEntity.status(409).body(Map.of("code", "ORDER_CONFLICT")); }
        @ExceptionHandler(HttpMessageNotWritableException.class) public ResponseEntity<Map<String,String>> write() { return ResponseEntity.status(500).body(Map.of("code", "WRITE_ERROR")); }
        public boolean supports(MethodParameter p, Class<? extends HttpMessageConverter<?>> converter) { return true; }
        public Object beforeBodyWrite(Object body, MethodParameter p, MediaType type, Class<? extends HttpMessageConverter<?>> converter, ServerHttpRequest request, ServerHttpResponse response) { response.getHeaders().set("X-Mvc-Advice", "visited"); return body; }
    }
    @Controller public static class Duplicate {
        @GetMapping("/same") public void first() {}
        @GetMapping("/same") public void second() {}
    }
    static void chapter25() throws Exception {
        TRACE.clear(); check(get("/hello").body().equals("hello"), "25 normal response");
        check(seen("filter REQUEST /hello") && seen("pre REQUEST /hello context=true") && seen("aop-enter") && seen("aop-exit") && seen("complete REQUEST"), "25 REQUEST crosses filter interceptor and proxy");
        TRACE.clear(); check(get("/async").body().equals("async-ok"), "25 asynchronous response");
        check(seen("filter ASYNC /async") && seen("concurrent REQUEST") && seen("pre ASYNC"), "25 ASYNC redispatch traverses filter and interceptor");
        check(TRACE.stream().filter(s -> s.startsWith("handler-async ")).count() == 1, "25 controller invoked once despite two dispatches");
        TRACE.clear(); check(get("/filter-error").statusCode() == 500, "25 filter sendError reaches configured error page");
        check(seen("filter ERROR /container-error") && seen("pre ERROR"), "25 ERROR is a container dispatch");
        check(!seen("aop-enter"), "25 filter failure does not enter service proxy");
    }
    static void chapter26() throws Exception {
        check(get("/path/abc").body().equals("abc"), "26 path variable matches");
        check(get("/absent").statusCode() == 404, "26 absent path 404");
        var method = call("POST", "/hello", "", null, null); check(method.statusCode() == 405 && method.headers().firstValue("Allow").orElse("").contains("GET"), "26 method 405 retains Allow");
        check(call("POST", "/json", "name=a", "text/plain", null).statusCode() == 415, "26 unsupported consumes 415");
        check(get("/hello/").statusCode() == 404, "26 trailing slash is distinct by default");
        check(get("/path/a%20b").body().equals("a b"), "26 encoded space decoded within segment");
        check(get("/path/a%2Fb").statusCode() == 400, "26 Tomcat rejects encoded slash before MVC");
        var mapping = new RequestMappingHandlerMapping();
        var info = org.springframework.web.servlet.mvc.method.RequestMappingInfo.paths("/same").methods(RequestMethod.GET).build();
        var target = new Duplicate(); mapping.registerMapping(info, target, Duplicate.class.getMethod("first"));
        boolean rejected = false; try { mapping.registerMapping(info, target, Duplicate.class.getMethod("second")); } catch (IllegalStateException ex) { rejected = ex.getMessage().contains("Ambiguous mapping"); System.out.println("MAPPING " + ex.getMessage()); }
        check(rejected, "26 duplicate mapping registration fails");
    }
    static void chapter27() throws Exception {
        check(get("/number?n=4").body().contains("4"), "27 query converts to int");
        check(get("/number").statusCode() == 400, "27 missing required parameter");
        check(get("/number?n=").statusCode() == 400, "27 empty primitive parameter");
        check(get("/optional").body().contains("<missing>"), "27 missing optional string is null");
        check(get("/optional?n=").body().equals("{\"value\":\"\"}"), "27 empty string differs from absent");
        check(get("/repeated?tag=a&tag=b").body().equals("[\"a\",\"b\"]"), "27 repeated parameter binds list in order");
        var form = call("POST", "/form", "name=desk&quantity=2&admin=true&extra=x", "application/x-www-form-urlencoded", null);
        check(form.body().contains("\"admin\":false") && form.body().contains("admin") && form.body().contains("extra") && form.body().contains("\"quantity\":2"), "27 form allowlist suppresses admin and unknown field");
        check(call("POST", "/form", "quantity=oops", "application/x-www-form-urlencoded", null).body().contains("\"errors\":1"), "27 adjacent BindingResult exposes conversion error");
        var json = call("POST", "/json", "{\"name\":\"desk\",\"quantity\":2,\"admin\":true,\"extra\":9}", "application/json", null);
        check(json.statusCode() == 200 && json.body().contains("\"admin\":true"), "27 JSON converter ignores unknown field but bypasses form property allowlist");
    }
    static void chapter28() throws Exception {
        check(call("POST", "/valid", "{bad", "application/json", null).body().contains("HttpMessageNotReadableException"), "28 malformed JSON rejected before validation");
        check(get("/number?n=bad").body().contains("MethodArgumentTypeMismatchException"), "28 query conversion error");
        var invalid = call("POST", "/valid", "{\"name\":\"\",\"quantity\":0}", "application/json", null);
        check(invalid.statusCode() == 400 && invalid.body().contains("MethodArgumentNotValidException"), "28 argument Bean Validation");
        var method = get("/minimum?n=0"); check(method.statusCode() == 400 && method.body().contains("HandlerMethodValidationException"), "28 MVC method validation without class Validated proxy");
        check(call("POST", "/valid", "{\"name\":\"desk\",\"quantity\":1}", "application/json", null).statusCode() == 200, "28 valid body reaches controller");
        var conflict = get("/business"); check(conflict.statusCode() == 409 && conflict.body().contains("ORDER_CONFLICT"), "28 business error retains 409");
        check(!get("/filter-error").body().contains("ORDER_CONFLICT"), "28 advice does not catch upstream filter execution");
    }
    static void chapter29() throws Exception {
        var entity = get("/entity"); check(entity.statusCode() == 201 && entity.headers().firstValue("X-Order").orElse("").equals("7"), "29 entity controls status and headers");
        var object = get("/object"); check(object.body().equals("{\"id\":\"7\"}") && object.headers().firstValue("Content-Type").orElse("").contains("application/json"), "29 object converted to JSON");
        check(object.headers().firstValue("X-Mvc-Advice").orElse("").equals("visited"), "29 body advice visits selected conversion");
        var nothing = get("/nothing"); check(nothing.statusCode() == 200 && nothing.body().isEmpty(), "29 null body does not imply 204");
        check(get("/view").body().equals("<p>receipt</p>"), "29 unannotated String resolves view");
        check(call("GET", "/object", null, null, "application/xml").statusCode() == 406, "29 unacceptable representation 406");
        var broken = get("/broken"); check(broken.statusCode() == 500 && broken.body().contains("WRITE_ERROR"), "29 uncommitted serialization error can become 500");
        String raw = raw("/stream", false); check(raw.startsWith("HTTP/1.1 200") && raw.contains("first"), "29 after flush client retains 200 and partial body");
    }
    static String raw(String path, boolean reset) throws Exception {
        var uri = URI.create(base); try (var socket = new Socket(uri.getHost(), uri.getPort())) {
            socket.setSoTimeout(5000); socket.getOutputStream().write(("GET " + path + " HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
            if (reset) { int value = socket.getInputStream().read(); check(value >= 0, "30 client receives bytes before forced RST"); socket.setSoLinger(true, 0); return "reset"; }
            String response = new String(socket.getInputStream().readAllBytes(), StandardCharsets.UTF_8); System.out.println("RAW " + response.replace("\r", "")); return response;
        }
    }
    static void awaitIdle() throws Exception { long until = System.nanoTime() + TimeUnit.SECONDS.toNanos(5); while (ACTIVE.get() != 0 && System.nanoTime() < until) Thread.sleep(10); check(ACTIVE.get() == 0, "30 producer resource count returned to zero"); }
    static void chapter30() throws Exception {
        check(get("/async").body().equals("async-ok"), "30 Callable success");
        check(get("/deferred").body().equals("deferred-ok"), "30 DeferredResult success");
        check(get("/async-fail").statusCode() == 409, "30 Callable exception resolves after redispatch");
        release = new CountDownLatch(1); check(get("/timeout").statusCode() == 503, "30 timeout produces 503");
        check(ACTIVE.get() == 1, "30 response timeout alone leaves external producer running");
        release.countDown(); awaitIdle(); check(!lateAccepted.get(), "30 late result rejected after timeout");
        release = new CountDownLatch(1); check(get("/timeout?cancel=true").statusCode() == 503, "30 timeout with explicit cancellation");
        awaitIdle(); check(seen("producer-interrupted"), "30 cancellation interrupts cooperative producer");
        raw("/disconnect", true); check(streamClosed.await(5, TimeUnit.SECONDS) && disconnectDetected.get(), "30 write detects RST and finally releases stream resource"); awaitIdle();
    }
    public static void main(String[] args) throws Exception {
        int chapter = Integer.parseInt(args[0]);
        Path baseDir = Files.createTempDirectory("spring-mvc-lab-");
        var tomcat = new Tomcat(); tomcat.setBaseDir(baseDir.toString()); tomcat.setPort(0); tomcat.getConnector().setProperty("address", "127.0.0.1");
        var context = tomcat.addContext("", baseDir.toString()); context.setParentClassLoader(MvcLab.class.getClassLoader());
        var spring = new AnnotationConfigWebApplicationContext(); spring.register(Config.class);
        var wrapper = Tomcat.addServlet(context, "mvc", new DispatcherServlet(spring)); wrapper.setLoadOnStartup(1); wrapper.setAsyncSupported(true); context.addServletMappingDecoded("/", "mvc");
        var filter = new FilterDef(); filter.setFilterName("trace"); filter.setAsyncSupported("true"); filter.setFilter(new Filter() {
            public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
                var r = (HttpServletRequest) request; trace("filter " + r.getDispatcherType() + " " + r.getRequestURI());
                if (r.getRequestURI().equals("/filter-error")) { ((HttpServletResponse) response).sendError(500, "filter failure"); return; }
                try { chain.doFilter(request, response); } finally { trace("filter-exit " + r.getDispatcherType()); }
            }
        }); context.addFilterDef(filter);
        var filterMap = new FilterMap(); filterMap.setFilterName("trace"); filterMap.addURLPattern("/*"); for (var type : DispatcherType.values()) filterMap.setDispatcher(type.name()); context.addFilterMap(filterMap);
        var error = new ErrorPage(); error.setErrorCode(500); error.setLocation("/container-error"); context.addErrorPage(error);
        try {
            tomcat.start(); base = "http://127.0.0.1:" + tomcat.getConnector().getLocalPort();
            System.out.println("ENV java=" + System.getProperty("java.version") + " spring=" + org.springframework.core.SpringVersion.getVersion() + " tomcat=" + org.apache.catalina.util.ServerInfo.getServerNumber() + " base=" + base);
            switch (chapter) { case 25 -> chapter25(); case 26 -> chapter26(); case 27 -> chapter27(); case 28 -> chapter28(); case 29 -> chapter29(); case 30 -> chapter30(); default -> throw new IllegalArgumentException("25..30 only"); }
        } finally {
            release.countDown(); PRODUCER.shutdownNow(); check(PRODUCER.awaitTermination(5, TimeUnit.SECONDS), "producer executor terminated");
            var mvcExecutor = spring.getBean(ThreadPoolTaskExecutor.class).getThreadPoolExecutor();
            int port = tomcat.getConnector().getLocalPort();
            tomcat.stop(); tomcat.destroy(); CLIENT.close();
            check(!spring.isActive(), "web application context closed");
            check(mvcExecutor.awaitTermination(5, TimeUnit.SECONDS), "MVC task executor terminated");
            boolean refused = false;
            try (var probe = new Socket()) { probe.connect(new InetSocketAddress("127.0.0.1", port), 1000); }
            catch (ConnectException expected) { refused = true; }
            check(refused, "Tomcat listening port closed");
            try (var paths = Files.walk(baseDir)) { for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(path); }
        }
        System.out.println("CHAPTER " + chapter + " PASS checks=" + checks);
    }
}
