# Servlet MVC 真 HTTP 实验（25–30）

独立 Maven 模块：JDK 21、Spring Framework 6.2.11、Tomcat 10.1.46、Jackson 2.18.4、Hibernate Validator 8.0.2.Final。版本用于复现机制，不表示生产升级推荐。

在 `examples/spring-framework-lab` 下，把 `JAVA_HOME` 指向 JDK 21：

```bash
./mvnw -f mvc-lab/pom.xml -q compile exec:java -Dexec.mainClass=blog.spring.mvc.MvcLab -Dexec.args=25
python3 mvc-lab/verify.py
```

单章参数为 25–30。每次启动独立 Tomcat，只监听 `127.0.0.1` 的随机端口；JDK HttpClient 发真实 HTTP 请求，第 29、30 篇另用 Socket 观察部分响应及主动 RST。完成后停止容器、关闭 Spring 上下文与执行器、删除本次临时容器目录。无需数据库。

`verify.py` 为每章写入 `../evidence/NN/local-20261002/` 的实际标准输出、退出码、命令与源码哈希。负例中的 400/404/405/406/409/415/500/503、Servlet 异常栈是预期观察，最终 `CHAPTER NN PASS` 与退出码 0 才表示通过。

| 章 | 实验 |
|---|---|
| 25 | REQUEST、ASYNC、ERROR；Filter / Interceptor / AOP；控制器只调用一次 |
| 26 | 路由状态码、Allow、尾斜杠、编码空格与编码斜杠、重复注册拒绝 |
| 27 | 缺值/空值/重复参数、表单白名单、BindingResult、JSON未知字段与过度绑定 |
| 28 | 转换错误、Bean Validation、MVC方法校验、业务异常、Filter边界 |
| 29 | ResponseEntity、JSON、null、视图、406、序列化失败、flush后部分响应 |
| 30 | Callable、DeferredResult、异常、超时不终止生产者、显式取消、断连资源清理 |

第 27 篇故意让 JSON 接受 `admin` 字段，以证明 `WebDataBinder` 的表单属性白名单不能代替安全的 JSON DTO。该接口仅为反例。第 30 篇 RST 是主动故障注入；真实链路的断连检测时延还取决于代理和缓冲，不能由此推算线上取消延迟。
