import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

module = Path(__file__).resolve().parent
lab = module.parent
chapters = [int(value) for value in sys.argv[1:]] or list(range(25, 31))
if any(chapter not in range(25, 31) for chapter in chapters):
    raise SystemExit("chapter must be 25..30")
for chapter in chapters:
    destination = lab / "evidence" / str(chapter) / "local-20261002"
    destination.mkdir(parents=True, exist_ok=True)
    command = [str(lab / "mvnw"), "-f", str(module / "pom.xml"), "-q", "compile", "exec:java",
               "-Dexec.mainClass=blog.spring.mvc.MvcLab", f"-Dexec.args={chapter}"]
    result = subprocess.run(command, cwd=lab, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
    (destination / "run.txt").write_text(result.stdout)
    (destination / "exit-code.txt").write_text(str(result.returncode) + "\n")
    sources = [module / "pom.xml", module / "src/main/java/blog/spring/mvc/MvcLab.java"]
    manifest = {"command": command, "JAVA_HOME": os.environ.get("JAVA_HOME"), "exit_code": result.returncode,
                "checks": result.stdout.count("CHECK PASS "), "source_sha256": {str(path.relative_to(lab)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sources},
                "run_sha256": hashlib.sha256(result.stdout.encode()).hexdigest()}
    (destination / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    print(f"chapter={chapter} exit={result.returncode} checks={manifest['checks']} log={destination / 'run.txt'}", flush=True)
    if result.returncode:
        print(result.stdout[-6000:])
        raise SystemExit(result.returncode)
