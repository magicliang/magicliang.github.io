# Spring 41–43：测试、AOT 与订单综合验收

JDK 21；Boot 3.5.6 BOM 管理 Framework 6.2.11。独立模块，不修改根 Framework pom。

在上级实验工程目录执行：

```bash
export JAVA_HOME=/path/to/jdk-21
export SPRING_LAB_JDBC_URL=jdbc:postgresql://127.0.0.1:55432/spring_lab
export SPRING_LAB_DB_USER=spring_lab
export SPRING_LAB_DB_PASSWORD=''
python3 final-lab/verify.py 41 42 43
```

41/43 需要真实 PostgreSQL，可使用工程 db/README.md 的本地安装方法。账号需允许创建 `spring_final` schema。41 使用固定测试键，不要并发运行本模块的 41；43 使用 UUID 前缀。只清理自己写入的订单，不关闭数据库服务。

| 章 | 实际场景 | 基线具名检查数 |
|---|---|---|
| 41 | 纯 JUnit、MockMvc、TestContext 事务/缓存、真 HTTP/PG | 15（8 个 JUnit 方法） |
| 42 | 普通 blue/red、构建 AOT、AOT JVM blue/runtime-red、生成 hints | 18 |
| 43 | 正常、并发幂等、回滚、异步失败、HTTP 超时、关闭 | 21（1 个 JUnit 方法） |

`evidence/NN/local-20261002/` 保存 stdout/stderr、退出码、命令、源文件与输出哈希、Surefire XML。42 额外保存生成 Java/class/JSON 与 jar SHA；可执行 jar 由脚本重建在 target，不提交依赖体积。

42 不连接数据库。pom 的 AOT profile 为 blue，运行参数 red 不重新选择 Bean；基线观察到有效 profile blue,red，而 Marker 仍为 blue。JVM 的反射成功不能证明 native hints 足够。当前 `native-image` 在 PATH 和指定 JDK 不存在，原生构建/运行明确 NOT_RUN。

43 的异步任务是 CompletableFuture，不是 @Async void；失败指标只是观测，不代表可靠通知。HTTP 是真实响应超时，不是 DNS/TCP 建连超时。订单只包含键和金额，不代表完整生产业务。所有服务器、连接池、执行器由实验自己创建并关闭。
