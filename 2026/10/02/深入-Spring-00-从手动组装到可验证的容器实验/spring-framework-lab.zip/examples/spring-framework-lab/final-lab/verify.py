import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

module = Path(__file__).resolve().parent
lab = module.parent
chapters = sys.argv[1:] or ["41", "42", "43"]
base = [str(lab / "mvnw"), "-f", str(module / "pom.xml"), "-q"]
java = str(Path(os.environ["JAVA_HOME"]) / "bin/java")
for chapter in chapters:
    if chapter not in ("41", "42", "43"):
        raise SystemExit("chapter must be 41, 42, or 43")
    destination = lab / "evidence" / chapter / "local-20261002"
    destination.mkdir(parents=True, exist_ok=True)
    commands = []
    combined = []
    def run(label, command):
        result = subprocess.run(command, cwd=module, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=240)
        (destination / (label + ".txt")).write_text(result.stdout)
        commands.append({"label": label, "command": command, "exit_code": result.returncode})
        combined.append(result.stdout)
        if result.returncode:
            (destination / "run.txt").write_text("\n".join(combined))
            (destination / "exit-code.txt").write_text(str(result.returncode) + "\n")
            print(result.stdout[-6000:])
            raise SystemExit(result.returncode)
    if chapter != "42":
        selected = "Chapter41PureTest,Chapter41Test" if chapter == "41" else "Chapter43Test"
        run("junit", base + ["-Dtest=" + selected, "test"])
        for report in (module / "target/surefire-reports").glob("TEST-*Chapter" + chapter + "*Test.xml"):
            shutil.copy2(report, destination / report.name)
    else:
        run("package", base + ["-DskipTests", "package"])
        jar = str(module / "target/final-lab-1.0-SNAPSHOT.jar")
        run("plain-blue", [java, "-jar", jar, "--spring.profiles.active=blue", "--lab.expected=blue"])
        run("plain-red", [java, "-jar", jar, "--spring.profiles.active=red", "--lab.expected=red"])
        run("process-aot", base + ["-DskipTests", "spring-boot:process-aot", "package"])
        run("aot-blue", [java, "-Dspring.aot.enabled=true", "-jar", jar, "--spring.profiles.active=blue", "--lab.expected=blue"])
        run("aot-runtime-red", [java, "-Dspring.aot.enabled=true", "-jar", jar, "--spring.profiles.active=red", "--lab.expected=blue"])
        generated = module / "target/spring-aot/main"
        generated_files = [p for p in generated.rglob("*") if p.is_file()]
        if not any(p.suffix == ".java" for p in generated_files):
            raise AssertionError("AOT Java missing")
        hint_files = [p for p in generated_files if p.suffix == ".json"]
        hint_text = "\n".join(p.read_text() for p in hint_files)
        if "lab-aot-message.txt" not in hint_text or "AotApp$Payload" not in hint_text:
            raise AssertionError("RuntimeHints output missing")
        shutil.copytree(generated, destination / "generated", dirs_exist_ok=True)
        combined.append("CHECK PASS AOT generated Java present\nCHECK PASS RuntimeHints resource and reflection metadata present\n")
        native = shutil.which("native-image")
        native_status = "NOT_RUN: native-image absent from PATH and selected JAVA_HOME" if not native and not (Path(os.environ["JAVA_HOME"]) / "bin/native-image").exists() else "NOT_RUN: native tool detected; native execution not part of JVM verification"
        (destination / "native-image.txt").write_text(native_status + "\n")
        jar_path = module / "target/final-lab-1.0-SNAPSHOT.jar"
        (destination / "aot-application-sha256.txt").write_text(hashlib.sha256(jar_path.read_bytes()).hexdigest() + "  final-lab-1.0-SNAPSHOT.jar\n")
    output = "\n".join(combined)
    (destination / "run.txt").write_text(output)
    (destination / "exit-code.txt").write_text("0\n")
    sources = [module / "pom.xml", *module.joinpath("src").rglob("*")]
    manifest = {"commands": commands, "JAVA_HOME": os.environ["JAVA_HOME"], "checks": output.count("CHECK PASS"), "exit_code": 0,
                "source_sha256": {str(p.relative_to(lab)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources if p.is_file()},
                "run_sha256": hashlib.sha256(output.encode()).hexdigest()}
    (destination / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print("chapter=" + chapter + " checks=" + str(manifest["checks"]) + " exit=0", flush=True)
