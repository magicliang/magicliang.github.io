package blog.spring.finalapp;

import java.net.*;
import java.net.http.*;
import java.time.Duration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.context.WebServerApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

final class LabSupport {
    static final String URL = System.getenv().getOrDefault("SPRING_LAB_JDBC_URL", "jdbc:postgresql://127.0.0.1:55432/spring_lab");
    static final String USER = System.getenv().getOrDefault("SPRING_LAB_DB_USER", "spring_lab");
    static final String PASSWORD = System.getenv().getOrDefault("SPRING_LAB_DB_PASSWORD", "");
    static ConfigurableApplicationContext start() {
        return new SpringApplicationBuilder(OrderApp.class).properties("server.port=0", "spring.datasource.url="+URL,
                "spring.datasource.username="+USER, "spring.datasource.password="+PASSWORD,
                "spring.datasource.hikari.maximum-pool-size=4", "logging.level.root=WARN").run();
    }
    static int port(ConfigurableApplicationContext context) { return ((WebServerApplicationContext)context).getWebServer().getPort(); }
    static JdbcTemplate observer() { return new JdbcTemplate(new DriverManagerDataSource(URL, USER, PASSWORD)); }
    static HttpResponse<String> post(HttpClient client, int port, String id, String args) throws Exception {
        return client.send(HttpRequest.newBuilder(URI.create("http://127.0.0.1:"+port+"/orders/"+id+"?"+args))
                .timeout(Duration.ofSeconds(10)).POST(HttpRequest.BodyPublishers.noBody()).build(), HttpResponse.BodyHandlers.ofString());
    }
    static void check(String label, boolean result) {
        if (!result) throw new AssertionError(label);
        System.out.println("CHECK PASS " + label);
    }
}
