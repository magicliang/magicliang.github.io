package blog.spring.finalapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertThrows;

class Chapter41PureTest {
    @Test void amountRuleWithoutSpringContext() {
        assertThrows(IllegalArgumentException.class, () -> OrderApp.Store.validate(0));
        System.out.println("CHECK PASS pure JUnit amount rule without SpringExtension or context");
    }
}
