package blog.spring.finalapp;

import java.nio.charset.StandardCharsets;
import org.springframework.aot.hint.*;
import org.springframework.boot.*;
import org.springframework.context.annotation.*;
import org.springframework.core.SpringVersion;
import org.springframework.core.io.ClassPathResource;

@Configuration(proxyBeanMethods = false)
@ImportRuntimeHints(AotApp.Hints.class)
public class AotApp {
    @Bean @Profile("blue") Marker blue() { return new Marker("blue"); }
    @Bean @Profile("red") Marker red() { return new Marker("red"); }
    public record Marker(String value) {}
    public static final class Payload { public Payload() {} public String value() { return "reflection-ok"; } }
    public static final class Hints implements RuntimeHintsRegistrar {
        public void registerHints(RuntimeHints hints, ClassLoader loader) {
            hints.resources().registerPattern("lab-aot-message.txt");
            hints.reflection().registerType(Payload.class, MemberCategory.INVOKE_PUBLIC_CONSTRUCTORS, MemberCategory.INVOKE_PUBLIC_METHODS);
        }
    }
    public static void main(String[] args) throws Exception {
        SpringApplication app = new SpringApplication(AotApp.class);
        app.setWebApplicationType(WebApplicationType.NONE);
        try (var context = app.run(args)) {
            check("framework fixed", "6.2.11".equals(SpringVersion.getVersion()));
            String expected = context.getEnvironment().getProperty("lab.expected", "blue");
            check("selected bean " + expected, context.getBean(Marker.class).value().equals(expected));
            try (var in = new ClassPathResource("lab-aot-message.txt").getInputStream()) {
                check("classpath resource", new String(in.readAllBytes(), StandardCharsets.UTF_8).trim().equals("resource-ok"));
            }
            Object payload = Payload.class.getConstructor().newInstance();
            check("reflective invocation", Payload.class.getMethod("value").invoke(payload).equals("reflection-ok"));
            System.out.println("ACTIVE_PROFILES=" + String.join(",", context.getEnvironment().getActiveProfiles()));
            System.out.println("AOT_ENABLED=" + Boolean.getBoolean("spring.aot.enabled"));
        }
    }
    static void check(String label, boolean value) { if (!value) throw new AssertionError(label); System.out.println("CHECK PASS " + label); }
}
