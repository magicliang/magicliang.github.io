package blog.spring.finalapp;

import java.net.http.HttpClient;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.*;
import org.springframework.jdbc.datasource.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.test.context.transaction.TestTransaction;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.junit.jupiter.api.Assertions.*;
import static blog.spring.finalapp.LabSupport.*;

@SpringJUnitConfig(Chapter41Test.Config.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class Chapter41Test {
    @Configuration static class Config {
        @Bean DriverManagerDataSource dataSource() { return new DriverManagerDataSource(URL, USER, PASSWORD); }
        @Bean DataSourceTransactionManager transactionManager(DriverManagerDataSource ds) { return new DataSourceTransactionManager(ds); }
        @Bean OrderApp.Store store(DriverManagerDataSource ds, DataSourceTransactionManager tm) {
            return new OrderApp.Store(new JdbcTemplate(ds), new TransactionTemplate(tm));
        }
        @Bean AtomicInteger mutable() { return new AtomicInteger(); }
    }
    @Autowired OrderApp.Store store;
    @Autowired AtomicInteger mutable;
    @Test @Order(1) void pureAndMockMvc() throws Exception {
        var mvc = MockMvcBuilders.standaloneSetup(new OrderApp.Orders(store)).build();
        mvc.perform(post("/orders/mvc-invalid").param("amount", "0")).andExpect(status().isBadRequest());
        check("MockMvc maps same validation fault to 400", true);
        mvc.perform(post("/orders/mvc-invalid").param("amount", "not-an-int")).andExpect(status().isBadRequest());
        check("MockMvc rejects binding before service", true);
    }
    @Test @Order(2) @Transactional void rollbackMasksCallback() {
        store.brokenCallback = true;
        try {
            store.create("test41-hidden", 10, false);
            check("test transaction delays afterCommit", store.callbacks.get() == 0);
            check("independent connection cannot see uncommitted row", count("test41-hidden") == 0);
            TestTransaction.flagForRollback(); TestTransaction.end();
            check("rollback skips broken callback", store.callbacks.get() == 0);
            check("rolled back row absent", count("test41-hidden") == 0);
        } finally { store.brokenCallback = false; }
    }
    @Test @Order(3) @Transactional void actualCommitExposesCallback() {
        store.brokenCallback = true;
        try {
            store.create("test41-committed", 10, false);
            TestTransaction.flagForCommit();
            assertThrows(IllegalStateException.class, TestTransaction::end);
            check("commit exposes callback fault", store.callbacks.get() == 1);
            check("callback exception cannot undo committed row", count("test41-committed") == 1);
        } finally {
            store.brokenCallback = false;
            observer().update("delete from " + OrderApp.TABLE + " where id='test41-committed'");
        }
    }
    @Test @Order(4) void cachedSingletonMutation() { mutable.set(99); check("singleton state changed", mutable.get() == 99); }
    @Test @Order(5) @DirtiesContext(methodMode = DirtiesContext.MethodMode.AFTER_METHOD)
    void cachedSingletonPollution() { check("next test inherits mutable singleton", mutable.get() == 99); }
    @Test @Order(6) void dirtyContextRebuilt() { check("DirtiesContext rebuilds singleton", mutable.get() == 0); }
    @Test @Order(7) void realHttpAndDatabase() throws Exception {
        try (var context = start(); var client = HttpClient.newHttpClient()) {
            int port = port(context);
            check("real server maps same validation fault to 400", LabSupport.post(client, port, "real-invalid", "amount=0").statusCode() == 400);
            check("real server commits request", LabSupport.post(client, port, "test41-http", "amount=10").statusCode() == 201);
            check("external JDBC observer sees request commit", count("test41-http") == 1);
        } finally { observer().update("delete from " + OrderApp.TABLE + " where id='test41-http'"); }
    }
    static int count(String id) { return observer().queryForObject("select count(*) from " + OrderApp.TABLE + " where id=?", Integer.class, id); }
}
