package blog.spring.finalapp;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import javax.sql.DataSource;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.*;
import org.springframework.web.bind.annotation.*;

@SpringBootConfiguration
@EnableAutoConfiguration
@Import(OrderApp.Orders.class)
public class OrderApp {
    public static final String TABLE = "spring_final.orders";
    @Bean Store store(DataSource source, PlatformTransactionManager manager) {
        return new Store(new JdbcTemplate(source), new TransactionTemplate(manager));
    }
    @Bean(destroyMethod = "close") Work work() { return new Work(); }
    public static final class Work implements AutoCloseable {
        public final ExecutorService executor = Executors.newSingleThreadExecutor();
        public final AtomicInteger failures = new AtomicInteger();
        public CompletableFuture<Void> fail() {
            return CompletableFuture.runAsync(() -> { throw new IllegalStateException("mail unavailable"); }, executor);
        }
        public void close() throws InterruptedException {
            executor.shutdown();
            if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                executor.shutdownNow();
                if (!executor.awaitTermination(5, TimeUnit.SECONDS)) throw new IllegalStateException("executor leaked");
            }
        }
    }
    public static final class Store {
        public final JdbcTemplate jdbc;
        public final TransactionTemplate tx;
        public final AtomicInteger callbacks = new AtomicInteger();
        public volatile boolean brokenCallback;
        Store(JdbcTemplate jdbc, TransactionTemplate tx) {
            this.jdbc = jdbc; this.tx = tx;
            jdbc.execute("create schema if not exists spring_final");
            jdbc.execute("create table if not exists " + TABLE + " (id varchar(100) primary key, amount int not null)");
        }
        public static void validate(int amount) { if (amount <= 0) throw new IllegalArgumentException("amount must be positive"); }
        public boolean create(String id, int amount, boolean fail) {
            validate(amount);
            return Boolean.TRUE.equals(tx.execute(status -> {
                int rows = jdbc.update("insert into " + TABLE + " values (?,?) on conflict (id) do nothing", id, amount);
                if (rows == 0) {
                    int existing = jdbc.queryForObject("select amount from " + TABLE + " where id=?", Integer.class, id);
                    if (existing != amount) throw new IllegalArgumentException("id reused with different amount");
                }
                if (fail) throw new IllegalStateException("payment failed");
                if (rows == 1) TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                    @Override public void afterCommit() {
                        callbacks.incrementAndGet();
                        if (brokenCallback) throw new IllegalStateException("broken afterCommit");
                    }
                });
                return rows == 1;
            }));
        }
    }
    @RestController
    public static class Orders {
        private final Store store;
        public Orders(Store store) { this.store = store; }
        @PostMapping("/orders/{id}") public ResponseEntity<String> create(@PathVariable String id,
                @RequestParam int amount, @RequestParam(defaultValue = "false") boolean fail) {
            return ResponseEntity.status(store.create(id, amount, fail) ? 201 : 200).body(id);
        }
        @GetMapping("/slow") public String slow() throws InterruptedException { Thread.sleep(600); return "done"; }
        @ExceptionHandler(IllegalArgumentException.class) ResponseEntity<String> invalid(IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
        @ExceptionHandler(IllegalStateException.class) ResponseEntity<String> failed(IllegalStateException e) {
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }
}
