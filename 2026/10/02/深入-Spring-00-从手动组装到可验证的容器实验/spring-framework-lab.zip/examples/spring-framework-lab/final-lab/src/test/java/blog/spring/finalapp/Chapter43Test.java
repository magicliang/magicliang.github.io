package blog.spring.finalapp;

import com.zaxxer.hikari.HikariDataSource;
import java.net.*;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static blog.spring.finalapp.LabSupport.*;

class Chapter43Test {
    @Test void fullOrderLifecycle() throws Exception {
        var context = start();
        var source = context.getBean(HikariDataSource.class);
        var store = context.getBean(OrderApp.Store.class);
        var work = context.getBean(OrderApp.Work.class);
        int port = port(context);
        String prefix = "test43-" + UUID.randomUUID();
        try (var client = HttpClient.newHttpClient(); var callers = Executors.newFixedThreadPool(8)) {
            check("normal HTTP created", post(client, port, prefix+"-normal", "amount=12").statusCode() == 201);
            check("normal commit visible outside pool", count(prefix+"-normal") == 1);
            check("normal afterCommit ran once", store.callbacks.get() == 1);
            var barrier = new CountDownLatch(1);
            List<Future<Integer>> results = new ArrayList<>();
            for (int i=0; i<8; i++) results.add(callers.submit(() -> { barrier.await(); return post(client, port, prefix+"-same", "amount=20").statusCode(); }));
            barrier.countDown();
            List<Integer> codes = new ArrayList<>();
            for (var future : results) codes.add(future.get(15, TimeUnit.SECONDS));
            check("eight concurrent responses one created seven existing", Collections.frequency(codes, 201)==1 && Collections.frequency(codes, 200)==7);
            check("concurrent idempotency stores one row", count(prefix+"-same") == 1);
            check("duplicate requests do not duplicate callback", store.callbacks.get() == 2);
            check("same id with different amount rejected", post(client, port, prefix+"-same", "amount=21").statusCode() == 400);
            check("rollback mapped to 500", post(client, port, prefix+"-rollback", "amount=5&fail=true").statusCode()==500);
            check("rollback absent from external observer", count(prefix+"-rollback")==0);
            check("rollback skipped commit callback", store.callbacks.get()==2);
            var discarded = work.fail();
            assertThrows(CompletionException.class, discarded::join);
            check("unobserved future has no failure metric", work.failures.get()==0);
            var observed = work.fail().whenComplete((value, failure) -> { if (failure != null) work.failures.incrementAndGet(); });
            assertThrows(CompletionException.class, observed::join);
            check("minimal completion handler records async failure", work.failures.get()==1);
            check("async failure did not reverse committed order", count(prefix+"-normal")==1);
            var slow = HttpRequest.newBuilder(URI.create("http://127.0.0.1:"+port+"/slow")).timeout(Duration.ofMillis(80)).build();
            assertThrows(HttpTimeoutException.class, () -> client.send(slow, HttpResponse.BodyHandlers.ofString()));
            check("real HTTP response deadline elapsed", true);
            check("server accepts request after client timeout", post(client, port, prefix+"-after-timeout", "amount=7").statusCode()==201);
            check("pool has no borrowed connection after completed requests", source.getHikariPoolMXBean().getActiveConnections()==0);
        } finally {
            context.close();
            observer().update("delete from " + OrderApp.TABLE + " where id like ?", prefix+"%");
        }
        check("Spring context closed", !context.isActive());
        check("JDBC pool closed", source.isClosed());
        check("async executor terminated", work.executor.isTerminated());
        try (var socket = new Socket()) {
            assertThrows(java.io.IOException.class, () -> socket.connect(new InetSocketAddress("127.0.0.1", port), 500));
            check("HTTP listener no longer accepts", true);
        }
        check("external cleanup sees no experiment rows", observer().queryForObject("select count(*) from " + OrderApp.TABLE + " where id like ?", Integer.class, prefix+"%")==0);
    }
    static int count(String id) { return observer().queryForObject("select count(*) from " + OrderApp.TABLE + " where id=?", Integer.class, id); }
}
