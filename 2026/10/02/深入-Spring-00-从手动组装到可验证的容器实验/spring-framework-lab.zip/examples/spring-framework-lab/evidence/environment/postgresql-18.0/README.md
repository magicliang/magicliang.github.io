# 实际数据库环境

日期2026-10-02；PostgreSQL18.0，官方源包SHA256 `0d5b903b1e5fe361bca7aa9507519933773eb34266b1357c4e7780fdee6d6078`；Apple clang21，aarch64-apple-darwin27.0.0；应用JDK21.0.11、Framework6.2.11、JDBC42.7.7、Hikari5.0.1。仅教学固定版本，不表示生产升级建议。

源码=/private/tmp/postgresql-18.0；安装=/private/tmp/spring-postgresql-runtime-18.0；数据=/private/tmp/spring-postgresql-data-source-20261002；日志=/private/tmp/spring-postgresql-server-20261002.log；地址127.0.0.1:55432；用户/数据库spring_lab；READ COMMITTED。

```bash
./configure --prefix=/private/tmp/spring-postgresql-runtime-18.0 --without-readline --without-zlib --without-icu
make -j6
make install
ln -s /private/tmp/postgresql-18.0/src/backend/postgres /private/tmp/postgresql-18.0/src/bin/initdb/postgres
/private/tmp/postgresql-18.0/src/bin/initdb/initdb -L /private/tmp/spring-postgresql-runtime-18.0/share -D /private/tmp/spring-postgresql-data-source-20261002 -U spring_lab --auth=trust --no-locale --encoding=UTF8
/private/tmp/postgresql-18.0/src/bin/pg_ctl/pg_ctl -p /private/tmp/postgresql-18.0/src/backend/postgres -D /private/tmp/spring-postgresql-data-source-20261002 -l /private/tmp/spring-postgresql-server-20261002.log -o '-h 127.0.0.1 -p 55432 -k /private/tmp' -w start
/private/tmp/postgresql-18.0/src/bin/scripts/createdb -h 127.0.0.1 -p 55432 -U spring_lab spring_lab
```

构建/安装退出码0；initdb、pg_ctl、createdb最终成功。安装目录程序exit137，源码目录程序工作正常；最终命令不依赖失败的安装目录程序。build.txt.gz和install.txt.gz为完整原始构建日志；server-start.txt为启动后服务器版本、隔离和会话查询。

PostgreSQL源码回归make check为NOT_RUN；没有镜像构建；没有生产数据库或外部服务。数据库暂时保留运行用于后续事务/ORM/响应式章节，全系列验收后关闭并记录终态。
