package blog.spring.finalapp;

import org.springframework.aot.generate.Generated;
import org.springframework.beans.factory.aot.BeanInstanceSupplier;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.RootBeanDefinition;

/**
 * Bean definitions for {@link AotApp}.
 */
@Generated
public class AotApp__BeanDefinitions {
  /**
   * Get the bean definition for 'aotApp'.
   */
  public static BeanDefinition getAotAppBeanDefinition() {
    RootBeanDefinition beanDefinition = new RootBeanDefinition(AotApp.class);
    beanDefinition.setInstanceSupplier(AotApp::new);
    return beanDefinition;
  }

  /**
   * Get the bean instance supplier for 'blue'.
   */
  private static BeanInstanceSupplier<AotApp.Marker> getBlueInstanceSupplier() {
    return BeanInstanceSupplier.<AotApp.Marker>forFactoryMethod(AotApp.class, "blue")
            .withGenerator((registeredBean) -> registeredBean.getBeanFactory().getBean("aotApp", AotApp.class).blue());
  }

  /**
   * Get the bean definition for 'blue'.
   */
  public static BeanDefinition getBlueBeanDefinition() {
    RootBeanDefinition beanDefinition = new RootBeanDefinition(AotApp.Marker.class);
    beanDefinition.setFactoryBeanName("aotApp");
    beanDefinition.setInstanceSupplier(getBlueInstanceSupplier());
    return beanDefinition;
  }
}
