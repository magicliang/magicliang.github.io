package blog.spring.consistency;

import java.net.*;
import java.net.http.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import javax.transaction.xa.*;
import javax.sql.XAConnection;
import org.postgresql.xa.PGXADataSource;
import com.sun.net.httpserver.HttpServer;

/** Fixed two-branch process-crash demonstration, not a production JTA coordinator. */
public class ChapterE04 {
    static final int PORT = Integer.getInteger("spring.lab.xa.port", 55433);
    static final Path DECISION = Path.of(System.getProperty("spring.lab.xa.decision", "target/e04-decision.txt"));
    static final String[] DATABASES = {"spring_xa_a", "spring_xa_b"};
    static void check(boolean condition, String label) { if (!condition) throw new AssertionError(label); System.out.println("PASS " + label); }
    static Connection connection(String database) throws SQLException { return DriverManager.getConnection("jdbc:postgresql://127.0.0.1:" + PORT + "/" + database + "?socketTimeout=5", "spring_lab", ""); }
    static XAConnection xa(String database) throws SQLException {
        var source = new PGXADataSource(); source.setServerNames(new String[]{"127.0.0.1"}); source.setPortNumbers(new int[]{PORT}); source.setDatabaseName(database); source.setUser("spring_lab"); return source.getXAConnection();
    }
    static final Map<Integer,Xid> identifiers = new HashMap<>();
    static Xid xid(int branch) { return identifiers.computeIfAbsent(branch, key -> new Xid() {
        public int getFormatId() { return 4004; }
        public byte[] getGlobalTransactionId() { return "spring-e04".getBytes(java.nio.charset.StandardCharsets.UTF_8); }
        public byte[] getBranchQualifier() { return new byte[]{(byte)branch}; }
    }); }
    static boolean ours(Xid value) { return value.getFormatId() == 4004 && Arrays.equals(value.getGlobalTransactionId(), xid(1).getGlobalTransactionId()); }
    static int count(String database, String sql) throws SQLException {
        try(var c=connection(database);var s=c.createStatement();var r=s.executeQuery(sql)) { r.next(); return r.getInt(1); }
    }
    static void setup() throws SQLException {
        for(String database:DATABASES) try(var c=connection(database);var s=c.createStatement()) {
            s.execute("create table xa_orders(id int primary key, note text)");
            s.execute("create table outbox(id int primary key, sent boolean not null default false)");
            s.execute("create table inbox(id int primary key)");
            s.execute("create table effects(id int primary key)");
        }
    }
    static void prepareAndCrash() throws Exception {
        setup(); var a=xa(DATABASES[0]);var b=xa(DATABASES[1]);
        check(!a.getXAResource().isSameRM(b.getXAResource()), "two database connections are distinct XA resource managers");
        XAConnection[] branches={a,b};
        for(int i=0;i<2;i++) {
            var resource=branches[i].getXAResource(); resource.start(xid(i+1),XAResource.TMNOFLAGS);
            try(var c=branches[i].getConnection();var s=c.createStatement()) {s.executeUpdate("insert into xa_orders values(4,'two-phase')");}
            resource.end(xid(i+1),XAResource.TMSUCCESS);
            check(resource.prepare(xid(i+1))==XAResource.XA_OK,"branch "+i+" votes prepared");
        }
        check(count(DATABASES[0],"select count(*) from xa_orders")==0 && count(DATABASES[1],"select count(*) from xa_orders")==0,"prepared changes invisible to independent sessions");
        try(var file=FileChannel.open(DECISION,StandardOpenOption.CREATE,StandardOpenOption.TRUNCATE_EXISTING,StandardOpenOption.WRITE)) {
            var data=ByteBuffer.wrap("COMMIT spring-e04 branches=1,2\n".getBytes(java.nio.charset.StandardCharsets.UTF_8));
            while(data.hasRemaining()) file.write(data); file.force(true);
        }
        a.getXAResource().commit(xid(1),false);
        check(count(DATABASES[0],"select count(*) from xa_orders")==1 && count(DATABASES[1],"select count(*) from xa_orders")==0,"one branch committed while second remains prepared");
        System.out.println("CRASH after forced COMMIT decision and first branch commit; expected exit 17"); System.out.flush();
        Runtime.getRuntime().halt(17);
    }
    static void recover() throws Exception {
        check(Files.readString(DECISION).equals("COMMIT spring-e04 branches=1,2\n"),"new JVM reads forced commit decision");
        int recovered=0;
        for(String database:DATABASES) {
            var c=xa(database);try {
                var resource=c.getXAResource();
                for(var value:resource.recover(XAResource.TMSTARTRSCAN|XAResource.TMENDRSCAN)) if(ours(value)) {
                    System.out.println("RECOVER database="+database+" branch="+Arrays.toString(value.getBranchQualifier()));
                    resource.commit(value,false);recovered++;
                }
            } finally {c.close();}
        }
        check(recovered==1,"recovery finds only remaining prepared branch");
        for(String database:DATABASES) check(count(database,"select count(*) from xa_orders where id=4")==1,"recovered business commit visible in "+database);
        check(count(DATABASES[0],"select count(*) from pg_prepared_xacts")==0,"no prepared transactions remain");
        var c=xa(DATABASES[0]);try {
            var resource=c.getXAResource();resource.start(xid(3),XAResource.TMNOFLAGS);
            try(var logical=c.getConnection();var s=logical.createStatement()) {s.executeUpdate("insert into xa_orders values(5,'rollback-prepared')");}
            resource.end(xid(3),XAResource.TMSUCCESS);check(resource.prepare(xid(3))==XAResource.XA_OK,"negative branch prepares before rollback");
            resource.rollback(xid(3));
        } finally {c.close();}
        check(count(DATABASES[0],"select count(*) from xa_orders where id=5")==0,"prepared rollback leaves no business row");
        System.out.println("XA RECOVERY PASS");
    }
    static void outbox() throws Exception {
        try(var c=connection(DATABASES[0]);var s=c.createStatement()) {
            c.setAutoCommit(false);s.executeUpdate("insert into xa_orders values(6,'outbox')");s.executeUpdate("insert into outbox(id) values(6)");c.commit();
            s.executeUpdate("insert into xa_orders values(7,'rollback')");s.executeUpdate("insert into outbox(id) values(7)");c.rollback();
        }
        check(count(DATABASES[0],"select count(*) from xa_orders where id=6")==1 && count(DATABASES[0],"select count(*) from outbox where id=6")==1,"order and outbox commit in one local transaction");
        check(count(DATABASES[0],"select count(*) from xa_orders where id=7")==0 && count(DATABASES[0],"select count(*) from outbox where id=7")==0,"order and outbox rollback together");
        AtomicInteger deliveries=new AtomicInteger(); var workers=Executors.newFixedThreadPool(1);
        var server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);server.setExecutor(workers);
        server.createContext("/receive",exchange->{
            try {
                int id=Integer.parseInt(new String(exchange.getRequestBody().readAllBytes(),java.nio.charset.StandardCharsets.UTF_8));deliveries.incrementAndGet();
                int inserted;
                try(var c=connection(DATABASES[1])) {
                    c.setAutoCommit(false);
                    try(var insert=c.prepareStatement("insert into inbox values(?) on conflict do nothing")) {insert.setInt(1,id);inserted=insert.executeUpdate();}
                    if(inserted==1) try(var effect=c.prepareStatement("insert into effects values(?)")) {effect.setInt(1,id);effect.executeUpdate();}
                    c.commit();
                }
                var body=(inserted==1?"applied":"duplicate").getBytes(java.nio.charset.StandardCharsets.UTF_8);
                exchange.sendResponseHeaders(200,body.length);exchange.getResponseBody().write(body);
            } catch(Exception failure) {exchange.sendResponseHeaders(500,-1);}
            finally {exchange.close();}
        });server.start();
        try(var client=HttpClient.newHttpClient()) {
            var request=HttpRequest.newBuilder(URI.create("http://127.0.0.1:"+server.getAddress().getPort()+"/receive")).timeout(java.time.Duration.ofSeconds(5)).POST(HttpRequest.BodyPublishers.ofString("6")).build();
            var first=client.send(request,HttpResponse.BodyHandlers.ofString());check(first.statusCode()==200 && first.body().equals("applied"),"first real HTTP delivery applied at receiver");
            // Inject a sender crash window: successful acknowledgement is not recorded in outbox.
            check(count(DATABASES[0],"select count(*) from outbox where id=6 and not sent")==1,"sender has no persisted acknowledgement after first delivery");
            var second=client.send(request,HttpResponse.BodyHandlers.ofString());check(second.statusCode()==200 && second.body().equals("duplicate"),"retry is delivered but receiver reports duplicate");
            try(var c=connection(DATABASES[0]);var s=c.createStatement()) {s.executeUpdate("update outbox set sent=true where id=6");}
            check(deliveries.get()==2,"transport performed two deliveries");
            check(count(DATABASES[1],"select count(*) from inbox where id=6")==1 && count(DATABASES[1],"select count(*) from effects where id=6")==1,"receiver commits one deduplication key and one business effect");
            check(count(DATABASES[0],"select count(*) from outbox where id=6 and sent")==1,"sender eventually persists acknowledgement");
        } finally {server.stop(0);workers.shutdown();check(workers.awaitTermination(5,TimeUnit.SECONDS),"receiver HTTP workers terminated");}
        System.out.println("CHAPTER E04 PASS");
    }
    public static void main(String[] args)throws Exception {switch(args[0]) {case "prepare"->prepareAndCrash();case "recover"->recover();case "outbox"->outbox();default->throw new IllegalArgumentException(args[0]);}}
}
