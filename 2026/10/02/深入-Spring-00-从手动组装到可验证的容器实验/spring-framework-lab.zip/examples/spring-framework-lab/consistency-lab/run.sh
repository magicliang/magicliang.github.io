#!/bin/sh
set -eu
cd "$(dirname "$0")"
export JAVA_HOME="${JAVA_HOME:?Set JAVA_HOME to JDK 21}"
PG_SRC="${PG_SRC:-/private/tmp/postgresql-18.0}"
PG_SHARE="${PG_SHARE:-/private/tmp/spring-postgresql-runtime-18.0/share}"
output=../evidence/E04/local-20261002
mkdir -p "$output"
printf '1\n' > "$output/exit-code.txt"
../mvnw -f consistency-lab/pom.xml -B -q compile dependency:build-classpath -Dmdep.outputFile=target/classpath.txt > "$output/build.txt" 2>&1
data=$(mktemp -d /private/tmp/spring-e04-pg-XXXXXX)
"$PG_SRC/src/bin/initdb/initdb" -D "$data" -L "$PG_SHARE" --no-locale -E UTF8 -U spring_lab --auth=trust > "$output/database-start.txt" 2>&1
"$PG_SRC/src/bin/pg_ctl/pg_ctl" -p "$PG_SRC/src/backend/postgres" -D "$data" -l "$data/server.log" -o '-h 127.0.0.1 -p 55433 -k /private/tmp -c max_prepared_transactions=10' -w start >> "$output/database-start.txt" 2>&1
trap '"$PG_SRC/src/bin/pg_ctl/pg_ctl" -D "$data" -m fast -w stop >> "$output/database-stop.txt" 2>&1' EXIT
for database in spring_xa_a spring_xa_b; do "$PG_SRC/src/bin/psql/psql" -h 127.0.0.1 -p 55433 -U spring_lab -d postgres -v ON_ERROR_STOP=1 -c "create database $database" >> "$output/database-start.txt"; done
"$PG_SRC/src/bin/psql/psql" -h 127.0.0.1 -p 55433 -U spring_lab -d postgres -v ON_ERROR_STOP=1 -c 'select version(); show max_prepared_transactions' > "$output/environment.txt"
classpath="target/classes:$(cat target/classpath.txt)"
code=0
"$JAVA_HOME/bin/java" -cp "$classpath" blog.spring.consistency.ChapterE04 prepare > "$output/run.txt" 2>&1 || code=$?
printf '%s\n' "$code" > "$output/crash-exit-code.txt"
if [ "$code" -ne 17 ]; then cat "$output/run.txt"; exit 1; fi
"$JAVA_HOME/bin/java" -cp "$classpath" blog.spring.consistency.ChapterE04 recover >> "$output/run.txt" 2>&1
"$JAVA_HOME/bin/java" -cp "$classpath" blog.spring.consistency.ChapterE04 outbox >> "$output/run.txt" 2>&1
printf '0\n' > "$output/exit-code.txt"
cp target/e04-decision.txt "$output/decision.txt"
cat "$output/run.txt"
