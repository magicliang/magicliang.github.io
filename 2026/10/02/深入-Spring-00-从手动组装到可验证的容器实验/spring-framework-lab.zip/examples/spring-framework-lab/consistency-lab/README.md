# E04：XA 与 outbox 实验

使用 JDK 21。固定 pgJDBC 42.7.7。该模块是有持久提交决定的教学协调器，直接调用真实 XAResource，**不是生产 JTA 协调器，也没有运行 JtaTransactionManager**。

## 前置条件和运行

run.sh 需要已经编译的 PostgreSQL 18.0 源码树。PG_SRC 下必须存在 src/bin/initdb/initdb、src/bin/pg_ctl/pg_ctl、src/bin/psql/psql 和 src/backend/postgres。PG_SHARE 指向 PostgreSQL 18.0 的 share 目录，内含 postgres.bki 等初始化文件。脚本没有下载或编译数据库。

本机默认 PG_SRC=/private/tmp/postgresql-18.0，PG_SHARE=/private/tmp/spring-postgresql-runtime-18.0/share。其他机器必须设为自己的实际路径；源码工具用于避免本机已安装二进制启动失败问题。

```bash
export JAVA_HOME=/path/to/jdk-21
export PG_SRC=/path/to/postgresql-18.0
export PG_SHARE=/path/to/postgresql-18.0/share
sh consistency-lab/run.sh
```

从 examples/spring-framework-lab 运行。需要 Maven 下载网络、可写 ~/.m2 和本地端口绑定权限。

脚本固定占用 127.0.0.1:55433，并建立专用临时集群，max_prepared_transactions=10。运行前必须保证端口未占用；不可与另一份 E04 同时运行，也不应停止占用端口的他人服务。已有共享数据库 55432 不受影响。脚本 trap 只关闭自己创建的集群，保留临时数据目录便于排查。

## 可核对终态

prepare 子进程持久化 COMMIT 决定、提交资源 A 后 Runtime.halt(17)，脚本明确验收退出码 17。全新 JVM recover 恢复资源 B，两个数据库均有订单、prepared 数为零。另有 prepare 后 rollback 分支。

outbox 先验证本地事务原子性，再通过真实本地 HTTP 投递同一事件两次；第一次接收成功后故意不落发送确认，并非第二次进程崩溃。数据库业务与 outbox 各一条，传输两次，接收 inbox/effects 各一条，发送标记最终为 sent。

evidence/E04/local-20261002 保存 run.txt、build.txt、exit-code.txt、crash-exit-code.txt、decision.txt、数据库启动关闭和环境文件。当前完整运行 21 条 PASS，最终退出 0。进程崩溃实验不证明断电持久性或网络分区恢复。

