package blog.spring.concurrent;

import java.net.URI;
import java.net.http.*;
import java.sql.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import com.zaxxer.hikari.*;
import io.r2dbc.pool.*;
import io.r2dbc.spi.ConnectionFactories;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import org.springframework.context.annotation.*;
import org.springframework.http.server.reactive.ReactorHttpHandlerAdapter;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.config.EnableWebFlux;
import org.springframework.web.server.adapter.WebHttpHandlerBuilder;
import reactor.core.publisher.*;
import reactor.netty.http.server.HttpServer;
import reactor.netty.resources.LoopResources;

public class ChapterE05 {
    static final Duration LIMIT=Duration.ofSeconds(20);
    static HikariDataSource jdbc;
    static ConnectionPool reactive;
    static DatabaseClient db;
    static final AtomicInteger completed=new AtomicInteger(), cancels=new AtomicInteger();
    static final AtomicBoolean handlerVirtual=new AtomicBoolean();
    static void check(boolean condition,String label){if(!condition)throw new AssertionError(label);System.out.println("PASS "+label);}
    static String sql(boolean slow){return "select 42 as n from pg_sleep("+(slow?"0.5":"0.03")+")";}
    @Configuration(proxyBeanMethods=false) @EnableAutoConfiguration @Import(MvcApi.class)
    public static class MvcApp { }
    @RestController public static class MvcApi {
        @GetMapping("/work") public String work(@RequestParam(defaultValue="false") boolean slow)throws Exception {
            handlerVirtual.set(Thread.currentThread().isVirtual());
            try(var c=jdbc.getConnection();var s=c.createStatement();var r=s.executeQuery(sql(slow))) {r.next();completed.incrementAndGet();return r.getInt(1)+"";}
        }
    }
    @Configuration(proxyBeanMethods=false) @EnableWebFlux @Import(FluxApi.class)
    public static class FluxApp { }
    @RestController public static class FluxApi {
        @GetMapping("/work") public Mono<String> work(@RequestParam(defaultValue="false") boolean slow) {
            return db.sql(sql(slow)).map((row,metadata)->row.get("n",Integer.class)+"").one()
                    .doOnNext(value->completed.incrementAndGet()).doFinally(signal->{if(signal==SignalType.CANCEL)cancels.incrementAndGet();});
        }
    }
    static int leased(boolean flux){return flux?reactive.getMetrics().orElseThrow().acquiredSize():jdbc.getHikariPoolMXBean().getActiveConnections();}
    static int waiting(boolean flux){return flux?reactive.getMetrics().orElseThrow().pendingAcquireSize():jdbc.getHikariPoolMXBean().getThreadsAwaitingConnection();}
    static void workload(String mode,int port,boolean flux)throws Exception {
        var samples=Executors.newSingleThreadScheduledExecutor();var maxLease=new AtomicInteger();var maxWait=new AtomicInteger();
        samples.scheduleAtFixedRate(()->{maxLease.accumulateAndGet(leased(flux),Math::max);maxWait.accumulateAndGet(waiting(flux),Math::max);},0,1,TimeUnit.MILLISECONDS);
        try(var client=HttpClient.newHttpClient()) {
            URI uri=URI.create("http://127.0.0.1:"+port+"/work");
            var warm=client.send(HttpRequest.newBuilder(uri).timeout(LIMIT).build(),HttpResponse.BodyHandlers.ofString());check(warm.statusCode()==200 && warm.body().equals("42"),mode+" warmup business result");
            for(int round=1;round<=3;round++) {
                long start=System.nanoTime();List<CompletableFuture<HttpResponse<String>>> requests=new ArrayList<>();
                for(int i=0;i<12;i++)requests.add(client.sendAsync(HttpRequest.newBuilder(uri).timeout(LIMIT).build(),HttpResponse.BodyHandlers.ofString()));
                CompletableFuture.allOf(requests.toArray(CompletableFuture[]::new)).get(20,TimeUnit.SECONDS);
                check(requests.stream().allMatch(f->f.join().statusCode()==200 && f.join().body().equals("42")),mode+" round "+round+" twelve equal responses");
                System.out.println("SAMPLE mode="+mode+" round="+round+" requests=12 ns="+(System.nanoTime()-start)+" maxLease="+maxLease.get()+" maxWait="+maxWait.get());
            }
            check(completed.get()==37,mode+" warmup plus36 database completions");
            check(maxLease.get()==2 && maxWait.get()>0,mode+" same two connection cap with observed waiting");
            var first=client.sendAsync(HttpRequest.newBuilder(URI.create(uri+"?slow=true")).timeout(LIMIT).build(),HttpResponse.BodyHandlers.ofString());
            var second=client.sendAsync(HttpRequest.newBuilder(URI.create(uri+"?slow=true")).timeout(LIMIT).build(),HttpResponse.BodyHandlers.ofString());
            long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(5);
            while(leased(flux)<2 && System.nanoTime()<deadline)Thread.sleep(2);
            check(leased(flux)==2,mode+" cancellation window owns two leases");
            check(!first.isDone()&&!second.isDone(),mode+" HTTP futures pending before cancellation request");
            boolean firstAccepted=first.cancel(true),secondAccepted=second.cancel(true);long cancelledAt=System.nanoTime();
            check(first.isCompletedExceptionally()&&second.isCompletedExceptionally(),mode+" client futures end exceptionally after cancellation request");
            while((leased(flux)!=0||waiting(flux)!=0) && System.nanoTime()<deadline)Thread.sleep(5);
            check(leased(flux)==0 && waiting(flux)==0,mode+" cancellation followed by complete resource release");
            System.out.println("CANCEL mode="+mode+" cancelReturned="+firstAccepted+","+secondAccepted+" clientExceptional="+(first.isCompletedExceptionally()&&second.isCompletedExceptionally())+" serverCompleted="+completed.get()+" reactiveCancel="+cancels.get()+" releaseNs="+(System.nanoTime()-cancelledAt));
        } finally {samples.shutdownNow();check(samples.awaitTermination(3,TimeUnit.SECONDS),mode+" sampler terminated");}
    }
    static void mvc(boolean virtual)throws Exception {
        completed.set(0);cancels.set(0);handlerVirtual.set(false);
        var config=new HikariConfig();config.setJdbcUrl("jdbc:postgresql://127.0.0.1:55432/spring_lab?socketTimeout=5");config.setUsername("spring_lab");config.setMaximumPoolSize(2);config.setMinimumIdle(0);config.setConnectionTimeout(5000);
        jdbc=new HikariDataSource(config);String mode=virtual?"virtual-mvc":"platform-mvc";
        var app=new SpringApplication(MvcApp.class);app.setBannerMode(Banner.Mode.OFF);app.setLogStartupInfo(false);app.setRegisterShutdownHook(false);
        app.setDefaultProperties(Map.of("server.address","127.0.0.1","server.port","0","logging.level.root","ERROR","spring.threads.virtual.enabled",Boolean.toString(virtual),"server.tomcat.threads.max","4","server.tomcat.threads.min-spare","1","spring.autoconfigure.exclude","org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration,org.springframework.boot.autoconfigure.r2dbc.R2dbcAutoConfiguration"));
        try(var context=app.run()) {workload(mode,((ServletWebServerApplicationContext)context).getWebServer().getPort(),false);check(handlerVirtual.get()==virtual,mode+" actual handler thread kind");}
        finally {jdbc.close();}check(jdbc.isClosed(),mode+" pool closed");
    }
    static void flux()throws Exception {
        completed.set(0);cancels.set(0);
        reactive=new ConnectionPool(ConnectionPoolConfiguration.builder(ConnectionFactories.get("r2dbc:postgresql://spring_lab@127.0.0.1:55432/spring_lab")).initialSize(0).maxSize(2).maxAcquireTime(Duration.ofSeconds(5)).build());db=DatabaseClient.create(reactive);
        var context=new AnnotationConfigApplicationContext(FluxApp.class);var loops=LoopResources.create("e05-http",2,true);
        var server=HttpServer.create().host("127.0.0.1").port(0).runOn(loops,false).handle(new ReactorHttpHandlerAdapter(WebHttpHandlerBuilder.applicationContext(context).build())).bindNow(LIMIT);
        try {workload("webflux",server.port(),true);}
        finally {server.disposeNow(LIMIT);context.close();loops.disposeLater().block(LIMIT);reactive.disposeLater().block(LIMIT);}
        check(server.isDisposed()&&reactive.isDisposed()&&loops.isDisposed(),"WebFlux server pool and loops disposed");
    }
    public static void main(String[] args)throws Exception {mvc(false);mvc(true);flux();reactor.core.scheduler.Schedulers.shutdownNow();System.out.println("CHAPTER E05 PASS");}
}
