# E05–E06：线程、协程与资源边界

JDK 21，Boot BOM 3.5.6 / Framework 6.2.11；完整冻结依赖见 pom.xml 和对应 evidence 的 dependencies.txt。Kotlin 1.9.25，coroutines 1.8.1，Reactor Core 3.7.11。

按 ../db/README.md 启动 PostgreSQL 18，127.0.0.1:55432，数据库和用户 spring_lab，空密码。共享服务器不由本模块关闭。

```bash
export JAVA_HOME=/path/to/jdk-21
sh concurrency-lab/run.sh E05 E06
```

在 examples/spring-framework-lab 运行，默认参数也是 E05 E06。脚本调用根 Maven wrapper 并显式指定本模块 POM，输出 evidence/E05、E06/local-20261002/run.txt 和 exit-code.txt。需要网络获取依赖、可写 ~/.m2、本地 HTTP 监听权限。不要同时运行两份 E06，它会重建同名实验数据。

E05 启动平台 MVC、虚拟线程 MVC、WebFlux 三个真实 HTTP 服务，逐组预热并各执行三轮十二请求。相同 SQL、连接上限 2，检查结果、排队、客户端取消与服务端租约归零；38 条 PASS。样本只支持固定负载下的行为，不能作一般性能排行。修改池上限为 1 时同步改变峰值断言，并跳过依赖两条已租连接的取消段。

E06 使用真实 Spring ProxyFactory 调用 suspend 方法，检验普通环绕通知提前返回；随后执行挂起中的 R2DBC 事务、异常回滚、取消回滚、上下文切换与 ThreadLocal 反例，22 条 PASS。表 spring_e06_orders 在运行开始 truncate，只用于本实验。业务行终态和池租约单独断言。

两篇运行均关闭自己创建的 HTTP 服务、执行器、连接池和调度器。环境版本与哈希文件是单独捕获的运行收尾证据，原始 run.sh 不自动重建这些元数据；复跑后应重新生成。

