package blog.spring.concurrent

import io.r2dbc.pool.ConnectionPool
import io.r2dbc.pool.ConnectionPoolConfiguration
import io.r2dbc.spi.ConnectionFactories
import kotlinx.coroutines.*
import kotlinx.coroutines.reactor.ReactorContext
import kotlinx.coroutines.reactor.awaitSingle
import kotlinx.coroutines.reactor.awaitSingleOrNull
import org.springframework.r2dbc.connection.R2dbcTransactionManager
import org.springframework.r2dbc.core.DatabaseClient
import org.springframework.transaction.TransactionExecution
import org.springframework.transaction.TransactionExecutionListener
import org.springframework.transaction.reactive.TransactionSynchronizationManager
import org.springframework.transaction.reactive.TransactionalOperator
import org.springframework.transaction.reactive.executeAndAwait
import reactor.util.context.Context
import java.sql.DriverManager
import java.time.Duration
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.coroutineContext

object ChapterE06 {
    interface SuspendedReader { suspend fun read(): String }
    private fun verify(value: Boolean, label: String) { check(value) { label }; println("PASS $label") }
    private fun count(key: String): Int = DriverManager.getConnection("jdbc:postgresql://127.0.0.1:55432/spring_lab", "spring_lab", "").use { c ->
        c.prepareStatement("select count(*) from spring_e06_orders where key=?").use { s -> s.setString(1,key);s.executeQuery().use { r->r.next();r.getInt(1) } }
    }
    @JvmStatic fun main(args: Array<String>) = runBlocking {
        val pool=ConnectionPool(ConnectionPoolConfiguration.builder(ConnectionFactories.get("r2dbc:postgresql://spring_lab@127.0.0.1:55432/spring_lab")).initialSize(0).maxSize(1).maxAcquireTime(Duration.ofSeconds(5)).build())
        val db=DatabaseClient.create(pool)
        val commits=AtomicInteger();val rollbacks=AtomicInteger()
        val manager=R2dbcTransactionManager(pool)
        manager.addListener(object: TransactionExecutionListener {
            override fun afterCommit(transaction: TransactionExecution, failure: Throwable?) { if(failure==null)commits.incrementAndGet() }
            override fun afterRollback(transaction: TransactionExecution, failure: Throwable?) { if(failure==null)rollbacks.incrementAndGet() }
        })
        val tx=TransactionalOperator.create(manager)
        suspend fun insert(key:String) { db.sql("insert into spring_e06_orders values(:key)").bind("key",key).fetch().rowsUpdated().awaitSingle() }
        suspend fun available(label:String) {
            verify(db.sql("select 1 as n").map { row, _ -> row.get("n",Integer::class.java)!!.toInt() }.one().awaitSingle()==1,"$label next query obtains sole connection")
            verify(pool.metrics.orElseThrow().acquiredSize()==0 && pool.metrics.orElseThrow().pendingAcquireSize()==0,"$label no leases or waiters")
        }
        try {
            val adviceReturned=AtomicInteger()
            val entered=CompletableDeferred<Unit>();val finish=CompletableDeferred<Unit>()
            val target=object:SuspendedReader { override suspend fun read():String {entered.complete(Unit);finish.await();return "read-complete"} }
            val factory=org.springframework.aop.framework.ProxyFactory(target)
            factory.addAdvice(org.aopalliance.intercept.MethodInterceptor { invocation ->
                val result=invocation.proceed();adviceReturned.incrementAndGet();result
            })
            val proxy=factory.proxy as SuspendedReader
            val call=async {proxy.read()}
            entered.await();yield()
            verify(adviceReturned.get()==1 && !call.isCompleted,"ordinary around advice returns before suspended business completion")
            finish.complete(Unit)
            verify(call.await()=="read-complete","Spring proxy adapts eventual suspend result")
            db.sql("create table if not exists spring_e06_orders(key text primary key)").then().awaitSingleOrNull()
            db.sql("truncate spring_e06_orders").then().awaitSingleOrNull()
            val inserted=CompletableDeferred<Unit>();val release=CompletableDeferred<Unit>()
            val task=async(ReactorContext(Context.of("requestId","synthetic-e06"))) {
                tx.executeAndAwait {
                    insert("success");inserted.complete(Unit)
                    val before=Thread.currentThread().name
                    withContext(Dispatchers.Default) {
                        verify(Thread.currentThread().name!=before,"suspend block changes dispatcher thread")
                        verify(coroutineContext[ReactorContext]!!.context.get<String>("requestId")=="synthetic-e06","Reactor request context survives dispatcher switch")
                        verify(TransactionSynchronizationManager.forCurrentTransaction().awaitSingle().isActualTransactionActive,"reactive transaction context survives dispatcher switch")
                    }
                    release.await();"done"
                }
            }
            inserted.await()
            verify(!task.isCompleted && count("success")==0,"suspended callback has no returned result or committed row")
            release.complete(Unit)
            verify(task.await()=="done" && count("success")==1,"awaited successful transaction commits")
            available("success")
            try {tx.executeAndAwait {insert("error");delay(10);throw IllegalStateException("synthetic-e06-error")};error("must fail")}
            catch(expected:IllegalStateException){verify(expected.message=="synthetic-e06-error","exception after suspension propagates")}
            verify(count("error")==0,"exception rolls transaction back")
            available("error")
            val ready=CompletableDeferred<Unit>()
            val cancelled=launch {tx.executeAndAwait {insert("cancel");ready.complete(Unit);awaitCancellation()}}
            ready.await();verify(count("cancel")==0 && pool.metrics.orElseThrow().acquiredSize()==1,"cancel window holds uncommitted connection")
            cancelled.cancelAndJoin();available("cancel")
            verify(count("cancel")==0,"coroutine cancellation rolls back business write")
            verify(commits.get()==1 && rollbacks.get()==2,"transaction manager sees one commit and two rollbacks")
            val local=ThreadLocal<String>();local.set("caller")
            withContext(Dispatchers.Default) {verify(local.get()==null,"ordinary ThreadLocal not automatically propagated")}
            withContext(Dispatchers.Default + local.asContextElement("explicit")) {
                delay(10);verify(local.get()=="explicit","explicit context element restores ThreadLocal around suspension")
            }
            verify(local.get()=="caller","caller ThreadLocal restored after context block");local.remove()
        } finally {pool.disposeLater().awaitSingleOrNull();reactor.core.scheduler.Schedulers.shutdownNow()}
        verify(pool.isDisposed,"R2DBC pool disposed")
        println("CHAPTER E06 PASS")
    }
}
