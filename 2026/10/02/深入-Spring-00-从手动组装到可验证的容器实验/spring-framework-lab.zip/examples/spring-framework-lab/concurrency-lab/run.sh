#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ "$#" -eq 0 ]; then set -- E05 E06; fi
../mvnw -f concurrency-lab/pom.xml -B -q compile dependency:build-classpath -Dmdep.outputFile=target/classpath.txt
classpath="target/classes:$(cat target/classpath.txt)"
for chapter in "$@"; do
  case "$chapter" in E05|E06) ;; *) exit 2 ;; esac
  output="../evidence/$chapter/local-20261002"
  mkdir -p "$output"
  if "$JAVA_HOME/bin/java" -cp "$classpath" "blog.spring.concurrent.Chapter$chapter" > "$output/run.txt" 2>&1; then printf '0\n' > "$output/exit-code.txt";
  else result=$?; printf '%s\n' "$result" > "$output/exit-code.txt"; cat "$output/run.txt"; exit "$result"; fi
  cat "$output/run.txt"
done
