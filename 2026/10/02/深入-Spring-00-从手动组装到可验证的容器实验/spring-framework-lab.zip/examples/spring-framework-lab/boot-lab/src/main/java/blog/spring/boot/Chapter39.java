package blog.spring.boot;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.annotation.ElementType;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.context.annotation.*;
import org.springframework.core.type.AnnotationMetadata;
import static blog.spring.boot.Support.*;

public class Chapter39 {
    static final AtomicInteger registrations = new AtomicInteger();
    @Target(ElementType.TYPE) @Retention(RetentionPolicy.RUNTIME)
    @Import(PolicySelector.class)
    public @interface EnableOrderPolicy { }
    public static class PolicySelector implements ImportSelector {
        public String[] selectImports(AnnotationMetadata metadata) {
            return new String[] {PolicyRegistrar.class.getName()};
        }
    }
    public static class PolicyRegistrar implements ImportBeanDefinitionRegistrar {
        public void registerBeanDefinitions(AnnotationMetadata metadata, BeanDefinitionRegistry registry) {
            if (registry.containsBeanDefinition("registeredPolicy"))
                throw new IllegalStateException("registeredPolicy already defined; importer=" + metadata.getClassName());
            var definition = new RootBeanDefinition(OrderPolicy.class);
            definition.getConstructorArgumentValues().addIndexedArgumentValue(0, "registrar");
            definition.getConstructorArgumentValues().addIndexedArgumentValue(1, 7);
            definition.setSource(metadata.getClassName());
            registry.registerBeanDefinition("registeredPolicy", definition);
            registrations.incrementAndGet();
        }
    }
    @Configuration(proxyBeanMethods = false) @EnableOrderPolicy public static class First { }
    @Configuration(proxyBeanMethods = false) @EnableOrderPolicy public static class Second { }
    @Configuration(proxyBeanMethods = false) @Import({First.class, First.class}) public static class Duplicate { }
    @Configuration(proxyBeanMethods = false) public static class Direct {
        @Bean OrderPolicy registeredPolicy() { return new OrderPolicy("direct", 7); }
    }
    public static void main(String[] args) {
        try (var context = new AnnotationConfigApplicationContext(Direct.class)) {
            check(context.getBean(OrderPolicy.class).limit() == 7, "ordinary bean handles fixed single application policy");
        }
        registrations.set(0);
        try (var context = new AnnotationConfigApplicationContext(Duplicate.class)) {
            check(context.getBeansOfType(OrderPolicy.class).size() == 1, "same configuration imported twice yields one policy");
            check(registrations.get() == 1, "same configuration parsed once");
            check(context.getBeanDefinition("registeredPolicy").getSource().equals(First.class.getName()), "definition source retains importing configuration");
            check(context.getBean(OrderPolicy.class).source().equals("registrar"), "registrar definition instantiated normally");
        }
        try (var context = new AnnotationConfigApplicationContext()) {
            context.register(First.class, Second.class);
            try { context.refresh(); throw new AssertionError("two independent importers must conflict"); }
            catch (IllegalStateException failure) {
                check(failure.getMessage().contains("registeredPolicy already defined"), "different importers fail with explicit name conflict");
                System.out.println("EXPECTED " + failure);
            }
            check(!context.isActive(), "failed refresh leaves context inactive");
        }
        try (var context = new AnnotationConfigApplicationContext()) {
            context.registerBean("registeredPolicy", String.class, () -> "unrelated");
            context.register(First.class);
            try { context.refresh(); throw new AssertionError("foreign definition must conflict"); }
            catch (IllegalStateException failure) {
                check(failure.getMessage().contains("registeredPolicy already defined"), "foreign same-name definition never silently replaced");
            }
        }
        try (var context = new AnnotationConfigApplicationContext()) {
            var missing = new RootBeanDefinition();
            missing.setBeanClassName("blog.spring.optional.MissingPolicy");
            context.registerBeanDefinition("missingPolicy", missing);
            try { context.refresh(); throw new AssertionError("missing class must fail"); }
            catch (org.springframework.beans.factory.CannotLoadBeanClassException failure) {
                check(failure.getBeanName().equals("missingPolicy"), "missing type failure identifies definition name");
                System.out.println("EXPECTED " + failure.getClass().getSimpleName() + " " + failure.getBeanName());
            }
        }
        try (var context = application(Chapter38.App.class).run()) {
            check(context.getBean(OrderPolicy.class).source().equals("auto"), "Boot discovers actual imports resource without component scan");
            report(context);
        }
        System.out.println("CHAPTER 39 PASS");
    }
}
