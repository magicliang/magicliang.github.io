package blog.spring.boot;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
@ConditionalOnClass(name = "org.postgresql.Driver")
@ConditionalOnProperty(prefix = "lab.order", name = "enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(OrderProperties.class)
public class OrderAutoConfiguration {
    @Bean
    @ConditionalOnMissingBean(OrderPolicy.class)
    OrderPolicy orderPolicy(OrderProperties properties) {
        return new OrderPolicy("auto", properties.getLimit());
    }
}
