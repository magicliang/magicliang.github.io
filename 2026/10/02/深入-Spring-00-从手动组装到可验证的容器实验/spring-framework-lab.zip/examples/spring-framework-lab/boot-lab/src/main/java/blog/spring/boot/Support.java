package blog.spring.boot;

import java.util.Map;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.Banner;
import org.springframework.boot.autoconfigure.condition.ConditionEvaluationReport;
import org.springframework.context.ConfigurableApplicationContext;

public final class Support {
    private Support() { }
    public static void check(boolean value, String label) {
        if (!value) throw new AssertionError(label);
        System.out.println("PASS " + label);
    }
    public static SpringApplication application(Class<?>... sources) {
        var app = new SpringApplication(sources);
        app.setWebApplicationType(WebApplicationType.NONE);
        app.setBannerMode(Banner.Mode.OFF);
        app.setLogStartupInfo(false);
        app.setRegisterShutdownHook(false);
        app.setDefaultProperties(Map.of("spring.autoconfigure.exclude",
                "org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration",
                "logging.level.root", "ERROR", "lab.order.limit", "20"));
        return app;
    }
    public static void report(ConfigurableApplicationContext context) {
        ConditionEvaluationReport.get(context.getBeanFactory()).getConditionAndOutcomesBySource()
                .forEach((source, outcomes) -> {
                    if (source.contains("OrderAutoConfiguration"))
                        outcomes.forEach(outcome -> System.out.println("CONDITION " + source + " " + outcome.getOutcome()));
                });
    }
}
