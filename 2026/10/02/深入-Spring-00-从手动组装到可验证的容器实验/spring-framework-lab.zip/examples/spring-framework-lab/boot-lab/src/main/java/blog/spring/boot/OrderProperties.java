package blog.spring.boot;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("lab.order")
public class OrderProperties {
    private int limit = 10;
    public int getLimit() { return limit; }
    public void setLimit(int limit) { this.limit = limit; }
}
