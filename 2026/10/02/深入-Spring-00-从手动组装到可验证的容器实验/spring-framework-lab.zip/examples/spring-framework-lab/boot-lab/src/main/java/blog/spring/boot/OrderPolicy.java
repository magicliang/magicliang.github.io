package blog.spring.boot;

public record OrderPolicy(String source, int limit) { }
