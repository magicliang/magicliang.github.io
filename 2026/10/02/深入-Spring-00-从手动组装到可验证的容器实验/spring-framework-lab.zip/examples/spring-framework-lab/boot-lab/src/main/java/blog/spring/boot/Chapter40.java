package blog.spring.boot;

import java.net.URI;
import java.net.http.*;
import java.sql.*;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import io.micrometer.observation.*;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.event.ApplicationFailedEvent;
import org.springframework.boot.context.metrics.buffering.BufferingApplicationStartup;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.*;
import org.springframework.web.bind.annotation.*;
import static blog.spring.boot.Support.*;

public class Chapter40 {
    public static final String JDBC = System.getProperty("spring.lab.jdbc.url",
            "jdbc:postgresql://127.0.0.1:55432/spring_lab?connectTimeout=3&socketTimeout=5");
    public static final String USER = System.getProperty("spring.lab.jdbc.user", "spring_lab");
    static final List<String> events = new CopyOnWriteArrayList<>();
    static final AtomicInteger observationStops = new AtomicInteger();
    public static class OrderContext extends Observation.Context { }
    public static void event(String id, String text) {
        String message = "EVENT id=" + id + " ns=" + System.nanoTime() + " thread=" + Thread.currentThread().getName() + " " + text;
        events.add(message); System.out.println(message);
    }
    @Configuration(proxyBeanMethods = false) @EnableAutoConfiguration
    @Import(Endpoint.class)
    public static class App {
        @Bean(destroyMethod = "close") HikariDataSource pool() {
            var config = new HikariConfig(); config.setJdbcUrl(JDBC); config.setUsername(USER); config.setPassword("");
            config.setPoolName("chapter40"); config.setMaximumPoolSize(1); config.setMinimumIdle(0);
            config.setConnectionTimeout(300); return new HikariDataSource(config);
        }
        @Bean ObservationHandler<Observation.Context> evidenceHandler() {
            return new ObservationHandler<>() {
                public boolean supportsContext(Observation.Context context) { return context instanceof OrderContext; }
                public void onStart(Observation.Context context) { event("synthetic-40", "observation.start"); }
                public void onStop(Observation.Context context) { observationStops.incrementAndGet(); event("synthetic-40", "observation.stop error=" + context.getError()); }
            };
        }
    }
    @Configuration(proxyBeanMethods = false)
    public static class Broken {
        @Bean String broken() { throw new IllegalStateException("synthetic-boot-failure-40"); }
    }
    @RestController
    public static class Endpoint {
        private final HikariDataSource pool;
        private final ObservationRegistry observations;
        public Endpoint(HikariDataSource pool, ObservationRegistry observations) { this.pool = pool; this.observations = observations; }
        @GetMapping("/evidence")
        public String evidence() throws Exception {
            String id = "synthetic-40";
            var observation = Observation.createNotStarted("lab.order", OrderContext::new, observations)
                    .lowCardinalityKeyValue("operation", "synthetic").start();
            try (var scope = observation.openScope(); var connection = pool.getConnection()) {
                connection.setAutoCommit(false);
                int pid;
                try (var statement = connection.createStatement(); var result = statement.executeQuery("select pg_backend_pid()")) { result.next(); pid = result.getInt(1); }
                event(id, "connection.acquired backend=" + pid + " active=" + pool.getHikariPoolMXBean().getActiveConnections());
                try (var statement = connection.createStatement()) {
                    statement.executeUpdate("insert into spring_ch40_orders values (40, 'synthetic')");
                }
                try (var observer = DriverManager.getConnection(JDBC, USER, "");
                        var workers = Executors.newFixedThreadPool(2)) {
                    var query = workers.submit(() -> {
                        event(id, "sql.start backend=" + pid + " sql=select pg_sleep(0.3) /* synthetic-40 */");
                        try (var statement = connection.createStatement()) { statement.execute("select pg_sleep(0.3) /* synthetic-40 */"); }
                        event(id, "sql.end backend=" + pid); return true;
                    });
                    boolean observed = false;
                    long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(3);
                    while (System.nanoTime() < deadline) {
                        try (var statement = observer.prepareStatement("select wait_event_type, wait_event, query from pg_stat_activity where pid=?")) {
                            statement.setInt(1, pid);
                            try (var result = statement.executeQuery()) {
                                if (result.next() && "PgSleep".equals(result.getString(2))) {
                                    event(id, "server.wait backend=" + pid + " type=" + result.getString(1) + " event=" + result.getString(2) + " sql=" + result.getString(3));
                                    observed = true; break;
                                }
                            }
                        }
                        Thread.sleep(5);
                    }
                    check(observed, "independent session sees correlated PostgreSQL PgSleep");
                    check(query.get(5, TimeUnit.SECONDS), "slow SQL completes");
                    long waitStart = System.nanoTime();
                    var waiting = workers.submit(() -> {
                        try (var unused = pool.getConnection()) { return false; }
                        catch (SQLTransientConnectionException expected) { event(id, "pool.timeout " + expected.getClass().getSimpleName()); return true; }
                    });
                    deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(2);
                    while (pool.getHikariPoolMXBean().getThreadsAwaitingConnection() == 0 && !waiting.isDone() && System.nanoTime() < deadline) Thread.sleep(2);
                    check(pool.getHikariPoolMXBean().getThreadsAwaitingConnection() == 1, "pool wait visible while sole connection held");
                    event(id, "pool.wait active=1 waiting=1");
                    check(waiting.get(3, TimeUnit.SECONDS), "bounded pool wait times out");
                    event(id, "pool.wait.duration.ns=" + (System.nanoTime() - waitStart));
                }
                var executor = new ThreadPoolExecutor(1, 1, 0, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(1));
                var entered = new CountDownLatch(1); var release = new CountDownLatch(1);
                try {
                    executor.execute(() -> { entered.countDown(); try { release.await(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } });
                    check(entered.await(2, TimeUnit.SECONDS), "executor first task running");
                    executor.execute(() -> event(id, "queued.task.completed"));
                    try { executor.execute(() -> { }); throw new AssertionError("must reject"); }
                    catch (RejectedExecutionException expected) { event(id, "executor.rejected active=" + executor.getActiveCount() + " queued=" + executor.getQueue().size()); }
                } finally {
                    release.countDown(); executor.shutdown();
                    check(executor.awaitTermination(3, TimeUnit.SECONDS), "executor terminates and queued task drains");
                }
                connection.rollback(); event(id, "transaction.rollback backend=" + pid);
                check(pool.getHikariPoolMXBean().getThreadsAwaitingConnection() == 0, "no remaining connection waiters");
                return "synthetic-40:rolled-back";
            } catch (Exception failure) { observation.error(failure); throw failure; }
            finally { observation.stop(); }
        }
    }
    public static void main(String[] args) throws Exception {
        var failed = new AtomicInteger(); var broken = application(Broken.class);
        broken.addListeners((ApplicationListener<ApplicationFailedEvent>) event -> {
            failed.incrementAndGet(); Chapter40.event("startup-40", "startup.failed " + event.getException().getClass().getSimpleName());
        });
        try { broken.run(); throw new AssertionError("startup must fail"); }
        catch (org.springframework.beans.BeansException expected) { check(expected.getMessage().contains("broken"), "startup failure identifies bean"); }
        check(failed.get() == 1, "ApplicationFailedEvent observed once");
        try (var connection = DriverManager.getConnection(JDBC, USER, ""); var statement = connection.createStatement()) {
            statement.execute("create table if not exists spring_ch40_orders (id int primary key, value text)");
            statement.execute("delete from spring_ch40_orders where id=40");
        }
        var startup = new BufferingApplicationStartup(2048);
        var app = application(App.class); app.setWebApplicationType(WebApplicationType.SERVLET); app.setApplicationStartup(startup);
        HikariDataSource pool; int port;
        try (var context = app.run("--server.address=127.0.0.1", "--server.port=0", "--management.endpoints.web.exposure.include=health,metrics")) {
            port = ((ServletWebServerApplicationContext) context).getWebServer().getPort(); pool = context.getBean(HikariDataSource.class);
            try (var client = HttpClient.newHttpClient()) {
                var response = client.send(HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + "/evidence")).timeout(Duration.ofSeconds(15)).build(), HttpResponse.BodyHandlers.ofString());
                check(response.statusCode() == 200 && response.body().equals("synthetic-40:rolled-back"), "real Boot Tomcat HTTP request completes");
                var metrics = client.send(HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + "/actuator/metrics/http.server.requests")).build(), HttpResponse.BodyHandlers.ofString());
                check(metrics.statusCode() == 200 && metrics.body().contains("http.server.requests"), "Actuator exposes completed HTTP observation metric");
                System.out.println("METRICS " + metrics.body());
            }
            check(observationStops.get() == 1, "custom ObservationHandler receives one completed order observation");
            check(pool.getHikariPoolMXBean().getActiveConnections() == 0, "request returns connection to pool");
            check(startup.getBufferedTimeline().getEvents().stream().anyMatch(e -> e.getStartupStep().getName().equals("spring.beans.instantiate")), "startup timeline contains bean instantiation steps");
            System.out.println("STARTUP events=" + startup.getBufferedTimeline().getEvents().size());
            try (var observer = DriverManager.getConnection(JDBC, USER, ""); var statement = observer.createStatement(); var result = statement.executeQuery("select count(*) from spring_ch40_orders where id=40")) {
                result.next(); check(result.getInt(1) == 0, "independent business read proves rollback despite HTTP 200");
            }
        }
        check(pool.isClosed(), "context close shuts Hikari pool");
        try (var client = HttpClient.newHttpClient()) {
            try { client.send(HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + "/evidence")).timeout(Duration.ofSeconds(2)).build(), HttpResponse.BodyHandlers.ofString()); throw new AssertionError("port must close"); }
            catch (java.io.IOException expected) { check(true, "HTTP port closed after context shutdown"); }
        }
        System.out.println("CHAPTER 40 PASS");
    }
}
