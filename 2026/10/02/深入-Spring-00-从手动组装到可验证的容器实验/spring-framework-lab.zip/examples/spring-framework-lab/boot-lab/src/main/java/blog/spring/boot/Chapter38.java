package blog.spring.boot;

import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.FilteredClassLoader;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import static blog.spring.boot.Support.*;

public class Chapter38 {
    @Configuration(proxyBeanMethods = false)
    @EnableAutoConfiguration
    public static class App { }
    @Configuration(proxyBeanMethods = false)
    public static class User {
        @Bean OrderPolicy customPolicy() { return new OrderPolicy("user", 99); }
    }
    public static void main(String[] args) {
        try (var plain = new AnnotationConfigApplicationContext(User.class)) {
            check(plain.getBean(OrderPolicy.class).source().equals("user"), "plain Framework creates explicit user bean");
            check(!plain.containsBean("orderPolicy"), "plain context does not discover Boot imports by itself");
        }
        try (var context = application(App.class).run("--spring.config.name=lab-boot")) {
            check(context.getBean(OrderPolicy.class).limit() == 30, "config data overrides default properties");
            check(!((org.springframework.beans.factory.support.DefaultListableBeanFactory) context.getBeanFactory()).isAllowCircularReferences(), "Boot disallows circular references by default");
            check(!((org.springframework.beans.factory.support.DefaultListableBeanFactory) context.getBeanFactory()).isAllowBeanDefinitionOverriding(), "Boot disallows bean overriding by default");
            report(context);
        }
        try (var context = application(App.class).run("--spring.config.name=lab-boot", "--lab.order.limit=40")) {
            check(context.getBean(OrderPolicy.class).limit() == 40, "command line overrides config data");
            check(context.getEnvironment().getPropertySources().get("commandLineArgs").containsProperty("lab.order.limit"), "winning property source recorded");
            check(context.getBean(OrderProperties.class).getLimit() == 40, "configuration properties bound through Boot infrastructure");
        }
        try (var context = application(App.class, User.class).run()) {
            check(context.getBeansOfType(OrderPolicy.class).size() == 1, "user policy causes type based backoff");
            check(context.getBean(OrderPolicy.class).source().equals("user"), "user policy retained");
            check(!context.containsBean("orderPolicy"), "default definition absent rather than overwritten");
            report(context);
        }
        new ApplicationContextRunner().withConfiguration(AutoConfigurations.of(OrderAutoConfiguration.class))
                .withClassLoader(new FilteredClassLoader("org.postgresql"))
                .run(context -> {
                    check(context.getStartupFailure() == null, "missing optional driver does not fail startup");
                    check(context.getBeansOfType(OrderPolicy.class).isEmpty(), "missing class disables auto configuration");
                    report(context.getSourceApplicationContext());
                });
        try (var context = application(App.class).run("--lab.order.enabled=false")) {
            check(context.getBeansOfType(OrderPolicy.class).isEmpty(), "property condition disables policy");
            report(context);
        }
        System.out.println("CHAPTER 38 PASS");
    }
}
