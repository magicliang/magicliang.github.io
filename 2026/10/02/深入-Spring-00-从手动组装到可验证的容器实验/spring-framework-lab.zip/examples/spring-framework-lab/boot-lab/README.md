# Boot 3.5.6 独立实验

JDK 21；根 Maven wrapper 3.9.9。使用 Boot starter-parent 3.5.6 原生 BOM，不覆盖 Framework 版本。

从 `examples/spring-framework-lab` 执行：

```bash
sh boot-lab/run.sh 38 39 40
./mvnw -f boot-lab/pom.xml -B dependency:tree
```

38/39 不需要数据库；40 需要 `db/README.md` 的 PostgreSQL，默认 `jdbc:postgresql://127.0.0.1:55432/spring_lab?connectTimeout=3&socketTimeout=5`，用户 spring_lab，空密码、合成数据。40 启动随机 loopback HTTP 端口并自行关闭上下文、池、执行器、HTTP 客户端。共享数据库服务器不关闭。仅清理专用表 `spring_ch40_orders` 的 id=40；不要并发执行两份40。

实际依赖：Framework 6.2.11、Tomcat10.1.46、Micrometer1.15.4、HikariCP6.3.3、pgJDBC42.7.7。完整树在 `../evidence/38/local-20261002/dependencies.txt`。

| 入口 | 场景 | 二值成功观察 |
| --- | --- | --- |
| `blog.spring.boot.Chapter38` | 原生容器对照；config data/CLI；backoff；FilteredClassLoader；property condition | 14 PASS、CHAPTER 38 PASS、exit0 |
| `blog.spring.boot.Chapter39` | 普通 Bean；组合注解、Selector、Registrar；重复/冲突/缺类；真实 imports 发现 | 10 PASS、CHAPTER 39 PASS、exit0 |
| `blog.spring.boot.Chapter40` | 启动失败；真实 HTTP；PG等待；池等待；拒绝；Observation/Actuator；rollback/资源关闭 | 17 PASS、CHAPTER 40 PASS、exit0 |

原始证据位于 `../evidence/38..40/local-20261002/`。故障注入的堆栈与 WARN 属于成功负例。`FilteredClassLoader` 模拟类不可见，并非移除磁盘 jar。没有 tracing bridge/collector，没有声明分布式 trace 已导出。上游测试为阅读，未运行。

## 后续复用边界

- `Chapter38.App`：不带组件扫描的 `@EnableAutoConfiguration` 配置，适合41测试上下文和42AOT另建入口。
- `OrderPolicy`、`OrderProperties`、`OrderAutoConfiguration`：真实 imports 资源与条件化默认组件，可直接导入或在独立测试上下文中验证。
- `Support.application(sources)`：显式 NONE、无shutdown hook、DataSourceAutoConfiguration exclusion；调用方可调整 WebApplicationType。
- `Chapter40.App`：完整 Servlet/Actuator/专用 Hikari Bean；只在需要真实资源时使用。

不要使用包扫描加载全部 Chapter 嵌套配置，其中包含预期启动失败的 `Broken`。41–43 若新增依赖、main class 或插件，请使用自己的模块/POM，避免把实验辅助配置误装成业务应用。根 wrapper 内部切换目录，调用必须带 `-f boot-lab/pom.xml`。
