#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ "$#" -eq 0 ]; then set -- 38 39 40; fi
for chapter in "$@"; do
  case "$chapter" in 38|39|40) ;; *) exit 2 ;; esac
  output="../evidence/$chapter/local-20261002"
  mkdir -p "$output"
  if ../mvnw -f boot-lab/pom.xml -B -q compile exec:java -Dexec.mainClass="blog.spring.boot.Chapter$chapter" > "$output/run.txt" 2>&1; then
    printf '0\n' > "$output/exit-code.txt"
  else
    result=$?
    printf '%s\n' "$result" > "$output/exit-code.txt"
    cat "$output/run.txt"
    exit "$result"
  fi
  cat "$output/run.txt"
done
