# Spring 24 ORM 独立实验

从上级 spring-framework-lab 目录运行：

```bash
export JAVA_HOME="$HOME/.sdkman/candidates/java/21.0.11-amzn"
./mvnw -f orm-lab/pom.xml compile exec:java -Dexec.mainClass=blog.spring.orm.Chapter24Orm
```

JDK 21；Spring 6.2.11；Hibernate ORM 6.6.15.Final；Jakarta Persistence 3.1.0；pgJDBC 42.7.7。实际依赖树见 ../evidence/24/orm-dependencies.txt。

需要本地 PostgreSQL 18.0 实验库，默认 jdbc:postgresql://127.0.0.1:55432/spring_lab，用户 spring_lab，空密码。通过 JVM 属性 spring.lab.jdbc.url / spring.lab.jdbc.user 修改。只允许连接专用实验库。

实体只映射 spring_ch24_orm，hibernate.hbm2ddl.auto=create-drop 会在启动时重建、关闭时删除该表。不影响其他章节表，不与另一轮本实验并行运行。

7 条断言覆盖：flush 的事务内可见性、独立连接不可见、提交后可见、flush 后回滚、提交脏检查、只读 MANUAL/defaultReadOnly、只读实体修改不自动保存。全部使用 PostgreSQL，没有 H2 替代。主程序或断言异常导致 Maven 非零退出。
