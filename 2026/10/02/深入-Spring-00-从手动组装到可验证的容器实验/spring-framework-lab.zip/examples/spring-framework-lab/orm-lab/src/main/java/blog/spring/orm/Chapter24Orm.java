package blog.spring.orm;

import jakarta.persistence.*;
import java.sql.*;
import java.util.Properties;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.*;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.support.TransactionTemplate;

public class Chapter24Orm {
    @Entity @Table(name = "spring_ch24_orm")
    public static class Entry {
        @Id private Integer id;
        private String name;
        public Entry() {}
        Entry(int id, String name) { this.id = id; this.name = name; }
    }
    static String url = System.getProperty("spring.lab.jdbc.url", "jdbc:postgresql://127.0.0.1:55432/spring_lab");
    static String user = System.getProperty("spring.lab.jdbc.user", "spring_lab");
    static void check(boolean result, String name) { if (!result) throw new AssertionError(name); System.out.println("CHECK PASS " + name); }
    static long count(int id) {
        try (var connection = DriverManager.getConnection(url, user, ""); var statement = connection.createStatement();
             var rows = statement.executeQuery("select count(*) from spring_ch24_orm where id=" + id)) {
            rows.next(); long count = rows.getLong(1); System.out.println("OBSERVER id=" + id + " count=" + count); return count;
        } catch (SQLException failure) { throw new IllegalStateException(failure); }
    }
    public static void main(String[] args) {
        System.out.println("ENV Java=" + System.getProperty("java.version") + " Spring=" + org.springframework.core.SpringVersion.getVersion() + " Hibernate=" + org.hibernate.Version.getVersionString());
        var factory = new LocalContainerEntityManagerFactoryBean();
        factory.setDataSource(new DriverManagerDataSource(url, user, ""));
        factory.setPackagesToScan("blog.spring.orm");
        factory.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
        var properties = new Properties(); properties.setProperty("hibernate.hbm2ddl.auto", "create-drop");
        properties.setProperty("hibernate.show_sql", "true"); factory.setJpaProperties(properties);
        factory.afterPropertiesSet();
        try {
            var emf = factory.getObject(); var manager = new JpaTransactionManager(emf);
            var tx = new TransactionTemplate(manager);
            var em = SharedEntityManagerCreator.createSharedEntityManager(emf);
            tx.executeWithoutResult(status -> {
                System.out.println("CONNECTION pid=" + em.createNativeQuery("select pg_backend_pid()").getSingleResult() + " thread=" + Thread.currentThread().getName());
                em.persist(new Entry(1, "commit"));
                em.flush();
                check(((Number) em.createNativeQuery("select count(*) from spring_ch24_orm where id=1").getSingleResult()).longValue() == 1, "flush SQL visible inside transaction");
                check(count(1) == 0, "flush is not commit: independent connection sees nothing");
            });
            check(count(1) == 1, "JpaTransactionManager commit visible independently");
            tx.executeWithoutResult(status -> { em.persist(new Entry(2, "rollback")); em.flush(); status.setRollbackOnly(); });
            check(count(2) == 0, "flushed insert rolled back");
            tx.executeWithoutResult(status -> { Entry entry = em.find(Entry.class, 1); entry.name = "dirty"; });
            try (var connection = DriverManager.getConnection(url, user, ""); var statement = connection.createStatement(); var rows = statement.executeQuery("select name from spring_ch24_orm where id=1")) {
                rows.next(); check("dirty".equals(rows.getString(1)), "commit dirty checking flushes changed managed entity");
            } catch (SQLException failure) { throw new IllegalStateException(failure); }
            var readOnly = new TransactionTemplate(manager); readOnly.setReadOnly(true);
            readOnly.executeWithoutResult(status -> {
                var session = em.unwrap(org.hibernate.Session.class);
                check(session.getHibernateFlushMode() == org.hibernate.FlushMode.MANUAL && session.isDefaultReadOnly(), "Hibernate readOnly transaction uses MANUAL flush and readOnly entity default");
                Entry entry = em.find(Entry.class, 1); entry.name = "ignored-change";
            });
            try (var connection = DriverManager.getConnection(url, user, ""); var statement = connection.createStatement(); var rows = statement.executeQuery("select name from spring_ch24_orm where id=1")) {
                rows.next(); check("dirty".equals(rows.getString(1)), "readOnly managed entity mutation is not automatically persisted");
            } catch (SQLException failure) { throw new IllegalStateException(failure); }
        } finally { factory.destroy(); }
    }
}
