package blog.spring.reactive;

import java.net.URI;
import java.net.http.*;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import org.apache.catalina.startup.Tomcat;
import org.reactivestreams.Subscription;
import org.springframework.context.annotation.*;
import org.springframework.http.server.reactive.ReactorHttpHandlerAdapter;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.reactive.config.EnableWebFlux;
import org.springframework.web.server.adapter.WebHttpHandlerBuilder;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import reactor.core.publisher.*;
import reactor.core.scheduler.Schedulers;
import reactor.netty.http.server.HttpServer;
import reactor.netty.resources.LoopResources;
import static blog.spring.reactive.Support.*;

public class Chapter35 {
    static final AtomicInteger subscriptions = new AtomicInteger();
    static final AtomicLong demand = new AtomicLong();
    static final AtomicReference<String> sourceThread = new AtomicReference<>();
    static final AtomicReference<Thread> blockedThread = new AtomicReference<>();
    static final CountDownLatch entered = new CountDownLatch(1), release = new CountDownLatch(1);
    static String order() { return "order=7,total=25.00"; }
    @Configuration @EnableWebFlux
    public static class FluxConfig { @Bean FluxApi api() { return new FluxApi(); } }
    @RestController
    public static class FluxApi {
        @GetMapping("/order") public Mono<String> get() {
            return Mono.defer(() -> { subscriptions.incrementAndGet(); sourceThread.set(Thread.currentThread().getName()); trace("subscribe-order"); return Mono.just(order()); })
                    .doOnRequest(n -> { demand.set(n); trace("http-demand=" + n); });
        }
        @GetMapping("/block") public Mono<String> bad() {
            return Mono.fromCallable(() -> { blockedThread.set(Thread.currentThread()); trace("blocking-enter"); entered.countDown(); await(release); return order(); });
        }
        @GetMapping("/offload") public Mono<String> offload() {
            return Mono.fromCallable(() -> { sourceThread.set(Thread.currentThread().getName()); trace("offloaded-callable"); return order(); }).subscribeOn(Schedulers.boundedElastic());
        }
    }
    @Configuration @EnableWebMvc
    public static class MvcConfig { @Bean MvcApi api() { return new MvcApi(); } }
    @RestController
    public static class MvcApi { @GetMapping("/order") public String get() { trace("mvc-handler"); return order(); } }
    static String get(HttpClient client, String base, String path) throws Exception {
        var response = client.send(HttpRequest.newBuilder(URI.create(base + path)).timeout(LIMIT).GET().build(), HttpResponse.BodyHandlers.ofString());
        check(response.statusCode() == 200, "HTTP " + path + " status=200");
        return response.body();
    }
    public static void main(String[] args) throws Exception {
        var received = new ArrayList<Integer>();
        var requests = new ArrayList<Long>();
        var subscriber = new BaseSubscriber<Integer>() { @Override protected void hookOnSubscribe(Subscription s) { trace("manual-subscribe-no-request"); } @Override protected void hookOnNext(Integer value) { received.add(value); } };
        Flux.range(1, 3).doOnRequest(requests::add).subscribe(subscriber);
        check(received.isEmpty(), "subscription alone emits no values without demand");
        subscriber.request(1); check(received.equals(java.util.List.of(1)), "request(1) yields one value");
        subscriber.request(2); check(received.equals(java.util.List.of(1, 2, 3)) && requests.equals(java.util.List.of(1L, 2L)), "request(2) consumes remaining two");
        var loops = LoopResources.create("spring35", 1, true);
        var fluxContext = new AnnotationConfigApplicationContext(FluxConfig.class);
        var server = HttpServer.create().host("127.0.0.1").port(0).runOn(loops, false).handle(new ReactorHttpHandlerAdapter(WebHttpHandlerBuilder.applicationContext(fluxContext).build())).bindNow(LIMIT);
        var tomcat = new Tomcat();
        tomcat.setBaseDir(Files.createTempDirectory("spring35-tomcat-").toString()); tomcat.setPort(0); tomcat.getConnector().setProperty("address", "127.0.0.1");
        var context = tomcat.addContext("", Files.createTempDirectory("spring35-doc-").toString());
        var mvc = new AnnotationConfigWebApplicationContext(); mvc.register(MvcConfig.class);
        var wrapper = Tomcat.addServlet(context, "mvc", new DispatcherServlet(mvc)); wrapper.setLoadOnStartup(1); wrapper.setAsyncSupported(true); context.addServletMappingDecoded("/", "mvc");
        try (var client = HttpClient.newHttpClient()) {
            tomcat.start();
            String fluxBase = "http://127.0.0.1:" + server.port(), mvcBase = "http://127.0.0.1:" + tomcat.getConnector().getLocalPort();
            check(subscriptions.get() == 0, "constructing server does not subscribe to business publisher");
            var reactive = get(client, fluxBase, "/order"); var imperative = get(client, mvcBase, "/order");
            check(reactive.equals(imperative) && reactive.equals(order()), "MVC and WebFlux return identical business data");
            check(subscriptions.get() == 1 && demand.get() > 0, "HTTP response writer subscribes and requests");
            check(sourceThread.get().startsWith("spring35"), "unscheduled source runs on server event loop");
            var blocked = client.sendAsync(HttpRequest.newBuilder(URI.create(fluxBase + "/block")).timeout(LIMIT).GET().build(), HttpResponse.BodyHandlers.ofString());
            await(entered);
            var marker = new CompletableFuture<Void>();
            loops.onServer(false).next().execute(() -> marker.complete(null));
            check(!marker.isDone() && !blocked.isDone(), "blocking source occupies sole event loop before latch release");
            check(blockedThread.get().getName().startsWith("spring35"), "blocking call executes on event loop");
            release.countDown();
            check(blocked.get(10, TimeUnit.SECONDS).body().equals(order()), "released blocking response completes");
            marker.get(10, TimeUnit.SECONDS); check(marker.isDone(), "event loop processes queued task after release");
            check(get(client, fluxBase, "/offload").equals(order()) && sourceThread.get().startsWith("boundedElastic"), "subscribeOn moves callable to boundedElastic");
        } finally {
            release.countDown(); tomcat.stop(); tomcat.destroy(); mvc.close(); server.disposeNow(LIMIT); fluxContext.close(); loops.disposeLater().block(LIMIT); Schedulers.shutdownNow();
        }
        check(server.isDisposed() && loops.isDisposed() && !fluxContext.isActive(), "servers event loops and context closed");
        done(35);
    }
}
