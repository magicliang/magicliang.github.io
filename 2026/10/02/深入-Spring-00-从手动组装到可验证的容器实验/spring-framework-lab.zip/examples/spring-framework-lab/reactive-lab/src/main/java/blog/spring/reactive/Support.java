package blog.spring.reactive;

import java.time.Duration;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

final class Support {
    static final Duration LIMIT = Duration.ofSeconds(10);
    static int checks;
    static void check(boolean condition, String name) {
        if (!condition) throw new AssertionError(name);
        checks++;
        System.out.println("CHECK PASS " + name);
    }
    static void await(CountDownLatch latch) {
        try { if (!latch.await(10, TimeUnit.SECONDS)) throw new AssertionError("barrier deadline"); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IllegalStateException(e); }
    }
    static void trace(String event) { System.out.println("TRACE " + event + " thread=" + Thread.currentThread().getName()); }
    static void done(int chapter) { System.out.println("SUMMARY chapter=" + chapter + " checks=" + checks); }
}
