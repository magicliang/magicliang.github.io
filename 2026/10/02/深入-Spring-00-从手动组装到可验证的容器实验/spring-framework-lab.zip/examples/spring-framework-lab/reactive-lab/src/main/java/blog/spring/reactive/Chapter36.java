package blog.spring.reactive;

import io.r2dbc.pool.*;
import io.r2dbc.spi.ConnectionFactories;
import java.sql.DriverManager;
import java.time.Duration;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.r2dbc.connection.R2dbcTransactionManager;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.transaction.reactive.TransactionSynchronizationManager;
import org.springframework.transaction.reactive.TransactionalOperator;
import org.springframework.transaction.TransactionExecution;
import org.springframework.transaction.TransactionExecutionListener;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import static blog.spring.reactive.Support.*;

public class Chapter36 {
    static final String TABLE = "spring_ch36_orders";
    static int count(String key) throws Exception {
        try (var connection = DriverManager.getConnection(System.getProperty("spring.lab.jdbc.url", "jdbc:postgresql://127.0.0.1:55432/spring_lab"), "spring_lab", "");
             var statement = connection.prepareStatement("select count(*) from " + TABLE + " where business_key=?")) {
            statement.setString(1, key); try (var result = statement.executeQuery()) { result.next(); return result.getInt(1); }
        }
    }
    static Mono<Long> insert(DatabaseClient db, String key) { return db.sql("insert into " + TABLE + " (business_key) values (:key)").bind("key", key).fetch().rowsUpdated(); }
    static void available(ConnectionPool pool, DatabaseClient db, String scenario) {
        check(Integer.valueOf(1).equals(db.sql("select 1 as n").map((row, metadata) -> row.get("n", Integer.class)).one().block(LIMIT)), scenario + " maxSize=1 pool serves next query");
        var metrics = pool.getMetrics().orElseThrow();
        check(metrics.acquiredSize() == 0 && metrics.pendingAcquireSize() == 0, scenario + " acquired=0 pending=0");
    }
    public static void main(String[] args) throws Exception {
        var factory = ConnectionFactories.get(System.getProperty("spring.lab.r2dbc.url", "r2dbc:postgresql://spring_lab@127.0.0.1:55432/spring_lab"));
        var pool = new ConnectionPool(ConnectionPoolConfiguration.builder(factory).initialSize(0).maxSize(1).maxAcquireTime(Duration.ofSeconds(5)).build());
        var db = DatabaseClient.create(pool);
        var manager = new R2dbcTransactionManager(pool);
        var commits = new AtomicInteger(); var rollbacks = new AtomicInteger();
        manager.addListener(new TransactionExecutionListener() {
            @Override public void afterBegin(TransactionExecution transaction, Throwable failure) { trace("manager-afterBegin failure=" + failure); }
            @Override public void afterCommit(TransactionExecution transaction, Throwable failure) { if (failure == null) commits.incrementAndGet(); trace("manager-afterCommit failure=" + failure); }
            @Override public void afterRollback(TransactionExecution transaction, Throwable failure) { if (failure == null) rollbacks.incrementAndGet(); trace("manager-afterRollback failure=" + failure); }
        });
        var tx = TransactionalOperator.create(manager);
        try {
            db.sql("create table if not exists " + TABLE + " (id bigint generated always as identity primary key, business_key text not null)").then().block(LIMIT);
            db.sql("truncate " + TABLE).then().block(LIMIT);
            var starts = new AtomicInteger();
            Mono<Long> cold = Mono.defer(() -> { starts.incrementAndGet(); trace("business-subscription"); return insert(db, "success"); }).as(tx::transactional);
            check(starts.get() == 0 && count("success") == 0, "publisher construction starts no transaction or SQL");
            check(Long.valueOf(1).equals(cold.block(LIMIT)) && count("success") == 1, "onComplete commits visible row");
            available(pool, db, "success");
            var beforeSwitch = new java.util.concurrent.atomic.AtomicReference<String>();
            String context = tx.transactional(TransactionSynchronizationManager.forCurrentTransaction().flatMap(synchronizations -> {
                beforeSwitch.set(Thread.currentThread().getName());
                check(synchronizations.isActualTransactionActive(), "reactive transaction context is active before scheduler switch");
                return Mono.just("hop").publishOn(Schedulers.boundedElastic()).flatMap(ignored -> TransactionSynchronizationManager.forCurrentTransaction())
                        .map(after -> { check(after.isActualTransactionActive(), "transaction context survives publishOn"); check(!beforeSwitch.get().equals(Thread.currentThread().getName()), "publishOn actually changed thread"); return "context-ok"; });
            })).block(LIMIT);
            check("context-ok".equals(context), "context probe completes");
            boolean error = false;
            try { tx.transactional(insert(db, "error").then(Mono.error(new IllegalStateException("business-error")))).block(LIMIT); }
            catch (IllegalStateException expected) { error = "business-error".equals(expected.getMessage()); }
            check(error && count("error") == 0, "onError rolls back insert and preserves business error");
            available(pool, db, "error");
            var inserted = new CountDownLatch(1);
            var cancellation = new CountDownLatch(1);
            var subscription = tx.transactional(db.sql("select pg_backend_pid() as pid").map((row, metadata) -> row.get("pid", Integer.class)).one().doOnNext(pid -> trace("cancel-connection backend-pid=" + pid))
                    .then(insert(db, "cancel")).then(Mono.defer(() -> { trace("insert-completed-awaiting-cancel"); inserted.countDown(); return Mono.<Void>never().doOnCancel(cancellation::countDown); })))
                    .subscribe(null, failure -> { failure.printStackTrace(); });
            await(inserted);
            check(count("cancel") == 0 && pool.getMetrics().orElseThrow().acquiredSize() == 1, "cancel window: insert done uncommitted and sole connection leased");
            subscription.dispose(); await(cancellation);
            available(pool, db, "cancel");
            check(count("cancel") == 0, "cancellation before completion rolls back database row");
            cold.block(LIMIT);
            check(starts.get() == 2 && count("success") == 2, "resubscription reexecutes transaction and duplicates business row");
            available(pool, db, "resubscribe");
            db.sql("create table if not exists spring_ch36_idempotent (business_key text primary key)").then().block(LIMIT);
            db.sql("truncate spring_ch36_idempotent").then().block(LIMIT);
            var idempotent = db.sql("insert into spring_ch36_idempotent values ('order-7') on conflict do nothing").fetch().rowsUpdated().as(tx::transactional);
            check(Long.valueOf(1).equals(idempotent.block(LIMIT)) && Long.valueOf(0).equals(idempotent.block(LIMIT)), "unique business key makes second subscription a no-op");
            available(pool, db, "idempotent");
            check(commits.get() == 5 && rollbacks.get() == 2, "manager observes five commits and two rollbacks");
        } finally { pool.disposeLater().block(LIMIT); Schedulers.shutdownNow(); }
        check(pool.isDisposed(), "R2DBC pool disposed");
        done(36);
    }
}
