#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

module = Path(__file__).resolve().parent
lab = module.parent
chapters = sys.argv[1:] or ["35", "36", "37"]
if any(chapter not in {"35", "36", "37"} for chapter in chapters):
    raise SystemExit("chapters must be 35, 36, or 37")
java = Path(os.environ["JAVA_HOME"]) / "bin/java"
classpath = str(module / "target/classes") + os.pathsep + (module / "target/classpath.txt").read_text().strip()
sources = {str(path.relative_to(module)): hashlib.sha256(path.read_bytes()).hexdigest()
           for path in sorted(module.rglob("*.java"))}
sources["pom.xml"] = hashlib.sha256((module / "pom.xml").read_bytes()).hexdigest()
for chapter in chapters:
    evidence = lab / "evidence" / chapter / "local-20261002"
    evidence.mkdir(parents=True, exist_ok=True)
    command = [str(java), "-cp", classpath, "blog.spring.reactive.Chapter" + chapter]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=90)
    (evidence / "run.txt").write_text(result.stdout)
    (evidence / "exit-code.txt").write_text(str(result.returncode) + "\n")
    checks = result.stdout.count("CHECK PASS ")
    (evidence / "manifest.json").write_text(json.dumps({"command": command, "exit": result.returncode, "checks": checks, "sources": sources, "java": subprocess.run([str(java), "-version"], capture_output=True, text=True).stderr}, indent=2) + "\n")
    print(f"chapter={chapter} exit={result.returncode} checks={checks} log={evidence / 'run.txt'}")
    if result.returncode:
        print(result.stdout[-8000:])
        raise SystemExit(result.returncode)
