package blog.spring.reactive;

import io.netty.channel.ChannelOption;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import java.net.*;
import java.net.http.HttpClient;
import java.time.Duration;
import java.util.Set;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.support.RestClientAdapter;
import org.springframework.web.reactive.function.client.*;
import org.springframework.web.reactive.function.client.support.WebClientAdapter;
import org.springframework.web.service.annotation.GetExchange;
import org.springframework.web.service.invoker.HttpServiceProxyFactory;
import reactor.core.publisher.Mono;
import reactor.netty.http.server.HttpServer;
import reactor.netty.resources.ConnectionProvider;
import reactor.netty.resources.LoopResources;
import static blog.spring.reactive.Support.*;

public class Chapter37 {
    public interface Api { @GetExchange("/ok") String ok(); }
    static final AtomicInteger unsafeCalls = new AtomicInteger(), safeCalls = new AtomicInteger(), writes = new AtomicInteger(), safeWrites = new AtomicInteger();
    static final Set<String> keys = ConcurrentHashMap.newKeySet();
    static final AtomicInteger slowCalls = new AtomicInteger(), disconnects = new AtomicInteger();
    static final AtomicReference<CountDownLatch> slowEntered = new AtomicReference<>(new CountDownLatch(1));
    static final AtomicReference<CountDownLatch> cancelled = new AtomicReference<>(new CountDownLatch(1));
    static boolean fails(Runnable action, String name, Class<? extends Throwable> expectedType) {
        try { action.run(); return false; }
        catch (RuntimeException expected) { trace(name + " failure=" + expected.getClass().getName() + " cause=" + root(expected).getClass().getName()); return expectedType.isInstance(root(expected)); }
    }
    static Throwable root(Throwable error) { while (error.getCause() != null) error = error.getCause(); return error; }
    public static void main(String[] args) throws Exception {
        var loops = LoopResources.create("spring37", 2, true);
        var server = HttpServer.create().host("127.0.0.1").port(0).runOn(loops).route(routes -> routes
                .get("/ok", (request, response) -> response.sendString(Mono.just("ok")))
                .get("/error", (request, response) -> response.status(503).sendString(Mono.just("unavailable")))
                .get("/slow", (request, response) -> { slowCalls.incrementAndGet(); var signal = cancelled.get(); slowEntered.get().countDown(); return response.sendString(Mono.<String>never().doOnCancel(signal::countDown)); })
                .get("/disconnect", (request, response) -> { disconnects.incrementAndGet(); response.withConnection(connection -> connection.dispose()); return Mono.empty(); })
                .post("/unsafe", (request, response) -> { writes.incrementAndGet(); int call = unsafeCalls.incrementAndGet(); return response.status(call == 1 ? 503 : 200).sendString(Mono.just("write=" + writes.get())); })
                .post("/safe", (request, response) -> { String key = request.requestHeaders().get("Idempotency-Key"); if (key == null) return response.status(400).send(); if (keys.add(key)) safeWrites.incrementAndGet(); int call = safeCalls.incrementAndGet(); return response.status(call == 1 ? 503 : 200).sendString(Mono.just("write=" + safeWrites.get())); }))
                .bindNow(LIMIT);
        var pool = ConnectionProvider.builder("spring37-client").maxConnections(1).pendingAcquireTimeout(Duration.ofSeconds(1)).build();
        var nativeClient = reactor.netty.http.client.HttpClient.create(pool).runOn(loops).disableRetry(true)
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 1000).responseTimeout(Duration.ofMillis(250));
        String base = "http://127.0.0.1:" + server.port();
        var web = WebClient.builder().baseUrl(base).clientConnector(new ReactorClientHttpConnector(nativeClient)).build();
        try (var jdk = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(1)).build()) {
            var factory = new JdkClientHttpRequestFactory(jdk); factory.setReadTimeout(Duration.ofMillis(250));
            var rest = RestClient.builder().baseUrl(base).requestFactory(factory).build();
            check("ok".equals(rest.get().uri("/ok").retrieve().body(String.class)), "RestClient consumes real HTTP response");
            check("ok".equals(web.get().uri("/ok").retrieve().bodyToMono(String.class).block(LIMIT)), "WebClient consumes real HTTP response");
            var syncApi = HttpServiceProxyFactory.builderFor(RestClientAdapter.create(rest)).build().createClient(Api.class);
            var reactiveApi = HttpServiceProxyFactory.builderFor(WebClientAdapter.create(web)).build().createClient(Api.class);
            check("ok".equals(syncApi.ok()) && "ok".equals(reactiveApi.ok()), "HTTP interface delegates to both adapters over real HTTP");
            check(fails(() -> rest.get().uri("/error").retrieve().body(String.class), "rest-503", org.springframework.web.client.HttpServerErrorException.ServiceUnavailable.class), "RestClient maps 503 to exception");
            check(fails(() -> web.get().uri("/error").retrieve().bodyToMono(String.class).block(LIMIT), "web-503", WebClientResponseException.ServiceUnavailable.class), "WebClient maps 503 to exception");
            check(fails(() -> rest.get().uri("/slow").retrieve().body(String.class), "rest-response-timeout", java.net.http.HttpTimeoutException.class), "RestClient read timeout bounds absent response");
            check(fails(() -> web.get().uri("/slow").retrieve().bodyToMono(String.class).block(LIMIT), "web-response-timeout", io.netty.handler.timeout.ReadTimeoutException.class), "WebClient response timeout bounds absent response");
            check("ok".equals(web.get().uri("/ok").retrieve().bodyToMono(String.class).block(LIMIT)), "maxConnections=1 recovers after response timeout");
            check(fails(() -> web.get().uri("/disconnect").retrieve().bodyToMono(String.class).block(LIMIT), "disconnect", reactor.netty.http.client.PrematureCloseException.class), "premature disconnect is observed as failure");
            check(disconnects.get() == 1, "disabled transport retry yields exactly one disconnect request");
            check("ok".equals(web.get().uri("/ok").retrieve().bodyToMono(String.class).block(LIMIT)), "pool capacity recovers after disconnect");
            check("write=2".equals(web.post().uri("/unsafe").retrieve().bodyToMono(String.class).retry(1).block(LIMIT)) && unsafeCalls.get() == 2 && writes.get() == 2, "POST retry executes two non-idempotent writes");
            check("write=1".equals(web.post().uri("/safe").header("Idempotency-Key", "order-7").retrieve().bodyToMono(String.class).retry(1).block(LIMIT)) && safeCalls.get() == 2 && safeWrites.get() == 1, "same idempotency key yields two requests one write");
            // Response timeout disabled for the explicit cancellation experiment.
            int beforeCancel = slowCalls.get();
            slowEntered.set(new CountDownLatch(1)); cancelled.set(new CountDownLatch(1));
            var cancelWeb = WebClient.builder().baseUrl(base).clientConnector(new ReactorClientHttpConnector(nativeClient.responseTimeout(null))).build();
            var subscription = cancelWeb.get().uri("/slow").retrieve().bodyToMono(String.class).subscribe(value -> {}, error -> trace("cancel-race=" + error));
            await(slowEntered.get());
            subscription.dispose();
            await(cancelled.get());
            check(subscription.isDisposed(), "caller explicitly cancels subscription");
            check(slowCalls.get() == beforeCancel + 1, "cancel occurs after exactly one server handler entry");
            check("ok".equals(web.get().uri("/ok").retrieve().bodyToMono(String.class).block(LIMIT)), "maxConnections=1 recovers after caller cancellation");
            trace("slow requests before=" + beforeCancel + " after=" + slowCalls.get());
            // Accept TCP but never send TLS handshake bytes. This isolates TLS establishment, not SYN timeout.
            try (var socket = new ServerSocket(0, 1, InetAddress.getLoopbackAddress()); var executor = Executors.newSingleThreadExecutor()) {
                var accepted = new CountDownLatch(1); var close = new CountDownLatch(1);
                var peer = executor.submit(() -> { try (var connection = socket.accept()) { accepted.countDown(); await(close); } catch (Exception error) { throw new RuntimeException(error); } });
                try {
                    var ssl = SslContextBuilder.forClient().trustManager(InsecureTrustManagerFactory.INSTANCE).build();
                    var tls = nativeClient.secure(spec -> spec.sslContext(ssl).handshakeTimeout(Duration.ofMillis(250)));
                    check(fails(() -> tls.get().uri("https://127.0.0.1:" + socket.getLocalPort() + "/").responseSingle((response, body) -> body.asString()).block(LIMIT), "TLS-establishment-timeout", io.netty.handler.ssl.SslHandshakeTimeoutException.class), "TLS handshake timeout bounds accepted but silent connection");
                    await(accepted);
                } finally { close.countDown(); peer.get(10, TimeUnit.SECONDS); }
            }
        } finally { pool.disposeLater().block(LIMIT); server.disposeNow(LIMIT); loops.disposeLater().block(LIMIT); }
        check(pool.isDisposed() && server.isDisposed() && loops.isDisposed(), "HTTP server pool and loops disposed");
        done(37);
    }
}
