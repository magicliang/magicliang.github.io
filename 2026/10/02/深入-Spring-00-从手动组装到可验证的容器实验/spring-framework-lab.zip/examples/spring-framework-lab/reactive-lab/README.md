# Spring 35–37 响应式实验

使用 JDK 21、Maven Wrapper 3.9.9；Spring 6.2.11、Reactor BOM 2024.0.10、R2DBC PostgreSQL 1.0.7.RELEASE、R2DBC Pool 1.0.2.RELEASE、Tomcat 10.1.46。所有依赖由本模块 POM 固定，父实验工程不需要增加 Reactor 依赖。

在 `examples/spring-framework-lab` 目录执行，`JAVA_HOME` 须指向 JDK 21：

```bash
./mvnw -f reactive-lab/pom.xml -q compile dependency:build-classpath \
  -Dmdep.outputFile=target/classpath.txt
python3 reactive-lab/verify.py
```

可在验证脚本后指定 `35`、`36` 或 `37`，例如 `python3 reactive-lab/verify.py 36`。每次运行以独立 Java 进程执行，日志、退出码、命令、JDK 与源文件哈希写入 `../evidence/<编号>/local-20261002/`。脚本整体进程截止时间为每篇90秒，内部等待最多10秒。

| 篇章 | 实际场景 | 通过断言 |
|---|---|---|
| 35 | 真实 MVC/WebFlux 同结果、需求控制、单事件循环受控阻塞、调度隔离、关闭 | 16 |
| 36 | 真实 PostgreSQL R2DBC 成功/错误/取消/重订阅、上下文换线程、独立 JDBC 终态、池释放 | 23 |
| 37 | RestClient/WebClient/HTTP Interface、503/超时/断连、主动取消、TLS握手停滞、幂等重试、池恢复 | 18 |

36 需要 `../db/README.md` 的 PostgreSQL。默认库 `spring_lab` 位于 `127.0.0.1:55432`，用户 `spring_lab`，空密码。程序只创建/清空自己拥有的 `spring_ch36_orders`、`spring_ch36_idempotent` 表。切换地址可用 `JAVA_TOOL_OPTIONS` 传入 `-Dspring.lab.r2dbc.url=...` 与 `-Dspring.lab.jdbc.url=...`，两者须指向同一数据库。

35/37 仅使用回环随机端口。37 的TLS故障服务只accept TCP而不发送握手字节；其不验证 TCP SYN 超时和慢DNS。TLS分支的无证书校验配置只用于该本地故障注入。幂等集合仅为内存计数模型，不具备持久化能力。

上游 Spring/驱动完整测试集、性能基准、提交确认丢失以及 TCP 丢包故障均未运行。浏览器和文章生成检查由系列统一验收完成。
