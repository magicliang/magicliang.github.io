package blog.spring.ecosystem.data;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "purchase", schema = "spring_e03")
public class Purchase {
    @Id private Long id;
    private String label;
    protected Purchase() { }
    public Purchase(long id, String label) { this.id = id; this.label = label; }
    public Long getId() { return id; }
    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }
}
