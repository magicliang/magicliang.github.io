package woven;

public aspect Trace {
    public static int constructors;
    public static int writes;
    public static int reads;
    public static int innerExecutions;
    after() returning: execution(woven.WovenTarget.new(..)) { constructors++; }
    before(): set(int woven.WovenTarget.value) { writes++; }
    before(): get(int woven.WovenTarget.value) { reads++; }
    before(): execution(void woven.WovenTarget.inner()) { innerExecutions++; }
}
