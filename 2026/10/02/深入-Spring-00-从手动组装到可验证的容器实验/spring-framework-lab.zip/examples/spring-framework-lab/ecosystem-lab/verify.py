import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys

module = Path(__file__).resolve().parent
root = module.parent
java_home = Path(os.environ["JAVA_HOME"])
environment = subprocess.run([str(java_home / "bin/java"), "-version"], capture_output=True, text=True, check=True)
cp = str(module / "target/classes") + os.pathsep + (module / "target/classpath.txt").read_text().strip()
hashes = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
          for p in sorted(module.rglob("*")) if p.is_file() and "target" not in p.relative_to(module).parts}
selected = sys.argv[1:] or ["E01", "E02", "E03"]
for chapter in selected:
    folder = root / "evidence" / chapter / "local-20261002"
    folder.mkdir(parents=True, exist_ok=True)
    commands = []
    if chapter == "E01":
        woven = module / "target/woven"
        woven.mkdir(parents=True, exist_ok=True)
        sources = sorted(str(p) for p in (module / "weaving").iterdir())
        commands.append([str(java_home / "bin/java"), "-cp", cp, "org.aspectj.tools.ajc.Main", "-21", "-showWeaveInfo", "-classpath", cp, "-d", str(woven), *sources])
        commands.append([str(java_home / "bin/javap"), "-c", "-p", "-classpath", str(woven), "woven.WovenTarget"])
        commands.append([str(java_home / "bin/java"), "-cp", str(woven) + os.pathsep + cp, "woven.WeavingMain"])
    else:
        main = {"E02": "SecurityLab", "E03": "DataLab"}[chapter]
        commands.append([str(java_home / "bin/java"), "-cp", cp, "blog.spring.ecosystem." + main])
    outputs = [environment.stderr + environment.stdout]
    exit_code = 0
    for index, command in enumerate(commands):
        result = subprocess.run(command, cwd=module, capture_output=True, text=True, timeout=180)
        output = result.stdout + result.stderr
        outputs.append("COMMAND " + shlex.join(command) + "\n" + output)
        if chapter == "E01" and index == 1:
            (folder / "javap.txt").write_text(output)
            if "woven/Trace.aspectOf" not in output:
                exit_code = 1
                outputs.append("FAIL woven bytecode advice invocation absent\n")
                break
        if result.returncode:
            exit_code = result.returncode
            break
    combined = "\n".join(outputs)
    (folder / "run.txt").write_text(combined)
    (folder / "exit-code.txt").write_text(str(exit_code) + "\n")
    manifest = {"chapter": chapter, "java": environment.stderr.strip(), "commands": commands,
                "source_sha256": hashes, "run_sha256": hashlib.sha256(combined.encode()).hexdigest(),
                "checks": sum(line.startswith("CHECK PASS ") for line in combined.splitlines()), "exit_code": exit_code}
    if chapter == "E01":
        manifest["woven_class_sha256"] = {str(p.relative_to(module)): hashlib.sha256(p.read_bytes()).hexdigest()
                                          for p in sorted((module / "target/woven").rglob("*.class"))}
        for binary in sorted((module / "target/woven").rglob("*.class")):
            artifact = folder / "woven-classes" / binary.relative_to(module / "target/woven")
            artifact.parent.mkdir(parents=True, exist_ok=True)
            artifact.write_bytes(binary.read_bytes())
    (folder / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(chapter, "exit", exit_code, "checks", manifest["checks"], flush=True)
    if exit_code:
        print(combined[-10000:])
        sys.exit(exit_code)
