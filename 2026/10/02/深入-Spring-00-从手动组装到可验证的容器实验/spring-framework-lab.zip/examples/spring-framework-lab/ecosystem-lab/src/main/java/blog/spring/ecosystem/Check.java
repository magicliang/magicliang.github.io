package blog.spring.ecosystem;

public final class Check {
    private Check() { }
    public static void that(boolean result, String description) {
        if (!result) throw new AssertionError(description);
        System.out.println("CHECK PASS " + description);
    }
}
