# E01–E03：织入、安全链与 Repository

固定 JDK 21、Spring Boot 3.5.6 BOM（Framework 6.2.11、Security 6.5.5、Data JPA 3.5.4、Hibernate 6.6.29.Final、Tomcat 10.1.46）。仅 AspectJ 显式冻结到 1.9.22.1，三件套版本一致。教学基线不表示当前推荐版本。

从 `examples/spring-framework-lab/` 执行，`JAVA_HOME` 指向 JDK 21：

```sh
./mvnw -f ecosystem-lab/pom.xml -q compile dependency:build-classpath -Dmdep.outputFile=target/classpath.txt
python3 ecosystem-lab/verify.py
```

可以给验证脚本传入 `E01`、`E02` 或 `E03`，只运行指定实验。脚本不会替代第一条编译命令。

- E01 调用真正的 ajc，输出织入报告、javap 反汇编和 9 条运行时断言；保留 class 文件及 SHA-256。编译期织入没有使用 `-javaagent`。
- E02 启动随机端口 Tomcat，发送真实 HTTP，19 条断言覆盖认证、URL/方法授权、CSRF token、CORS、ERROR 分派与端口关闭。`{noop}pw` 仅为回环测试账户；真实服务需密码编码、TLS 与账号生命周期管理。
- E03 连接真正的 PostgreSQL，20 条断言覆盖 Repository 查询、事务默认值、外部事务、JdbcTemplate/原生 JPA、批量更新与持久化上下文。仅创建并清空实验专属 `spring_e03.purchase`；不要把 JDBC URL 指向业务库。

数据库默认 `jdbc:postgresql://127.0.0.1:55432/spring_lab`，用户 `spring_lab`，空密码。可通过 `SPRING_LAB_JDBC_URL`、`SPRING_LAB_DB_USER`、`SPRING_LAB_DB_PASSWORD` 覆盖。E01/E02 无需数据库；E03 不启动或关闭 PostgreSQL。

日志位于上层 `evidence/E01`、`E02`、`E03`。`run.txt` 是实际命令和进程输出，`manifest.json` 记录源码/POM/输出哈希、JDK、检查数和退出码。SQL 的事务标签来自 Hibernate StatementInspector 调用时的 Spring 线程状态，不是数据库服务端 SQL 日志；真正的可见性另由独立 JDBC 连接断言。
