package blog.spring.ecosystem;

import blog.spring.ecosystem.data.Purchase;
import blog.spring.ecosystem.data.PurchaseRepository;
import com.zaxxer.hikari.HikariDataSource;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.hibernate.resource.jdbc.spi.StatementInspector;
import org.springframework.aop.framework.Advised;
import org.springframework.aop.support.AopUtils;
import org.springframework.context.annotation.*;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.SharedEntityManagerCreator;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.transaction.support.TransactionTemplate;

public class DataLab {
    static final String URL = System.getenv().getOrDefault("SPRING_LAB_JDBC_URL", "jdbc:postgresql://127.0.0.1:55432/spring_lab");
    static final String USER = System.getenv().getOrDefault("SPRING_LAB_DB_USER", "spring_lab");
    static final String PASSWORD = System.getenv().getOrDefault("SPRING_LAB_DB_PASSWORD", "");
    static final List<String> sqlEvents = new ArrayList<>();
    public static class SqlTrace implements StatementInspector {
        @Override public String inspect(String sql) {
            String record = "SQL tx=" + TransactionSynchronizationManager.isActualTransactionActive()
                + " readOnly=" + TransactionSynchronizationManager.isCurrentTransactionReadOnly() + " " + sql;
            sqlEvents.add(record);
            System.out.println(record);
            return sql;
        }
    }
    @Configuration
    @EnableJpaRepositories(basePackageClasses = PurchaseRepository.class)
    public static class Config {
        @Bean(destroyMethod = "close") HikariDataSource dataSource() {
            HikariDataSource ds = new HikariDataSource();
            ds.setJdbcUrl(URL); ds.setUsername(USER); ds.setPassword(PASSWORD);
            ds.setMaximumPoolSize(3); ds.setMinimumIdle(0);
            return ds;
        }
        @Bean LocalContainerEntityManagerFactoryBean entityManagerFactory(DataSource ds) {
            var factory = new LocalContainerEntityManagerFactoryBean();
            factory.setDataSource(ds);
            factory.setPackagesToScan(Purchase.class.getPackageName());
            factory.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
            factory.setJpaPropertyMap(Map.of("hibernate.hbm2ddl.auto", "none", "hibernate.session_factory.statement_inspector", new SqlTrace()));
            return factory;
        }
        @Bean JpaTransactionManager transactionManager(EntityManagerFactory emf) { return new JpaTransactionManager(emf); }
    }
    static long observed(long id) throws Exception {
        try (var connection = DriverManager.getConnection(URL, USER, PASSWORD);
             var statement = connection.prepareStatement("select count(*) from spring_e03.purchase where id=?")) {
            statement.setLong(1, id);
            try (var rows = statement.executeQuery()) { rows.next(); return rows.getLong(1); }
        }
    }
    static long observer(long id) {
        try { return observed(id); } catch (Exception error) { throw new IllegalStateException(error); }
    }
    public static void main(String[] args) throws Exception {
        try (var connection = DriverManager.getConnection(URL, USER, PASSWORD); var statement = connection.createStatement()) {
            statement.execute("create schema if not exists spring_e03");
            statement.execute("create table if not exists spring_e03.purchase(id bigint primary key,label varchar(100))");
            statement.execute("truncate spring_e03.purchase");
        }
        HikariDataSource ds;
        EntityManagerFactory emf;
        try (var context = new AnnotationConfigApplicationContext(Config.class)) {
            var repository = context.getBean(PurchaseRepository.class);
            ds = context.getBean(HikariDataSource.class);
            emf = context.getBean(EntityManagerFactory.class);
            var transaction = new TransactionTemplate(context.getBean(JpaTransactionManager.class));
            var jdbc = new JdbcTemplate(ds);
            EntityManager shared = SharedEntityManagerCreator.createSharedEntityManager(emf);
            Check.that(AopUtils.isJdkDynamicProxy(repository), "repository interface is implemented by JDK proxy");
            System.out.println("ADVISORS " + List.of(((Advised) repository).getAdvisors()));
            repository.saveAndFlush(new Purchase(1, "original"));
            Check.that(observed(1) == 1, "inherited saveAndFlush owns and commits transaction");
            sqlEvents.clear();
            repository.findAll();
            Check.that(sqlEvents.stream().anyMatch(s -> s.startsWith("SQL tx=true readOnly=true")), "inherited findAll opens read-only transaction");
            sqlEvents.clear();
            Check.that(repository.findByLabel("original").size() == 1, "derived query parses property and executes SQL");
            Check.that(sqlEvents.stream().anyMatch(s -> s.startsWith("SQL tx=false")), "declared derived query has no default transaction");
            sqlEvents.clear();
            Check.that(repository.byDeclaredQuery("original").size() == 1, "JPQL declared query executes independently of name parser");
            Check.that(sqlEvents.stream().anyMatch(s -> s.startsWith("SQL tx=false")), "declared JPQL query has no default transaction");
            boolean noTransaction = false;
            try { repository.rename(1, "forbidden"); } catch (org.springframework.dao.InvalidDataAccessApiUsageException expected) {
                noTransaction = true; System.out.println("EXPECTED " + expected.getClass().getName());
            }
            Check.that(noTransaction, "Modifying annotation alone does not begin transaction");
            transaction.executeWithoutResult(status -> {
                repository.saveAndFlush(new Purchase(2, "repo"));
                jdbc.update("insert into spring_e03.purchase values (?,?)", 3L, "jdbc");
                shared.persist(new Purchase(4, "jpa")); shared.flush();
                Check.that(observer(2) == 0 && observer(3) == 0 && observer(4) == 0, "fresh observer sees none of repository JDBC JPA uncommitted writes");
                Check.that(jdbc.queryForObject("select count(*) from spring_e03.purchase where id in (2,3,4)", Long.class) == 3L, "JdbcTemplate sees all writes on JPA transaction connection");
                status.setRollbackOnly();
            });
            Check.that(observed(2) == 0 && observed(3) == 0 && observed(4) == 0, "outer rollback removes repository JDBC and native JPA writes");
            transaction.executeWithoutResult(status -> {
                repository.saveAndFlush(new Purchase(5, "committed"));
                Check.that(observer(5) == 0, "saveAndFlush inside outer transaction is not commit");
            });
            Check.that(observed(5) == 1, "outer completion exposes repository write to observer");
            sqlEvents.clear();
            transaction.executeWithoutResult(status -> repository.findAll());
            Check.that(sqlEvents.stream().anyMatch(s -> s.startsWith("SQL tx=true readOnly=false")), "outer read-write transaction overrides repository read-only default");
            transaction.executeWithoutResult(status -> {
                Purchase managed = shared.find(Purchase.class, 1L);
                repository.rename(1, "bulk");
                Check.that(managed.getLabel().equals("original"), "bulk JPQL update leaves managed entity stale");
                shared.clear();
                Check.that(shared.find(Purchase.class, 1L).getLabel().equals("bulk"), "clear plus reload observes bulk update");
            });
            EntityManager nativeEm = emf.createEntityManager();
            try {
                nativeEm.getTransaction().begin();
                nativeEm.persist(new Purchase(6, "native")); nativeEm.flush();
                Check.that(observed(6) == 0, "native EntityManager flush remains uncommitted");
                nativeEm.getTransaction().commit();
                Check.that(observed(6) == 1, "native JPA requires explicit transaction completion");
            } finally { if (nativeEm.getTransaction().isActive()) nativeEm.getTransaction().rollback(); nativeEm.close(); }
            jdbc.update("insert into spring_e03.purchase values (?,?)", 7L, "autocommit");
            Check.that(observed(7) == 1, "JdbcTemplate outside Spring transaction uses autocommit connection");
        }
        Check.that(ds.isClosed() && !emf.isOpen(), "context close releases pool and EntityManagerFactory");
    }
}
