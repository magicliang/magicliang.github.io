package blog.spring.ecosystem.data;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface PurchaseRepository extends JpaRepository<Purchase, Long> {
    List<Purchase> findByLabel(String label);
    @Query("select p from Purchase p where p.label = :label")
    List<Purchase> byDeclaredQuery(String label);
    @Modifying
    @Query("update Purchase p set p.label = :label where p.id = :id")
    int rename(long id, String label);
}
