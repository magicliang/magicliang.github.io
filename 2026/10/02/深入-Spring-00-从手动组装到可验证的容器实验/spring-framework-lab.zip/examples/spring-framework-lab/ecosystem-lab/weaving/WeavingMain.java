package woven;

import blog.spring.ecosystem.Check;
import org.aopalliance.intercept.MethodInterceptor;
import org.springframework.aop.framework.ProxyFactory;

public class WeavingMain {
    public static class ProxyTarget {
        public int value;
        public void outer() { inner(); }
        public void inner() { value++; }
    }
    public static void main(String[] args) {
        WovenTarget target = new WovenTarget();
        Check.that(Trace.constructors == 1, "constructor execution woven for plain new");
        Check.that(Trace.writes == 1, "constructor field assignment woven");
        target.outer();
        Check.that(Trace.innerExecutions == 1, "self invocation executes woven inner advice");
        Check.that(Trace.writes == 2 && Trace.reads == 1, "increment has distinct field get and set join points");
        int value = target.value;
        Check.that(value == 2 && Trace.reads == 2, "external field access woven at caller");
        ProxyTarget raw = new ProxyTarget();
        ProxyFactory factory = new ProxyFactory(raw);
        factory.setProxyTargetClass(true);
        int[] calls = {0};
        factory.addAdvice((MethodInterceptor) invocation -> { calls[0]++; return invocation.proceed(); });
        ProxyTarget proxy = (ProxyTarget) factory.getProxy();
        proxy.outer();
        Check.that(calls[0] == 1 && raw.value == 1, "Spring proxy intercepts outer but not target self invocation");
        proxy.inner();
        Check.that(calls[0] == 2 && raw.value == 2, "external inner call crosses Spring proxy");
        raw.value = 8;
        Check.that(calls[0] == 2, "raw field write has no Spring method interceptor");
        new ProxyTarget();
        Check.that(calls[0] == 2, "plain constructor is outside Spring proxy interception");
    }
}
