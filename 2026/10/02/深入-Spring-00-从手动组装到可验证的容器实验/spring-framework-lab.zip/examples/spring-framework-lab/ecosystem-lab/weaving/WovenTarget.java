package woven;

public class WovenTarget {
    public int value;
    public WovenTarget() { value = 1; }
    public void outer() { inner(); }
    public void inner() { value++; }
}
