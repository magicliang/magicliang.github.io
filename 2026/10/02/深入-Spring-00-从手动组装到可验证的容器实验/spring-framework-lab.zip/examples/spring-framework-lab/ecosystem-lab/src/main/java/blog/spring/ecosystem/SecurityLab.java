package blog.spring.ecosystem;

import jakarta.servlet.DispatcherType;
import jakarta.servlet.Filter;
import jakarta.servlet.http.HttpServletRequest;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

public class SecurityLab {
    static final List<String> dispatches = new CopyOnWriteArrayList<>();
    @SpringBootConfiguration
    @EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class, JpaRepositoriesAutoConfiguration.class})
    @EnableMethodSecurity
    public static class Config {
        @Bean UserDetailsService users() {
            return new InMemoryUserDetailsManager(
                User.withUsername("reader").password("{noop}pw").roles("READER").build(),
                User.withUsername("admin").password("{noop}pw").roles("ADMIN").build());
        }
        @Bean SecurityFilterChain security(HttpSecurity http) throws Exception {
            return http.cors(Customizer.withDefaults())
                .authorizeHttpRequests(a -> a.dispatcherTypeMatchers(DispatcherType.ERROR).permitAll()
                    .requestMatchers("/public", "/csrf").permitAll()
                    .requestMatchers("/admin").hasRole("ADMIN").anyRequest().authenticated())
                .httpBasic(Customizer.withDefaults()).build();
        }
        @Bean UrlBasedCorsConfigurationSource corsConfigurationSource() {
            CorsConfiguration config = new CorsConfiguration();
            config.setAllowedOrigins(List.of("https://client.example"));
            config.setAllowedMethods(List.of("GET", "POST"));
            config.setAllowedHeaders(List.of("Authorization", "X-CSRF-TOKEN", "Content-Type"));
            config.setAllowCredentials(true);
            UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
            source.registerCorsConfiguration("/**", config);
            return source;
        }
        @Bean Guard guard() { return new Guard(); }
        @Bean Endpoints endpoints(Guard guard) { return new Endpoints(guard); }
        @Bean FilterRegistrationBean<Filter> trace() {
            FilterRegistrationBean<Filter> bean = new FilterRegistrationBean<>((request, response, chain) -> {
                HttpServletRequest r = (HttpServletRequest) request;
                dispatches.add(r.getDispatcherType() + " " + r.getRequestURI());
                chain.doFilter(request, response);
            });
            bean.setOrder(-200);
            bean.setDispatcherTypes(DispatcherType.REQUEST, DispatcherType.ERROR);
            return bean;
        }
    }
    public static class Guard {
        @PreAuthorize("hasRole('ADMIN')") public String restricted() { return "method-admin"; }
    }
    @RestController
    public static class Endpoints {
        private final Guard guard;
        Endpoints(Guard guard) { this.guard = guard; }
        @GetMapping("/public") String open() { return "public"; }
        @GetMapping("/private") String authenticated() { return "private"; }
        @GetMapping("/admin") String admin() { return "admin"; }
        @GetMapping("/method") String method() { return guard.restricted(); }
        @GetMapping("/csrf") Map<String, String> csrf(CsrfToken token) { return Map.of("token", token.getToken(), "header", token.getHeaderName()); }
        @PostMapping("/write") String write() { return "written"; }
        @GetMapping("/explode") String explode() { throw new IllegalStateException("E02 expected application failure"); }
    }
    static HttpResponse<String> request(HttpClient client, String base, String path, String method, String user, String... headers) throws Exception {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(base + path)).timeout(Duration.ofSeconds(10));
        if (user != null) b.header("Authorization", "Basic " + Base64.getEncoder().encodeToString((user + ":pw").getBytes(StandardCharsets.UTF_8)));
        for (int i = 0; i < headers.length; i += 2) b.header(headers[i], headers[i + 1]);
        b.method(method, HttpRequest.BodyPublishers.noBody());
        HttpResponse<String> r = client.send(b.build(), HttpResponse.BodyHandlers.ofString());
        System.out.println("HTTP " + method + " " + path + " user=" + user + " status=" + r.statusCode() + " body=" + r.body());
        return r;
    }
    public static void main(String[] args) throws Exception {
        SpringApplication app = new SpringApplication(Config.class);
        app.setDefaultProperties(Map.of("server.port", "0", "spring.main.banner-mode", "off", "logging.level.root", "WARN"));
        int port;
        try (ServletWebServerApplicationContext context = (ServletWebServerApplicationContext) app.run()) {
            port = context.getWebServer().getPort();
            String base = "http://127.0.0.1:" + port;
            CookieManager cookies = new CookieManager(null, CookiePolicy.ACCEPT_ALL);
            try (HttpClient client = HttpClient.newBuilder().cookieHandler(cookies).connectTimeout(Duration.ofSeconds(3)).build()) {
                FilterChainProxy chain = context.getBean("springSecurityFilterChain", FilterChainProxy.class);
                List<String> filters = chain.getFilterChains().getFirst().getFilters().stream().map(f -> f.getClass().getSimpleName()).toList();
                System.out.println("FILTERS " + filters);
                Check.that(filters.contains("CsrfFilter") && filters.contains("AuthorizationFilter"), "CSRF and authorization filters remain installed");
                Check.that(filters.indexOf("CorsFilter") < filters.indexOf("BasicAuthenticationFilter"), "CORS runs before authentication");
                Check.that(request(client, base, "/public", "GET", null).statusCode() == 200, "public anonymous GET succeeds");
                Check.that(request(client, base, "/private", "GET", null).statusCode() == 401, "anonymous protected GET invokes authentication entry point");
                Check.that(request(client, base, "/private", "GET", "missing").statusCode() == 401, "invalid credentials are rejected");
                Check.that(request(client, base, "/private", "GET", "reader").statusCode() == 200, "valid reader authentication succeeds");
                Check.that(request(client, base, "/admin", "GET", "reader").statusCode() == 403, "authenticated reader fails URL authorization");
                Check.that(request(client, base, "/admin", "GET", "admin").statusCode() == 200, "admin passes URL authorization");
                Check.that(request(client, base, "/method", "GET", "reader").statusCode() == 403, "method interceptor rejects authenticated reader");
                Check.that(request(client, base, "/method", "GET", "admin").statusCode() == 200, "method interceptor permits admin");
                Check.that(request(client, base, "/write", "POST", "admin").statusCode() == 403, "authenticated POST without CSRF token is denied");
                var json = new com.fasterxml.jackson.databind.ObjectMapper().readTree(request(client, base, "/csrf", "GET", "admin").body());
                Check.that(!cookies.getCookieStore().getCookies().isEmpty(), "deferred CSRF token access creates session cookie");
                Check.that(request(client, base, "/write", "POST", "admin", json.get("header").asText(), json.get("token").asText()).statusCode() == 200, "session cookie plus CSRF token permits POST");
                var preflight = request(client, base, "/private", "OPTIONS", null, "Origin", "https://client.example", "Access-Control-Request-Method", "POST");
                Check.that(preflight.statusCode() == 200 && preflight.headers().firstValue("Access-Control-Allow-Origin").orElse("").equals("https://client.example"), "allowed origin anonymous preflight succeeds");
                Check.that(request(client, base, "/private", "OPTIONS", null, "Origin", "https://evil.example", "Access-Control-Request-Method", "POST").statusCode() == 403, "unlisted origin preflight is denied");
                Check.that(request(client, base, "/explode", "GET", "reader").statusCode() == 500, "application error retains 500 through ERROR dispatch");
                Check.that(dispatches.contains("REQUEST /explode") && dispatches.contains("ERROR /error"), "real Tomcat error dispatch observed");
                Check.that(request(client, base, "/private", "GET", null).statusCode() == 401, "prior Basic request does not authenticate later anonymous request");
                System.out.println("DISPATCHES " + dispatches);
            }
        }
        try (java.net.Socket socket = new java.net.Socket()) {
            boolean refused = false;
            try { socket.connect(new java.net.InetSocketAddress("127.0.0.1", port), 1000); }
            catch (java.io.IOException expected) { refused = true; }
            Check.that(refused, "closed context releases HTTP listener");
        }
    }
}
