# Spring Framework 可运行实验

教学版本固定 Spring Framework **6.2.11**，JDK **21**。00–18使用原生Framework，19开始使用真实PostgreSQL。共享订单域为 `OrderService`、`OrderRepository`、`PricePolicy`，数量、单价和落库金额必须大于零。初始仓库是供单线程教学使用的内存集合；singleton仅描述容器内对象数量，不提供线程安全保证。

在本目录运行（先将 `JAVA_HOME` 指向 JDK 21）：

```sh
./mvnw -q compile exec:java -Dexec.mainClass=blog.spring.Chapter00
./run-all.sh
```

把 `00` 替换为 `01`–`19` 可独立运行其他章节。每条 `CHECK PASS` 只有对应断言通过才打印，失败抛 `AssertionError` 并返回非零退出码；脚本在首个失败处停止。无参数脚本执行00–18；指定参数可只运行目标章节。

数据库准备见[db/README.md](db/README.md)，随后运行：

```sh
./run-all.sh 19
./mvnw -q compile exec:java -Dexec.mainClass=blog.spring.Chapter19 -Dspring.lab.jdbc.url='jdbc:postgresql://127.0.0.1:55432/spring_lab' -Dspring.lab.jdbc.user=spring_lab
```

默认实验库只用于本机合成数据；程序创建和清空对应章节表。19检查实际commit、rollback、REQUIRED连接身份、rollback-only、原始连接独立提交与租约终态。连接池不代替数据库服务。

| 章节 | 类 | 实际检查 |
| --- | --- | --- |
| 00 | `Chapter00` | 手工/容器订单均为 25.00，数量/金额校验，缺依赖启动失败，关闭销毁 |
| 01 | `Chapter01` | `new` 与容器身份、singleton/prototype 实例计数、定义先于实例、跨容器与多定义身份边界 |
| 02 | `Chapter02` | 编程/XML/配置类同语义，别名、构造参数、注册不实例化、prototype别名、来源及工厂方法元数据 |
| 03 | `Chapter03` | registry/factory/构造/BPP/init/事件顺序，包装行为，失败清理边界 |
| 04 | `Chapter04` | scan/Import，full/lite 直接调用差异，方法参数注入恢复托管 |
| 05 | `Chapter05` | 零/一/多候选、泛型、Qualifier、Primary、集合、延迟 Provider |
| 06 | `Chapter06` | 构造器/静态及实例工厂，FactoryBean 产品缓存与 `&name`，lazy/prototype Provider、FactoryBean 类型探测、eager 依赖强制 lazy 初始化 |
| 07–09 | `Chapter07`–`Chapter09` | 回调、代理引用、扩展排序、过早创建、循环对象图和早期代理一致性 |
| 10–13 | `Chapter10`–`Chapter13` | scope与受控并发、属性条件时点、同步/异步事件、阶段与关闭线程终态 |
| 14–18 | `Chapter14`–`Chapter18` | JDK/CGLIB、自动代理器、静态/动态切点、拦截器链、自调用与桥接方法 |
| 19 | `Chapter19` | JDBC物理事务、连接绑定、参与事务、独立会话与清理 |

`Chapter03` 的失败控制组先通过 `BeanFactory.getBean()` 人为创建一个可销毁单例，再触发 factory/BPP/prepareRefresh 阶段故障，以观察同一对象的清理边界。`prepareRefresh()` 子类故意在 `super.prepareRefresh()` 之后抛错：本版本该调用在 refresh 内层清理 catch 之外，断言 active=true、单例保留，显式 close 后才销毁。这不是正常启动路径，也不意味着所有 refresh 异常都会自动清理。

证据位于 `evidence/NN/local-20261002/run.txt` 与 `exit-code.txt`，全量输出为 `evidence/run-all.txt`；`evidence/manifest.json` 逐项记录调用、通过条件和原始产物。`evidence/environment/` 保存实际 Maven/JDK 版本和依赖树。日志中的预期注入失败警告属于故障实验；以断言及退出码判断结果。

Wrapper 沿用仓库 Hibernate 实验的下载方式，固定 Maven 3.9.9 与 SHA-512。首次运行需访问 Maven Central；这里的运行利用已有本地缓存。未修改全局 Maven 配置。执行插件固定 3.1.0，避开本机缺少新插件传递依赖的环境限制。
