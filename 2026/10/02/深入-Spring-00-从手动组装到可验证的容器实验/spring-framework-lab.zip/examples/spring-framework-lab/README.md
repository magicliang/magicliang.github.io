# Spring Framework 可运行实验

教学版本固定 Spring Framework **6.2.11**，JDK **21**。00–18使用原生Framework，19开始使用真实PostgreSQL。共享订单域为 `OrderService`、`OrderRepository`、`PricePolicy`，数量、单价和落库金额必须大于零。初始仓库是供单线程教学使用的内存集合；singleton仅描述容器内对象数量，不提供线程安全保证。

在本目录运行（先将 `JAVA_HOME` 指向 JDK 21）：

```sh
./mvnw -q compile exec:java -Dexec.mainClass=blog.spring.Chapter00
./run-all.sh
```

把 `00` 替换为 `01`–`24`或`31`–`34` 可独立运行根工程其他章节。每条 `CHECK PASS` 只有对应断言通过才打印，失败抛 `AssertionError` 并返回非零退出码；脚本在首个失败处停止。无参数脚本执行00–18；指定参数可只运行目标章节。

数据库准备见[db/README.md](db/README.md)，随后运行：

```sh
./run-all.sh 19
./mvnw -q compile exec:java -Dexec.mainClass=blog.spring.Chapter19 -Dspring.lab.jdbc.url='jdbc:postgresql://127.0.0.1:55432/spring_lab' -Dspring.lab.jdbc.user=spring_lab
```

默认实验库只用于本机合成数据；程序创建和清空对应章节表。19检查实际commit、rollback、REQUIRED连接身份、rollback-only、原始连接独立提交与租约终态。连接池不代替数据库服务。

| 章节 | 类 | 实际检查 |
| --- | --- | --- |
| 00 | `Chapter00` | 手工/容器订单均为 25.00，数量/金额校验，缺依赖启动失败，关闭销毁 |
| 01 | `Chapter01` | `new` 与容器身份、singleton/prototype 实例计数、定义先于实例、跨容器与多定义身份边界 |
| 02 | `Chapter02` | 编程/XML/配置类同语义，别名、构造参数、注册不实例化、prototype别名、来源及工厂方法元数据 |
| 03 | `Chapter03` | registry/factory/构造/BPP/init/事件顺序，包装行为，失败清理边界 |
| 04 | `Chapter04` | scan/Import，full/lite 直接调用差异，方法参数注入恢复托管 |
| 05 | `Chapter05` | 零/一/多候选、泛型、Qualifier、Primary、集合、延迟 Provider |
| 06 | `Chapter06` | 构造器/静态及实例工厂，FactoryBean 产品缓存与 `&name`，lazy/prototype Provider、FactoryBean 类型探测、eager 依赖强制 lazy 初始化 |
| 07–09 | `Chapter07`–`Chapter09` | 回调、代理引用、扩展排序、过早创建、循环对象图和早期代理一致性 |
| 10–13 | `Chapter10`–`Chapter13` | scope与受控并发、属性条件时点、同步/异步事件、阶段与关闭线程终态 |
| 14–18 | `Chapter14`–`Chapter18` | JDK/CGLIB、自动代理器、静态/动态切点、拦截器链、自调用与桥接方法 |
| 19 | `Chapter19` | JDBC物理事务、连接绑定、参与事务、独立会话与清理 |
| 20–24 | `Chapter20`–`Chapter24`，另加`orm-lab` | 声明式属性、传播、回滚规则、提交后事件、资源与ORM flush |
| 25–30 | `mvc-lab`的`MvcLab` | 真实Tomcat HTTP：分派、匹配、绑定、校验、返回值、异步与断连 |
| 31–34 | `Chapter31`–`Chapter34` | 执行器拒绝与异常、调度终态、缓存并发及回滚、真实HTTP请求上下文捕获恢复 |
| 35–37 | `reactive-lab` | 真HTTP与R2DBC：需求、订阅事务、取消回滚、客户端超时与释放 |

24的ORM需要单独运行，不在根run-all.sh中：

```sh
./mvnw -q -f orm-lab/pom.xml compile exec:java -Dexec.mainClass=blog.spring.orm.Chapter24Orm
python3 mvc-lab/verify.py
```

独立MVC模块的版本、端口与资源清理契约见[mvc-lab/README.md](mvc-lab/README.md)。该模块六篇真实HTTP共有77条断言；它不使用数据库。

31–34 在根工程运行；35–37 是独立模块，构建必须明确传入它的 POM：

```sh
./run-all.sh 31 32 33 34
./mvnw -q -f reactive-lab/pom.xml compile dependency:build-classpath -Dmdep.outputFile=target/classpath.txt
python3 reactive-lab/verify.py
```

前一组52条断言；后一组57条，包含真实PostgreSQL/R2DBC事务。37的连接阶段故障为已接受TCP连接后的TLS握手停滞；TCP SYN丢弃和慢DNS没有执行。

`Chapter03` 的失败控制组先通过 `BeanFactory.getBean()` 人为创建一个可销毁单例，再触发 factory/BPP/prepareRefresh 阶段故障，以观察同一对象的清理边界。`prepareRefresh()` 子类故意在 `super.prepareRefresh()` 之后抛错：本版本该调用在 refresh 内层清理 catch 之外，断言 active=true、单例保留，显式 close 后才销毁。这不是正常启动路径，也不意味着所有 refresh 异常都会自动清理。

证据位于 `evidence/NN/local-20261002/run.txt` 与 `exit-code.txt`，全量输出为 `evidence/run-all.txt`；`evidence/manifest.json` 逐项记录调用、通过条件和原始产物。`evidence/environment/` 保存实际 Maven/JDK 版本和依赖树。日志中的预期注入失败警告属于故障实验；以断言及退出码判断结果。

Wrapper 沿用仓库 Hibernate 实验的下载方式，固定 Maven 3.9.9 与 SHA-512。首次运行需访问 Maven Central；这里的运行利用已有本地缓存。未修改全局 Maven 配置。执行插件固定 3.1.0，避开本机缺少新插件传递依赖的环境限制。

## 后段与选修复现

以下命令从本工程根目录运行，JDK21与数据库已按上文准备。每个模块README写明版本、端口、清理和验收条件；脚本退出0才表示整个实验通过。

```sh
sh boot-lab/run.sh
python3 final-lab/verify.py
./mvnw -q -f ecosystem-lab/pom.xml compile dependency:build-classpath -Dmdep.outputFile=target/classpath.txt
python3 ecosystem-lab/verify.py
PG_SRC=/path/to/postgresql-18.0 PG_SHARE=/path/to/installed/share sh consistency-lab/run.sh
sh concurrency-lab/run.sh
sh migration-lab/run.sh
python3 minimal-lab/verify.py
```

| 篇 | 模块与实际检查 | 断言 |
|---|---|---|
| 38–40 | boot-lab：条件退让与绑定、导入扩展、观测事件与资源终态 | 14+10+17 |
| 41–43 | final-lab：纯单测/集成边界、process-aot与AOT JVM、六组订单验收 | 15+18+21 |
| E01–E03 | ecosystem-lab：ajc真实编织、Security真HTTP、Repository真数据库 | 9+19+20 |
| E04 | consistency-lab：双DB真实XA准备、持久COMMIT后中断恢复、HTTP outbox幂等 | 21 |
| E05–E06 | concurrency-lab：同SQL/负载的三种服务器、取消/池租约；真实挂起调用与R2DBC上下文 | 38+22 |
| E07 | migration-lab：两个POM/独立JVM各25条；JSON/校验/Servlet/RuntimeHints迁移 | 50 |
| E08 | minimal-lab：单线程显式绑定、构造依赖、代理发布与失败契约 | 21 |

全系列主线662条、选修200条，共862条。42未安装native-image，原生编译NOT_RUN；AOT生成和AOT JVM已运行。E04专用端口55433需空闲，脚本自行创建和关闭临时PG集群；主实验55432服务由操作者负责关闭。PG_SRC必须是已构建的18.0源码树，PG_SHARE是对应initdb使用的share目录；不是主库连接URL。所有数据均为本机合成实验数据。

E05记录同一硬件/连接池/SQL负载的观察，不能作为框架通用性能排名。E04协调器只覆盖固定两分支教学恢复，没有生产JTA协议完整性。E08不支持并发、作用域、资源生命周期或事务。上游测试仅阅读，没有运行上游Gradle/JUnit。
