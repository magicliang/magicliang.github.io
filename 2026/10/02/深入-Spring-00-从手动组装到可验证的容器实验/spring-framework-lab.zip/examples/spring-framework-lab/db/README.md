# 本地 PostgreSQL 事务实验

固定数据库版本18.0、pgJDBC42.7.7、HikariCP5.0.1、READ COMMITTED。数据库仅本机回环，合成数据，专用spring_lab数据库；不要把这些实验指向业务数据库。每篇只操作自己的spring_chNN_*表。

## 已有18.0服务器工具

设置`SPRING_PG_BIN`指向包含postgres/initdb/pg_ctl/createdb的完整安装；客户端libpq目录可能没有postgres，不能据此判断server可用。

```bash
export SPRING_PG_BIN=/path/to/postgresql-18.0/bin
export SPRING_LAB_PGDATA=$(mktemp -d /tmp/spring-lab-pg.XXXXXX)
"$SPRING_PG_BIN/initdb" -D "$SPRING_LAB_PGDATA" -U spring_lab --auth=trust --no-locale --encoding=UTF8
"$SPRING_PG_BIN/pg_ctl" -D "$SPRING_LAB_PGDATA" -l "$SPRING_LAB_PGDATA/server.log" -o "-h 127.0.0.1 -p 55432 -k $SPRING_LAB_PGDATA" -w start
"$SPRING_PG_BIN/createdb" -h 127.0.0.1 -p 55432 -U spring_lab spring_lab
```

这里只为临时本地实验选择trust认证且绑定127.0.0.1；实验结束保留日志，然后关闭自己的数据库：

```bash
"$SPRING_PG_BIN/pg_ctl" -D "$SPRING_LAB_PGDATA" -m fast -w stop
```

Chapter19默认连接`jdbc:postgresql://127.0.0.1:55432/spring_lab?connectTimeout=3&socketTimeout=5`，用户名spring_lab，空密码。只用专用数据库，运行会重置当篇合成表中的记录。

## 从官方源码构建

官方下载页：https://ftp.postgresql.org/pub/source/v18.0/ 。源码包postgresql-18.0.tar.bz2的SHA256：

```text
0d5b903b1e5fe361bca7aa9507519933773eb34266b1357c4e7780fdee6d6078
```

在独立临时目录解压，按官方源码安装说明构建，无需安装到系统目录：

```bash
./configure --prefix=/path/to/temporary/pg-runtime --without-readline --without-zlib --without-icu
make -j4
make install
```

实际本机Apple clang21、macOS arm64、构建并行6；官方源包校验通过。安装目录的可执行文件被本机系统终止，重新本地签名未解决；源码构建目录的程序正常，因此本次记录使用源码程序启动。该路径属于本机复现差异，不表示PostgreSQL安装普遍失败。源目录initdb查找相邻postgres，需要在该目录放置指向src/backend/postgres的链接；`initdb -L`必须指向实际包含postgres.bki的share目录。本次前缀包含postgres字符串，安装路径是share，不能误填share/postgresql。

精确实际命令与环境记录见`evidence/environment/postgresql-18.0/README.md`。本次未执行PostgreSQL自身回归套件，不把数据库可启动或应用实验通过称为上游make check通过。没有使用容器镜像，所以没有镜像digest；源码SHA256承担发行材料标识。
