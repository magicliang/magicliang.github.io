package blog.spring.migration;

import jakarta.servlet.ServletContext;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Map;
import org.springframework.aot.hint.MemberCategory;
import org.springframework.aot.hint.RuntimeHints;
import org.springframework.aot.hint.RuntimeHintsRegistrar;
import org.springframework.aot.nativex.FileNativeConfigurationWriter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.core.SpringVersion;
import org.springframework.web.bind.annotation.*;

public class MigrationProbe {
    static String lane;
    static void check(boolean success, String message) {
        if (!success) throw new AssertionError(lane + " " + message);
        System.out.println("CHECK PASS " + lane + " " + message);
    }
    public record Input(@NotBlank String name, @Min(1) int quantity) { }
    public record Output(String zebra, String alpha, String nullable) { }
    public static class BeanOutput {
        public String zebra = "Z";
        public String alpha = "A";
        public String nullable;
    }
    public static class Broken {
        public String getValue() { throw new IllegalStateException("intentional serializer failure"); }
    }
    public static class ProbeHints implements RuntimeHintsRegistrar {
        @Override public void registerHints(RuntimeHints hints, ClassLoader loader) {
            hints.reflection().registerType(Input.class, MemberCategory.INVOKE_DECLARED_CONSTRUCTORS);
            hints.resources().registerPattern("migration-contract.txt");
        }
    }
    @SpringBootConfiguration
    @EnableAutoConfiguration
    public static class Config {
        @Bean Endpoints endpoints() { return new Endpoints(); }
    }
    @RestController
    public static class Endpoints {
        @GetMapping("/payload") Output payload() { return new Output("Z", "A", null); }
        @GetMapping("/bean") BeanOutput bean() { return new BeanOutput(); }
        @PostMapping("/input") String input(@Valid @RequestBody Input input) { return input.name() + ":" + input.quantity(); }
        @GetMapping("/quantity") String quantity(@RequestParam @Min(1) int value) { return Integer.toString(value); }
        @GetMapping("/broken") Broken broken() { return new Broken(); }
    }
    static HttpResponse<String> request(HttpClient client, String base, String path, String method, String body, String... headers) throws Exception {
        var builder = HttpRequest.newBuilder(URI.create(base + path)).timeout(Duration.ofSeconds(10));
        for (int i = 0; i < headers.length; i += 2) builder.header(headers[i], headers[i + 1]);
        builder.method(method, HttpRequest.BodyPublishers.ofString(body));
        var response = client.send(builder.build(), HttpResponse.BodyHandlers.ofString());
        System.out.println("HTTP " + method + " " + path + " " + response.statusCode() + " " + response.body());
        return response;
    }
    static boolean present(String type) {
        try { Class.forName(type); return true; } catch (ClassNotFoundException absent) { return false; }
    }
    public static void main(String[] args) throws Exception {
        lane = args[0];
        boolean modern = lane.equals("modern");
        var hints = new RuntimeHints();
        new ProbeHints().registerHints(hints, MigrationProbe.class.getClassLoader());
        check(hints.reflection().getTypeHint(Input.class).getMemberCategories().contains(MemberCategory.INVOKE_DECLARED_CONSTRUCTORS), "record constructor reflection hint registered");
        new FileNativeConfigurationWriter(Path.of("target/generated-hints")).write(hints);
        System.out.println("HINTS target/generated-hints");
        SpringApplication app = new SpringApplication(Config.class);
        app.setDefaultProperties(Map.of("server.port", "0", "server.address", "127.0.0.1", "spring.main.banner-mode", "off", "logging.level.root", "WARN"));
        int port;
        try (var context = app.run()) {
            port = Integer.parseInt(context.getEnvironment().getRequiredProperty("local.server.port"));
            ServletContext servlet = context.getBean(ServletContext.class);
            System.out.println("VERSION framework=" + SpringVersion.getVersion() + " servlet=" + servlet.getMajorVersion() + "." + servlet.getMinorVersion());
            check(SpringVersion.getVersion().equals(modern ? "7.0.1" : "6.2.11"), "resolved framework matches frozen BOM");
            check(servlet.getMajorVersion() == 6 && servlet.getMinorVersion() == (modern ? 1 : 0), "actual servlet runtime contract matches baseline");
            String mapperType = modern ? "tools.jackson.databind.json.JsonMapper" : "com.fasterxml.jackson.databind.ObjectMapper";
            check(!context.getBeansOfType(Class.forName(mapperType)).isEmpty(), "auto-configured JSON mapper uses expected namespace");
            check(present("org.springframework.util.concurrent.ListenableFuture") != modern, "removed ListenableFuture API boundary observed");
            String base = "http://127.0.0.1:" + port;
            try (HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3)).build()) {
                var payload = request(client, base, "/payload", "GET", "");
                check(payload.statusCode() == 200 && payload.headers().firstValue("Content-Type").orElse("").contains("application/json"), "record serialization produces JSON response");
                check(payload.body().contains("\"nullable\":null"), "default JSON includes null property");
                check(payload.body().contains("\"alpha\":\"A\"") && payload.body().contains("\"zebra\":\"Z\""), "record property values preserved");
                System.out.println("OBSERVED_PROPERTY_ORDER " + payload.body());
                check(payload.body().indexOf("zebra") < payload.body().indexOf("alpha"), "record constructor property order preserved in this fixture");
                var bean = request(client, base, "/bean", "GET", "");
                check(bean.statusCode() == 200 && bean.body().contains("\"nullable\":null"), "ordinary bean JSON retains null property");
                check((bean.body().indexOf("alpha") < bean.body().indexOf("zebra")) == modern, "ordinary bean default property sorting differs across Jackson generations");
                System.out.println("OBSERVED_BEAN_ORDER " + bean.body());
                check(request(client, base, "/payload/", "GET", "").statusCode() == 404, "trailing slash is not implicitly matched");
                check(request(client, base, "/input", "POST", "{\"name\":\"order\",\"quantity\":2}", "Content-Type", "application/json").body().equals("order:2"), "record JSON input is deserialized and validated");
                check(request(client, base, "/input", "POST", "{\"name\":\"order\",\"quantity\":2,\"extra\":true}", "Content-Type", "application/json").statusCode() == 200, "Boot default ignores unknown JSON property");
                check(request(client, base, "/input", "POST", "{\"name\":\"\",\"quantity\":0}", "Content-Type", "application/json").statusCode() == 400, "Jakarta bean validation rejects invalid record");
                check(request(client, base, "/input", "POST", "{", "Content-Type", "application/json").statusCode() == 400, "malformed JSON rejected");
                check(request(client, base, "/input", "POST", "null", "Content-Type", "application/json").statusCode() == 400, "null required request body rejected");
                check(request(client, base, "/input", "POST", "hello", "Content-Type", "text/plain").statusCode() == 415, "unsupported input media type rejected");
                check(request(client, base, "/quantity?value=2", "GET", "").statusCode() == 200, "valid method constraint input succeeds");
                check(request(client, base, "/quantity?value=0", "GET", "").statusCode() == 400, "MVC method validation rejects numeric constraint");
                check(request(client, base, "/quantity?value=bad", "GET", "").statusCode() == 400, "parameter conversion failure remains 400");
                check(request(client, base, "/payload", "POST", "").statusCode() == 405, "method mismatch remains 405");
                check(request(client, base, "/payload", "GET", "", "Accept", "application/xml").statusCode() == 406, "unsupported response media type remains 406");
                check(request(client, base, "/broken", "GET", "").statusCode() == 500, "serializer getter exception returns 500 before commitment");
            }
        }
        try (var socket = new java.net.Socket()) {
            boolean refused = false;
            try { socket.connect(new java.net.InetSocketAddress("127.0.0.1", port), 1000); } catch (java.io.IOException expected) { refused = true; }
            check(refused, "context shutdown releases listener");
        }
    }
}
