import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

module = Path(__file__).resolve().parent
root = module.parent
java = Path(os.environ["JAVA_HOME"]) / "bin/java"
evidence = root / "evidence/E07/local-20261002"
evidence.mkdir(parents=True, exist_ok=True)
hashes = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
          for p in sorted(module.rglob("*")) if p.is_file() and "target" not in p.relative_to(module).parts}
summary = []
manifests = []
for lane in ("legacy", "modern"):
    cwd = module / lane
    folder = evidence / lane
    folder.mkdir(exist_ok=True)
    build_command = [str(root / "mvnw"), "-f", str(cwd / "pom.xml"), "compile", "dependency:build-classpath", "-Dmdep.outputFile=target/classpath.txt", "dependency:tree"]
    build = subprocess.run(build_command, cwd=root, capture_output=True, text=True, timeout=420)
    (folder / "build.txt").write_text(build.stdout + build.stderr)
    (folder / "build-exit-code.txt").write_text(str(build.returncode) + "\n")
    if build.returncode:
        print((build.stdout + build.stderr)[-10000:]); sys.exit(build.returncode)
    cp = str(cwd / "target/classes") + os.pathsep + (cwd / "target/classpath.txt").read_text().strip()
    command = [str(java), "-cp", cp, "blog.spring.migration.MigrationProbe", lane]
    result = subprocess.run(command, cwd=cwd, capture_output=True, text=True, timeout=150)
    output = result.stdout + result.stderr
    (folder / "run.txt").write_text(output)
    (folder / "exit-code.txt").write_text(str(result.returncode) + "\n")
    hints = list((cwd / "target/generated-hints").rglob("*.json"))
    assert hints, "native hints JSON missing"
    hints_text = "\n".join(p.read_text() for p in hints)
    assert "MigrationProbe$Input" in hints_text and "migration-contract" in hints_text
    for hint in hints:
        dest = folder / "generated-hints" / hint.relative_to(cwd / "target/generated-hints")
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(hint, dest)
    checks = [line for line in output.splitlines() if line.startswith("CHECK PASS ")]
    entry = {"lane": lane, "build_command": build_command, "command": command, "exit_code": result.returncode,
             "checks": len(checks), "source_sha256": hashes, "run_sha256": hashlib.sha256(output.encode()).hexdigest(),
             "hint_files": [str(p.relative_to(cwd)) for p in hints]}
    (folder / "manifest.json").write_text(json.dumps(entry, indent=2) + "\n")
    manifests.append(entry)
    summary.extend(checks)
    print(lane, "exit", result.returncode, "checks", len(checks), flush=True)
    if result.returncode:
        print(output[-12000:]); sys.exit(result.returncode)
(evidence / "run.txt").write_text("\n".join(summary) + "\n")
(evidence / "exit-code.txt").write_text("0\n")
(evidence / "manifest.json").write_text(json.dumps({"checks": len(summary), "lanes": manifests, "scope": "two separate JVM classpaths; compile plus generated RuntimeHints; no native-image or full application AOT claim"}, indent=2) + "\n")
