# E07：独立版本契约回归

`legacy/pom.xml` 使用 Boot 3.5.6，`modern/pom.xml` 使用 Boot 4.0.0。两者自然解析各自 BOM，共享契约源码但单独编译、单独 JVM 执行，依赖不会合并。新版本使用拆分后的 `spring-boot-starter-webmvc`。

在 `examples/spring-framework-lab/` 下，将 `JAVA_HOME` 指向 JDK 21 后运行：

```sh
python3 migration-lab/verify.py
```

脚本逐个执行上层 Maven Wrapper，以各模块 POM 编译并捕获依赖树，然后启动回环随机端口，使用真实 HTTP 检查 JSON、校验、路径、转换、内容协商和序列化异常。`evidence/E07/local-20261002/legacy` 与 modern 分别保存构建、退出码、运行输出、命令和哈希；顶层 run.txt 仅汇总唯一 CHECK PASS 行。

RuntimeHintsRegistrar 在两代都实际编译、运行并生成原生配置 JSON。这是 hints API 与输出格式的迁移探针，不是完整应用 process-aot，也没有运行 native-image。完整应用 AOT 证据属于主线 42 章。

示例的排序和 null 行为以实际 HTTP 输出为准，不把 Jackson 库原始默认值与 Boot 自动配置后的默认值混为一谈。这个历史冻结组合用于行为比较，不是最新生产版本推荐。
