# E08 最小容器

只使用JDK21，不依赖Maven或Spring。实现显式接口注册、单一public构造器注入、每绑定一个singleton代理、一个拦截器。运行：

```sh
JAVA_HOME=/path/to/jdk21 python3 minimal-lab/verify.py
```

从实验根目录执行。21条真实断言包含延迟创建、图依赖、代理身份、自调用、异常、构造失败重试、缺失/循环/重复定义和跨线程拒绝。源码和命令哈希保存在`evidence/E08/local-20261002/manifest.json`。

不支持注解、泛型候选、scope、生命周期、事务、类代理、多拦截器、并发或AOT。AutoCloseable实现被拒绝，因为本容器没有资源关闭协议。构造失败不会发布当前对象，但之前成功创建的依赖仍保留；没有对象图回滚。固定单线程，首次lookup以后禁止注册。
