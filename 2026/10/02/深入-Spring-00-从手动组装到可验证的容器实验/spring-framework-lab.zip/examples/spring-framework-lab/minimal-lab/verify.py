import hashlib
import json
import os
from pathlib import Path
import subprocess

module = Path(__file__).resolve().parent
evidence = module.parent / 'evidence/E08/local-20261002'
evidence.mkdir(parents=True, exist_ok=True)
target = module / 'target'
target.mkdir(exist_ok=True)
java_home = Path(os.environ['JAVA_HOME'])
commands = [[str(java_home / 'bin/javac'), '--release', '21', '-d', str(target), str(module / 'MinimalContainerLab.java')],
            [str(java_home / 'bin/java'), '-cp', str(target), 'MinimalContainerLab']]
logs = []
for command in commands:
    result = subprocess.run(command, capture_output=True, text=True, timeout=60)
    logs.append(result.stdout + result.stderr)
    if result.returncode:
        break
(evidence / 'run.txt').write_text('\n'.join(logs))
(evidence / 'exit-code.txt').write_text(str(result.returncode) + '\n')
(evidence / 'manifest.json').write_text(json.dumps({'commands': commands, 'exit': result.returncode, 'checks': logs[-1].count('CHECK PASS '),
    'sources': {'minimal-lab/MinimalContainerLab.java': hashlib.sha256((module / 'MinimalContainerLab.java').read_bytes()).hexdigest()},
    'java': subprocess.run([str(java_home / 'bin/java'), '-version'], capture_output=True, text=True).stderr}, indent=2) + '\n')
print(logs[-1])
raise SystemExit(result.returncode)
