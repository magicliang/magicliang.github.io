import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

public final class MinimalContainerLab {
    @FunctionalInterface interface Call { Object run() throws Throwable; }
    @FunctionalInterface interface Interceptor { Object invoke(Method method, Call next) throws Throwable; }

    static final class Container {
        private final Thread owner = Thread.currentThread();
        private final Map<Class<?>, Class<?>> definitions = new HashMap<>();
        private final Map<Class<?>, Object> singletons = new HashMap<>();
        private final Set<Class<?>> constructing = new LinkedHashSet<>();
        private final Interceptor interceptor;
        private boolean frozen;

        Container(Interceptor interceptor) { this.interceptor = Objects.requireNonNull(interceptor); }

        <T> void register(Class<T> contract, Class<? extends T> implementation) {
            owner();
            if (frozen) throw new IllegalStateException("registration frozen after first lookup");
            Objects.requireNonNull(contract);
            Objects.requireNonNull(implementation);
            if (!contract.isInterface() || !Modifier.isPublic(contract.getModifiers())
                    || !contract.isAssignableFrom(implementation)
                    || AutoCloseable.class.isAssignableFrom(implementation)
                    || Modifier.isAbstract(implementation.getModifiers())) {
                throw new IllegalArgumentException("public interface and concrete compatible implementation required");
            }
            Constructor<?>[] constructors = implementation.getConstructors();
            if (constructors.length != 1) throw new IllegalArgumentException("exactly one public constructor required");
            for (var parameter : constructors[0].getGenericParameterTypes()) {
                if (!(parameter instanceof Class<?> type) || !type.isInterface()) {
                    throw new IllegalArgumentException("only plain interface constructor dependencies supported");
                }
            }
            if (definitions.putIfAbsent(contract, implementation) != null) {
                throw new IllegalArgumentException("duplicate binding: " + contract.getName());
            }
        }

        <T> T get(Class<T> contract) {
            owner();
            Objects.requireNonNull(contract);
            frozen = true;
            Object cached = singletons.get(contract);
            if (cached != null) return contract.cast(cached);
            Class<?> implementation = definitions.get(contract);
            if (implementation == null) throw new IllegalArgumentException("missing binding: " + contract.getName());
            if (!constructing.add(contract)) throw new IllegalStateException("constructor cycle: " + constructing + " -> " + contract);
            try {
                Constructor<?> constructor = implementation.getConstructors()[0];
                Object[] arguments = new Object[constructor.getParameterCount()];
                for (int i = 0; i < arguments.length; i++) arguments[i] = get(constructor.getParameterTypes()[i]);
                Object target;
                try { target = constructor.newInstance(arguments); }
                catch (InvocationTargetException failure) {
                    if (failure.getCause() instanceof RuntimeException cause) throw cause;
                    if (failure.getCause() instanceof Error cause) throw cause;
                    throw new IllegalStateException("constructor failed", failure.getCause());
                }
                Object proxy = Proxy.newProxyInstance(contract.getClassLoader(), new Class<?>[] {contract},
                    (reference, method, args) -> {
                        owner();
                        if (method.getDeclaringClass() == Object.class) {
                            return switch (method.getName()) {
                                case "equals" -> reference == args[0];
                                case "hashCode" -> System.identityHashCode(reference);
                                case "toString" -> "MiniProxy[" + contract.getName() + "]";
                                default -> throw new AssertionError(method);
                            };
                        }
                        return interceptor.invoke(method, () -> {
                            try { return method.invoke(target, args); }
                            catch (InvocationTargetException failure) { throw failure.getCause(); }
                        });
                    });
                singletons.put(contract, proxy);
                return contract.cast(proxy);
            } catch (ReflectiveOperationException failure) {
                throw new IllegalStateException("construction failed", failure);
            } finally {
                constructing.remove(contract);
            }
        }

        private void owner() {
            if (Thread.currentThread() != owner) throw new IllegalStateException("single-thread teaching container");
        }
    }

    public interface Repository { String save(String id); }
    public static final class MemoryRepository implements Repository {
        static int constructions;
        public MemoryRepository() { constructions++; }
        public String save(String id) { return "saved:" + id; }
    }
    public interface Orders { String place(String id); String externalThenInternal(String id); void fail() throws IOException; }
    public static final class OrderService implements Orders {
        final Repository repository;
        public OrderService(Repository repository) { this.repository = repository; }
        public String place(String id) { if (id.isBlank()) throw new IllegalArgumentException("empty order"); return repository.save(id); }
        public String externalThenInternal(String id) { return place(id); }
        public void fail() throws IOException { throw new IOException("target failure"); }
    }
    public interface A { void a(); }
    public interface B { void b(); }
    public static final class CyclicA implements A { public CyclicA(B b) {} public void a() {} }
    public static final class CyclicB implements B { public CyclicB(A a) {} public void b() {} }
    public static final class Ambiguous implements A { public Ambiguous() {} public Ambiguous(B b) {} public void a() {} }
    public static final class GenericDependency implements A { public GenericDependency(List<B> values) {} public void a() {} }
    public static final class RetryConstructor implements A {
        static boolean fail = true;
        public RetryConstructor() { if (fail) throw new IllegalArgumentException("constructor fault"); }
        public void a() {}
    }
    static int checks;
    static void check(boolean ok, String name) { if (!ok) throw new AssertionError(name); checks++; System.out.println("CHECK PASS " + name); }
    static void rejects(Class<? extends Throwable> expected, Call action, String name) {
        try { action.run(); } catch (Throwable failure) { check(expected.isInstance(failure), name + " -> " + failure.getClass().getSimpleName()); return; }
        throw new AssertionError(name + " did not fail");
    }

    public static void main(String[] args) throws Exception {
        List<String> calls = new ArrayList<>();
        Container container = new Container((method, next) -> {
            calls.add("before:" + method.getName());
            try { Object result = next.run(); calls.add("return:" + method.getName()); return result; }
            finally { calls.add("finally:" + method.getName()); }
        });
        container.register(Repository.class, MemoryRepository.class);
        container.register(Orders.class, OrderService.class);
        check(MemoryRepository.constructions == 0, "registration leaves definitions uninstantiated");
        rejects(IllegalArgumentException.class, () -> { container.register(Orders.class, OrderService.class); return null; }, "duplicate binding rejected");
        Orders orders = container.get(Orders.class);
        check(MemoryRepository.constructions == 1, "constructor graph creates dependency once");
        check(orders == container.get(Orders.class), "published proxy singleton identity");
        check(Proxy.isProxyClass(orders.getClass()), "exposed reference is JDK interface proxy");
        check(orders.place("o1").equals("saved:o1"), "injected repository proxy executes target");
        check(calls.equals(List.of("before:place", "before:save", "return:save", "finally:save", "return:place", "finally:place")), "nested dependency call crosses two proxy boundaries");
        calls.clear(); orders.externalThenInternal("o2");
        check(!calls.contains("before:place") && calls.contains("before:externalThenInternal"), "self invocation bypasses interceptor");
        calls.clear(); rejects(IOException.class, () -> { orders.fail(); return null; }, "declared target exception preserved");
        check(calls.equals(List.of("before:fail", "finally:fail")), "finally executes on target exception");
        calls.clear(); check(orders.equals(orders) && !orders.equals(new Object()) && orders.hashCode() == System.identityHashCode(orders), "Object methods preserve proxy identity");
        check(calls.isEmpty(), "Object methods bypass business interceptor");
        rejects(IllegalStateException.class, () -> { container.register(A.class, CyclicA.class); return null; }, "late registration rejected");
        Container missing = new Container((m, next) -> next.run()); missing.register(Orders.class, OrderService.class);
        rejects(IllegalArgumentException.class, () -> missing.get(Orders.class), "missing dependency rejected");
        Container cycle = new Container((m, next) -> next.run()); cycle.register(A.class, CyclicA.class); cycle.register(B.class, CyclicB.class);
        rejects(IllegalStateException.class, () -> cycle.get(A.class), "constructor cycle rejected");
        rejects(IllegalStateException.class, () -> cycle.get(A.class), "cycle lookup cleanup permits same diagnostic on retry");
        Container unsupported = new Container((m, next) -> next.run());
        rejects(IllegalArgumentException.class, () -> { unsupported.register(A.class, Ambiguous.class); return null; }, "ambiguous constructor rejected");
        rejects(IllegalArgumentException.class, () -> { unsupported.register(A.class, GenericDependency.class); return null; }, "generic collection resolution unsupported");
        Container retry = new Container((m, next) -> next.run()); retry.register(A.class, RetryConstructor.class);
        rejects(IllegalArgumentException.class, () -> retry.get(A.class), "constructor exception unwrapped");
        RetryConstructor.fail = false; check(retry.get(A.class) != null, "failed singleton not published");
        AtomicReference<Throwable> other = new AtomicReference<>(); Thread thread = new Thread(() -> { try { orders.place("o3"); } catch (Throwable t) { other.set(t); } });
        thread.start(); thread.join(2000);
        check(!thread.isAlive() && other.get() instanceof IllegalStateException, "cross-thread proxy use explicitly rejected");
        System.out.println("SUMMARY chapter=E08 checks=" + checks);
    }
}
