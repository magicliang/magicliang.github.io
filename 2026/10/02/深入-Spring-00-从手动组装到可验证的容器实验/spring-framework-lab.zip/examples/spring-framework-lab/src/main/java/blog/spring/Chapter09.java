package blog.spring;

import org.aopalliance.intercept.MethodInterceptor;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.framework.autoproxy.BeanNameAutoProxyCreator;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.*;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.support.*;
import org.springframework.context.support.GenericApplicationContext;
import static blog.spring.Checks.*;

public class Chapter09 {
    static int intercepted;
    public interface Order { boolean ready(); }
    public static class A implements Order, InitializingBean {
        B b; boolean ready;
        public void setB(B b) { this.b = b; }
        public void afterPropertiesSet() { ready = true; }
        public boolean ready() { return ready; }
    }
    public static class B {
        Order a; boolean observedEarly;
        public void setA(Order a) { this.a = a; observedEarly = !a.ready(); }
    }
    public static class ConstructorA { public ConstructorA(ConstructorB b) {} }
    public static class ConstructorB { public ConstructorB(ConstructorA a) {} }
    static void registerPair(GenericApplicationContext context) {
        var a = new RootBeanDefinition(A.class); a.getPropertyValues().add("b", new org.springframework.beans.factory.config.RuntimeBeanReference("b"));
        var b = new RootBeanDefinition(B.class); b.getPropertyValues().add("a", new org.springframework.beans.factory.config.RuntimeBeanReference("a"));
        context.registerBeanDefinition("a", a); context.registerBeanDefinition("b", b);
    }
    static void assertFailure(GenericApplicationContext context, String scenario) {
        var failure = fails(BeanCreationException.class, context::refresh, scenario);
        check(failure.getMostSpecificCause() instanceof BeanCurrentlyInCreationException, scenario + " cycle cause");
        check(!context.isActive(), scenario + " inactive context");
        check(!context.getBeanFactory().containsSingleton("a") && !context.getBeanFactory().containsSingleton("b"), scenario + " no published pair");
    }
    public static void main(String[] args) {
        try (var context = new GenericApplicationContext()) {
            var a = new RootBeanDefinition(ConstructorA.class); a.setAutowireMode(AbstractBeanDefinition.AUTOWIRE_CONSTRUCTOR);
            var b = new RootBeanDefinition(ConstructorB.class); b.setAutowireMode(AbstractBeanDefinition.AUTOWIRE_CONSTRUCTOR);
            context.registerBeanDefinition("a", a); context.registerBeanDefinition("b", b);
            check(context.getDefaultListableBeanFactory().isAllowCircularReferences(), "09 Framework default allows circular references");
            assertFailure(context, "09 constructor cycle");
        }
        try (var context = new GenericApplicationContext()) {
            registerPair(context); context.refresh();
            A a = context.getBean("a", A.class); B b = context.getBean("b", B.class);
            check(a.b == b && b.a == a, "09 setter cycle references agree");
            check(b.observedEarly && a.ready(), "09 early reference exposes uninitialized state");
        }
        intercepted = 0;
        try (var context = new GenericApplicationContext()) {
            registerPair(context);
            context.registerBean("advice", MethodInterceptor.class, () -> invocation -> { intercepted++; return invocation.proceed(); });
            context.registerBean("autoProxy", BeanNameAutoProxyCreator.class, () -> {
                var creator = new BeanNameAutoProxyCreator(); creator.setBeanNames("a"); creator.setInterceptorNames("advice"); return creator;
            });
            context.refresh();
            Order exposed = context.getBean("a", Order.class); B b = context.getBean("b", B.class);
            check(AopUtils.isJdkDynamicProxy(exposed), "09 auto proxy created");
            check(b.a == exposed, "09 early proxy equals final published reference");
            check(b.observedEarly && intercepted == 1, "09 early call already advised but target uninitialized");
            check(exposed.ready() && intercepted == 2, "09 final call sees initialized target");
        }
        try (var context = new GenericApplicationContext()) {
            registerPair(context); context.getDefaultListableBeanFactory().setAllowCircularReferences(false);
            assertFailure(context, "09 circular references disabled");
        }
        try (var context = new GenericApplicationContext()) {
            registerPair(context);
            context.getBeanFactory().getBeanDefinition("a").setLazyInit(true);
            context.getBeanFactory().getBeanDefinition("b").setLazyInit(true);
            context.getBeanFactory().addBeanPostProcessor(new BeanPostProcessor() {
                public Object postProcessAfterInitialization(Object bean, String name) {
                    if (!name.equals("a")) return bean;
                    return new ProxyFactory(bean).getProxy();
                }
            });
            context.refresh();
            var failure = fails(BeanCurrentlyInCreationException.class, () -> context.getBean("a"), "09 late-only wrapper breaks reference consistency");
            check(failure.getMessage().contains("raw version"), "09 failure explains raw reference mismatch");
            check(!context.getBeanFactory().containsSingleton("a") && !context.getBeanFactory().containsSingleton("b"), "09 mismatch cleans dependent singleton");
        }
        System.out.println("PASS Chapter09 resources closed");
    }
}
