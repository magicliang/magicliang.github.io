package blog.spring;

import java.sql.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

public class Chapter24 {
    static long count(int id) {
        try (var connection = LabDatabase.observer(); var statement = connection.createStatement();
             var rows = statement.executeQuery("select count(*) from spring_ch24_resource where id=" + id)) {
            rows.next(); long count = rows.getLong(1); System.out.println("OBSERVER id=" + id + " rows=" + count); return count;
        } catch (SQLException failure) { throw new IllegalStateException(failure); }
    }
    public static void main(String[] args) throws Exception {
        try (var pool = LabDatabase.pool("chapter24-a", 4); var second = LabDatabase.pool("chapter24-b", 2)) {
            var jdbc = new JdbcTemplate(pool); var jdbcB = new JdbcTemplate(second);
            jdbc.execute("create table if not exists spring_ch24_resource(id integer primary key)");
            jdbc.execute("truncate spring_ch24_resource");
            var manager = new DataSourceTransactionManager(pool); var tx = new TransactionTemplate(manager);
            tx.executeWithoutResult(status -> {
                jdbc.update("insert into spring_ch24_resource values(1)");
                int managed = jdbc.queryForObject("select pg_backend_pid()", Integer.class);
                try (var direct = pool.getConnection(); var statement = direct.createStatement()) {
                    try (var result = statement.executeQuery("select pg_backend_pid()")) { result.next();
                        System.out.println("CONNECTION template=" + managed + " direct=" + result.getInt(1));
                        Checks.check(managed != result.getInt(1) && direct.getAutoCommit(), "raw pool checkout is separate autoCommit connection"); }
                    statement.executeUpdate("insert into spring_ch24_resource values(2)");
                } catch (SQLException failure) { throw new IllegalStateException(failure); }
                status.setRollbackOnly();
            });
            Checks.check(count(1) == 0 && count(2) == 1, "template write rolls back while raw connection write survives");
            var read = new TransactionTemplate(manager); read.setReadOnly(true);
            Checks.fails(org.springframework.dao.DataAccessException.class, () -> read.executeWithoutResult(status -> {
                Checks.check("on".equals(jdbc.queryForObject("show transaction_read_only", String.class)), "default pgJDBC propagates readOnly hint");
                jdbc.update("insert into spring_ch24_resource values(3)");
            }), "default driver readOnly rejects write");
            manager.setEnforceReadOnly(true);
            Checks.fails(org.springframework.dao.DataAccessException.class, () -> read.executeWithoutResult(status -> jdbc.update("insert into spring_ch24_resource values(4)")), "enforceReadOnly rejects write");
            Checks.check(count(3) == 0 && count(4) == 0, "readOnly rejected writes absent independently");
            var other = new TransactionTemplate(new DataSourceTransactionManager(second));
            tx.executeWithoutResult(status -> {
                jdbc.update("insert into spring_ch24_resource values(5)");
                other.executeWithoutResult(inner -> jdbcB.update("insert into spring_ch24_resource values(6)"));
                status.setRollbackOnly();
            });
            Checks.check(count(5) == 0 && count(6) == 1, "two local managers do not atomically rollback both resources");
        }
        String base = LabDatabase.url();
        var ignored = new org.springframework.jdbc.datasource.DriverManagerDataSource(base + (base.contains("?") ? "&" : "?") + "readOnlyMode=ignore", LabDatabase.user(), "");
        var hintJdbc = new JdbcTemplate(ignored);
        var hintManager = new DataSourceTransactionManager(ignored);
        var hintTx = new TransactionTemplate(hintManager); hintTx.setReadOnly(true);
        hintTx.executeWithoutResult(status -> {
            Checks.check("off".equals(hintJdbc.queryForObject("show transaction_read_only", String.class)), "driver ignore mode leaves database writable despite Spring hint");
            hintJdbc.update("insert into spring_ch24_resource values(7)");
        });
        Checks.check(count(7) == 1, "readOnly hint alone is not portable write prohibition");
        hintManager.setEnforceReadOnly(true);
        Checks.fails(org.springframework.dao.DataAccessException.class, () -> hintTx.executeWithoutResult(status -> hintJdbc.update("insert into spring_ch24_resource values(8)")), "explicit SQL read only still rejects write when driver hint ignored");
        Checks.check(count(8) == 0, "enforced readOnly leaves no row");
    }
}
