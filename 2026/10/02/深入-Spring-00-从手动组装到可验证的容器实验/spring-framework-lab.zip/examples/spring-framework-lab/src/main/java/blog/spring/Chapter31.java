package blog.spring;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.context.annotation.*;
import org.springframework.scheduling.annotation.*;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.support.*;

public class Chapter31 {
    static final CountDownLatch handled = new CountDownLatch(1);
    static final AtomicReference<String> failure = new AtomicReference<>();
    static void await(CountDownLatch latch) {
        try { if (!latch.await(5, TimeUnit.SECONDS)) throw new AssertionError("latch timeout"); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IllegalStateException(e); }
    }
    @Configuration @EnableAsync(proxyTargetClass = true)
    static class Config implements AsyncConfigurer {
        @Bean ThreadPoolTaskExecutor orders() {
            var e = new ThreadPoolTaskExecutor();
            e.setCorePoolSize(1); e.setMaxPoolSize(1); e.setQueueCapacity(1);
            e.setThreadNamePrefix("orders-31-"); e.setAwaitTerminationSeconds(5); return e;
        }
        @Bean Worker worker() { return new Worker(); }
        @Override public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
            return (e, m, a) -> { failure.set(m.getName() + ":" + e.getMessage()); handled.countDown(); };
        }
    }
    static class Worker {
        @Async("orders") public CompletableFuture<String> thread() {
            return CompletableFuture.completedFuture(Thread.currentThread().getName());
        }
        public String self() { return thread().join(); }
        @Async("orders") public CompletableFuture<String> blocked(CountDownLatch entered, CountDownLatch release) {
            entered.countDown(); await(release); return CompletableFuture.completedFuture("done");
        }
        @Async("orders") public CompletableFuture<String> futureFailure() { throw new IllegalArgumentException("future"); }
        @Async("orders") public void voidFailure() { throw new IllegalStateException("void"); }
        @Async("orders") public CompletableFuture<Boolean> transaction() {
            return CompletableFuture.completedFuture(TransactionSynchronizationManager.isActualTransactionActive());
        }
    }
    public static void main(String[] args) throws Exception {
        ThreadPoolTaskExecutor executor;
        try (var context = new AnnotationConfigApplicationContext(Config.class);
             var pool = LabDatabase.pool("chapter31", 1)) {
            executor = context.getBean(ThreadPoolTaskExecutor.class);
            var worker = context.getBean(Worker.class);
            Checks.check(worker.thread().get(5, TimeUnit.SECONDS).startsWith("orders-31-"), "31 qualified executor");
            Checks.check(worker.self().equals(Thread.currentThread().getName()), "31 self invocation stays caller");
            var entered = new CountDownLatch(1); var release = new CountDownLatch(1);
            var running = worker.blocked(entered, release); await(entered);
            try {
                Checks.check(!running.isDone(), "31 submitted is not completed");
                var queued = worker.thread();
                Checks.check(executor.getThreadPoolExecutor().getQueue().size() == 1, "31 one queued task");
                Checks.fails(org.springframework.core.task.TaskRejectedException.class, worker::thread, "31 rejection on caller");
                release.countDown();
                Checks.check(running.get(5, TimeUnit.SECONDS).equals("done"), "31 running task completes");
                Checks.check(queued.get(5, TimeUnit.SECONDS).startsWith("orders-31-"), "31 queued task executes");
            } finally { release.countDown(); }
            try { worker.futureFailure().get(5, TimeUnit.SECONDS); throw new AssertionError("missing failure"); }
            catch (ExecutionException e) { Checks.check(e.getCause() instanceof IllegalArgumentException, "31 Future exposes target failure"); }
            worker.voidFailure(); await(handled);
            Checks.check("voidFailure:void".equals(failure.get()), "31 void handler observes method and cause");
            new TransactionTemplate(new DataSourceTransactionManager(pool)).executeWithoutResult(status -> {
                Checks.check(TransactionSynchronizationManager.isActualTransactionActive(), "31 caller real JDBC transaction active");
                Checks.check(!worker.transaction().join(), "31 transaction absent on worker");
            });
            Checks.check(pool.getHikariPoolMXBean().getActiveConnections() == 0, "31 JDBC lease returned");
        }
        Checks.check(executor.getThreadPoolExecutor().isTerminated(), "31 executor terminated after context close");
    }
}
