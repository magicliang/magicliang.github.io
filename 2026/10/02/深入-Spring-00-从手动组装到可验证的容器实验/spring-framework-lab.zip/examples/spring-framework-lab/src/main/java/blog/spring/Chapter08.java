package blog.spring;

import java.util.ArrayList;
import java.util.List;
import org.aopalliance.intercept.MethodInterceptor;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.config.*;
import org.springframework.beans.factory.support.*;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.Ordered;
import org.springframework.core.PriorityOrdered;
import static blog.spring.Checks.*;

public class Chapter08 {
    static final List<String> events = new ArrayList<>();
    public interface Work { String value(); }
    public static class Service implements Work {
        private String value = "original";
        public void setValue(String value) { this.value = value; }
        public String value() { return value; }
    }
    public static class Registry implements BeanDefinitionRegistryPostProcessor, PriorityOrdered {
        public int getOrder() { return 100; }
        public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) {
            events.add("registry");
            registry.registerBeanDefinition("service", new RootBeanDefinition(Service.class));
        }
        public void postProcessBeanFactory(ConfigurableListableBeanFactory factory) {
            events.add("registryFactory");
        }
    }
    public static class FactoryPriority implements BeanFactoryPostProcessor, PriorityOrdered {
        public int getOrder() { return 100; }
        public void postProcessBeanFactory(ConfigurableListableBeanFactory factory) {
            events.add("factoryPriority");
            factory.getBeanDefinition("service").getPropertyValues().add("value", "modified");
        }
    }
    public static class FactoryOrdered implements BeanFactoryPostProcessor, Ordered {
        public int getOrder() { return -100; }
        public void postProcessBeanFactory(ConfigurableListableBeanFactory factory) { events.add("factoryOrdered"); }
    }
    public static class OrderedProcessor implements BeanPostProcessor, Ordered {
        final String id; final int order;
        public OrderedProcessor() { this("autoOrdered", -100); }
        OrderedProcessor(String id, int order) { this.id = id; this.order = order; }
        public int getOrder() { return order; }
        public Object postProcessAfterInitialization(Object bean, String name) {
            if (name.equals("service")) events.add(id); return bean;
        }
    }
    public static class PriorityProcessor extends OrderedProcessor implements PriorityOrdered {
        public PriorityProcessor() { super("autoPriority", 100); }
    }
    public static class Wrapper implements BeanPostProcessor {
        public Object postProcessAfterInitialization(Object bean, String name) {
            if (!name.equals("service")) return bean;
            events.add("wrap"); var proxy = new ProxyFactory(bean);
            proxy.addAdvice((MethodInterceptor) invocation -> invocation.proceed());
            return proxy.getProxy();
        }
    }
    public static void main(String[] args) {
        events.clear();
        try (var context = new GenericApplicationContext()) {
            context.getBeanFactory().addBeanPostProcessor(new OrderedProcessor("manual100", 100));
            context.getBeanFactory().addBeanPostProcessor(new OrderedProcessor("manual-100", -100));
            context.registerBean("registry", Registry.class);
            context.registerBean("factoryPriority", FactoryPriority.class);
            context.registerBean("factoryOrdered", FactoryOrdered.class);
            context.registerBean("ordered", OrderedProcessor.class);
            context.registerBean("priority", PriorityProcessor.class);
            context.registerBean("wrapper", Wrapper.class);
            context.refresh();
            check(events.equals(List.of("registry", "registryFactory", "factoryPriority", "factoryOrdered", "manual100", "manual-100", "autoPriority", "autoOrdered", "wrap")), "08 phase and registration order");
            check(context.getBean("service", Work.class).value().equals("modified"), "08 definition change affects created instance");
            check(AopUtils.isAopProxy(context.getBean("service")), "08 instance processor wraps service");
            System.out.println("EVENTS " + events);
        }
        events.clear();
        try (var context = new GenericApplicationContext()) {
            context.registerBean("service", Service.class);
            context.registerBean("wrapper", Wrapper.class);
            context.addBeanFactoryPostProcessor(factory -> {
                factory.getBean("service");
                factory.getBeanDefinition("service").getPropertyValues().add("value", "tooLate");
            });
            context.refresh();
            Work service = context.getBean("service", Work.class);
            check(!AopUtils.isAopProxy(service), "08 early getBean misses subsequently registered wrapper");
            check(service.value().equals("original"), "08 late metadata change does not rewrite existing singleton");
            check(events.isEmpty(), "08 missing post-processing is not replayed");
        }
        System.out.println("PASS Chapter08 resources closed");
    }
}
