package blog.spring;

import java.math.BigDecimal;
import org.springframework.beans.factory.UnsatisfiedDependencyException;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import static blog.spring.Checks.*;

public class Chapter00 {
    public static void main(String[] args) {
        var manualRepository = new OrderRepository();
        var manual = new OrderService(manualRepository, new PricePolicy());
        OrderRepository managedRepository;
        try (var context = new AnnotationConfigApplicationContext()) {
            context.register(OrderRepository.class, PricePolicy.class, OrderService.class);
            context.refresh();
            managedRepository = context.getBean(OrderRepository.class);
            var manualAmount = manual.place(2);
            var managedAmount = context.getBean(OrderService.class).place(2);
            check(manualAmount.equals(new BigDecimal("25.00")) && managedAmount.equals(manualAmount), "00 manual/container both return 25.00");
            check(managedRepository.count() == 1 && manualRepository.count() == 1, "00 both repositories saved once");
            fails(IllegalArgumentException.class, () -> manual.place(0), "00 reject zero quantity");
            fails(IllegalArgumentException.class, () -> manual.place(-1), "00 reject negative quantity");
            fails(IllegalArgumentException.class, () -> new PricePolicy(BigDecimal.ZERO), "00 reject zero unit price");
            fails(IllegalArgumentException.class, () -> new PricePolicy(new BigDecimal("-1")), "00 reject negative unit price");
            fails(IllegalArgumentException.class, () -> managedRepository.save(BigDecimal.ZERO), "00 reject invalid persisted amount");
            check(managedRepository.count() == 1, "00 invalid amount does not save");
        }
        check(managedRepository.closed(), "00 context close destroys managed repository");
        check(!manualRepository.closed(), "00 manual repository requires explicit destroy");
        manualRepository.destroy();
        try (var missing = new AnnotationConfigApplicationContext()) {
            missing.register(OrderService.class, PricePolicy.class);
            fails(UnsatisfiedDependencyException.class, missing::refresh, "00 missing repository fails refresh");
        }
        System.out.println("CHAPTER 00 PASS");
    }
}
