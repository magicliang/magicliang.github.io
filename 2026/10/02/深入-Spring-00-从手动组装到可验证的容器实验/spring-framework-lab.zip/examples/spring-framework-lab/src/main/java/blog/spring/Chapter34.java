package blog.spring;

import java.util.*;
import java.util.concurrent.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import com.sun.net.httpserver.HttpServer;
import org.springframework.core.task.TaskDecorator;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.context.request.*;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.support.*;

public class Chapter34 {
    static final ThreadLocal<String> TRACE = new ThreadLocal<>();
    static class Request implements RequestAttributes {
        final Map<String, Object> attributes = new HashMap<>();
        public Object getAttribute(String n, int s) { return attributes.get(n); }
        public void setAttribute(String n, Object v, int s) { attributes.put(n, v); }
        public void removeAttribute(String n, int s) { attributes.remove(n); }
        public String[] getAttributeNames(int s) { return attributes.keySet().toArray(String[]::new); }
        public void registerDestructionCallback(String n, Runnable r, int s) {}
        public Object resolveReference(String key) { return null; }
        public String getSessionId() { return "synthetic-request"; }
        public Object getSessionMutex() { return this; }
    }
    static TaskDecorator traceDecorator() {
        return task -> {
            String captured = TRACE.get();
            return () -> {
                String previous = TRACE.get();
                try { set(captured); task.run(); }
                finally { set(previous); }
            };
        };
    }
    static void set(String value) { if (value == null) TRACE.remove(); else TRACE.set(value); }
    static ThreadPoolTaskExecutor executor(TaskDecorator decorator) {
        var e = new ThreadPoolTaskExecutor(); e.setCorePoolSize(1); e.setMaxPoolSize(1);
        e.setThreadNamePrefix("context-34-"); e.setAwaitTerminationSeconds(5);
        if (decorator != null) e.setTaskDecorator(decorator); e.initialize(); return e;
    }
    static <T> T get(Future<T> future) {
        try { return future.get(5, TimeUnit.SECONDS); }
        catch (Exception e) { throw new IllegalStateException(e); }
    }
    public static void main(String[] args) throws Exception {
        var raw = executor(null);
        try {
            TRACE.set("caller-A");
            Checks.check(get(raw.submit(TRACE::get)) == null, "34 plain ThreadLocal not copied");
            get(raw.submit(() -> { TRACE.set("leaked-A"); return true; }));
            Checks.check("leaked-A".equals(get(raw.submit(TRACE::get))), "34 reused worker leaks uncleaned context");
            get(raw.submit(() -> { TRACE.remove(); return true; }));
        } finally { TRACE.remove(); raw.shutdown(); }
        Checks.check(raw.getThreadPoolExecutor().awaitTermination(5, TimeUnit.SECONDS), "34 raw worker terminated");
        var decorated = executor(traceDecorator());
        try (var pool = LabDatabase.pool("chapter34", 1)) {
            var request = new Request(); request.setAttribute("trace", "request-A", RequestAttributes.SCOPE_REQUEST);
            RequestContextHolder.setRequestAttributes(request); TRACE.set("request-A");
            new TransactionTemplate(new DataSourceTransactionManager(pool)).executeWithoutResult(status -> {
                Checks.check(TransactionSynchronizationManager.hasResource(pool), "34 caller JDBC connection bound");
                var result = get(decorated.submit(() -> List.of(
                        TRACE.get(), String.valueOf(RequestContextHolder.getRequestAttributes() == null),
                        String.valueOf(TransactionSynchronizationManager.hasResource(pool)),
                        String.valueOf(TransactionSynchronizationManager.isActualTransactionActive()))));
                Checks.check(result.equals(List.of("request-A", "true", "false", "false")), "34 trace copied without request or JDBC transaction");
            });
            Checks.check("request-A".equals(TRACE.get()), "34 worker leaves caller context intact");
            TRACE.set("request-B");
            Checks.check("request-B".equals(get(decorated.submit(TRACE::get))), "34 next request sees its own trace");
            var failed = decorated.submit(() -> { throw new IllegalStateException("expected"); });
            try { failed.get(5, TimeUnit.SECONDS); throw new AssertionError("missing error"); }
            catch (ExecutionException e) { Checks.check(e.getCause() instanceof IllegalStateException, "34 Future retains task error"); }
            TRACE.remove(); RequestContextHolder.resetRequestAttributes();
            Checks.check(get(decorated.submit(TRACE::get)) == null, "34 absent next context remains absent");
            // Bypass decoration solely to inspect the worker after the preceding wrapper has completed.
            Checks.check(get(decorated.getThreadPoolExecutor().submit(TRACE::get)) == null, "34 finally restores clean worker after failure");
            Checks.check(!TransactionSynchronizationManager.hasResource(pool), "34 caller transaction resource removed");
            Checks.check(pool.getHikariPoolMXBean().getActiveConnections() == 0, "34 JDBC lease returned");
            var server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
            var httpThreads = Executors.newSingleThreadExecutor(); server.setExecutor(httpThreads);
            server.createContext("/context", exchange -> {
                String id = exchange.getRequestHeaders().getFirst("X-Trace");
                var incoming = new Request(); incoming.setAttribute("trace", id, RequestAttributes.SCOPE_REQUEST);
                RequestContextHolder.setRequestAttributes(incoming); TRACE.set(id);
                try {
                    String result = get(decorated.submit(() -> TRACE.get() + ":" + (RequestContextHolder.getRequestAttributes() == null)));
                    byte[] bytes = result.getBytes(StandardCharsets.UTF_8);
                    exchange.sendResponseHeaders(200, bytes.length); exchange.getResponseBody().write(bytes);
                } finally { TRACE.remove(); RequestContextHolder.resetRequestAttributes(); exchange.close(); }
            });
            server.start();
            try (var client = HttpClient.newHttpClient()) {
                URI uri = URI.create("http://127.0.0.1:" + server.getAddress().getPort() + "/context");
                for (String id : List.of("http-A", "http-B")) {
                    var response = client.send(HttpRequest.newBuilder(uri).timeout(java.time.Duration.ofSeconds(5))
                            .header("X-Trace", id).build(), HttpResponse.BodyHandlers.ofString());
                    Checks.check(response.statusCode() == 200 && response.body().equals(id + ":true"),
                            "34 real HTTP " + id + " propagates trace without request object");
                }
                Checks.check(get(httpThreads.submit(() -> TRACE.get() == null && RequestContextHolder.getRequestAttributes() == null)),
                        "34 reused HTTP thread cleaned");
            } finally { server.stop(0); httpThreads.shutdownNow(); }
            Checks.check(httpThreads.awaitTermination(5, TimeUnit.SECONDS), "34 HTTP executor terminated");
        } finally { TRACE.remove(); RequestContextHolder.resetRequestAttributes(); decorated.shutdown(); }
        Checks.check(decorated.getThreadPoolExecutor().awaitTermination(5, TimeUnit.SECONDS), "34 decorated worker terminated");
    }
}
