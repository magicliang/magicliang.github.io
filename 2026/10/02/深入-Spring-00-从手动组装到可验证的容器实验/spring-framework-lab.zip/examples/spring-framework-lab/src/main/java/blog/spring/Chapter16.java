package blog.spring;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicInteger;
import org.aopalliance.intercept.MethodInterceptor;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.interceptor.ExposeInvocationInterceptor;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import static blog.spring.Checks.*;

public class Chapter16 {
    @Retention(RetentionPolicy.RUNTIME)
    public @interface Audited {}
    public interface Orders { Object submit(Object input); }
    public static class OrderTarget implements Orders {
        @Audited public Object submit(Object input) { return input; }
    }
    static AspectJExpressionPointcut pointcut(String expression) {
        var pointcut = new AspectJExpressionPointcut();
        pointcut.setExpression(expression);
        return pointcut;
    }
    static int invoke(String expression, boolean classProxy, Object input) {
        var calls = new AtomicInteger();
        var factory = new ProxyFactory(new OrderTarget());
        factory.setProxyTargetClass(classProxy);
        factory.addAdvisor(ExposeInvocationInterceptor.ADVISOR);
        factory.addAdvisor(new DefaultPointcutAdvisor(pointcut(expression), (MethodInterceptor) invocation -> {
            calls.incrementAndGet(); return invocation.proceed();
        }));
        ((Orders) factory.getProxy()).submit(input);
        return calls.get();
    }
    public static void main(String[] args) throws Exception {
        Method method = OrderTarget.class.getMethod("submit", Object.class);
        String type = "blog.spring.Chapter16.OrderTarget";
        String execution = "execution(* submit(..))";
        check(pointcut(execution).matches(method, OrderTarget.class) && !pointcut(execution).isRuntime(), "16 execution static match");
        check(invoke(execution, false, 1) == 1 && invoke(execution, false, "order") == 1,
                "16 execution accepts Integer and String arguments");
        check(invoke("within(" + type + ")", false, 1) == 1, "16 within implementation lexical type");
        check(invoke("this(" + type + ")", false, 1) == 0, "16 JDK proxy is not implementation instance");
        check(invoke("this(" + type + ")", true, 1) == 1, "16 CGLIB proxy is implementation instance");
        check(invoke("target(" + type + ")", false, 1) == 1, "16 target matches behind JDK proxy");
        var runtime = pointcut("args(java.lang.String)");
        check(runtime.matches(method, OrderTarget.class) && runtime.isRuntime(), "16 Object signature leaves runtime args test");
        check(runtime.matches(method, OrderTarget.class, "order") && !runtime.matches(method, OrderTarget.class, 1), "16 runtime String versus Integer");
        check(invoke("args(java.lang.String)", false, "order") == 1 && invoke("args(java.lang.String)", false, 1) == 0, "16 invocation chain evaluates runtime args");
        check(invoke("execution(* submit(java.lang.String))", false, "order") == 0, "16 declared Object signature differs from actual String");
        check(invoke("@annotation(blog.spring.Chapter16.Audited)", false, 1) == 1, "16 implementation annotation resolves from interface invocation");
        fails(org.aspectj.weaver.tools.UnsupportedPointcutPrimitiveException.class,
                () -> pointcut("call(* *(..))").matches(method, OrderTarget.class), "16 call pointcut unsupported by proxy AOP");
        System.out.println("RESULT Chapter16 PASS; no threads or external resources created");
    }
}
