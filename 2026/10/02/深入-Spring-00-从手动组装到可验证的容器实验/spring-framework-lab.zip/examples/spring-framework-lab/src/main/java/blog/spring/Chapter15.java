package blog.spring;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import org.aopalliance.intercept.MethodInterceptor;
import org.springframework.aop.framework.Advised;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;
import org.springframework.aop.support.AopUtils;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.aop.support.StaticMethodMatcherPointcut;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.context.support.GenericApplicationContext;
import static blog.spring.Checks.*;

public class Chapter15 {
    public interface Orders { String place(); }
    public static class OrderTarget implements Orders {
        private Observer observer;
        public void setObserver(Observer observer) { this.observer = observer; }
        public Observer observer() { return observer; }
        public String place() { return "order"; }
    }
    public static class Observer {
        private Orders orders;
        public void setOrders(Orders orders) { this.orders = orders; }
        public Orders orders() { return orders; }
    }
    public static class TracingCreator extends DefaultAdvisorAutoProxyCreator {
        final List<Object> early = new ArrayList<>();
        public Object getEarlyBeanReference(Object bean, String name) {
            Object result = super.getEarlyBeanReference(bean, name);
            early.add(result);
            System.out.println("EARLY " + name + " raw=" + System.identityHashCode(bean) + " exposed=" + System.identityHashCode(result));
            return result;
        }
    }
    static DefaultPointcutAdvisor advisor(AtomicInteger calls) {
        return new DefaultPointcutAdvisor(new StaticMethodMatcherPointcut() {
            public boolean matches(Method method, Class<?> type) {
                return Orders.class.isAssignableFrom(type) && method.getName().equals("place");
            }
        }, (MethodInterceptor) invocation -> { calls.incrementAndGet(); return invocation.proceed(); });
    }
    public static void main(String[] args) throws Exception {
        var calls = new AtomicInteger();
        var advice = advisor(calls);
        var raw = new OrderTarget();
        var manual = new ProxyFactory(raw);
        manual.addAdvisor(advice);
        ((Orders) manual.getProxy()).place();
        check(calls.get() == 1, "15 manual factory explicitly installs advisor");
        calls.set(0);
        var creator = new TracingCreator();
        try (var context = new GenericApplicationContext()) {
            creator.setBeanFactory(context.getBeanFactory());
            context.getBeanFactory().addBeanPostProcessor(creator);
            context.getBeanFactory().registerSingleton("auditAdvisor", advice);
            var order = new RootBeanDefinition(OrderTarget.class);
            order.getPropertyValues().add("observer", new org.springframework.beans.factory.config.RuntimeBeanReference("observer"));
            var observer = new RootBeanDefinition(Observer.class);
            observer.getPropertyValues().add("orders", new org.springframework.beans.factory.config.RuntimeBeanReference("orders"));
            context.registerBeanDefinition("orders", order);
            context.registerBeanDefinition("observer", observer);
            context.refresh();
            Orders proxy = context.getBean("orders", Orders.class);
            check(AopUtils.isAopProxy(proxy), "15 automatic wrapping");
            check(context.getBean(Observer.class).orders() == proxy, "15 early reference equals final singleton");
            check(creator.early.contains(proxy), "15 creator observed early proxy");
            check(((Advised) proxy).getAdvisors().length == 1, "15 one matching candidate advisor");
            check(!AopUtils.isAopProxy(((Advised) proxy).getTargetSource().getTarget()), "15 no duplicate wrapper for early exposure");
            check(creator.postProcessAfterInitialization(advice, "infrastructureCheck") == advice, "15 Advisor infrastructure excluded");
            check(!AopUtils.isAopProxy(context.getBean(Observer.class)), "15 unmatched bean remains raw");
            proxy.place();
            check(calls.get() == 1, "15 one invocation one advice");
            var outer = new ProxyFactory(proxy);
            outer.addAdvisor(advice);
            ((Orders) outer.getProxy()).place();
            check(calls.get() == 3, "15 manual outer wrapper can duplicate advice");
        }
        System.out.println("RESULT Chapter15 PASS; context closed; no external resources created");
    }
}
