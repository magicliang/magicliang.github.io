package blog.spring;

import java.util.ArrayList;
import java.util.List;
import org.aopalliance.intercept.MethodInterceptor;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.core.annotation.AnnotationAwareOrderComparator;
import static blog.spring.Checks.*;

public class Chapter17 {
    public interface Orders { String place(boolean fail); }
    public static class OrderTarget implements Orders {
        final List<String> trace;
        final IllegalStateException failure = new IllegalStateException("inventory");
        OrderTarget(List<String> trace) { this.trace = trace; }
        public String place(boolean fail) { trace.add("target"); if (fail) throw failure; return "order"; }
    }
    static DefaultPointcutAdvisor around(String name, int order, List<String> trace) {
        var advisor = new DefaultPointcutAdvisor((MethodInterceptor) invocation -> {
            trace.add(name + "+");
            try { Object value = invocation.proceed(); trace.add(name + " return"); return name + "(" + value + ")"; }
            catch (Throwable failure) { trace.add(name + " throw"); throw failure; }
            finally { trace.add(name + " finally"); }
        });
        advisor.setOrder(order);
        return advisor;
    }
    public static void main(String[] args) {
        var trace = new ArrayList<String>();
        var target = new OrderTarget(trace);
        var a = around("A", 20, trace);
        var b = around("B", 10, trace);
        var factory = new ProxyFactory(target);
        factory.addAdvisor(a); factory.addAdvisor(b);
        Orders proxy = (Orders) factory.getProxy();
        check(proxy.place(false).equals("A(B(order))"), "17 manual insertion determines wrapper order");
        check(trace.equals(List.of("A+", "B+", "target", "B return", "B finally", "A return", "A finally")), "17 nested normal return and finally order");
        System.out.println("TRACE success=" + trace);
        trace.clear();
        Throwable actual = fails(IllegalStateException.class, () -> proxy.place(true), "17 target failure propagates");
        check(actual == target.failure, "17 same exception identity");
        check(trace.equals(List.of("A+", "B+", "target", "B throw", "B finally", "A throw", "A finally")), "17 nested exceptional exit and finally order");
        System.out.println("TRACE failure=" + trace);
        trace.clear();
        var sorted = new ArrayList<>(List.of(a, b));
        AnnotationAwareOrderComparator.sort(sorted);
        var sortedFactory = new ProxyFactory(target);
        sorted.forEach(sortedFactory::addAdvisor);
        check(((Orders) sortedFactory.getProxy()).place(false).equals("B(A(order))"), "17 explicitly sorted order differs from insertion");
        trace.clear();
        var shortcut = new ProxyFactory(target);
        shortcut.addAdvice((MethodInterceptor) invocation -> "cached");
        check(((Orders) shortcut.getProxy()).place(true).equals("cached") && trace.isEmpty(), "17 no proceed skips target and its exception");
        var recover = new ProxyFactory(target);
        recover.addAdvice((MethodInterceptor) invocation -> { try { return invocation.proceed(); } catch (IllegalStateException ex) { return "fallback"; } });
        check(((Orders) recover.getProxy()).place(true).equals("fallback"), "17 recovery changes caller outcome");
        System.out.println("RESULT Chapter17 PASS; no threads or external resources created");
    }
}
