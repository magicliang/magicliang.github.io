package blog.spring;

import java.math.BigDecimal;
import org.springframework.beans.factory.config.RuntimeBeanReference;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.context.annotation.*;
import static blog.spring.Checks.*;

public class Chapter02 {
    public static class TrackedOrderService extends OrderService {
        static int created;
        public TrackedOrderService(OrderRepository r, PricePolicy p) { super(r, p); created++; }
    }
    @Configuration public static class Config {
        @Bean OrderRepository repository() { return new OrderRepository(); }
        @Bean PricePolicy policy() { return new PricePolicy(); }
        @Bean(name={"orderService", "orders"}) OrderService orderService(OrderRepository r, PricePolicy p) { return new TrackedOrderService(r, p); }
    }
    private static void verify(GenericApplicationContext context, String mode) {
        context.refresh();
        check(context.getBean("orders") == context.getBean("orderService"), "02 " + mode + " alias identity");
        check(context.getBean(OrderService.class).place(2).equals(new BigDecimal("25.00")), "02 " + mode + " same order result");
    }
    public static void main(String[] args) {
        TrackedOrderService.created = 0;
        try (var programmatic = new GenericApplicationContext()) {
            programmatic.registerBean("repository", OrderRepository.class);
            programmatic.registerBean("policy", PricePolicy.class);
            var definition = new RootBeanDefinition(TrackedOrderService.class);
            definition.getConstructorArgumentValues().addIndexedArgumentValue(0, new RuntimeBeanReference("repository"));
            definition.getConstructorArgumentValues().addIndexedArgumentValue(1, new RuntimeBeanReference("policy"));
            programmatic.registerBeanDefinition("orderService", definition);
            programmatic.registerAlias("orderService", "orders");
            check(TrackedOrderService.created == 0, "02 definition registration does not instantiate");
            check(definition.getConstructorArgumentValues().getArgumentCount() == 2, "02 definition records two constructor references");
            var prototype = new RootBeanDefinition(OrderRepository.class);
            prototype.setScope("prototype");
            programmatic.registerBeanDefinition("prototypeRepository", prototype);
            programmatic.registerAlias("prototypeRepository", "freshRepository");
            verify(programmatic, "programmatic");
            check(programmatic.getBean("prototypeRepository") != programmatic.getBean("freshRepository"), "02 alias preserves prototype scope");
            check(definition.getResourceDescription() == null, "02 programmatic definition resource may be null");
        }
        try (var xml = new GenericApplicationContext()) {
            new XmlBeanDefinitionReader(xml).loadBeanDefinitions("classpath:chapter02.xml");
            check(TrackedOrderService.created == 1, "02 XML loading registers definitions only");
            check(xml.getBeanDefinition("orderService").getResourceDescription().contains("chapter02.xml"), "02 XML definition records resource description");
            verify(xml, "XML");
        }
        try (var config = new AnnotationConfigApplicationContext()) { config.register(Config.class); verify(config, "configuration");
            check("orderService".equals(config.getBeanDefinition("orderService").getFactoryMethodName()), "02 Bean definition records factory method"); }
        check(TrackedOrderService.created == 3, "02 three containers create three services");
        System.out.println("CHAPTER 02 PASS");
    }
}
