package blog.spring;

import java.sql.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.context.annotation.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.scheduling.annotation.*;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.event.*;
import org.springframework.transaction.support.*;

public class Chapter23 {
    record Notice(String kind) {}
    static final AtomicInteger committed = new AtomicInteger(), rolledBack = new AtomicInteger(), fallback = new AtomicInteger();
    static final CountDownLatch entered = new CountDownLatch(1), release = new CountDownLatch(1), done = new CountDownLatch(1);
    static volatile boolean asyncTransaction;
    static boolean eventThrew;
    @Configuration @EnableAsync
    static class Config {
        @Bean static TransactionalEventListenerFactory transactionalEventListenerFactory() { return new TransactionalEventListenerFactory(); }
        @Bean Listeners listeners() { return new Listeners(); }
        @Bean Executor taskExecutor() { return Executors.newSingleThreadExecutor(r -> new Thread(r, "chapter23-listener")); }
    }
    static class Listeners {
        @TransactionalEventListener public void committed(Notice notice) { committed.incrementAndGet(); }
        @TransactionalEventListener(phase = TransactionPhase.AFTER_ROLLBACK)
        public void rollback(Notice notice) { rolledBack.incrementAndGet(); }
        @TransactionalEventListener(fallbackExecution = true)
        public void fallback(Notice notice) { fallback.incrementAndGet(); }
        @Async @TransactionalEventListener(condition = "#root.args[0].kind == 'async'")
        public void asynchronous(Notice notice) throws InterruptedException {
            asyncTransaction = TransactionSynchronizationManager.isActualTransactionActive();
            System.out.println("ASYNC thread=" + Thread.currentThread().getName() + " tx=" + asyncTransaction);
            entered.countDown();
            try { if (!release.await(5, TimeUnit.SECONDS)) throw new AssertionError("release timeout"); }
            finally { done.countDown(); }
        }
        @TransactionalEventListener(condition = "#root.args[0].kind == 'throw'")
        public void throwing(Notice notice) {
            eventThrew = true;
            System.out.println("EVENT throwing after commit thread=" + Thread.currentThread().getName());
            throw new IllegalStateException("expected event listener failure after commit");
        }
    }
    static long count(int id) {
        try (var connection = LabDatabase.observer(); var statement = connection.createStatement();
             var rows = statement.executeQuery("select count(*) from spring_ch23_event where id=" + id)) {
            rows.next(); long count = rows.getLong(1);
            System.out.println("OBSERVER id=" + id + " rows=" + count); return count;
        } catch (SQLException failure) { throw new IllegalStateException(failure); }
    }
    public static void main(String[] args) throws Exception {
        try (var pool = LabDatabase.pool("chapter23", 4); var context = new AnnotationConfigApplicationContext(Config.class)) {
            var jdbc = new JdbcTemplate(pool);
            jdbc.execute("create table if not exists spring_ch23_event(id integer primary key)");
            jdbc.execute("truncate spring_ch23_event");
            var manager = new DataSourceTransactionManager(pool);
            var tx = new TransactionTemplate(manager);
            System.out.println("ENV PostgreSQL=" + jdbc.queryForObject("show server_version", String.class));
            context.publishEvent(new Notice("outside"));
            Checks.check(committed.get() == 0 && fallback.get() == 1, "no transaction skips default listener but invokes fallback");
            tx.executeWithoutResult(status -> { jdbc.update("insert into spring_ch23_event values(1)"); context.publishEvent(new Notice("commit"));
                Checks.check(committed.get() == 0 && count(1) == 0, "publish registers callback before commit and observer cannot see row"); });
            Checks.check(committed.get() == 1 && count(1) == 1, "commit event follows durable database commit");
            tx.executeWithoutResult(status -> { jdbc.update("insert into spring_ch23_event values(2)"); context.publishEvent(new Notice("rollback")); status.setRollbackOnly(); });
            Checks.check(rolledBack.get() == 1 && committed.get() == 1 && count(2) == 0, "rollback invokes rollback listener only");
            tx.executeWithoutResult(status -> { jdbc.update("insert into spring_ch23_event values(3)"); context.publishEvent(new Notice("async")); });
            Checks.check(entered.await(5, TimeUnit.SECONDS) && done.getCount() == 1 && count(3) == 1, "commit returns while async listener waits");
            release.countDown();
            Checks.check(done.await(5, TimeUnit.SECONDS) && !asyncTransaction, "async thread has no inherited transaction");
            tx.executeWithoutResult(status -> { jdbc.update("insert into spring_ch23_event values(4)"); context.publishEvent(new Notice("throw")); });
            Checks.check(eventThrew && count(4) == 1, "event afterCompletion failure does not escape and row remains committed");
            Checks.fails(IllegalStateException.class, () -> tx.executeWithoutResult(status -> {
                jdbc.update("insert into spring_ch23_event values(5)");
                TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                    @Override public void afterCommit() { throw new IllegalStateException("expected raw afterCommit failure"); }
                });
            }), "raw afterCommit exception propagates");
            Checks.check(count(5) == 1, "raw callback exception cannot undo committed row");
            var fresh = new TransactionTemplate(manager); fresh.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
            tx.executeWithoutResult(status -> {
                jdbc.update("insert into spring_ch23_event values(6)");
                int outerPid = jdbc.queryForObject("select pg_backend_pid()", Integer.class);
                TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                    @Override public void afterCommit() {
                        Checks.check(TransactionSynchronizationManager.hasResource(pool), "afterCommit still sees bound resource before cleanup");
                        fresh.executeWithoutResult(inner -> {
                            int innerPid = jdbc.queryForObject("select pg_backend_pid()", Integer.class);
                            System.out.println("CONNECTION outer=" + outerPid + " requiresNew=" + innerPid);
                            Checks.check(outerPid != innerPid, "new transaction uses distinct physical backend");
                            jdbc.update("insert into spring_ch23_event values(7)");
                        });
                    }
                });
            });
            Checks.check(count(6) == 1 && count(7) == 1, "original and explicit new transaction both committed");
            Checks.check(!TransactionSynchronizationManager.hasResource(pool), "resource unbound after completion");
            ((ExecutorService) context.getBean("taskExecutor")).shutdownNow();
        } finally { release.countDown(); }
    }
}
