package blog.spring;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;
import org.aopalliance.intercept.MethodInterceptor;
import org.springframework.aop.framework.Advised;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.AopUtils;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.aop.support.StaticMethodMatcherPointcut;
import org.springframework.core.BridgeMethodResolver;
import static blog.spring.Checks.*;

public class Chapter18 {
    @Retention(RetentionPolicy.RUNTIME)
    public @interface Boundary {}
    public interface Orders { String outer(); String inner(); }
    public static class OrderTarget implements Orders {
        public String outer() { return this.inner(); }
        @Boundary public String inner() { return "order"; }
    }
    public static class Checkout {
        final Orders inventory;
        Checkout(Orders inventory) { this.inventory = inventory; }
        public String place() { return inventory.inner(); }
    }
    public interface Store<T> { T save(T value); }
    public static class StringStore implements Store<String> {
        @Boundary public String save(String value) { return value; }
    }
    static DefaultPointcutAdvisor advisor(AtomicInteger calls) {
        return new DefaultPointcutAdvisor(new StaticMethodMatcherPointcut() {
            public boolean matches(Method method, Class<?> targetClass) {
                Method specific = AopUtils.getMostSpecificMethod(method, targetClass);
                return specific.isAnnotationPresent(Boundary.class);
            }
        }, (MethodInterceptor) invocation -> { calls.incrementAndGet(); return invocation.proceed(); });
    }
    static <T> T explicitBoundary(AtomicInteger calls, Supplier<T> action) {
        calls.incrementAndGet();
        return action.get();
    }
    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        for (boolean classProxy : new boolean[]{false, true}) {
            var calls = new AtomicInteger();
            var target = new OrderTarget();
            var factory = new ProxyFactory(target);
            factory.setProxyTargetClass(classProxy);
            factory.addAdvisor(advisor(calls));
            Orders proxy = (Orders) factory.getProxy();
            System.out.printf("IDENTITY classProxy=%s proxy=%x target=%x thread=%s%n", classProxy,
                    System.identityHashCode(proxy), System.identityHashCode(target), Thread.currentThread().getName());
            check(proxy != target && ((Advised) proxy).getTargetSource().getTarget() == target, "18 distinct proxy and target " + classProxy);
            check(proxy.inner().equals("order") && calls.get() == 1, "18 external annotated entry " + classProxy);
            check(proxy.outer().equals("order") && calls.get() == 1, "18 this call bypasses inner advisor " + classProxy);
            target.inner();
            check(calls.get() == 1, "18 raw object bypass " + classProxy);
            check(new Checkout(proxy).place().equals("order") && calls.get() == 2, "18 split service enters dependency proxy " + classProxy);
            explicitBoundary(calls, target::inner);
            check(calls.get() == 3, "18 explicit callback boundary independent of proxy " + classProxy);
        }
        Method interfaceMethod = Store.class.getMethod("save", Object.class);
        Method bridge = Arrays.stream(StringStore.class.getDeclaredMethods()).filter(Method::isBridge).findFirst().orElseThrow();
        Method concrete = StringStore.class.getMethod("save", String.class);
        check(!interfaceMethod.isAnnotationPresent(Boundary.class), "18 interface method has no implementation annotation");
        check(BridgeMethodResolver.findBridgedMethod(bridge).equals(concrete), "18 generated bridge resolves concrete method");
        check(AopUtils.getMostSpecificMethod(interfaceMethod, StringStore.class).equals(concrete), "18 interface generic signature resolves annotated method");
        var calls = new AtomicInteger();
        var factory = new ProxyFactory(new StringStore());
        factory.addAdvisor(advisor(calls));
        Store<String> proxy = (Store<String>) factory.getProxy();
        check(proxy.save("order").equals("order") && calls.get() == 1, "18 generic interface call still advised");
        System.out.println("RESULT Chapter18 PASS; no threads or external resources created");
    }
}
