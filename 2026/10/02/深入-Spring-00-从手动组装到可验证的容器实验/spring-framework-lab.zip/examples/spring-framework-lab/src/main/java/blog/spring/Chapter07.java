package blog.spring;

import java.util.ArrayList;
import java.util.List;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.aopalliance.intercept.MethodInterceptor;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.*;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.context.annotation.CommonAnnotationBeanPostProcessor;
import org.springframework.context.support.GenericApplicationContext;
import static blog.spring.Checks.*;

public class Chapter07 {
    static final List<String> events = new ArrayList<>();
    static Object initThis;
    static int intercepted;
    public interface Work { String work(); }
    public static class Service implements Work, BeanNameAware, BeanFactoryAware,
            InitializingBean, DisposableBean {
        String dependency;
        public Service() { events.add("construct"); }
        public void setDependency(String value) { dependency = value; events.add("inject"); }
        public void setBeanName(String name) { events.add("name:" + name); }
        public void setBeanFactory(BeanFactory factory) { events.add("factory"); }
        @PostConstruct public void annotatedInit() {
            check("repository".equals(dependency), "07 dependency exists before annotated init");
            events.add("annotation"); initThis = this; work();
        }
        public void afterPropertiesSet() { events.add("interface"); }
        public void customInit() { events.add("custom"); }
        public String work() { return dependency; }
        @PreDestroy public void annotatedDestroy() { events.add("preDestroy"); }
        public void destroy() { events.add("destroy"); }
        public void customDestroy() { events.add("customDestroy"); }
    }
    public static class Broken implements InitializingBean {
        public void afterPropertiesSet() { throw new IllegalStateException("invalid configuration"); }
    }
    public static void main(String[] args) {
        events.clear(); intercepted = 0;
        try (var context = new GenericApplicationContext()) {
            var factory = context.getDefaultListableBeanFactory();
            factory.addBeanPostProcessor(new BeanPostProcessor() {
                public Object postProcessBeforeInitialization(Object bean, String name) {
                    if (name.equals("service")) events.add("before"); return bean;
                }
                public Object postProcessAfterInitialization(Object bean, String name) {
                    if (!name.equals("service")) return bean;
                    events.add("after");
                    var proxy = new ProxyFactory(bean);
                    proxy.addAdvice((MethodInterceptor) invocation -> { intercepted++; return invocation.proceed(); });
                    return proxy.getProxy();
                }
            });
            factory.addBeanPostProcessor(new CommonAnnotationBeanPostProcessor());
            var definition = new RootBeanDefinition(Service.class);
            definition.getPropertyValues().add("dependency", "repository");
            definition.setInitMethodName("customInit"); definition.setDestroyMethodName("customDestroy");
            context.registerBeanDefinition("service", definition);
            context.refresh();
            check(events.equals(List.of("construct", "inject", "name:service", "factory", "before", "annotation", "interface", "custom", "after")), "07 exact initialization sequence");
            Work exposed = context.getBean("service", Work.class);
            check(AopUtils.isJdkDynamicProxy(exposed), "07 exposed object is proxy");
            check(initThis != exposed, "07 lifecycle this differs from exposed reference");
            check(intercepted == 0, "07 lifecycle self invocation bypasses advice");
            check(exposed.work().equals("repository") && intercepted == 1, "07 external invocation enters advice");
            check(context.getBean("service") == exposed, "07 published singleton identity is stable");
        }
        check(events.subList(events.size() - 3, events.size()).equals(List.of("preDestroy", "destroy", "customDestroy")), "07 exact destruction sequence");
        System.out.println("EVENTS " + events);
        try (var context = new GenericApplicationContext()) {
            context.registerBean("broken", Broken.class);
            var failure = fails(BeanCreationException.class, context::refresh, "07 initialization failure aborts refresh");
            check(failure.getMostSpecificCause() instanceof IllegalStateException, "07 original initialization cause retained");
            check(!context.isActive(), "07 failed context inactive");
            check(!context.getBeanFactory().containsSingleton("broken"), "07 failed bean not published");
        }
        System.out.println("PASS Chapter07 resources closed");
    }
}
