package blog.spring;

final class Checks {
    static {
        String version = org.springframework.core.SpringVersion.getVersion();
        if (!"6.2.11".equals(version)) throw new AssertionError("unexpected Spring version " + version);
        System.out.println("ENV Spring=" + version + " Java=" + System.getProperty("java.version"));
    }
    static void check(boolean condition, String scenario) {
        if (!condition) throw new AssertionError(scenario);
        System.out.println("CHECK PASS " + scenario);
    }
    static <T extends Throwable> T fails(Class<T> type, Runnable action, String scenario) {
        try { action.run(); }
        catch (Throwable failure) {
            if (!type.isInstance(failure)) throw new AssertionError(scenario, failure);
            System.out.println("CHECK PASS " + scenario + " -> " + failure.getClass().getSimpleName());
            return type.cast(failure);
        }
        throw new AssertionError(scenario + ": expected " + type.getSimpleName());
    }
}
