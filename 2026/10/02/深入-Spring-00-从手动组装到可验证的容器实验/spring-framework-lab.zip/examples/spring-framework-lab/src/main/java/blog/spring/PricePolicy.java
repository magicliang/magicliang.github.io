package blog.spring;

import java.math.BigDecimal;

public class PricePolicy {
    private final BigDecimal unitPrice;
    public PricePolicy() { this(new BigDecimal("12.50")); }
    public PricePolicy(BigDecimal unitPrice) {
        if (unitPrice == null || unitPrice.signum() <= 0) throw new IllegalArgumentException("positive unit price required");
        this.unitPrice = unitPrice;
    }
    public BigDecimal total(int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("positive quantity required");
        return unitPrice.multiply(BigDecimal.valueOf(quantity));
    }
}
