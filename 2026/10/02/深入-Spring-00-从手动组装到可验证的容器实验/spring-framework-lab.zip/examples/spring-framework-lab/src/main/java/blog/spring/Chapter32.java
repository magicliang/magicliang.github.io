package blog.spring;

import java.time.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.context.annotation.*;
import org.springframework.scheduling.annotation.*;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.*;

public class Chapter32 {
    static void await(CountDownLatch latch) {
        try { if (!latch.await(5, TimeUnit.SECONDS)) throw new AssertionError("latch timeout"); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IllegalStateException(e); }
    }
    static final CountDownLatch overlap = new CountDownLatch(2), release = new CountDownLatch(1);
    static final AtomicInteger active = new AtomicInteger(), maximum = new AtomicInteger();
    @Configuration @EnableScheduling
    static class Config {
        @Bean ThreadPoolTaskScheduler taskScheduler() {
            var s = new ThreadPoolTaskScheduler(); s.setPoolSize(2); s.setThreadNamePrefix("schedule-32-");
            s.setAwaitTerminationSeconds(5); return s;
        }
        @Bean Jobs jobs() { return new Jobs(); }
    }
    static class Jobs {
        @Scheduled(fixedDelay = 100000) @Scheduled(fixedRate = 100000)
        public void twice() {
            int n = active.incrementAndGet(); maximum.accumulateAndGet(n, Math::max); overlap.countDown();
            try { await(release); } finally { active.decrementAndGet(); }
        }
    }
    public static void main(String[] args) throws Exception {
        Instant start = Instant.parse("2026-10-02T00:00:00Z"), finish = start.plusSeconds(25);
        var previous = new SimpleTriggerContext(start, start, finish);
        var rate = new PeriodicTrigger(Duration.ofSeconds(10)); rate.setFixedRate(true);
        var delay = new PeriodicTrigger(Duration.ofSeconds(10));
        Checks.check(rate.nextExecution(previous).equals(start.plusSeconds(10)), "32 fixedRate based on scheduled time");
        Checks.check(delay.nextExecution(previous).equals(finish.plusSeconds(10)), "32 fixedDelay based on completion");
        var cron = new CronTrigger("0 0 9 * * *", ZoneId.of("Asia/Shanghai"));
        var clock = new SimpleTriggerContext(Clock.fixed(start, ZoneOffset.UTC));
        Checks.check(cron.nextExecution(clock).equals(Instant.parse("2026-10-02T01:00:00Z")), "32 cron explicit Shanghai zone");
        var context = new AnnotationConfigApplicationContext(Config.class);
        var scheduler = context.getBean(ThreadPoolTaskScheduler.class);
        try { await(overlap); Checks.check(maximum.get() == 2, "32 two registrations overlap on pool two"); }
        finally { release.countDown(); context.close(); }
        Checks.check(active.get() == 0, "32 annotated tasks released");
        Checks.check(scheduler.getScheduledThreadPoolExecutor().isTerminated(), "32 context closes scheduler");
        var s = new ThreadPoolTaskScheduler(); s.setPoolSize(2); s.setAwaitTerminationSeconds(5);
        var errors = new AtomicInteger(); s.setErrorHandler(e -> errors.incrementAndGet()); s.initialize();
        var rounds = new CountDownLatch(3); var inTask = new AtomicInteger(); var max = new AtomicInteger();
        ScheduledFuture<?> future = null;
        try {
            future = s.scheduleAtFixedRate(() -> {
                int n = inTask.incrementAndGet(); max.accumulateAndGet(n, Math::max);
                try { rounds.countDown(); throw new IllegalStateException("expected periodic failure"); }
                finally { inTask.decrementAndGet(); }
            }, Duration.ofMillis(10));
            await(rounds); future.cancel(false);
        } finally { if (future != null) future.cancel(false); s.shutdown(); }
        Checks.check(s.getScheduledThreadPoolExecutor().awaitTermination(5, TimeUnit.SECONDS), "32 standalone scheduler terminated");
        Checks.check(max.get() == 1, "32 single periodic registration nonoverlap");
        Checks.check(errors.get() >= 3, "32 suppressing handler permits subsequent executions");
        Checks.check(future.isCancelled(), "32 future cancelled");
    }
}
