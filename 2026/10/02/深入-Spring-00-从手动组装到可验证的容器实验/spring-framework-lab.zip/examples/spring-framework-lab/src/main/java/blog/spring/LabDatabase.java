package blog.spring;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class LabDatabase {
    private LabDatabase() {}

    public static String url() {
        return System.getProperty("spring.lab.jdbc.url",
                "jdbc:postgresql://127.0.0.1:55432/spring_lab?connectTimeout=3&socketTimeout=5");
    }

    public static String user() {
        return System.getProperty("spring.lab.jdbc.user", "spring_lab");
    }

    public static Connection observer() throws SQLException {
        Connection connection = DriverManager.getConnection(url(), user(), "");
        connection.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
        return connection;
    }

    public static HikariDataSource pool(String name, int maximum) {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(url());
        config.setUsername(user());
        config.setPoolName(name);
        config.setMaximumPoolSize(maximum);
        config.setMinimumIdle(0);
        config.setConnectionTimeout(1500);
        config.setTransactionIsolation("TRANSACTION_READ_COMMITTED");
        return new HikariDataSource(config);
    }
}
