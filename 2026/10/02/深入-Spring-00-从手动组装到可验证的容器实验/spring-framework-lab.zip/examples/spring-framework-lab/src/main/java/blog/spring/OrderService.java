package blog.spring;

import java.math.BigDecimal;
import java.util.Objects;

public class OrderService {
    private final OrderRepository repository;
    private final PricePolicy policy;
    public OrderService(OrderRepository repository, PricePolicy policy) {
        this.repository = Objects.requireNonNull(repository);
        this.policy = Objects.requireNonNull(policy);
    }
    public BigDecimal place(int quantity) {
        BigDecimal amount = policy.total(quantity);
        repository.save(amount);
        return amount;
    }
    public OrderRepository repository() { return repository; }
}
