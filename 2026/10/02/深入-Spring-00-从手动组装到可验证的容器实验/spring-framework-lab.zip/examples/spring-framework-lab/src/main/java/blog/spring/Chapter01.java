package blog.spring;

import org.springframework.context.support.GenericApplicationContext;
import static blog.spring.Checks.*;

public class Chapter01 {
    public static class Counted { static int created; public Counted() { created++; } }
    public static void main(String[] args) {
        Counted.created = 0;
        try (var context = new GenericApplicationContext()) {
            context.registerBean("singleton", Counted.class);
            context.registerBean("prototype", Counted.class, d -> d.setScope("prototype"));
            check(context.containsBeanDefinition("singleton") && !context.getBeanFactory().containsSingleton("singleton") && Counted.created == 0,
                "01 definition registered before instance creation");
            context.refresh();
            var managed = context.getBean("singleton");
            check(managed == context.getBean("singleton"), "01 singleton lookup identity");
            check(managed != new Counted(), "01 new object is outside container");
            check(context.getBean("prototype") != context.getBean("prototype"), "01 prototype lookup creates distinct objects");
            check(Counted.created == 4, "01 one singleton + manual + two prototype instances");
        }
        try (var first = new GenericApplicationContext(); var second = new GenericApplicationContext()) {
            first.registerBean("sameName", Counted.class);
            first.registerBean("otherName", Counted.class);
            second.registerBean("sameName", Counted.class);
            first.refresh(); second.refresh();
            check(first.getBean("sameName") != second.getBean("sameName"), "01 same name in separate containers has separate singleton identity");
            check(first.getBean("sameName") != first.getBean("otherName"), "01 two definitions of same class have distinct singleton instances");
        }
        System.out.println("CHAPTER 01 PASS");
    }
}
