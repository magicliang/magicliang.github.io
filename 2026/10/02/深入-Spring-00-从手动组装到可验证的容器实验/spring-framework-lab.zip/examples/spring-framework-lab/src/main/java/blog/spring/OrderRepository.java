package blog.spring;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.DisposableBean;

public class OrderRepository implements DisposableBean {
    private final List<BigDecimal> orders = new ArrayList<>();
    private boolean closed;
    public void save(BigDecimal amount) {
        if (closed) throw new IllegalStateException("repository closed");
        if (amount == null || amount.signum() <= 0) throw new IllegalArgumentException("positive amount required");
        orders.add(amount);
    }
    public int count() { return orders.size(); }
    public boolean closed() { return closed; }
    @Override public void destroy() { closed = true; }
}
