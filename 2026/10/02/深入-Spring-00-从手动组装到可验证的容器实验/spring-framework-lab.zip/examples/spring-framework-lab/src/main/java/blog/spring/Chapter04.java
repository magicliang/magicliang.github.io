package blog.spring;

import org.springframework.context.annotation.*;
import org.springframework.stereotype.Component;
import static blog.spring.Checks.*;

public class Chapter04 {
    @Component public static class Scanned { }
    public static class Imported { }
    @Configuration
    @Import(Imported.class)
    @ComponentScan(basePackageClasses=Chapter04.class, useDefaultFilters=false,
        includeFilters=@ComponentScan.Filter(type=FilterType.ASSIGNABLE_TYPE, classes=Scanned.class))
    public static class Discovery { }
    @Configuration public static class Full {
        @Bean OrderRepository repository() { return new OrderRepository(); }
        @Bean OrderService service() { return new OrderService(repository(), new PricePolicy()); }
    }
    @Configuration(proxyBeanMethods=false) public static class Lite {
        @Bean OrderRepository repository() { return new OrderRepository(); }
        @Bean OrderService service() { return new OrderService(repository(), new PricePolicy()); }
        @Bean OrderService injected(OrderRepository repository) { return new OrderService(repository, new PricePolicy()); }
    }
    public static void main(String[] args) {
        try (var context = new AnnotationConfigApplicationContext(Discovery.class)) {
            check(context.getBean(Scanned.class) != null, "04 component scan registers component");
            check(context.getBean(Imported.class) != null, "04 Import registers explicit type");
        }
        try (var context = new AnnotationConfigApplicationContext(Full.class)) {
            check(context.getBean(OrderService.class).repository() == context.getBean(OrderRepository.class), "04 full configuration intercepts direct Bean call");
        }
        OrderRepository unmanaged;
        try (var context = new AnnotationConfigApplicationContext(Lite.class)) {
            unmanaged = context.getBean("service", OrderService.class).repository();
            check(unmanaged != context.getBean(OrderRepository.class), "04 lite direct Bean call creates unmanaged repository");
            check(context.getBean("injected", OrderService.class).repository() == context.getBean(OrderRepository.class), "04 lite method parameter restores managed injection");
        }
        check(!unmanaged.closed(), "04 context cannot destroy repository made by ordinary direct call");
        unmanaged.destroy();
        System.out.println("CHAPTER 04 PASS");
    }
}
