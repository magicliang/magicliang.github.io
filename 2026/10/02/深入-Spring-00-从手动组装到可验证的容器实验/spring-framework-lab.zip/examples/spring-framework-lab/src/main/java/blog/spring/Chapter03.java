package blog.spring;

import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.*;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.support.GenericApplicationContext;
import static blog.spring.Checks.*;

public class Chapter03 {
    static final List<String> events = new ArrayList<>();
    public interface Operation { String execute(); }
    public static class Target implements Operation, InitializingBean, DisposableBean {
        public Target() { events.add("construct"); }
        public void afterPropertiesSet() { events.add("init"); }
        public String execute() { return "order"; }
        public void destroy() { events.add("destroy"); }
    }
    public static class Broken { public Broken() { throw new IllegalStateException("intentional bean creation failure"); } }
    public static class PrepareFailure extends GenericApplicationContext {
        @Override protected void prepareRefresh() {
            super.prepareRefresh();
            throw new IllegalStateException("intentional prepareRefresh failure");
        }
    }
    private static void failureBoundary(String phase) {
        events.clear();
        try (var context = phase.equals("prepareRefresh") ? new PrepareFailure() : new GenericApplicationContext()) {
            context.registerBean("precreated", Target.class);
            // Deliberately create a disposable singleton before refresh, to observe cleanup boundaries.
            context.getBeanFactory().getBean("precreated");
            if (phase.equals("factory")) context.addBeanFactoryPostProcessor(factory -> {
                throw new IllegalStateException("intentional factory post-processor failure");
            });
            if (phase.equals("BPP")) context.registerBean("brokenProcessor", BeanPostProcessor.class, () -> {
                throw new IllegalStateException("intentional BPP creation failure");
            });
            fails(RuntimeException.class, context::refresh, "03 " + phase + " failure propagates");
            boolean outsideCatch = phase.equals("prepareRefresh");
            check(events.contains("destroy") != outsideCatch, "03 " + phase + " cleanup boundary events=" + events);
            check(context.isActive() == outsideCatch, "03 " + phase + " active=" + context.isActive());
            check(context.getBeanFactory().containsSingleton("precreated") == outsideCatch, "03 " + phase + " singleton retention=" + context.getBeanFactory().containsSingleton("precreated"));
        }
        check(events.getLast().equals("destroy"), "03 " + phase + " explicit close leaves disposable destroyed");
    }
    public static void main(String[] args) {
        events.clear();
        try (var context = new GenericApplicationContext()) {
            context.addBeanFactoryPostProcessor((BeanDefinitionRegistryPostProcessor) registry -> events.add("registry"));
            context.addBeanFactoryPostProcessor(factory -> events.add("factory"));
            context.registerBean("postProcessor", BeanPostProcessor.class, () -> new BeanPostProcessor() {
                public Object postProcessBeforeInitialization(Object bean, String name) {
                    if (name.equals("target")) events.add("before");
                    return bean;
                }
                public Object postProcessAfterInitialization(Object bean, String name) {
                    if (!name.equals("target")) return bean;
                    events.add("after");
                    return Proxy.newProxyInstance(Operation.class.getClassLoader(), new Class<?>[]{Operation.class},
                        (proxy, method, arguments) -> method.invoke(bean, arguments));
                }
            });
            context.registerBean("target", Target.class);
            context.addApplicationListener(event -> { if (event instanceof ContextRefreshedEvent) events.add("refreshed"); });
            context.refresh();
            check(events.equals(List.of("registry", "factory", "construct", "before", "init", "after", "refreshed")), "03 refresh phase order " + events);
            var operation = context.getBean("target", Operation.class);
            check(Proxy.isProxyClass(operation.getClass()) && operation.execute().equals("order"), "03 BPP wrapper preserves callable behavior");
        }
        check(events.getLast().equals("destroy"), "03 close destroys original target behind wrapper");
        events.clear();
        try (var context = new GenericApplicationContext()) {
            context.registerBean("first", Target.class);
            context.registerBean("broken", Broken.class, d -> d.setDependsOn("first"));
            fails(BeanCreationException.class, context::refresh, "03 singleton creation failure cancels refresh");
            check(events.equals(List.of("construct", "init", "destroy")), "03 failed refresh destroys already created disposable singleton " + events);
            check(!context.isActive(), "03 failed context inactive");
        }
        failureBoundary("factory");
        failureBoundary("BPP");
        failureBoundary("prepareRefresh");
        System.out.println("CHAPTER 03 PASS");
    }
}
