package blog.spring;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.context.support.GenericApplicationContext;
import static blog.spring.Checks.*;

public class Chapter06 {
    public static class Product {
        static int created;
        public Product() { created++; }
        public static Product make() { return new Product(); }
    }
    public static class Maker { public Product make() { return new Product(); } }
    public static class ProductFactory implements FactoryBean<Product> {
        int calls;
        public Product getObject() { calls++; return new Product(); }
        public Class<?> getObjectType() { return Product.class; }
        public boolean isSingleton() { return true; }
    }
    public static class PrototypeFactory extends ProductFactory { public boolean isSingleton() { return false; } }
    @SuppressWarnings("rawtypes")
    public static class RawFactory implements FactoryBean {
        static int factories;
        static int products;
        public RawFactory() { factories++; }
        public Object getObject() { products++; return new Product(); }
        public Class<?> getObjectType() { return Product.class; }
    }
    public record EagerConsumer(Product product) { }
    public static void main(String[] args) {
        Product.created = 0;
        try (var context = new GenericApplicationContext()) {
            context.registerBean("constructor", Product.class);
            var staticFactory = new RootBeanDefinition(Product.class); staticFactory.setFactoryMethodName("make");
            context.registerBeanDefinition("staticFactory", staticFactory);
            context.registerBean("maker", Maker.class);
            var instanceFactory = new RootBeanDefinition(Product.class);
            instanceFactory.setFactoryBeanName("maker"); instanceFactory.setFactoryMethodName("make");
            context.registerBeanDefinition("instanceFactory", instanceFactory);
            context.registerBean("product", ProductFactory.class);
            context.registerBean("uncached", PrototypeFactory.class);
            context.registerBean("lazy", Product.class, d -> d.setLazyInit(true));
            context.registerBean("prototype", Product.class, d -> d.setScope("prototype"));
            context.refresh();
            check(Product.created == 3, "06 constructor/static/instance factory eagerly create three products");
            check(context.getBean("constructor") instanceof Product && context.getBean("staticFactory") instanceof Product && context.getBean("instanceFactory") instanceof Product, "06 three creation mechanisms return products");
            var factory = context.getBean("&product", ProductFactory.class);
            check(factory.calls == 0, "06 ordinary FactoryBean itself eager but product not yet created");
            check(context.getBean("product") == context.getBean("product") && factory.calls == 1, "06 FactoryBean singleton product cached");
            check(context.getBean("&product") == factory, "06 ampersand retrieves factory identity");
            var uncached = context.getBean("&uncached", PrototypeFactory.class);
            check(context.getBean("uncached") != context.getBean("uncached") && uncached.calls == 2, "06 non-singleton FactoryBean creates each product");
            int before = Product.created;
            context.getBeanFactory().getBeanProvider(Product.class);
            check(Product.created == before, "06 provider acquisition does not instantiate target");
            check(context.getBean("lazy") == context.getBean("lazy") && Product.created == before + 1, "06 lazy singleton initialized once on lookup");
            var prototypeFactory = new org.springframework.beans.factory.support.DefaultListableBeanFactory();
            var definition = new RootBeanDefinition(Product.class);
            definition.setScope("prototype");
            prototypeFactory.registerBeanDefinition("product", definition);
            ObjectProvider<Product> prototypes = prototypeFactory.getBeanProvider(Product.class);
            before = Product.created;
            check(prototypes.getObject() != prototypes.getObject() && Product.created == before + 2, "06 provider honors prototype scope per lookup");
        }
        RawFactory.factories = RawFactory.products = 0;
        try (var context = new GenericApplicationContext()) {
            context.registerBean("raw", RawFactory.class, d -> d.setLazyInit(true));
            context.refresh();
            check(context.getBeanFactory().getType("raw", false) == null && RawFactory.factories == 0, "06 raw FactoryBean type query without init stays unknown and uncreated");
            check(context.getType("raw") == Product.class && RawFactory.factories == 1 && RawFactory.products == 0, "06 allowed type query constructs raw factory but not product");
            context.getBean("raw");
            check(RawFactory.products == 1, "06 raw factory product created only on product lookup");
        }
        Product.created = 0;
        try (var context = new GenericApplicationContext()) {
            context.registerBean("lazyDependency", Product.class, d -> d.setLazyInit(true));
            var eager = new RootBeanDefinition(EagerConsumer.class);
            eager.setAutowireMode(RootBeanDefinition.AUTOWIRE_CONSTRUCTOR);
            context.registerBeanDefinition("eagerConsumer", eager);
            context.refresh();
            check(Product.created == 1 && context.getBean(EagerConsumer.class).product() == context.getBean(Product.class), "06 eager constructor dependency forces lazy singleton creation during refresh");
        }
        System.out.println("CHAPTER 06 PASS");
    }
}
