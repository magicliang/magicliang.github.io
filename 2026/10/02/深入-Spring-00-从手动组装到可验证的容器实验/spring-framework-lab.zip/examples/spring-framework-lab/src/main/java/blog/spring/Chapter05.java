package blog.spring;

import java.util.List;
import org.springframework.beans.factory.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.*;
import static blog.spring.Checks.*;

public class Chapter05 {
    public interface Channel { }
    public static class Web implements Channel { }
    public static class Store implements Channel { }
    public record NeedsChannel(Channel channel) { }
    public interface Box<T> { T value(); }
    public static class Expensive { static int created; public Expensive() { created++; } }
    public record Selection(Channel primary, Channel qualified, List<Channel> all, Box<String> generic, ObjectProvider<Expensive> provider) { }
    @Configuration(proxyBeanMethods=false) public static class Config {
        @Bean @Primary Channel web() { return new Web(); }
        @Bean Channel store() { return new Store(); }
        @Bean Box<String> textBox() { return () -> "order"; }
        @Bean Box<Integer> integerBox() { return () -> 42; }
        @Bean @Lazy Expensive expensive() { return new Expensive(); }
        @Bean Selection selection(Channel channel, @Qualifier("store") Channel store, List<Channel> all,
                                  Box<String> generic, ObjectProvider<Expensive> provider) {
            return new Selection(channel, store, all, generic, provider);
        }
    }
    public static void main(String[] args) {
        try (var zero = new AnnotationConfigApplicationContext()) {
            zero.register(NeedsChannel.class);
            var failure = fails(UnsatisfiedDependencyException.class, zero::refresh, "05 zero candidates fails constructor injection");
            check(failure.getMostSpecificCause() instanceof NoSuchBeanDefinitionException, "05 zero failure root is missing candidate");
        }
        try (var one = new AnnotationConfigApplicationContext()) {
            one.register(NeedsChannel.class, Web.class); one.refresh();
            check(one.getBean(NeedsChannel.class).channel() == one.getBean(Web.class), "05 one candidate injected");
        }
        try (var many = new AnnotationConfigApplicationContext()) {
            many.register(NeedsChannel.class, Web.class, Store.class);
            var failure = fails(UnsatisfiedDependencyException.class, many::refresh, "05 multiple candidates fail without selection");
            check(failure.getMostSpecificCause() instanceof NoUniqueBeanDefinitionException, "05 multiple failure root is ambiguity");
        }
        Expensive.created = 0;
        try (var context = new AnnotationConfigApplicationContext(Config.class)) {
            var selection = context.getBean(Selection.class);
            check(selection.primary() == context.getBean("web"), "05 Primary resolves single injection");
            check(selection.qualified() == context.getBean("store"), "05 Qualifier narrows candidate");
            check(selection.all().size() == 2 && selection.all().containsAll(List.of(selection.primary(), selection.qualified())), "05 collection contains both even with Primary");
            check(selection.generic().value().equals("order"), "05 generic String candidate selected");
            check(Expensive.created == 0, "05 ObjectProvider injection leaves lazy target uncreated");
            check(selection.provider().getObject() == selection.provider().getObject() && Expensive.created == 1, "05 provider resolves one lazy singleton on demand");
        }
        System.out.println("CHAPTER 05 PASS");
    }
}
