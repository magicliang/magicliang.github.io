package blog.spring;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.DefaultTransactionStatus;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.transaction.support.TransactionTemplate;
import static blog.spring.Checks.check;
import static blog.spring.Checks.fails;

public final class Chapter19 {
    private static final String TABLE = "spring_ch19_orders";

    public static void main(String[] args) throws Exception {
        try (var pool = LabDatabase.pool("chapter19", 3)) {
            var jdbc = new JdbcTemplate(pool);
            jdbc.setQueryTimeout(5);
            jdbc.execute("CREATE TABLE IF NOT EXISTS " + TABLE
                    + " (id integer PRIMARY KEY, quantity integer CHECK(quantity>0), amount numeric(12,2))");
            jdbc.update("DELETE FROM " + TABLE);
            try (Connection connection = pool.getConnection()) {
                connection.setAutoCommit(false);
                insert(connection, 1);
                check(count(1) == 0, "native JDBC uncommitted row hidden from independent READ COMMITTED connection");
                connection.commit();
                check(count(1) == 1, "native JDBC commit visible independently");
                insert(connection, 2);
                connection.rollback();
                check(count(2) == 0, "native JDBC rollback leaves no row");
            }

            var manager = new ObservedManager(pool);
            var template = new TransactionTemplate(manager);
            template.setName("order-write");
            template.setTimeout(5);
            BigDecimal amount = template.execute(status -> {
                Connection bound = DataSourceUtils.getConnection(pool);
                try {
                    check(status.isNewTransaction() && !bound.getAutoCommit(), "template opens physical transaction with autocommit false");
                    check(TransactionSynchronizationManager.hasResource(pool)
                            && TransactionSynchronizationManager.isActualTransactionActive(), "holder and actual transaction bound to current thread");
                    check(bound == DataSourceUtils.getConnection(pool), "DataSourceUtils reuses same bound connection");
                    jdbc.update("INSERT INTO " + TABLE + " VALUES (3,2,25.00)");
                    check(count(3) == 0, "SQL success before commit is not visible independently");
                    template.execute(inner -> {
                        check(!inner.isNewTransaction(), "inner REQUIRED participates without a new physical transaction");
                        check(bound == DataSourceUtils.getConnection(pool), "participating scope keeps same physical connection");
                        jdbc.update("INSERT INTO " + TABLE + " VALUES (4,2,25.00)");
                        return null;
                    });
                    System.out.println("SQL backend=" + scalar(bound, "SELECT pg_backend_pid()")
                            + " transaction=" + scalar(bound, "SELECT pg_current_xact_id_if_assigned()")
                            + " isolation=" + bound.getTransactionIsolation());
                    return new BigDecimal("25.00");
                } catch (SQLException failure) {
                    throw new IllegalStateException(failure);
                } finally {
                    DataSourceUtils.releaseConnection(bound, pool);
                }
            });
            check(amount.compareTo(new BigDecimal("25.00")) == 0 && count(3) == 1 && count(4) == 1,
                    "outer template returns after commit and both rows visible independently");
            check(manager.begins == 1 && manager.commits == 1, "two logical REQUIRED scopes have one physical begin and commit");
            check(!TransactionSynchronizationManager.hasResource(pool)
                    && !TransactionSynchronizationManager.isSynchronizationActive(), "completion removes thread resource and synchronization");

            fails(IllegalStateException.class, () -> template.execute(status -> {
                jdbc.update("INSERT INTO " + TABLE + " VALUES (5,2,25.00)");
                throw new IllegalStateException("business rejection");
            }), "uncaught runtime exception crosses template boundary");
            check(count(5) == 0 && manager.rollbacks == 1, "runtime failure rolls back physical transaction");
            String returned = template.execute(status -> {
                jdbc.update("INSERT INTO " + TABLE + " VALUES (6,2,25.00)");
                status.setRollbackOnly();
                return "accepted-by-callback";
            });
            check("accepted-by-callback".equals(returned) && count(6) == 0,
                    "normal callback result does not imply database commit after rollback-only");

            AtomicInteger memory = new AtomicInteger();
            fails(IllegalStateException.class, () -> template.execute(status -> {
                jdbc.update("INSERT INTO " + TABLE + " VALUES (8,2,25.00)");
                memory.incrementAndGet();
                try (Connection direct = pool.getConnection()) {
                    check(direct.getAutoCommit() && !DataSourceUtils.isConnectionTransactional(direct, pool),
                            "direct pool connection does not join bound transaction");
                    insert(direct, 7);
                } catch (SQLException failure) {
                    throw new IllegalStateException(failure);
                }
                throw new IllegalStateException("rollback outer only");
            }), "outer rollback with independently autocommitted write");
            check(count(7) == 1 && count(8) == 0 && memory.get() == 1,
                    "rollback covers participating SQL but neither independent SQL nor memory mutation");
            check(pool.getHikariPoolMXBean().getActiveConnections() == 0, "all pool leases returned");
            try (Connection restored = pool.getConnection()) {
                check(restored.getAutoCommit() && restored.getTransactionIsolation() == Connection.TRANSACTION_READ_COMMITTED,
                        "next lease has autocommit and isolation restored");
            }
            check(!TransactionSynchronizationManager.hasResource(pool), "failure paths also leave no bound holder");
        }
        System.out.println("CHAPTER19 PASS");
    }

    private static void insert(Connection connection, int id) throws SQLException {
        try (var statement = connection.prepareStatement("INSERT INTO " + TABLE + " VALUES (?,2,25.00)")) {
            statement.setQueryTimeout(5);
            statement.setInt(1, id);
            statement.executeUpdate();
        }
    }

    private static int count(int id) {
        try (Connection observer = LabDatabase.observer();
                var statement = observer.prepareStatement("SELECT count(*) FROM " + TABLE + " WHERE id=?")) {
            statement.setQueryTimeout(5);
            statement.setInt(1, id);
            try (var rows = statement.executeQuery()) {
                rows.next();
                return rows.getInt(1);
            }
        } catch (SQLException failure) {
            throw new IllegalStateException(failure);
        }
    }

    private static Object scalar(Connection connection, String sql) throws SQLException {
        try (var statement = connection.createStatement(); var rows = statement.executeQuery(sql)) {
            rows.next();
            return rows.getObject(1);
        }
    }

    private static final class ObservedManager extends DataSourceTransactionManager {
        int begins;
        int commits;
        int rollbacks;
        int sequence;
        ObservedManager(javax.sql.DataSource source) { super(source); }
        void trace(String stage) {
            System.out.println("TX " + (++sequence) + " " + stage + " thread=" + Thread.currentThread().getName());
        }
        @Override protected void doBegin(Object transaction, TransactionDefinition definition) {
            super.doBegin(transaction, definition);
            begins++;
            trace("begin " + definition.getName());
        }
        @Override protected void doCommit(DefaultTransactionStatus status) {
            super.doCommit(status);
            commits++;
            trace("commit confirmed");
        }
        @Override protected void doRollback(DefaultTransactionStatus status) {
            super.doRollback(status);
            rollbacks++;
            trace("rollback confirmed");
        }
        @Override protected void doCleanupAfterCompletion(Object transaction) {
            super.doCleanupAfterCompletion(transaction);
            trace("cleanup");
        }
    }
}
