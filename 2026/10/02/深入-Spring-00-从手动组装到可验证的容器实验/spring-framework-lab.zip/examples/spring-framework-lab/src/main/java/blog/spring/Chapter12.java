package blog.spring;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import org.springframework.context.*;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.event.*;
import org.springframework.context.event.EventListener;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import static blog.spring.Checks.*;

public class Chapter12 {
    static final class OrderPlaced extends ApplicationEvent {
        final int depth;
        OrderPlaced(int depth) { super("order-42"); this.depth = depth; }
    }
    static class Audit {
        final List<String> trace = new ArrayList<>();
        Thread listenerThread;
        final ApplicationEventPublisher publisher;
        Audit(ApplicationEventPublisher publisher) { this.publisher = publisher; }
        @EventListener @Order(0)
        public void first(OrderPlaced event) {
            listenerThread = Thread.currentThread(); trace.add("first:" + event.depth);
            if (event.depth == 0) publisher.publishEvent(new OrderPlaced(1));
        }
        @EventListener @Order(1)
        public void second(OrderPlaced event) { trace.add("second:" + event.depth); }
    }
    static class Listener implements ApplicationListener<OrderPlaced>, Ordered {
        final int order; final java.util.function.Consumer<OrderPlaced> action;
        Listener(int order, java.util.function.Consumer<OrderPlaced> action) { this.order = order; this.action = action; }
        public int getOrder() { return order; }
        public void onApplicationEvent(OrderPlaced event) { action.accept(event); }
    }
    static void await(CountDownLatch latch) {
        try { if (!latch.await(5, TimeUnit.SECONDS)) throw new AssertionError("latch deadline exceeded"); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IllegalStateException(e); }
    }
    public static void main(String[] args) throws Exception {
        Thread publisher = Thread.currentThread();
        try (var context = new AnnotationConfigApplicationContext()) {
            context.registerBean(Audit.class, () -> new Audit(context)); context.refresh();
            context.publishEvent(new OrderPlaced(0));
            Audit audit = context.getBean(Audit.class);
            check(audit.listenerThread == publisher, "default event listener uses publisher thread");
            check(audit.trace.equals(List.of("first:0", "first:1", "second:1", "second:0")),
                "synchronous recursion completes nested publication before outer second listener");
            System.out.println("TRACE " + audit.trace);
        }
        var multicaster = new SimpleApplicationEventMulticaster();
        List<String> trace = new ArrayList<>();
        multicaster.addApplicationListener(new Listener(0, e -> { trace.add("failed"); throw new IllegalStateException("notification failed"); }));
        multicaster.addApplicationListener(new Listener(1, e -> trace.add("later")));
        fails(IllegalStateException.class, () -> multicaster.multicastEvent(new OrderPlaced(0)),
            "default synchronous listener exception propagates to publisher");
        check(trace.equals(List.of("failed")), "exception aborts remaining synchronous listeners");
        trace.clear();
        AtomicReference<Throwable> observed = new AtomicReference<>();
        multicaster.setErrorHandler(observed::set);
        multicaster.multicastEvent(new OrderPlaced(0));
        check(observed.get() instanceof IllegalStateException && trace.equals(List.of("failed", "later")),
            "nonthrowing error handler records failure and permits next listener");

        ExecutorService executor = Executors.newFixedThreadPool(2);
        CountDownLatch entered = new CountDownLatch(1), release = new CountDownLatch(1);
        CountDownLatch completed = new CountDownLatch(1), errorReceived = new CountDownLatch(1);
        AtomicReference<Thread> worker = new AtomicReference<>();
        AtomicReference<Throwable> asyncFailure = new AtomicReference<>();
        var async = new SimpleApplicationEventMulticaster();
        async.setTaskExecutor(executor);
        async.setErrorHandler(error -> { asyncFailure.set(error); errorReceived.countDown(); });
        async.addApplicationListener(new Listener(0, e -> {
            worker.set(Thread.currentThread()); entered.countDown(); await(release); completed.countDown();
        }));
        async.addApplicationListener(new Listener(1, e -> { throw new IllegalStateException("async failure"); }));
        try {
            async.multicastEvent(new OrderPlaced(0));
            await(entered); await(errorReceived);
            check(completed.getCount() == 1, "async publish returns while listener remains blocked");
            check(worker.get() != publisher, "executor runs listener on different thread");
            check(asyncFailure.get() instanceof IllegalStateException, "async exception observed by error handler");
            release.countDown(); await(completed);
            check(completed.getCount() == 0, "business completion requires separate signal");

            AtomicReference<Thread> forcedThread = new AtomicReference<>();
            var mixed = new SimpleApplicationEventMulticaster(); mixed.setTaskExecutor(executor);
            mixed.addApplicationListener(new Listener(0, e -> forcedThread.set(Thread.currentThread())) {
                public boolean supportsAsyncExecution() { return false; }
            });
            mixed.multicastEvent(new OrderPlaced(0));
            check(forcedThread.get() == publisher, "nonasync listener stays on publisher despite executor");
            mixed.setTaskExecutor(task -> { throw new RejectedExecutionException("controlled rejection"); });
            AtomicReference<Thread> fallback = new AtomicReference<>();
            mixed.addApplicationListener(new Listener(1, e -> fallback.set(Thread.currentThread())));
            mixed.multicastEvent(new OrderPlaced(0));
            check(fallback.get() == publisher, "rejected execution falls back to local invocation");
        } finally {
            release.countDown(); executor.shutdownNow();
            check(executor.awaitTermination(5, TimeUnit.SECONDS), "event executor terminated");
        }
    }
}
