package blog.spring;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.support.TransactionSynchronizationManager;

final class TxChapterSupport {
    private TxChapterSupport() {}
    static void sql(String sql) {
        try (var connection = LabDatabase.observer(); var statement = connection.createStatement()) {
            statement.setQueryTimeout(5);
            statement.execute(sql);
            System.out.println("SQL " + sql);
        } catch (SQLException failure) { throw new IllegalStateException(failure); }
    }
    static List<String> rows(String table) {
        try (var connection = LabDatabase.observer(); var statement = connection.createStatement()) {
            statement.setQueryTimeout(5);
            var result = new ArrayList<String>();
            try (var rows = statement.executeQuery("select label from " + table + " order by label")) {
                while (rows.next()) result.add(rows.getString(1));
            }
            System.out.println("OBSERVER thread=" + Thread.currentThread().getName() + " " + table + "=" + result);
            return result;
        } catch (SQLException failure) { throw new IllegalStateException(failure); }
    }
    static long[] identity(JdbcTemplate jdbc, String label) {
        var result = jdbc.queryForObject("select pg_backend_pid(), txid_current()",
                (rs, row) -> new long[] {rs.getLong(1), rs.getLong(2)});
        System.out.println("TX " + label + " thread=" + Thread.currentThread().getName()
                + " pid=" + result[0] + " xid=" + result[1]
                + " active=" + TransactionSynchronizationManager.isActualTransactionActive());
        return result;
    }
}
