package blog.spring;

import java.util.ArrayList;
import java.util.List;
import org.aopalliance.intercept.MethodInterceptor;
import org.springframework.aop.framework.Advised;
import org.springframework.aop.framework.AopConfigException;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.AopUtils;
import static blog.spring.Checks.*;

public class Chapter14 {
    public interface Orders { String place(); String fixed(); String secretEntry(); }
    public static class OrderTarget implements Orders {
        public String place() { return "order"; }
        public final String fixed() { return "fixed"; }
        public String secretEntry() { return secret(); }
        private String secret() { return "secret"; }
    }
    public static final class FinalTarget implements Orders {
        public String place() { return "order"; }
        public String fixed() { return "fixed"; }
        public String secretEntry() { return "secret"; }
    }
    public static void main(String[] args) throws Exception {
        for (boolean classProxy : new boolean[]{false, true}) {
            var calls = new ArrayList<String>();
            var target = new OrderTarget();
            var factory = new ProxyFactory(target);
            factory.setProxyTargetClass(classProxy);
            factory.addAdvice((MethodInterceptor) invocation -> {
                calls.add(invocation.getMethod().getName());
                return invocation.proceed();
            });
            Orders proxy = (Orders) factory.getProxy();
            System.out.printf("IDENTITY mode=%s proxy=%s@%x target=%s@%x thread=%s%n",
                    classProxy, proxy.getClass().getName(), System.identityHashCode(proxy),
                    target.getClass().getName(), System.identityHashCode(target), Thread.currentThread().getName());
            check(classProxy ? AopUtils.isCglibProxy(proxy) : AopUtils.isJdkDynamicProxy(proxy), "14 proxy strategy " + classProxy);
            check(proxy != target && ((Advised) proxy).getTargetSource().getTarget() == target, "14 target identity " + classProxy);
            check("order".equals(proxy.place()) && calls.equals(List.of("place")), "14 public interception " + classProxy);
            calls.clear();
            check("fixed".equals(proxy.fixed()) && calls.size() == (classProxy ? 0 : 1), "14 final interface method " + classProxy);
            calls.clear();
            check("secret".equals(proxy.secretEntry()) && calls.equals(List.of("secretEntry")), "14 private call not separately advised " + classProxy);
            calls.clear();
            target.place();
            check(calls.isEmpty(), "14 original reference bypass " + classProxy);
            check((proxy instanceof OrderTarget) == classProxy, "14 implementation assignability " + classProxy);
        }
        var finalFactory = new ProxyFactory(new FinalTarget());
        check(AopUtils.isJdkDynamicProxy(finalFactory.getProxy()), "14 final target can implement JDK proxy interface");
        finalFactory.setProxyTargetClass(true);
        fails(AopConfigException.class, finalFactory::getProxy, "14 final class cannot be subclassed");
        System.out.println("RESULT Chapter14 PASS; no threads or external resources created");
    }
}
