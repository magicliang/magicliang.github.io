package blog.spring;

import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.context.annotation.*;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.type.AnnotatedTypeMetadata;
import static blog.spring.Checks.*;

public class Chapter11 {
    static final AtomicInteger created = new AtomicInteger();
    record Pricing(String region, int limit) { Pricing { created.incrementAndGet(); } }
    public static class Enabled implements Condition {
        public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
            return context.getEnvironment().getProperty("spring.lab.enabled", Boolean.class, false);
        }
    }
    @Configuration(proxyBeanMethods = false)
    static class Config {
        @Bean Pricing pricing(org.springframework.core.env.Environment environment) {
            return new Pricing(environment.getRequiredProperty("spring.lab.region"),
                environment.getRequiredProperty("spring.lab.limit", Integer.class));
        }
        @Bean @Profile("prod & !test") String productionRoute() { return "production"; }
        @Bean @Profile("test") String testRoute() { return "test"; }
        @Bean @Conditional(Enabled.class) String notification() { return "enabled"; }
    }
    static AnnotationConfigApplicationContext context(boolean enabled, String... profiles) {
        var context = new AnnotationConfigApplicationContext();
        var env = context.getEnvironment();
        env.setActiveProfiles(profiles);
        env.getPropertySources().addFirst(new MapPropertySource("defaults", Map.of(
            "spring.lab.region", "default", "spring.lab.limit", "3", "spring.lab.enabled", false)));
        env.getPropertySources().addFirst(new MapPropertySource("command", Map.of(
            "spring.lab.region", "east", "spring.lab.enabled", enabled)));
        context.register(Config.class); context.refresh(); return context;
    }
    public static void main(String[] args) {
        created.set(0);
        try (var context = context(true, "prod")) {
            var env = context.getEnvironment();
            Pricing original = context.getBean(Pricing.class);
            check(original.region().equals("east") && original.limit() == 3,
                "first source wins per property and missing key falls through");
            check(context.containsBean("productionRoute") && !context.containsBean("testRoute"),
                "profile expression selects production definition");
            check(context.containsBean("notification"), "true condition registers notification");
            env.getPropertySources().replace("command", new MapPropertySource("command", Map.of(
                "spring.lab.region", "west", "spring.lab.enabled", false)));
            env.setActiveProfiles("test");
            check(env.getProperty("spring.lab.region").equals("west"), "live environment sees replacement");
            check(context.getBean(Pricing.class) == original && original.region().equals("east") && created.get() == 1,
                "existing singleton is not recreated by property changes");
            check(context.containsBean("productionRoute") && !context.containsBean("testRoute")
                && context.containsBean("notification"), "definition selection is not reevaluated after refresh");
            check(env.resolveRequiredPlaceholders("orders-${spring.lab.region}").equals("orders-west"),
                "explicit placeholder lookup reads current property sources");
            fails(IllegalStateException.class, () -> env.getRequiredProperty("spring.lab.missing"),
                "required property fails explicitly");
        }
        try (var context = context(false, "test")) {
            check(!context.containsBean("productionRoute") && context.containsBean("testRoute"),
                "new context applies test profile");
            check(!context.containsBean("notification"), "false condition omits definition");
            check(created.get() == 2, "new context constructs its own pricing singleton");
        }
    }
}
