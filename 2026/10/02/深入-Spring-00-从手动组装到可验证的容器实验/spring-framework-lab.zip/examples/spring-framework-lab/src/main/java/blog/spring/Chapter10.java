package blog.spring;

import java.lang.reflect.Proxy;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.support.ScopeNotActiveException;
import org.springframework.context.annotation.*;
import org.springframework.web.context.request.*;
import static blog.spring.Checks.*;

public class Chapter10 {
    public static class Ticket implements DisposableBean {
        static final AtomicInteger created = new AtomicInteger();
        static final AtomicInteger destroyed = new AtomicInteger();
        final int id = created.incrementAndGet();
        boolean closed;
        public int id() { return id; }
        public void destroy() { if (!closed) { closed = true; destroyed.incrementAndGet(); } }
    }
    record Checkout(Ticket ticket) {}
    record TicketSource(ObjectProvider<Ticket> provider) {}
    @Configuration(proxyBeanMethods = false)
    static class Config {
        @Bean @Scope("prototype") Ticket prototypeTicket() { return new Ticket(); }
        @Bean TicketSource ticketSource(@Qualifier("prototypeTicket") ObjectProvider<Ticket> provider) {
            return new TicketSource(provider);
        }
        @Bean @Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
        Ticket requestTicket() { return new Ticket(); }
    }
    static ServletRequestAttributes request() {
        Map<String, Object> attributes = new HashMap<>();
        HttpServletRequest request = (HttpServletRequest) Proxy.newProxyInstance(
            Chapter10.class.getClassLoader(), new Class<?>[]{HttpServletRequest.class}, (p, m, a) -> {
                return switch (m.getName()) {
                    case "getAttribute" -> attributes.get((String) a[0]);
                    case "setAttribute" -> { attributes.put((String) a[0], a[1]); yield null; }
                    case "removeAttribute" -> { attributes.remove((String) a[0]); yield null; }
                    case "getAttributeNames" -> Collections.enumeration(attributes.keySet());
                    case "getSession" -> null;
                    case "toString" -> "attribute-only-request";
                    default -> throw new UnsupportedOperationException(m.getName());
                };
            });
        return new ServletRequestAttributes(request);
    }
    static class UnsafeCounter { volatile int count; }
    public static void main(String[] args) throws Exception {
        Ticket.created.set(0); Ticket.destroyed.set(0);
        Ticket direct;
        List<Ticket> prototypes = new ArrayList<>();
        try (var context = new AnnotationConfigApplicationContext()) {
            context.getBeanFactory().registerScope("request", new RequestScope());
            context.registerBean("direct", Checkout.class,
                () -> new Checkout(context.getBean("prototypeTicket", Ticket.class)));
            context.register(Config.class); context.refresh();
            direct = context.getBean("direct", Checkout.class).ticket();
            check(context.getBean("direct", Checkout.class).ticket() == direct,
                "singleton retains one injected prototype reference");
            var first = context.getBean("prototypeTicket", Ticket.class);
            var second = context.getBean("prototypeTicket", Ticket.class);
            prototypes.add(first); prototypes.add(second);
            check(first != second && first != direct, "prototype getBean creates distinct instances");
            var namedProvider = context.getBean(TicketSource.class).provider();
            Ticket a = namedProvider.getObject(), b = namedProvider.getObject();
            prototypes.add(a); prototypes.add(b);
            check(a != b, "provider requests prototype per business operation");
            Ticket proxy = context.getBean("requestTicket", Ticket.class);
            check(proxy == context.getBean("requestTicket"), "scoped proxy identity remains singleton");
            fails(ScopeNotActiveException.class, proxy::id, "request target unavailable without binding");
            int firstId;
            var request1 = request();
            try {
                RequestContextHolder.setRequestAttributes(request1);
                firstId = proxy.id();
                check(firstId == proxy.id(), "same request reuses target");
                check(Ticket.destroyed.get() == 0, "target alive before request completion");
            } finally { request1.requestCompleted(); RequestContextHolder.resetRequestAttributes(); }
            check(Ticket.destroyed.get() == 1, "request completion destroys first target");
            var request2 = request();
            try {
                RequestContextHolder.setRequestAttributes(request2);
                check(firstId != proxy.id(), "same proxy resolves second request target");
            } finally { request2.requestCompleted(); RequestContextHolder.resetRequestAttributes(); }
            check(Ticket.destroyed.get() == 2, "both request targets destroyed");
        }
        check(!direct.closed && prototypes.stream().noneMatch(t -> t.closed),
            "context close does not destroy prototypes");
        direct.destroy(); prototypes.forEach(Ticket::destroy);
        check(direct.closed && prototypes.stream().allMatch(t -> t.closed), "prototype owner releases objects");
        try (var context = new AnnotationConfigApplicationContext()) {
            context.registerBean(UnsafeCounter.class); context.refresh();
            var counter = context.getBean(UnsafeCounter.class);
            var barrier = new CyclicBarrier(2);
            ExecutorService pool = Executors.newFixedThreadPool(2);
            try {
                Callable<Void> increment = () -> { int old = counter.count;
                    barrier.await(5, TimeUnit.SECONDS); counter.count = old + 1; return null; };
                Future<Void> x = pool.submit(increment), y = pool.submit(increment);
                x.get(5, TimeUnit.SECONDS); y.get(5, TimeUnit.SECONDS);
                check(counter.count == 1, "two ordered reads cause lost update in singleton");
            } finally { pool.shutdownNow(); check(pool.awaitTermination(5, TimeUnit.SECONDS), "counter pool terminated"); }
        }
        check(RequestContextHolder.getRequestAttributes() == null, "request thread state cleared");
    }
}
