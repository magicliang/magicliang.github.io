package blog.spring;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.*;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

public class Chapter33 {
    static final CountDownLatch syncRequests = new CountDownLatch(2);
    @Configuration @EnableCaching(proxyTargetClass = true)
    static class Config {
        @Bean CacheManager cacheManager() {
            return new ConcurrentMapCacheManager("values", "collision", "normal", "sync") {
                @Override protected org.springframework.cache.Cache createConcurrentMapCache(String name) {
                    if (!name.equals("sync")) return super.createConcurrentMapCache(name);
                    return new org.springframework.cache.concurrent.ConcurrentMapCache(name) {
                        @Override public <T> T get(Object key, Callable<T> loader) {
                            syncRequests.countDown(); return super.get(key, loader);
                        }
                    };
                }
            };
        }
        @Bean Prices prices() { return new Prices(); }
    }
    static class Prices {
        final AtomicInteger loads = new AtomicInteger(), normalLoads = new AtomicInteger(), syncLoads = new AtomicInteger();
        final CountDownLatch both = new CountDownLatch(2), syncStarted = new CountDownLatch(1), syncRelease = new CountDownLatch(1);
        @Cacheable("values") public String read(String key) { return "value-" + loads.incrementAndGet(); }
        public String self(String key) { return read(key); }
        @Cacheable("collision") public String usd(String key) { return "USD"; }
        @Cacheable("collision") public String eur(String key) { return "EUR"; }
        @Cacheable("values") public String broken(String key) { loads.incrementAndGet(); throw new IllegalArgumentException("broken"); }
        @CacheEvict("values") public void evict(String key) {}
        @CachePut(cacheNames = "values", key = "#p0") public String put(String key, String value) { return value; }
        @Cacheable("normal") public String concurrent(String key) {
            normalLoads.incrementAndGet(); both.countDown(); await(both); return "loaded";
        }
        @Cacheable(cacheNames = "sync", sync = true) public String synchronizedLoad(String key) {
            syncLoads.incrementAndGet(); syncStarted.countDown(); await(syncRelease); return "one";
        }
    }
    static void await(CountDownLatch latch) {
        try { if (!latch.await(5, TimeUnit.SECONDS)) throw new AssertionError("latch timeout"); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IllegalStateException(e); }
    }
    public static void main(String[] args) throws Exception {
        try (var context = new AnnotationConfigApplicationContext(Config.class); var pool = LabDatabase.pool("chapter33", 1)) {
            var p = context.getBean(Prices.class);
            // CGLIB proxy fields are not target fields: obtain the managed target for counters only.
            var target = (Prices) ((org.springframework.aop.framework.Advised) p).getTargetSource().getTarget();
            var caches = context.getBean(CacheManager.class);
            Checks.check(p.read("a").equals(p.read("a")) && target.loads.get() == 1, "33 second read hits cache");
            Checks.check(!p.self("a").equals(p.read("a")), "33 self call bypasses cache");
            Checks.check(p.usd("sku").equals("USD") && p.eur("sku").equals("USD"), "33 default key omits method identity");
            Checks.fails(IllegalArgumentException.class, () -> p.broken("bad"), "33 failure escapes");
            Checks.check(caches.getCache("values").get("bad") == null, "33 failing invocation not populated");
            String old = p.read("a"); p.evict("a");
            Checks.check(!p.read("a").equals(old), "33 eviction forces reload");
            var executor = Executors.newFixedThreadPool(2);
            try {
                var a = executor.submit(() -> p.concurrent("same")); var b = executor.submit(() -> p.concurrent("same"));
                Checks.check(a.get(5, TimeUnit.SECONDS).equals(b.get(5, TimeUnit.SECONDS)) && target.normalLoads.get() == 2,
                        "33 concurrent misses execute twice");
                var c = executor.submit(() -> p.synchronizedLoad("same")); await(target.syncStarted);
                var d = executor.submit(() -> p.synchronizedLoad("same")); await(syncRequests);
                target.syncRelease.countDown();
                Checks.check(c.get(5, TimeUnit.SECONDS).equals(d.get(5, TimeUnit.SECONDS)) && target.syncLoads.get() == 1,
                        "33 sync provider loads once");
            } finally { target.syncRelease.countDown(); executor.shutdownNow(); }
            Checks.check(executor.awaitTermination(5, TimeUnit.SECONDS), "33 concurrent clients terminated");
            var jdbc = new JdbcTemplate(pool);
            jdbc.execute("CREATE TABLE IF NOT EXISTS spring_ch33_value (id integer primary key, value text not null)");
            jdbc.update("DELETE FROM spring_ch33_value");
            new TransactionTemplate(new DataSourceTransactionManager(pool)).executeWithoutResult(status -> {
                jdbc.update("INSERT INTO spring_ch33_value VALUES (1, 'uncommitted')");
                p.put("tx", "uncommitted"); status.setRollbackOnly();
            });
            try (var connection = LabDatabase.observer(); var statement = connection.createStatement();
                 var rows = statement.executeQuery("SELECT count(*) FROM spring_ch33_value")) {
                rows.next(); Checks.check(rows.getInt(1) == 0, "33 independent observer confirms database rollback");
            }
            Checks.check("uncommitted".equals(caches.getCache("values").get("tx", String.class)), "33 ordinary cache survives database rollback");
            Checks.check(pool.getHikariPoolMXBean().getActiveConnections() == 0, "33 JDBC lease returned");
        }
    }
}
