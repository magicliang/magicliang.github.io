package blog.spring;

import java.util.*;
import java.util.concurrent.*;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.*;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import static blog.spring.Checks.*;

public class Chapter13 {
    static class Worker implements SmartLifecycle, DisposableBean {
        final String name; final int phase; final List<String> trace;
        volatile boolean running; boolean destroyed;
        ExecutorService executor;
        Worker(String name, int phase, List<String> trace) { this.name = name; this.phase = phase; this.trace = trace; }
        public int getPhase() { return phase; }
        public boolean isRunning() { return running; }
        public void start() {
            executor = Executors.newSingleThreadExecutor();
            try { executor.submit(() -> {}).get(5, TimeUnit.SECONDS); }
            catch (Exception e) { executor.shutdownNow(); throw new IllegalStateException(e); }
            running = true; trace.add("start:" + name);
        }
        public void stop() {
            if (executor != null) {
                executor.shutdownNow();
                try { if (!executor.awaitTermination(5, TimeUnit.SECONDS)) throw new IllegalStateException("executor still live"); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IllegalStateException(e); }
            }
            running = false; trace.add("stop:" + name);
        }
        public void stop(Runnable callback) { stop(); callback.run(); }
        public void destroy() { if (running) stop(); destroyed = true; trace.add("destroy:" + name); }
    }
    static class Failing implements SmartLifecycle {
        public int getPhase() { return 100; }
        public boolean isRunning() { return false; }
        public void start() { throw new IllegalStateException("controlled start failure"); }
        public void stop() {}
    }
    public static void main(String[] args) {
        List<String> trace = new ArrayList<>();
        Worker early = new Worker("early", -10, trace), late = new Worker("late", 10, trace);
        try (var context = new AnnotationConfigApplicationContext()) {
            context.registerBean("early", Worker.class, () -> early);
            context.registerBean("late", Worker.class, () -> late); context.refresh();
            check(trace.equals(List.of("start:early", "start:late")), "smart lifecycle starts by ascending phase");
            check(early.running && late.running, "workers ready after successful refresh");
        }
        check(trace.indexOf("stop:late") < trace.indexOf("stop:early"), "shutdown reverses phase order");
        check(trace.indexOf("stop:early") < trace.indexOf("destroy:late"), "lifecycle stop precedes singleton destruction");
        check(early.destroyed && late.destroyed && early.executor.isTerminated() && late.executor.isTerminated(),
            "close terminates both pools and destroys both beans");
        System.out.println("TRACE " + trace);

        trace.clear();
        Worker dependent = new Worker("dependent", -10, trace), dependency = new Worker("dependency", 10, trace);
        try (var context = new AnnotationConfigApplicationContext()) {
            context.registerBean("dependent", Worker.class, () -> dependent, bd -> bd.setDependsOn("dependency"));
            context.registerBean("dependency", Worker.class, () -> dependency); context.refresh();
            check(trace.equals(List.of("start:dependency", "start:dependent")), "explicit dependency overrides phase at startup");
        }
        check(trace.indexOf("stop:dependent") < trace.indexOf("stop:dependency"), "dependent stops before dependency");
        check(dependent.executor.isTerminated() && dependency.executor.isTerminated(), "dependency scenario pools terminated");

        try (var parent = new AnnotationConfigApplicationContext()) {
            parent.registerBean("route", String.class, () -> "parent");
            parent.registerBean("parentOnly", Integer.class, () -> 42); parent.refresh();
            var child = new AnnotationConfigApplicationContext(); child.setParent(parent);
            try (child) {
                child.registerBean("route", String.class, () -> "child");
                child.registerBean("childOnly", Long.class, () -> 7L); child.refresh();
                check(child.getBean("route").equals("child") && parent.getBean("route").equals("parent"),
                    "child definition shadows parent without mutation");
                check(child.getBean("parentOnly") == parent.getBean("parentOnly"), "missing child name delegates to parent");
                fails(NoSuchBeanDefinitionException.class, () -> parent.getBean("childOnly"), "parent cannot resolve child bean");
                check(!child.containsLocalBean("parentOnly") && child.containsBean("parentOnly"), "local membership differs from hierarchical lookup");
            }
            check(parent.isActive() && parent.getBean("route").equals("parent"), "closing child leaves parent active");
        }

        trace.clear(); Worker survivor = new Worker("survivor", 0, trace);
        var broken = new AnnotationConfigApplicationContext();
        try (broken) {
            broken.registerBean("survivor", Worker.class, () -> survivor);
            broken.registerBean(Failing.class);
            fails(ApplicationContextException.class, broken::refresh, "later lifecycle start fails refresh");
            check(!broken.isActive(), "failed refresh cancels active context state");
            check(!survivor.running && survivor.executor.isTerminated(), "failure stops previously started worker and terminates pool");
            check(survivor.destroyed && trace.contains("destroy:survivor"), "failed refresh destroys singleton resource owner");
        }
        System.out.println("FAILURE TRACE " + trace);
    }
}
