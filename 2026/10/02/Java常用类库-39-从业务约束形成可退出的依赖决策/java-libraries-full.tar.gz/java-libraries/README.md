# Java常用类库：48篇可复跑实验

对应主线00–39与E01–E08，使用合成商品数据。实验POM汇集候选库和故障复现provider，供研究对照，不是生产依赖清单。首批00–02历史结果29tests保留在evidence/00；全量结果以evidence/integration为准。

## 主实验：Java8兼容

实际环境Zulu8u472与Corretto21.0.11。Wrapper固定Maven3.9.14（only-script3.3.4），首次需官方Maven Central网络。Unix使用mvnw，Windows可用mvnw.cmd，但本次未在Windows验证。

38篇需要独立旧Guava jar，放在target外，避免clean时删除。它不进入正常POM类路径：

```bash
mkdir -p /tmp/java-libraries-guava-old
curl --fail --location https://repo.maven.apache.org/maven2/com/google/guava/guava/30.1.1-jre/guava-30.1.1-jre.jar --output /tmp/java-libraries-guava-old/guava-30.1.1-jre.jar
./mvnw -B -ntp -s .mvn/settings.xml -DoldGuavaJar=/tmp/java-libraries-guava-old/guava-30.1.1-jre.jar clean verify
java -cp target/classes blog.libraries.LibraryDecisionDemo
```

切换JDK后clean verify；先归档Surefire XML再切换，避免覆盖证据。按章可用-Dtest=Chapter15Test，E01/E02/E03/E04/E05/E06采用ExtensionNNTest；17篇测试在com.google.common.util.concurrent包中。183项全量测试在两套实际JDK分别通过；现代反射API的Java8分支明确不适用，不能把测试方法计数当所有运行时分支覆盖。

主实验包含JDK基线、Guava、Apache Commons、Jackson、SLF4J/HTTP、Vavr及集合扩展。Product原始编号只拒绝null和空串，不trim、不校验严格SKU；01独立SKU实验和37入口格式规则没有改写基线Product。Catalog保证商户内商品唯一、遇见顺序、返回容器隔离，浅复制不构成任意可变实体的深复制。

SLF4J测试为验证0/1/2 provider使用显式子进程classpath；主测试POM装有测试provider，生产应用应选择一个。测试故意产生的日志和错误fork保留原始输出；正常全量回归要求零失败、零错误、零跳过。

## 独立模块

| 模块 | 编译目标/实际运行 | 验证入口 |
|---|---|---|
| modern | release17，实际JDK21；Java8不适用 | `./mvnw -B -ntp -s .mvn/settings.xml -f modern/pom.xml clean verify` |
| processors | release8，实际JDK8与21 | `./mvnw -B -ntp -s .mvn/settings.xml -f processors/pom.xml clean verify` |
| benchmarks | release17，实际JDK21 | `./mvnw -B -ntp -s .mvn/settings.xml -f benchmarks/pom.xml clean package` |

modern包含31缓存迁移、34JDK HTTP对照、35Mockito外部边界及E07真实Resilience4j，Surefire显式使用固定Mockito5.20.0 javaagent。processors使用MapStruct1.6.3、Lombok1.18.42、binding0.2.0固定处理器，实际生成Java源码/字节码，并比较手写映射、null更新和预期诊断。JDK17/11只属于目标或依赖最低要求，没有作为本次实际运行环境。

基准包需要JMH本机fork协调socket；禁用socket的sandbox运行会失败，不能算有效结果：

```bash
java -jar benchmarks/target/benchmarks.jar blog.libraries.LibraryBenchmarks -f 2 -wi 2 -i 3 -w 1s -r 1s -t 1 -prof gc -rf json -rff benchmarks/target/jmh-result.json
```

36篇有九组真实基准，每组两fork、各三次测量，原始JSON/stdout在evidence/36。单线程1024个整数键、小工作集、简单对象值；平均时间和B/op不代表生产尾延迟、retained heap或所有并发负载。E03的JOL布局无Instrumentation/SA时采用估计，并保留告警，不与分配率混用。

## 交付与范围

evidence按章区分DOC/SOURCE/LAB/NOT_RUN；固定版本和官方源码commit见writing-plans/java-libraries/VERSIONS.md。XML含实际classpath和本机路径，只用于追溯，复跑目录不必相同。37的有界输入、真实localhost HTTP、私有JSON/ZIP暂存目录在成功/失败/取消路径实际验证；借用输入与客户端由调用方关闭，取消只在协作检查点生效。

00篇提供29tests首批历史包；39篇提供全量java-libraries-full.tar.gz与SHA-256，排除target、本地依赖与Wrapper下载缓存。解压后需JDK和网络首次下载依赖；最终验收在独立/tmp副本运行，避免覆盖共享工作区target。

未验证JDK11/17/25实际运行、Windows/Linux、生产部署、视觉浏览器效果、恶意并发目录写入与远端幂等，也未测大工作集共享缓存尾延迟。归档与路径实验依赖可信私有工作目录，循环预算不保证中断正在阻塞的read。
