# 第 34 篇证据账本

## 版本与证据类型

Jackson databind/jsr310 2.20.1，databind SHA4164a2b47d3795a28f7cb838a02c27b77f9adaf4。
SLF4J api/simple/jdk14/jul-to-slf4j 2.0.20，SHA58d80a4fe8f2e811707fcfba4d292b5d62fc2fe9。
HttpClient5 5.6.4，SHA36508cead5c4388d04d20aa7efad5a68595631a0。
AssertJ3.27.6，SHA716b1e0a6a372890cd4b3495b954f57755e99471；Mockito5.20.0，SHA3a1a19ee40f1234048880393343405046fc3fa60。JUnit5.13.4。

DOC=公开契约，SOURCE=固定实现与上游测试阅读，LAB=本地真实运行，NOT_RUN=未运行范围。同一上游的Javadoc、源码、issue不冒充独立来源；本地反例增加运行证据，不等于生产验证。源码摘录及行号见source-inspection.txt，正文引用完整SHA。

| claim | DOC/SOURCE | LAB方法 | 输入与二值观察 |
|---|---|---|---|
| 未消费响应持租约/关闭释放 | InternalExecRuntime.acquireEndpoint；CloseableHttpClient.execute | unconsumedResponseHoldsLeaseUntilClosed | leased1→lease exception→0；后续200；关闭available0 |
| 响应等待与租用不同 | RequestConfig responseTimeout非deadline注释 | responseTimeoutIsNotPoolLeaseTimeout | server entered；SocketTimeoutException；leased0 |
| 错误码/断连/handler异常有不同语义 | CloseableHttpClient try-with-resource；上游TestCloseableHttpClient | statusAndDisconnectAreDifferentAndHandlerReleases | 503 status；error/drop各1次；handler IAE后leased0 |
| 取消不证明远端回滚 | request.cancel真实客户端路径 | cancellationEndsWaitingButDoesNotProveServerRollback | server entered；cancel true；Future IOException；leased0 |
| JDK客户端对照 | java.net.http Java11 API，JDK21实跑 | Chapter34ModernTest两个方法 | 503+body；HttpTimeoutException，不冒称pool lease |

## 最终命令和结果

隔离副本 /tmp/java-libraries-32-35，缓存 /tmp/java-libraries-m2，Maven Wrapper3.9.14；不写共享target。
```sh
JAVA_HOME=<JDK路径> MAVEN_USER_HOME=<仓库>/examples/java-libraries/.maven-user-home ./mvnw -o -B -ntp -s .mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 -Dtest=Chapter32Test,Chapter33Test,Chapter34Test,Chapter35Test clean verify
```
Java8路径 /Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home。
Java21路径 /Users/magicliang/.sdkman/candidates/java/21.0.11-amzn。
两最终命令退出0，各20次；本章tests=4、failures/errors/skipped均0，见jdk8/jdk21-surefire.xml与maven.log。实际环境从XML属性提取到environment.txt，XML含实际classpath。

Modern命令相同，但增加 -f modern/pom.xml -Dtest=Chapter34ModernTest,Chapter35ModernTest，实际JDK21，release17。共享modern POM显式javaagent，最终未传临时argLine；退出0，总5次，本章2次，原始modern-jdk21-surefire.xml与maven.log。不在Java8运行Mockito5或JDK HttpClient。



首次默认sandbox禁止bind，未将该错误作为实验通过。工具批准本机127.0.0.1测试后重跑。首次Java8断连计数0暴露前序503连接关闭/复用干扰，修正503响应显式Connection:close；最终双JDK完整重跑并确认drop计数1。没有用放宽计数掩盖问题。


## 反向研究和版本边界

官方反向入口：
- Jackson重复树节点issue2809：https://github.com/FasterXML/jackson-databind/issues/2809 ，固定ObjectNodeTest重复键覆盖分支与本地strict样本交叉检查；不将历史issue直接当2.20.1缺陷。
- SLF4J MDC初始化issue450：https://github.com/qos-ch/slf4j/issues/450 ，固定LoggerFactory earlyBindMDCAdapter与实际JUL provider核验；不把simple空适配器当有效MDC实验。
- HttpClient retry timeout历史问题：https://issues.apache.org/jira/browse/HTTPCLIENT-2141 ，固定RequestConfig明确responseTimeout不是deadline；本地关闭重试，不外推默认策略。
- Mockito Java21显式instrumentation以固定Mockito.java第172段及现代真实测试核验，未使用搜索结果中的旧2.x Javadoc。
- JUnit用户指南抓取超时，改为https://docs.junit.org/5.13.4/api/org.junit.jupiter.params/org/junit/jupiter/params/ParameterizedTest.html 的固定API契约。AssertJ实现/上游失败测试说明顺序与数量断言。

研究三阶段：确定输入/配置问题→读冻结实现与上游反例→本地实测并反向检查错误解释。上游全套测试未运行。怀疑者检查：null不等于missing，诊断成功不等于业务日志输出，客户端失败不等于远端未执行，mock正确不证明第三方正确。

NOT_RUN：所有性能/内存基准、其他平台、全量Unicode/JSON格式、网络接收前内存预算、任意多态实例化、日志大包/异步上下文/循环桥接、TLS/DNS/代理/HTTP2/黑洞connect timeout、开启重试、全量自动突变。练习不计通过。Hexo全系列生成/导航整合/本地commit由根代理执行，本账本不预先宣称完成。

## 写作与附件验收

临时draft依次anti-ai-tone check_prose.py --profile tech --json、anti-persona-fabrication人工/关键词检查后apply_patch落盘。style-scan.json为0 errors/0 warnings，无第一人称叙事、拟人/说书人。34/35后续仅补真实post_link导航，不改变技术段落；最终样本重新扫描。正文有业务反例、两个可迁移判断、改动练习与速查表。

完整测试imports与文章附件一致，RUN.md列命令与未运行范围。见evidence/32/batch-final-check.json。Java LSP未安装，工具清单无lsp_install_decision；使用实际Maven编译测试验证，不安装额外工具。
