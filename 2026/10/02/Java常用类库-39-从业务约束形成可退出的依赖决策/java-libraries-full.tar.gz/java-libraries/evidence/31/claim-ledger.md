# 31：缓存迁移证据

预期先按公开契约写断言，再运行受控时序；版本Guava33.5.0-jre/Caffeine3.2.4；modern release17，实际Corretto21.0.11、macOS aarch64。

DOC：固定LoadingCache/CacheLoader接口；SOURCE：Caffeine commit836b65c0a83e5d1641ded9c6de578654bc04b2e9的LocalLoadingCache103–169、BoundedLocalCache1348–1473、LocalAsyncCache202–236，以及固定Guava commit8868c096cfdabbe38170b6e395369c315cfb72a1缓存实现。源码片段单独保存；接口与实现不是独立团队重复证明。

LAB_VERIFIED七项：空返回不缓存和检查异常包装差异；读触发刷新/失败保留/成功/空移除；已有值刷新→失效→迟到完成的Guava/Caffeine对照；两真实线程同键合并；自定义加载器返回同一future的取消反例；direct executor移除通知原因和线程；TTL/maintenance/capacity/stats。

运行命令（examples/java-libraries，JAVA_HOME=Corretto21）：

```sh
MAVEN_USER_HOME="$PWD/.maven-user-home" ./mvnw -o -B -ntp -s .mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 -f modern/pom.xml -Dtest=Chapter31Test verify
```

退出0、7tests/0failures/0errors/0skipped。raw stdout及XML在jdk21。刷新异常是故意构造的失败输入，raw日志保留其WARNING/stacktrace，没有抑制错误。首次6项输出在integration/modern31-first.stdout.txt；添加第7项通知场景后重新运行最终7项，不以首次6项计为最终。

反向调查：官方issue193报道的是Caffeine2.5.3异步刷新，不适用于本次版本；固定上游LoadingCacheTest.refresh_invalidate展示不同分支，仍另做自己的独立受控实验。红队：在相同取消对象下取消会传播给另一调用方，但取消future不证明后台IO停止；直接执行器不证明默认线程池时序；精确淘汰键不属于跨库契约；未测首次异步加载失效，不从刷新时序外推。

NOT_APPLICABLE：Java8。NOT_RUN：实际JDK11/17、其他平台、弱引用GC、真实网络取消、默认执行器压力、全部并发交错、命中率轨迹/性能。正文额外并发put练习未执行，不计入七项。

写作链：java-tech-writer及深研；draft anti-ai-tone（0errors/0warnings）四遍支持/推进/节奏/连续性复核后，anti-persona-fabrication复核无第一人称/拟人/说书，再source落盘。文本检测不代替技术审查。
