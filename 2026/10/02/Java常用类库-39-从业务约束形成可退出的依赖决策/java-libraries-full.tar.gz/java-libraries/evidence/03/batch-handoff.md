# 03–06 本地交付记录

正文四篇及各自 RUN.md、完整 ChapterNNTest.java 附件已落盘。未修改共享 POM、主代码、其他章节、状态文件，未提交或推送。

| 场景 | 调用 | 二值验收 | 证据 |
|---|---|---|---|
| 03 相等/排序反例 | 隔离副本 Maven，-Dtest=Chapter03Test,Chapter04Test,Chapter05Test,Chapter06Test clean verify | Java8/21各3项，0失败/错误/跳过 | 本目录 jdk8-surefire.xml、jdk21-surefire.xml |
| 04 规范化 | 同上 | Java8/21各2项，0失败/错误/跳过 | ../04/jdk8-surefire.xml、../04/jdk21-surefire.xml |
| 05 失败契约 | 同上 | Java8/21各3项，0失败/错误/跳过 | ../05/jdk8-surefire.xml、../05/jdk21-surefire.xml |
| 06 Optional迁移 | 同上 | Java8/21各4项，0失败/错误/跳过 | ../06/jdk8-surefire.xml、../06/jdk21-surefire.xml |
| 四个正文main | JDK8 javac；各自Java8/21 java运行 | 退出0且自校验未抛AssertionError | 各目录 snippet-jdk8.stdout.txt、snippet-jdk21.stdout.txt |
| 风格扫描 | check_prose.py --profile tech 临时草稿 --json；随后persona逐段复查 | 0 errors；persona红线0命中 | 各目录 style-ai.json、claim-ledger.md |
| 04 包体/依赖树 | stat明确坐标；maven-dependency-plugin:3.8.1:tree -Dscope=compile | 退出0，BUILD SUCCESS | ../04/jar-bytes.txt、../04/dependency-tree.stdout.txt |

散文汉字数（扫描器剔除代码等）：03=3001、04=3028、05=3025、06=3034。03–05各有一处长句的“的”字warning，人工检查主语与具体证据明确，保留原句；06无warning。脚本顺序为anti-ai-tone后persona，再发布到source/_posts。

每篇claim-ledger列出DOC/SOURCE/LAB及限制。没有把可变键未指定行为升级成通用保证，也没有把JAR字节数当堆占用或性能。没有声明执行过上游全测试、多线程实验、微基准、跨版本SDK链接或历史对象流迁移。

根整合负责统一Hexo/页面资源检查、系列状态及本地精确提交；本记录不将这些待集成项目标为完成。03→04→05→06与00入口使用不含日期的post_link。各章独立运行说明指向00已有实验工程；根随后提供全系列归档。
