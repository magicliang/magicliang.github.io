# 03 证据账本

| 结论 | 一手资料与可观察结果 | 等级/判定 | 边界 |
|---|---|---|---|
| 可变键破坏索引定位假设 | Map 文档的可变键限制；HashMap 固定源码节点 hash/getNode/putVal；测试查找 null、大小1、恢复后命中 | DOC+SOURCE+LAB，Verified | 观察限于固定输入/运行时，不宣布未指定行为的通用恢复算法 |
| TreeSet 以比较零判等 | Comparator/BigDecimal Javadoc；测试 BigDecimal 1.0/1.00 在 HashSet=2、TreeSet=1 | DOC+LAB，Verified | 数值等价与业务身份不同 |
| 两商户同SKU保留两条 | 组合身份 comparator 与 SKU-only 对照为2/1 | LAB，Verified | 价格未参与身份 |
| null次序与减法溢出 | Comparator 与 JLS4.2.2；nullsFirst/Last、Integer.compare断言 | DOC+LAB，Verified | 无速度结论 |

本章3测试/每JDK。source-inspection.txt 为 OpenJDK固定提交64050651646459b18fa06ac90660e93999039c7e 摘录（来源用于算法解释，不冒充所用供应商源码）。

反向核验：Map明确把可变键行为列为未指定，因此删除任何“所有HashMap必定查不到”的推论；SortedSet文档明确不一致排序可有定义但不满足Set一般契约，因此未写成集合崩溃。怀疑者检查碰撞、实施者检查商户作用域、对抗者检查比较零丢数据，均纳入正文边界。上游规范与本地实验独立核验，不用计数代替并发证明。

## 版本与命令

研究日期 2026-10-02。Guava 33.5.0-jre 源码 SHA 8868c096cfdabbe38170b6e395369c315cfb72a1；Commons Lang 3.20.0 SHA 598dfc163b8b410fb3bb8794521206ec8dcec82a。源码来自 /tmp/java-baseline-guava-3350、/tmp/java-baseline-lang-3200，正文固定链接指向上述提交。

隔离副本 /tmp/java-chapters03-06，未使用共享 target。命令为：

```bash
JAVA_HOME=<下面的 JDK 路径> MAVEN_USER_HOME=<仓库>/examples/java-libraries/.maven-user-home /tmp/java-chapters03-06/mvnw -f /tmp/java-chapters03-06/pom.xml -o -B -ntp -s /tmp/java-chapters03-06/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 -Dtest=Chapter03Test,Chapter04Test,Chapter05Test,Chapter06Test clean verify
```

JDK8 路径 /Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home；JDK21 路径 /Users/magicliang/.sdkman/candidates/java/21.0.11-amzn。两次退出码均为 0，批次各12测试、0失败/错误/跳过。原始完整日志 jdk8-verify.stdout.txt、jdk21-verify.stdout.txt；各章独立 XML 为 jdk8-surefire.xml、jdk21-surefire.xml，包含 java.version/java.home 环境及逐用例时间、system-out。二十一版的旧 source/target 警告未屏蔽。

正文独立 main 由 Markdown Java 代码块原样生成到隔离目录 snippets，通过 JDK8 javac 编译，分别用 Java8/21 运行；输出为 snippet-jdk8.stdout.txt、snippet-jdk21.stdout.txt。完整 main 与测试不同，分别验收。没有耗时性能、线程安全或其他运行时的实验结论。

## 写作验收

java-tech-writer 与 deep-research 入口；临时草稿先运行 anti-ai-tone check_prose.py --profile tech --json，再进行 anti-persona-fabrication 红线扫描与逐段复查后 apply_patch 落盘。style-ai.json 保存首次落盘前扫描；persona 未命中第一人称、虚构经历、说书人腔。正文含业务输入、机制、正常路径/反例、手算题、改动练习、两种迁移模式。独立审阅和最终 Hexo 由根整合验收，此文件不将尚未执行的页面验收报为通过。
