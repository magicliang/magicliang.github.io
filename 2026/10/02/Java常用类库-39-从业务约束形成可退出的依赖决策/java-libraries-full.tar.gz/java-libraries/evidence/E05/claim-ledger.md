# E05 claims / evidence ledger

基线：CLI1.11.0 d74613321325f6081fa0206c4ab608ab65d80e2e；Configuration2.15.1 51f8140ab63e2904c6a5c46fecf841fd5e34c492；BeanUtils1.11.0 9c0b5cf007818c3fb1ac36d5ed394d56d0fd13c3。源码POM source/target1.8。

- DOC/SOURCE：DefaultParser token/long option/quote设置；CompositeConfiguration优先级；ConfigurationInterpolator.initSubstitutor/resolve与登记lookup；ConvertUtilsBean primitive整数默认零；PropertyUtilsBean注册SUPPRESS_CLASS。
- LAB：tokensAreAlreadySeparatedAndUnknownOrMissingOptionsFail：required/unknown/缩写/空格/单引号/双引号/--；precedenceSplittingAndInterpolationAreIndependentPolicies：3->清除->2，a,b\\,c拆分、cfg-only lookup；whiteListPrecedesReflectionAndConversionDoesNotValidateDomain：完整键白名单阻止敏感/嵌套表达式，strict转换异常及负数领域拒绝。
- 反向核验：BeanUtils上游bugs/Jira520TestCase证明class属性默认抑制可被配置改变，所以应用仍先白名单。默认Integer转换非法文本为0已本地反例；Configuration未解析残留与任意模板语法不混淆。
- NOT_RUN：未执行shell、访问真实环境、读取文件配置、热更新或并发发布；插值残留检查不是完整不可信模板语言；三来源优先级与候选对象发布设计不代表配置事务全实现。

完整实际运行在隔离 /tmp/java-libraries-extensions，没有写共享 target：

```bash
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn MAVEN_USER_HOME=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/java-libraries/.maven-user-home /tmp/java-libraries-extensions/mvnw -B -ntp -o -f /tmp/java-libraries-extensions/pom.xml -s /tmp/java-libraries-extensions/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify
```

JDK8同命令切换JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home。处理器模块初次运行使用系列wrapper与settings，后复制同一wrapper入独立包；实际POM和源码均相同。10 tests每JDK通过，本章3 tests，无失败错误跳过。原始jdk8/jdk21 stdout与original Surefire XML在当前目录；各次clean前保存XML。

文章先在/tmp草稿运行anti-ai-tone，再执行persona人工连读和模式检查，最终apply_patch。JSON保存扫描结果、顺序和草稿SHA256；最终字节及所有资产核对见evidence/E03/delivery-check.json。源码下载和测试工程一致。E08 generated附件匹配jdk21生成证据；E03 JMH JSON字节与36源证据一致。

源码仓库均为官方tag冻结；完整固定URL已在正文，不把当前站点snapshot作为版本依据。没有运行整个上游测试套件；读取上游断言与执行本地断言分别标记。
