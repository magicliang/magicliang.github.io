# 04 证据账本

| 结论 | 一手资料与可观察结果 | 等级/判定 | 边界 |
|---|---|---|---|
| 三种规范化并非全域等价 | String.trim文档、StringUtils固定源码stripStart/End、CharMatcher固定源码；NBSP/U+001C反例 | DOC+SOURCE+LAB，Verified | 只对五组普通ASCII样本确认等价 |
| 地区与长度可影响大小写 | String.toUpperCase契约；ROOT i=I、tr i=U+0130、ß=SS | DOC+LAB，Verified | 未修改全局Locale；不声称完成Unicode标准化 |
| 主JAR包体数字 | jar-bytes.txt：3017283、713862 | LAB，Verified | 仅主JAR压缩字节，不是堆/性能/完整部署增量 |
| 实际传递依赖 | dependency-tree.stdout.txt BUILD SUCCESS | LAB，Verified | 只适用当前隔离工程的解析图 |

本章2测试/每JDK。strip-source.txt 为固定Lang源码。依赖树命令使用 org.apache.maven.plugins:maven-dependency-plugin:3.8.1:tree -Dscope=compile，与上面的 Maven 参数一致；退出0。首次短前缀 dependency:tree 离线插件解析失败，修复为缓存中固定版本的完整坐标后全场景重跑。主JAR由 stat -f '%N %z' 读取明确坐标，不枚举整个缓存作为依赖集合。

反向核验：U+001C拒绝“Guava删得更多”包含关系；Commons在线当前文档不能替代3.20.0源码；Maven文档的调解规则拒绝“上游POM就是应用完整运行图”。怀疑者核查数字单位、对抗者输入NBSP、实施者核查索引两侧规范化一致性。没有凭包大小给性能排名。

## 版本与命令

研究日期 2026-10-02。Guava 33.5.0-jre 源码 SHA 8868c096cfdabbe38170b6e395369c315cfb72a1；Commons Lang 3.20.0 SHA 598dfc163b8b410fb3bb8794521206ec8dcec82a。源码来自 /tmp/java-baseline-guava-3350、/tmp/java-baseline-lang-3200，正文固定链接指向上述提交。

隔离副本 /tmp/java-chapters03-06，未使用共享 target。命令为：

```bash
JAVA_HOME=<下面的 JDK 路径> MAVEN_USER_HOME=<仓库>/examples/java-libraries/.maven-user-home /tmp/java-chapters03-06/mvnw -f /tmp/java-chapters03-06/pom.xml -o -B -ntp -s /tmp/java-chapters03-06/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 -Dtest=Chapter03Test,Chapter04Test,Chapter05Test,Chapter06Test clean verify
```

JDK8 路径 /Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home；JDK21 路径 /Users/magicliang/.sdkman/candidates/java/21.0.11-amzn。两次退出码均为 0，批次各12测试、0失败/错误/跳过。原始完整日志 jdk8-verify.stdout.txt、jdk21-verify.stdout.txt；各章独立 XML 为 jdk8-surefire.xml、jdk21-surefire.xml，包含 java.version/java.home 环境及逐用例时间、system-out。二十一版的旧 source/target 警告未屏蔽。

正文独立 main 由 Markdown Java 代码块原样生成到隔离目录 snippets，通过 JDK8 javac 编译，分别用 Java8/21 运行；输出为 snippet-jdk8.stdout.txt、snippet-jdk21.stdout.txt。完整 main 与测试不同，分别验收。没有耗时性能、线程安全或其他运行时的实验结论。

## 写作验收

java-tech-writer 与 deep-research 入口；临时草稿先运行 anti-ai-tone check_prose.py --profile tech --json，再进行 anti-persona-fabrication 红线扫描与逐段复查后 apply_patch 落盘。style-ai.json 保存首次落盘前扫描；persona 未命中第一人称、虚构经历、说书人腔。正文含业务输入、机制、正常路径/反例、手算题、改动练习、两种迁移模式。独立审阅和最终 Hexo 由根整合验收，此文件不将尚未执行的页面验收报为通过。
