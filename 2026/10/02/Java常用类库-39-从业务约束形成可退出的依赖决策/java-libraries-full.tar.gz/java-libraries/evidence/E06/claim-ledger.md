# E06 claim ledger

## DOC/SOURCE

固定版本Vavr 0.10.7 + Guava33.5.0-jre adapter，SHA 3af14df99c6a99ecd984e516d5f5294335cfbe84。v0.10.7源码POM Java1.8；Option/Value/TryModule/List/Lazy固定源码；DOC docs.vavr.io；官方issue2657是反向线索不当修改落地。dependency:tree离线缺插件失败已保留log；fallback实际Surefire java.class.path证明Vavr及vavr-match共2jar。接口3种Vavr类型到0是静态类型设计比较，不是性能测量。

source-inspection.txt含实际git rev-parse输出和读取的源码全文；正文所有实现结论固定到此版本。网络官方文档与issue用于反向核对，master搜索结果不替代固定源码。检索日期2026-10-02。

## LAB

Option.map null=Some(null)，JDK map null=empty，Vavr->JDK->Guava转换合并空；Try NumberFormatException/AssertionError成Failure，合成LinkageError/InterruptedException同实例重抛；recover后0、toOption失败信息丢弃；List.prepend尾部同一实例、旧新size1/2、可变StringBuilder共享；Lazy成功supplier0->1->1。

Java8与Java21每次3项测试均0failure/error/skip。原始输出jdk*-verify.stdout.txt；独立JUnit报告jdk*-surefire.xml。完整正文main通过javac/java，详见jdk*-snippet.stdout.txt，包含真实命令、退出码和stdout。

实际Maven调用（独立工程，不写共享target）：

```sh
JAVA_HOME=<JDK路径> MAVEN_USER_HOME=<repo>/examples/java-libraries/.maven-user-home /tmp/java-extensions-01020607/mvnw -o -B -ntp -s /tmp/java-extensions-01020607/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 -f /tmp/java-extensions-01020607/pom.xml clean verify
```

legacy组共8项：E01=2/E02=3/E06=3，modern组E07=4。JUnit XML含JVM具体版本与依赖classpath。SOURCE不等同LAB；合成fatal异常不等于实际VM崩溃。

## NOT_RUN/限制

真实VM灾难、阻塞中断标记、Lazy失败缓存组合、集合性能未测。 全站Hexo、浏览器由根统一验收，本子任务不声称已运行。未gitcommit/push/deploy。LSP未安装，未安装新工具；使用真实javac/Maven验证替代。

## 写作前置检查

临时/tmp/javaE06-draft.md先执行anti-ai-tone check_prose.py --profile tech --json，0errors/0warnings，结果anti-ai-tone.json；随后anti-persona-fabrication关键词扫描无命中并通读，无第一人称叙事/软件拟人/虚构经验/说书人。通过后apply_patch落盘；正文完整imports例子有独立编译执行，不只依赖测试。
