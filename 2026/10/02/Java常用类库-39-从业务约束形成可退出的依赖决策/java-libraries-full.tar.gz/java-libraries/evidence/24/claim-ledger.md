# 第 24 篇 claim ledger

## 冻结与范围

Commons Lang 3.20.0：org.apache.commons:commons-lang3:3.20.0，SHA 598dfc163b8b410fb3bb8794521206ec8dcec82a。
Commons Collections 4.6.0：org.apache.commons:commons-collections4:4.6.0，SHA 4107624de41aeed37985d2a069fad41992fd71a2。
Guava 33.5.0-jre：com.google.guava:guava:33.5.0-jre，SHA 8868c096cfdabbe38170b6e395369c315cfb72a1。

固定源码链接见正文，读取行号见 source-inspection.txt。DOC 为官方契约；SOURCE 为冻结实现与上游测试阅读；LAB 为本地断言。Javadoc 与源码均属同一上游，未当作多个独立第三方来源。本地实验提供不同证据类型，不代表生产流量验证。

| claim | DOC/SOURCE 入口 | LAB 方法 | 二值判定所用样本 |
|---|---|---|---|
| 校验包装无法保护底层旁路 | PredicatedCollection 构造/add | Chapter24Test.predicateOnlyProtectsTheDecoratedEntrance | 包装拒绝、底层成功、既有非法构造拒绝 |
| 转换时机分为既有转换和以后写入 | TransformedCollection 两工厂 | Chapter24Test.transformingDoesNotTransformExistingButTransformedDoes | 计数0→1→3；contains只查存储表示 |
| 惰性读取重复求值，partition 是子视图 | Guava Lists.transform；Commons ListUtils.partition | Chapter24Test.lazyReadAndPartitionRemainViews | get两次计数2，改源/改组传播，外层拒add |
| 同步方法持锁，迭代需显式持同一锁 | SynchronizedCollection.lock=this / iterator | Chapter24Test.synchronizedDecoratorDoesNotLockIteratorAutomatically | holdsLock：add true，iterator false，外部整段锁 true，底层add false |

## 复跑命令与原始结果

独立工作副本 /tmp/java-libraries-20-24，禁止向共享 target 并行写入。每个 JDK 顺序执行：
```sh
JAVA_HOME=<JDK路径> MAVEN_USER_HOME=<仓库>/examples/java-libraries/.maven-user-home ./mvnw -o -B -ntp -s .mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 -Dtest=Chapter20Test,Chapter21Test,Chapter22Test,Chapter23Test,Chapter24Test clean verify
```

JDK8=/Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home
JDK21=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn

两命令退出码均为 0，Maven 3.9.14，各批 20 tests。本章 jdk8-surefire.xml 与 jdk21-surefire.xml 各 tests=4、failures=0、errors=0、skipped=0。对应 jdk8-maven.log/jdk21-maven.log 保存完整输出；jdk*-environment.txt 从 XML 真实属性提取，XML 保存完整 classpath。

## 反向核验

官方网页检索核验 StringUtils whitespace/strip、NumberUtils default/overflow、BooleanUtils unknown、Bag remove contract violation、DualHashBidiMap duplicate value、TransformedCollection existing elements、SynchronizedCollection iterator。仅采纳官方来源，在线 Lang Javadoc 当前标为 3.21.0-SNAPSHOT，所以本章版本结论以固定 3.20.0 源码为准。

22 的 JEP395 页面本次抓取403，改用官方 Java16 语言变更页确认 records 正式化：https://docs.oracle.com/en/java/javase/16/language/java-language-changes.html 。这项属于 DOC，未计入 LAB。

怀疑者检查：不把容错等同合法；不把 immutable 当深不可变；不把相同不变量当相同冲突策略；不把同步包装当全部写入口受锁保护。
实施者检查：完整 imports、Java8 API 编译、异常类别及返回状态断言；测试在独立副本运行，没有要求安装额外 LSP。
上游测试只读取核验，未运行上游全套。

NOT_RUN：性能/内存基准、其他JDK/平台、真实并发负载、模块强封装失败、record编译；24 转换中途异常及包装叠加顺序只作 SOURCE 推导/练习，不列为 LAB。各篇改动题均未计入通过数。Hexo全系列生成、导航统一验收与commit由根代理处理，本账本不预先宣称完成。

## 落盘前扫描

/tmp/java-libraries-24-draft.md 先运行 anti-ai-tone 的 check_prose.py --profile tech --json，结果 style-scan.json，errors=0、warnings=0。再按 anti-persona-fabrication 检查第一人称、拟人化、说书人腔；关键词零命中，人工复核未使用虚构个人经验。正文支撑、推进、节奏、连续性复核后 apply_patch 写入 source/_posts。附件与测试源码字节一致性见 evidence/20/batch-final-check.json。
