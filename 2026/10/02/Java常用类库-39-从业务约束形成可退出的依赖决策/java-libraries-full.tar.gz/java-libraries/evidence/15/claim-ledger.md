# Chapter 15 evidence ledger

冻结：Guava33.5.0-jre，SHA8868c096cfdabbe38170b6e395369c315cfb72a1。研究角度：商品详情的状态、旧值窗口与更新边界；面向需要决定刷新及失效协议的Java工程师。没有加入网络、吞吐量或所有线程交错结论。

| claim | source/support | verification | risk/action |
|---|---|---|---|
| 同key首次加载合并 | LoadingCache固定Javadoc；LocalCache.lockedGetOrLoad/waitForLoadingValue；sameKeyMissesShareOneBlockedLoad | DOC/SOURCE/LAB，两个JDK通过 | 单实例、指定key与受控时序；不外推跨进程 |
| 到达刷新年龄不会自行刷新；未完成Future保留旧值 | scheduleRefresh/loadAsync；refreshNeedsAccessAndKeepsOldValueWhilePendingOrFailed；上游testLongAsyncRefresh | DOC/SOURCE/LAB | 同步完成的reload可以返回新值，默认reload不保证异步 |
| 刷新失败记录警告，旧值有效时仍可读 | LocalCache.getAndRecordStats/removeLoadingValue，受控IOException和第二次成功刷新 | DOC/SOURCE/LAB | 原始异常警告保留；不外推无限陈旧回退 |
| 逻辑过期与物理大小不同 | Cache.size/cleanUp Javadoc；expirationHidesEntryBeforePhysicalCleanup | DOC/SOURCE/LAB：size观察1、读取null、清理后0 | size观察值限定本次运行，不作为实时精确可用项计数 |
| 首次加载中invalidate不取消加载；结果可回填 | Segment.remove未激活加载引用直接返回；storeLoadedValue替换引用；invalidationIsNotCancellationAndCapacityIsASeparateBudget | SOURCE/LAB，8/21观察到旧加载结果回填 | 返回null不证明删除占位；不把其他回填分支当成已覆盖时序 |
| null加载及异常类别不同 | CacheLoader/LoadingCache契约，checkedUncheckedAndNullFailuresHaveDifferentBoundaries | DOC/SOURCE/LAB | getUnchecked改变包装，不消除故障 |
| 容量预算与加载并发不同 | maximumSize文档；放入三个条目后size2/eviction1；加载占位路径 | DOC/SOURCE/LAB | 不断言驱逐具体key，不声称完整流量并发预算 |

反向检索：官方google/guava issues的invalidate/load race、refresh failure、LocalCache缺陷。#976为历史11.x问题且13.0已修复，不能套入本篇。#1881关注先加载后失效的竞态，固定33.5.0源码与受控实验独立核验；#7975涉及computeIfAbsent异常引用保留，未把其结论用于本文get/load路径。源码与上游测试属于同一维护来源，不伪称两个独立作者。

红队：怀疑者核对刷新资格与同步/异步区别；对抗者注入刷新异常、null返回、加载中失效；实施者确认latch上限和executor finally关闭。已纠正“实验删除了加载占位”的错误推导，正文按remove实际分支解释。性能、弱引用GC、不同操作系统和业务版本围栏NOT_RUN。

来源入口：[LoadingCache](https://guava.dev/releases/33.5.0-jre/api/docs/com/google/common/cache/LoadingCache.html)、[Cache](https://guava.dev/releases/33.5.0-jre/api/docs/com/google/common/cache/Cache.html)、[CacheLoader](https://guava.dev/releases/33.5.0-jre/api/docs/com/google/common/cache/CacheLoader.html)、[固定LocalCache](https://github.com/google/guava/blob/8868c096cfdabbe38170b6e395369c315cfb72a1/guava/src/com/google/common/cache/LocalCache.java)、[上游测试](https://github.com/google/guava/blob/8868c096cfdabbe38170b6e395369c315cfb72a1/guava-tests/test/com/google/common/cache/LocalCacheTest.java)、[#1881](https://github.com/google/guava/issues/1881)。在线工具无法打开部分guava.dev页面，契约内容另从固定源码Javadoc读取；链接存活将在发布资源检查中再核对，不将工具错误当不存在。
