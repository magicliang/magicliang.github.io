# 00–15整合验收

日期2026-10-02，系统macOS aarch64。合成数据；不调用外部业务服务。

在examples/java-libraries运行以下两次命令，每次clean前保存上次XML；JAVA_HOME依次为Zulu8.0.472及Corretto21.0.11。wrapper缓存目录由下方命令明确设置。

```sh
MAVEN_USER_HOME="$PWD/.maven-user-home" ./mvnw -o -B -ntp -s .mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify
```

两次退出0、BUILD SUCCESS，各81tests/0failures/0errors/0skipped。原始输出jdk8-00-15.stdout.txt与jdk21-00-15.stdout.txt，同名目录保存16份JUnit XML。00=3，01=20，02=6，03=3，04=2，05=3，06=4，07–10各4，11=5，12=5，13=4，14=5，15=5。

Hexo验证：仓库根执行node writing-plans/java-libraries/verification/verify-pages.mjs --expected 16，退出0；生成隔离站点，不部署。原始输出hexo-00-15.stdout.txt，完整检查report在writing-plans/java-libraries/verification/hexo-pages.latest.json。

实际HTTP：将该report的isolatedRoot/public作为Python ThreadingHTTPServer目录，只绑定127.0.0.1随机端口；依次请求每篇URL及其附件，逐项要求HTTP200且内容与生成文件逐字节相同；finally shutdown、server_close和join。结果http-00-15.json：16pages/47requests/PASS。服务器已关闭。

仅证明所列功能场景、生成页面和资源访问；视觉浏览器检查、其他JDK/操作系统/性能未运行。03–15单篇声明与源码锚点另见各章claim ledger；源码/文档引用不能替代实际实验。
