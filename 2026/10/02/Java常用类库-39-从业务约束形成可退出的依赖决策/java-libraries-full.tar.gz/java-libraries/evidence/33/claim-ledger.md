# 第 33 篇证据账本

## 版本与证据类型

Jackson databind/jsr310 2.20.1，databind SHA4164a2b47d3795a28f7cb838a02c27b77f9adaf4。
SLF4J api/simple/jdk14/jul-to-slf4j 2.0.20，SHA58d80a4fe8f2e811707fcfba4d292b5d62fc2fe9。
HttpClient5 5.6.4，SHA36508cead5c4388d04d20aa7efad5a68595631a0。
AssertJ3.27.6，SHA716b1e0a6a372890cd4b3495b954f57755e99471；Mockito5.20.0，SHA3a1a19ee40f1234048880393343405046fc3fa60。JUnit5.13.4。

DOC=公开契约，SOURCE=固定实现与上游测试阅读，LAB=本地真实运行，NOT_RUN=未运行范围。同一上游的Javadoc、源码、issue不冒充独立来源；本地反例增加运行证据，不等于生产验证。源码摘录及行号见source-inspection.txt，正文引用完整SHA。

| claim | DOC/SOURCE | LAB方法 | 输入与二值观察 |
|---|---|---|---|
| 无provider回退NOP | LoggerFactory.findServiceProviders/bind | noProviderFallsBackWithDiagnostic | fork none provider=0、NOP工厂、真实stderr |
| 单provider输出已选择字段 | simple真实provider | singleProviderLogsOnlySanitizedFields | provider=1、占位输出、无合成secret |
| 多provider歧义 | LoggerFactory.reportMultipleBindingAmbiguity | multipleProvidersAreDetectedWithoutAssumingWinner | fork provider=2；真实warn；不预设胜出者 |
| MDC失败清理 | JULServiceProvider BasicMDCAdapter；MDC.remove | mdcIsRemovedAfterFailedRequest | 写入req-A确认；finally后nextRequestMdc=null |
| 单向JUL桥接 | 官方legacy桥接说明；SLF4JBridgeHandler | julBridgeHasOneDirectionAndIsRemoved | exactly1 bridged-product，卸载false；禁用debug计数为1 |

## 最终命令和结果

隔离副本 /tmp/java-libraries-32-35，缓存 /tmp/java-libraries-m2，Maven Wrapper3.9.14；不写共享target。
```sh
JAVA_HOME=<JDK路径> MAVEN_USER_HOME=<仓库>/examples/java-libraries/.maven-user-home ./mvnw -o -B -ntp -s .mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 -Dtest=Chapter32Test,Chapter33Test,Chapter34Test,Chapter35Test clean verify
```
Java8路径 /Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home。
Java21路径 /Users/magicliang/.sdkman/candidates/java/21.0.11-amzn。
两最终命令退出0，各20次；本章tests=5、failures/errors/skipped均0，见jdk8/jdk21-surefire.xml与maven.log。实际环境从XML属性提取到environment.txt，XML含实际classpath。


五个fork各自command/stdout/stderr在jdk8-forks及jdk21-forks。命令行classpath实际隔离，最多等待20秒，异常时强制结束。主suite多provider诊断是夹具状态，不用于替代隔离验证。bridge只JUL→SLF4J→simple，卸载后检查false；未运行循环配置。



## 反向研究和版本边界

官方反向入口：
- Jackson重复树节点issue2809：https://github.com/FasterXML/jackson-databind/issues/2809 ，固定ObjectNodeTest重复键覆盖分支与本地strict样本交叉检查；不将历史issue直接当2.20.1缺陷。
- SLF4J MDC初始化issue450：https://github.com/qos-ch/slf4j/issues/450 ，固定LoggerFactory earlyBindMDCAdapter与实际JUL provider核验；不把simple空适配器当有效MDC实验。
- HttpClient retry timeout历史问题：https://issues.apache.org/jira/browse/HTTPCLIENT-2141 ，固定RequestConfig明确responseTimeout不是deadline；本地关闭重试，不外推默认策略。
- Mockito Java21显式instrumentation以固定Mockito.java第172段及现代真实测试核验，未使用搜索结果中的旧2.x Javadoc。
- JUnit用户指南抓取超时，改为https://docs.junit.org/5.13.4/api/org.junit.jupiter.params/org/junit/jupiter/params/ParameterizedTest.html 的固定API契约。AssertJ实现/上游失败测试说明顺序与数量断言。

研究三阶段：确定输入/配置问题→读冻结实现与上游反例→本地实测并反向检查错误解释。上游全套测试未运行。怀疑者检查：null不等于missing，诊断成功不等于业务日志输出，客户端失败不等于远端未执行，mock正确不证明第三方正确。

NOT_RUN：所有性能/内存基准、其他平台、全量Unicode/JSON格式、网络接收前内存预算、任意多态实例化、日志大包/异步上下文/循环桥接、TLS/DNS/代理/HTTP2/黑洞connect timeout、开启重试、全量自动突变。练习不计通过。Hexo全系列生成/导航整合/本地commit由根代理执行，本账本不预先宣称完成。

## 写作与附件验收

临时draft依次anti-ai-tone check_prose.py --profile tech --json、anti-persona-fabrication人工/关键词检查后apply_patch落盘。style-scan.json为0 errors/0 warnings，无第一人称叙事、拟人/说书人。34/35后续仅补真实post_link导航，不改变技术段落；最终样本重新扫描。正文有业务反例、两个可迁移判断、改动练习与速查表。

完整测试imports与文章附件一致，RUN.md列命令与未运行范围。见evidence/32/batch-final-check.json。Java LSP未安装，工具清单无lsp_install_decision；使用实际Maven编译测试验证，不安装额外工具。
