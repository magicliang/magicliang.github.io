# Chapter 27 claim ledger

基线：Commons Text 1.15.0，源码 04e937470d3679cc163df85d82d5b6d2e3e71128。DOC 为官方文档；SOURCE 为固定源码；LAB 为本地断言；NOT_RUN 不声称验证。现行官网可能显示 snapshot，行为归属于固定 SHA。

- SOURCE: https://github.com/apache/commons-text/blob/04e937470d3679cc163df85d82d5b6d2e3e71128/src/main/java/org/apache/commons/text/StringEscapeUtils.java
- SOURCE: https://github.com/apache/commons-text/blob/04e937470d3679cc163df85d82d5b6d2e3e71128/src/main/java/org/apache/commons/text/StringSubstitutor.java#substitute/setValueDelimiterMatcher
- SOURCE: https://github.com/apache/commons-text/blob/04e937470d3679cc163df85d82d5b6d2e3e71128/src/main/java/org/apache/commons/text/similarity/LevenshteinDistance.java

- 上游反向核验：src/test/java/org/apache/commons/text/StringSubstitutorTest.java#testReplaceFailOnUndefinedVariable and recursive tests
- SOURCE/DOC 结论：HTML4 单引号原样，JSON 仍有 <，XML1.0 删除 NUL；Map-only lookup、未知键异常、关闭默认值和值递归；长度限制先于距离阈值。
- LAB 场景：escapingMustMatchTheDestinationContext; mapLookupCannotReadEnvironmentAndUndefinedIsAnError; distanceThresholdIsNotAnInputLengthBudget
- LAB 反例：${unknown:-fallback} 用 null delimiter 关闭；默认递归 cycle 抛异常；超距离返回 -1；长度超限先拒绝。
- 边界：NOT_RUN: browser execution, sensitive environment lookup, output allocation budget, Unicode grapheme equivalence, large candidate ranking.

实际命令（隔离副本，不触及共享 target）：

```bash
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn MAVEN_USER_HOME=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/java-libraries/.maven-user-home /tmp/java-libraries-25-30/mvnw -B -ntp -o -f /tmp/java-libraries-25-30/pom.xml -s /tmp/java-libraries-25-30/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify
```

第二次完整运行替换 JAVA_HOME 为 /Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home。两次 23 tests / 0 failures / 0 errors / 0 skipped。raw 输出见 jdk8-verify.stdout.txt 与 jdk21-verify.stdout.txt；本章各 3 个测试的 original Surefire XML 同目录。编译前同步所有本次最终源码至隔离副本；测试间复制 XML，避免 clean 覆盖证据。

交付扫描：/tmp/java-libraries-27-draft.md 先 check_prose.py --profile tech，再 anti-persona-fabrication 人工连读及模式扫描，之后 apply_patch 正文。报告 anti-ai-tone.json 与 anti-persona-fabrication.json；正文/附件/hash/XML 综合检查由 evidence/25/delivery-check.json 记录。
