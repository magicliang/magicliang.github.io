# Chapter 30 claim ledger

基线：Commons Compress 1.28.0，源码 852d9c23b94127feafc1649d9c7f13d4df338845。DOC 为官方文档；SOURCE 为固定源码；LAB 为本地断言；NOT_RUN 不声称验证。现行官网可能显示 snapshot，行为归属于固定 SHA。

- SOURCE: https://github.com/apache/commons-compress/blob/852d9c23b94127feafc1649d9c7f13d4df338845/src/main/java/org/apache/commons/compress/archivers/zip/ZipFile.java
- SOURCE: https://github.com/apache/commons-compress/blob/852d9c23b94127feafc1649d9c7f13d4df338845/src/main/java/org/apache/commons/compress/archivers/tar/TarArchiveEntry.java#isFile/getLinkFlag
- SOURCE: https://github.com/apache/commons-compress/blob/852d9c23b94127feafc1649d9c7f13d4df338845/src/main/java/org/apache/commons/compress/archivers/tar/TarArchiveInputStream.java

- 上游反向核验：TarArchiveEntry.isFile 源码 1196 附近；官方 https://commons.apache.org/proper/commons-compress/examples 与 /zip；本地手工类型矩阵比正向文件断言更严格。
- SOURCE/DOC 结论：合法两格式/目录成功；两格式 ../、absolute、C:/、混分隔符拒绝；duplicate与后置existing目录拒绝；ZIP symlink、TAR软硬链接FIFO拒绝；实际条目/单项/总字节/归档字节/检查点时间限制；10万零字节高比压缩样本拒绝；截断输入拒绝并清理。
- LAB 场景：zipAndTarExtractRegularFilesUnderPrivateRoot; traversalAbsoluteMixedPathsAndDuplicateAreRejectedWithCleanup; archiveLinksAndSpecialEntriesAreRejected; actualDecompressedBytesEntryCountAndTimeAreBudgeted; damagedArchiveAndTruncatedTarFailWithoutPublishingPartialFiles
- LAB 反例：初次 isFile OR directory 让 FIFO 通过；源码 isFile fallback 确认，最终以 getLinkFlag NORMAL/OLDNORM/DIR 白名单修复。原失败日志保留。
- 边界：NOT_RUN: isolated CRC corruption, cleanup permission failure, process crash, Windows, adversarial path swap, blocking parser cancellation, metadata heap cap. Private trusted directory/stable input required; no full-safety claim.

实际命令（隔离副本，不触及共享 target）：

```bash
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn MAVEN_USER_HOME=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/java-libraries/.maven-user-home /tmp/java-libraries-25-30/mvnw -B -ntp -o -f /tmp/java-libraries-25-30/pom.xml -s /tmp/java-libraries-25-30/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify
```

第二次完整运行替换 JAVA_HOME 为 /Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home。两次 23 tests / 0 failures / 0 errors / 0 skipped。raw 输出见 jdk8-verify.stdout.txt 与 jdk21-verify.stdout.txt；本章各 5 个测试的 original Surefire XML 同目录。编译前同步所有本次最终源码至隔离副本；测试间复制 XML，避免 clean 覆盖证据。

交付扫描：/tmp/java-libraries-30-draft.md 先 check_prose.py --profile tech，再 anti-persona-fabrication 人工连读及模式扫描，之后 apply_patch 正文。报告 anti-ai-tone.json 与 anti-persona-fabrication.json；正文/附件/hash/XML 综合检查由 evidence/25/delivery-check.json 记录。
