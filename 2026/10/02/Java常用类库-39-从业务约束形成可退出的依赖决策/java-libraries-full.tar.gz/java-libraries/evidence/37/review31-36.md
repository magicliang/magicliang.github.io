# 第31/36篇只读审查

结论：本轮范围内未发现阻断交付的问题。未修改31/36源码、正文或证据。

31：阅读完整正文与Chapter31Test七项测试；在/tmp/java-review31-modern复制独立POM+测试，JDK21离线clean verify真实重跑7tests/0failures/errors/skips。核对缺失与异常包装、显式刷新+invalidate+late、共享future取消、直接执行器、可控时钟与维护后容量。正文明确没有真实HTTP取消证明，历史issue193不作当前行为依据，Java11/17运行未执行。Caffeine固定README支持3.x需Java11。输出见review31.stdout.txt及review31-surefire.xml。

36：逐项核对LibraryBenchmarks实际源码与正文Java块，完全一致；所有asset_link存在。读取原始jmh-result.json九组，每组rawData为2fork×3测量，warmup=2/measurement=3/threads=1；ns/op score和scoreError及gc.alloc.rate.norm与正文表格三位小数一致。命中预装、未命中新键、转换完整物化与setup等价检查相符。正文明确直接执行器差异、Scope.Thread非共享负载、区间重叠、均值CI不是尾延迟、分配不是retained heap。未重新跑耗时基准，也不把只读数值核验称为重新测量。

核验输出和精确文件hash见review31-36-check.stdout.txt；站点渲染仍由根统一执行。
