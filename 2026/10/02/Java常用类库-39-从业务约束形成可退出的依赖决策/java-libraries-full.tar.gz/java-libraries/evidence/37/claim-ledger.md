# 第37章证据账本

DOC/SOURCE：Guava33.5.0-jre SHA8868c096cfdabbe38170b6e395369c315cfb72a1；CSV1.14.1 SHAe14ef86d34211f9d1b9b6040c5f6dbafc93ba907；Jackson Databind2.20.1 SHA4164a2b47d3795a28f7cb838a02c27b77f9adaf4；HttpClient5.6.4 SHA36508cead5c4388d04d20aa7efad5a68595631a0。source-inspection.txt保存实际读取路径/源码。CSV迭代format.useRow达到上限会停止，不等于超量错误；故实现自行拒绝额外记录。Jackson顶层readTree trailing检查与parser重复字段检测经LAB反查。HttpClient官方建议handler，本文显式executeOpen并关闭；未使用弃用execute返回响应重载。

LAB：Chapter37Test六项测试在Java8和21各通过，0failures/errors/skips。测试包含真实127.0.0.1服务器、真实HttpClient、真实JSON/ZIP/私有临时文件。成功3次富化，A=2/B=1，[0,10)=2，report经PrivateArchive解包字节相等；借入input保持open且client可继续使用；Export.close清理。非法输入在HTTP前拒绝；中途HTTP/JSON六类失败leased=0且父目录空；取消导入前/响应期/报告后均清理；报告/ZIP预算失败清理。独立main在同一真实服务下调用并结束清理，日志含报告JSON与ZIP大小。

实际命令（/tmp独立副本，无共享target）：

```sh
JAVA_HOME=<Zulu8或Corretto21> MAVEN_USER_HOME=<repo>/examples/java-libraries/.maven-user-home /tmp/java-chapter37/mvnw -o -B -ntp -s /tmp/java-chapter37/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 -f /tmp/java-chapter37/pom.xml clean verify
```

jdk8-verify.stdout.txt / jdk21-verify.stdout.txt及对应surefire XML为实际输出。初次受限沙箱不能listen，6项报Socket Operation not permitted，原始失败保留sandbox-loopback-blocked.stdout.txt。随后仅为localhost测试启用授权的沙箱外执行，修订connect timeout/executeOpen后重新跑全6项，通过后才写正文。

NOT_RUN：真实外部网络、远端副作用撤销、阻塞I/O即时取消、全链统一期限、恶意并发改写可信目录、磁盘/权限故障造成的删除失败、生产吞吐/峰值内存。应用响应预算不等于网络传输总量；行数预算为整批拒绝非截断。缓存/重试未加入，因为每个唯一商品本批只请求一次。日志含两SLF4J providers警告，未修改其他章节需要的共享POM，不声明生产日志策略已验收。

写作：Java入口；临时草稿先anti-ai-tone，3206汉字/0errors/0warnings；后anti-persona-fabrication关键词无命中并人工通读，无虚构经历/第一人称/拟人/说书人，再apply_patch落盘。完整实现和测试附件与实际源码一致。类级Javadoc保留借入流/client与返回目录所有权，这是公共API必要契约。

Hexo与浏览器由根统一验收，本子任务未运行，未gitcommit/push/deploy。31/36只读审查记录在review31-36.md；没有修改它们。
