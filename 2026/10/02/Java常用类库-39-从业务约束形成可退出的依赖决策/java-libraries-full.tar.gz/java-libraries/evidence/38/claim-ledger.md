# Chapter 38 claim ledger

## Research sequence

1. DOC: owner 31.1 release adds buildKeepingLast; owner 30.1.1 API lacks it. Primary https://github.com/google/guava/releases/tag/v31.1 and https://guava.dev/releases/30.1.1-jre/api/docs/com/google/common/collect/ImmutableMap.Builder.html . Same owner, not independent empirical sources.
2. SOURCE: new SHA 8868c096cfdabbe38170b6e395369c315cfb72a1 ImmutableMap.Builder lines 604–632 buildKeepingLast -> build(false), since31.1. Upstream ImmutableMapTest testBuildKeepingLast_allowsOverwrite and shortTable inspect overwrite/order. Old v30.1.1 tag resolved via git ls-remote to 43a53bc0328c7efd1da152f3b56b1fd241c88d4c; fetched fixed owner raw ImmutableMap.java, lines360–390 build rejects duplicate keys, no keepingLast method. Binary absence additionally observed with old-javap.txt.
3. Reverse checks: direction is newer caller/older runtime, not old caller upgrade incompatibility. JVMS8 5.4.3.3 governs missing-method resolution. Owner security release https://github.com/google/guava/releases/tag/v32.0.0 concerns IO APIs; this probe only uses ImmutableMap. Security applicability cannot be inferred from this probe.

## LAB

JDK8 and21: `-DoldGuavaJar=/tmp/java-libraries-guava-old/guava-30.1.1-jre.jar -Dtest=Chapter38Test clean verify`, two tests each, zero failures/errors/skips. `jdk8.xml`, `jdk21.xml`, respective logs/environment files prove outcomes. Actual fork command/classpath, CodeSource stdout, stderr, SHA256 and exit are in `jdk8-forks/` and `jdk21-forks/`. New exits0/value2/empty stderr; old exits1/NoSuchMethodError/buildKeepingLast and no value2. `old-javap.txt`, `new-javap.txt`, `probe-javap.txt` record actual binary method lists and invocation.

Initial attempt expected uncanonical /tmp paths; macOS CodeSource uses /private/tmp. Fixed assertion to toRealPath, reran full relevant scenario on both JDKs. No LSP jdtls installed; no user request to install, actual Maven javac/tests used.

## NOT_RUN

Alternative LinkedHashMap implementation, production deployment/container classloaders, Android, module path, IO vulnerability exploit, security certification and performance comparison. Upstream tests were read, not run. No JDK compatibility claim beyond the two captured environments.

## Editorial

Draft scanned anti-ai-tone before anti-persona-fabrication and before source write. style-scan.json: 3102 Han, zero errors/warnings; persona-scan.json records second pass. Test attachment byte-identical at publication.
