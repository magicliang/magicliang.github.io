# 06 证据账本

| 结论 | 一手资料与可观察结果 | 等级/判定 | 边界 |
|---|---|---|---|
| mapper null语义不同 | Guava Present/Absent源码、JDK map文档；NPE/empty对照 | DOC+SOURCE+LAB，Verified | 不等于mapper异常也被吞掉 |
| eager与supplier默认值不同 | Present/Absent or源码、JDK orElse/Get；计数2/后续0 | SOURCE+LAB，Verified | 未测分配速度 |
| null默认值/返回值不同 | Guava or检查与JDK默认值契约；四种断言 | DOC+SOURCE+LAB，Verified | 不能假定链末必非null |
| 静态转换保留null容器引用 | Optional固定源码三元分支；两方向null与正常转换断言 | SOURCE+LAB，Verified | 类型转换不修复上游违规null |
| 函数接口适配方向 | Function extends JDK、Predicate default test->apply；赋值/适配运行 | SOURCE+LAB，Verified | 不依赖函数对象equals |
| Java对象流边界 | Serializable声明/序列化规范；Guava String与absent成功，JDK与非序列化内容失败 | DOC+LAB，Verified | 不声明JSON或历史持久化兼容 |

本章4测试/每JDK。present-source.txt和upstream-tests.txt分别记录固定实现与OptionalTest对应反例；上游源码阅读不是上游完整测试执行。对象流只读本进程生成数据，try-with-resources关闭。

反向核验：Guava33.5静态转换不是null-to-empty；函数接口兼容仅由旧子接口到标准父接口；Guava容器Serializable不代表载荷可序列化。怀疑者检查公开类型身份、对抗者使用null mapper与非序列化对象、实施者检查资源闭合和旧接口适配。未运行跨版本SDK二进制替换及历史字节流迁移，正文明确限界。

## 版本与命令

研究日期 2026-10-02。Guava 33.5.0-jre 源码 SHA 8868c096cfdabbe38170b6e395369c315cfb72a1；Commons Lang 3.20.0 SHA 598dfc163b8b410fb3bb8794521206ec8dcec82a。源码来自 /tmp/java-baseline-guava-3350、/tmp/java-baseline-lang-3200，正文固定链接指向上述提交。

隔离副本 /tmp/java-chapters03-06，未使用共享 target。命令为：

```bash
JAVA_HOME=<下面的 JDK 路径> MAVEN_USER_HOME=<仓库>/examples/java-libraries/.maven-user-home /tmp/java-chapters03-06/mvnw -f /tmp/java-chapters03-06/pom.xml -o -B -ntp -s /tmp/java-chapters03-06/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 -Dtest=Chapter03Test,Chapter04Test,Chapter05Test,Chapter06Test clean verify
```

JDK8 路径 /Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home；JDK21 路径 /Users/magicliang/.sdkman/candidates/java/21.0.11-amzn。两次退出码均为 0，批次各12测试、0失败/错误/跳过。原始完整日志 jdk8-verify.stdout.txt、jdk21-verify.stdout.txt；各章独立 XML 为 jdk8-surefire.xml、jdk21-surefire.xml，包含 java.version/java.home 环境及逐用例时间、system-out。二十一版的旧 source/target 警告未屏蔽。

正文独立 main 由 Markdown Java 代码块原样生成到隔离目录 snippets，通过 JDK8 javac 编译，分别用 Java8/21 运行；输出为 snippet-jdk8.stdout.txt、snippet-jdk21.stdout.txt。完整 main 与测试不同，分别验收。没有耗时性能、线程安全或其他运行时的实验结论。

## 写作验收

java-tech-writer 与 deep-research 入口；临时草稿先运行 anti-ai-tone check_prose.py --profile tech --json，再进行 anti-persona-fabrication 红线扫描与逐段复查后 apply_patch 落盘。style-ai.json 保存首次落盘前扫描；persona 未命中第一人称、虚构经历、说书人腔。正文含业务输入、机制、正常路径/反例、手算题、改动练习、两种迁移模式。独立审阅和最终 Hexo 由根整合验收，此文件不将尚未执行的页面验收报为通过。
