# Chapter 18 claim ledger

LAB：2项测试：SHA256空串/abc已知向量；中文UTF8与JDK MessageDigest一致；putInt小端序；字段无边界拼接反例与长度前缀；Random seed20261002、expected1000/fpp.01、实际1000/10000、精确LinkedHashSet真值、10000个不相交查询，误判110/9949，重复插入不改bits，已插入无阴性。SOURCE：BloomFilter/AbstractByteHasher/BloomFilterStrategies。DOC：版本化BloomFilter、NIST示例向量列表。NOT_RUN：密码存储、真实性能、所有输入分布或种子的概率保证；固定种子统计仅为本样本。

## 固定来源

Guava 33.5.0-jre commit 8868c096cfdabbe38170b6e395369c315cfb72a1。source-inspection.txt含本次读取的固定源码。正文链接指向此SHA或版本化Javadoc；反查搜索可能返回旧版或master，只作线索，不替代固定版。

## 实际调用与观测

隔离工程 /tmp/java-chapters16-19，仅含16–19测试，不写共享target。

```sh
JAVA_HOME=<Zulu8或Corretto21路径> MAVEN_USER_HOME=<仓库>/examples/java-libraries/.maven-user-home /tmp/java-chapters16-19/mvnw -f /tmp/java-chapters16-19/pom.xml -o -B -ntp -s /tmp/java-chapters16-19/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify
```

jdk8-verify.stdout.txt、jdk21-verify.stdout.txt为完整实际输出；jdk8-surefire.xml、jdk21-surefire.xml为本章JUnit结果。整个隔离组13tests，0failures/errors/skips。正文4个main分别在双JDK编译和运行，具体命令/退出码/输出见jdk8-snippet.stdout.txt、jdk21-snippet.stdout.txt。

## 写作与限制

临时草稿先执行anti-ai-tone check_prose.py --profile tech --json，输出anti-ai-tone.json；随后anti-persona-fabrication关键词+人工通读无第一人称叙事/拟人/说书人，输出anti-persona-fabrication.json。16的单个heavy_de_sentence警告复核为比较具体Future实现的必要限定，保留，无错误。完成两步后才apply_patch落盘。

未运行全站Hexo和浏览器验收，由根协调器统一执行；本记录不声称已完成页面验收。没有commit/push/deploy。
