# 第 12 篇证据账本

研究日期：2026-10-02。范围：计划第 12 篇的商品导入容器契约；读者为Java工程师；以固定版本的公开契约、源码路径、反例与两个JDK实验交叉验证。Guava 33.5.0-jre，源码 SHA 8868c096cfdabbe38170b6e395369c315cfb72a1。

固定源码根：https://github.com/google/guava/tree/8868c096cfdabbe38170b6e395369c315cfb72a1/guava/src/com/google/common/collect

| 结论 | 证据等级 | 场景及二元判定 |
|---|---|---|
| 重复值拒绝保持原关系 | SOURCE/LAB | duplicateValueIsRejectedBeforeMutation |
| forcePut两条变一条 | DOC/SOURCE/LAB | forcePutCanDeleteTwoOldAssociationsAndReturnOnlyOneValue |
| inverse共享/null歧义 | DOC/SOURCE/LAB | inverseIsWritableSharedDataAndNullNeedsContainsKey |
| row/column联动及缺失行 | SOURCE/LAB | rowAndColumnViewsWriteThroughAndMissingRowCanBecomePresent |
| Table非法null/整行替换 | SOURCE/LAB | tableRejectsNullsAndWholeRowReplacement |

来源：BiMap.java、HashBiMap.java、HashBasedTable.java、StandardTable.java；上游HashBiMapTest.testInsertionOrderAfterForcePut等已读，未运行上游测试。列扫描源码直接见StandardTable.Column.EntrySet.size及containsColumn。
反向复核：BiMap双向索引不意味着Table双向维护同等物理索引；单次put冲突保持状态不代表批量事务；forcePut返回当前键旧值，不返回被抢占值的旧键。

## 实际执行

隔离副本 /tmp/java-libraries-11-14 只包含11–14测试、基础main和冻结的00–02 POM，避免共享target竞争。最终两次clean verify各运行19个测试，exit=0，全部failures/errors/skipped=0。原始stdout文件 jdk8-verify.stdout.txt 与 jdk21-verify.stdout.txt 包含整个19测试批次，本章结果分别见 jdk8-TEST-blog.libraries.Chapter12Test.xml 和 jdk21-TEST-blog.libraries.Chapter12Test.xml（5项）。XML内java.version/java.home记录实际环境。

```sh
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home MAVEN_USER_HOME=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/java-libraries/.maven-user-home /tmp/java-libraries-11-14/mvnw -B -ntp -o -f /tmp/java-libraries-11-14/pom.xml -s /tmp/java-libraries-11-14/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn MAVEN_USER_HOME=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/java-libraries/.maven-user-home /tmp/java-libraries-11-14/mvnw -B -ntp -o -f /tmp/java-libraries-11-14/pom.xml -s /tmp/java-libraries-11-14/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify
```

## 写作与研究复核

按java-tech-writer及deep-research执行：问题分解为身份/数量、修改入口、别名、边界异常与替代条件；官方Javadoc+固定源码深读；搜索官方issues与旧wiki以反向寻找过时说明；独立本地测试反证过度推广。九阶段研究的综合与批判记录归入本账本。怀疑者检查定量结果是否来自断言，对抗者检查null/边界/别名，实施者检查Java8与隔离复跑。没有把官方文档与同项目源码当成两个独立作者的共识。

临时草稿先运行anti-ai-tone脚本，再人工anti-persona-fabrication检查第一人称、身体/经历/社交/写作旁白；零命中后才落盘。style-scan.json为最终草稿扫描，0错误0警告；代码与技术标识不做拟人扫描。独立外部审阅与整站Hexo/HTTP由根任务统一完成，不在此伪称已验收。

NOT_RUN：并发修改、JMH耗时、堆占用、全上游测试suite。文章对这些主题仅给设计边界或明确源码分析，未声称实测。
