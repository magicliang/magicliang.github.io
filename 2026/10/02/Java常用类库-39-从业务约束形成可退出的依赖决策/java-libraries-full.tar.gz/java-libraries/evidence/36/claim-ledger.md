# 36 基准验收

DOC/SOURCE：JMH 1.37 commit 2effa2c8310e1d3ad03c8ee02024edca9252b46a；官方样例08、10、11、12；Result.java mean error/confidence 0.999；GCProfiler.java allocation snapshots/allOps。源码固定版本实际读过。

LAB：benchmarks release17，实际Corretto21.0.11/macOS aarch64。build.stdout.txt退出0；第一次sandbox运行协调socket失败不计成绩；第二次jmh.stdout.txt退出0，9基准各2fork、各3个测量值，2次1秒预热/3次1秒测量，1线程，256MiB固定堆。

LAB：初始化确认3种映射相同对象值、2种完整列表相等、2种缓存加载结果相等。JSON原始数据完整可重算，记录均值、99.9%均值区间、GC分配B/op。CaffeineMiss直接执行器与命中默认执行器条件明确。

NOT_RUN：Java8、其他JDK/平台/GC、汇编与硬件计数器、大工作集、多线程共享状态、Zipf分布、服务请求尾延迟、保留堆分析。均值区间不是尾延迟；分配不是可达对象/retained heap；区间重叠不形成稳定排名。
