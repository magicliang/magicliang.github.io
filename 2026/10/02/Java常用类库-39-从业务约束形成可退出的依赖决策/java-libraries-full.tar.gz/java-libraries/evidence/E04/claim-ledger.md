# E04 claims / evidence ledger

基线：Gson 2.14.0 3ff35d6269894901ab8006258395aafc4b9765cd；Jackson Databind 2.20.1 4164a2b47d3795a28f7cb838a02c27b77f9adaf4；JavaTime 2.20.1。

- DOC/SOURCE：Gson ReflectiveTypeAdapterFactory.java：字段发现和fieldValue==source时跳过；JavaTimeTypeAdapters.java：Instant使用seconds/nanos。Jackson反序列化特性FAIL_ON_UNKNOWN_PROPERTIES、ACCEPT_FLOAT_AS_INT及JsonFactory重复键检测。
- LAB：missingNullUnknownAndExposureHaveSeparateContracts；genericNumericDateAndTreesCanShareAnExplicitContract；duplicatePolicyNeedsMoreThanStrictJsonGrammar；byteBudgetPrecedesTreeMaterializationAndCyclesAreNotIdentityGraphs。
- 反向核验：初版以为支持Instant即默认ISO，真实测试失败；source确认后保留默认seconds/nanos并注册ISO TypeAdapter再比较。Gson上游CircularReferenceTest明确直接自引用跳过与更长循环失败不同；本地只测直接自引用。
- NOT_RUN：Gson重复检查仅根对象；未跑更长循环、全部数值范围、任意时区/精度、堆峰值或JSON性能。输入字节限制并非所有解析资源证明。

完整实际运行在隔离 /tmp/java-libraries-extensions，没有写共享 target：

```bash
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn MAVEN_USER_HOME=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/java-libraries/.maven-user-home /tmp/java-libraries-extensions/mvnw -B -ntp -o -f /tmp/java-libraries-extensions/pom.xml -s /tmp/java-libraries-extensions/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify
```

JDK8同命令切换JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home。处理器模块初次运行使用系列wrapper与settings，后复制同一wrapper入独立包；实际POM和源码均相同。10 tests每JDK通过，本章4 tests，无失败错误跳过。原始jdk8/jdk21 stdout与original Surefire XML在当前目录；各次clean前保存XML。

文章先在/tmp草稿运行anti-ai-tone，再执行persona人工连读和模式检查，最终apply_patch。JSON保存扫描结果、顺序和草稿SHA256；最终字节及所有资产核对见evidence/E03/delivery-check.json。源码下载和测试工程一致。E08 generated附件匹配jdk21生成证据；E03 JMH JSON字节与36源证据一致。

源码仓库均为官方tag冻结；完整固定URL已在正文，不把当前站点snapshot作为版本依据。没有运行整个上游测试套件；读取上游断言与执行本地断言分别标记。
