# E03 claims / evidence ledger

基线：fastutil 8.5.16 aa30fa7d93bf06fec45c4f6f572a1f6a38047d9f；Eclipse Collections 11.1.0 fb6abf7fe655ff04acf616158bce49725f2df5ad；JOL 0.17 400c871bd4b7542fdbba96f4081b1ec3a01b5ebe。均固定Java8实验基线。

- DOC/SOURCE：fastutil drv/Function.drv 默认返回协议与containsKey组合；drv/Map.drv FastEntrySet说明对象可复用；drv/OpenHashMap.drv 返回defRetValue分支。Eclipse eclipse-collections-code-generator/src/main/resources/impl/map/mutable/primitivePrimitiveHashMap.stg 与对应test模板。JOL GraphLayout/VM布局估计，未取得Instrumentation/SA告警保留。
- LAB：absenceMustNotBeInferredFromZeroOrNull：null/0/-1碰撞；sameInputsHaveEqualIterationChecksumsButDifferentProtocols：1024项、校验和6191104；objectGraphLayoutEstimateIsNotRetainedHeapOrAllocationRate：HashMap73792/fastutil32880/Eclipse32840布局估计字节。
- 反向核验：反查专用迭代Entry复用文档，未把快速迭代条目当持久快照。确认36 benchmark是int→Object、共享Integer值；原始类型值协议与该基准分开。
- NOT_RUN：未跑随机/未命中/扩容/并发基准；JMH只复用36已跑数据，未在本章重新运行；JOL不是GC retained heap，不同根分别统计共享对象不能直接相加。

完整实际运行在隔离 /tmp/java-libraries-extensions，没有写共享 target：

```bash
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn MAVEN_USER_HOME=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/java-libraries/.maven-user-home /tmp/java-libraries-extensions/mvnw -B -ntp -o -f /tmp/java-libraries-extensions/pom.xml -s /tmp/java-libraries-extensions/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify
```

JDK8同命令切换JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home。处理器模块初次运行使用系列wrapper与settings，后复制同一wrapper入独立包；实际POM和源码均相同。10 tests每JDK通过，本章3 tests，无失败错误跳过。原始jdk8/jdk21 stdout与original Surefire XML在当前目录；各次clean前保存XML。

文章先在/tmp草稿运行anti-ai-tone，再执行persona人工连读和模式检查，最终apply_patch。JSON保存扫描结果、顺序和草稿SHA256；最终字节及所有资产核对见evidence/E03/delivery-check.json。源码下载和测试工程一致。E08 generated附件匹配jdk21生成证据；E03 JMH JSON字节与36源证据一致。

源码仓库均为官方tag冻结；完整固定URL已在正文，不把当前站点snapshot作为版本依据。没有运行整个上游测试套件；读取上游断言与执行本地断言分别标记。
