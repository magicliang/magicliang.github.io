# Chapter 29 claim ledger

基线：Commons CSV 1.14.1，源码 e14ef86d34211f9d1b9b6040c5f6dbafc93ba907。DOC 为官方文档；SOURCE 为固定源码；LAB 为本地断言；NOT_RUN 不声称验证。现行官网可能显示 snapshot，行为归属于固定 SHA。

- SOURCE: https://github.com/apache/commons-csv/blob/e14ef86d34211f9d1b9b6040c5f6dbafc93ba907/src/main/java/org/apache/commons/csv/CSVFormat.java
- SOURCE: https://github.com/apache/commons-csv/blob/e14ef86d34211f9d1b9b6040c5f6dbafc93ba907/src/main/java/org/apache/commons/csv/CSVParser.java#createHeaders/close
- SOURCE: https://github.com/apache/commons-csv/blob/e14ef86d34211f9d1b9b6040c5f6dbafc93ba907/src/main/java/org/apache/commons/csv/CSVRecord.java

- 上游反向核验：src/test/java/org/apache/commons/csv/CSVParserTest.java#testBOMInputStreamParserWithReader; createHeaders source rules
- SOURCE/DOC 结论：逐条解析/打印保存逗号、多行、引号、空字段；BOM 去除后表头准确；重复缺失列名拒绝；缺字段 isConsistent=false，逻辑 recordNo1；未闭合引号遍历阶段错误含 line。
- LAB 场景：streamingRoundTripPreservesFieldsNotSourceBytes; bomAndHeaderPolicyAreExplicit; unevenRowsAndUnclosedQuotesHaveDifferentDiagnostics; csvQuotingDoesNotNeutralizeSpreadsheetFormula
- LAB 反例：CSVPrinter 的 =1+1 仍可作为公式文本；独立首字符前缀策略也改变 -1，所以不泛化电子表格安全。
- 边界：NOT_RUN: spreadsheet application execution, hard allocation cap, mandatory-column set, huge file performance, business transaction atomicity.

实际命令（隔离副本，不触及共享 target）：

```bash
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn MAVEN_USER_HOME=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/java-libraries/.maven-user-home /tmp/java-libraries-25-30/mvnw -B -ntp -o -f /tmp/java-libraries-25-30/pom.xml -s /tmp/java-libraries-25-30/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify
```

第二次完整运行替换 JAVA_HOME 为 /Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home。两次 23 tests / 0 failures / 0 errors / 0 skipped。raw 输出见 jdk8-verify.stdout.txt 与 jdk21-verify.stdout.txt；本章各 4 个测试的 original Surefire XML 同目录。编译前同步所有本次最终源码至隔离副本；测试间复制 XML，避免 clean 覆盖证据。

交付扫描：/tmp/java-libraries-29-draft.md 先 check_prose.py --profile tech，再 anti-persona-fabrication 人工连读及模式扫描，之后 apply_patch 正文。报告 anti-ai-tone.json 与 anti-persona-fabrication.json；正文/附件/hash/XML 综合检查由 evidence/25/delivery-check.json 记录。
