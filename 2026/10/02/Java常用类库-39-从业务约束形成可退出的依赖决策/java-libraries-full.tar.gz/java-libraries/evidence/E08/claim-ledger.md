# E08 claims / evidence ledger

基线：MapStruct1.6.3 b4e25e49deae707b50ce061172e114292b414a23；Lombok1.18.42 2031eb0880942b5f0b7281580f6e877a3e87279a；binding0.2.0二进制坐标与SHA256在artifact-checksums.sha256，通知源码参考同Lombok固定commit，不声称从该源码重建0.2.0。

- DOC/SOURCE：MapStruct core/BeanMapping.java默认SET_TO_NULL；生成ProductMapperImpl实际null检查、builder/newArrayList、update clear/addAll；Lombok src/bindings/mapstruct/lombok/mapstruct/NotifierHider.java，javap实际getter/builder/equals/hashCode。
- LAB：createMatchesManualContractAndNullSourceReturnsNull；updateDefaultNullAndIgnoreHaveDifferentMeanings；builderSharesValuesAndGeneratedHashCodeDoesNotFreezeKeys；missingTargetFieldIsARealCompilerDiagnostic。最后一项ToolProvider真实编译返回false且诊断Unmapped target property extra。
- 反向核验：上游UnmappedProductTest#shouldRaiseErrorDueToUnsetTargetProperty与本地Compiler负例一致；MapStruct官方FAQ较新Lombok须binding。generated更新集合所需可变性、源目标别名边界明确为尚未实测。
- NOT_RUN：未跑IDE集成、其他JDK、构建性能、不可变目标/源目标同列表更新；列表容器复制不推导深复制；Data/builder不推导线程安全；仅关闭生成时间戳非字节级可复现构建。

完整实际运行在隔离 /tmp/java-libraries-processors，没有写共享 target：

```bash
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn MAVEN_USER_HOME=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/java-libraries/.maven-user-home /tmp/java-libraries-processors/mvnw -B -ntp -o -f /tmp/java-libraries-processors/pom.xml -s /tmp/java-libraries-processors/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify
```

JDK8同命令切换JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home。处理器模块初次运行使用系列wrapper与settings，后复制同一wrapper入独立包；实际POM和源码均相同。4 tests每JDK通过，本章4 tests，无失败错误跳过。原始jdk8/jdk21 stdout与original Surefire XML在当前目录；各次clean前保存XML。

文章先在/tmp草稿运行anti-ai-tone，再执行persona人工连读和模式检查，最终apply_patch。JSON保存扫描结果、顺序和草稿SHA256；最终字节及所有资产核对见evidence/E03/delivery-check.json。源码下载和测试工程一致。E08 generated附件匹配jdk21生成证据；E03 JMH JSON字节与36源证据一致。

源码仓库均为官方tag冻结；完整固定URL已在正文，不把当前站点snapshot作为版本依据。没有运行整个上游测试套件；读取上游断言与执行本地断言分别标记。
