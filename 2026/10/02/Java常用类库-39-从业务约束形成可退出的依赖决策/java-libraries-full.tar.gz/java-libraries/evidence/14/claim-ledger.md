# 第 14 篇证据账本

研究日期：2026-10-02。范围：计划第 14 篇的商品导入容器契约；读者为Java工程师；以固定版本的公开契约、源码路径、反例与两个JDK实验交叉验证。Guava 33.5.0-jre，源码 SHA 8868c096cfdabbe38170b6e395369c315cfb72a1。

固定源码根：https://github.com/google/guava/tree/8868c096cfdabbe38170b6e395369c315cfb72a1/guava/src/com/google/common/collect

| 结论 | 证据等级 | 场景及二元判定 |
|---|---|---|
| 开闭/离散空集 | DOC/SOURCE/LAB | endpointsAndDiscreteEmptinessAreDifferentQuestions |
| 连通可为空交集 | DOC/SOURCE/LAB | connectedDoesNotMeanNonEmptyIntersection |
| RangeSet合并删除分裂 | SOURCE/LAB | rangeSetCoalescesAndRemovalSplitsWithExactEndpoints |
| RangeMap覆盖和空洞 | SOURCE/LAB | rangeMapOverwriteKeepsOuterFragmentsAndRemoveCreatesHole |
| 相邻同值合并与窗口联动 | SOURCE/LAB | sameValueNeedsExplicitCoalescingAndViewsAreLive；putCoalescing([10,20))合并左相邻段 |

来源：Range.java、Cut.java、DiscreteDomain.java、TreeRangeSet.java、TreeRangeMap.java。上游RangeTest.testIsConnected/testEmpty与TreeRangeMapTest.testPutCoalescing/testPutCoalescingEmpty已读，未运行上游suite。
反向复核发现旧wiki https://github.com/google/guava/wiki/NewCollectionTypesExplained/7945a03e30c7158b61ef5dfed7316f4cc787db00 声称RangeMap never coalesces；固定版本已有putCoalescing，正文纠正过度泛化。初稿测试覆盖整个[0,20)不能区分普通put，已改为仅[10,20)并重跑全19测试。

## 实际执行

隔离副本 /tmp/java-libraries-11-14 只包含11–14测试、基础main和冻结的00–02 POM，避免共享target竞争。最终两次clean verify各运行19个测试，exit=0，全部failures/errors/skipped=0。原始stdout文件 jdk8-verify.stdout.txt 与 jdk21-verify.stdout.txt 包含整个19测试批次，本章结果分别见 jdk8-TEST-blog.libraries.Chapter14Test.xml 和 jdk21-TEST-blog.libraries.Chapter14Test.xml（5项）。XML内java.version/java.home记录实际环境。

```sh
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home MAVEN_USER_HOME=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/java-libraries/.maven-user-home /tmp/java-libraries-11-14/mvnw -B -ntp -o -f /tmp/java-libraries-11-14/pom.xml -s /tmp/java-libraries-11-14/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn MAVEN_USER_HOME=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/java-libraries/.maven-user-home /tmp/java-libraries-11-14/mvnw -B -ntp -o -f /tmp/java-libraries-11-14/pom.xml -s /tmp/java-libraries-11-14/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify
```

## 写作与研究复核

按java-tech-writer及deep-research执行：问题分解为身份/数量、修改入口、别名、边界异常与替代条件；官方Javadoc+固定源码深读；搜索官方issues与旧wiki以反向寻找过时说明；独立本地测试反证过度推广。九阶段研究的综合与批判记录归入本账本。怀疑者检查定量结果是否来自断言，对抗者检查null/边界/别名，实施者检查Java8与隔离复跑。没有把官方文档与同项目源码当成两个独立作者的共识。

临时草稿先运行anti-ai-tone脚本，再人工anti-persona-fabrication检查第一人称、身体/经历/社交/写作旁白；零命中后才落盘。style-scan.json为最终草稿扫描，0错误0警告；代码与技术标识不做拟人扫描。独立外部审阅与整站Hexo/HTTP由根任务统一完成，不在此伪称已验收。

NOT_RUN：并发修改、JMH耗时、堆占用、全上游测试suite。文章对这些主题仅给设计边界或明确源码分析，未声称实测。
