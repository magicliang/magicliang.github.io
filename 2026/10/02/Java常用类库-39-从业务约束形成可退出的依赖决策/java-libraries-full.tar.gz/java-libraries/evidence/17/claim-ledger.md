# Chapter 17 claim ledger

LAB：4项测试：确定模型rate2 acquire(4),acquire(),acquire()等待0/2/.5秒；idle3秒后2个存储许可与随后1个新许可零等待，try499ms失败/500ms成功；warmup rate2/period4s/cold3等待0/1.375/1.125/.875/.625/.5；真实时钟测acquire(3)，记录计划与elapsed；3并发线程在完成前均取得许可，Semaphore2第三次失败。SOURCE：RateLimiter/SmoothRateLimiter及上游RateLimiterTest。NOT_RUN：动态setRate、全线程交错公平性、分布式配额与严格滑窗；未将假时钟当真实时间。真实测量保留初次执行raw logs，不把一次调度误差推广成保证。

## 固定来源

Guava 33.5.0-jre commit 8868c096cfdabbe38170b6e395369c315cfb72a1。source-inspection.txt含本次读取的固定源码。正文链接指向此SHA或版本化Javadoc；反查搜索可能返回旧版或master，只作线索，不替代固定版。

## 实际调用与观测

隔离工程 /tmp/java-chapters16-19，仅含16–19测试，不写共享target。

```sh
JAVA_HOME=<Zulu8或Corretto21路径> MAVEN_USER_HOME=<仓库>/examples/java-libraries/.maven-user-home /tmp/java-chapters16-19/mvnw -f /tmp/java-chapters16-19/pom.xml -o -B -ntp -s /tmp/java-chapters16-19/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify
```

jdk8-verify.stdout.txt、jdk21-verify.stdout.txt为完整实际输出；jdk8-surefire.xml、jdk21-surefire.xml为本章JUnit结果。整个隔离组13tests，0failures/errors/skips。正文4个main分别在双JDK编译和运行，具体命令/退出码/输出见jdk8-snippet.stdout.txt、jdk21-snippet.stdout.txt。

## 写作与限制

临时草稿先执行anti-ai-tone check_prose.py --profile tech --json，输出anti-ai-tone.json；随后anti-persona-fabrication关键词+人工通读无第一人称叙事/拟人/说书人，输出anti-persona-fabrication.json。16的单个heavy_de_sentence警告复核为比较具体Future实现的必要限定，保留，无错误。完成两步后才apply_patch落盘。

未运行全站Hexo和浏览器验收，由根协调器统一执行；本记录不声称已完成页面验收。没有commit/push/deploy。
