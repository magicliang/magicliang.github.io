# 05 证据账本

| 结论 | 一手资料与可观察结果 | 等级/判定 | 边界 |
|---|---|---|---|
| 参数/状态/假设类别不同 | Preconditions/Verify版本Javadoc与源码；IAE/ISE/VerifyException和精确消息断言 | DOC+SOURCE+LAB，Verified | 不自动映射HTTP状态码 |
| 两种普通null检查返回原引用 | Objects与Preconditions文档；assertSame及null异常消息 | DOC+LAB，Verified | verifyNotNull故意类别不同 |
| 消息参数eager | JLS15.7.4；合法条件仍计数、消息函数异常提前终止 | DOC+LAB，Verified | 不声称微基准收益 |
| Supplier方法体延迟 | Objects文档；非null不调用、null调用一次 | DOC+LAB，Verified | lambda自身成本未测 |
| 格式不是printf | Strings源码与Javadoc；bad %d: A [7] | DOC+SOURCE+LAB，Verified | 不是稳定跨版本错误协议 |

本章3测试/每JDK。source-inspection.txt 保存Preconditions/Verify/Strings相关分支（含03共用HashMap定位摘录）。上游 PreconditionsTest/VerifyTest 路径位于 guava-tests/test/com/google/common/base，结合正文对格式、异常、求值反例验证，不声称运行上游整套测试。

反向核验：延迟format与延迟参数严格分离；Verify不是assert开关；toString防护不能捕获方法外已发生的表达式异常。怀疑者检查诊断副作用、对抗者提供正常条件+抛异常消息、实施者区分批量预检与快速失败。并发原子性与回滚没有实验，正文未作为实测结论。

## 版本与命令

研究日期 2026-10-02。Guava 33.5.0-jre 源码 SHA 8868c096cfdabbe38170b6e395369c315cfb72a1；Commons Lang 3.20.0 SHA 598dfc163b8b410fb3bb8794521206ec8dcec82a。源码来自 /tmp/java-baseline-guava-3350、/tmp/java-baseline-lang-3200，正文固定链接指向上述提交。

隔离副本 /tmp/java-chapters03-06，未使用共享 target。命令为：

```bash
JAVA_HOME=<下面的 JDK 路径> MAVEN_USER_HOME=<仓库>/examples/java-libraries/.maven-user-home /tmp/java-chapters03-06/mvnw -f /tmp/java-chapters03-06/pom.xml -o -B -ntp -s /tmp/java-chapters03-06/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 -Dtest=Chapter03Test,Chapter04Test,Chapter05Test,Chapter06Test clean verify
```

JDK8 路径 /Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home；JDK21 路径 /Users/magicliang/.sdkman/candidates/java/21.0.11-amzn。两次退出码均为 0，批次各12测试、0失败/错误/跳过。原始完整日志 jdk8-verify.stdout.txt、jdk21-verify.stdout.txt；各章独立 XML 为 jdk8-surefire.xml、jdk21-surefire.xml，包含 java.version/java.home 环境及逐用例时间、system-out。二十一版的旧 source/target 警告未屏蔽。

正文独立 main 由 Markdown Java 代码块原样生成到隔离目录 snippets，通过 JDK8 javac 编译，分别用 Java8/21 运行；输出为 snippet-jdk8.stdout.txt、snippet-jdk21.stdout.txt。完整 main 与测试不同，分别验收。没有耗时性能、线程安全或其他运行时的实验结论。

## 写作验收

java-tech-writer 与 deep-research 入口；临时草稿先运行 anti-ai-tone check_prose.py --profile tech --json，再进行 anti-persona-fabrication 红线扫描与逐段复查后 apply_patch 落盘。style-ai.json 保存首次落盘前扫描；persona 未命中第一人称、虚构经历、说书人腔。正文含业务输入、机制、正常路径/反例、手算题、改动练习、两种迁移模式。独立审阅和最终 Hexo 由根整合验收，此文件不将尚未执行的页面验收报为通过。
