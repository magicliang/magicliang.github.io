# Chapter 26 claim ledger

基线：Commons IO 2.22.0 / JDK Path，源码 c14acc16f73e44a75b2062b17aacb26c4feda746。DOC 为官方文档；SOURCE 为固定源码；LAB 为本地断言；NOT_RUN 不声称验证。现行官网可能显示 snapshot，行为归属于固定 SHA。

- SOURCE: https://github.com/apache/commons-io/blob/c14acc16f73e44a75b2062b17aacb26c4feda746/src/main/java/org/apache/commons/io/FilenameUtils.java#doNormalize

- 上游反向核验：src/test/java/org/apache/commons/io/FilenameUtilsTest.java#testNormalize
- SOURCE/DOC 结论：normalize 是词法转换；Path startsWith 分段比较；toRealPath 与父目录检查处理实际路径；CREATE_NEW 保留不覆盖政策。
- LAB 场景：text normalization; relative/absolute/mixed separator rejection matrix; actual symlink and existing file plus valid nested creation
- LAB 反例：实际 root/link 指向 outside；目标拒绝且 outside 文件不存在；existing 文件字节 7 保持。
- 边界：NOT_RUN: Windows, hard links, TOCTOU hostile writers, SecureDirectoryStream implementation. Requires private root with no untrusted concurrent writers.

实际命令（隔离副本，不触及共享 target）：

```bash
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn MAVEN_USER_HOME=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/java-libraries/.maven-user-home /tmp/java-libraries-25-30/mvnw -B -ntp -o -f /tmp/java-libraries-25-30/pom.xml -s /tmp/java-libraries-25-30/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify
```

第二次完整运行替换 JAVA_HOME 为 /Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home。两次 23 tests / 0 failures / 0 errors / 0 skipped。raw 输出见 jdk8-verify.stdout.txt 与 jdk21-verify.stdout.txt；本章各 3 个测试的 original Surefire XML 同目录。编译前同步所有本次最终源码至隔离副本；测试间复制 XML，避免 clean 覆盖证据。

交付扫描：/tmp/java-libraries-26-draft.md 先 check_prose.py --profile tech，再 anti-persona-fabrication 人工连读及模式扫描，之后 apply_patch 正文。报告 anti-ai-tone.json 与 anti-persona-fabrication.json；正文/附件/hash/XML 综合检查由 evidence/25/delivery-check.json 记录。
