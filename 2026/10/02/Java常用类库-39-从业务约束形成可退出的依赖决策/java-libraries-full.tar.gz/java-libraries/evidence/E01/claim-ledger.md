# E01 claim ledger

## DOC/SOURCE

固定版本Guava 33.5.0-jre，SHA 8868c096cfdabbe38170b6e395369c315cfb72a1。Graph/ValueGraph/Network/StandardMutableNetwork/ImmutableGraph固定源码。DOC官方GraphsExplained；反向搜索node removed invalidated，官方说明33.1.0以后视图失效，正文不泛化未测删除行为。

source-inspection.txt含实际git rev-parse输出和读取的源码全文；正文所有实现结论固定到此版本。网络官方文档与issue用于反向核对，master搜索结果不替代固定源码。检索日期2026-10-02。

## LAB

Graph/ValueGraph/Network同一端点数据分别2/2/3条边，asGraph为2；四节点含orphan；Graph重复边false、ValueGraph替换返回10、Network重复edge对象端点冲突IAE；有向反向不存在、自环拒绝和无向自环degree2；配置nodes插入顺序；successors实时只读视图、ImmutableGraph快照不变；添加反向形成环；JDK邻接Map保留孤立节点和纯终点。

Java8与Java21每次2项测试均0failure/error/skip。原始输出jdk*-verify.stdout.txt；独立JUnit报告jdk*-surefire.xml。完整正文main通过javac/java，详见jdk*-snippet.stdout.txt，包含真实命令、退出码和stdout。

实际Maven调用（独立工程，不写共享target）：

```sh
JAVA_HOME=<JDK路径> MAVEN_USER_HOME=<repo>/examples/java-libraries/.maven-user-home /tmp/java-extensions-01020607/mvnw -o -B -ntp -s /tmp/java-extensions-01020607/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 -f /tmp/java-extensions-01020607/pom.xml clean verify
```

legacy组共8项：E01=2/E02=3/E06=3，modern组E07=4。JUnit XML含JVM具体版本与依赖classpath。SOURCE不等同LAB；合成fatal异常不等于实际VM崩溃。

## NOT_RUN/限制

并发图修改、删除节点后视图全部操作、图算法性能/内存未测。 全站Hexo、浏览器由根统一验收，本子任务不声称已运行。未gitcommit/push/deploy。LSP未安装，未安装新工具；使用真实javac/Maven验证替代。

## 写作前置检查

临时/tmp/javaE01-draft.md先执行anti-ai-tone check_prose.py --profile tech --json，0errors/0warnings，结果anti-ai-tone.json；随后anti-persona-fabrication关键词扫描无命中并通读，无第一人称叙事/软件拟人/虚构经验/说书人。通过后apply_patch落盘；正文完整imports例子有独立编译执行，不只依赖测试。
