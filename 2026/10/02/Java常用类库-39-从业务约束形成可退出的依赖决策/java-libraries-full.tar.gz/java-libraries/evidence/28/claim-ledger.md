# Chapter 28 claim ledger

基线：Commons Codec 1.22.1，源码 dc8f6c832a30f524bf12a5ae7ab013e4ad7c088f。DOC 为官方文档；SOURCE 为固定源码；LAB 为本地断言；NOT_RUN 不声称验证。现行官网可能显示 snapshot，行为归属于固定 SHA。

- SOURCE: https://github.com/apache/commons-codec/blob/dc8f6c832a30f524bf12a5ae7ab013e4ad7c088f/src/main/java/org/apache/commons/codec/binary/Base64.java#decode/validateCharacter
- SOURCE: https://github.com/apache/commons-codec/blob/dc8f6c832a30f524bf12a5ae7ab013e4ad7c088f/src/main/java/org/apache/commons/codec/digest/DigestUtils.java
- SOURCE: https://github.com/apache/commons-codec/blob/dc8f6c832a30f524bf12a5ae7ab013e4ad7c088f/src/main/java/org/apache/commons/codec/digest/HmacUtils.java

- 上游反向核验：src/test/java/org/apache/commons/codec/binary/Base64Test.java#assertBase64DecodingOfTrailingBits; digest/DigestUtilsTest.java#testSha256; https://datatracker.ietf.org/doc/html/rfc4231#section-4.2
- SOURCE/DOC 结论：FBFF -> +/8= and -_8；STRICT 拒绝 TR== 尾比特但接受 T!Q==，decodeBase64Standard 同样跳过 !；JDK basic 拒绝该字符；SHA256abc/RFC4231 HMAC 向量匹配。
- LAB 场景：urlAlphabetPaddingAndCharsetAreSeparateChoices; strictTrailingBitsDoesNotMeanStrictAlphabet; digestAndHmacMatchPublishedVectors
- LAB 反例：初次把 static Standard 当成 alphabet-strict 的断言失败，回读 decode 分支修正；odd Hex 拒绝。
- 边界：NOT_RUN: server MAC verification, replay rejection, key management, complete canonical Base64 grammar matrix.

实际命令（隔离副本，不触及共享 target）：

```bash
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn MAVEN_USER_HOME=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/java-libraries/.maven-user-home /tmp/java-libraries-25-30/mvnw -B -ntp -o -f /tmp/java-libraries-25-30/pom.xml -s /tmp/java-libraries-25-30/.mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 clean verify
```

第二次完整运行替换 JAVA_HOME 为 /Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home。两次 23 tests / 0 failures / 0 errors / 0 skipped。raw 输出见 jdk8-verify.stdout.txt 与 jdk21-verify.stdout.txt；本章各 3 个测试的 original Surefire XML 同目录。编译前同步所有本次最终源码至隔离副本；测试间复制 XML，避免 clean 覆盖证据。

交付扫描：/tmp/java-libraries-28-draft.md 先 check_prose.py --profile tech，再 anti-persona-fabrication 人工连读及模式扫描，之后 apply_patch 正文。报告 anti-ai-tone.json 与 anti-persona-fabrication.json；正文/附件/hash/XML 综合检查由 evidence/25/delivery-check.json 记录。
