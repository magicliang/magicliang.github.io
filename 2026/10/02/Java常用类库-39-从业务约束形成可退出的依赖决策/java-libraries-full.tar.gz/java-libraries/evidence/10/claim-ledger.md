# 第 10 篇证据账本

## 范围与版本

面向 Java 应用工程师，以商品目录为业务输入；研究公开语义与修改边界，不比较流行度或性能。Guava 坐标 com.google.guava:guava:33.5.0-jre，源码 SHA 8868c096cfdabbe38170b6e395369c315cfb72a1；Java 8 API 编译，JUnit 5.13.4。官方 Javadoc 为 https://guava.dev/releases/33.5.0-jre/api/docs/；固定源码为 https://github.com/google/guava/tree/8868c096cfdabbe38170b6e395369c315cfb72a1/guava/src/com/google/common 。

## 核验记录

| claim | DOC/SOURCE | LAB 场景 | 判定 |
|---|---|---|---|
| list/set 重复及 size 语义不同，两个可变实现接受 null | ArrayListMultimap/HashMultimap Javadoc/source | Chapter10Test.duplicateAndSizePolicies | 已验证，限列出的输入与版本 |
| get 缺失返回视图，asMap 缺失 null，写入传播与空组清理 | AbstractMapBasedMultimap WrappedCollection | Chapter10Test.absentViewsAttachAndDetach | 已验证，限列出的输入与版本 |
| 删除结果独立，values/entries/keySet 为写入视图 | AbstractMapBasedMultimap.AsMap/KeySet；Multimap docs | Chapter10Test.removalResultIsDetachedButAllCollectionViewsAreLive | 已验证，限列出的输入与版本 |
| Multimap 不保留空分组 | Multimap docs；putAll | Chapter10Test.ordinaryMapCanRepresentAnEmptyGroup | 已验证，限列出的输入与版本 |

## 命令、观测与产物

临时工程 /tmp/java-libraries-07-10，不修改共享 target。完整命令：

```sh
JAVA_HOME=<下列JDK路径> MAVEN_USER_HOME=<仓库>/examples/java-libraries/.maven-user-home ./mvnw -o -B -ntp -s .mvn/settings.xml -Dmaven.repo.local=/tmp/java-libraries-m2 -Dtest=Chapter07Test,Chapter08Test,Chapter09Test,Chapter10Test clean verify
```

JDK8=/Users/magicliang/.sdkman/candidates/java/8.0.472-zulu/zulu-8.jdk/Contents/Home

JDK21=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn

两次命令退出码均 0，各批 16 tests，失败/错误/跳过均 0。本章原始 jdk8-surefire.xml 与 jdk21-surefire.xml 各 tests=4、failures=0、errors=0、skipped=0；属性记录实际 java.version、java.home 与 classpath。共享批次日志分别为 jdk8-verify.stdout.txt、jdk21-verify.stdout.txt。最初 Maven3.9.13 预检未作为最终证据；最终使用工程冻结的 Wrapper3.9.14。

## 反向核验与审查

Web 检索以 Guava Splitter limit omitEmptyStrings bug、CharMatcher surrogate、ImmutableMap builder reuse duplicate、Multimap get absent view 为关键词，检索结果仅使用官方源码、文档及上游测试。对核心结论分别用公开契约、固定 SHA 分支和本地反例交叉检查；源码与 Javadoc 属于同一项目，未冒充两个独立第三方来源。上游测试用于读取复核，没有运行 Guava 全量测试套件。

怀疑者检查：不可变不等于深不可变；字符不等于码点；join/split 不承诺往返；Map of collections 与 Multimap 不同域。

对抗输入检查：null、空项、重复、代理对/组合序列、共享引用、缺失键分别由本章相应测试或上下文章节覆盖，未将单章结果泛化为所有实现。

实施者检查：Java8 编译，完整 imports，异常断言；09 线程有有界等待和 join；没有共享 target 并行冲突。修改练习是读者任务，不计入已执行实验。

NOT_RUN：性能/内存基准、其他 JVM/操作系统、Guava 全量上游测试。09 现代 JDK Set/Map 工厂为 DOC 对照，现代 List.copyOf 实验在02章，不冒充本章新运行。Hexo 全系列生成、内部导航检查由根代理统一执行，本账本不预先声称通过。

## 落盘前文风

先在 /tmp/java-libraries-10-draft.md 执行 anti-ai-tone 的 check_prose.py --profile tech --json；结果保存 style-scan.json。随后人工按 anti-persona-fabrication 三红线检查，正则检查第一人称、第二人称、说书人词零命中。07/09 的长句 warning 涉及内联引用和术语，人工检查主语清楚、没有空转扩写；保留技术关系。文章经正文支撑/推进/节奏/连续性检查后以 apply_patch 落盘。
