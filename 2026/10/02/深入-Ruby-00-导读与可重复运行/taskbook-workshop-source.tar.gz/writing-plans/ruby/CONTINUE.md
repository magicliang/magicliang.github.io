# Ruby 系列续写入口

主线 00–39 与选修 E01–E08 共 48 篇已写成，统一 48 个实验已通过。正文入口是 `source/_posts/2026-10-02-深入-Ruby-00-导读与可重复运行.md`；逐篇文件与证据见 `STATUS.md`，版本和适用边界见 `VERSIONS.md`。

本批用户要求只提交，不推送，不部署。提交只包含 Ruby 计划、正文、素材、实验、研究账本和检查脚本；其他主题的工作区与暂存改动保留。

复现先检查本机 Ruby 是 CRuby 3.4.11，再在 `examples/ruby` 执行 `bundle install` 与 `bundle exec ruby verify.rb`。运行会刷新证据文件；发生失败时先检查对应编号的 `verification.log`。不将旧日志当作新环境通过证明。

全部选修已开展并验收。运行全系列前须按各 lab 的 README/INSTALL 安装独立冻结依赖、JRuby/JDK 和原生工具链；入口不自动联网安装。只重测部分篇目可给 verify.rb 传 00–39 或 E01–E08 编号。

目前明确的验证边界：arm64 macOS 的 CRuby 3.4.11 与选修指定的 JRuby/Java/框架/SQLite 环境；RBS/Steep 仅独立协议样例；教学 scheduler 不支持通用异步框架所需的全部 hook；YJIT 只有固定整数负载的测量。48 篇没有遗留待写篇目，也没有把未运行平台纳入通过数。
