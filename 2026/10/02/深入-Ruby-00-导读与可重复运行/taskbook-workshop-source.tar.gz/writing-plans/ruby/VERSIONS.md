# Ruby 系列版本与验证范围

记录日期：2026-10-02。教学基线是 CRuby 3.4.11，不是最新版声明。

## 解释器与构建

| 项目 | 实际值 |
|---|---|
| Ruby | `ruby 3.4.11 (2026-09-23 revision 592f1ffdb3) +PRISM [arm64-darwin27]` |
| 实现源码 | `592f1ffdb36153e8be83603ade3c2e9ab6138a77` |
| 平台 | arm64，macOS 27.0.1，build 26A434 |
| 编译器 | Apple clang 21；YJIT 使用 Rust 1.85.1 |
| 安装位置 | `/private/tmp/hexo-ruby-3.4`；独立构建，未替换系统 Ruby |
| RubyGems / Bundler | 3.6.9 / 2.6.9 |
| YJIT | 已编译；`ruby --yjit` 的实际启用探针为 true |

官方 Ruby 发行包 SHA256：`5c22be44524312b3d433d68739bcc530633b1da5ef8ba0afa0a37680da17d3de`，下载后已与[发布说明](https://www.ruby-lang.org/en/news/2026/09/23/ruby-3-4-11-released/)核对。实际解压源码位于 `/private/tmp/ruby-3.4.11`，`revision.h` 与上述 revision 一致。

最终 configure 参数：

```text
--prefix=/private/tmp/hexo-ruby-3.4
--with-openssl-dir=/opt/homebrew/opt/openssl@3
--with-libyaml-source-dir=/private/tmp/yaml-0.2.5
--disable-install-doc
--disable-dtrace
--enable-yjit
```

libyaml 0.2.5 发行包 SHA256 为 `c642ae9b75fee120b2d96c712538bd2cf283228d2337df2cf2988e3c02678ef4`。Rust 官方 arm64 Darwin 的 rustc 1.85.1 与标准库包分别核对发布的 `.sha256` 文件：`93a6fd55cf1a88bb50e133c5bdb629197b80ad0ccab128ce3a84902992786b4c`、`a066d9b033f5fc74283ca86e38da8178c201e86b17113e184383904573734a67`。这些临时路径是本次运行记录，读者应使用本机已确认的 3.4.11 解释器路径。

## 工程依赖

完整依赖及传递依赖以 `examples/ruby/Gemfile.lock` 为准；安装源为 `https://rubygems.org/`。

| 用途 | 固定版本 |
|---|---|
| 运行库 | JSON 2.13.2、CSV 3.3.5、Net::HTTP 0.6.0、Rack 3.2.1 |
| 测试与诊断 | Minitest 5.25.5、debug 1.11.0、BigDecimal 3.1.8 |
| 类型样例 | RBS 3.9.5、Steep 1.10.0 |
| 打包结果 | 本地 `taskbook-workshop` 0.1.0，required_ruby_version 为 >= 3.4 且 < 3.5 |
| 本次 Bundler 激活 | Prism gem 1.9.0、Psych 5.5.0；完整传递依赖见锁文件 |

Prism gem 1.9.0 的 AST 观察和 CRuby 自带 Prism 解析器是不同观察入口，不能用 gem 版本冒充解释器内置解析器版本。未经 Bundler 激活时，独立解释器自带 Psych 为 5.2.2。锁文件列出多平台 FFI 包不等于那些平台已实测；本次只验证 arm64 macOS。

## 复现与边界

```bash
cd examples/ruby
ruby -v
bundle install
bundle exec ruby verify.rb
```

本次实际调用在工程目录中设置 `PATH=/private/tmp/hexo-ruby-3.4/bin:/opt/homebrew/bin:/usr/bin:/bin`、`BUNDLE_PATH=.bundle/vendor`，由该解释器执行 `ruby -rbundler/setup verify.rb`。结果是 73 个 Ruby 文件语法通过、48 个 lab 通过、Minitest 5 runs / 45 assertions / 0 failures / 0 errors / 0 skips。复跑时会生成本地 `examples/ruby/evidence/NN/verification.log` 和 `examples/ruby/evidence/tests.log`；Git 仅保留正文采用的原始结果，不保存重复验收日志。

Steep 只覆盖第 25 篇的独立 TypedTasks 协议样例，未声明整个 Taskbook 已完成静态类型检查。第 25 篇同时验证合法检查、预期的 MethodBodyTypeMismatch 和不经类型检查时的运行错误。

第 28 与 39 篇确实创建本地 TCP 服务并检查请求、错误和关闭；Rack Mock 与真实 TCP 结果分别记录。第 22 与 39 篇确实从外部工作目录、临时 GEM_HOME 安装并调用所构建的包；仅打包成功不算行为验收。

信号、进程、RSS 与教学 scheduler 使用 POSIX 条件；Windows、Linux、x86_64 与 TruffleRuby 未运行。JRuby 的有限共同契约及安装包 API/CLI 已在 E03/E05 实测。Ractor 的实验性警告是该基线的真实输出。第 36 篇在受限执行环境曾遇到退出 137，随后在获准的本地执行环境完成五轮双模式测量；未据此归因 Ruby 程序错误。性能数字只属于给定预热、输入和机器，不外推服务吞吐。

## 选修冻结与真实范围

| 篇 | 实际环境与证据 |
|---|---|
| E01 | Rails railties/ActionPack/ActiveSupport 8.1.4；进程内集成请求、按需加载与回调，非 TCP 部署测试 |
| E02 | Minitest 5.25.5 / RSpec 聚合 gem 3.13.2；两框架契约、边界变异、100 组生成输入及删除收缩 |
| E03 | JRuby 10.0.5.0，RUBY_VERSION 3.4.5，OpenJDK 21.0.10；JAR SHA256 df539aab793d21df970c45749f71f2ef39731dcbe7c144427d5910ca7eb9c4b3 |
| E04 | 当前 CRuby 头文件、Apple clang 21、Fiddle 1.1.6；TypedData 与动态库在临时目录真实构建并清理 |
| E05 | 同一 arm64 macOS 上 CRuby 3.4.11 / JRuby 10.0.5.0 两实现；JRuby 使用独立 json 2.13.2-java 等平台依赖，实测安装包 API/CLI |
| E06 | sqlite3 gem 2.7.3 实际链接 SQLite 3.50.3；ActiveRecord 8.0.2，独立锁文件与临时数据库 |
| E07 / E08 | Ruby 标准库；自定义有限规则语言 / 单进程内存任务替身，无 Redis 或 Sidekiq |

CRuby 3.4.10 官方包摘要核验通过，但构建子进程被 SIGKILL，父 make 退出 2；未取得可执行解释器，运行矩阵记录 NOT_RUN。原始构建记录见 verification/cruby-3.4.10-attempt.json。包矩阵没有声称空机器依赖安装或所有平台支持。各选修锁文件与 INSTALL/README 保留实际复现条件。
