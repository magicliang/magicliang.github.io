# E06–E08：状态边界与受限执行研究账本

研究日期：2026-10-02。读者已完成异常、资源、并发、输入边界主线；本文群分别验证持久数据库状态、外部规则文本和可重复任务副作用。贡献是可运行的反例与状态观察，不是数据库/解析器/队列产品综述。

## 范围与文章卡

- E06：CRuby 3.4.11、sqlite3 gem 2.7.3、其 arm64-darwin 构件链接 SQLite 3.50.3、ActiveRecord 8.0.2；真实临时文件、两个独立连接，DELETE journal。输入注入仅在临时测试库做只读反例。不把 SQLite 的锁推广到其他数据库。
- E07：自定义只读筛选语言，ASCII/UTF-8、有限字段/比较、独立 lexer/parser/AST/evaluator；AST 只来自本 parser，数据为校验后的普通 Hash。不是 Ruby 兼容解析器，也不接受对象反序列化输入。
- E08：单进程 Queue/Mutex 本地替身；不安装 Redis/Sidekiq。受控 ACK 丢失、重复投递、有限重试、两线程同键竞争、协作取消及排空关闭。内存副作用可观察，但不声称跨进程/崩溃恢复。

## 五项文章卡

| 篇 | 问题与前置 | 规则与依据 | 示例与调用链 | 实验与取舍 | 验收与练习 |
|---|---|---|---|---|---|
| E06 | 事务回滚后对象属性未恢复；18/21/23/26 | SQLite3.50.3约束/ABORT/事务，sqlite3 gem2.7.3，AR8.0.2 | Ruby调用→驱动→SQLite文件→另一连接观察；ORM update/rollback/reload | 参数化对照2/0；两连接写锁；数据库todo/对象done；不用网络库 | run.rb、附件；练习移动rescue位置、两连接版本冲突 |
| E07 | 外部规则仅需筛选却可能获取Ruby执行权限；15–17/26/35/38 | 自定义文法与Ruby3.4正则/安全/Data | ASCII文本→tokens→AST→固定case解释器→任务结果 | 优先级/短路；非法输入/资源拒绝；Proc修改closure对照 | run.rb、附件；练习增加!=、改变批次预算与短路 |
| E08 | 副作用成功但确认丢失导致重复；18/23/29–33/39 | Ruby3.4 Queue/Mutex/Thread；本地协议与SQS重复语义分开 | 提交→尝试→EffectStore→确认/重试→终止→关闭 | 无保护14、保护10/2次写；两线程去重；受控取消；虚拟backoff | run.rb、20次重复、附件；练习拆开临界区、累计等待预算 |

## 来源与反向复核

读取官方 SQLite transaction、isolation、conflict、STRICT、CREATE TABLE、binding 文档；用安装包中的 sqlite3/database.rb:646 反查 transaction 的 rescue/ensure，不把所有异常类、return/break 与 commit 错误作同一保证。读取固定 ActiveRecord transactions.rb 中 rollback 与对象状态说明，反查“回滚会恢复模型内存”的错误推断。官方当下 API 页面可能随主版本变化，具体实验由8.0.2安装源码与固定SHA约束。

读取 Ruby 3.4 security（eval/send/锚点）、Regexp、Data、Thread/Queue、Mutex、Thread 文档。反向查询包括“SQLite ABORT constraint transaction remains”“Rails rollback instance data”“eval safe security untrusted code”“SQS duplicate visibility timeout idempotent”。反证重点不是措辞：捕获 SQL 约束后检查前一条写入仍存在；检查模型字段未自动恢复；普通 Proc 确实能改变闭包；取消发生在副作用后无法撤回；重复执行在无幂等保护时计数翻倍。

官方页多为持续维护页而非独立论文；2026-10-02读取。SQLite 3.50.3发布日期2025-07-17，作为冻结教学基线，不宣称最新版。Ruby3.4文档与源码按本系列基线使用。没有以搜索未见反例作为“已经证明正确”。

| Claim | Source / support | Verification / risk / action |
|---|---|---|
| 参数绑定把值与SQL结构分开；不能用绑定任意列名 | [SQLite binding](https://www.sqlite.org/c3ref/bind_blob.html)、[expressions](https://www.sqlite.org/lang_expr.html) | 实测拼接返回2行、绑定返回0行；采信本查询，不推广任意SQL构造 |
| CHECK/NOT NULL/UNIQUE/STRICT/FK分别约束不同错误 | [CREATE TABLE](https://www.sqlite.org/lang_createtable.html)、[STRICT](https://www.sqlite.org/stricttables.html)、[FK](https://www.sqlite.org/foreignkeys.html) | 5种真实失败；每个连接显式FK ON；STRICT不是拒绝一切可转换值 |
| 普通ABORT约束错误不必回滚整个事务 | [conflict](https://www.sqlite.org/conflict.html)、[transaction](https://www.sqlite.org/lang_transaction.html) | 同事务较早insert仍在；显式rollback后另连接查无；纠正“异常即全回滚” |
| SQLite同一时刻一个写事务，BEGIN IMMEDIATE占写资格 | [transaction](https://www.sqlite.org/lang_transaction.html)、[isolation](https://www.sqlite.org/isolation.html) | 两连接、busy_timeout=0，第二writer BusyException；只宣称本journal/时序 |
| ORM回滚数据库不自动恢复所有模型字段 | [AR8源码](https://github.com/rails/rails/blob/3235827585d87661942c91bc81f64f56d710f0b2/activerecord/lib/active_record/transactions.rb) | item.status done、查询todo，reload后todo；具体模型与版本实测 |
| 外部文本不能用eval/任意send作受限求值 | [Ruby security](https://docs.ruby-lang.org/en/3.4/security_rdoc.html) | lexer拒绝分号、调用语法、非法字段；evaluator固定case；普通block会修改closure |
| 语法限制还需资源与数据边界 | 自定义文法和rules.rb；[Regexp](https://docs.ruby-lang.org/en/3.4/Regexp.html) | 字节/token/递归深度/task数/step预算分别失败；不是安全审计证明 |
| Queue close后仍可排空，空队列pop返回nil | [Queue](https://docs.ruby-lang.org/en/3.4/Thread/Queue.html) | 最后任务ack先于closed，后续submit拒绝；实验禁止nil任务 |
| 幂等检查与本地副作用必须在同一互斥区 | [Mutex](https://docs.ruby-lang.org/en/3.4/Thread/Mutex.html)、本地EffectStore实现 | 两线程同键1次写；远程外部副作用不受此Mutex保护 |
| ACK丢失后重试会重复副作用；取消不等于回滚 | [SQS至少一次](https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/standard-queues-at-least-once-delivery.html)、本地事件脚本 | 无保护14，幂等任务a仅7；副作用后cancel仍4；不宣称exactly-once |

## 源码版本与实现入口

- sqlite3-ruby v2.7.3 SHA `0cfccfc91c93afb11769dc7b830cb5d7ae2addcc`，`lib/sqlite3/database.rb` execute与transaction。
- Rails v8.0.2 SHA `3235827585d87661942c91bc81f64f56d710f0b2`，`activerecord/lib/active_record/transactions.rb`、`persistence.rb`。
- 两SHA来自官方GitHub API只读GET，原始结果见 `examples/ruby/evidence/E06/source-commits.json`。
- SQLite runtime与版本断言见E06/run.log；源码发布身份见 [3.50.3 release](https://www.sqlite.org/releaselog/3_50_3.html)。不根据系统sqlite3命令推断Ruby驱动链接版本。

## 验收与缺口

具体输出以各 `examples/ruby/evidence/E0N/` 为准。E06独立Gemfile/lock，run入口清除父Bundler环境再exec，依赖安装与实验分开；临时库由mktmpdir清理。E07是自定义受限语言，节点数上限在当前token限制下属于冗余保险；平铺and/or树仍受token上限约束。E08的backoff为注入的虚拟等待，只验证计划值1、2，不测实际时间；hook必须协作返回，关闭没有强制超时保证。尚未验证其他数据库、其他CPU/OS构件、持久化任务恢复或网络消息协议。
