# Ruby E03/E04 研究与文章卡

日期2026-10-02。受众是已完成对象、异常、线程、GC主线的开发者。范围限定两种Ruby实现的有限契约与CRuby原生边界；不作性能排名、不声明整个Taskbook跨实现兼容。角度是把“兼容、并行、自动释放”拆为可失败实验，非原创运行时理论。

写作链：沿用已加载blog-editor入口；重新读取计划5/6/7、tech-writer、deep-research、anti-ai-tone与anti-persona-fabrication。Deep研究按语义/互操作和原生生命周期两个边界展开。父代理明确禁止递归代理，广度搜索、反向核查与红队均由本分片直接完成，不伪称独立子代理审阅。

## 文章卡

| 篇 | 可预测问题/前置 | 实验与普通对照 | 验收/练习 |
|---|---|---|---|
|E03|共同脚本在JRuby上是否同结果？21/30/34–36|CRuby/JRuby同一contract.rb；Queue强制旧值竞争与Mutex；JVM双线程latch；Java集合/BigDecimal/异常|比较result完全相等，不比较诊断版本；不同JVM线程ID、原子2000、线程关闭；练习缺字段/Unicode和拆分get-set|
|E04|Ruby对象消失后C资源是否释放？18/19/22/30/34/35|TypedData显式close与GC兜底；持有/释放GVL管道协议；Fiddle真实动态库；C原子load-store对照fetch_add|参数/状态错误、GC引用、50到0、GVLfalse/true、校验和520、幂等释放、原生1/2000；练习大小边界/异常关闭和安全所有者类|

## 来源与claim账本

| 断言 | 一手来源/固定版本 | 实测证据 | 风险及修正 |
|---|---|---|---|
|JRuby10.0.5目标Ruby3.4，Java最低21|[固定发布说明](https://www.jruby.org/2026/04/06/jruby-10-0-5-0)、[官方JRuby10介绍](https://blog.jruby.org/2025/04/jruby-10-part-1-whats-new)|E03/run.log显示JRUBY_VERSION10.0.5.0、RUBY_VERSION3.4.5、Java21.0.10|最初检索9.4是Ruby3.1且已非所需基线；改用10.0.5。目标兼容不等于所有API实现相同。非最新版声明。|
|同一有限契约结果一致|固定下载org.jruby:jruby-complete:10.0.5.0；SHA256与官方.sha256核对|E03共同关键字、输入错误/ensure、浅复制、Queue竞争和Mutex结果一致|不得把CRuby专属API报错算兼容PASS；不外推主线gem与全部Taskbook。|
|JVM线程和可见性不自动提供复合原子性|[JRuby并发wiki](https://github.com/jruby/jruby/wiki/Concurrency-in-jruby)、[JDK21 CountDownLatch](https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/CountDownLatch.html)、[AtomicInteger](https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/atomic/AtomicInteger.html)|E03两个ID、两个ready先于done、AtomicInteger2000、全部join|反向检索JRuby GIL/thread safe，官方明确String/Array/Hash与+=边界。wiki非固定版契约，以本次有限实验支撑；ID不是OS TID，不证明CPU倍率。|
|TypedData需要标记Ruby引用、原生释放与大小函数|[Ruby3.4扩展说明](https://docs.ruby-lang.org/en/3.4/extension_rdoc.html)、实际发行源doc/extension.rdoc|E04标签在GC.compact后仍正确，close幂等、关闭读取错误、50缓冲GC归零|反向检索dmark/compaction；采用普通rb_gc_mark固定引用，未冒充movable+dcompact；free回调不分配Ruby对象。|
|无GVL区间不能直接使用多数Ruby C API|实际include/ruby/thread.h、doc/extension.rdoc，[历史API误用讨论](https://bugs.ruby-lang.org/issues/13486)|E04管道原生等待持锁超时false，解锁收到x true，Ruby响应时active=true|历史讨论2017只作反例，当前语义以3.4.11源码；无UBF，仅1200ms有限poll，不声明通用取消。|
|Fiddle声明只决定ABI/锁，不认证线程安全|[Function3.4](https://docs.ruby-lang.org/en/3.4/Fiddle/Function.html)、实际ext/fiddle/function.c381–385|显式need_gvl:false，真实C函数校验和520，C共享计数使用原子变量|网页一句unless/don't双否定措辞混乱，直接对照源码if need_gvl调用ffi_call、else call_without_gvl；不将该措辞转述成相反规则。|
|一个Pointer所有者只释放一次|[Pointer3.4](https://docs.ruby-lang.org/en/3.4/Fiddle/Pointer.html)、实际ext/fiddle/pointer.c67–74|两次call_free，freed=true且owned_live=0|反向检索call_free/double free；幂等性不跨两个独立包装，不允许释放后访问。|
|原子小步骤也可能丢复合更新|本分片C11原子与pthread条件变量实验|native_counter(0)=1，native_counter(1)=2000|使用atomic_load/store避免普通C变量数据竞争UB；GVL与C同步分别验证。未跑TSan/ASan，不声明全内存安全证明。|

## 固定源与下载

JRuby标签10.0.5.0通过官方git ls-remote解析为`5db1ba72f3062af4130ddfa3764879969fb028b8`，固定[源码树](https://github.com/jruby/jruby/tree/5db1ba72f3062af4130ddfa3764879969fb028b8)。未声称逐行审阅JRuby编译器。

JAR URL：https://repo.maven.apache.org/maven2/org/jruby/jruby-complete/10.0.5.0/jruby-complete-10.0.5.0.jar；官方.sha256同目录。核对值`df539aab793d21df970c45749f71f2ef39731dcbe7c144427d5910ca7eb9c4b3`。只保留校验文件，不提交JAR。

CRuby源码SHA `592f1ffdb36153e8be83603ade3c2e9ab6138a77`。本地官方发行源位于/private/tmp/ruby-3.4.11；实际读取doc/extension.rdoc、include/ruby/thread.h、ext/fiddle/function.c及pointer.c。固定SHA链接供版本定位，源码核对证据见source-check.log，不把浏览器获取失败记为链接访问成功。

## 批判与红队收敛

怀疑者：共同版本号不证明应用兼容。收窄为结果字段覆盖的契约，并单列JVM专属实验。

对抗者：故意构造普通C数据竞争可能使反例本身无定义。改用原子load/store加屏障，仅破坏业务原子性；不执行真实double-free/use-after-free。

实施者：工具链与依赖不应污染主线。JAR在/private/tmp；扩展与动态库在临时目录构建并清理；独立进程清除Bundler环境。保留编译输出与真实版本。

缺口复核：本地测试覆盖目标场景；不存在未运行却计PASS的实验。未实测Linux/Windows、任意第三方gem、CPU加速、通用异步取消和全部内存安全，正文明确限制。全站构建、导航与提交由根代理负责。

## 集成复测修正

独立运行已通过，但根统一入口激活Bundler后发现仅清除BUNDLE_GEMFILE不足：JRuby仍经BUNDLE_BIN_PATH/BUNDLER_SETUP加载父CRuby路径。修复所有BUNDLE前缀变量与Ruby/Gem加载变量，子进程直接断言没有BUNDLE键。E03/E04均从真实主工程 -rbundler/setup 环境完整重跑退出0；final-verification.log记录命令、清除键和判定。此项已修复，不作为未决缺口。
