# Ruby 30–39：运行时与综合交付研究账本

研究日期：2026-10-02。目标读者为已完成前29篇的中级开发者。范围为CRuby 3.4.11；不把JRuby、Ruby 4.x或未来master的行为迁入本系列。研究角度是把并发、运行时与性能命题变成可失败实验；文章不以“用了更高级API”作为优化依据。新意来自同一教学工程的可重放反例，不声称原创运行时理论。

执行写作链路：blog-editor → tech-writer/deep-research（Deep）→ anti-ai-tone（tech profile，先材料支撑、段落推进、节奏、连续性，再十类症状）→ anti-persona-fabrication。每篇发布目录落盘前人工按这一顺序处理；最终再以脚本辅助检查形状。

## 问题与一手来源

| 篇 | 问题 | 官方来源与支持内容 | 风险、反向核查与采用方式 |
|---|---|---|---|
|30|GVL能否保护业务读改写？|[Thread](https://docs.ruby-lang.org/en/3.4/Thread.html)、[Mutex](https://docs.ruby-lang.org/en/3.4/Thread/Mutex.html)：线程生命周期、异常传播和同步边界|反向检索GVL race wrong、线程安全误解；实验用Queue在读写之间确定性交错。采用“GVL不保证复合业务操作原子性”，不从循环碰巧正确推断安全。|
|31|fiber何时让出？|[Fiber](https://docs.ruby-lang.org/en/3.4/Fiber.html)、[Scheduler](https://docs.ruby-lang.org/en/3.4/Fiber/Scheduler.html)：非阻塞fiber与hook协议|反向检索blocking CPU parallel；只声称已触发的io_wait及sleep hook，单线程计算无CPU并行。教学scheduler没有DNS、跨线程唤醒和通用取消支持。|
|32|冻结是否等于共享？|[Ractor API](https://docs.ruby-lang.org/en/3.4/Ractor.html)、[Ractor设计](https://docs.ruby-lang.org/en/3.4/ractor_md.html)：复制、move、shareable对象图|反向检索freeze nested shareable experimental，并查[deep_freeze讨论](https://bugs.ruby-lang.org/issues/17145)。修正“外层freeze足够”的错误命题；实验断言深层冻结、复制隔离、move后访问失败。3.4仍有实验性提示。|
|33|超时能否证明操作终止？|[Timeout](https://docs.ruby-lang.org/en/3.4/Timeout.html)、[Process](https://docs.ruby-lang.org/en/3.4/Process.html)及发行包lib/timeout.rb|反向检索ensure unreliable untrusted；实际实现支持scheduler.timeout_after，否则共享timeout管理线程提交Request，不能写成每次调用创建一个新计时线程。信号发送后必须wait回收；ensure执行不等于远端副作用撤销。|
|34|RSS上升是否等于对象泄漏？|[GC](https://docs.ruby-lang.org/en/3.4/GC.html)、[ObjectSpace](https://docs.ruby-lang.org/en/3.4/ObjectSpace.html)|反向检索RSS freed memsize；分别采样累计分配、强引用缓存大小、受测对象内存估计和RSS。ObjectSpace估计不等于进程全部内存；不设RSS下降断言。|
|35|Prism与YARV是替代关系吗？|[3.4发布说明](https://www.ruby-lang.org/en/news/2024/12/25/ruby-3-4-0-released/)、[ISeq](https://docs.ruby-lang.org/en/3.4/RubyVM/InstructionSequence.html)、[Prism项目](https://github.com/ruby/prism)|Prism默认解析器变化不等于取消字节码虚拟机。解析不执行；ISeq.eval会执行，不能对不可信输入调用。反汇编是实现证据，不是语言兼容契约。|
|36|YJIT能否稳定改善当前负载？|[YJIT 3.4](https://docs.ruby-lang.org/en/3.4/yjit/yjit_md.html)、3.4发布说明及实际启用探针|反向检索performance memory/no improvement；禁止用发行公告倍率预测本机。每模式5个独立进程，轮换顺序，100次预热/200次测量，同输入同结果，记录分配、RSS和enabled。|
|37|惰性枚举总比循环快吗？|[Enumerable](https://docs.ruby-lang.org/en/3.4/Enumerable.html)、[Lazy](https://docs.ruby-lang.org/en/3.4/Enumerator/Lazy.html)|限制为取前20个偶数平方，断言遍历数量与结果；计时观察不推广到全量计算、异常顺序或副作用。短路会改变后续数据是否被验证。|
|38|动态API怎样限制外部权限？|[Psych](https://docs.ruby-lang.org/en/3.4/Psych.html)、[Process](https://docs.ruby-lang.org/en/3.4/Process.html)、[Ruby security](https://docs.ruby-lang.org/en/3.4/security_rdoc.html)|反向检查Marshal不可信反序列化；拒绝任意类标签，显式命令映射，参数数组执行。文件名白名单仅对私有目录成立，symlink检查有TOCTOU，不声称敌对文件系统沙箱。|
|39|源码测试通过是否证明安装可用？|[RubyGems specification](https://guides.rubygems.org/specification-reference/)、[command reference](https://guides.rubygems.org/command-reference/)、本仓Taskbook打包清单|通过外部cwd和新GEM_HOME安装验证遗漏文件；需统一测试、类型检查与HTTP真实场景独立证据，Rack mock不可伪称真实网络验收。|

以上API文档属于同一项目来源；“文档+源码”不是两个独立实证来源。语义结论标记为官方契约支持，实验只确认此构建下的有限案例。搜索未出现异议不作为全称命题证明。2020/2024材料超过两年时仅作历史设计依据，当前行为取3.4.11发行源与实验。

## 固定源码

发行源目录 `/private/tmp/ruby-3.4.11`，revision.h读取到完整SHA：`592f1ffdb36153e8be83603ade3c2e9ab6138a77`。

- [prism_compile.c](https://github.com/ruby/ruby/blob/592f1ffdb36153e8be83603ade3c2e9ab6138a77/prism_compile.c)：实际定位pm_compile_call、pm_iseq_compile_node及pm_parse调用。
- [insns.def](https://github.com/ruby/ruby/blob/592f1ffdb36153e8be83603ade3c2e9ab6138a77/insns.def)：send与opt_send_without_block，经vm_sendish进行调用。
- [vm.c](https://github.com/ruby/ruby/blob/592f1ffdb36153e8be83603ade3c2e9ab6138a77/vm.c)：虚拟机上下文；指令具体实现结合insns.def阅读。
- [lib/timeout.rb](https://github.com/ruby/ruby/blob/592f1ffdb36153e8be83603ade3c2e9ab6138a77/lib/timeout.rb)：timeout分支直接对照本地发行源。

浏览器工具对上述SHA链接返回cache miss；源码内容核对来自官方发行压缩包的实际解压文件，不把cache miss记为链接已验证。正式链接保留完整SHA便于复核。

## 批判与红队检查

怀疑者：一次race输出不足以说明发生概率。因此构造两线程同读旧值的屏障，并说明只证明允许该交错。

对抗者：关闭与异常最容易被正常结果掩盖。因此scheduler保存受控异常，管道在ensure关闭；子进程就绪后才计时并回收状态。安全实验只用合成内容和临时目录。

实施者：实验若要求全功能异步框架或新依赖，会偏离教学目标。因此scheduler固定为教学实现，不写入Taskbook核心；性能结果给测量条件，不据此自动修改业务实现。

缺口收敛：YJIT本机能力探针与五轮双模式实验已通过，39已完成隔离安装、CLI往返和真实本地TCP请求；全工程统一测试与页面检查由主代理汇总。未运行项禁止进入实测叙述。全部结果由各篇evidence中的实际日志补齐，源码检查、语法通过与打包通过不可代替运行证据。
