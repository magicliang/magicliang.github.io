# Ruby 18–29：工程边界研究账本

研究日期：2026-10-02。教学版本为 CRuby 3.4；实际补丁版本、依赖版本与运行记录以版本文件及各篇 evidence 为准。研究范围是本地合成任务工具，排除 Rails 自动加载、远端发布、生产服务器与跨平台耐久性背书。

## 问题与检索

研究问题分为资源传播、代码与依赖加载、质量反馈、输入与进程协议四组。各组先读官方文档，再用边界反例检查文档的适用条件。研究采用 deep-research 的来源、反查、冲突、综合与红队流程；不把同一项目的文档与源码称为两个独立来源。实测构成另一种证据，但只能支持实际运行的实现与平台。

| 篇 | 核心主张 | 依据与版本 | 反查及限制 | 实验 |
|---|---|---|---|---|
| 18 | ensure 普通末表达式不替换结果，显式 return 可以遮蔽异常；裸 rescue 默认 StandardError | [Ruby 3.4 exceptions](https://docs.ruby-lang.org/en/3.4/syntax/exceptions_rdoc.html)、[Exception](https://docs.ruby-lang.org/en/3.4/Exception.html) | 搜索 ensure return cause corrected；未把 ensure 扩大到 SIGKILL、exit!、掉电 | labs/18/run.rb |
| 19 | block 关闭 IO；编码标签不等于合法字节；rename 不独自保证断电持久性 | [Ruby 3.4 IO](https://docs.ruby-lang.org/en/3.4/IO.html)、[File](https://docs.ruby-lang.org/en/3.4/File.html) | 反查 File rename fsync atomic；实验只验证本地可见替换，未做断电故障注入 | labs/19/run.rb |
| 20 | require 缓存成功加载，load 重执行，autoload 在常量访问触发；循环可能观察半初始化状态 | [Ruby 3.4 Kernel](https://docs.ruby-lang.org/en/3.4/Kernel.html)、[Module](https://docs.ruby-lang.org/en/3.4/Module.html) | [21719](https://bugs.ruby-lang.org/issues/21719) 记录线程/加载死锁；不将单线程实验外推为并发正确性 | labs/20/run.rb |
| 21 | 安装与激活不同；bundle 执行环境受解算图约束 | [Bundler exec](https://bundler.io/man/bundle-exec.1.html)、[Gemfile](https://bundler.io/man/gemfile.5.html) | 反查 bundle exec lockfile changes；锁文件不固定 OS、外部动态库或 Ruby 构建 | labs/21/run.rb |
| 22 | gemspec 文件清单和运行依赖决定包边界；安装退出零不足以证明入口可用 | [RubyGems tutorial](https://guides.rubygems.org/make-your-own-gem/)、[spec reference](https://guides.rubygems.org/specification-reference/) | 临时安装禁用自动依赖下载，复用已锁定依赖；明确非完全离线空机器 bootstrap | labs/22/run.rb |
| 23 | 测试应观察协议结果，负控制检验测试入口会失败 | [Minitest](https://docs.seattlerb.org/minitest/) | 网站可能是更新版本；项目固定 5.25.5，读取安装版本运行结果；负控制不是完整突变测试 | labs/23/run.rb |
| 24 | debugger 可观察实际暂停帧；语法正确不证明业务正确 | [ruby/debug](https://github.com/ruby/debug) | 明确禁止将调试端口公开；本例仅标准输入驱动本地调试会话 | labs/24/run.rb |
| 25 | RBS 为声明，Steep 为静态检查；动态输入仍需运行校验 | [RBS syntax](https://github.com/ruby/rbs/blob/master/docs/syntax.md)、[Steep 1.10.0](https://github.com/soutaro/steep/blob/v1.10.0/README.md) | [RBS best practices](https://github.com/ruby/rbs/wiki/Writing-Signatures-Best-Practices) 及 metaprogramming discussion 1639；本工程只检查 TypedTasks 子集，不冒充整体类型安全 | labs/25/run.rb |
| 26 | JSON/CSV 语法成功不等于任务契约成立 | [JSON](https://ruby.github.io/json/)、[CSV](https://ruby.github.io/csv/) | 错误类型、缺字段、未知枚举、编码和体积分别拒绝；64KiB只是教学限制，不代表通用最优值 | labs/26/run.rb |
| 27 | CLI 输出、错误流、退出码和覆盖规则都是公共协议 | [Ruby 3.4 OptionParser](https://docs.ruby-lang.org/en/3.4/OptionParser.html)、[Open3](https://docs.ruby-lang.org/en/3.4/Open3.html) | 不用 shell 拼接；EXCL 防覆盖不代表内容写入具备事务性 | labs/27/run.rb |
| 28 | Rack 是调用协议，Net::HTTP 是客户端；读取超时不是全请求截止时间 | [Rack 3.2 SPEC](https://rack.github.io/rack/3.2/SPEC_rdoc.html)、[net-http 0.6.0 source](https://github.com/ruby/net-http/blob/v0.6.0/lib/net/http.rb) | 反查 Rack lower-case header CHANGELOG 与 net-http max_retries；固定重试为0；实验仅 loopback HTTP，非TLS/代理测试 | labs/28/run.rb |
| 29 | trap 只标记请求，普通流程负责关闭；配置优先级与日志脱敏需显式定义 | [Ruby 3.4 Signal](https://docs.ruby-lang.org/en/3.4/Signal.html)、[Logger](https://docs.ruby-lang.org/en/3.4/Logger.html) | POSIX TERM 子进程实验不能证明 Windows 或 SIGKILL 清理；日志采用字段白名单 | labs/29/run.rb |

## 红队检查与收敛

怀疑者检查：错误是否被 catch-all 吞掉？IO 只统一输入语法错误，其他缺陷继续失败；Rack 只转换公开输入错误。实施者检查：包装后是否误从源码目录加载？22 的新进程在临时目录检查已安装 gem 路径。对抗者检查：文档可能借“安全”“原子”隐藏前提？正文分别保留路径、并发、耐久性、资源上限与平台边界。

资料中未确认的最新行为不进入教学结论。类型检查的范围必须在正文显式说明；不能通过放大 untyped、禁用诊断或删除反例得到通过。正文落盘前按 anti-ai-tone 的 tech profile 检查材料与段落推进，再按 anti-persona-fabrication 清除第一人称经历、拟人化和写作旁白。

## 实测收敛

最终环境为 CRuby 3.4.11（592f1ffdb3，arm64-darwin27）、Bundler 2.6.9。锁文件已生成；18–29 的完整最终运行均退出 0。各篇原始记录在 `examples/ruby/evidence/NN/run.txt`，验收矩阵在 `.omo/evidence/ruby-engineering/EVIDENCE.md`。

22 的初次验证发现 Bundler 环境影响了临时 gem 安装位置，修复后明确清除 BUNDLE 相关变量、RUBYOPT/RUBYLIB，并指定 --install-dir；随后从临时目录验证了真实安装路径和 CLI。28 初次因沙箱拒绝 bind 未运行成功，获得仅回环测试的执行权限后完成 200、503、读取超时和关闭验证。没有把这两次初始失败计为通过。
