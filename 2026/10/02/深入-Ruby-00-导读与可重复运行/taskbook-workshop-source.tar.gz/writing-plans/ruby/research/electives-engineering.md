# E01 / E02 / E05 source and claim ledger

Date: 2026-10-02. Scope: Ruby framework boundaries, behavior testing and local gem maintenance. Audience: readers who completed the listed main-series prerequisites. Angle: differentiate documented semantics from directly observed behavior. No upstream-library superiority or global compatibility claim.

## Sources and counterchecks

| Claim | Official source | Direct evidence | Risk / resolution |
|---|---|---|---|
| Rails 8.1.4 exists; selected components fixed | https://rubygems.org/gems/rails/versions/8.1.4 | E01/Gemfile.lock, actual Rails.version 8.1.4 | Only railties/actionpack/activesupport selected; not a full database app |
| blank? is an ActiveSupport extension, not core truthiness | https://guides.rubyonrails.org/active_support_core_extensions.html | fresh process before/after require, false.blank? and !0.blank? | Rails console already loads extensions, so fresh process required |
| Rails autoload maps paths to constants | https://guides.rubyonrails.org/autoloading_and_reloading_constants.html | E01 $LOADED_FEATURES absent before first request, present afterward | Not reload/eager-load acceptance |
| before_action can halt action after setting response; around uses yield | https://guides.rubyonrails.org/action_controller_overview.html | E01 event sequence; missing header only before; 422 still around-exit | Not transactions or production authentication |
| Integration session exercises Rails request stack | https://guides.rubyonrails.org/testing.html | actual ActionDispatch::Integration::Session statuses 200/401/422/422 | In-process Rack request, not TCP |
| RSpec aggregate 3.13.2 exists | https://rubygems.org/gems/rspec/versions/3.13.2 | E02 lock + real three-example suite | Component patches differ; no assumption all equal aggregate |
| RSpec seed does not automatically seed application random generator | https://rspec.info/features/3-13/rspec-core/command-line/randomization/ | E02 independent Random.new(SEED), order seed separate | preserve generator and runtime as well as seed |
| Random supports explicit reproducible state | https://docs.ruby-lang.org/en/3.4/Random.html | seed 20261002, 100 cases, saved original/deletion/canonical input | Not proof over all input values or versions |
| Same behavior can run in two frameworks | https://rspec.info/features/3-13/rspec-core/ | Minitest 3/3 and RSpec 3 examples; both boundary mutant exit 1 | No universal equivalence claim; only three contracts |
| required_ruby_version is an installation constraint | https://guides.rubygems.org/specification-reference/ | E05 actual installed package probes on two engines | Constraint wider than tested combinations |
| Gem loading must respect package layout | https://guides.rubygems.org/patterns/ | E05 package file check and installed path outside checkout | Dependencies reused, not clean-machine bootstrap |
| JRuby 10.0.5.0 targets Ruby 3.4 | https://www.jruby.org/2026/04/06/jruby-10-0-5-0 | E05 reports JRuby10.0.5.0/Ruby3.4.5 on Java21.0.10 | Independent installation/API/CLI checks, not relying on another chapter's contract test |
| Java platform JSON2.13.2 exists | https://rubygems.org/gems/json/versions/2.13.2-java | independent JRuby GEM_HOME, activated spec platform java | Never reuse CRuby native extension directory for JRuby |
| Ruby3.4.10 source release hash | https://www.ruby-lang.org/en/news/2026/06/30/ruby-3-4-10-released/ | root build attempt stopped after bootstrap exit137 | NOT_RUN, excluded from passing matrix; no inference of language incompatibility |

The v8.1 Rails guide URL variant and one Minitest GitHub fetch returned retrieval errors. Those errors were not treated as supporting citations; current official guides plus exact installed source/runtime checks were used. Dynamic guide version drift is bounded by the frozen lab lock and observed output.

## Experiment findings and repairs

- E01: scalar parameter check added before Integer conversion so min[]=1 maps to the intended ArgumentError/422 boundary instead of an uncaught TypeError. Fresh rerun passes both invalid text and structured parameter paths.
- E02: threshold must be 4, not 3, because sample priorities 5/2/4 otherwise do not touch equality. Both runners now reject the same real API boundary mutant. Data-seed run finds seven records and shrinks by six accepted deletions, then a domain-specific canonicalization. Only record-deletion minimality is proved.
- E01/E02: wrapper re-executes with own Gemfile and local .bundle/vendor, clearing inherited BUNDLE variables, RUBYOPT and RUBYLIB. Both were rerun from main bundle environment.
- E05: root's CRuby3.4.10 bootstrap exit137 prevented a patch matrix. Authorized replacement matrix executes CRuby3.4.11 and JRuby10.0.5.0, installing Java-specific dependencies. Both package/API/CLI paths and fixture positive/negative paths are directly observed.
- Fixture 1.0.0/2.0.0 is artificial local teaching software. Its API removal and warning are authored experiment conditions, never attributed to an upstream dependency.

CRuby3.4.10 NOT_RUN evidence: [attempt record](../verification/cruby-3.4.10-attempt.json), [first build](../verification/ruby-3.4.10-make.log), [retry](../verification/ruby-3.4.10-make-retry.log), [bootstrap retry](../verification/ruby-3.4.10-make-bootstrap.log). Independent reread found `make: *** [ext/configure-ext.mk] Killed: 9` at line126; parent make exit2 and nested SIGKILL/137 are separate statuses. The verified source hash does not turn the failed build into an executed runtime.

## Independent review separation

Parent reviewed E01/E02 code and article boundaries before final evidence: confirmed in-process request wording and deletion-minimal shrink scope; requested removal of internal PATTERN markers and article cards. Both changes applied. Parent will own independent final verifier/build/navigation review. This writer does not claim global Hexo integration complete.

Ordered pre-write scans: anti-ai-tone technical support/progression/rhythm, then anti-persona-fabrication narrator/persona checks. Supplemental script scans and final scenario results are in .omo/evidence/ruby-electives-engineering/. Each article has two exercises, exact lab path, version scope and companion SVG.
