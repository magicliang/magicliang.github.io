# Ruby 00–08 研究与证据账本

研究日期：2026-10-02。范围是 Ruby 3.4 的表达式、值、参数、闭包与枚举；面向掌握其他语言的开发者，用同一任务清单建立行为基线。与生态概览的区别是每个结论对应输入、反例和可失败的断言。

## 子问题与阶段

| 子问题 | 研究与验证动作 |
|---|---|
| 环境与依赖 | 官方发布包、校验值、解释器实际版本及项目调用路径 |
| 真值与求值 | 控制表达式文档、优先级反例、短路副作用 |
| 数字与编码 | 核心类契约、精确数与转换、字节及字符实验 |
| 容器与参数 | 默认对象、相等与范围；位置和关键字参数绑定 |
| 闭包与枚举 | Proc 文档及控制流反例，each 协议和惰性计数 |

官方资料深读、反向检索和冲突复核已完成；真实解释器下的 00–08 实验与独立复核均通过。正文落盘前依次执行 anti-ai-tone 与 anti-persona-fabrication。

## 已核对入口

- [Ruby 发布表](https://www.ruby-lang.org/en/downloads/releases/)
- [Ruby 3.4.11 发布说明](https://www.ruby-lang.org/en/news/2026/09/23/ruby-3-4-11-released/)
- [Ruby 3.4 语法入口](https://docs.ruby-lang.org/en/3.4/syntax_rdoc.html)
- [方法调用](https://docs.ruby-lang.org/en/3.4/syntax/calling_methods_rdoc.html)
- [Proc](https://docs.ruby-lang.org/en/3.4/Proc.html)
- [Kernel](https://docs.ruby-lang.org/en/3.4/Kernel.html)

## 版本包

实际采用 CRuby 3.4.11。官方 tar.gz SHA256 为 `5c22be44524312b3d433d68739bcc530633b1da5ef8ba0afa0a37680da17d3de`，已下载并核对。源码 revision 是 `592f1ffdb36153e8be83603ade3c2e9ab6138a77`；系统 Ruby 2.6.10 不作为实验结果。完整构建与依赖见 `../VERSIONS.md`。

## 逐篇断言、冲突与结论

| 篇 | 官方规则与反向复核 | 实测与限定 |
|---|---|---|
| 00 | 解释器版本、require_relative、raise；打印结果不能证明契约 | 合成输入的筛选、统计、复制与非法字段均有可失败断言；未证明任意输入 |
| 01 | [控制表达式](https://docs.ruby-lang.org/en/3.4/syntax/control_expressions_rdoc.html)与[优先级](https://docs.ruby-lang.org/en/3.4/syntax/precedence_rdoc.html) | nil/false 之外包括 0、空字符串和空容器均为真；短路、and 与 && 绑定、case 匹配顺序有轨迹 |
| 02 | [Integer](https://docs.ruby-lang.org/en/3.4/Integer.html)、[Rational](https://docs.ruby-lang.org/en/3.4/Rational.html)、[BigDecimal](https://github.com/ruby/bigdecimal) | 负整数除法、Float 近似、字符串创建精确数与舍入；不把 to_i 当严格解析 |
| 03 | [String](https://docs.ruby-lang.org/en/3.4/String.html)、[Encoding](https://docs.ruby-lang.org/en/3.4/Encoding.html)、[Regexp](https://docs.ruby-lang.org/en/3.4/Regexp.html) | 字节与字符计数、坏 UTF-8、UTF-16 转换、别名和行锚点反例；scrub 会改数据 |
| 04 | [Array](https://docs.ruby-lang.org/en/3.4/Array.html)、[Hash](https://docs.ruby-lang.org/en/3.4/Hash.html)、[Range](https://docs.ruby-lang.org/en/3.4/Range.html) | 默认对象共享、默认 proc 插入、eql?/hash、可变 String 键与 cover?/include? 差异 |
| 05 | [方法调用](https://docs.ruby-lang.org/en/3.4/syntax/calling_methods_rdoc.html)及[关键字迁移说明](https://www.ruby-lang.org/en/news/2019/12/12/separation-of-positional-and-keyword-arguments-in-ruby-3-0/) | 位置 Hash 与关键字分离、默认表达式重复求值、位置/关键字/block 三通道转发；未沿用 Ruby 2 的隐式转移 |
| 06 | [Proc](https://docs.ruby-lang.org/en/3.4/Proc.html)及 Symbol#to_proc | block 不是普通位置参数；非 lambda 与 lambda 参数绑定、显式解构和协议转换分别断言 |
| 07 | Proc 的 return/break 目标及 LocalJumpError | 活动和已结束目标、lambda 局部返回、next 与共享闭包状态分别执行；不假设闭包复制环境 |
| 08 | [Enumerable](https://docs.ruby-lang.org/en/3.4/Enumerable.html)、[Lazy](https://docs.ruby-lang.org/en/3.4/Enumerator/Lazy.html) | eager 遍历 100 项、lazy 首次取 3 项；重复 force 再执行，副作用并未缓存；无限源只取有限前缀 |

反向检索集中于旧关键字迁移示例、Float 精度、Hash 共享默认值及非局部控制流。旧版本与当前行为冲突时，正文使用冻结版本的契约与真实实验；搜索没有找到异议不作为全称证明。历史发布说明只解释变更背景。

## 独立复核与修正

对象模型代理独立运行 00–08 的九个实验，均退出 0；在副本中逐篇故意破坏首个断言，九个变体均非零退出，说明检查能拒绝受测错误。复核同时指出：仅 valid_encoding? 会允许有效 UTF-16 字符串，随后 strip 可能抛出 Encoding::CompatibilityError，偏离领域约定的 ArgumentError。

核心校验已在标题、标签与筛选参数统一要求 UTF-8，再检查有效性与空白。第 00 篇增加有效 UTF-16 标题/标签、坏 UTF-8 标题和筛选参数的拒绝断言。修正后的完整统一验证为 40 labs PASS，Minitest 5 runs / 45 assertions / 0 failures / 0 errors / 0 skips。

官方文档和官方源码属于同一发布者，不能计作两个独立实证来源。独立实验只确认此构建下的有限输入；独立复核记录实际发现并已修正的边界，不虚构生产案例、作者经历或未运行的平台结论。
