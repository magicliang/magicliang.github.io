# Ruby 对象模型研究账本（09–17）

日期：2026-10-02。范围：固定教学基线Ruby 3.4，实际安装版CRuby 3.4.11。读者：已能阅读方法、闭包和集合的开发者。角度：由反例和真实调用路径解释对象模型，不把动态能力等同于接口正确或安全隔离。

## 研究方法与出处

使用Ruby官方3.4文档逐项查阅；对容易误述的private字面self、super()的block、refinement范围、Data浅冻结、匹配失败绑定与class_eval两种语境反查对应段落。随后先编写独立核心语义实验，以真实3.4.11运行；完整安装后重新运行才落正文。结果不从系统Ruby或旧报告推断。

| 篇 | 核心claim | 官方依据 | 实验观察 | 适用边界 |
|---|---|---|---|---|
| 09 | block保留局部环境；def建立新局部作用域；双冒号定义不引入外层词法嵌套；继承调用不重新绑定方法内常量。 | [官方3.4](https://docs.ruby-lang.org/en/3.4/syntax/modules_and_classes_rdoc.html) | NameError、Module.nesting、接收者身份、父子TOKEN结果 | 未引入const_missing/autoload；不外推Rails加载行为。 |
| 10 | equal?身份与==值区分；Hash键需eql?/hash一致；dup/clone和freeze均有浅层边界。 | [官方3.4](https://docs.ruby-lang.org/en/3.4/Object.html) | 嵌套数组可变、外层FrozenError、单例方法与冻结复制、真实Hash查询 | 不声称通用深复制；自定义复制钩子与循环对象图另行定义。 |
| 11 | 构造器建立领域不变量；Ruby3.4允许字面self调用private；别名接收者失败；protected允许类内同层次协作。 | [官方3.4](https://docs.ruby-lang.org/en/3.4/syntax/modules_and_classes_rdoc.html) | 标题快照、NoMethodError、重复迁移ArgumentError、失败后状态保持 | 可见性不是安全隔离或互斥；本例状态机属于教学规则。 |
| 12 | 单例类承载局部方法；super沿后续同名实现；super()不传普通实参但仍传block；&nil阻断block。 | [官方3.4](https://docs.ruby-lang.org/en/3.4/syntax/modules_and_classes_rdoc.html) | Method#owner与super_method、祖先前缀、三种参数通道结果 | 裸super实验未修改形参；不把ancestors当成动态事件轨迹。 |
| 13 | include可被宿主同名方法遮挡；prepend位于宿主前；refinement依据定义处词法范围。 | [官方3.4](https://docs.ruby-lang.org/en/3.4/syntax/refinements_rdoc.html) | 组合/include/prepend事件数组、外部方法NoMethodError | 未测试异常清理包装；正文明确after只在成功返回时执行。 |
| 14 | 各自实现each的类可共享协议；respond_to?不能证明元素/迭代正确；to_a与to_ary通道不同。 | [官方3.4](https://docs.ruby-lang.org/en/3.4/Kernel.html) | 两源相同ID、Enumerator、隐式转换TypeError、坏行KeyError、假each空结果 | 只验证有限each契约；不声明任意源可重放或有固定长度。 |
| 15 | Data成员不可替换但嵌套可变；with浅复制；模式pin/guard/额外键/右向失败各有独立语义。 | [官方3.4](https://docs.ruby-lang.org/en/3.4/syntax/pattern_matching_rdoc.html) | Data/Struct字段、tags共享、deconstruct、NoMatchingPatternError、**nil | 不依赖失败绑定或deconstruct次数；Data不是深不可变保证。 |
| 16 | define_method可与普通方法同契约；动态缺失处理需反射配合；未知调用super且保留目标内部错误。 | [官方3.4](https://docs.ruby-lang.org/en/3.4/Module.html) | 结果对照、method_added事件、owner/source_location、NoMethodError.name与KeyError | 无性能优越声明；允许集有限，不转发所有方法。 |
| 17 | instance_eval改self而保留闭包；class_eval block保留词法常量，字符串形式在本例使用目标语境。 | [官方3.4](https://docs.ruby-lang.org/en/3.4/Module.html#method-i-class_eval) | 普通API/DSL三点边界等价、上下文数组、词法/目标TOKEN、非法及缺项拒绝 | 只eval源码内固定合成字符串；不可信文本不进入eval；无沙箱宣称。 |

补充查阅：[Object](https://docs.ruby-lang.org/en/3.4/Object.html)、[BasicObject](https://docs.ruby-lang.org/en/3.4/BasicObject.html)、[Class](https://docs.ruby-lang.org/en/3.4/Class.html)、[Method](https://docs.ruby-lang.org/en/3.4/Method.html)、[Hash](https://docs.ruby-lang.org/en/3.4/Hash.html)、[Array](https://docs.ruby-lang.org/en/3.4/Array.html)、[Enumerable](https://docs.ruby-lang.org/en/3.4/Enumerable.html)、[Struct](https://docs.ruby-lang.org/en/3.4/Struct.html)、[Data](https://docs.ruby-lang.org/en/3.4/Data.html)。正文代码为独立教学实验，不搬运官方示例；资料用于规则交叉检查，具体输出由lab断言决定。

## 逐篇文章卡与证据

每篇按照计划的问题→可运行正反例→对象关系/查找链→Taskbook接口取舍→两道练习组织。文章不把lab里的局部类直接加入累计工程；共享lib由主代理维护，避免把所有教学机制塞入应用。

- 09：前置见原计划；正文 `source/_posts/2026-10-02-深入-Ruby-09-作用域-self-与常量.md`；代码 `examples/ruby/labs/09/run.rb`；运行、语法、故障变体、环境及附件记录 `examples/ruby/evidence/09/`。
- 10：前置见原计划；正文 `source/_posts/2026-10-02-深入-Ruby-10-身份-相等-复制与冻结.md`；代码 `examples/ruby/labs/10/run.rb`；运行、语法、故障变体、环境及附件记录 `examples/ruby/evidence/10/`。
- 11：前置见原计划；正文 `source/_posts/2026-10-02-深入-Ruby-11-类-实例与可见性.md`；代码 `examples/ruby/labs/11/run.rb`；运行、语法、故障变体、环境及附件记录 `examples/ruby/evidence/11/`。
- 12：前置见原计划；正文 `source/_posts/2026-10-02-深入-Ruby-12-单例类-方法查找与-super.md`；代码 `examples/ruby/labs/12/run.rb`；运行、语法、故障变体、环境及附件记录 `examples/ruby/evidence/12/`。
- 13：前置见原计划；正文 `source/_posts/2026-10-02-深入-Ruby-13-Module-include-prepend-与-refinement.md`；代码 `examples/ruby/labs/13/run.rb`；运行、语法、故障变体、环境及附件记录 `examples/ruby/evidence/13/`。
- 14：前置见原计划；正文 `source/_posts/2026-10-02-深入-Ruby-14-鸭子类型与委托.md`；代码 `examples/ruby/labs/14/run.rb`；运行、语法、故障变体、环境及附件记录 `examples/ruby/evidence/14/`。
- 15：前置见原计划；正文 `source/_posts/2026-10-02-深入-Ruby-15-Struct-Data-与模式匹配.md`；代码 `examples/ruby/labs/15/run.rb`；运行、语法、故障变体、环境及附件记录 `examples/ruby/evidence/15/`。
- 16：前置见原计划；正文 `source/_posts/2026-10-02-深入-Ruby-16-动态方法-反射与钩子.md`；代码 `examples/ruby/labs/16/run.rb`；运行、语法、故障变体、环境及附件记录 `examples/ruby/evidence/16/`。
- 17：前置见原计划；正文 `source/_posts/2026-10-02-深入-Ruby-17-DSL-instance_eval-与-class_eval.md`；代码 `examples/ruby/labs/17/run.rb`；运行、语法、故障变体、环境及附件记录 `examples/ruby/evidence/17/`。

## 写作链路与落盘前扫描

依次读取并应用blog-editor（文章与附件绑定）、tech-writer（Scope/Angle/Audience与claim账本）、anti-ai-tone（材料支撑/推进/节奏/连续性），最后anti-persona-fabrication（第一人称/经历/社交/说书表达）。文章在内存形成后完成两扫描，再使用apply_patch落入source/_posts；没有颠倒扫描顺序。

[
  {
    "n": "09",
    "characters": 2565,
    "order": [
      "anti-ai-tone",
      "anti-persona-fabrication"
    ],
    "aiHits": [],
    "personaHits": [],
    "manual": "按实验支撑、段落推进、定义/调用/边界与练习逐篇连读；删去元话语，不新增第一人称或拟人经历。"
  },
  {
    "n": "10",
    "characters": 2626,
    "order": [
      "anti-ai-tone",
      "anti-persona-fabrication"
    ],
    "aiHits": [],
    "personaHits": [],
    "manual": "按实验支撑、段落推进、定义/调用/边界与练习逐篇连读；删去元话语，不新增第一人称或拟人经历。"
  },
  {
    "n": "11",
    "characters": 2611,
    "order": [
      "anti-ai-tone",
      "anti-persona-fabrication"
    ],
    "aiHits": [],
    "personaHits": [],
    "manual": "按实验支撑、段落推进、定义/调用/边界与练习逐篇连读；删去元话语，不新增第一人称或拟人经历。"
  },
  {
    "n": "12",
    "characters": 2542,
    "order": [
      "anti-ai-tone",
      "anti-persona-fabrication"
    ],
    "aiHits": [],
    "personaHits": [],
    "manual": "按实验支撑、段落推进、定义/调用/边界与练习逐篇连读；删去元话语，不新增第一人称或拟人经历。"
  },
  {
    "n": "13",
    "characters": 2526,
    "order": [
      "anti-ai-tone",
      "anti-persona-fabrication"
    ],
    "aiHits": [],
    "personaHits": [],
    "manual": "按实验支撑、段落推进、定义/调用/边界与练习逐篇连读；删去元话语，不新增第一人称或拟人经历。"
  },
  {
    "n": "14",
    "characters": 2500,
    "order": [
      "anti-ai-tone",
      "anti-persona-fabrication"
    ],
    "aiHits": [],
    "personaHits": [],
    "manual": "按实验支撑、段落推进、定义/调用/边界与练习逐篇连读；删去元话语，不新增第一人称或拟人经历。"
  },
  {
    "n": "15",
    "characters": 2548,
    "order": [
      "anti-ai-tone",
      "anti-persona-fabrication"
    ],
    "aiHits": [],
    "personaHits": [],
    "manual": "按实验支撑、段落推进、定义/调用/边界与练习逐篇连读；删去元话语，不新增第一人称或拟人经历。"
  },
  {
    "n": "16",
    "characters": 2543,
    "order": [
      "anti-ai-tone",
      "anti-persona-fabrication"
    ],
    "aiHits": [],
    "personaHits": [],
    "manual": "按实验支撑、段落推进、定义/调用/边界与练习逐篇连读；删去元话语，不新增第一人称或拟人经历。"
  },
  {
    "n": "17",
    "characters": 2569,
    "order": [
      "anti-ai-tone",
      "anti-persona-fabrication"
    ],
    "aiHits": [],
    "personaHits": [],
    "manual": "按实验支撑、段落推进、定义/调用/边界与练习逐篇连读；删去元话语，不新增第一人称或拟人经历。"
  }
]

文字统计为正文Unicode汉字数，代码标识不计入汉字数量。每篇不少于2500汉字，不用短表格代替正文。结构性模式以普通语句表达，遵循计划不保留[PATTERN]标签。封面沿主代理指定路径。

## 已观察与尚待集成

九个安装版脚本全部退出0；九个反转首断言的故障变体全部退出1。所有结果位于各章run.log/mutation.log，语法检查也独立保存。下载附件与工程脚本已核对字节一致，九个附件独立执行全部退出0，见asset-run.log与.omo/evidence/ruby-objects-validation.log。落盘后辅助扫描结果位于各章prose-scan.json；13篇一句“的”偏多已拆分并再次依次过结构扫描和拟人扫描。全站构建、浏览器与导航检查由主代理统一完成，不用这份局部记录替代全站验收。无Git写操作、无推送、未触碰共享lib、配置或其他分工文件。
