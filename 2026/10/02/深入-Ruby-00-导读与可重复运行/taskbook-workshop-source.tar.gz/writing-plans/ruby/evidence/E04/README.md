# E04 验收记录

最终实际命令：在 examples/ruby 下设置 `PATH=/private/tmp/hexo-ruby-3.4/bin:/opt/homebrew/bin:/usr/bin:/bin BUNDLE_PATH=.bundle/vendor`，执行 `/private/tmp/hexo-ruby-3.4/bin/ruby -rbundler/setup labs/E04/run.rb`，require_escalated本地执行。退出0，完整构建命令、stdout、stderr与每一步exit收录run.log；最终pass=true、temporary_build_removed=true。

版本CRuby3.4.11、Fiddle1.1.6、Apple clang21、arm64 macOS。mkmf/Make与真实C动态库都在临时目录构建；子Ruby进程加载并运行，不提交.bundle/.so/.dylib。INSTALL.md给出复现条件。

二元验收：参数TypeError/ArgumentError/TypeError、关闭后IOError；完整GC及GC.compact后label仍可达；显式close返回true/false，50个丢弃缓冲GC后归零。持有GVL原生握手false、释放后true且Ruby响应时原生active=true。Fiddle空分配/空指针错误码、8字节校验和520、两次call_free后freed=true/live=0。原生atomic_load/store屏障丢更新=1，fetch_add=2000，pthread全部join。

持GVL对照故意等待1200ms上限，未实测通用取消；未执行真实double-free或C未定义数据竞争。未跑ASan/TSan；计数器及行为断言不代表全部内存安全证明。Linux/Windows未测。源码固定位置见.omo/evidence/ruby-electives-runtime/source-check.log；编辑检查见editorial-verification.log。

最终场景从主工程Bundler激活环境运行，全部BUNDLE前缀与Ruby/Gem加载环境均清除；子probe断言无BUNDLE残留，完整构建和行为复跑通过。
