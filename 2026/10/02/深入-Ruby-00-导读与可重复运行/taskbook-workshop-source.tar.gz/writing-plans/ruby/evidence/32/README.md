# 第32篇实验验收

- 场景：计划第32篇全部随文lab断言。
- 实际调用：`/private/tmp/hexo-ruby-3.4/bin/ruby examples/ruby/labs/32/run.rb`。
- 退出码：0。
- 二元判定：日志中`"pass": true`，任意断言失败会退出非零。
- 可观察结果：浅freeze不可共享、深度共享为true；复制隔离；move后Ractor::MovedError；共享对象identity相同。保留实验性warning。
- 原始日志：`writing-plans/ruby/evidence/32/run.log`。
- 环境：Ruby 3.4.11 revision 592f1ffdb36153e8be83603ade3c2e9ab6138a77，arm64-darwin27。
- 文风顺序：落盘前人工执行anti-ai-tone（段落支撑、推进、节奏、连续性）后anti-persona-fabrication；落盘后脚本复核见`.omo/evidence/ruby-runtime/prose-check.log`及`persona-check.log`。

本日志为真实执行输出；语法检查与源码阅读不替代行为验收。
