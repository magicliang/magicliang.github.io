# 第30篇实验验收

- 场景：计划第30篇全部随文lab断言。
- 实际调用：`/private/tmp/hexo-ruby-3.4/bin/ruby examples/ruby/labs/30/run.rb`。
- 退出码：0。
- 二元判定：日志中`"pass": true`，任意断言失败会退出非零。
- 可观察结果：race=1；synchronized=2000；两次read均为0，两个I/O读者均读到x；5轮CPU串行/线程样本保存。
- 原始日志：`writing-plans/ruby/evidence/30/run.log`。
- 环境：Ruby 3.4.11 revision 592f1ffdb36153e8be83603ade3c2e9ab6138a77，arm64-darwin27。
- 文风顺序：落盘前人工执行anti-ai-tone（段落支撑、推进、节奏、连续性）后anti-persona-fabrication；落盘后脚本复核见`.omo/evidence/ruby-runtime/prose-check.log`及`persona-check.log`。

本日志为真实执行输出；语法检查与源码阅读不替代行为验收。
