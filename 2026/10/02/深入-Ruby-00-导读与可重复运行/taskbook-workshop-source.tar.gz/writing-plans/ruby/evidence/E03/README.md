# E03 验收记录

最终实际命令：在 examples/ruby 下设置 `PATH=/private/tmp/hexo-ruby-3.4/bin:/opt/homebrew/bin:/usr/bin:/bin BUNDLE_PATH=.bundle/vendor`，执行 `/private/tmp/hexo-ruby-3.4/bin/ruby -rbundler/setup labs/E03/run.rb`，require_escalated本地执行。run.rb默认JAVA=/opt/homebrew/opt/openjdk@21/bin/java、JRUBY_JAR=/private/tmp/ruby-electives-jruby-10.0.5.0.jar；INSTALL.md给出官方下载与覆盖方式。

退出0，原始JSON在run.log，最终pass=true。官方JAR下载SHA256复核见download.log及labs/E03/jruby.sha256。版本CRuby3.4.11、JRuby10.0.5.0（Ruby3.4.5）、OpenJDK21.0.10 Homebrew，arm64 macOS。

二元验收：两解释器共同契约result完全相同；关键字误用与limit=0抛ArgumentError；ensure存在；浅复制嵌套共享；屏障竞争=1、Mutex=2000。JRuby两个Java线程ID37/38不同，ready先于done，线程最终关闭；AtomicInteger=2000、Java集合中文往返、BigDecimal=0.3、NumberFormatException类型正确。

同一结果不证明全部应用/gem兼容；线程ID不是OS TID，未声称CPU倍率。jar留tmp，未添加主线依赖或二进制。正文落盘前顺序双扫描与6个脚本语法记录见.omo/evidence/ruby-electives-runtime/editorial-verification.log。页面检查由根代理统一负责。

主工程Bundler继承环境曾使JRuby加载CRuby的bundler/setup。修复为清除所有BUNDLE前缀变量及RUBYOPT/RUBYLIB/GEM_HOME/GEM_PATH/RUBYGEMS_GEMDEPS；子进程断言无BUNDLE残留，完整主工程激活环境重跑通过。最终run.log对应该修复后复跑。
