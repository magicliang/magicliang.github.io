# 第38篇实验验收

- 场景：计划第38篇全部随文lab断言。
- 实际调用：`/private/tmp/hexo-ruby-3.4/bin/ruby examples/ruby/labs/38/run.rb`。
- 退出码：0。
- 二元判定：日志中`"pass": true`，任意断言失败会退出非零。
- 可观察结果：拒绝越界、缺失、symlink；命令字符串原样作为参数且无文件副作用；白名单拒绝instance_eval；Psych拒绝类标签。
- 原始日志：`writing-plans/ruby/evidence/38/run.log`。
- 环境：Ruby 3.4.11 revision 592f1ffdb36153e8be83603ade3c2e9ab6138a77，arm64-darwin27。
- 文风顺序：落盘前人工执行anti-ai-tone（段落支撑、推进、节奏、连续性）后anti-persona-fabrication；落盘后脚本复核见`.omo/evidence/ruby-runtime/prose-check.log`及`persona-check.log`。

本日志为真实执行输出；语法检查与源码阅读不替代行为验收。
