# 第37篇实验验收

- 场景：计划第37篇全部随文lab断言。
- 实际调用：`/private/tmp/hexo-ruby-3.4/bin/ruby examples/ruby/labs/37/run.rb`。
- 退出码：0。
- 二元判定：日志中`"pass": true`，任意断言失败会退出非零。
- 可观察结果：三策略结果相同；eager访问100000，lazy/loop访问40；各5样本，含分配与RSS。
- 原始日志：`writing-plans/ruby/evidence/37/run.log`。
- 环境：Ruby 3.4.11 revision 592f1ffdb36153e8be83603ade3c2e9ab6138a77，arm64-darwin27。
- 文风顺序：落盘前人工执行anti-ai-tone（段落支撑、推进、节奏、连续性）后anti-persona-fabrication；落盘后脚本复核见`.omo/evidence/ruby-runtime/prose-check.log`及`persona-check.log`。

RSS通过ps读取自身进程；初次sandbox返回EPERM，随后在允许读取的执行环境完整重跑通过。未把权限失败或零占位当作通过。
