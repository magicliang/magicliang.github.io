# 第39篇实验验收

- 场景：计划第39篇全部随文lab断言。
- 实际调用：`cd examples/ruby && PATH=/private/tmp/hexo-ruby-3.4/bin:$PATH BUNDLE_PATH=.bundle/vendor bundle exec ruby -Ilib labs/39/run.rb`。
- 退出码：0。
- 二元判定：日志中`"pass": true`，任意断言失败会退出非零。
- 可观察结果：全新GEM_HOME本地安装；外部cwd CLI JSON/CSV往返；错误退出2/3且原文件保留；installed路径realpath校验；真实HTTP200/400/404；连接3关闭、监听关闭、临时目录清理。
- 原始日志：`writing-plans/ruby/evidence/39/run.log`。
- 环境：Ruby 3.4.11 revision 592f1ffdb36153e8be83603ade3c2e9ab6138a77，arm64-darwin27。
- 文风顺序：落盘前人工执行anti-ai-tone（段落支撑、推进、节奏、连续性）后anti-persona-fabrication；落盘后脚本复核见`.omo/evidence/ruby-runtime/prose-check.log`及`persona-check.log`。

安装路径先用字符串前缀校验触发macOS /var 与 /private/var别名差异，已改为realpath归一化，完整场景重跑通过。HTTP仅绑定127.0.0.1，未访问外网。
