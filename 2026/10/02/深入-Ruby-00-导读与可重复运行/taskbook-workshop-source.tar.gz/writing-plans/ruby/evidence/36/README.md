# 第36篇实验验收

- 场景：五个独立进程/模式，交替运行解释器与YJIT；同输入、100次预热、200次测量。
- 实际调用：`/private/tmp/hexo-ruby-3.4/bin/ruby examples/ruby/labs/36/run.rb`，执行权限require_escalated以支持本机JIT原生代码及ps RSS采样。
- 退出码：0；日志中`"pass": true`。
- 二元判定：全部计算返回600050000；解释模式enabled=false、JIT模式enabled=true；子进程全部正常退出。
- 可观察结果：中位数0.104379/0.018799秒，倍率5.55237；全部分配6；RSS解释16112–18128 KiB、JIT17232–19088 KiB；保存所有runtime_stats。
- 原始日志：`writing-plans/ruby/evidence/36/run.log`。
- 环境：Ruby3.4.11 revision592f1ffdb36153e8be83603ade3c2e9ab6138a77，arm64-darwin27，Rust1.85.1构建YJIT。
- 限制：倍率只覆盖此预热整数负载；未测冷启动/服务性能。受限执行环境曾出现退出137，成功运行使用授权本地执行环境，不把该退出归因于Ruby代码。未改动签名。
- 文风顺序：落盘前anti-ai-tone检查材料支撑、段落推进、节奏、连续性后anti-persona-fabrication检查；未发现第一人称、拟人化和说书人叙事。最终脚本见`.omo/evidence/ruby-runtime/prose-check.log`。
