# Ruby 17 实验验收

- 场景：普通API/DSL三点边界等价、上下文数组、词法/目标TOKEN、非法及缺项拒绝。
- 环境：安装版 CRuby 3.4.11，revision 592f1ffdb3，arm64-darwin27；见 environment.txt。预跑 miniruby 和构建目录结果不作为最终日志。
- 实际调用：`/private/tmp/hexo-ruby-3.4/bin/ruby examples/ruby/labs/17/run.rb`
- 二元判据：退出码 0 且最后一行精确为 `PASS lab 17`；实际满足。
- 原始产物：`run.log` 保存全部断言输出；`syntax.log` 保存 `ruby -c` 的 Syntax OK；`environment.txt` 保存真实运行时。
- 故障调用：`/private/tmp/hexo-ruby-3.4/bin/ruby -e 'eval(File.read(ARGV[0]).sub("raise label unless condition", "raise label if condition"), TOPLEVEL_BINDING, ARGV[0])' examples/ruby/labs/17/run.rb`
- 故障判据：变体必须非零退出；实际退出 1，首个真实断言被反转而失败，原始 stderr 位于 `mutation.log`。未修改原 lab。
- 资料依据：[Ruby 3.4 官方文档](https://docs.ruby-lang.org/en/3.4/Module.html#method-i-class_eval)。
- 限制：只eval源码内固定合成字符串；不可信文本不进入eval；无沙箱宣称。
- 可下载附件：同名文章素材目录中的 lab.rb 与工程脚本字节一致；独立执行结果见 asset-run.log。

## 范围说明

语言实验是核心类的本地合成场景，不需要第三方 gem，不涉及网络与生产系统。解释器安装来源及全系列依赖由 VERSIONS.md 统一记录。Ruby LSP 未安装，未新增依赖；验证由真实解释器语法检查及断言完成。
