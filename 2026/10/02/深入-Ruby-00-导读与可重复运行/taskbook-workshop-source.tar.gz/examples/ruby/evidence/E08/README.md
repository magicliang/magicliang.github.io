# Writing and behavior evidence E08

- Candidate written outside posts; anti-ai-tone check_prose.py --profile tech --json completed before publication: 2610 Han characters, 0 errors, 0 warnings.
- Then anti-persona-fabrication review: no fabricated first-person experience, personification, storytelling transitions; concrete subjects and experiment-bounded claims retained.
- Technical consistency: chapter examples checked against real lab outputs; expected failures require specific errors and fail if unexpectedly accepted.
- Original lab and extracted source.tar.gz both exited 0 under CRuby 3.4.11. See run.log and attachment-run.log.
- Deliberate semantic mutations fail nonzero; exact changed behavior and captured stack trace in mutations.json.
- Mermaid source included in post. Global Hexo generation and browser rendering are delegated to the root integrator, not claimed here.
