# Ruby 系列实验与 Taskbook

固定解释器：CRuby 3.4.11。工程根目录是本文件所在的 `examples/ruby`。

```bash
ruby -v
bundle install
bundle exec ruby verify.rb
```

`verify.rb` 检查 Ruby 文件语法、逐篇运行 00–39 与 E01–E08 共 48 个 lab，再运行行为测试。命令会生成本地 `evidence/NN/verification.log` 和 `evidence/tests.log`；这些重复验收输出不纳入 Git。断言或子进程失败会非零退出。只验证指定篇目时可运行 `bundle exec ruby verify.rb 00 01 E07 E08`，行为测试仍会执行。

运行全部实验前，按各选修目录的 README 或 INSTALL 安装冻结依赖：E01/E02 使用独立 Gemfile 与 `.bundle/vendor`，E03 使用已校验的 JRuby JAR 和 JDK 21，E04 需要 C 编译器及当前 CRuby 头文件，E05 需要两种实现的平台依赖，E06 使用独立 SQLite/ActiveRecord 锁文件。入口不自动联网补依赖；缺少环境会失败。E07/E08 仅使用标准库。

并发、信号、进程与 RSS 实验使用 POSIX 平台；35 使用 CRuby 专有观察接口；36 要求解释器已编译 YJIT，分别启动解释执行与 YJIT 的五个独立进程。缺少能力会报告失败，不跳过后宣称全通过。性能结果只描述实际机器和本次工作负载。

## CLI

```bash
bundle exec ruby -Ilib exe/taskbook --help
bundle exec ruby -Ilib exe/taskbook filter --tag ruby < tasks.json
bundle exec ruby -Ilib exe/taskbook stats < tasks.json
bundle exec ruby -Ilib exe/taskbook export --output report.csv --output-format csv < tasks.json
```

输入 JSON 是数组，任务字段为 `id`、`title`、`priority`、`tags`、`status`；状态的外部形式是 `"todo"` 或 `"done"`。JSON/CSV 格式和输出选项见 `--help`。输出文件已存在时拒绝覆盖。

## 可复核材料

`labs/NN/` 是完整机制实验；`lib/taskbook.rb` 是内存核心，`lib/taskbook/io.rb` 与 `http.rb` 提供数据和 Rack 接口；`test/` 是行为测试；`Gemfile.lock` 固定本工程依赖。

正文采用的原始运行结果保存在 `evidence/`，部分运行时专题的原始观察保存在仓库 `writing-plans/ruby/evidence/`。环境与验证范围见 `writing-plans/ruby/VERSIONS.md`；官方来源列在各篇博文的参考资料中。

`bundle exec steep check` 检查第 25 篇独立协议样例的 RBS 签名，不代表整个 Taskbook 已通过静态类型检查。第 39 篇在新临时 GEM_HOME 中打包安装并执行 CLI 与本地 HTTP，结束后清理临时安装。
