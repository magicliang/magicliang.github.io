# frozen_string_literal: true

require 'taskbook'
require 'json'
require 'csv'

module Taskbook
  module IO
    MAX_BYTES = 65_536
    FIELDS = %w[id title priority tags status].freeze
    STATUSES = { 'todo' => :todo, 'done' => :done }.freeze

    def self.read(stream, format: 'json')
      text = stream.read(MAX_BYTES + 1) || ''
      raise ArgumentError, 'input exceeds 65536 bytes' if text.bytesize > MAX_BYTES
      text = text.dup.force_encoding(Encoding::UTF_8)
      raise ArgumentError, 'input must be valid UTF-8' unless text.valid_encoding?

      rows = case format
             when 'json'
               JSON.parse(text, create_additions: false, max_nesting: 20)
             when 'csv'
               table = CSV.parse(text, headers: true)
               raise ArgumentError, 'invalid CSV headers' unless table.headers == FIELDS
               table.map do |row|
                 values = row.to_h
                 values['id'] = Integer(values['id'], 10)
                 values['priority'] = Integer(values['priority'], 10)
                 values['tags'] = JSON.parse(values['tags'], create_additions: false)
                 values
               end
             else
               raise ArgumentError, 'format must be json or csv'
             end
      raise ArgumentError, 'top level must be an array' unless rows.is_a?(Array)
      tasks = rows.map do |row|
        raise ArgumentError, 'invalid task fields' unless row.is_a?(Hash) && row.keys.sort == FIELDS.sort
        { id: row['id'], title: row['title'], priority: row['priority'],
          tags: row['tags'], status: STATUSES.fetch(row['status']) { raise ArgumentError, 'invalid status' } }
      end
      Taskbook.validate(tasks)
    rescue JSON::ParserError, CSV::MalformedCSVError, TypeError
      raise ArgumentError, 'invalid input syntax'
    end

    def self.dump(tasks, format: 'json')
      checked = Taskbook.validate(tasks)
      case format
      when 'json'
        JSON.generate(checked) + "\n"
      when 'csv'
        CSV.generate do |csv|
          csv << FIELDS
          checked.each { |t| csv << [t[:id], t[:title], t[:priority], JSON.generate(t[:tags]), t[:status]] }
        end
      else
        raise ArgumentError, 'format must be json or csv'
      end
    end
  end
end
