# frozen_string_literal: true

require 'taskbook/io'
require 'net/http'

module Taskbook
  class HTTPApp
    def call(env)
      return response(404, error: 'not found') unless env['PATH_INFO'] == '/tasks'
      return response(405, error: 'method not allowed') unless env['REQUEST_METHOD'] == 'POST'
      return response(415, error: 'application/json required') unless env['CONTENT_TYPE'] == 'application/json'
      tasks = Taskbook::IO.read(env.fetch('rack.input'))
      response(200, Taskbook.summary(tasks))
    rescue ArgumentError
      response(400, error: 'invalid tasks')
    end

    private

    def response(status, value)
      body = JSON.generate(value)
      [status, { 'content-type' => 'application/json', 'content-length' => body.bytesize.to_s }, [body]]
    end
  end

  def self.fetch_local(uri, timeout: 1)
    raise ArgumentError, 'loopback HTTP only' unless uri.scheme == 'http' && uri.host == '127.0.0.1'
    http = Net::HTTP.new(uri.host, uri.port, nil)
    http.open_timeout = timeout
    http.read_timeout = timeout
    http.write_timeout = timeout
    http.max_retries = 0
    response = http.start { |session| session.get(uri.request_uri) }
    raise IOError, "HTTP status #{response.code}" unless response.is_a?(Net::HTTPSuccess)
    response.body
  end
end
