# frozen_string_literal: true

module Taskbook
  FIELDS = %i[id title priority tags status].freeze
  STATUSES = %i[todo done].freeze

  def self.sample_tasks
    [
      { id: 1, title: '复核输入', priority: 5, tags: ['ruby', 'review'], status: :todo },
      { id: 2, title: '整理输出', priority: 2, tags: ['report'], status: :done },
      { id: 3, title: '编写实验', priority: 4, tags: ['ruby'], status: :todo }
    ]
  end

  def self.validate(tasks)
    raise ArgumentError, 'tasks must be an Array' unless tasks.is_a?(Array)

    ids = {}
    tasks.map do |task|
      unless task.is_a?(Hash) && task.keys.sort == FIELDS.sort
        raise ArgumentError, 'task fields must be id, title, priority, tags, status'
      end
      id = task[:id]
      raise ArgumentError, 'id must be a positive Integer' unless id.is_a?(Integer) && id.positive?
      raise ArgumentError, "duplicate id: #{id}" if ids.key?(id)
      ids[id] = true
      title = task[:title]
      unless title.is_a?(String) && title.encoding == Encoding::UTF_8 && title.valid_encoding? && !title.strip.empty?
        raise ArgumentError, 'title must be a nonempty valid UTF-8 String'
      end
      priority = task[:priority]
      unless priority.is_a?(Integer) && (1..5).cover?(priority)
        raise ArgumentError, 'priority must be an Integer in 1..5'
      end
      tags = task[:tags]
      unless tags.is_a?(Array) && tags.all? { |tag| tag.is_a?(String) && tag.encoding == Encoding::UTF_8 && tag.valid_encoding? && !tag.strip.empty? }
        raise ArgumentError, 'tags must contain nonempty valid UTF-8 Strings'
      end
      raise ArgumentError, 'status must be :todo or :done' unless STATUSES.include?(task[:status])

      { id: id, title: title.dup, priority: priority, tags: tags.map(&:dup), status: task[:status] }
    end
  end

  def self.filter(tasks, min_priority: 1, tag: nil, status: nil)
    unless min_priority.is_a?(Integer) && (1..5).cover?(min_priority)
      raise ArgumentError, 'min_priority must be an Integer in 1..5'
    end
    unless tag.nil? || (tag.is_a?(String) && tag.encoding == Encoding::UTF_8 && tag.valid_encoding? && !tag.strip.empty?)
      raise ArgumentError, 'tag must be nil or a nonempty valid UTF-8 String'
    end
    raise ArgumentError, 'status must be nil, :todo or :done' unless status.nil? || STATUSES.include?(status)

    validate(tasks).select do |task|
      task[:priority] >= min_priority && (tag.nil? || task[:tags].include?(tag)) &&
        (status.nil? || task[:status] == status)
    end
  end

  def self.summary(tasks)
    checked = validate(tasks)
    counts = { todo: 0, done: 0 }
    checked.each { |task| counts[task[:status]] += 1 }
    { total: checked.size, by_status: counts }
  end
end
