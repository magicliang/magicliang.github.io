require 'open3'
require 'rbconfig'
require 'fileutils'
require 'json'

raise 'use CRuby 3.4.11' unless RUBY_ENGINE == 'ruby' && RUBY_VERSION == '3.4.11'
root = __dir__
available = (0..39).map { |n| format('%02d', n) } + (1..8).map { |n| format('E%02d', n) }
chapters = ARGV.empty? ? available : ARGV
raise 'arguments must be chapter numbers 00..39 or E01..E08' unless chapters.all? { |n| available.include?(n) }
files = Dir.glob(File.join(root, '{lib,labs,test}/**/*.rb')) + [File.join(root, 'exe/taskbook'), __FILE__]
files.each do |path|
  output, error, status = Open3.capture3(RbConfig.ruby, '-c', path)
  raise "syntax failed: #{path}\n#{output}#{error}" unless status.success?
end
puts "syntax: #{files.length} files PASS"

chapters.each do |number|
  path = File.join(root, 'labs', number, number == '00' ? 'check.rb' : 'run.rb')
  raise "missing lab: #{path}" unless File.file?(path)
  output, error, status = Open3.capture3(RbConfig.ruby, path, chdir: root)
  directory = File.join(root, 'evidence', number)
  FileUtils.mkdir_p(directory)
  log = "command: ruby #{path.delete_prefix(root + '/')}\n#{output}#{error}\nexit: #{status.exitstatus}\n"
  File.write(File.join(directory, 'verification.log'), log.lines.map { |line| line.rstrip + "\n" }.join)
  raise "lab #{number} failed\n#{output}#{error}" unless status.success?
  puts "lab #{number}: PASS"
end

output, error, status = Open3.capture3(RbConfig.ruby, '-Ilib', 'test/engineering_boundaries_test.rb', chdir: root)
raise "tests failed\n#{output}#{error}" unless status.success?
File.write(File.join(root, 'evidence', 'tests.log'), output + error)
puts output
puts "PASS #{chapters.length} labs, syntax, behavioral tests"
