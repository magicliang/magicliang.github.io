require 'rbconfig'
require 'open3'
gemfile = File.join(__dir__, 'Gemfile')
unless ENV['BUNDLE_GEMFILE'] == gemfile
  isolated = ENV.keys.grep(/\ABUNDLE/).to_h { |key| [key, nil] }
  isolated.merge!('BUNDLE_GEMFILE' => gemfile, 'BUNDLE_PATH' => File.join(__dir__, '.bundle/vendor'),
                  'RUBYOPT' => nil, 'RUBYLIB' => nil)
  status = system(isolated, RbConfig.ruby, '-rbundler/setup', __FILE__)
  exit(status ? 0 : 1)
end
require 'bundler/setup'
require 'open3'
require 'rbconfig'
require 'json'
require 'stringio'
require 'fileutils'

probe = <<~'RUBY'
  raise 'core unexpectedly extended' if ' '.respond_to?(:blank?)
  require 'active_support/core_ext/object/blank'
  raise 'blank semantics' unless ' '.blank? && false.blank? && !0.blank?
  puts 'core=false extension=true false.blank?=true zero.blank?=false'
RUBY
stdout, stderr, status = Open3.capture3(RbConfig.ruby, '-rbundler/setup', '-e', probe)
raise stderr unless status.success?
puts stdout

require 'rails'
require 'action_controller/railtie'
require_relative '../../lib/taskbook'

class WorkshopApplication < Rails::Application
  config.root = __dir__
  config.eager_load = false
  config.secret_key_base = 'educational-local-key-' * 8
  config.hosts = ['www.example.com']
  config.logger = Logger.new(StringIO.new)
  config.action_dispatch.show_exceptions = :none
end

app = WorkshopApplication.initialize!
app.routes.draw { get '/tasks', to: 'tasks#index' }
controller = File.join(__dir__, 'app/controllers/tasks_controller.rb')
raise 'controller eagerly loaded' if $LOADED_FEATURES.include?(controller)
session = ActionDispatch::Integration::Session.new(app)
session.get('/tasks', headers: { 'X-Lab-Key' => 'local-test' })
raise 'request failed' unless session.response.status == 200
raise 'business protocol' unless JSON.parse(session.response.body)['total'] == 3
raise 'not autoloaded' unless $LOADED_FEATURES.include?(controller)
events = session.request.env.fetch('lab.events')
raise 'callback order' unless events == %w[before around-enter action around-exit]
session.get('/tasks')
raise 'authorization bypass' unless session.response.status == 401
raise 'action ran after rejection' unless session.request.env['lab.events'] == ['before']
session.get('/tasks?min=nope', headers: { 'X-Lab-Key' => 'local-test' })
raise 'invalid input accepted' unless session.response.status == 422
raise 'around ensure lost' unless session.request.env['lab.events'].last == 'around-exit'
session.get('/tasks?min[]=1', headers: { 'X-Lab-Key' => 'local-test' })
raise 'structured parameter accepted' unless session.response.status == 422
evidence = { ruby: RUBY_DESCRIPTION, rails: Rails.version,
             autoloaded: true, callbacks: events, statuses: [200, 401, 422, 422] }
target = File.expand_path('../../evidence/E01', __dir__)
FileUtils.mkdir_p(target)
File.write(File.join(target, 'requests.json'), JSON.pretty_generate(evidence))
puts JSON.generate(evidence)
puts 'PASS E01 real Rails integration requests, autoload and callbacks'
