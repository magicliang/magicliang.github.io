# frozen_string_literal: true

class TaskStream
  include Enumerable
  def initialize(items)
    @items = items
  end
  def each
    return enum_for(__method__) unless block_given?
    @items.each { |item| yield item }
    self
  end
end
source = TaskStream.new([1, 2, 3, 4, 5])
raise unless source.select(&:odd?).map { |n| n * 10 } == [10, 30, 50]
eager_count = 0
eager = (1..100).map { |n| eager_count += 1; n * 2 }.take(3)
lazy_count = 0
pipeline = (1..100).lazy.map { |n| lazy_count += 1; n * 2 }.take(3)
raise unless lazy_count.zero?
lazy = pipeline.force
raise unless lazy == eager && eager_count == 100 && lazy_count == 3
pipeline.force
raise unless lazy_count == 6
raise unless (1..).lazy.select(&:odd?).take(4).force == [1, 3, 5, 7]
enum = source.each
raise unless enum.next == 1 && enum.next == 2
enum.rewind
raise unless enum.next == 1
raise unless source.reduce(0) { |sum, item| sum + item } == 15
puts "eager=#{eager_count} lazy_first=3 lazy_second=#{lazy_count} result=#{lazy.inspect} infinite=#{(1..).lazy.take(3).force.inspect}"
puts 'PASS 08'
