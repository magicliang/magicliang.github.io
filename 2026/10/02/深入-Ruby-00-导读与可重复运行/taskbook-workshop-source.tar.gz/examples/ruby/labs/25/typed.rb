module TypedTasks
  def self.total(tasks)
    tasks.length
  end

  def self.titles(tasks)
    tasks.map { |task| task[:title] }
  end

  def self.each_title(tasks)
    tasks.each { |task| yield task[:title] }
    nil
  end
end
