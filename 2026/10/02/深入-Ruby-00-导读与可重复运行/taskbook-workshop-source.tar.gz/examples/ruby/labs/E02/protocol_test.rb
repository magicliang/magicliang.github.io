require 'minitest/autorun'
require_relative 'contract'

class ProtocolTest < Minitest::Test
  TaskbookContract.cases.each_with_index do |(description, check), index|
    define_method("test_contract_#{index}") { assert check.call, description }
  end
end
