# frozen_string_literal: true

def select_tasks(tasks, min_priority: 1, **options)
  raise ArgumentError, 'unknown option' unless options.empty?
  [tasks, min_priority]
end
def forward(...)
  select_tasks(...)
end
def separated(*args, **keywords, &block)
  [args, keywords, block&.call]
end
raise unless select_tasks([], min_priority: 4) == [[], 4]
raise unless forward([], **{ min_priority: 3 }) == [[], 3]
begin
  select_tasks([], { min_priority: 4 })
  raise 'Hash treated as keyword arguments'
rescue ArgumentError
end
begin
  select_tasks([], unexpected: true)
  raise 'unknown option accepted'
rescue ArgumentError
end
counter = 0
factory = -> { counter += 1; [] }
define_singleton_method(:defaulted) { |items = factory.call| items }
raise unless defaulted.object_id != defaulted.object_id && counter == 2
result = separated({ min_priority: 4 }, min_priority: 2) { :block }
raise unless result == [[{ min_priority: 4 }], { min_priority: 2 }, :block]
puts "forward=#{forward([], min_priority: 3).inspect} channels=#{result.inspect} defaults=#{counter}"
puts 'PASS 05'
