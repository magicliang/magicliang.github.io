# E08 retry, idempotency, cancellation and shutdown

CRuby 3.4.11, core Ruby only. From repository root:

```sh
ruby examples/ruby/labs/E08/run.rb
```

After extracting the article attachment: `ruby run.rb` in E08. Effects, processed
keys, queue and terminal/dead events exist only in this process. There is no
Sidekiq, Redis, network service, persistence or crash recovery claim.

Tests assert actual in-memory writes and amounts, not merely worker return values:
naive duplicate amount 14; protected jobs a/b total 10, writes 2; poisoned task
exactly 3 attempts; same key/different payload rejected. Backoff injection records
virtual seconds [1,1,2] without sleeping. Two concurrent same-key calls yield only
one write. Queue barriers place cancellation before the effect checkpoint.

Shutdown stops submissions, closes Queue and waits for worker value. drain:false
cooperatively cancels running/pending work at checkpoints. Hooks/sleeper must
return; no forced shutdown deadline or thread kill is provided. Cancellation
arriving after an effect cannot undo it. Queue and dedup history are unbounded in
this small teaching implementation. Expected exit 0 and PASS lab E08.
