require 'tmpdir'
require 'open3'
require 'rbconfig'
require 'fileutils'
require 'rubygems/package'
root = File.expand_path('../..', __dir__)
Dir.mktmpdir('taskbook-package') do |dir|
  package = File.join(dir, 'taskbook.gem')
  out, err, status = Open3.capture3(RbConfig.ruby, '-S', 'gem', 'build', 'taskbook.gemspec', '--output', package, chdir: root)
  raise "build failed: #{out} #{err}" unless status.success?
  contents = Gem::Package.new(package).spec.files
  raise 'missing public API' unless contents.include?('lib/taskbook.rb') && contents.include?('lib/taskbook/io.rb') && contents.include?('exe/taskbook')
  raise 'lab accidentally packaged' if contents.any? { |name| name.start_with?('labs/', 'test/', '.bundle/') }
  installed = File.join(dir, 'installed')
  env = ENV.keys.grep(/\ABUNDLE/).to_h { |key| [key, nil] }
  env.merge!('GEM_HOME' => installed, 'GEM_PATH' => [installed, Gem.path].flatten.join(File::PATH_SEPARATOR),
             'RUBYOPT' => nil, 'RUBYLIB' => nil)
  out, err, status = Open3.capture3(env, RbConfig.ruby, '-S', 'gem', 'install', '--local', package, '--install-dir', installed, '--ignore-dependencies', '--no-document')
  raise "install failed: #{out} #{err}" unless status.success?
  code = 'require "taskbook/io"; require "stringio"; raise unless Taskbook::IO.read(StringIO.new("[]")) == []; puts Gem.loaded_specs.fetch("taskbook-workshop").full_gem_path'
  out, err, status = Open3.capture3(env, RbConfig.ruby, '-e', code, chdir: dir)
  raise "installed API failed: #{out} #{err}" unless status.success? && out.include?(installed)
  out, err, status = Open3.capture3(env, RbConfig.ruby, File.join(installed, 'bin/taskbook'), 'stats', stdin_data: '[]', chdir: dir)
  raise "installed CLI failed: #{out} #{err}" unless status.success? && out.include?('"total":0')
  puts 'PASS 22: local package build, isolated install, installed API and CLI'
  puts 'Dependencies reused from frozen bundle; no remote package publication.'
end
