# frozen_string_literal: true
require 'tmpdir'
Dir.mktmpdir('taskbook-load') do |dir|
  path = File.join(dir, 'feature.rb')
  File.write(path, '$taskbook_load_count = ($taskbook_load_count || 0) + 1')
  raise unless require(path) == true
  raise unless require(path) == false
  raise unless $taskbook_load_count == 1 && $LOADED_FEATURES.include?(path)
  load path
  load path
  raise unless $taskbook_load_count == 3
  auto = File.join(dir, 'auto.rb')
  File.write(auto, 'module LoadProbe; Value = 42; end')
  Object.const_set(:LoadProbe, Module.new)
  LoadProbe.autoload(:Value, auto)
  raise unless LoadProbe.autoload?(:Value) == auto
  raise unless LoadProbe::Value == 42 && LoadProbe.autoload?(:Value).nil?
  a = File.join(dir, 'a.rb')
  b = File.join(dir, 'b.rb')
  File.write(a, "require #{b.dump}\nCycleComplete = true\n")
  File.write(b, "require #{a.dump}\nCycleObserved = defined?(CycleComplete)\n")
  require a
  raise unless CycleComplete && CycleObserved.nil?
end
puts 'PASS 20: require once, load repeated, autoload, partially initialized cycle'
