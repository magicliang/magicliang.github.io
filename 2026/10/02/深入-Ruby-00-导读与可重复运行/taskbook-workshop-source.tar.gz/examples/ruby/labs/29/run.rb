require 'open3'
require 'rbconfig'
require 'json'
require 'timeout'
file = { 'limit' => 10, 'token' => 'secret' }
env = { 'limit' => 20 }
cli = { 'limit' => 30 }
config = file.merge(env).merge(cli)
raise unless config['limit'] == 30
safe_log = JSON.generate(event: 'configured', limit: config.fetch('limit'))
raise if safe_log.include?('secret') || safe_log.include?('token')
Open3.popen3(RbConfig.ruby, 'labs/29/daemon.rb') do |stdin, stdout, stderr, child|
  Timeout.timeout(5) do
    raise unless JSON.parse(stdout.gets).fetch('event') == 'ready'
    stdin.write("one\ntwo\n")
    stdin.flush
    accepted = JSON.parse(stdout.gets)
    raise unless accepted == { 'event' => 'accepted', 'id' => 'one' }
    Process.kill('TERM', child.pid)
    stdin.close
    events = stdout.each_line.map { |line| JSON.parse(line).fetch('event') }
    raise unless events == %w[finished stop_accepting closed] && child.value.success?
    raise unless stderr.read.empty?
  end
ensure
  if child.alive?
    Process.kill('KILL', child.pid)
    child.join
  end
end
puts 'PASS 29: configuration precedence, allowlisted log, TERM lifecycle child exited'
