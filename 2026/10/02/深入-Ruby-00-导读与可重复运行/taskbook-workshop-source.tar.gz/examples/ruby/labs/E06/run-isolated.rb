# frozen_string_literal: true
require 'rbconfig'
root = ENV.fetch('E06_BUNDLE_ROOT', '/tmp/ruby-e06-bundle')
env = ENV.keys.grep(/\A(?:BUNDLE|RUBYOPT\z|RUBYLIB\z|GEM_HOME\z|GEM_PATH\z)/).to_h { |key| [key, nil] }
env.merge!('BUNDLE_GEMFILE' => File.expand_path('Gemfile', __dir__), 'BUNDLE_PATH' => root,
  'BUNDLE_APP_CONFIG' => "#{root}-config", 'BUNDLE_USER_HOME' => "#{root}-home", 'BUNDLE_FROZEN' => 'true',
  'GEM_HOME' => "#{root}-bootstrap", 'GEM_PATH' => "#{root}-bootstrap")
ruby = RbConfig.ruby
bundle = File.join(RbConfig::CONFIG.fetch('bindir'), 'bundle')
command = ARGV == ['--install'] ? ['install'] : ['exec', ruby, File.join(__dir__, 'experiment.rb')]
raise ArgumentError, 'use no arguments or --install' unless ARGV.empty? || ARGV == ['--install']
exec(env, ruby, bundle, *command)
