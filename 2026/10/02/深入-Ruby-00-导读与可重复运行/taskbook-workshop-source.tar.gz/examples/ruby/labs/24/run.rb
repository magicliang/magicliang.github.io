require 'open3'
require 'rbconfig'
require 'tmpdir'
env = { 'RUBY_DEBUG_NO_COLOR' => '1', 'RUBY_DEBUG_HISTORY_FILE' => '/dev/null' }
out, err, status = Open3.capture3(env, RbConfig.ruby, '-rdebug', 'labs/24/probe.rb', stdin_data: "p total\nbt\ncontinue\n")
raise "debugger failed: #{out} #{err}" unless status.success? && (out + err).include?('report_total') && (out + err).include?('=> 2')
puts out, err
Dir.mktmpdir do |dir|
  file = File.join(dir, 'invalid.rb')
  File.write(file, 'def missing(')
  out, err, status = Open3.capture3(RbConfig.ruby, '-c', file)
  raise 'syntax failure not detected' if status.success?
  puts err
end
out, err, status = Open3.capture3(RbConfig.ruby, '-w', '-e', 'KNOWN = 1; KNOWN = 2')
raise unless status.success? && err.include?('already initialized constant')
puts err
puts 'PASS 24: breakpoint locals/stack, negative syntax, warning'
