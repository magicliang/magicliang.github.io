# frozen_string_literal: true

shared = Array.new(2, [])
shared[0] << :changed
raise unless shared == [[:changed], [:changed]]
separate = Array.new(2) { [] }
separate[0] << :changed
raise unless separate == [[:changed], []]
wrong = Hash.new([])
wrong[:one] << 1
raise unless wrong[:two] == [1] && wrong.empty?
right = Hash.new { |hash, key| hash[key] = [] }
right[:one] << 1
raise unless right[:two].empty? && right.keys == [:one, :two]
raise unless 1 == 1.0 && !1.eql?(1.0)
raise unless { 1 => :integer, 1.0 => :float }.size == 2
key = String.new('task')
index = { key => 7 }
key << '!'
raise unless index['task'] == 7 && !index.key?('task!')
raise unless (1..5).cover?(5) && !(1...5).cover?(5)
raise unless ('a'..'z').cover?('cc') && !('a'..'z').include?('cc')
source = [{ tags: ['ruby'] }]
copy = source.dup
copy[0][:tags] << 'shared'
raise unless source[0][:tags] == ['ruby', 'shared']
puts "array_alias=#{shared.inspect} hash_missing=#{wrong[:two].inspect} key_count=2 range=#{[('a'..'z').cover?('cc'), ('a'..'z').include?('cc')].inspect}"
puts 'PASS 04'
