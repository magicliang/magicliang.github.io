module TaskbookPolicyFixture
  def self.total(tasks)
    tasks.length
  end

  def self.count(tasks)
    warn 'DEPRECATED fixture count; use total before upgrading to 2.0'
    total(tasks)
  end
end
