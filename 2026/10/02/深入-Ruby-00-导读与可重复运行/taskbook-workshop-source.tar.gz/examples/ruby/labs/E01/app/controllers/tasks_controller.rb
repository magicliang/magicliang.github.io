class TasksController < ActionController::Base
  before_action :authorize_lab
  around_action :record_action

  def index
    request.env['lab.events'] << 'action'
    raw = params.fetch(:min, '1')
    raise ArgumentError, 'min must be a string' unless raw.is_a?(String)
    tasks = Taskbook.filter(Taskbook.sample_tasks, min_priority: Integer(raw, 10))
    render json: Taskbook.summary(tasks)
  rescue ArgumentError => error
    render json: { error: error.class.name }, status: :unprocessable_content
  end

  private

  def authorize_lab
    request.env['lab.events'] = ['before']
    head :unauthorized unless request.headers['X-Lab-Key'] == 'local-test'
  end

  def record_action
    request.env['lab.events'] << 'around-enter'
    yield
  ensure
    request.env['lab.events'] << 'around-exit'
  end
end
