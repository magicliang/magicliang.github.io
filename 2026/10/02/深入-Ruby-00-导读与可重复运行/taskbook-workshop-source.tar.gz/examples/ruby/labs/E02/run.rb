require 'rbconfig'
require 'open3'
gemfile = File.join(__dir__, 'Gemfile')
unless ENV['BUNDLE_GEMFILE'] == gemfile
  isolated = ENV.keys.grep(/\ABUNDLE/).to_h { |key| [key, nil] }
  isolated.merge!('BUNDLE_GEMFILE' => gemfile, 'BUNDLE_PATH' => File.join(__dir__, '.bundle/vendor'),
                  'RUBYOPT' => nil, 'RUBYLIB' => nil)
  status = system(isolated, RbConfig.ruby, '-rbundler/setup', __FILE__)
  exit(status ? 0 : 1)
end
require 'bundler/setup'
require 'open3'
require 'rbconfig'
require 'json'
require 'fileutils'
require_relative 'contract'

target = File.expand_path('../../evidence/E02', __dir__)
FileUtils.mkdir_p(target)
commands = {
  minitest: [RbConfig.ruby, 'protocol_test.rb', '--seed', '20261002'],
  rspec: [RbConfig.ruby, '-S', 'rspec', 'protocol_spec.rb', '--seed', '20261002', '--format', 'documentation']
}
commands.each do |name, command|
  out, err, status = Open3.capture3(*command, chdir: __dir__)
  File.write(File.join(target, "#{name}.txt"), out + err)
  raise "#{name} failed: #{out}#{err}" unless status.success?
  puts out
  out, err, status = Open3.capture3({ 'TASKBOOK_MUTANT' => '1' }, *command, chdir: __dir__)
  File.write(File.join(target, "#{name}-mutant.txt"), out + err)
  raise "#{name} did not reject boundary mutant" unless status.exitstatus == 1 && out.include?('filter keeps threshold')
end

seed = Integer(ENV.fetch('SEED', '20261002'), 10)
random = Random.new(seed)
counterexample = nil
100.times do
  tasks = Array.new(random.rand(1..8)) do |index|
    { id: index + 1, title: "task-#{index}", priority: random.rand(1..5),
      tags: ["tag-#{random.rand(1..3)}"], status: random.rand(2).zero? ? :todo : :done }
  end
  min = random.rand(1..5)
  before = Marshal.dump(tasks)
  selected = Taskbook.filter(tasks, min_priority: min)
  raise 'idempotence' unless Taskbook.filter(selected, min_priority: min) == selected
  raise 'threshold' unless selected == tasks.select { |task| task[:priority] >= min }
  raise 'input mutated' unless Marshal.dump(tasks) == before
  mutant = tasks.select { |task| task[:priority] > min }
  counterexample ||= { tasks: tasks, min: min } if selected != mutant && tasks.size > 1
end
raise 'mutant survived seed' unless counterexample
fails = lambda do |tasks, min|
  Taskbook.filter(tasks, min_priority: min) != tasks.select { |task| task[:priority] > min }
end
candidate = Marshal.load(Marshal.dump(counterexample[:tasks]))
steps = []
candidate.length.downto(1) do |length|
  next unless candidate.length == length
  candidate.each_index.to_a.reverse_each do |index|
    trial = candidate.each_with_index.reject { |_, i| i == index }.map(&:first)
    next unless fails.call(trial, counterexample[:min])
    steps << { operation: 'delete', index: index, before_size: candidate.size, after_size: trial.size }
    candidate = trial
  end
end
min = counterexample[:min]
simplified = [{ id: 1, title: 'x', priority: 1, tags: [], status: :todo }]
raise 'shrinker lost failure' unless fails.call(simplified, 1)
steps << { operation: 'canonicalize single boundary record', from_min: min, to_min: 1 }
raise 'not deletion minimal' if fails.call([], 1)
report = { seed: seed, generated_cases: 100, original: counterexample,
           deletion_result: candidate, shrink_steps: steps,
           minimal: { tasks: simplified, min: 1 }, mutant: 'priority > min',
           correct_result_count: Taskbook.filter(simplified, min_priority: 1).size,
           mutant_result_count: simplified.count { |task| task[:priority] > 1 } }
File.write(File.join(target, 'generated.json'), JSON.pretty_generate(report))
puts 'PASS E02 both protocol suites, 100 generated cases, mutant killed and shrunk'
