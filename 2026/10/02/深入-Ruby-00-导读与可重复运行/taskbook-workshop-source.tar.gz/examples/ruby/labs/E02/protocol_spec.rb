require_relative 'contract'

RSpec.describe 'Taskbook real protocol' do
  TaskbookContract.cases.each do |description, check|
    it(description) { expect(check.call).to eq(true) }
  end
end
