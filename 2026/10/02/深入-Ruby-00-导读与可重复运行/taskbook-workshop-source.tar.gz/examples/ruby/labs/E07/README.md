# E07 restricted rule parser

CRuby 3.4.11, core Ruby only. From repository root:

```sh
ruby examples/ruby/labs/E07/run.rb
```

After extracting the article attachment: `ruby run.rb` in E07. `rules.rb` contains
independent Lexer, Parser, immutable AST representation and Evaluator. No eval,
instance_eval or user-derived send is used. AST objects are trusted outputs of
this Parser, not a public serialized-object input format.

Rules are ASCII text tagged valid UTF-8, up to 1024 bytes / 128 tokens / 12 recursive
parenthesis-or-not levels. Strings are lowercase ASCII labels up to 32 characters.
Tasks are bounded to 100 per batch and 32 tags each. A batch shares 256 node visits
unless the trusted caller chooses another positive budget. AST node cap 128 is
redundant under this grammar's token cap; it is not claimed separately triggered.

Expected exit 0, ids=[1, 2], AST=or/and and PASS lab E07. Invalid grammar, encoding,
shape and limits have explicit rejection assertions. This is a teaching language,
not a general Ruby sandbox, a Unicode grammar or a production security audit.
