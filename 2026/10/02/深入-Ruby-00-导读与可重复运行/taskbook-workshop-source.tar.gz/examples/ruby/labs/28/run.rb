require 'taskbook/http'
require 'socket'
require 'rack/mock'
require 'rack/lint'
def server_reply(reply, delay: 0)
  server = TCPServer.new('127.0.0.1', 0)
  port = server.addr[1]
  worker = Thread.new do
    client = server.accept
    begin
      line = client.gets
      raise 'missing request' unless line&.start_with?('GET ')
      while (header = client.gets) && header != "\r\n"; end
      sleep delay
      client.write(reply)
    rescue Errno::EPIPE, Errno::ECONNRESET
    ensure
      client.close
    end
  end
  yield URI("http://127.0.0.1:#{port}/")
ensure
  server&.close
  worker&.join
  raise 'listener leaked' if server && !server.closed?
end
server_reply("HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok") do |uri|
  raise unless Taskbook.fetch_local(uri) == 'ok'
end
server_reply("HTTP/1.1 503 Unavailable\r\nContent-Length: 0\r\nConnection: close\r\n\r\n") do |uri|
  begin
    Taskbook.fetch_local(uri)
  rescue IOError
  else
    raise 'HTTP error escaped'
  end
end
server_reply('', delay: 0.15) do |uri|
  begin
    Taskbook.fetch_local(uri, timeout: 0.03)
  rescue Net::ReadTimeout
  else
    raise 'timeout missing'
  end
end
request = Rack::MockRequest.new(Rack::Lint.new(Taskbook::HTTPApp.new))
response = request.post('/tasks', 'CONTENT_TYPE' => 'application/json', input: '[]')
raise unless response.status == 200 && JSON.parse(response.body)['total'] == 0
puts 'PASS 28: loopback success/HTTP error/read timeout, listener closed, Rack::Lint'
