# frozen_string_literal: true
require 'tmpdir'
Dir.mktmpdir('taskbook-io') do |dir|
  path = File.join(dir, 'tasks.txt')
  File.write(path, "one\ntwo\n")
  held = nil
  begin
    File.open(path, 'r:UTF-8') do |file|
      held = file
      raise unless file.read(2) == 'on' && file.read(2) == "e\n"
      raise ArgumentError, 'consumer failed'
    end
  rescue ArgumentError
    raise unless held.closed?
  end
  File.binwrite(path, "\xFF".b)
  begin
    File.open(path, 'r:UTF-8:UTF-16LE', &:read)
  rescue Encoding::InvalidByteSequenceError
  else
    raise 'invalid encoding accepted'
  end
  File.write(path, 'old')
  pending = File.join(dir, 'tasks.pending')
  File.open(pending, 'w') { |f| f.write('new'); f.flush; f.fsync }
  File.rename(pending, path)
  raise unless File.read(path) == 'new' && !File.exist?(pending)
end
puts 'PASS 19: partial reads, exceptional close, encoding, same-directory rename'
