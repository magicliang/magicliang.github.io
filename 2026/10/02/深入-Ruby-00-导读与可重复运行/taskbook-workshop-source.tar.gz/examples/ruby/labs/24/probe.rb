def report_total(tasks)
  total = tasks.length
  binding.break
  total
end
puts report_total([:one, :two])
