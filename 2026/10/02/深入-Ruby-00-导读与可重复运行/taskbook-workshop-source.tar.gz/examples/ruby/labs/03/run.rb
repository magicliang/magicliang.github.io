# frozen_string_literal: true

text = '任务'
raise unless text.bytesize == 6 && text.length == 2
bad = "\xFF".b.force_encoding(Encoding::UTF_8)
raise if bad.valid_encoding?
begin
  bad.encode(Encoding::UTF_16LE)
  raise 'invalid bytes accepted'
rescue Encoding::InvalidByteSequenceError
end
raise unless bad.scrub == "\uFFFD"
converted = text.encode(Encoding::UTF_16LE).encode(Encoding::UTF_8)
raise unless converted == text
mutable = String.new('ruby')
alias_text = mutable
mutable << '!'
raise unless alias_text == 'ruby!'
raise unless :todo == 'todo'.to_sym && :todo != 'todo'
raise unless /\Aruby\z/.match?('ruby') && !/\Aruby\z/.match?("ruby\n")
raise unless /^ruby$/.match?("ruby\n")
raise unless /\A(?<name>[^:]+):(?<id>[0-9]+)\z/.match('task:12')[:id] == '12'
puts "utf8=#{[text.bytesize, text.length].inspect} invalid=#{bad.valid_encoding?} scrub=#{bad.scrub.inspect} alias=#{alias_text}"
puts 'PASS 03'
