# frozen_string_literal: true
require_relative 'rules'
raise 'Ruby 3.4 required' unless RUBY_VERSION.start_with?('3.4.')
def check(label, condition)
  raise label unless condition
  puts "PASS #{label}"
end
def rejects(label)
  yield
  raise "accepted #{label}"
rescue Rules::Error
  puts "PASS reject #{label}"
end
tasks = [
  { id: 1, priority: 1, status: 'done', tags: ['ruby'] },
  { id: 2, priority: 5, status: 'todo', tags: ['ruby'] },
  { id: 3, priority: 5, status: 'todo', tags: ['sql'] }
]
rule = 'status == "done" or priority >= 4 and tag == "ruby"'
tree = Rules::Parser.call(rule)
check('and binds before or', tree.kind == :or && tree.args[1].kind == :and)
selected = Rules::Evaluator.call(tree, tasks).map { |task| task[:id] }
check('selection ids 1,2', selected == [1, 2])
parenthesized = Rules::Parser.call('(status == "done" or priority >= 4) and not tag == "ruby"')
check('parentheses and not', Rules::Evaluator.call(parenthesized, tasks).map { |task| task[:id] } == [3])
[
  '', 'priority >=', 'priority >= 6', 'status == "other"', 'tag > "ruby"',
  'system("echo")', 'priority >= 1; exit', 'priority >= 1 garbage',
  'priority >= 1 # comment', 'tag == "a\\nb"', 'priority >= 1.0'
].each { |input| rejects(input.inspect) { Rules::Parser.call(input) } }
rejects('bytes') { Rules::Parser.call(' ' * 1025) }
rejects('tokens') { Rules::Parser.call(['not'] * 129 * ' ') }
rejects('depth') { Rules::Parser.call('not ' * 13 + 'priority >= 1') }
rejects('encoding') { Rules::Parser.call("\xFF".dup.force_encoding('UTF-8')) }
rejects('task count') { Rules::Evaluator.call(tree, tasks * 34) }
rejects('task shape') { Rules::Evaluator.call(tree, [{ priority: '5' }]) }
rejects('task tag encoding') { Rules::Evaluator.call(tree, [tasks.first.merge(tags: ["\xFF".dup.force_encoding('UTF-8')])]) }
rejects('steps') { Rules::Evaluator.call(tree, tasks, budget: 1) }
short = Rules::Parser.call('priority >= 1 or tag == "ruby"')
check('short circuit consumes two steps', Rules::Evaluator.call(short, [tasks.first], budget: 2).size == 1)
effects = []
trusted = proc { |task| effects << task[:id]; task[:priority] >= 4 }
check('block DSL can mutate closure', tasks.select(&trusted).map { |task| task[:id] } == [2, 3] && effects == [1, 2, 3])
puts "ids=#{selected.inspect} AST=#{tree.kind}/#{tree.args[1].kind} block_effects=#{effects.inspect}"
puts 'PASS lab E07'
