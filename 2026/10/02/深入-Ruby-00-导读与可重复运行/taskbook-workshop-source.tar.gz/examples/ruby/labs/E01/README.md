# E01: Rails request boundary

Ruby 3.4.11. Frozen railties/actionpack/activesupport 8.1.4, selected Rails components (no Active Record/database).

From this directory, with the desired Ruby bin first on PATH:

```sh
env -u BUNDLE_GEMFILE -u RUBYOPT -u RUBYLIB BUNDLE_PATH=.bundle/vendor bundle install
BUNDLE_PATH=.bundle/vendor bundle exec ruby run.rb
```

The runner also accepts `bundle exec ruby labs/E01/run.rb` from examples/ruby. It clears inherited BUNDLE variables, RUBYOPT and RUBYLIB and re-executes with this Gemfile and this directory's .bundle/vendor. No automatic installation occurs. Do not commit or package .bundle.

Actual in-process ActionDispatch integration requests check 200, 401 and two 422 cases, callback execution and controller autoloading. This is not a TCP/server deployment test. Output artifacts: ../../evidence/E01/requests.json and captured run.txt. Core-extension probing uses a fresh Ruby subprocess.
