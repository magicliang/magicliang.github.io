module TaskbookPolicyFixture
  def self.total(tasks)
    tasks.length
  end
end
