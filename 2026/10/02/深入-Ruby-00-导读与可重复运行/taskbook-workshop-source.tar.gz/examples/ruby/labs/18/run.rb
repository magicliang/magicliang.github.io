# frozen_string_literal: true
def path(events, fail: false)
  events << :body
  raise ArgumentError, 'invalid field' if fail
  :body_value
rescue ArgumentError
  events << :rescue
  :recovered
else
  events << :else
  :accepted
ensure
  events << :ensure
  :ignored
end
events = []
raise unless path(events) == :accepted && events == %i[body else ensure]
events.clear
raise unless path(events, fail: true) == :recovered && events == %i[body rescue ensure]
def overwritten
  raise 'lost'
ensure
  return :masked
end
raise unless overwritten == :masked
raise unless StandardError < Exception && !(SystemExit < StandardError)
begin
  begin
    raise SystemExit, 9
  rescue
    raise 'bare rescue swallowed SystemExit'
  end
rescue SystemExit => error
  raise unless error.status == 9
end
begin
  begin
    Integer('bad')
  rescue ArgumentError
    raise RuntimeError, 'import failed'
  end
rescue RuntimeError => error
  raise unless error.cause.is_a?(ArgumentError)
end
raise unless catch(:found) { [1, 2, 3].each { |n| throw :found, n if n.even? }; nil } == 2
begin
  throw :missing
rescue UncaughtThrowError
  puts 'PASS 18: normal/rescue/else/ensure, masking, cause, catch/throw'
else
  raise 'missing throw must fail'
end
