# frozen_string_literal: true
require 'sqlite3'
require 'active_record'
require 'tmpdir'
raise 'Ruby 3.4 required' unless RUBY_VERSION.start_with?('3.4.')
def check(label, condition)
  raise label unless condition
  puts "PASS #{label}"
end
def rejects(label, error)
  yield
  raise "accepted #{label}"
rescue error
  puts "PASS reject #{label}"
end
class AbortDemo < StandardError; end
class SqlTask < ActiveRecord::Base
  self.table_name = 'tasks'
  validates :title, presence: true
end
Dir.mktmpdir('ruby-sql-') do |dir|
  path = File.join(dir, 'tasks.sqlite3')
  db = SQLite3::Database.new(path)
  observer = SQLite3::Database.new(path)
  begin
    [db, observer].each do |connection|
      connection.execute('PRAGMA foreign_keys = ON')
      connection.busy_timeout = 0
    end
    check('fixed driver and database versions', SQLite3::VERSION == '2.7.3' && db.get_first_value('SELECT sqlite_version()') == '3.50.3' && ActiveRecord::VERSION::STRING == '8.0.2')
    db.execute('PRAGMA journal_mode = DELETE')
    db.execute_batch(<<~SQL)
      CREATE TABLE tasks (
        id INTEGER PRIMARY KEY,
        title TEXT NOT NULL UNIQUE CHECK (length(trim(title)) > 0),
        priority INTEGER NOT NULL CHECK (priority BETWEEN 1 AND 5),
        status TEXT NOT NULL CHECK (status IN ('todo','done')),
        version INTEGER NOT NULL DEFAULT 0
      ) STRICT;
      CREATE TABLE audits (
        task_id INTEGER NOT NULL REFERENCES tasks(id),
        message TEXT NOT NULL
      ) STRICT;
    SQL
    insert = 'INSERT INTO tasks(id,title,priority,status) VALUES(?,?,?,?)'
    db.execute(insert, [1, 'write', 3, 'todo'])
    rejects('unique title', SQLite3::ConstraintException) { db.execute(insert, [2, 'write', 3, 'todo']) }
    rejects('priority check', SQLite3::ConstraintException) { db.execute(insert, [2, 'bad', 9, 'todo']) }
    rejects('not null', SQLite3::ConstraintException) { db.execute(insert, [2, nil, 3, 'todo']) }
    rejects('strict type', SQLite3::ConstraintException) { db.execute(insert, [2, 'bad', 'high', 'todo']) }
    rejects('foreign key', SQLite3::ConstraintException) { db.execute('INSERT INTO audits VALUES(?,?)', [999, 'missing']) }
    db.transaction { db.execute(insert, [2, 'review', 5, 'todo']) }
    check('commit observed on second connection', observer.get_first_value('SELECT count(*) FROM tasks') == 2)
    payload = "missing' OR 1=1 --"
    unsafe = db.execute("SELECT id FROM tasks WHERE title = '#{payload}'")
    safe = db.execute('SELECT id FROM tasks WHERE title = ?', [payload])
    check('parameterized value does not become SQL', unsafe.size == 2 && safe.empty?)
    memory = { status: 'todo' }
    begin
      db.transaction do
        db.execute("UPDATE tasks SET status='done' WHERE id=1")
        memory[:status] = 'done'
        raise AbortDemo, 'reject rest of unit of work'
      end
    rescue AbortDemo
      puts 'PASS explicit exception escaped transaction'
    end
    check('rollback DB but not Ruby memory', observer.get_first_value('SELECT status FROM tasks WHERE id=1') == 'todo' && memory[:status] == 'done')
    db.transaction(:immediate) do
      db.execute("UPDATE tasks SET priority=4 WHERE id=1")
      check('observer cannot see uncommitted update', observer.get_first_value('SELECT priority FROM tasks WHERE id=1') == 3)
      rejects('second writer busy', SQLite3::BusyException) { observer.execute("UPDATE tasks SET priority=2 WHERE id=2") }
    end
    check('writer release permits later write', observer.execute("UPDATE tasks SET priority=2 WHERE id=2").empty? && observer.changes == 1)
    db.execute('BEGIN')
    db.execute(insert, [3, 'partial', 1, 'todo'])
    rejects('ABORT affects statement', SQLite3::ConstraintException) { db.execute(insert, [4, 'write', 1, 'todo']) }
    check('earlier transaction write still present', db.get_first_value('SELECT count(*) FROM tasks WHERE id=3') == 1)
    db.execute('ROLLBACK')
    check('explicit rollback removes earlier write', observer.get_first_value('SELECT count(*) FROM tasks WHERE id=3').zero?)
    db.transaction do
      db.execute(insert, [3, 'rescued', '3', 'todo'])
      begin
        db.execute(insert, [4, 'write', 1, 'todo'])
      rescue SQLite3::ConstraintException
        # Deliberately suppress this statement error to observe transaction commit.
      end
    end
    check('rescued statement error permits surrounding commit', observer.get_first_value('SELECT priority FROM tasks WHERE id=3') == 3)
    check('STRICT accepts lossless integer conversion', db.get_first_value('SELECT typeof(priority) FROM tasks WHERE id=3') == 'integer')
    db.execute('DELETE FROM tasks WHERE id=3')
    db.execute('UPDATE tasks SET version=version+1 WHERE id=? AND version=?', [1, 0])
    check('first optimistic update succeeds', db.changes == 1)
    observer.execute('UPDATE tasks SET version=version+1 WHERE id=? AND version=?', [1, 0])
    check('stale optimistic update changes zero rows', observer.changes.zero?)

    ActiveRecord::Base.establish_connection(adapter: 'sqlite3', database: path)
    item = SqlTask.find(1)
    SqlTask.transaction do
      item.update!(status: 'done')
      raise ActiveRecord::Rollback
    end
    check('ORM rollback leaves attribute changed', item.status == 'done' && SqlTask.find(1).status == 'todo')
    item.reload
    check('ORM reload obtains persisted state', item.status == 'todo')
    rejects('ORM validation rejects blank', ActiveRecord::RecordInvalid) { SqlTask.create!(title: '', priority: 1, status: 'todo') }
    rejects('SQL constraint still guards bypass', ActiveRecord::StatementInvalid) { SqlTask.where(id: 1).update_all(priority: 9) }
    check('ORM safe where keeps value separate', SqlTask.where(title: payload).count.zero?)
    puts "ruby=#{RUBY_VERSION} sqlite3_gem=#{SQLite3::VERSION} sqlite=#{db.get_first_value('SELECT sqlite_version()')} activerecord=#{ActiveRecord::VERSION::STRING}"
    puts "injection_rows=#{unsafe.size}/#{safe.size} ruby_memory=#{memory[:status]} database=#{item.status}"
    puts 'PASS lab E06'
  ensure
    ActiveRecord::Base.connection_pool.disconnect! if ActiveRecord::Base.connected?
    observer.close
    db.close
  end
end
