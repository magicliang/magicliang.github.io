# frozen_string_literal: true
require_relative 'jobs'
raise 'Ruby 3.4 required' unless RUBY_VERSION.start_with?('3.4.')
def check(label, condition)
  raise label unless condition
  puts "PASS #{label}"
end
# Model a lost acknowledgement after an observable effect, using only local state.
naive_total = 0; naive_attempts = 0
begin
  naive_attempts += 1; naive_total += 7
  raise Jobs::Retryable if naive_attempts == 1
rescue Jobs::Retryable
  retry
end
check('naive redelivery doubles effect', naive_total == 14 && naive_attempts == 2)
store = Jobs::EffectStore.new; delays = []
worker = Jobs::Worker.new(store, sleeper: ->(seconds) { delays << seconds })
worker.submit(Jobs::Job.new('a', 7, 0, true))
worker.submit(Jobs::Job.new('a', 7, 0, false))
worker.submit(Jobs::Job.new('poison', 99, 10, false))
worker.submit(Jobs::Job.new('b', 3, 0, false))
worker.close
snapshot = store.snapshot; events = worker.events
check('effect store records two writes total 10', snapshot == { total: 10, writes: 2, keys: ['a', 'b'] })
check('ack lost duplicate and repeated delivery', events.count { |event| event == [:effect, 'a', :duplicate] } == 2)
check('poison has exactly three attempts', events.count { |event| event[0..1] == [:attempt, 'poison'] } == 3 && events.include?([:dead, 'poison']))
check('virtual backoff is bounded', delays == [1, 1, 2])
check('drain acknowledges later job before close', events.index([:acked, 'b']) < events.index([:closed]))
begin
  worker.submit(Jobs::Job.new('c', 1, 0, false)); raise 'submit after close accepted'
rescue Jobs::Closed
  puts 'PASS closed submission rejected'
end
begin
  store.apply_once('a', 8); raise 'changed payload accepted'
rescue Jobs::KeyConflict
  puts 'PASS idempotency payload conflict rejected'
end
check('conflict did not mutate effects', store.snapshot == snapshot)

race_store = Jobs::EffectStore.new; start = Queue.new
threads = 2.times.map { Thread.new { start.pop; race_store.apply_once('race', 5) } }
2.times { start << true }; outcomes = threads.map(&:value)
check('atomic claim and effect under concurrent calls', outcomes.sort == [:applied, :duplicate] && race_store.snapshot[:writes] == 1)

cancel_store = Jobs::EffectStore.new; entered = Queue.new; release = Queue.new
cancel_worker = Jobs::Worker.new(cancel_store, before_effect: ->(_job, _attempt) { entered << true; release.pop })
cancel_worker.submit(Jobs::Job.new('cancel', 9, 0, false))
cancel_worker.submit(Jobs::Job.new('pending', 9, 0, false))
entered.pop
cancel_worker.token.cancel
release << true
cancel_worker.close(drain: false)
check('cancelled running and pending jobs have no effects', cancel_store.snapshot[:writes].zero? &&
  cancel_worker.events.include?([:cancelled, 'cancel']) && cancel_worker.events.include?([:cancelled, 'pending']))
check('cancel shutdown still joins worker', cancel_worker.events.last == [:closed])
late = Jobs::Token.new; already = Jobs::EffectStore.new
already.apply_once('late', 4); late.cancel
check('late cancellation cannot undo effect', late.cancelled? && already.snapshot[:total] == 4)
puts "naive_total=#{naive_total} deduplicated=#{snapshot.inspect} delays=#{delays.inspect}"
puts "events=#{events.inspect}"
puts "cancel_events=#{cancel_worker.events.inspect}"
puts 'PASS lab E08'
