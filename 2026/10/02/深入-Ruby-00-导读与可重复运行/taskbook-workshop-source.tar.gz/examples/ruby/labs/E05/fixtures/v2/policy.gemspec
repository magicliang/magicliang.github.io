Gem::Specification.new do |spec|
  spec.name = 'taskbook-policy-fixture'
  spec.version = '2.0.0'
  spec.summary = 'Artificial local-only upgrade fixture'
  spec.authors = ['Ruby workshop']
  spec.license = 'MIT'
  spec.files = ['lib/taskbook_policy_fixture.rb']
  spec.required_ruby_version = '>= 3.4', '< 3.5'
end
