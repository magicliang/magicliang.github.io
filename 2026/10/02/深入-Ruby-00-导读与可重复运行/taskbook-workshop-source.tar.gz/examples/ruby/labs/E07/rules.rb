# frozen_string_literal: true
module Rules
  class Error < StandardError; end
  Token = Data.define(:kind, :value, :offset)
  Node = Data.define(:kind, :args)

  class Lexer
    def self.call(text)
      unless text.instance_of?(String) && text.encoding == Encoding::UTF_8 && text.valid_encoding? && text.ascii_only?
        raise Error, 'rule must be ASCII text tagged UTF-8'
      end
      raise Error, 'byte limit' if text.bytesize > 1024
      tokens = []; offset = 0
      while offset < text.length
        if (match = /\G[ \t\r\n]+/.match(text, offset))
          offset = match.end(0); next
        end
        match = /\G(>=|<=|==|>|<|\(|\)|[a-z]+|[0-9]+|"[a-z][a-z0-9_-]{0,31}")/.match(text, offset)
        raise Error, "illegal token at #{offset}" unless match
        raw = match[0]
        kind, value = if raw.start_with?('"')
          [:string, raw[1...-1].freeze]
        elsif /\A[0-9]+\z/.match?(raw)
          raise Error, 'integer width' if raw.length > 3
          [:integer, Integer(raw, 10)]
        else
          [:word, raw.freeze]
        end
        tokens << Token.new(kind, value, offset)
        raise Error, 'token limit' if tokens.size > 128
        offset = match.end(0)
      end
      (tokens << Token.new(:end, nil, offset)).freeze
    end
  end

  class Parser
    def self.call(text) = new(Lexer.call(text)).parse
    def initialize(tokens)
      @tokens = tokens; @position = 0; @nodes = 0
    end
    def parse
      tree = disjunction(0)
      raise Error, "trailing token at #{current.offset}" unless current.kind == :end
      tree
    end
    private
    def current = @tokens.fetch(@position)
    def consume(value)
      return false unless current.value == value
      @position += 1; true
    end
    def expect(value)
      raise Error, "expected #{value} at #{current.offset}" unless consume(value)
    end
    def node(kind, *args)
      @nodes += 1
      raise Error, 'node limit' if @nodes > 128
      Node.new(kind, args.freeze)
    end
    def disjunction(depth)
      left = conjunction(depth)
      left = node(:or, left, conjunction(depth)) while consume('or')
      left
    end
    def conjunction(depth)
      left = unary(depth)
      left = node(:and, left, unary(depth)) while consume('and')
      left
    end
    def unary(depth)
      raise Error, 'depth limit' if depth > 12
      return node(:not, unary(depth + 1)) if consume('not')
      if consume('(')
        result = disjunction(depth + 1); expect(')'); return result
      end
      predicate
    end
    def predicate
      field = current.value; @position += 1 unless current.kind == :end
      raise Error, 'unknown field' unless %w[priority status tag].include?(field)
      operator = current.value; @position += 1 unless current.kind == :end
      allowed = field == 'priority' ? %w[== >= <= > <] : ['==']
      raise Error, 'operator not allowed' unless allowed.include?(operator)
      value = current
      expected_kind = field == 'priority' ? :integer : :string
      raise Error, 'literal type' unless value.kind == expected_kind
      @position += 1
      raise Error, 'priority literal range' if field == 'priority' && !(1..5).cover?(value.value)
      raise Error, 'status literal' if field == 'status' && !%w[todo done].include?(value.value)
      node(:predicate, field, operator, value.value)
    end
  end

  class Evaluator
    def self.call(tree, tasks, budget: 256)
      raise Error, 'task count' unless tasks.instance_of?(Array) && tasks.size <= 100
      raise Error, 'invalid budget' unless budget.instance_of?(Integer) && budget.positive?
      tasks.each do |task|
        valid = task.instance_of?(Hash) && task[:priority].instance_of?(Integer) &&
          (1..5).cover?(task[:priority]) && %w[todo done].include?(task[:status]) &&
          task[:tags].instance_of?(Array) && task[:tags].size <= 32 &&
          task[:tags].all? { |tag| tag.instance_of?(String) && tag.encoding == Encoding::UTF_8 && tag.valid_encoding? && tag.ascii_only? && tag.bytesize <= 32 && /\A[a-z][a-z0-9_-]*\z/.match?(tag) }
        raise Error, 'invalid task' unless valid
      end
      evaluator = new(budget)
      tasks.select { |task| evaluator.visit(tree, task) }
    end
    def initialize(budget) = (@remaining = budget)
    def visit(tree, task)
      @remaining -= 1
      raise Error, 'evaluation budget' if @remaining.negative?
      case tree.kind
      when :and then visit(tree.args[0], task) && visit(tree.args[1], task)
      when :or then visit(tree.args[0], task) || visit(tree.args[1], task)
      when :not then !visit(tree.args[0], task)
      when :predicate
        field, operator, expected = tree.args
        return task[:tags].include?(expected) if field == 'tag'
        actual = field == 'priority' ? task[:priority] : task[:status]
        case operator
        when '==' then actual == expected
        when '>=' then actual >= expected
        when '<=' then actual <= expected
        when '>' then actual > expected
        when '<' then actual < expected
        else raise Error, 'unknown operator'
        end
      else raise Error, 'unknown node'
      end
    end
  end
end
