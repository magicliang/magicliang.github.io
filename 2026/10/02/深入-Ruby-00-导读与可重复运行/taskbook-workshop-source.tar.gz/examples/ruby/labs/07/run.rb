# frozen_string_literal: true

def escaped_return
  proc { return :left }
end
def live_return
  callback = proc { return :method_result }
  callback.call
  :unreachable
end
def local_return
  callback = -> { return :lambda_result }
  [callback.call, :method_continued]
end
def invoke
  yield
  :after_yield
end
def escaped_break(&block)
  block
end
raise unless live_return == :method_result
raise unless local_return == [:lambda_result, :method_continued]
callback = escaped_return
begin
  callback.call
  raise 'dead return target accepted'
rescue LocalJumpError => error
  raise unless error.reason == :return
end
raise unless invoke { break :caller_result } == :caller_result
raise unless invoke { next :block_result } == :after_yield
late = escaped_break { break :late }
begin
  late.call
  raise 'dead break target accepted'
rescue LocalJumpError => error
  raise unless error.reason == :break
end
count = 0
increment = -> { count += 1 }
observe = -> { count }
increment.call
increment.call
raise unless observe.call == 2
puts "return=#{live_return} lambda=#{local_return.inspect} break=caller_result next=after_yield closure=#{observe.call}"
puts 'PASS 07'
