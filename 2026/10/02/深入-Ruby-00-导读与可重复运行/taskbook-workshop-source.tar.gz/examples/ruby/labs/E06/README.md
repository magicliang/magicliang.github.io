# E06 SQL and transaction experiment

Requires CRuby 3.4.x and Bundler 2.6.9. Verified: CRuby 3.4.11 arm64-darwin27,
sqlite3 gem 2.7.3 (arm64-darwin), linked SQLite 3.50.3, ActiveRecord 8.0.2.
The experiment asserts actual loaded versions. Other platform builds are not tested.

From the repository root:

```sh
ruby examples/ruby/labs/E06/run-isolated.rb --install
ruby examples/ruby/labs/E06/run.rb
```

The first command explicitly downloads the lockfile dependencies; the second never
installs. `E06_BUNDLE_ROOT` overrides `/tmp/ruby-e06-bundle`. Configuration, Bundler
home and bootstrap gem paths are derived from that root, outside the repository.
The child process clears inherited BUNDLE*, RUBYOPT, RUBYLIB, GEM_HOME and GEM_PATH.
Do not place a dependency directory under this lab. On an extracted attachment,
run `ruby run-isolated.rb --install` then `ruby run.rb` from the E06 directory.

`experiment.rb` creates a temporary on-disk database, tests two SQLite connections
and ORM access, then closes connections and removes the database. It deliberately
executes one unsafe SELECT against this disposable database as an injection
counterexample; no real connection string or credentials are used.

Expected: process exit 0 and `PASS lab E06`; logs show injection_rows=2/0,
ruby_memory=done, database=todo. Missing dependencies, a different linked SQLite,
an accepted invalid write or an incorrect result fail the process. See
`../../evidence/E06/run.log` for the actual output used in the article.
