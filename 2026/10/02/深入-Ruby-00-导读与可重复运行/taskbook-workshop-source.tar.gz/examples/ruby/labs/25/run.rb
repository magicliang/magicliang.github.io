require 'open3'
require 'rbconfig'
require 'tmpdir'
require 'fileutils'
require_relative 'typed'
raise unless TypedTasks.total([{ id: 1, title: 'x' }]) == 1
raise unless TypedTasks.titles([{ id: 1, title: 'x' }]) == ['x']
seen = []
TypedTasks.each_title([{ id: 1, title: 'x' }]) { |title| seen << title }
raise unless seen == ['x']
out, err, status = Open3.capture3(RbConfig.ruby, '-S', 'steep', 'check', '-j', '1')
puts out, err
raise 'positive type check failed' unless status.success?
Dir.mktmpdir('taskbook-types') do |dir|
  FileUtils.cp_r('sig', dir)
  File.write(File.join(dir, 'Steepfile'), "target :bad do\n signature 'sig'\n check 'bad.rb'\nend\n")
  File.write(File.join(dir, 'bad.rb'), "module TypedTasks\n def self.total(tasks)\n 'wrong'\n end\n def self.titles(tasks)\n tasks.map { |task| task[:title] }\n end\n def self.each_title(tasks)\n tasks.each { |task| yield task[:title] }; nil\n end\nend\n")
  out, err, status = Open3.capture3(RbConfig.ruby, '-S', 'steep', 'check', '-j', '1', chdir: dir)
  puts out, err
  raise 'negative type check escaped' if status.success?
end
begin
  TypedTasks.titles([{}]).first.upcase
rescue NoMethodError
else
  raise 'runtime missing field escaped'
end
puts 'PASS 25: typed collection/block, rejected return type, runtime unchecked input'
