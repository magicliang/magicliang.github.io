require_relative '../../lib/taskbook'

if ENV['TASKBOOK_MUTANT'] == '1'
  Taskbook.singleton_class.prepend(Module.new do
    def filter(tasks, min_priority: 1, **options)
      super.reject { |task| task[:priority] == min_priority }
    end
  end)
end

module TaskbookContract
  def self.cases
    {
      'filter keeps threshold and does not mutate' => lambda do
        tasks = Taskbook.sample_tasks
        before = Marshal.dump(tasks)
        actual = Taskbook.filter(tasks, min_priority: 4)
        expected = tasks.select { |task| task[:priority] >= 4 }
        actual == expected && Marshal.dump(tasks) == before
      end,
      'invalid priority raises ArgumentError' => lambda do
        begin
          Taskbook.filter(Taskbook.sample_tasks, min_priority: 0)
          false
        rescue ArgumentError
          true
        end
      end,
      'validated nested strings do not alias input' => lambda do
        source = Taskbook.sample_tasks
        copy = Taskbook.validate(source)
        copy.first[:title].replace('changed')
        source.first[:title] != 'changed'
      end
    }
  end
end
