# frozen_string_literal: true
module Jobs
  class Retryable < StandardError; end
  class KeyConflict < StandardError; end
  class Closed < StandardError; end
  Job = Data.define(:key, :amount, :fail_before, :lose_ack)

  class Token
    def initialize
      @mutex = Mutex.new; @cancelled = false
    end
    def cancel = @mutex.synchronize { @cancelled = true }
    def cancelled? = @mutex.synchronize { @cancelled }
  end

  class EffectStore
    def initialize
      @mutex = Mutex.new; @seen = {}; @total = 0; @writes = 0
    end
    def apply_once(key, amount)
      @mutex.synchronize do
        if @seen.key?(key)
          raise KeyConflict, 'key reused for a different amount' unless @seen[key] == amount
          return :duplicate
        end
        @total += amount
        @writes += 1
        @seen[key] = amount
        :applied
      end
    end
    def snapshot = @mutex.synchronize { { total: @total, writes: @writes, keys: @seen.keys.sort } }
  end

  class Worker
    attr_reader :token
    def initialize(store, max_attempts: 3, before_effect: ->(_job, _attempt) {}, sleeper: ->(_seconds) {})
      raise ArgumentError, 'max_attempts must be 1..10' unless max_attempts.instance_of?(Integer) && (1..10).cover?(max_attempts)
      @store = store; @max_attempts = max_attempts; @before_effect = before_effect; @sleeper = sleeper
      @token = Token.new; @queue = Queue.new; @events = []; @events_mutex = Mutex.new
      @state_mutex = Mutex.new; @closed = false
      @thread = Thread.new do
        begin
          while (job = @queue.pop)
            process(job)
          end
        ensure
          record(:closed)
        end
      end
    end
    def submit(job)
      valid = job.instance_of?(Job) && job.key.instance_of?(String) && job.key.encoding == Encoding::UTF_8 && job.key.valid_encoding? && job.key.ascii_only? && /\A[a-z0-9-]{1,32}\z/.match?(job.key) &&
        job.amount.instance_of?(Integer) && job.amount.positive? && job.fail_before.instance_of?(Integer) &&
        job.fail_before >= 0 && [true, false].include?(job.lose_ack)
      raise ArgumentError, 'invalid job' unless valid
      owned = Job.new(job.key.dup.freeze, job.amount, job.fail_before, job.lose_ack)
      @state_mutex.synchronize do
        raise Closed, 'worker is closed' if @closed
        @queue << owned
      end
    end
    def close(drain: true)
      @state_mutex.synchronize do
        @closed = true
        @token.cancel unless drain
        @queue.close
      end
      @thread.value
    end
    def events = @events_mutex.synchronize { @events.map(&:dup) }
    private
    def record(*event) = @events_mutex.synchronize { @events << event }
    def process(job)
      (1..@max_attempts).each do |attempt|
        if @token.cancelled?
          record(:cancelled, job.key); return
        end
        record(:attempt, job.key, attempt)
        begin
          raise Retryable, 'failure before effect' if attempt <= job.fail_before
          @before_effect.call(job, attempt)
          if @token.cancelled?
            record(:cancelled, job.key); return
          end
          result = @store.apply_once(job.key, job.amount)
          record(:effect, job.key, result)
          raise Retryable, 'ack lost after effect' if job.lose_ack && attempt == 1
          record(:acked, job.key); return
        rescue Retryable
          if attempt == @max_attempts
            record(:dead, job.key); return
          end
          delay = 2**(attempt - 1)
          record(:retry, job.key, delay)
          @sleeper.call(delay)
        end
      end
    end
  end
end
