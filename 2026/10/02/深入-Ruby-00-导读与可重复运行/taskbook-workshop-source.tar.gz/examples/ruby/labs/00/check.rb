# frozen_string_literal: true
require_relative '../../lib/taskbook'

tasks = Taskbook.sample_tasks
raise 'filter contract' unless Taskbook.filter(tasks, min_priority: 4, tag: 'ruby').map { |task| task[:id] } == [1, 3]
raise 'summary contract' unless Taskbook.summary(tasks) == { total: 3, by_status: { todo: 2, done: 1 } }
raise 'empty contract' unless Taskbook.filter([]) == []
copy = Taskbook.validate(tasks)
copy.first[:tags].first.replace('changed')
copy.first[:title].replace('changed')
raise 'input alias leaked' unless tasks.first[:tags].first == 'ruby' && tasks.first[:title] == '复核输入'

bad_inputs = [nil, [tasks.first.merge(priority: 6)], [tasks.first.merge(id: 0)],
              [tasks.first.merge(title: '')], [tasks.first.merge(tags: [nil])],
              [tasks.first.merge(status: 'todo')], [tasks.first, tasks.first],
              [tasks.first.merge(unexpected: true)],
              [tasks.first.merge(title: '任务'.encode('UTF-16'))],
              [tasks.first.merge(tags: ['ruby'.encode('UTF-16')])],
              [tasks.first.merge(title: "\xFF".b.force_encoding(Encoding::UTF_8))]]
bad_inputs.each do |input|
  begin
    Taskbook.validate(input)
  rescue ArgumentError
    next
  end
  raise "invalid input accepted: #{input.inspect}"
end
['ruby'.encode('UTF-16'), "\xFF".b.force_encoding(Encoding::UTF_8)].each do |tag|
  begin
    Taskbook.filter(tasks, tag: tag)
  rescue ArgumentError
    next
  end
  raise 'invalid filter tag accepted'
end
puts "PASS 00: baseline, filter, summary, isolation, #{bad_inputs.size} invalid inputs; #{RUBY_DESCRIPTION}"
