# frozen_string_literal: true

def twice(value)
  return enum_for(__method__, value) unless block_given?
  yield value
  yield value + 1
  :finished
end
events = []
raise unless twice(3) { |item| events << item } == :finished && events == [3, 4]
raise unless twice(3).to_a == [3, 4]
loose = proc { |a, b| [a, b] }
strict = ->(a, b) { [a, b] }
raise unless loose.call(1) == [1, nil] && loose.call(1, 2, 3) == [1, 2]
raise unless loose.call([1, 2]) == [1, 2]
begin
  strict.call([1, 2])
  raise 'lambda accepted wrong arity'
rescue ArgumentError
end
explicit = ->((a, b)) { [a, b] }
raise unless explicit.call([1, 2]) == [1, 2]
callable = Object.new
callable.define_singleton_method(:call) { |value| value * 2 }
raise unless callable.call(4) == 8
raise unless %w[ruby block].map(&:length) == [4, 5]
puts "yield=#{events.inspect} proc=#{loose.call([1, 2]).inspect} lambda_destructure=#{explicit.call([1, 2]).inspect}"
puts 'PASS 06'
