require 'bundler/setup'
require 'json'
require 'rack'
raise unless Gem.loaded_specs.fetch('json').version.to_s == '2.13.2'
raise unless Gem.loaded_specs.fetch('rack').version.to_s == '3.2.1'
begin
  gem 'json', '= 0.0.0'
rescue Gem::LoadError
else
  raise 'conflicting activation unexpectedly succeeded'
end
puts "PASS 21: Ruby=#{RUBY_VERSION}, Bundler=#{Bundler::VERSION}, json=#{JSON::VERSION}, rack=#{Rack.release}"
puts "platform=#{Gem::Platform.local}"
