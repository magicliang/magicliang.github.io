# frozen_string_literal: true

values = [nil, false, 0, '', [], {}]
truth = values.map { |value| value ? true : false }
raise unless truth == [false, false, true, true, true, true]
events = []
false && events << :and
true || events << :or
result = nil || :fallback
raise unless events.empty? && result == :fallback
value = true and false
other = true && false
raise unless value == true && other == false
selected = if false
  :yes
else
  :no
end
raise unless selected == :no
trace = []
matcher = Object.new
matcher.define_singleton_method(:===) { |item| trace << item; item == 4 }
answer = case 4
when matcher then :matched
else :missed
end
raise unless answer == :matched && trace == [4]
i = 0
normal = while i < 2
  i += 1
end
stopped = loop { break :finished }
raise unless normal.nil? && stopped == :finished
puts "truth=#{truth.inspect} assignment=#{[value, other].inspect} case=#{answer} loops=#{[normal, stopped].inspect}"
puts 'PASS 01'
