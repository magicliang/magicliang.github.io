# E05: package support matrix and artificial upgrade fixture

Run from examples/ruby with the main frozen bundle already installed:

```sh
PATH=/private/tmp/hexo-ruby-3.4/bin:$PATH BUNDLE_PATH=.bundle/vendor bundle install
PATH=/private/tmp/hexo-ruby-3.4/bin:$PATH BUNDLE_PATH=.bundle/vendor bundle exec ruby labs/E05/run.rb
```

The actual matrix is CRuby 3.4.11 and JRuby 10.0.5.0 (RUBY_VERSION 3.4.5). JRuby uses `/opt/homebrew/opt/openjdk@21/bin/java -jar /private/tmp/ruby-electives-jruby-10.0.5.0.jar`. Configure other paths with CRUBY_BIN, JAVA_BIN, JRUBY_JAR and JRUBY_GEMS. Both engines must actually execute. CRuby 3.4.10 bootstrap was killed with exit 137 and is NOT_RUN, not a passing matrix cell.

Install the JRuby-specific dependencies once, outside any bundle environment:

```sh
env -u BUNDLE_GEMFILE -u RUBYOPT -u RUBYLIB \
  GEM_HOME=/private/tmp/ruby-e05-jruby-gems GEM_PATH=/private/tmp/ruby-e05-jruby-gems \
  /opt/homebrew/opt/openjdk@21/bin/java -jar /private/tmp/ruby-electives-jruby-10.0.5.0.jar \
  -S gem install json:2.13.2 csv:3.3.5 net-http:0.6.0 rack:3.2.1 --no-document
```

JSON resolves to 2.13.2-java. JRuby does not reuse CRuby native extensions. The main frozen bundle is read-only; the runner does not install dependencies automatically.

Each cell builds and installs Taskbook into a temporary GEM_HOME, clears BUNDLE variables and RUBYOPT/RUBYLIB, runs installed API roundtrip/negative validation and installed CLI outside the checkout. Existing frozen dependencies are reused, so this does not prove clean-machine dependency bootstrap. Temporary installs are removed on exit.

Local fixtures v1/v2 deliberately demonstrate an API removal: count warns in 1.0.0 and fails in 2.0.0; total works in both. This is an artificial educational fixture, not a claim about any upstream gem. Both fixture packages are built and installed under both interpreters. No package publication occurs.

Artifacts: ../../evidence/E05/matrix.json, commands.json, run.txt. Only the actually recorded local platform/Java runtime is tested; Linux, Windows, x86_64 and TruffleRuby are not tested here.
