require 'open3'
require 'rbconfig'
require 'tmpdir'
out, err, status = Open3.capture3(RbConfig.ruby, '-Ilib', 'test/engineering_boundaries_test.rb')
print out, err
raise 'behavior suite failed' unless status.success?
Dir.mktmpdir('taskbook-mutation') do |dir|
  test = File.join(dir, 'mutant.rb')
  suite = File.expand_path('test/engineering_boundaries_test.rb')
  File.write(test, "require #{suite.dump}\nmodule Taskbook\n def self.summary(tasks)\n { total: 0, by_status: {todo: 0, done: 0} }\n end\nend\n")
  out, err, status = Open3.capture3(RbConfig.ruby, '-Ilib', test)
  raise 'negative control was not detected' unless status.exitstatus == 1 && out.include?('Failure:')
  puts out
end
puts 'PASS 23: behavior suite and deliberately failing negative control'
