require 'json'
$stdout.sync = true
stop = false
trap('TERM') { stop = true }
puts JSON.generate(event: 'ready')
until stop
  next unless IO.select([$stdin], nil, nil, 0.05)
  task = $stdin.gets
  break unless task
  puts JSON.generate(event: 'accepted', id: task.strip)
  sleep 0.15
  puts JSON.generate(event: 'finished', id: task.strip)
end
puts JSON.generate(event: 'stop_accepting')
puts JSON.generate(event: 'closed')
