require 'tmpdir'
require 'open3'
require 'rbconfig'
require 'fileutils'
require 'json'
require 'rubygems/package'
require 'digest'

root = File.expand_path('../..', __dir__)
evidence = File.join(root, 'evidence/E05')
FileUtils.mkdir_p(evidence)
rubies = [[ENV.fetch('CRUBY_BIN', '/private/tmp/hexo-ruby-3.4/bin/ruby')],
          [ENV.fetch('JAVA_BIN', '/opt/homebrew/opt/openjdk@21/bin/java'), '-jar',
           ENV.fetch('JRUBY_JAR', '/private/tmp/ruby-electives-jruby-10.0.5.0.jar')]]
raise 'need two executable runtimes' unless rubies.all? { |command| File.executable?(command.first) }
dependency_path = File.join(root, '.bundle/vendor/ruby/3.4.0')
raise 'main frozen dependencies missing' unless File.directory?(dependency_path)
clean = ENV.keys.grep(/\ABUNDLE/).to_h { |key| [key, nil] }
clean.merge!('RUBYOPT' => nil, 'RUBYLIB' => nil)
rows = []
log = []
run = lambda do |env, *command, **options|
  out, err, status = Open3.capture3(env, *command, **options)
  log << { command: command, stdout: out, stderr: err, exit: status.exitstatus }
  [out, err, status]
end

Dir.mktmpdir('taskbook-matrix') do |tmp|
  rubies.each_with_index do |ruby, index|
    isolated = File.join(tmp, "installed-#{index}")
    deps = index.zero? ? dependency_path : ENV.fetch('JRUBY_GEMS', '/private/tmp/ruby-e05-jruby-gems')
    env = clean.merge('GEM_HOME' => isolated, 'GEM_PATH' => [isolated, deps].join(File::PATH_SEPARATOR))
    metadata, error, status = run.call(env, *ruby, '-rjson', '-e', 'puts JSON.generate(engine: RUBY_ENGINE, ruby: RUBY_VERSION, description: RUBY_DESCRIPTION, platform: RUBY_PLATFORM)')
    raise error unless status.success?
    row = JSON.parse(metadata)
    package = File.join(tmp, "taskbook-#{index}.gem")
    out, err, status = run.call(env, *ruby, '-S', 'gem', 'build', 'taskbook.gemspec', '--output', package, chdir: root)
    raise "build: #{out}#{err}" unless status.success?
    files = Gem::Package.new(package).spec.files
    raise 'missing executable' unless files.include?('exe/taskbook')
    raise 'development file packaged' if files.any? { |path| path.start_with?('labs/', '.bundle/') }
    out, err, status = run.call(env, *ruby, '-S', 'gem', 'install', '--local', package, '--install-dir', isolated, '--ignore-dependencies', '--no-document')
    raise "install: #{out}#{err}" unless status.success?
    api = <<~'RUBY'
      require 'taskbook/io'
      require 'stringio'
      tasks = Taskbook.sample_tasks
      raise unless Taskbook.summary(tasks)[:total] == 3
      raise unless Taskbook::IO.read(StringIO.new(Taskbook::IO.dump(tasks))) == tasks
      begin
        Taskbook.filter(tasks, min_priority: 0)
        abort 'invalid option accepted'
      rescue ArgumentError
      end
      puts JSON.generate(installed_path: Gem.loaded_specs.fetch('taskbook-workshop').full_gem_path,
                         dependencies: Gem.loaded_specs.transform_values { |spec| { version: spec.version.to_s, platform: spec.platform.to_s } })
    RUBY
    out, err, status = run.call(env, *ruby, '-e', api, chdir: tmp)
    raise "API: #{out}#{err}" unless status.success? && out.include?(isolated)
    row['dependencies'] = JSON.parse(out).fetch('dependencies')
    out, err, status = run.call(env, *ruby, File.join(isolated, 'bin/taskbook'), 'stats', stdin_data: '[]', chdir: tmp)
    raise "CLI: #{out}#{err}" unless status.success? && JSON.parse(out)['total'] == 0
    row.merge!('package_api_cli' => 'PASS', 'package_sha256' => Digest::SHA256.file(package).hexdigest)
    row['fixture'] = []
    %w[v1 v2].each do |version|
      fixture = File.join(tmp, "fixture-#{index}-#{version}.gem")
      out, err, status = run.call(env, *ruby, '-S', 'gem', 'build', 'policy.gemspec', '--output', fixture, chdir: File.join(__dir__, 'fixtures', version))
      raise "fixture build: #{out}#{err}" unless status.success?
      out, err, status = run.call(env, *ruby, '-S', 'gem', 'install', '--local', fixture, '--install-dir', isolated, '--no-document')
      raise "fixture install: #{out}#{err}" unless status.success?
      gem_version = version == 'v1' ? '1.0.0' : '2.0.0'
      preamble = "gem 'taskbook-policy-fixture', '#{gem_version}'; require 'taskbook_policy_fixture'; "
      out, err, status = run.call(env, *ruby, '-e', preamble + 'raise unless TaskbookPolicyFixture.total([1,2]) == 2; puts "new API PASS"', chdir: tmp)
      raise 'new API regression' unless status.success? && err.empty?
      out, err, status = run.call(env, *ruby, '-e', preamble + 'puts TaskbookPolicyFixture.count([1,2])', chdir: tmp)
      if version == 'v1'
        raise 'deprecation missing' unless status.success? && out.strip == '2' && err.include?('DEPRECATED')
      else
        raise 'removed API silently survived' unless !status.success? && err.include?('NoMethodError')
      end
      row['fixture'] << { version: gem_version, new_api: 'PASS', old_api_exit: status.exitstatus,
                         old_api_stderr: err, artificial_fixture: true }
    end
    rows << row
  end
end
raise 'same engine accidentally tested twice' unless rows.map { |row| row['engine'] }.uniq.size == 2
File.write(File.join(evidence, 'commands.json'), JSON.pretty_generate(log))
File.write(File.join(evidence, 'matrix.json'), JSON.pretty_generate(tested: rows, untested: ['Linux', 'Windows', 'x86_64', 'CRuby 3.4.10: bootstrap killed, exit 137', 'TruffleRuby'], dependencies: 'CRuby frozen bundle and separate JRuby Java gems reused; not clean-machine bootstrap'))
puts JSON.pretty_generate(rows)
puts 'PASS E05 CRuby and JRuby installed package/API/CLI, fixture upgrade and deprecation'
