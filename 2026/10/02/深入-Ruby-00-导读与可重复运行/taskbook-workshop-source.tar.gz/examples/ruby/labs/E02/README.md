# E02: shared protocol and generated inputs

Ruby 3.4.11; RSpec aggregate 3.13.2 and Minitest 5.25.5. Exact component versions are in Gemfile.lock.

```sh
env -u BUNDLE_GEMFILE -u RUBYOPT -u RUBYLIB BUNDLE_PATH=.bundle/vendor bundle install
BUNDLE_PATH=.bundle/vendor bundle exec ruby run.rb
SEED=20261002 BUNDLE_PATH=.bundle/vendor bundle exec ruby run.rb
```

Run installation from this directory with Ruby 3.4.11 first on PATH. From examples/ruby, `bundle exec ruby labs/E02/run.rb` re-executes with this independent Gemfile after clearing BUNDLE variables, RUBYOPT/RUBYLIB. It never installs automatically. Do not commit or package .bundle.

Both frameworks execute three real Taskbook protocol cases. Each also runs an isolated boundary mutant and must exit 1. Generated input testing checks 100 valid arrays and preserves data seed, original counterexample, accepted deletion steps and a canonical boundary input in ../../evidence/E02/generated.json. This is a custom domain-specific shrinker: deletion minimality of this counterexample is tested; general/global minimization is not claimed. Framework ordering seed and generated-data seed are distinct.
