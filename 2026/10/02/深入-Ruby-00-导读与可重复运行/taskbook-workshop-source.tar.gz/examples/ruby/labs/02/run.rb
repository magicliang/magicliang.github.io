# frozen_string_literal: true

require 'bigdecimal'
raise unless 7 / 3 == 2 && -7 / 3 == -3
raise unless -7 == (-7 / 3) * 3 + (-7 % 3)
raise unless (10**100 + 1) - 10**100 == 1
raise if 0.1 + 0.2 == 0.3
raise unless Rational('0.1') + Rational('0.2') == Rational(3, 10)
raise unless BigDecimal('0.1') + BigDecimal('0.2') == BigDecimal('0.3')
raise if Rational(0.1) == Rational('0.1')
raise unless 2.5.round(half: :even) == 2 && 3.5.round(half: :even) == 4
raise unless 2.5.round(half: :up) == 3 && (-2.5).round(half: :up) == -3
raise unless '17oops'.to_i == 17 && 'oops'.to_i == 0
%w[17oops oops].each do |input|
  begin
    Integer(input, 10)
    raise 'invalid number accepted'
  rescue ArgumentError
  end
end
raise unless Integer('017', 10) == 17
puts "division=#{[7 / 3, -7 / 3].inspect} float=#{0.1 + 0.2} rational=#{Rational('0.1') + Rational('0.2')}"
puts "bigdecimal=#{BigDecimal::VERSION} decimal=#{(BigDecimal('0.1') + BigDecimal('0.2')).to_s('F')}"
puts 'PASS 02'
