Gem::Specification.new do |spec|
  spec.name = 'taskbook-workshop'
  spec.version = '0.1.0'
  spec.summary = 'Local synthetic-task examples for the Ruby workshop'
  spec.authors = ['Ruby workshop']
  spec.license = 'MIT'
  spec.required_ruby_version = '>= 3.4', '< 3.5'
  spec.files = Dir['lib/**/*.rb', 'exe/*', 'sig/**/*.rbs']
  spec.bindir = 'exe'
  spec.executables = ['taskbook']
  spec.require_paths = ['lib']
  spec.add_dependency 'json', '= 2.13.2'
  spec.add_dependency 'csv', '= 3.3.5'
  spec.add_dependency 'net-http', '= 0.6.0'
  spec.add_dependency 'rack', '= 3.2.1'
end
