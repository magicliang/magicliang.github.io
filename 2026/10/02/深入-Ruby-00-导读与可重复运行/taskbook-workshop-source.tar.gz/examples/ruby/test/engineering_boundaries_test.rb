require 'minitest/autorun'
require 'taskbook/io'
require 'taskbook/http'
require 'stringio'
require 'open3'
require 'rbconfig'
require 'tmpdir'
require 'rack/mock'
require 'rack/lint'

class EngineeringBoundariesTest < Minitest::Test
  def sample
    [{ id: 1, title: 'read Ruby', priority: 3, tags: ['ruby'], status: :todo }]
  end

  def test_json_and_csv_round_trip
    %w[json csv].each do |format|
      assert_equal sample, Taskbook::IO.read(StringIO.new(Taskbook::IO.dump(sample, format: format)), format: format)
    end
  end

  def test_input_validation
    ['{}', '[', "\xFF".b, ' ' * 65_537,
     '[{"id":1,"title":"x","priority":3,"tags":[],"status":"other"}]',
     '[{"id":1,"title":"x","priority":"3","tags":[],"status":"todo"}]',
     '[{"id":1,"title":"x","priority":3,"tags":[],"status":"todo","extra":true}]'].each do |input|
      assert_raises(ArgumentError) { Taskbook::IO.read(StringIO.new(input)) }
    end
    assert_raises(ArgumentError) { Taskbook::IO.read(StringIO.new("bad,headers\n1,2\n"), format: 'csv') }
    assert_raises(ArgumentError) { Taskbook::IO.read(StringIO.new('[{"id":1}]')) }
  end

  def cli(*args, input: Taskbook::IO.dump(sample))
    Open3.capture3(RbConfig.ruby, '-Ilib', 'exe/taskbook', *args, stdin_data: input)
  end

  def test_cli_contract
    out, err, status = cli('--help', input: '')
    assert status.success?
    assert_includes out, 'Usage:'
    assert_empty err
    out, err, status = cli('filter', '--tag', 'ruby')
    assert status.success?
    assert_equal 1, JSON.parse(out).length
    assert_empty err
    out, err, status = cli('stats')
    assert status.success?
    assert_equal 1, JSON.parse(out)['total']
    assert_empty err
    out, err, status = cli('--invalid')
    assert_equal 2, status.exitstatus
    assert_empty out
    refute_empty err
    out, err, status = cli('filter', input: '[')
    assert_equal 2, status.exitstatus
    assert_empty out
    refute_empty err
    Dir.mktmpdir do |dir|
      path = File.join(dir, 'output.json')
      _, _, first = cli('export', '--output', path)
      assert first.success?
      original = File.binread(path)
      _, _, second = cli('export', '--output', path)
      assert_equal 3, second.exitstatus
      assert_equal original, File.binread(path)
    end
  end

  def test_rack_contract
    request = Rack::MockRequest.new(Rack::Lint.new(Taskbook::HTTPApp.new))
    result = request.post('/tasks', 'CONTENT_TYPE' => 'application/json', input: Taskbook::IO.dump(sample))
    assert_equal 200, result.status
    assert_equal 1, JSON.parse(result.body)['total']
    assert_equal 404, request.get('/missing').status
    assert_equal 405, request.get('/tasks').status
    assert_equal 415, request.post('/tasks', input: '[]').status
    assert_equal 400, request.post('/tasks', 'CONTENT_TYPE' => 'application/json', input: '[').status
  end

  def test_alias_boundary
    source = sample
    copy = Taskbook.validate(source)
    source[0][:tags] << 'later'
    assert_equal ['ruby'], copy[0][:tags]
    assert_raises(ArgumentError) { Taskbook.validate(source + source) }
  end
end
