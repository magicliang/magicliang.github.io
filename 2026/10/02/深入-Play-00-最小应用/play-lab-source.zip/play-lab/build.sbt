ThisBuild / scalaVersion := "2.13.15"
ThisBuild / organization := "example.playlab"
ThisBuild / version := "0.1.0"

lazy val inventoryCore = (project in file("inventory-core"))
  .settings(name := "inventory-core")

lazy val root = (project in file("."))
  .enablePlugins(PlayJava)
  .dependsOn(inventoryCore)
  .settings(
    name := "play-lab",
    libraryDependencies ++= Seq(guice, javaWs, caffeine, javaJdbc, evolutions,
      "org.postgresql" % "postgresql" % "42.7.5",
      "junit" % "junit" % "4.13.2" % Test,
      "com.github.sbt" % "junit-interface" % "0.13.3" % Test),
    Test / parallelExecution := false
  )
