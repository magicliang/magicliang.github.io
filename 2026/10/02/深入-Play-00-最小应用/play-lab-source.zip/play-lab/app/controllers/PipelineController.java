package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.atomic.AtomicInteger;
import javax.inject.Inject;
import javax.inject.Singleton;
import lab.AuditAction;
import lab.AuthorizationAction;
import lab.CountingJsonParser;
import lab.TraceLog;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;
import play.mvc.With;

@Singleton
public final class PipelineController extends Controller {
    private final TraceLog trace;
    private final AtomicInteger businessCalls = new AtomicInteger();

    @Inject
    public PipelineController(TraceLog trace) {
        this.trace = trace;
    }

    @With({AuditAction.class, AuthorizationAction.class})
    @BodyParser.Of(CountingJsonParser.class)
    public CompletionStage<Result> json(Http.Request request, String mode) {
        recordBusiness(request);
        if (mode.equals("sync")) throw new IllegalStateException("pipeline-sync-failure");
        if (mode.equals("async")) {
            return CompletableFuture.failedFuture(new IllegalStateException("pipeline-async-failure"));
        }
        return CompletableFuture.completedFuture(ok(Json.newObject()
                .put("kind", "json").<JsonNode>set("body", request.body().asJson())));
    }

    @BodyParser.Of(BodyParser.Text.class)
    public Result text(Http.Request request) {
        recordBusiness(request);
        return ok(Json.newObject().put("kind", "text").put("body", request.body().asText()));
    }

    public Result any(Http.Request request) {
        recordBusiness(request);
        String kind = request.body().asJson() != null ? "json"
                : request.body().asText() != null ? "text" : request.body().asBytes().isEmpty() ? "empty" : "raw";
        return ok(Json.newObject().put("kind", kind));
    }

    private void recordBusiness(Http.Request request) {
        businessCalls.incrementAndGet();
        trace.add(request.headers().get("X-Pipeline-Id").orElse("anonymous"), "business");
    }

    public Result stats(String id) {
        List<String> events = trace.events(id);
        String bytesPrefix = id + ":parser-bytes-";
        return ok(Json.newObject().put("businessCalls", businessCalls.get())
                .put("requestBusinessCalls", events.stream().filter(e -> e.equals(id + ":business")).count())
                .put("parserCalls", events.stream().filter(e -> e.equals(id + ":parser-apply")).count())
                .put("parserBytes", events.stream().filter(e -> e.startsWith(bytesPrefix))
                        .mapToLong(e -> Long.parseLong(e.substring(bytesPrefix.length()))).sum())
                .<JsonNode>set("events", Json.toJson(events)));
    }
}
