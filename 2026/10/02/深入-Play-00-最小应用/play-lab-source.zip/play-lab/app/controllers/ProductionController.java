package controllers;
import jakarta.inject.Inject;
import java.util.concurrent.CompletionStage;
import production.ProductionProbe;
import play.mvc.Controller;
import play.mvc.Result;
public final class ProductionController extends Controller {
    private final ProductionProbe probe;
    @Inject public ProductionController(ProductionProbe probe) { this.probe = probe; }
    public Result health() { return ok("process-alive"); }
    public Result state() { return ok(probe.state()); }
    public CompletionStage<Result> ready() { return probe.ready().thenApply(s -> status(s.path("ready").asBoolean() ? 200 : 503, s)); }
    public Result drain() { probe.drain(); return ok(probe.state()); }
    public CompletionStage<Result> work(String id, int millis) {
        return probe.work(id, millis).handle((body, error) -> error == null ? ok(body) : status(503, "work-rejected-or-failed"));
    }
    public Result stream(int chunks) { return ok().chunked(probe.stream(chunks)).as("application/octet-stream"); }
}
