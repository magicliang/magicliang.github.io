package controllers;
import authlab.ObjectPolicy;
import observabilitylab.*;
import com.typesafe.config.Config;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import javax.inject.Inject;
import org.apache.pekko.actor.ActorSystem;
import org.apache.pekko.stream.javadsl.*;
import org.apache.pekko.util.ByteString;
import play.libs.*;
import play.mvc.*;
import play.filters.csrf.*;
public final class GovernanceController extends Controller {
    private final Semaphore workSlots = new Semaphore(16);
    private final ObjectPolicy policy; private final RequestEvents events; private final boolean fixture; private final ActorSystem system;
    @Inject public GovernanceController(ObjectPolicy policy, RequestEvents events, Config config, ActorSystem system) {
        this.policy=policy;this.events=events;this.system=system;
        fixture=config.hasPath("governance.fixtureLoginEnabled") && config.getBoolean("governance.fixtureLoginEnabled");
    }
    @AddCSRFToken public Result form(Http.Request request) {
        return ok(Json.newObject().put("csrfToken",CSRF.getToken(request).orElseThrow().value()));
    }
    public Result login(Http.Request request, String user) {
        if(!fixture) return notFound("fixture disabled");
        if(!Set.of("alice","bob").contains(user)) return badRequest();
        return ok("PUBLIC SYNTHETIC TEST FIXTURE").addingToSession(request,"username",user);
    }
    @Security.Authenticated public Result list(Http.Request request) {
        var result=Json.newArray(); String user=request.attrs().get(Security.USERNAME);
        for(int id=1;id<=2;id++) if(policy.allowed(user,id)) result.add(id);
        return ok(result);
    }
    @Security.Authenticated public Result detail(Http.Request request,int id) {
        return policy.allowed(request.attrs().get(Security.USERNAME),id)?ok("object-"+id):forbidden();
    }
    @Security.Authenticated public Result update(Http.Request request,int id) {
        return policy.update(request.attrs().get(Security.USERNAME),id)?ok(policy.snapshot()):forbidden();
    }
    @Security.Authenticated public Result revoke(Http.Request request) {
        policy.revoke(request.attrs().get(Security.USERNAME)); return ok(policy.snapshot());
    }
    public Result policyState() { return fixture?ok(policy.snapshot()):notFound(); }
    @Security.Authenticated public Result events(Http.Request request,int id,String track) {
        String user=request.attrs().get(Security.USERNAME);
        if(!track.matches("[a-zA-Z0-9_-]{1,48}"))return badRequest();
        if(!policy.allowed(user,id))return forbidden();
        var source=Source.range(1,20).throttle(1,Duration.ofMillis(150)).map(n->{
            if(!policy.allowed(user,id)) throw new SecurityException("authorization revoked");
            return EventSource.Event.event("object-"+id+":"+n).withId(""+n);
        }).via(EventSource.flow()).takeWithin(Duration.ofSeconds(5)).watchTermination((m,d)->{
            d.whenComplete((v,e)->events.event(track,"subscription_terminal",e==null?"completed_or_cancelled":"revoked_or_failed")); return m;
        });
        return ok().chunked(source).as("text/event-stream");
    }
    public WebSocket socket(int id,String track) {
        return WebSocket.Text.acceptOrResult(request->{
            String user=request.session().get("username").orElse("");
            if(!track.matches("[a-zA-Z0-9_-]{1,48}"))return CompletableFuture.completedFuture(F.Either.Left(badRequest()));
            if(user.isEmpty())return CompletableFuture.completedFuture(F.Either.Left(unauthorized()));
            if(!request.header("Origin").orElse("").equals("http://trusted.example") || !policy.allowed(user,id))
                return CompletableFuture.completedFuture(F.Either.Left(forbidden()));
            var flow=org.apache.pekko.stream.javadsl.Flow.of(String.class).take(20).map(message->{
                if(!policy.allowed(user,id))throw new SecurityException("authorization revoked");
                if(message.length()>4096)throw new IllegalArgumentException("message too long");
                return "object-"+id+":"+message;
            }).completionTimeout(Duration.ofSeconds(5)).watchTermination((m,d)->{
                d.whenComplete((v,e)->events.event(track,"subscription_terminal",e==null?"completed_or_cancelled":"revoked_or_failed"));return m;
            });
            return CompletableFuture.completedFuture(F.Either.Right(flow));
        });
    }
    public Result connection(Http.Request request) {
        return ok(Json.newObject().put("remote",request.remoteAddress()).put("secure",request.secure()));
    }
    public Result snapshot() {return ok(events.snapshot().put("workSlotsAvailable",workSlots.availablePermits()));}
    @BodyParser.Of(BodyParser.Json.class) public Result decision(Http.Request request) {
        var json=request.body().asJson();
        boolean accepted=json!=null && json.has("amount") && json.get("amount").isIntegralNumber()
            && json.get("amount").canConvertToInt() && ObjectPolicy.amountAllowed(json.get("amount").intValue());
        events.event(request.attrs().get(GovernanceKeys.ID),"business_result",accepted?"accepted":"rejected");
        return status(accepted?200:400,Json.newObject().put("accepted",accepted));
    }
    public CompletionStage<Result> timeout(Http.Request request) {
        String id=request.attrs().get(GovernanceKeys.ID);
        if(!workSlots.tryAcquire()) { events.event(id,"business_result","capacity_rejected"); return CompletableFuture.completedFuture(status(503,"capacity")); }
        CompletableFuture<Result> result=new CompletableFuture<>();
        system.scheduler().scheduleOnce(Duration.ofMillis(50),()->result.complete(status(504,"deadline")),system.dispatcher());
        system.scheduler().scheduleOnce(Duration.ofMillis(500),()->{try {events.event(id,"business_result","completed_after_deadline");} finally {workSlots.release();}},system.dispatcher());
        return result;
    }
    public Result stream(Http.Request request) {
        String id=request.attrs().get(GovernanceKeys.ID);
        events.event(id,"business_result","accepted");
        var bytes=Source.range(1,2048).map(n->{events.produced(id,16384);return ByteString.fromArray(new byte[16384]);});
        return ok().chunked(bytes).as("application/octet-stream");
    }
}
