package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.typesafe.config.Config;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import javax.inject.Inject;
import lab.TraceLog;
import org.apache.pekko.stream.javadsl.Source;
import org.apache.pekko.util.ByteString;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;
import services.InventoryService;

public final class LabController extends Controller {
    private final InventoryService inventory;
    private final TraceLog trace;
    private final Config config;

    @Inject
    public LabController(InventoryService inventory, TraceLog trace, Config config) {
        this.inventory = inventory;
        this.trace = trace;
        this.config = config;
    }

    public Result health() {
        return ok("play-lab-ok");
    }

    public Result trace(String id) {
        return ok(Json.toJson(trace.events(id)));
    }

    public Result order(long id, boolean verbose) {
        return ok(Json.newObject().put("id", id).put("verbose", verbose).put("stock", inventory.stock(id)));
    }

    public Result reverse(long id) {
        return ok(controllers.routes.LabController.order(id, false).url());
    }

    @BodyParser.Of(BodyParser.Json.class)
    public Result create(Http.Request request) {
        String id = request.headers().get("X-Lab-Id").orElse("anonymous");
        trace.add(id, "controller");
        JsonNode body = request.body().asJson();
        return created(body);
    }

    public Result fail() {
        throw new IllegalStateException("synthetic-sync-failure");
    }

    public CompletionStage<Result> asyncFail() {
        return CompletableFuture.failedFuture(new IllegalStateException("synthetic-async-failure"));
    }

    public Result setSession(Http.Request request, String name) {
        return ok("set").addingToSession(request, "name", name);
    }

    public Result readSession(Http.Request request) {
        return ok(request.session().get("name").orElse("absent"));
    }

    public Result setFlash(Http.Request request) {
        return redirect("/flash/read").flashing("notice", "saved");
    }

    public Result readFlash(Http.Request request) {
        return ok(request.flash().get("notice").orElse("absent"));
    }

    public Result shape(String kind) {
        return switch (kind) {
            case "text" -> ok("hello").as("text/plain; charset=utf-8");
            case "empty" -> noContent();
            default -> status(422, "unknown shape");
        };
    }

    public Result scope() {
        return ok(Json.newObject().put("controller", System.identityHashCode(this))
                .put("service", System.identityHashCode(inventory)));
    }

    public Result config() {
        return ok(Integer.toString(config.getInt("lab.stock")));
    }

    public Result template(String name) {
        return ok(views.html.greeting.render(name));
    }

    public Result stream() {
        Source<ByteString, ?> body = Source.from(List.of(ByteString.fromString("one\n"),
                ByteString.fromString("two\n"), ByteString.fromString("three\n")))
                .throttle(1, Duration.ofMillis(150));
        return ok().chunked(body).as("text/plain");
    }
}
