package controllers;

import java.nio.file.*;
import java.io.IOException;
import java.util.*;
import play.libs.Json;
import play.mvc.*;
import streamlab.*;

public final class FileLabController extends Controller {
    @BodyParser.Of(UploadLabParser.class)
    public Result upload(Http.Request request) throws IOException {
        Http.MultipartFormData<Path> data = request.body().asMultipartFormData();
        var parts = data.getFiles();
        try {
            if (parts.size() != 1) return badRequest("exactly one file required");
            var part = parts.get(0); String name = part.getFilename();
            if (!name.matches("[A-Za-z0-9][A-Za-z0-9._-]{0,63}") || name.contains("..")) return badRequest("invalid filename");
            if (part.getFileSize() == 0) return badRequest("empty file");
            Files.createDirectories(UploadLabParser.ROOT.resolve("saved"));
            String stored = UUID.randomUUID().toString();
            Path dest = UploadLabParser.ROOT.resolve("saved").resolve(stored);
            Files.move(part.getRef(), dest);
            return ok(Json.newObject().put("stored", stored).put("original", name).put("bytes", part.getFileSize()).put("contentType", "application/octet-stream"));
        } finally { for (var part : parts) UploadLabParser.remove(part.getRef()); }
    }
    public Result snapshot() throws IOException {
        var out = Json.newObject();
        for (String kind : List.of("tmp", "saved")) {
            var array = out.putArray(kind); Path dir = UploadLabParser.ROOT.resolve(kind);
            if (Files.exists(dir)) try (var paths = Files.list(dir)) { paths.sorted().forEach(p -> array.add(p.getFileName().toString())); }
        }
        return ok(out);
    }
    public Result delete(String id) throws IOException {
        if (!id.matches("[a-f0-9-]{36}")) return badRequest();
        Files.deleteIfExists(UploadLabParser.ROOT.resolve("saved").resolve(id)); return noContent();
    }
    public Result download(String id) throws IOException {
        final StreamLedger.Entry e;
        try { e = StreamLedger.open(id); } catch (RuntimeException ex) { return badRequest(ex.getMessage()); }
        Files.createDirectories(UploadLabParser.ROOT.resolve("tmp"));
        Path file = Files.createTempFile(UploadLabParser.ROOT.resolve("tmp"), "download-", ".bin");
        try (var out = Files.newOutputStream(file)) { byte[] bytes = new byte[16384]; for (int n = 0; n < 2048; n++) out.write(bytes); }
        e.materialized = true;
        return ok().sendPath(file, false, Optional.of("export.bin"), () -> {
            try { UploadLabParser.remove(file); e.close(null); } catch (RuntimeException ex) { e.close(ex); throw ex; }
        }, Runnable::run).as("application/octet-stream");
    }
}
