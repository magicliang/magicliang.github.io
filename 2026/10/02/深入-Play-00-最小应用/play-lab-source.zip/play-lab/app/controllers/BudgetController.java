package controllers;

import jakarta.inject.Inject;
import java.util.concurrent.*;
import java.util.function.Supplier;
import com.fasterxml.jackson.databind.node.ObjectNode;
import labbudget.CacheLab;
import labbudget.TimeoutLab;
import labbudget.WsLab;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;

public final class BudgetController extends Controller {
    private final TimeoutLab timeouts;
    private final WsLab ws;
    private final CacheLab cache;
    @Inject public BudgetController(TimeoutLab timeouts, WsLab ws, CacheLab cache) {
        this.timeouts = timeouts; this.ws = ws; this.cache = cache;
    }
    public CompletionStage<Result> timeout() { return experiment(timeouts::run); }
    public CompletionStage<Result> ws() { return experiment(ws::run); }
    public CompletionStage<Result> cache() { return experiment(cache::run); }

    // Laboratory-only resource allocation; production pools belong to application lifecycle.
    private CompletionStage<Result> experiment(Supplier<ObjectNode> work) {
        ExecutorService coordinator = Executors.newSingleThreadExecutor(Thread.ofPlatform().name("lab-budget-coordinator").factory());
        return CompletableFuture.supplyAsync(work, coordinator).handle((value, error) -> {
            coordinator.shutdown();
            return error == null ? ok(value) : internalServerError(Json.newObject().put("code", "LAB_FAILURE"));
        });
    }
}
