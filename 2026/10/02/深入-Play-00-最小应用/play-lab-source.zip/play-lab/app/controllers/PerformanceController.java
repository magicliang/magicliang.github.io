package controllers;

import jakarta.inject.Inject;
import java.util.concurrent.CompletionStage;
import labperf.PerformanceLab;
import labperf.PayloadLab;
import play.mvc.Controller;
import play.mvc.Result;

public final class PerformanceController extends Controller {
    private final PerformanceLab lab;
    private final PayloadLab payload;
    @Inject public PerformanceController(PerformanceLab lab, PayloadLab payload) { this.lab = lab; this.payload = payload; }
    public Result configuration() { return ok(lab.configuration()); }
    public Result begin(String run, String mode, int count) { return ok(lab.begin(run, mode, count)); }
    public CompletionStage<Result> task(String run, int id) { return lab.submit(run, id).thenApply(body -> status(body.path("status").asInt(), body)); }
    public Result state() { return ok(lab.snapshot()); }
    public Result progress() { return ok(lab.progress()); }
    public Result committed() { return ok(lab.committed()); }
    public Result acknowledge(String run, int id) { return ok(lab.acknowledge(run, id)); }
    public Result payloadBegin(String run, String mode, int count) { return ok(payload.begin(run, mode, count)); }
    public Result aggregate(String run, int id) { return ok(payload.aggregate(run, id)).as("application/octet-stream"); }
    public Result stream(String run, int id) { return ok().chunked(payload.stream(run, id)).as("application/octet-stream"); }
    public CompletionStage<Result> value(String run, int id) { return payload.value(run, id).thenApply(body -> ok(body)); }
    public CompletionStage<Result> warm(String run, int key) { return payload.warm(run, key).thenApply(body -> ok(body)); }
    public Result payloadState() { return ok(payload.snapshot()); }
}
