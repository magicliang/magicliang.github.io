package controllers;

import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.inject.Inject;
import java.util.concurrent.*;
import java.util.function.Supplier;
import labasync.CompositionLab;
import labasync.ContextLab;
import labasync.ExecutorLab;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;

public final class AsyncController extends Controller {
    private final ExecutorLab executors;
    @Inject public AsyncController(ExecutorLab executors) { this.executors = executors; }

    public CompletionStage<Result> composition() { return experiment(() -> ok(CompositionLab.composition())); }
    public CompletionStage<Result> execution() { return experiment(() -> ok(CompositionLab.execution())); }
    public CompletionStage<Result> placement() { return experiment(() -> ok(executors.placement())); }
    public CompletionStage<Result> pekko() { return experiment(() -> ok(executors.pekko())); }
    public CompletionStage<Result> abort() {
        return experiment(() -> {
            ObjectNode evidence = executors.abort();
            return status(evidence.path("fourthStatus").asInt(), evidence);
        });
    }
    public CompletionStage<Result> context(Http.Request request) { return experiment(() -> ok(ContextLab.run(request))); }
    public CompletionStage<Result> result(String mode) {
        if (!java.util.Set.of("ok", "sync", "failed").contains(mode))
            return CompletableFuture.completedFuture(badRequest(Json.newObject().put("code", "UNKNOWN_MODE")));
        return CompositionLab.result(mode);
    }

    // Bounded synthetic demonstrations only: a fresh coordinator avoids blocking the HTTP dispatcher.
    // Production code should inject lifecycle-managed pools instead of making pools per request.
    private CompletionStage<Result> experiment(Supplier<Result> work) {
        ExecutorService coordinator = Executors.newSingleThreadExecutor(Thread.ofPlatform().name("lab-coordinator").factory());
        return CompletableFuture.supplyAsync(work, coordinator).handle((result, error) -> {
            coordinator.shutdown();
            return error == null ? result : internalServerError(Json.newObject().put("code", "LAB_FAILURE"));
        });
    }
}
