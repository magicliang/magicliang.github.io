package controllers;

import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import org.apache.pekko.stream.*;
import org.apache.pekko.stream.javadsl.Flow;
import play.libs.F;
import play.mvc.*;
import streamlab.StreamLedger;

public final class WebSocketLabController extends Controller {
    public WebSocket socket(String id) {
        return WebSocket.Text.acceptOrResult(request -> {
            if (!"synthetic-token".equals(request.getQueryString("token")))
                return CompletableFuture.completedFuture(F.Either.Left(unauthorized("token")));
            if (!request.header("Origin").orElse("").equals("http://localhost:19018"))
                return CompletableFuture.completedFuture(F.Either.Left(forbidden("origin")));
            final StreamLedger.Entry e;
            try { e = StreamLedger.open(id); } catch (RuntimeException ex) { return CompletableFuture.completedFuture(F.Either.Left(badRequest(ex.getMessage()))); }
            Flow<String, String, ?> flow = Flow.of(String.class).take(20).map(text -> {
                if (text.length() > 4096) throw new IllegalArgumentException("application message limit 4096 chars");
                e.produced(text.length()); return "echo:" + text;
            }).buffer(4, OverflowStrategy.fail()).withAttributes(Attributes.inputBuffer(1, 1))
                .completionTimeout(Duration.ofSeconds(10)).watchTermination((mat, done) -> {
                    e.materialized = true; done.whenComplete((value, error) -> e.close(error)); return mat;
                });
            return CompletableFuture.completedFuture(F.Either.Right(flow));
        });
    }
}
