package controllers;

import java.util.Optional;
import org.apache.pekko.stream.Attributes;
import org.apache.pekko.stream.javadsl.Source;
import org.apache.pekko.util.ByteString;
import play.http.HttpEntity;
import play.mvc.*;
import streamlab.StreamLedger;

public final class StreamLabController extends Controller {
    private final org.apache.pekko.actor.ActorSystem system;
    @javax.inject.Inject public StreamLabController(org.apache.pekko.actor.ActorSystem system) { this.system = system; }
    public java.util.concurrent.CompletionStage<Result> work(String id) {
        final StreamLedger.Entry e;
        try { e = StreamLedger.open(id); }
        catch (RuntimeException ex) { return java.util.concurrent.CompletableFuture.completedFuture(badRequest(ex.getMessage())); }
        var result = new java.util.concurrent.CompletableFuture<Result>();
        e.workStage = "scheduled";
        result.whenComplete((value, error) -> { e.futureCancelled = result.isCancelled(); e.close(error); });
        system.scheduler().scheduleOnce(java.time.Duration.ofMillis(750), () -> {
            e.workStage = "running"; e.produced(1); e.workStage = "completed";
            result.complete(ok(e.json()));
        }, system.dispatcher());
        return result;
    }

    public Result data(String id, int chunks, boolean known, int failAt) {
        if (chunks < 1 || chunks > 2048 || failAt < -1) return badRequest("bounded chunks: 1..2048");
        final StreamLedger.Entry e;
        try { e = StreamLedger.open(id); } catch (RuntimeException ex) { return badRequest(ex.getMessage()); }
        var source = Source.range(0, chunks - 1).map(index -> {
            if (index == failAt) throw new IllegalStateException("synthetic upstream failure");
            byte[] block = new byte[16384]; java.util.Arrays.fill(block, (byte) ('a' + index % 26));
            e.produced(block.length); return ByteString.fromArray(block);
        }).withAttributes(Attributes.inputBuffer(1, 1)).watchTermination((mat, done) -> {
            e.materialized = true; done.whenComplete((value, error) -> e.close(error)); return mat;
        });
        return ok().sendEntity(new HttpEntity.Streamed(source, known ? Optional.of(chunks * 16384L) : Optional.empty(), Optional.of("application/octet-stream")));
    }
    public Result state(String id) {
        var e = StreamLedger.get(id); return e == null ? notFound() : ok(e.json());
    }
}
