package controllers;

import java.time.Duration;
import java.util.*;
import org.apache.pekko.stream.javadsl.Source;
import org.apache.pekko.util.ByteString;
import play.libs.EventSource;
import play.mvc.*;
import streamlab.StreamLedger;

public final class SseLabController extends Controller {
    // Fixed synthetic retained log: IDs 101..120. Cursor 100 starts at its oldest item.
    private static final List<EventSource.Event> EVENTS = java.util.stream.IntStream.rangeClosed(101, 120)
        .mapToObj(i -> EventSource.Event.event("line-one-" + i + "\nline-two-" + i).withId("" + i).withName("sample")).toList();
    public Result events(Http.Request request, String id) {
        int cursor;
        try { cursor = Integer.parseInt(request.header("Last-Event-ID").orElse("100")); }
        catch (NumberFormatException ex) { return badRequest("invalid cursor"); }
        if (cursor < 100) return status(410, "cursor expired; retained IDs 101..120");
        if (cursor > 120) return badRequest("future cursor");
        if (cursor == 120) return noContent();
        final StreamLedger.Entry e;
        try { e = StreamLedger.open(id); } catch (RuntimeException ex) { return badRequest(ex.getMessage()); }
        var data = Source.from(EVENTS.subList(cursor - 100, 20)).throttle(1, Duration.ofMillis(450))
            .zipWithIndex().map(pair -> {
                if ("fail".equals(request.getQueryString("mode")) && pair.second() == 3L)
                    throw new IllegalStateException("synthetic SSE upstream failure");
                return pair.first();
            })
            .via(EventSource.flow()).intersperse(ByteString.fromString(": heartbeat\n\n"))
            .takeWithin(Duration.ofSeconds(10)).map(bytes -> { e.produced(bytes.size()); return bytes; })
            .watchTermination((mat, done) -> { e.materialized = true; done.whenComplete((v, err) -> e.close(err)); return mat; });
        return ok().chunked(data).as("text/event-stream").withHeader("Cache-Control", "no-cache");
    }
}
