package controllers;
import capstone.*;
import com.fasterxml.jackson.databind.*;
import com.typesafe.config.Config;
import jakarta.inject.Inject;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Supplier;
import org.apache.pekko.stream.javadsl.Source;
import play.libs.*;
import play.mvc.*;
import play.filters.csrf.*;
public final class CapstoneController extends Controller {
    private final CapstoneService service;private final boolean fixture;
    @Inject public CapstoneController(CapstoneService service,Config config){this.service=service;fixture=config.hasPath("capstone.fixtureLoginEnabled")&&config.getBoolean("capstone.fixtureLoginEnabled");}
    public Result ready(){if(!fixture)return notFound();service.initialize();return ok(service.state());}
    public Result login(Http.Request request,String tenant,String subject) {
        if(!fixture)return notFound();try{new Principal(tenant,subject);}catch(IllegalArgumentException e){return badRequest();}
        return ok("PUBLIC SYNTHETIC FIXTURE").addingToSession(request,Map.of("tenant",tenant,"username",subject));
    }
    @AddCSRFToken public Result form(Http.Request request){return ok(Json.newObject().put("csrfToken",CSRF.getToken(request).orElseThrow().value()));}
    private CompletionStage<Result> call(Supplier<CompletionStage<? extends JsonNode>> action) {
        try{return action.get().handle((value,error)->error==null?ok(value):failure(error));}catch(RuntimeException e){return CompletableFuture.completedFuture(failure(e));}
    }
    private Result failure(Throwable error) {
        while(error instanceof CompletionException && error.getCause()!=null)error=error.getCause();
        int status=error instanceof OrderRepository.Denied?403:error instanceof OrderRepository.Conflict?409:error instanceof IllegalArgumentException?400:error instanceof RejectedExecutionException?503:500;
        return status(status,Json.newObject().put("error",status==500?"INTERNAL":error.getMessage()));
    }
    @Security.Authenticated @BodyParser.Of(BodyParser.Json.class)
    public CompletionStage<Result> create(Http.Request request) {
        return call(()->{
            JsonNode body=request.body().asJson();
            if(body==null || !body.isObject())throw new IllegalArgumentException("object JSON required");
            Set<String> allowed=Set.of("key","quantity","note","delayMillis","notifySlow");body.fieldNames().forEachRemaining(k->{if(!allowed.contains(k))throw new IllegalArgumentException("unknown field");});
            if(!body.path("key").isTextual() || !body.path("quantity").isInt() || !body.path("note").isTextual())throw new IllegalArgumentException("invalid fields");
            if(body.has("delayMillis")&&(!fixture || !body.get("delayMillis").isInt()))throw new IllegalArgumentException("delay fixture only");
            if(body.has("notifySlow")&&!body.get("notifySlow").isBoolean())throw new IllegalArgumentException("notify boolean");
            return service.create(Principal.from(request),body.get("key").asText(),body.get("quantity").asInt(),body.get("note").asText(),body.path("delayMillis").asInt(0),body.path("notifySlow").asBoolean(false));
        });
    }
    @Security.Authenticated public CompletionStage<Result> list(Http.Request request){return call(()->service.list(Principal.from(request)));}
    @Security.Authenticated public CompletionStage<Result> detail(Http.Request request,String id){return call(()->service.detail(Principal.from(request),id));}
    @Security.Authenticated public CompletionStage<Result> cancel(Http.Request request,String id){return call(()->service.cancel(Principal.from(request),id));}
    @Security.Authenticated public CompletionStage<Result> revoke(Http.Request request){return fixture?call(()->service.revoke(Principal.from(request))):CompletableFuture.completedFuture(notFound());}
    public Result state(){return fixture?ok(service.state()):notFound();}
    @Security.Authenticated public CompletionStage<Result> events(Http.Request request,String id,String track) {
        Principal principal=Principal.from(request);
        return service.detail(principal,id).handle((order,error)->{
            if(error!=null)return failure(error);
            try{service.openStream(track,"sse");}catch(RuntimeException e){return failure(e);}
            var bytes=Source.range(1,20).throttle(1,Duration.ofMillis(150)).mapAsync(1,n->service.detail(principal,id))
                .map(row->{service.produced(track);return EventSource.Event.event(row.toString());}).via(EventSource.flow())
                .takeWithin(Duration.ofSeconds(5)).watchTermination((m,d)->{d.whenComplete((v,e)->service.closeStream(track,e));return m;});
            return ok().chunked(bytes).as("text/event-stream");
        });
    }
    @Security.Authenticated public CompletionStage<Result> export(Http.Request request,String id,String track,int copies) {
        return service.export(Principal.from(request),id,track,copies).handle((download,error)->{
            if(error!=null)return failure(error);
            return ok().sendPath(download.path(),false,Optional.of("orders.csv"),()->service.closeDownload(download),Runnable::run).as("text/csv");
        });
    }
}
