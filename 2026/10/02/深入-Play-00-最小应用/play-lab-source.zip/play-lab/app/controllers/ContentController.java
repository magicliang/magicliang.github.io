package controllers;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import content.ApiJsonParser;
import content.ReservationForm;
import content.StockService;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.inject.Inject;
import play.data.Form;
import play.data.FormFactory;
import play.filters.csrf.AddCSRFToken;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;

public final class ContentController extends Controller {
    private static final Set<String> FORM_FIELDS = Set.of("name", "quantity", "confirmation");
    private static final String PROBE = "<img id=\"twirl-payload\" src=\"/assets/missing-probe.png\" "
            + "onerror=\"window.recordTwirlProbe('img')\"><script>window.recordTwirlProbe('script')</script>";
    private final FormFactory forms;
    private final StockService stock;
    private final ObjectMapper mapper;

    @Inject
    public ContentController(FormFactory forms, StockService stock, ObjectMapper mapper) {
        this.forms = forms;
        this.stock = stock;
        this.mapper = mapper;
    }

    @BodyParser.Of(ApiJsonParser.class)
    public Result json(Http.Request request) {
        JsonNode body = request.body().asJson();
        if (body == null || !body.isObject() || body.size() != 2
                || !body.hasNonNull("name") || !body.hasNonNull("amount")
                || !body.get("name").isTextual() || !body.get("amount").isTextual()) return invalidJson();
        String name = body.get("name").textValue();
        String amount = body.get("amount").textValue();
        if (name.isBlank() || name.codePointCount(0, name.length()) > 40
                || !amount.matches("(?:0|[1-9][0-9]{0,8})(?:\\.[0-9]{1,2})?")) return invalidJson();
        BigDecimal decimal = new BigDecimal(amount);
        if (decimal.signum() <= 0) return invalidJson();
        return created(Json.newObject().put("name", name).put("amount", decimal.setScale(2).toPlainString()));
    }

    private Result invalidJson() {
        return badRequest(Json.newObject().put("code", "INVALID_INPUT"));
    }

    public Result mapper() throws com.fasterxml.jackson.core.JsonProcessingException {
        String literal = "123456789.123456789";
        JsonNode injected = mapper.readTree(literal);
        JsonNode active = Json.parse(literal);
        return ok(Json.newObject().put("literal", literal).put("mapperClass", mapper.getClass().getName())
                .put("injectedNodeClass", injected.getClass().getSimpleName()).put("injectedTreeText", injected.asText())
                .put("activeNodeClass", active.getClass().getSimpleName()).put("activeTreeText", active.asText())
                .put("injectedBigDecimalForFloats", mapper.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS))
                .put("activeBigDecimalForFloats", Json.mapper().isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS))
                .put("stringDecimal", new BigDecimal(literal).toPlainString()));
    }

    @AddCSRFToken
    public Result formPage(Http.Request request) {
        return ok(views.html.contentForm.render(Map.of(), List.of(), "READY", request));
    }

    @BodyParser.Of(BodyParser.FormUrlEncoded.class)
    public Result form(Http.Request request) {
        Map<String, String[]> values = request.body().asFormUrlEncoded();
        if (!FORM_FIELDS.containsAll(values.keySet())) {
            return badRequest(views.html.contentForm.render(values, List.of("Unexpected field"), "UNKNOWN_FIELD", request));
        }
        if (values.values().stream().anyMatch(value -> value.length != 1)) {
            return badRequest(views.html.contentForm.render(values, List.of("Scalar field repeated"), "DUPLICATE_FIELD", request));
        }
        Form<ReservationForm> bound = forms.form(ReservationForm.class)
                .bindFromRequest(request, "name", "quantity", "confirmation");
        if (bound.hasErrors()) {
            List<String> errors = bound.errors().stream().map(error -> error.key() + ":" + error.message()).toList();
            return badRequest(views.html.contentForm.render(values, errors, "FORM_INVALID", request));
        }
        if (!stock.reserve(bound.get().getQuantity())) {
            return status(CONFLICT, views.html.contentForm.render(values, List.of("Stock changed"), "STOCK_CONFLICT", request));
        }
        return created(Json.newObject().put("code", "RESERVED").put("remaining", stock.remaining()));
    }

    @BodyParser.Of(BodyParser.FormUrlEncoded.class)
    public Result ordinaryForm(Http.Request request) {
        Form<ReservationForm> bound = forms.form(ReservationForm.class).bindFromRequest(request);
        return ok(Json.newObject().put("hasErrors", bound.hasErrors())
                .<JsonNode>set("data", Json.toJson(bound.rawData())));
    }

    public Result stock() {
        return ok(Json.newObject().put("remaining", stock.remaining()));
    }

    public Result resetStock() {
        stock.reset();
        return stock();
    }

    public Result twirl(boolean raw) {
        return ok(views.html.contentTwirl.render(PROBE, raw));
    }
}
