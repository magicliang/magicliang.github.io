package controllers;

import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.inject.Inject;
import java.util.concurrent.*;
import java.util.function.Supplier;
import labdb.DbAccess;
import labdb.PoolLab;
import labdb.TransactionLab;
import labdb.EvolutionLab;
import labdb.LateCommitLab;
import lifecycle.ManagedDatabaseJob;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;

public final class DatabaseLabController extends Controller {
    private final DbAccess access;
    private final PoolLab pools;
    private final TransactionLab transactions;
    private final EvolutionLab evolutions;
    private final LateCommitLab late;
    private final ManagedDatabaseJob background;
    @Inject public DatabaseLabController(DbAccess access, PoolLab pools, TransactionLab transactions, EvolutionLab evolutions, LateCommitLab late, ManagedDatabaseJob background) {
        this.access = access; this.pools = pools; this.transactions = transactions; this.evolutions = evolutions; this.late = late; this.background = background;
    }
    public CompletionStage<Result> pools() { return experiment(pools::run); }
    public CompletionStage<Result> interruptedCleanup() { return experiment(pools::interruptedCleanup); }
    public CompletionStage<Result> load(boolean dedicated) {
        if (!access.enabled()) return CompletableFuture.completedFuture(status(503, Json.newObject().put("code", "DB_DISABLED")));
        return pools.load(dedicated).thenApply(value -> ok(value));
    }
    public CompletionStage<Result> transactions() { return experiment(transactions::run); }
    public CompletionStage<Result> prepareOrder() { return experiment(transactions::prepareOrder); }
    public CompletionStage<Result> submitOrder(String id, String key, String payload) {
        return experiment(() -> transactions.submitOrder(id, key, payload));
    }
    public CompletionStage<Result> evolutions() { return experiment(evolutions::run); }
    public CompletionStage<Result> lateStart(boolean committed) {
        if (!access.enabled()) return CompletableFuture.completedFuture(status(503, Json.newObject().put("code", "DB_DISABLED")));
        return late.start(committed).thenApply(value -> status(value.path("response").asText().equals("TIMEOUT") ? 504 : value.path("response").asText().equals("FAILED") ? 500 : 200, value));
    }
    public CompletionStage<Result> lateStatus(String id, boolean release, boolean retry) { return experiment(() -> late.status(id, release, retry)); }
    public CompletionStage<Result> backgroundStart(String key, int millis) { return experiment(() -> background.start(key, millis)); }
    public CompletionStage<Result> backgroundStatus() { return experiment(background::status); }
    public CompletionStage<Result> placement(boolean dedicated) {
        if (!access.enabled()) return CompletableFuture.completedFuture(status(503, Json.newObject().put("code", "DB_DISABLED")));
        return pools.placement(dedicated).thenApply(value -> ok(value));
    }
    private CompletionStage<Result> experiment(Supplier<ObjectNode> work) {
        if (!access.enabled()) return CompletableFuture.completedFuture(status(503, Json.newObject().put("code", "DB_DISABLED")));
        ExecutorService driver = Executors.newSingleThreadExecutor(Thread.ofPlatform().name("db-lab-driver").factory());
        return CompletableFuture.supplyAsync(work, driver).handle((body, error) -> {
            driver.shutdown();
            if (error != null) {
                Throwable cause = error;
                while (cause instanceof CompletionException && cause.getCause() != null) cause = cause.getCause();
                if (cause instanceof RejectedExecutionException) return status(503, Json.newObject().put("code", "DB_STOPPING"));
                error.printStackTrace(); return internalServerError(Json.newObject().put("code", "DB_LAB_FAILURE"));
            }
            String outcome = body.path("outcome").asText();
            return status(outcome.equals("CONFLICT") ? 409 : outcome.equals("CREATED") ? 201 : 200, body);
        });
    }
}
