package capstone;
import java.sql.*;
import java.util.*;
import java.util.function.Consumer;
import com.fasterxml.jackson.databind.node.*;
import labdb.DbAccess;
import play.db.Database;
import play.libs.Json;
public final class OrderRepository {
    public static final class Denied extends RuntimeException { public Denied(){super("object policy denied");} }
    public static final class Conflict extends RuntimeException { public Conflict(String reason){super(reason);} }
    private final Database db; private final String schema;
    public OrderRepository(Database db,String schema) {
        if(!schema.matches("capstone_[a-z0-9_]{1,40}"))throw new IllegalArgumentException("schema");
        this.db=db;this.schema=schema;
        db.withTransaction(c->{
            DbAccess.execute(c,"CREATE SCHEMA IF NOT EXISTS "+schema);
            DbAccess.execute(c,"CREATE TABLE IF NOT EXISTS "+schema+".principals(tenant text,subject text,revoked boolean NOT NULL DEFAULT false,PRIMARY KEY(tenant,subject))");
            DbAccess.execute(c,"CREATE TABLE IF NOT EXISTS "+schema+".stock(tenant text PRIMARY KEY,remaining integer NOT NULL CHECK(remaining>=0))");
            DbAccess.execute(c,"CREATE TABLE IF NOT EXISTS "+schema+".orders(id uuid PRIMARY KEY,tenant text NOT NULL,subject text NOT NULL,idem_key text NOT NULL,payload text NOT NULL,quantity integer NOT NULL CHECK(quantity>0),status text NOT NULL CHECK(status IN ('CREATED','CANCELLED')),UNIQUE(tenant,subject,idem_key))");
            for(String tenant:List.of("t1","t2")) {
                try(PreparedStatement s=c.prepareStatement("INSERT INTO "+schema+".stock VALUES(?,20) ON CONFLICT DO NOTHING")){s.setQueryTimeout(5);s.setString(1,tenant);s.executeUpdate();}
                for(String subject:List.of("alice","bob"))try(PreparedStatement s=c.prepareStatement("INSERT INTO "+schema+".principals VALUES(?,?,false) ON CONFLICT DO NOTHING")){s.setQueryTimeout(5);s.setString(1,tenant);s.setString(2,subject);s.executeUpdate();}
            } return null;
        });
    }
    private void authorize(Connection c,Principal p) throws SQLException {
        try(PreparedStatement s=c.prepareStatement("SELECT revoked FROM "+schema+".principals WHERE tenant=? AND subject=? FOR SHARE")) {
            s.setQueryTimeout(5);s.setString(1,p.tenant());s.setString(2,p.subject());
            try(ResultSet r=s.executeQuery()){if(!r.next() || r.getBoolean(1))throw new Denied();}
        }
    }
    public static void validate(String key,int quantity,String note,int delay) {
        if(!key.matches("[a-zA-Z0-9_-]{1,40}") || quantity<1 || quantity>3 || !note.matches("[a-zA-Z0-9 _.-]{0,80}") || delay<0 || delay>2000)throw new IllegalArgumentException("invalid order fields");
    }
    public ObjectNode create(Principal p,String key,int quantity,String note,int delay,Consumer<String> event) {
        validate(key,quantity,note,delay);String payload=quantity+":"+note;
        return db.withTransaction(c->{
            authorize(c,p);UUID id=UUID.randomUUID();int inserted;
            try(PreparedStatement s=c.prepareStatement("INSERT INTO "+schema+".orders VALUES(?,?,?,?,?,?, 'CREATED') ON CONFLICT(tenant,subject,idem_key) DO NOTHING")) {
                s.setQueryTimeout(5);s.setObject(1,id);s.setString(2,p.tenant());s.setString(3,p.subject());s.setString(4,key);s.setString(5,payload);s.setInt(6,quantity);inserted=s.executeUpdate();
            }
            if(inserted==0) {
                try(PreparedStatement s=c.prepareStatement("SELECT id,payload,quantity,status FROM "+schema+".orders WHERE tenant=? AND subject=? AND idem_key=?")) {
                    s.setQueryTimeout(5);s.setString(1,p.tenant());s.setString(2,p.subject());s.setString(3,key);
                    try(ResultSet r=s.executeQuery()){if(!r.next())throw new IllegalStateException("unique conflict row absent");if(!r.getString(2).equals(payload))throw new Conflict("PAYLOAD_CONFLICT");return row(r.getString(1),p,r.getInt(3),r.getString(4)).put("outcome","REPLAY");}
                }
            }
            try(PreparedStatement s=c.prepareStatement("UPDATE "+schema+".stock SET remaining=remaining-? WHERE tenant=? AND remaining>=?")) {
                s.setQueryTimeout(5);s.setInt(1,quantity);s.setString(2,p.tenant());s.setInt(3,quantity);if(s.executeUpdate()!=1)throw new Conflict("OUT_OF_STOCK");
            }
            if(delay>0) {
                event.accept("sql-entered");
                try(PreparedStatement s=c.prepareStatement("SELECT pg_sleep(?) /* "+schema+" */")){s.setQueryTimeout(5);s.setDouble(1,delay/1000.0);s.execute();}
            }
            return row(id.toString(),p,quantity,"CREATED").put("outcome","CREATED");
        });
    }
    private static ObjectNode row(String id,Principal p,int quantity,String status) {
        return Json.newObject().put("id",id).put("tenant",p.tenant()).put("subject",p.subject()).put("quantity",quantity).put("status",status);
    }
    public ObjectNode detail(Principal p,String id) {
        UUID parsed=UUID.fromString(id);
        return db.withTransaction(c->{authorize(c,p);return select(c,p,parsed,false);});
    }
    private ObjectNode select(Connection c,Principal p,UUID id,boolean lock) throws SQLException {
        try(PreparedStatement s=c.prepareStatement("SELECT quantity,status FROM "+schema+".orders WHERE id=? AND tenant=? AND subject=?"+(lock?" FOR UPDATE":""))) {
            s.setQueryTimeout(5);s.setObject(1,id);s.setString(2,p.tenant());s.setString(3,p.subject());
            try(ResultSet r=s.executeQuery()){if(!r.next())throw new Denied();return row(id.toString(),p,r.getInt(1),r.getString(2));}
        }
    }
    public ArrayNode list(Principal p) {
        return db.withTransaction(c->{authorize(c,p);ArrayNode rows=Json.newArray();
            try(PreparedStatement s=c.prepareStatement("SELECT id,quantity,status FROM "+schema+".orders WHERE tenant=? AND subject=? ORDER BY id LIMIT 100")) {
                s.setQueryTimeout(5);s.setString(1,p.tenant());s.setString(2,p.subject());try(ResultSet r=s.executeQuery()){while(r.next())rows.add(row(r.getString(1),p,r.getInt(2),r.getString(3)));}
            }return rows;
        });
    }
    public ObjectNode cancel(Principal p,String id) {
        UUID parsed=UUID.fromString(id);
        return db.withTransaction(c->{authorize(c,p);ObjectNode row=select(c,p,parsed,true);
            if(row.get("status").asText().equals("CANCELLED"))return row.put("outcome","REPLAY_CANCEL");
            try(PreparedStatement s=c.prepareStatement("UPDATE "+schema+".orders SET status='CANCELLED' WHERE id=?")){s.setQueryTimeout(5);s.setObject(1,parsed);s.executeUpdate();}
            try(PreparedStatement s=c.prepareStatement("UPDATE "+schema+".stock SET remaining=remaining+? WHERE tenant=?")){s.setQueryTimeout(5);s.setInt(1,row.get("quantity").asInt());s.setString(2,p.tenant());s.executeUpdate();}
            return row.put("status","CANCELLED").put("outcome","CANCELLED");
        });
    }
    public void revoke(Principal p) {
        db.withTransaction(c->{try(PreparedStatement s=c.prepareStatement("UPDATE "+schema+".principals SET revoked=true WHERE tenant=? AND subject=?")){s.setQueryTimeout(5);s.setString(1,p.tenant());s.setString(2,p.subject());s.executeUpdate();}return null;});
    }
}
