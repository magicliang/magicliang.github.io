package capstone;
import play.mvc.Http;
public record Principal(String tenant, String subject) {
    public Principal {
        if (!tenant.matches("t[12]") || !subject.matches("alice|bob")) throw new IllegalArgumentException("unknown fixture principal");
    }
    public static Principal from(Http.RequestHeader request) {
        return new Principal(request.session().get("tenant").orElse(""),request.session().get("username").orElse(""));
    }
}
