package capstone;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.typesafe.config.*;
import jakarta.inject.*;
import java.io.*;
import java.net.URI;
import java.nio.*;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import labdb.DbAccess;
import observabilitylab.RequestEvents;
import org.apache.pekko.Done;
import org.apache.pekko.actor.*;
import org.apache.pekko.stream.Materializer;
import play.db.Database;
import play.inject.ApplicationLifecycle;
import play.libs.Json;
import play.libs.ws.ahc.*;
import play.shaded.ahc.org.asynchttpclient.AsyncHttpClient;
@Singleton
public final class CapstoneService {
    public record Download(Path path,String track) {}
    private final DbAccess access; private final Config config; private final Materializer mat; private final RequestEvents observations;
    private final AtomicInteger inFlight=new AtomicInteger();
    private final Semaphore streams=new Semaphore(4);
    private final LinkedHashMap<String,ObjectNode> ledger=new LinkedHashMap<>();
    private Database db; private OrderRepository repository; private ThreadPoolExecutor workers;
    private AhcWSClient client; private FileChannel journal; private Path journalPath,files;
    private String downstream; private boolean initialized,stopping,closed;private int journalRows;
    @Inject public CapstoneService(DbAccess access,Config config,Materializer mat,RequestEvents observations,ApplicationLifecycle lifecycle,ActorSystem actors) {
        this.access=access;this.config=config;this.mat=mat;this.observations=observations;
        CoordinatedShutdown.get(actors).addTask(CoordinatedShutdown.PhaseBeforeServiceUnbind(),"capstone-stop-admission",()->{
            synchronized(this){stopping=true;}
            if(initialized) {
                event("admission-closed","inFlight="+inFlight.get());
                boolean rejected=false;
                try { submit(()->null).toCompletableFuture().join(); } catch(CompletionException expected){rejected=true;}
                event("new-task-rejected",Boolean.toString(rejected));
            }
            return CompletableFuture.completedFuture(Done.getInstance());
        });
        lifecycle.addStopHook(()->CompletableFuture.runAsync(this::closeResources,r->Thread.ofPlatform().name("capstone-shutdown").start(r)));
    }
    public synchronized void initialize() {
        if(initialized)return;
        if(stopping || !config.hasPath("capstone.enabled") || !config.getBoolean("capstone.enabled"))throw new RejectedExecutionException("capstone disabled or stopping");
        String schema=config.getString("capstone.schema");
        URI uri=URI.create(config.getString("capstone.downstream"));
        if(!"http".equals(uri.getScheme()) || !"127.0.0.1".equals(uri.getHost()) || uri.getPort()<1 || !"/slow".equals(uri.getPath()) || uri.getUserInfo()!=null || uri.getQuery()!=null || uri.getFragment()!=null)throw new IllegalArgumentException("fixed loopback downstream required");
        downstream=uri.toString();
        try {
            journalPath=Path.of(config.getString("capstone.journal"));files=Path.of(config.getString("capstone.files"));Files.createDirectories(files);Files.createDirectories(journalPath.toAbsolutePath().getParent());
            journal=FileChannel.open(journalPath,StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE);
            db=access.open("capstone",4,1000);repository=new OrderRepository(db,schema);
            workers=new ThreadPoolExecutor(4,4,0,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<>(16),Thread.ofPlatform().name("capstone-db-",0).factory(),new ThreadPoolExecutor.AbortPolicy());
            Config limited=ConfigFactory.parseMap(Map.of("play.ws.ahc.maxConnectionsPerHost",2,"play.ws.ahc.maxConnectionsTotal",2)).withFallback(config).resolve();
            client=AhcWSClient.create(AhcWSClientConfigFactory.forConfig(limited,Thread.currentThread().getContextClassLoader()),null,mat);
            initialized=true;event("initialized",schema);
        } catch(Exception error) {
            if(workers!=null)workers.shutdownNow();if(client!=null)try{client.close();}catch(IOException close){error.addSuppressed(close);}if(db!=null)DbAccess.shutdown(db,error);if(journal!=null)try{journal.close();}catch(IOException close){error.addSuppressed(close);}
            throw new IllegalStateException(error);
        }
    }
    public <T> CompletionStage<T> submit(Callable<T> task) {
        synchronized(this) {
            if(stopping)return CompletableFuture.failedFuture(new RejectedExecutionException("DRAINING"));
            try{initialize();}catch(RuntimeException e){return CompletableFuture.failedFuture(e);}
            inFlight.incrementAndGet();CompletableFuture<T> result=new CompletableFuture<>();
            try {workers.execute(()->{try{result.complete(task.call());}catch(Throwable e){result.completeExceptionally(e);}finally{inFlight.decrementAndGet();}});}
            catch(RejectedExecutionException e){inFlight.decrementAndGet();result.completeExceptionally(e);}
            return result;
        }
    }
    public CompletionStage<ObjectNode> create(Principal p,String key,int quantity,String note,int delay,boolean notifySlow) {
        return submit(()->repository.create(p,key,quantity,note,delay,name->event(name,key))).thenCompose(order->{
            event("transaction-returned",key+":"+order.get("outcome").asText());observations.event(key,"capstone_commit","committed_or_replayed");
            if(!notifySlow)return CompletableFuture.completedFuture(order.put("notification","NOT_REQUESTED"));
            // Only the trusted configured URL is used; request data cannot supply or extend it.
            return client.url(downstream).setFollowRedirects(false).setRequestTimeout(Duration.ofMillis(120)).get().handle((response,error)->{
                String outcome=error==null?"HTTP_"+response.getStatus():"BUDGET_FAILED";
                event("notification-terminal",key+":"+outcome);observations.event(key,"capstone_notify",error==null?"response":"budget_failed");
                return order.put("notification",outcome);
            });
        });
    }
    public CompletionStage<ObjectNode> detail(Principal p,String id){return submit(()->repository.detail(p,id));}
    public CompletionStage<com.fasterxml.jackson.databind.node.ArrayNode> list(Principal p){return submit(()->repository.list(p));}
    public CompletionStage<ObjectNode> cancel(Principal p,String id){return submit(()->repository.cancel(p,id));}
    public CompletionStage<ObjectNode> revoke(Principal p){return submit(()->{repository.revoke(p);return Json.newObject().put("revoked",true);});}
    public synchronized void openStream(String track,String kind) {
        if(!track.matches("[A-Za-z0-9_-]{1,48}") || ledger.containsKey(track))throw new IllegalArgumentException("unique track required");
        if(stopping || !streams.tryAcquire())throw new RejectedExecutionException("stream capacity");
        if(ledger.size()==128){String old=ledger.entrySet().stream().filter(e->e.getValue().path("closed").asBoolean()).map(Map.Entry::getKey).findFirst().orElse(null);if(old==null){streams.release();throw new RejectedExecutionException("ledger capacity");}ledger.remove(old);}
        ledger.put(track,Json.newObject().put("kind",kind).put("producedEvents",0).put("closed",false).put("closeCount",0));
    }
    public synchronized void produced(String track){ObjectNode r=ledger.get(track);r.put("producedEvents",r.get("producedEvents").asInt()+1);}
    public synchronized void closeStream(String track,Throwable error) {
        ObjectNode row=ledger.get(track);if(row==null || row.path("closed").asBoolean())return;
        row.put("closed",true).put("closeCount",1).put("failure",error==null?"":error.getClass().getSimpleName());streams.release();event("stream-terminal",track+":"+row.get("failure").asText());
    }
    public CompletionStage<Download> export(Principal p,String id,String track,int copies) {
        if(copies<1 || copies>524288)return CompletableFuture.failedFuture(new IllegalArgumentException("copies"));
        return submit(()->{
            ObjectNode order=repository.detail(p,id);openStream(track,"csv");Path file=null;
            try {
                file=Files.createTempFile(files,"order-",".csv");String row=order.get("id").asText()+","+order.get("status").asText()+","+order.get("quantity").asInt()+"\n";
                try(BufferedWriter writer=Files.newBufferedWriter(file,StandardCharsets.UTF_8)){writer.write("id,status,quantity\n");for(int i=0;i<copies;i++)writer.write(row);}
                return new Download(file,track);
            }catch(Throwable error){if(file!=null)try{Files.deleteIfExists(file);}catch(IOException e){error.addSuppressed(e);}closeStream(track,error);throw error;}
        });
    }
    public void closeDownload(Download file) {
        try{Files.delete(file.path());closeStream(file.track(),null);}
        catch(IOException error){closeStream(file.track(),error);throw new UncheckedIOException(error);}
    }
    public synchronized ObjectNode state() {
        ObjectNode out=Json.newObject().put("initialized",initialized).put("stopping",stopping).put("closed",closed).put("inFlight",inFlight.get()).put("streamPermits",streams.availablePermits());
        ObjectNode rows=out.putObject("streams");ledger.forEach((k,v)->rows.set(k,v.deepCopy()));return out;
    }
    private synchronized void event(String name,String detail) {
        if(journal==null || !journal.isOpen())return;
        if(journalRows++>=1024)return;
        byte[] bytes=(Json.newObject().put("event",name).put("detail",detail).put("thread",Thread.currentThread().getName()).put("nanoTime",System.nanoTime()).toString()+"\n").getBytes(StandardCharsets.UTF_8);
        try{ByteBuffer data=ByteBuffer.wrap(bytes);while(data.hasRemaining())journal.write(data);journal.force(false);}catch(IOException e){throw new UncheckedIOException(e);}
    }
    private void closeResources() {
        synchronized(this){stopping=true;if(!initialized || closed)return;}
        Throwable failure=null;boolean interrupted=false;
        try {
            event("drain-start","inFlight="+inFlight.get());workers.shutdown();
            if(!workers.awaitTermination(8,TimeUnit.SECONDS)){workers.shutdownNow();if(!workers.awaitTermination(3,TimeUnit.SECONDS))throw new IllegalStateException("worker did not terminate");}
            event("drain-end","inFlight="+inFlight.get());
        } catch(Exception error){failure=error;interrupted=error instanceof InterruptedException;workers.shutdownNow();}
        try{client.close();}catch(Exception error){failure=append(failure,error);}
        try{DbAccess.shutdown(db,null);}catch(Exception error){failure=append(failure,error);}
        boolean clientClosed=((AsyncHttpClient)client.getUnderlying()).isClosed();
        boolean poolClosed=((com.zaxxer.hikari.HikariDataSource)db.getDataSource()).isClosed();
        long filesLeft=-1;
        try(var list=Files.list(files)){filesLeft=list.count();}catch(IOException error){failure=append(failure,error);}
        try{event("resources-before-journal-close","poolClosed="+poolClosed+",clientClosed="+clientClosed+",executorTerminated="+workers.isTerminated()+",filesLeft="+filesLeft+",streamPermits="+streams.availablePermits());}
        catch(RuntimeException error){failure=append(failure,error);}
        try{journal.close();}catch(IOException error){failure=append(failure,error);}
        synchronized(this){closed=true;}
        try {
            Files.writeString(journalPath,Json.newObject().put("event","final-cleanup").put("fileClosed",!journal.isOpen()).put("poolClosed",poolClosed).put("clientClosed",clientClosed).put("executorTerminated",workers.isTerminated()).put("inFlight",inFlight.get()).put("filesLeft",filesLeft).put("streamPermits",streams.availablePermits()).put("cleanupFailure",failure==null?"":failure.getClass().getSimpleName()).toString()+"\n",StandardOpenOption.APPEND);
        } catch(IOException error){failure=append(failure,error);}
        finally{if(interrupted)Thread.currentThread().interrupt();}
        if(failure!=null)throw new IllegalStateException("capstone cleanup failed",failure);
    }
    private static Throwable append(Throwable primary,Throwable secondary){if(primary==null)return secondary;primary.addSuppressed(secondary);return primary;}
}
