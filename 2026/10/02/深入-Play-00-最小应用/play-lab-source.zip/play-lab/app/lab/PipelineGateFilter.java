package lab;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.function.Function;
import javax.inject.Inject;
import org.apache.pekko.stream.Materializer;
import play.mvc.Filter;
import play.mvc.Http;
import play.mvc.Result;
import play.mvc.Results;

public final class PipelineGateFilter extends Filter {
    private final TraceLog trace;

    @Inject
    public PipelineGateFilter(Materializer materializer, TraceLog trace) {
        super(materializer);
        this.trace = trace;
    }

    @Override
    public CompletionStage<Result> apply(
            Function<Http.RequestHeader, CompletionStage<Result>> next, Http.RequestHeader request) {
        if (request.headers().get("X-Pipeline-Id").isEmpty()) return next.apply(request);
        String id = request.headers().get("X-Pipeline-Id").orElseThrow();
        trace.add(id, "gate-enter");
        if (request.headers().get("X-Pipeline-Block").filter("yes"::equals).isPresent()) {
            trace.add(id, "gate-reject");
            trace.add(id, "gate-exit-403");
            return CompletableFuture.completedFuture(Results.forbidden("blocked by lab filter"));
        }
        return next.apply(request).thenApply(result -> {
            trace.add(id, "gate-exit-" + result.status());
            return result;
        });
    }
}
