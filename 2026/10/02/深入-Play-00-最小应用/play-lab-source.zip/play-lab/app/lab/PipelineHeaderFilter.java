package lab;

import java.util.concurrent.CompletionStage;
import java.util.function.Function;
import javax.inject.Inject;
import org.apache.pekko.stream.Materializer;
import play.mvc.Filter;
import play.mvc.Http;
import play.mvc.Result;

public final class PipelineHeaderFilter extends Filter {
    private final TraceLog trace;

    @Inject
    public PipelineHeaderFilter(Materializer materializer, TraceLog trace) {
        super(materializer);
        this.trace = trace;
    }

    @Override
    public CompletionStage<Result> apply(
            Function<Http.RequestHeader, CompletionStage<Result>> next, Http.RequestHeader request) {
        if (request.headers().get("X-Pipeline-Id").isEmpty()) return next.apply(request);
        String id = request.headers().get("X-Pipeline-Id").orElseThrow();
        trace.add(id, "header-enter");
        return next.apply(request).thenApply(result -> {
            trace.add(id, "header-exit-" + result.status());
            return result.withHeader("X-Pipeline-Security", "applied");
        });
    }
}
