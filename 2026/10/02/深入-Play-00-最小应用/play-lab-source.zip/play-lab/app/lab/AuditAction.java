package lab;

import java.util.concurrent.CompletionStage;
import javax.inject.Inject;
import play.mvc.Action;
import play.mvc.Http;
import play.mvc.Result;

public final class AuditAction extends Action.Simple {
    private final TraceLog trace;

    @Inject
    public AuditAction(TraceLog trace) {
        this.trace = trace;
    }

    @Override
    public CompletionStage<Result> call(Http.Request request) {
        String id = request.headers().get("X-Pipeline-Id").orElse("anonymous");
        trace.add(id, "audit-enter");
        try {
            return delegate.call(request).whenComplete((result, failure) -> {
                if (failure != null) trace.add(id, "audit-failed");
                trace.add(id, "audit-exit");
            });
        } catch (RuntimeException failure) {
            trace.add(id, "audit-sync-failed");
            trace.add(id, "audit-exit");
            throw failure;
        }
    }
}
