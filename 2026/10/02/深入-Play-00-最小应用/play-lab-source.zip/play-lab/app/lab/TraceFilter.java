package lab;

import java.util.concurrent.CompletionStage;
import java.util.function.Function;
import javax.inject.Inject;
import org.apache.pekko.stream.Materializer;
import play.mvc.Filter;
import play.mvc.Http;
import play.mvc.Result;

public final class TraceFilter extends Filter {
    private final TraceLog trace;

    @Inject
    public TraceFilter(Materializer materializer, TraceLog trace) {
        super(materializer);
        this.trace = trace;
    }

    @Override
    public CompletionStage<Result> apply(
            Function<Http.RequestHeader, CompletionStage<Result>> next, Http.RequestHeader request) {
        String id = request.headers().get("X-Lab-Id").orElse("anonymous");
        trace.add(id, "filter-enter");
        return next.apply(request).whenComplete((result, failure) -> {
            if (failure != null) trace.add(id, "stage-failed");
        }).thenApply(result -> {
            trace.add(id, "result-available-" + result.status());
            return result.withHeader("X-Lab-Result", "available");
        });
    }
}
