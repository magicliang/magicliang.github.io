package lab;

import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import javax.inject.Singleton;

@Singleton
public final class TraceLog {
    private final ConcurrentLinkedQueue<String> events = new ConcurrentLinkedQueue<>();

    public void add(String id, String event) {
        events.add(id + ":" + event);
    }

    public List<String> events(String id) {
        return events.stream().filter(e -> e.startsWith(id + ":")).toList();
    }

    public void clear() {
        events.clear();
    }
}
