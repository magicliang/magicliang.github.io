package lab;

import com.fasterxml.jackson.databind.JsonNode;
import javax.inject.Inject;
import org.apache.pekko.stream.javadsl.Flow;
import org.apache.pekko.util.ByteString;
import play.http.HttpErrorHandler;
import play.libs.F;
import play.libs.streams.Accumulator;
import play.mvc.BodyParser;
import play.mvc.Http;
import play.mvc.Result;

public final class CountingJsonParser implements BodyParser<JsonNode> {
    public static final int MAX_BYTES = 32;
    private final BodyParser.Json parser;
    private final TraceLog trace;

    @Inject
    public CountingJsonParser(HttpErrorHandler errorHandler, TraceLog trace) {
        parser = new BodyParser.Json(MAX_BYTES, errorHandler);
        this.trace = trace;
    }

    @Override
    public Accumulator<ByteString, F.Either<Result, JsonNode>> apply(Http.RequestHeader request) {
        String id = request.headers().get("X-Pipeline-Id").orElse("anonymous");
        trace.add(id, "parser-apply");
        // Counts chunks delivered to this parser, not bytes accepted by the socket or buffered upstream.
        Flow<ByteString, ByteString, ?> counting = Flow.of(ByteString.class).map(bytes -> {
            trace.add(id, "parser-bytes-" + bytes.size());
            return bytes;
        }).watchTermination((unused, completion) -> {
            completion.whenComplete((done, failure) ->
                    trace.add(id, failure == null ? "parser-stream-end" : "parser-stream-failed"));
            return completion;
        });
        return parser.apply(request).through(counting).map(parsed -> {
            trace.add(id, "parser-result-" + parsed.left.map(Result::status).orElse(200));
            return parsed;
        }, Runnable::run);
    }
}
