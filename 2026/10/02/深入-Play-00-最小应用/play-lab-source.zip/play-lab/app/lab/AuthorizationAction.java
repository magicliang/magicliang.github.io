package lab;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import javax.inject.Inject;
import play.mvc.Action;
import play.mvc.Http;
import play.mvc.Result;

public final class AuthorizationAction extends Action.Simple {
    private final TraceLog trace;

    @Inject
    public AuthorizationAction(TraceLog trace) {
        this.trace = trace;
    }

    @Override
    public CompletionStage<Result> call(Http.Request request) {
        String id = request.headers().get("X-Pipeline-Id").orElse("anonymous");
        trace.add(id, "auth-enter");
        if (!request.headers().get("X-Lab-Token").filter("allow"::equals).isPresent()) {
            trace.add(id, "auth-reject");
            trace.add(id, "auth-exit");
            return CompletableFuture.completedFuture(unauthorized("lab authorization required"));
        }
        try {
            return delegate.call(request).whenComplete((result, failure) -> {
                if (failure != null) trace.add(id, "auth-failed");
                trace.add(id, "auth-exit");
            });
        } catch (RuntimeException failure) {
            trace.add(id, "auth-sync-failed");
            trace.add(id, "auth-exit");
            throw failure;
        }
    }
}
