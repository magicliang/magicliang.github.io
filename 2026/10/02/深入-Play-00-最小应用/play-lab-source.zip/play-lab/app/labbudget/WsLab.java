package labbudget;

import static labasync.LabSupport.*;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import jakarta.inject.Inject;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.pekko.stream.Materializer;
import org.apache.pekko.util.ByteString;
import play.libs.Json;
import play.libs.concurrent.Futures;
import play.libs.ws.WSClient;
import play.libs.ws.WSResponse;

public final class WsLab {
    private final WSClient ws;
    private final Futures futures;
    private final Materializer materializer;
    private final WsBoundaryLab boundaries;
    @Inject public WsLab(WSClient ws, Futures futures, Materializer materializer, WsBoundaryLab boundaries) {
        this.ws = ws; this.futures = futures; this.materializer = materializer; this.boundaries = boundaries;
    }

    public ObjectNode run() {
        ExecutorService serverWorkers = Executors.newFixedThreadPool(4, Thread.ofPlatform().name("lab-downstream-", 0).factory());
        HttpServer origin = null, target = null;
        Gate aggregate = new Gate(true), stream = new Gate(true), outer = new Gate(false), own = new Gate(false);
        List<Gate> gates = List.of(aggregate, stream, outer, own);
        AtomicInteger targetCalls = new AtomicInteger();
        Map<String, String> received = new ConcurrentHashMap<>();
        ObjectNode out = Json.newObject();
        try {
            origin = server(); target = server();
            origin.setExecutor(serverWorkers); target.setExecutor(serverWorkers);
            origin.createContext("/aggregate", aggregate::handle);
            origin.createContext("/stream", stream::handle);
            origin.createContext("/outer", outer::handle);
            origin.createContext("/own", own::handle);
            String targetUrl = url(target, "/target");
            origin.createContext("/redirect", exchange -> {
                try {
                    exchange.getResponseHeaders().set("Location", targetUrl);
                    exchange.sendResponseHeaders(302, -1);
                } finally { exchange.close(); }
            });
            target.createContext("/target", exchange -> {
                targetCalls.incrementAndGet();
                received.put("authorization", header(exchange, "Authorization"));
                received.put("cookie", header(exchange, "Cookie"));
                received.put("customCredential", header(exchange, "X-Lab-Credential"));
                try { write(exchange, "redirect-target"); }
                finally { exchange.close(); }
            });
            origin.start(); target.start();
            out.put("originPort", origin.getAddress().getPort()).put("targetPort", target.getAddress().getPort());

            CompletableFuture<WSResponse> aggregated = ws.url(url(origin, "/aggregate")).setRequestTimeout(Duration.ofSeconds(3)).get().toCompletableFuture();
            await(aggregate.entered);
            out.put("aggregateDoneAfterPrefix", aggregated.isDone());
            aggregate.release.countDown();
            out.put("aggregateBody", get(aggregated).getBody());
            out.put("aggregateServerTerminal", get(aggregate.done));

            CompletableFuture<WSResponse> streaming = ws.url(url(origin, "/stream")).setRequestTimeout(Duration.ofSeconds(3)).stream().toCompletableFuture();
            await(stream.entered);
            WSResponse response = get(streaming);
            out.put("streamResponseDoneBeforeBodyRelease", streaming.isDone());
            CompletableFuture<ByteString> body = response.getBodyAsSource()
                    .limitWeighted(64, bytes -> (long) bytes.size()).completionTimeout(Duration.ofSeconds(3))
                    .runFold(ByteString.emptyByteString(), ByteString::concat, materializer).toCompletableFuture();
            out.put("streamBodyDoneBeforeRelease", body.isDone());
            stream.release.countDown();
            ByteString consumed = get(body);
            out.put("streamBody", consumed.utf8String()).put("streamConsumedBytes", consumed.size());
            out.put("streamServerTerminal", get(stream.done));

            CompletableFuture<WSResponse> original = ws.url(url(origin, "/outer")).setRequestTimeout(Duration.ofSeconds(3)).get().toCompletableFuture();
            await(outer.entered);
            out.put("outerTimeoutOutcome", TimeoutLab.outcome(futures.timeout(original, Duration.ofMillis(100))));
            out.put("wsDoneAtOuterTimeout", original.isDone()).put("wsCancelledAtOuterTimeout", original.isCancelled());
            outer.release.countDown();
            out.put("outerLateStatus", get(original).getStatus()).put("outerServerTerminal", get(outer.done));

            CompletableFuture<WSResponse> transportTimeout = ws.url(url(origin, "/own")).setRequestTimeout(Duration.ofMillis(300)).get().toCompletableFuture();
            await(own.entered);
            out.put("wsTimeoutOutcome", TimeoutLab.outcome(transportTimeout)).put("wsDoneAtOwnTimeout", transportTimeout.isDone());
            own.release.countDown();
            out.put("ownServerTerminal", get(own.done));

            WSResponse disabled = get(ws.url(url(origin, "/redirect")).setFollowRedirects(false)
                    .setRequestTimeout(Duration.ofSeconds(3)).get().toCompletableFuture());
            out.put("redirectDisabledStatus", disabled.getStatus()).put("targetCallsWhenDisabled", targetCalls.get());
            WSResponse followed = get(ws.url(url(origin, "/redirect")).setFollowRedirects(true)
                    .addHeader("Authorization", "Bearer synthetic-only")
                    .addHeader("Cookie", "lab=synthetic-only")
                    .addHeader("X-Lab-Credential", "synthetic-only")
                    .setRequestTimeout(Duration.ofSeconds(3)).get().toCompletableFuture());
            out.put("redirectEnabledStatus", followed.getStatus()).put("redirectBody", followed.getBody())
                    .put("targetCallsWhenEnabled", targetCalls.get());
            out.set("redirectTargetHeaders", Json.toJson(received));
        } finally {
            gates.forEach(gate -> gate.release.countDown());
            if (origin != null) origin.stop(0);
            if (target != null) target.stop(0);
            close(serverWorkers);
        }
        out.set("boundaries", boundaries.run());
        return out.put("serverWorkersTerminated", serverWorkers.isTerminated())
                .put("allGatedHandlersDone", gates.stream().allMatch(gate -> gate.done.isDone()));
    }

    private static HttpServer server() {
        try { return HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0); }
        catch (IOException e) { throw new IllegalStateException(e); }
    }
    private static String url(HttpServer server, String path) { return "http://127.0.0.1:" + server.getAddress().getPort() + path; }
    private static String header(HttpExchange exchange, String name) {
        String value = exchange.getRequestHeaders().getFirst(name); return value == null ? "absent" : value;
    }
    private static void write(HttpExchange exchange, String value) throws IOException {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(200, bytes.length); exchange.getResponseBody().write(bytes);
    }

    private static final class Gate {
        final CountDownLatch entered = new CountDownLatch(1), release = new CountDownLatch(1);
        final CompletableFuture<String> done = new CompletableFuture<>();
        final boolean prefix;
        Gate(boolean prefix) { this.prefix = prefix; }
        void handle(HttpExchange exchange) {
            String terminal = "completed";
            try {
                if (prefix) {
                    exchange.sendResponseHeaders(200, 0);
                    exchange.getResponseBody().write("prefix-".getBytes(StandardCharsets.UTF_8));
                    exchange.getResponseBody().flush();
                }
                entered.countDown(); await(release);
                if (prefix) exchange.getResponseBody().write("suffix".getBytes(StandardCharsets.UTF_8));
                else write(exchange, "released");
            } catch (IOException error) { terminal = error.getClass().getSimpleName(); }
            catch (RuntimeException error) { terminal = error.getClass().getSimpleName(); }
            finally { entered.countDown(); exchange.close(); done.complete(terminal); }
        }
    }
}
