package labbudget;

import static labasync.LabSupport.*;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import jakarta.inject.Inject;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.pekko.stream.Materializer;
import org.apache.pekko.util.ByteString;
import play.libs.Json;
import play.libs.ws.WSResponse;
import play.libs.ws.ahc.AhcWSClient;
import play.libs.ws.ahc.AhcWSClientConfigFactory;
import play.shaded.ahc.org.asynchttpclient.AsyncHttpClient;

public final class WsBoundaryLab {
    private final Config configuration;
    private final Materializer materializer;
    @Inject public WsBoundaryLab(Config configuration, Materializer materializer) {
        this.configuration = configuration; this.materializer = materializer;
    }

    public ObjectNode run() { return run(false, Json.newObject()); }

    public ObjectNode interruptedRun() {
        ObjectNode out = Json.newObject();
        try {
            run(true, out);
            throw new AssertionError("interrupted run unexpectedly succeeded");
        } catch (IllegalStateException failure) {
            out.put("failureClass", failure.getClass().getSimpleName())
                    .put("failureCause", failure.getCause().getClass().getSimpleName())
                    .put("coordinatorInterruptRestored", Thread.currentThread().isInterrupted());
            return out;
        }
    }

    private ObjectNode run(boolean interruptAtSecondHop, ObjectNode out) {
        Config limited = ConfigFactory.parseMap(Map.of("play.ws.ahc.maxConnectionsPerHost", 1,
                "play.ws.ahc.maxConnectionsTotal", 2)).withFallback(configuration).resolve();
        AhcWSClient client = AhcWSClient.create(AhcWSClientConfigFactory.forConfig(limited,
                Thread.currentThread().getContextClassLoader()), null, materializer);
        AsyncHttpClient underlying = (AsyncHttpClient) client.getUnderlying();
        ExecutorService workers = Executors.newFixedThreadPool(2, Thread.ofPlatform().name("lab-ws-boundary-", 0).factory());
        Resources resources = new Resources(client, underlying, workers, out);
        CountDownLatch prefixSent = new CountDownLatch(1), continueLarge = new CountDownLatch(1);
        resources.continueLarge = continueLarge;
        CompletableFuture<String> largeDone = new CompletableFuture<>();
        AtomicInteger outsideCalls = new AtomicInteger(), handlersStarted = new AtomicInteger(), handlersFinished = new AtomicInteger();
        AtomicInteger serverBytes = new AtomicInteger();
        out.put("effectiveMaxConnectionsPerHost", underlying.getConfig().getMaxConnectionsPerHost())
                .put("effectiveMaxConnectionsTotal", underlying.getConfig().getMaxConnections());
        try (resources) {
            HttpServer allowed = resources.allowed = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
            HttpServer outside = resources.outside = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
            allowed.setExecutor(workers); outside.setExecutor(workers);
            String allowedOrigin = "http://127.0.0.1:" + allowed.getAddress().getPort();
            String outsideOrigin = "http://127.0.0.1:" + outside.getAddress().getPort();
            // This set is fixed from trusted fixture addresses, never extended from Location.
            Set<String> allowlist = Set.of(allowedOrigin);
            out.put("allowedOrigin", allowedOrigin).put("outsideOrigin", outsideOrigin);
            allowed.createContext("/large", exchange -> {
                handlersStarted.incrementAndGet();
                String terminal = "completed";
                try {
                    byte[] chunk = new byte[16 * 1024];
                    exchange.sendResponseHeaders(200, 0);
                    exchange.getResponseBody().write(chunk); serverBytes.addAndGet(chunk.length);
                    exchange.getResponseBody().flush(); prefixSent.countDown();
                    await(continueLarge);
                    for (int i = 1; i < 256; i++) {
                        exchange.getResponseBody().write(chunk); serverBytes.addAndGet(chunk.length);
                    }
                } catch (IOException error) { terminal = error.getClass().getSimpleName(); }
                catch (RuntimeException error) { terminal = error.getClass().getSimpleName(); }
                finally {
                    prefixSent.countDown(); exchange.close(); handlersFinished.incrementAndGet(); largeDone.complete(terminal);
                }
            });
            allowed.createContext("/ok", exchange -> serve(exchange, handlersStarted, handlersFinished, null));
            allowed.createContext("/redirect-out", exchange -> serve(exchange, handlersStarted, handlersFinished, outsideOrigin + "/target"));
            allowed.createContext("/redirect-in", exchange -> serve(exchange, handlersStarted, handlersFinished, "/ok"));
            WsDeadlineLab deadline = resources.deadline = new WsDeadlineLab(client, allowed, allowlist,
                    handlersStarted, handlersFinished);
            outside.createContext("/target", exchange -> {
                outsideCalls.incrementAndGet(); serve(exchange, handlersStarted, handlersFinished, null);
            });
            allowed.start(); outside.start();

            WSResponse streaming = get(client.url(allowedOrigin + "/large").setFollowRedirects(false)
                    .setRequestTimeout(Duration.ofSeconds(3)).stream().toCompletableFuture());
            await(prefixSent);
            ByteString consumed = get(streaming.getBodyAsSource().limitWeighted(32 * 1024, bytes -> (long) bytes.size())
                    .take(1).completionTimeout(Duration.ofSeconds(3))
                    .runFold(ByteString.emptyByteString(), ByteString::concat, materializer).toCompletableFuture());
            out.put("plannedLargeBodyBytes", 256 * 16 * 1024).put("consumedBeforeTakeCancellation", consumed.size());
            continueLarge.countDown();
            out.put("largeServerTerminal", get(largeDone)).put("largeServerBytesWritten", serverBytes.get());
            WSResponse afterCancel = get(client.url(allowedOrigin + "/ok").setFollowRedirects(false)
                    .setRequestTimeout(Duration.ofSeconds(3)).get().toCompletableFuture());
            out.put("requestAfterCancellationStatus", afterCancel.getStatus());

            out.set("initialOutside", fetchAllowed(client, URI.create(outsideOrigin + "/target"), allowlist));
            out.put("outsideCallsAfterInitialRejection", outsideCalls.get());
            out.set("redirectOutside", fetchAllowed(client, URI.create(allowedOrigin + "/redirect-out"), allowlist));
            out.put("outsideCallsAfterRedirectRejection", outsideCalls.get());
            out.set("redirectInside", fetchAllowed(client, URI.create(allowedOrigin + "/redirect-in"), allowlist));
            // Counterexample: validation of only the initial URL plus automatic redirects escapes.
            WSResponse unsafe = get(client.url(allowedOrigin + "/redirect-out").setFollowRedirects(true)
                    .setRequestTimeout(Duration.ofSeconds(3)).get().toCompletableFuture());
            out.put("initialOnlyValidationStatus", unsafe.getStatus()).put("outsideCallsAfterInitialOnlyValidation", outsideCalls.get());

            out.set("deadline", deadline.run(interruptAtSecondHop));
        } catch (Exception error) {
            if (error instanceof RuntimeException runtime) throw runtime;
            throw new IllegalStateException(error);
        } finally {
            continueLarge.countDown();
            out.put("largeHandlerDone", largeDone.isDone()).put("handlersStarted", handlersStarted.get())
                    .put("handlersFinished", handlersFinished.get());
        }
        return out;
    }

    private static final class Resources implements AutoCloseable {
        final AhcWSClient client;
        final AsyncHttpClient underlying;
        final ExecutorService workers;
        final ObjectNode out;
        HttpServer allowed, outside;
        WsDeadlineLab deadline;
        CountDownLatch continueLarge;
        Resources(AhcWSClient client, AsyncHttpClient underlying, ExecutorService workers, ObjectNode out) {
            this.client = client; this.underlying = underlying; this.workers = workers; this.out = out;
        }
        @Override public void close() throws Exception {
            boolean interrupted = Thread.interrupted();
            continueLarge.countDown();
            Exception first = null;
            AutoCloseable[] cleanup = {
                () -> { if (deadline != null) deadline.close(); },
                () -> { if (allowed != null) allowed.stop(0); },
                () -> { if (outside != null) outside.stop(0); },
                client,
                () -> labasync.LabSupport.close(workers)
            };
            try {
                for (AutoCloseable resource : cleanup) {
                    try { resource.close(); }
                    catch (Exception failure) {
                        if (first == null) first = failure;
                        else first.addSuppressed(failure);
                    } finally { interrupted |= Thread.interrupted(); }
                }
                if (first != null) throw first;
            } finally {
                out.put("clientClosed", underlying.isClosed()).put("serverWorkersTerminated", workers.isTerminated())
                        .put("allowedServerStopAttempted", allowed != null).put("outsideServerStopAttempted", outside != null);
                if (deadline != null) deadline.recordCleanup(out);
                if (interrupted) Thread.currentThread().interrupt();
            }
        }
    }

    private ObjectNode fetchAllowed(AhcWSClient client, URI initial, Set<String> allowlist) {
        URI next = initial;
        int requests = 0;
        for (int hop = 0; hop < 3; hop++) {
            String origin = next.getScheme() + "://" + next.getHost() + ":" + next.getPort();
            if (!allowlist.contains(origin) || next.getUserInfo() != null)
                return Json.newObject().put("outcome", "REJECTED_TARGET").put("requestsSent", requests);
            WSResponse response = get(client.url(next.toString()).setFollowRedirects(false)
                    .setRequestTimeout(Duration.ofSeconds(3)).get().toCompletableFuture());
            requests++;
            if (response.getStatus() < 300 || response.getStatus() >= 400)
                return Json.newObject().put("outcome", "OK").put("status", response.getStatus()).put("requestsSent", requests);
            next = next.resolve(response.getSingleHeader("Location").orElseThrow());
        }
        return Json.newObject().put("outcome", "REDIRECT_LIMIT").put("requestsSent", requests);
    }

    private static void serve(HttpExchange exchange, AtomicInteger started, AtomicInteger finished, String redirect) throws IOException {
        started.incrementAndGet();
        try {
            if (redirect != null) {
                exchange.getResponseHeaders().set("Location", redirect); exchange.sendResponseHeaders(302, -1);
            } else {
                byte[] bytes = "ok".getBytes(StandardCharsets.UTF_8);
                exchange.sendResponseHeaders(200, bytes.length); exchange.getResponseBody().write(bytes);
            }
        } finally { exchange.close(); finished.incrementAndGet(); }
    }
}
