package labbudget;

import static labasync.LabSupport.*;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.inject.Inject;
import java.time.Duration;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;
import play.libs.Json;
import play.libs.concurrent.Futures;

public final class TimeoutLab {
    private final Futures futures;
    @Inject public TimeoutLab(Futures futures) { this.futures = futures; }

    public ObjectNode run() {
        ExecutorService worker = single("lab-budget-work");
        CountDownLatch entered = new CountDownLatch(1), release = new CountDownLatch(1);
        CountDownLatch cooperativeEntered = new CountDownLatch(1), cooperativeRelease = new CountDownLatch(1);
        AtomicBoolean cancellation = new AtomicBoolean();
        AtomicInteger sideEffects = new AtomicInteger();
        ObjectNode out = Json.newObject();
        try {
            CompletableFuture<String> original = CompletableFuture.supplyAsync(() -> {
                entered.countDown(); await(release); return "late-success";
            }, worker);
            await(entered);
            out.put("timeoutOutcome", outcome(futures.timeout(original, Duration.ofMillis(100))));
            out.put("originalDoneAtTimeout", original.isDone()).put("originalCancelledAtTimeout", original.isCancelled());
            release.countDown(); out.put("lateOutcome", get(original));
            CompletableFuture<String> cooperative = CompletableFuture.supplyAsync(() -> {
                cooperativeEntered.countDown(); await(cooperativeRelease);
                if (cancellation.get()) return "cooperatively-cancelled";
                sideEffects.incrementAndGet(); return "effect-applied";
            }, worker);
            await(cooperativeEntered);
            out.put("cooperativeTimeoutOutcome", outcome(futures.timeout(cooperative, Duration.ofMillis(100))));
            cancellation.set(true); cooperativeRelease.countDown();
            out.put("cooperativeTerminal", get(cooperative)).put("cooperativeSideEffects", sideEffects.get());
            out.set("retrySuccess", retryScenario(2, false));
            out.set("retryExhausted", retryScenario(9, false));
            out.set("retryFatal", retryScenario(9, true));
        } finally { release.countDown(); cooperativeRelease.countDown(); close(worker); }
        return out.put("workerTerminated", worker.isTerminated());
    }

    private ObjectNode retryScenario(int failures, boolean fatal) {
        AtomicInteger attempts = new AtomicInteger();
        Supplier<CompletionStage<String>> operation = () -> {
            int current = attempts.incrementAndGet();
            if (current <= failures) return CompletableFuture.failedFuture(fatal
                    ? new IllegalArgumentException("synthetic permanent") : new TransientFailure());
            return CompletableFuture.completedFuture("ok");
        };
        String result = get(retry(operation, 3).handle((value, error) -> error == null ? value : "failed").toCompletableFuture());
        return Json.newObject().put("attempts", attempts.get()).put("maxAttempts", 3).put("outcome", result);
    }

    private CompletionStage<String> retry(Supplier<CompletionStage<String>> operation, int remaining) {
        CompletionStage<String> attempt;
        try { attempt = operation.get(); } catch (RuntimeException error) { attempt = CompletableFuture.failedFuture(error); }
        return attempt.handle((value, error) -> {
            if (error == null) return CompletableFuture.completedFuture(value);
            if (cause(error) instanceof TransientFailure && remaining > 1) return retry(operation, remaining - 1);
            return CompletableFuture.<String>failedFuture(cause(error));
        }).thenCompose(next -> next);
    }

    public static String outcome(CompletionStage<?> stage) {
        return get(stage.handle((value, error) -> error == null ? "success" : cause(error).getClass().getSimpleName()).toCompletableFuture());
    }

    private static Throwable cause(Throwable error) {
        while ((error instanceof CompletionException || error instanceof ExecutionException) && error.getCause() != null) error = error.getCause();
        return error;
    }

    private static final class TransientFailure extends RuntimeException {}
}
