package labbudget;

import static labasync.LabSupport.*;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import play.cache.AsyncCacheApi;
import play.libs.Json;

public final class CacheLab {
    private final AsyncCacheApi cache;
    @Inject public CacheLab(AsyncCacheApi cache) { this.cache = cache; }

    public ObjectNode run() {
        String prefix = "budget-" + UUID.randomUUID();
        String cold = prefix + ":cold", failure = prefix + ":failure", ttl = prefix + ":ttl", forever = prefix + ":zero";
        String alice = prefix + ":alice:item", bob = prefix + ":bob:item";
        String version = prefix + ":version", late = prefix + ":late";
        List<String> keys = List.of(cold, failure, ttl, forever, alice, bob, version, late);
        ExecutorService callers = Executors.newFixedThreadPool(4, Thread.ofPlatform().name("lab-cache-", 0).factory());
        CountDownLatch ready = new CountDownLatch(4), start = new CountDownLatch(1);
        CompletableFuture<String> loading = new CompletableFuture<>();
        CompletableFuture<String> oldLoading = new CompletableFuture<>();
        AtomicInteger loads = new AtomicInteger(), failureLoads = new AtomicInteger();
        ObjectNode out = Json.newObject();
        try {
            List<Future<CompletionStage<String>>> invocations = new ArrayList<>();
            for (int i = 0; i < 4; i++) invocations.add(callers.submit(() -> {
                ready.countDown(); await(start);
                return cache.getOrElseUpdate(cold, () -> { loads.incrementAndGet(); return loading; }, 10);
            }));
            await(ready); start.countDown();
            List<CompletionStage<String>> stages = new ArrayList<>();
            for (Future<CompletionStage<String>> invocation : invocations) stages.add(get(invocation));
            out.put("coldCallers", stages.size()).put("loadsBeforeRelease", loads.get())
                    .put("callersDoneBeforeRelease", stages.stream().filter(stage -> stage.toCompletableFuture().isDone()).count());
            loading.complete("loaded");
            int completed = 0;
            for (CompletionStage<String> stage : stages) if ("loaded".equals(get(stage.toCompletableFuture()))) completed++;
            out.put("coldCompleted", completed);
            String hot = get(cache.getOrElseUpdate(cold, () -> {
                loads.incrementAndGet(); return CompletableFuture.completedFuture("unexpected");
            }, 10).toCompletableFuture());
            out.put("hotValue", hot).put("loadsAfterHot", loads.get());
            CompletionStage<String> failed = cache.getOrElseUpdate(failure, () -> {
                failureLoads.incrementAndGet(); return CompletableFuture.failedFuture(new IllegalStateException("synthetic cache load"));
            }, 10);
            out.put("failedLoadOutcome", TimeoutLab.outcome(failed));
            boolean removed = waitUntilMissing(failure, 3000);
            out.put("failedEntryRemoved", removed);
            String reloaded = get(cache.getOrElseUpdate(failure, () -> {
                failureLoads.incrementAndGet(); return CompletableFuture.completedFuture("reloaded");
            }, 10).toCompletableFuture());
            out.put("reloadValue", reloaded).put("failureLoaderCalls", failureLoads.get());
            get(cache.set(ttl, "short", 1).toCompletableFuture());
            get(cache.set(forever, "zero", 0).toCompletableFuture());
            out.put("ttlInitiallyPresent", get(cache.get(ttl).toCompletableFuture()).isPresent());
            long before = System.nanoTime();
            out.put("ttlExpired", waitUntilMissing(ttl, 4000));
            out.put("ttlObservedMillis", TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - before));
            out.put("zeroPresentAfterTtlExpired", get(cache.get(forever).toCompletableFuture()).isPresent());
            get(cache.set(alice, "alice-private", 10).toCompletableFuture());
            get(cache.set(bob, "bob-private", 10).toCompletableFuture());
            out.put("aliceValue", get(cache.<String>get(alice).toCompletableFuture()).orElse("missing"));
            out.put("bobValue", get(cache.<String>get(bob).toCompletableFuture()).orElse("missing"));
            get(cache.set(version, "v1", 10).toCompletableFuture());
            out.put("beforeUpdateVersion", get(cache.<String>get(version).toCompletableFuture()).orElse("missing"));
            get(cache.set(version, "v2", 10).toCompletableFuture());
            out.put("afterUpdateVersion", get(cache.<String>get(version).toCompletableFuture()).orElse("missing"));
            AtomicInteger oldLoaderCalls = new AtomicInteger();
            CountDownLatch oldLoaderStarted = new CountDownLatch(1);
            CompletionStage<String> oldReader = cache.getOrElseUpdate(late, () -> {
                oldLoaderCalls.incrementAndGet(); oldLoaderStarted.countDown(); return oldLoading;
            }, 10);
            await(oldLoaderStarted);
            get(cache.set(late, "new-v2", 10).toCompletableFuture());
            out.put("oldReaderDoneAfterNewSet", oldReader.toCompletableFuture().isDone());
            out.put("cacheAfterNewSet", get(cache.<String>get(late).toCompletableFuture()).orElse("missing"));
            oldLoading.complete("old-v1");
            out.put("oldReaderLateValue", get(oldReader.toCompletableFuture()));
            out.put("cacheAfterOldLoaderCompletes", get(cache.<String>get(late).toCompletableFuture()).orElse("missing"));
            out.put("oldLoaderCalls", oldLoaderCalls.get());
        } finally {
            start.countDown(); loading.complete("cleanup"); oldLoading.complete("cleanup"); close(callers);
            for (String key : keys) get(cache.remove(key).toCompletableFuture());
        }
        boolean removed = true;
        for (String key : keys) removed &= get(cache.get(key).toCompletableFuture()).isEmpty();
        return out.put("allExperimentKeysRemoved", removed).put("callersTerminated", callers.isTerminated());
    }

    private boolean waitUntilMissing(String key, long budgetMillis) {
        long deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(budgetMillis);
        do {
            try { if (get(cache.get(key).toCompletableFuture()).isEmpty()) return true; }
            catch (IllegalStateException failedFutureStillPresent) {
                if (!(failedFutureStillPresent.getCause() instanceof ExecutionException completedFailure)
                        || !(completedFailure.getCause() instanceof IllegalStateException))
                    throw failedFutureStillPresent;
            }
            try { Thread.sleep(25); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IllegalStateException(e); }
        } while (System.nanoTime() < deadline);
        return false;
    }
}
