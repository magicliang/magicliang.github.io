package labbudget;

import static labasync.LabSupport.*;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Set;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import play.libs.Json;
import play.libs.ws.WSResponse;
import play.libs.ws.ahc.AhcWSClient;

final class WsDeadlineLab implements AutoCloseable {
    private final AhcWSClient client;
    private final URI origin;
    private final Set<String> allowlist;
    private final AtomicInteger handlersStarted;
    private final ExecutorService caller = single("lab-ws-deadline-caller");
    private final ScheduledExecutorService timer = Executors.newSingleThreadScheduledExecutor(
            Thread.ofPlatform().name("lab-ws-deadline-timer").factory());
    private final DeadlineGate shortFirst = new DeadlineGate("/deadline-short/second"), shortSecond = new DeadlineGate(null);
    private final DeadlineGate enoughFirst = new DeadlineGate("/deadline-enough/second"), enoughSecond = new DeadlineGate(null);
    private final DeadlineGate[] gates = {shortFirst, shortSecond, enoughFirst, enoughSecond};
    private Future<ObjectNode> shortTask;

    WsDeadlineLab(AhcWSClient client, HttpServer server, Set<String> allowlist,
                  AtomicInteger started, AtomicInteger finished) {
        this.client = client; this.allowlist = allowlist; this.handlersStarted = started;
        origin = URI.create("http://127.0.0.1:" + server.getAddress().getPort());
        server.createContext("/deadline-short/first", exchange -> shortFirst.handle(exchange, started, finished));
        server.createContext("/deadline-short/second", exchange -> shortSecond.handle(exchange, started, finished));
        server.createContext("/deadline-enough/first", exchange -> enoughFirst.handle(exchange, started, finished));
        server.createContext("/deadline-enough/second", exchange -> enoughSecond.handle(exchange, started, finished));
    }

    ObjectNode run(boolean interruptAtSecondHop) {
        ObjectNode out = Json.newObject().put("perRequestCapMillis", 3000);
        int beforeExpired = handlersStarted.get();
        out.set("alreadyExpired", fetchAllowedUntil(client, origin.resolve("/ok"), allowlist, System.nanoTime() - 1));
        out.put("handlersForAlreadyExpired", handlersStarted.get() - beforeExpired);
        long shortDeadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(1);
        shortTask = caller.submit(() -> fetchAllowedUntil(client,
                origin.resolve("/deadline-short/first"), allowlist, shortDeadline));
        await(shortFirst.entered);
        scheduleRelease(shortFirst, 150);
        await(shortSecond.entered);
        scheduleRelease(shortSecond, 1350);
        if (interruptAtSecondHop) Thread.currentThread().interrupt();
        ObjectNode timedOut = get(shortTask);
        timedOut.put("totalBudgetMillis", 1000).put("secondReleaseDelayMillis", 1350)
                .put("secondEnteredBeforeOutcome", shortSecond.entered.getCount() == 0)
                .put("secondReleasedBeforeOutcome", shortSecond.release.getCount() == 0)
                .put("secondDoneBeforeOutcome", shortSecond.done.isDone());
        timedOut.put("firstHandlerTerminal", get(shortFirst.done)).put("secondHandlerTerminal", get(shortSecond.done))
                .put("secondIndependentlyReleased", shortSecond.independentlyReleased)
                .put("secondReleaseAfterEnteredMillis",
                        TimeUnit.NANOSECONDS.toMillis(shortSecond.releasedNanos - shortSecond.enteredNanos));
        out.set("exceededAcrossHops", timedOut);
        long enoughDeadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(3);
        Future<ObjectNode> enoughTask = caller.submit(() -> fetchAllowedUntil(client,
                origin.resolve("/deadline-enough/first"), allowlist, enoughDeadline));
        await(enoughFirst.entered);
        scheduleRelease(enoughFirst, 150);
        await(enoughSecond.entered);
        scheduleRelease(enoughSecond, 150);
        ObjectNode enough = get(enoughTask).put("totalBudgetMillis", 3000)
                .put("firstHandlerTerminal", get(enoughFirst.done)).put("secondHandlerTerminal", get(enoughSecond.done));
        out.set("enoughAcrossHops", enough);
        out.put("allFourHandlersDone", java.util.Arrays.stream(gates).allMatch(gate -> gate.done.isDone()));
        return out;
    }

    private void scheduleRelease(DeadlineGate gate, long delayMillis) {
        timer.schedule(() -> {
            gate.releasedNanos = System.nanoTime();
            gate.independentlyReleased = true;
            gate.release.countDown();
        }, delayMillis, TimeUnit.MILLISECONDS);
    }

    @Override public void close() throws Exception {
        for (DeadlineGate gate : gates) gate.release.countDown();
        try (AutoCloseable timerClose = () -> labasync.LabSupport.close(timer);
             AutoCloseable callerClose = () -> labasync.LabSupport.close(caller)) {
        }
    }

    void recordCleanup(ObjectNode out) {
        out.put("deadlineCallerTerminated", caller.isTerminated()).put("deadlineTimerTerminated", timer.isTerminated())
                .put("deadlineShortTaskDone", shortTask != null && shortTask.isDone())
                .put("deadlineShortTaskCancelled", shortTask != null && shortTask.isCancelled())
                .put("deadlineSecondEntered", shortSecond.entered.getCount() == 0)
                .put("deadlineEnteredHandlersDone", java.util.Arrays.stream(gates)
                        .filter(gate -> gate.entered.getCount() == 0).allMatch(gate -> gate.done.isDone()));
    }

    private ObjectNode fetchAllowedUntil(AhcWSClient client, URI initial, Set<String> allowlist, long deadlineNanos) {
        URI next = initial;
        int requests = 0;
        long started = System.nanoTime();
        ObjectNode out = Json.newObject();
        ArrayNode remaining = out.putArray("remainingMillisBeforeRequests");
        ArrayNode timeouts = out.putArray("requestTimeoutMillis");
        ArrayNode statuses = out.putArray("responseStatuses");
        try {
            for (int hop = 0; hop < 3; hop++) {
                String origin = next.getScheme() + "://" + next.getHost() + ":" + next.getPort();
                if (!allowlist.contains(origin) || next.getUserInfo() != null)
                    return out.put("outcome", "REJECTED_TARGET");
                long remainingMillis = TimeUnit.NANOSECONDS.toMillis(deadlineNanos - System.nanoTime());
                // A sub-millisecond remainder cannot become AHC's zero-millisecond timeout.
                if (remainingMillis <= 0) return out.put("outcome", "DEADLINE_EXHAUSTED");
                long timeoutMillis = Math.min(3000, remainingMillis);
                var request = client.url(next.toString()).setFollowRedirects(false)
                        .setRequestTimeout(Duration.ofMillis(timeoutMillis));
                if (deadlineNanos - System.nanoTime() <= 0) return out.put("outcome", "DEADLINE_EXHAUSTED");
                remaining.add(remainingMillis);
                timeouts.add(timeoutMillis);
                requests++;
                WSResponse response;
                try { response = get(request.get().toCompletableFuture()); }
                catch (RuntimeException error) {
                    Throwable cause = error;
                    while (cause.getCause() != null) cause = cause.getCause();
                    if (!(cause instanceof TimeoutException)) throw error;
                    return out.put("outcome", "TIMEOUT").put("failureClass", cause.getClass().getSimpleName());
                }
                statuses.add(response.getStatus());
                if (deadlineNanos - System.nanoTime() <= 0) return out.put("outcome", "DEADLINE_EXHAUSTED");
                if (response.getStatus() < 300 || response.getStatus() >= 400)
                    return out.put("outcome", "OK").put("status", response.getStatus()).put("body", response.getBody());
                next = next.resolve(response.getSingleHeader("Location").orElseThrow());
            }
            return out.put("outcome", "REDIRECT_LIMIT");
        } finally {
            out.put("requestsSent", requests)
                    .put("elapsedMillis", TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - started))
                    .put("remainingNanosAtTerminal", deadlineNanos - System.nanoTime());
        }
    }

    private static final class DeadlineGate {
        final CountDownLatch entered = new CountDownLatch(1), release = new CountDownLatch(1);
        final CompletableFuture<String> done = new CompletableFuture<>();
        final String redirect;
        volatile long enteredNanos, releasedNanos;
        volatile boolean independentlyReleased;
        DeadlineGate(String redirect) { this.redirect = redirect; }
        void handle(HttpExchange exchange, AtomicInteger started, AtomicInteger finished) {
            started.incrementAndGet();
            String terminal = "completed";
            try {
                enteredNanos = System.nanoTime();
                entered.countDown();
                await(release);
                if (redirect != null) {
                    exchange.getResponseHeaders().set("Location", redirect);
                    exchange.sendResponseHeaders(302, -1);
                } else {
                    byte[] bytes = "deadline-ok".getBytes(StandardCharsets.UTF_8);
                    exchange.sendResponseHeaders(200, bytes.length);
                    exchange.getResponseBody().write(bytes);
                }
            } catch (IOException error) { terminal = error.getClass().getSimpleName(); }
            catch (RuntimeException error) { terminal = error.getClass().getSimpleName(); }
            finally { entered.countDown(); exchange.close(); finished.incrementAndGet(); done.complete(terminal); }
        }
    }

}
