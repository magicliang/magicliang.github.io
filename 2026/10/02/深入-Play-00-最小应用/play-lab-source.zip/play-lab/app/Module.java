import com.google.inject.AbstractModule;
import services.ConfiguredInventoryService;
import services.InventoryService;

public final class Module extends AbstractModule {
    @Override
    protected void configure() {
        bind(InventoryService.class).to(ConfiguredInventoryService.class);
    }
}
