package labdb;

import com.typesafe.config.Config;
import jakarta.inject.Inject;
import java.sql.*;
import java.util.Map;
import java.util.UUID;
import play.db.Database;
import play.db.Databases;

public final class DbAccess {
    private final Config config;
    @Inject public DbAccess(Config config) { this.config = config; }
    public boolean enabled() { return config.getBoolean("lab.db.enabled"); }
    public static void shutdown(Database db, Throwable primary) {
        boolean interrupted = Thread.interrupted();
        try { db.shutdown(); }
        catch (RuntimeException | Error error) { if (primary != null) primary.addSuppressed(error); else throw error; }
        finally { if (interrupted) Thread.currentThread().interrupt(); }
    }
    public Database open(String suffix, int size, long borrowMillis) {
        if (!enabled()) throw new IllegalStateException("DB experiment disabled");
        return Databases.createFrom("lab-" + suffix + "-" + UUID.randomUUID(), "org.postgresql.Driver",
                config.getString("lab.db.url"), Map.of("username", config.getString("lab.db.user"),
                "password", config.getString("lab.db.password"), "hikaricp.maximumPoolSize", size,
                "hikaricp.minimumIdle", size, "hikaricp.connectionTimeout", borrowMillis + "ms"));
    }
    public Connection observer() throws SQLException {
        return DriverManager.getConnection(config.getString("lab.db.url"), config.getString("lab.db.user"), config.getString("lab.db.password"));
    }
    public static void execute(Connection connection, String sql) throws SQLException {
        try (Statement statement = connection.createStatement()) { statement.setQueryTimeout(5); statement.execute(sql); }
    }
    public static long scalar(Connection connection, String sql) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.setQueryTimeout(5);
            try (ResultSet rows = statement.executeQuery(sql)) { rows.next(); return rows.getLong(1); }
        }
    }
    public static String state(Throwable error) {
        while (error.getCause() != null && !(error instanceof SQLException)) error = error.getCause();
        return error instanceof SQLException sql ? String.valueOf(sql.getSQLState()) : error.getClass().getSimpleName();
    }
}
