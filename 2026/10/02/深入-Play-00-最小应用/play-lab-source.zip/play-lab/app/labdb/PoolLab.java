package labdb;

import static labasync.LabSupport.*;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.zaxxer.hikari.HikariDataSource;
import jakarta.inject.Inject;
import java.sql.Connection;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import labasync.LabExecutionContext;
import org.apache.pekko.actor.ActorSystem;
import play.db.Database;
import play.libs.Json;

public final class PoolLab {
    private final DbAccess access;
    private final ActorSystem system;
    private final LabExecutionContext dedicated;
    @Inject public PoolLab(DbAccess access, ActorSystem system, LabExecutionContext dedicated) {
        this.access = access; this.system = system; this.dedicated = dedicated;
    }
    public ObjectNode run() {
        ObjectNode out = Json.newObject();
        out.set("executor4", pressure(4)); out.set("executor2", pressure(2));
        out.set("recovery", recovery());
        out.set("defaultSql", sqlPosition(system.dispatcher()));
        out.set("dedicatedSql", sqlPosition(dedicated.current()));
        return out;
    }

    private ObjectNode pressure(int threads) {
        Database db = access.open("pool", 2, 3500);
        HikariDataSource hikari = (HikariDataSource) db.getDataSource();
        ThreadPoolExecutor executor = new ThreadPoolExecutor(threads, threads, 0, TimeUnit.SECONDS,
                new ArrayBlockingQueue<>(4), Thread.ofPlatform().name("lab-jdbc-" + threads + "-", 0).factory());
        String marker = "pool_" + UUID.randomUUID().toString().replace("-", "");
        List<CompletableFuture<ObjectNode>> tasks = new ArrayList<>();
        long zero = System.nanoTime();
        Throwable failure = null;
        try {
            for (int i = 0; i < 2; i++) tasks.add(query(db, executor, marker, zero, i));
            poll(() -> {
                try (Connection observer = access.observer()) {
                    return DbAccess.scalar(observer, "SELECT count(*) FROM pg_stat_activity WHERE wait_event='PgSleep' AND query LIKE '%" + marker + "%' AND pid<>pg_backend_pid()") == 2;
                } catch (Exception error) { throw new IllegalStateException(error); }
            });
            for (int i = 2; i < 4; i++) tasks.add(query(db, executor, marker, zero, i));
            poll(() -> threads == 4 ? hikari.getHikariPoolMXBean().getThreadsAwaitingConnection() == 2 : executor.getQueue().size() == 2);
            ObjectNode out = Json.newObject().put("executorThreads", threads).put("poolMaximum", hikari.getMaximumPoolSize())
                    .put("sqlRunningAtSnapshot", 2).put("activeConnections", hikari.getHikariPoolMXBean().getActiveConnections())
                    .put("waitingForConnection", hikari.getHikariPoolMXBean().getThreadsAwaitingConnection()).put("executorQueued", executor.getQueue().size());
            ArrayNode rows = out.putArray("tasks"); for (CompletableFuture<ObjectNode> task : tasks) rows.add(get(task));
            out.put("activeAfterTasks", hikari.getHikariPoolMXBean().getActiveConnections());
            return out;
        } catch (RuntimeException | Error error) { failure = error; throw error; }
        finally { closeExperiment(executor, db, failure); }
    }

    private void closeExperiment(ExecutorService executor, Database db, Throwable primary) {
        Throwable failure = primary;
        boolean interrupted = Thread.currentThread().isInterrupted();
        try { close(executor); }
        catch (RuntimeException | Error error) { if (failure == null) failure = error; else failure.addSuppressed(error); }
        finally {
            interrupted |= Thread.interrupted();
            try { db.shutdown(); }
            catch (RuntimeException | Error error) { if (failure == null) failure = error; else failure.addSuppressed(error); }
            finally {
                try {
                    if (!executor.awaitTermination(5, TimeUnit.SECONDS)) throw new IllegalStateException("executor remained alive after DB shutdown");
                } catch (InterruptedException error) {
                    interrupted = true;
                    if (failure == null) failure = new IllegalStateException(error); else failure.addSuppressed(error);
                } catch (RuntimeException | Error error) {
                    if (failure == null) failure = error; else failure.addSuppressed(error);
                } finally { if (interrupted) Thread.currentThread().interrupt(); }
            }
        }
        if (primary == null && failure != null) {
            if (failure instanceof Error error) throw error;
            throw (RuntimeException) failure;
        }
    }

    public ObjectNode interruptedCleanup() {
        return get(CompletableFuture.supplyAsync(() -> {
            Database db = access.open("interrupted", 2, 1000);
            HikariDataSource hikari = (HikariDataSource) db.getDataSource();
            long selectOne;
            try (Connection connection = db.getConnection()) { selectOne = DbAccess.scalar(connection, "SELECT 1"); }
            catch (Exception error) { DbAccess.shutdown(db, error); throw new IllegalStateException(error); }
            ExecutorService executor = single("db-interrupted-worker");
            CountDownLatch started = new CountDownLatch(1);
            executor.submit(() -> { started.countDown(); try { Thread.sleep(4000); } catch (InterruptedException expected) { Thread.currentThread().interrupt(); } });
            IllegalStateException primary = new IllegalStateException("synthetic primary failure");
            Throwable observed = null;
            try { await(started); Thread.currentThread().interrupt(); throw primary; }
            catch (RuntimeException | Error error) { observed = error; }
            finally { closeExperiment(executor, db, observed); }
            if (observed != primary) throw new IllegalStateException("unexpected primary", observed);
            return Json.newObject().put("selectOneBeforeInterrupt", selectOne).put("primary", primary.getMessage()).put("suppressed", primary.getSuppressed().length)
                    .put("interrupted", Thread.currentThread().isInterrupted()).put("poolClosed", hikari.isClosed()).put("executorTerminated", executor.isTerminated());
        }, runnable -> Thread.ofPlatform().name("db-interrupted-driver").start(runnable)));
    }

    public CompletionStage<ObjectNode> load(boolean useDedicated) {
        Executor target = useDedicated ? dedicated.current() : system.dispatcher();
        return CompletableFuture.supplyAsync(() -> {
            Database db = access.open("load", 2, 1000);
            long zero = System.nanoTime();
            String marker = "jdbc_load_" + UUID.randomUUID().toString().replace("-", "");
            Throwable primary = null;
            try {
                List<CompletableFuture<ObjectNode>> tasks = new ArrayList<>();
                for (int index = 0; index < 2; index++) {
                    long submitted = elapsed(zero);
                    tasks.add(CompletableFuture.supplyAsync(() -> {
                        ObjectNode row = Json.newObject().put("submittedMicros", submitted).put("startedMicros", elapsed(zero)).put("thread", Thread.currentThread().getName());
                        try (Connection connection = db.getConnection()) {
                            row.put("borrowedMicros", elapsed(zero));
                            DbAccess.execute(connection, "SELECT pg_sleep(2) /* " + marker + " */");
                            row.put("sqlFinishedMicros", elapsed(zero)).put("selectOne", DbAccess.scalar(connection, "SELECT 1"));
                        } catch (Exception error) { throw new IllegalStateException(error); }
                        return row.put("returnedMicros", elapsed(zero));
                    }, target));
                }
                ObjectNode out = Json.newObject().put("dedicated", useDedicated).put("marker", marker)
                        .put("configuredDefaultMin", system.settings().config().getInt("pekko.actor.default-dispatcher.fork-join-executor.parallelism-min"))
                        .put("configuredDefaultMax", system.settings().config().getInt("pekko.actor.default-dispatcher.fork-join-executor.parallelism-max"));
                ArrayNode rows = out.putArray("tasks"); for (var task : tasks) rows.add(get(task)); return out;
            } catch (RuntimeException | Error error) { primary = error; throw error; }
            finally { DbAccess.shutdown(db, primary); }
        }, runnable -> Thread.ofPlatform().name("db-load-driver").start(runnable));
    }

    private CompletableFuture<ObjectNode> query(Database db, Executor executor, String marker, long zero, int index) {
        ObjectNode row = Json.newObject().put("id", index).put("submittedMicros", elapsed(zero));
        return CompletableFuture.supplyAsync(() -> {
            row.put("startedMicros", elapsed(zero)).put("thread", Thread.currentThread().getName()).put("borrowStartedMicros", elapsed(zero));
            try (Connection connection = db.getConnection()) {
                row.put("borrowedMicros", elapsed(zero)).put("sqlStartedMicros", elapsed(zero));
                DbAccess.execute(connection, "SELECT pg_sleep(1.5) /* " + marker + " */");
                row.put("sqlFinishedMicros", elapsed(zero)).put("outcome", "ok");
            } catch (Exception error) { row.put("outcome", DbAccess.state(error)); }
            return row.put("returnedMicros", elapsed(zero));
        }, executor);
    }

    private ObjectNode recovery() {
        Database db = access.open("recovery", 2, 300);
        HikariDataSource hikari = (HikariDataSource) db.getDataSource();
        ObjectNode out = Json.newObject();
        Throwable primary = null;
        try {
            poll(() -> hikari.getHikariPoolMXBean().getIdleConnections() == 2);
            try (Connection first = db.getConnection(); Connection second = db.getConnection()) {
                try (Connection unexpected = db.getConnection()) { out.put("borrowTimeout", "unexpected-success"); }
                catch (Exception error) { out.put("borrowTimeout", error.getClass().getSimpleName()); }
            }
            try (Connection connection = db.getConnection()) { DbAccess.execute(connection, "SELECT 1/0"); }
            catch (Exception error) { out.put("sqlError", DbAccess.state(error)); }
            try (Connection connection = db.getConnection()) { throw new IllegalStateException("synthetic application failure"); }
            catch (Exception error) { out.put("applicationError", error.getClass().getSimpleName()); }
            try (Connection connection = db.getConnection()) { out.put("selectOneAfterFailures", DbAccess.scalar(connection, "SELECT 1")); }
            return out.put("activeAfterFailures", hikari.getHikariPoolMXBean().getActiveConnections());
        } catch (Exception error) { primary = error; throw new IllegalStateException(error); }
        catch (Error error) { primary = error; throw error; }
        finally { DbAccess.shutdown(db, primary); }
    }

    public ObjectNode sqlPosition(Executor executor) {
        Database db = access.open("position", 2, 1000);
        Throwable primary = null;
        try {
            return get(CompletableFuture.supplyAsync(() -> {
                try (Connection connection = db.getConnection()) {
                    DbAccess.execute(connection, "SELECT pg_sleep(1.0)");
                    return Json.newObject().put("thread", Thread.currentThread().getName()).put("selectOne", DbAccess.scalar(connection, "SELECT 1"));
                } catch (Exception error) { throw new IllegalStateException(error); }
            }, executor));
        } catch (RuntimeException | Error error) { primary = error; throw error; }
        finally { DbAccess.shutdown(db, primary); }
    }
    public CompletionStage<ObjectNode> placement(boolean useDedicated) {
        Executor executor = useDedicated ? dedicated.current() : system.dispatcher();
        return CompletableFuture.supplyAsync(() -> sqlPosition(executor), runnable -> Thread.ofPlatform().name("db-position-driver").start(runnable));
    }
    public static void poll(java.util.function.BooleanSupplier condition) {
        long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(5);
        while (!condition.getAsBoolean()) {
            if (System.nanoTime() > deadline) throw new IllegalStateException("DB observation timeout");
            try { Thread.sleep(10); } catch (InterruptedException error) { Thread.currentThread().interrupt(); throw new IllegalStateException(error); }
        }
    }
    private static long elapsed(long zero) { return TimeUnit.NANOSECONDS.toMicros(System.nanoTime() - zero); }
}
