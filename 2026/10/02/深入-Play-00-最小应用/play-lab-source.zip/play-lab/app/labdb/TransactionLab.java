package labdb;

import static labasync.LabSupport.*;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.inject.Inject;
import java.sql.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import play.db.Database;
import play.libs.Json;
import play.libs.concurrent.Futures;

public final class TransactionLab {
    private final DbAccess access;
    private final Futures futures;
    @Inject public TransactionLab(DbAccess access, Futures futures) { this.access = access; this.futures = futures; }

    public ObjectNode prepareOrder() {
        Database db = access.open("http-order", 2, 2000);
        String id = UUID.randomUUID().toString().replace("-", "");
        Throwable primary = null;
        try { schema(db); stock(db, id, 1); return Json.newObject().put("id", id).put("stock", 1); }
        catch (RuntimeException | Error error) { primary = error; throw error; }
        finally { DbAccess.shutdown(db, primary); }
    }
    public ObjectNode submitOrder(String id, String key, String payload) {
        if (!id.matches("[a-f0-9]{32}") || !key.matches("[A-Za-z0-9_-]{1,40}") || payload.length() > 80) throw new IllegalArgumentException("invalid synthetic order");
        Database db = access.open("http-order", 2, 2000);
        Throwable primary = null;
        try {
            String outcome = purchase(db, id, key, payload, id, false);
            ObjectNode out = state(db, id, id).put("outcome", outcome);
            return out;
        } catch (RuntimeException | Error error) { primary = error; throw error; }
        finally { DbAccess.shutdown(db, primary); }
    }

    public static void schema(Database db) {
        db.withConnection(connection -> {
            DbAccess.execute(connection, "CREATE TABLE IF NOT EXISTS lab_inventory(sku text PRIMARY KEY, remaining integer NOT NULL CHECK(remaining>=0))");
            DbAccess.execute(connection, "CREATE TABLE IF NOT EXISTS lab_orders(tenant text NOT NULL, idempotency_key text NOT NULL, payload text NOT NULL, sku text NOT NULL, PRIMARY KEY(tenant,idempotency_key))");
            return null;
        });
    }

    public static String purchase(Database db, String tenant, String key, String payload, String sku, boolean fail) {
        try {
            return db.withTransaction(connection -> {
                int inserted;
                try (PreparedStatement statement = connection.prepareStatement("INSERT INTO lab_orders VALUES(?,?,?,?) ON CONFLICT(tenant,idempotency_key) DO NOTHING")) {
                    statement.setQueryTimeout(5); statement.setString(1, tenant); statement.setString(2, key); statement.setString(3, payload); statement.setString(4, sku);
                    inserted = statement.executeUpdate();
                }
                if (inserted == 0) {
                    try (PreparedStatement statement = connection.prepareStatement("SELECT payload FROM lab_orders WHERE tenant=? AND idempotency_key=?")) {
                        statement.setQueryTimeout(5); statement.setString(1, tenant); statement.setString(2, key);
                        try (ResultSet rows = statement.executeQuery()) { rows.next(); return rows.getString(1).equals(payload) ? "REPLAY" : "CONFLICT"; }
                    }
                }
                try (PreparedStatement statement = connection.prepareStatement("UPDATE lab_inventory SET remaining=remaining-1 WHERE sku=? AND remaining>0")) {
                    statement.setQueryTimeout(5); statement.setString(1, sku); if (statement.executeUpdate() != 1) throw new StockConflict();
                }
                if (fail) throw new IllegalStateException("synthetic rollback after inventory update");
                return "CREATED";
            });
        } catch (StockConflict conflict) { return "CONFLICT"; }
    }

    public ObjectNode run() {
        Database db = access.open("transactions", 2, 2000);
        ExecutorService workers = Executors.newFixedThreadPool(2, Thread.ofPlatform().name("lab-tx-", 0).factory());
        String run = UUID.randomUUID().toString();
        Throwable primary = null;
        try {
            schema(db);
            ObjectNode out = Json.newObject().put("run", run);
            stock(db, run + "-success", 2);
            out.put("success", purchase(db, run, "success", "p", run + "-success", false));
            out.set("successState", state(db, run, run + "-success"));
            stock(db, run + "-rollback", 1);
            try { purchase(db, run, "rollback", "p", run + "-rollback", true); }
            catch (IllegalStateException expected) { out.put("rollbackError", expected.getClass().getSimpleName()); }
            out.set("rollbackState", state(db, run, run + "-rollback"));
            stock(db, run + "-same", 1);
            out.set("sameKeyResults", Json.toJson(compete(workers,
                    () -> purchase(db, run, "same", "p", run + "-same", false),
                    () -> purchase(db, run, "same", "p", run + "-same", false))));
            out.set("sameKeyState", state(db, run, run + "-same"));
            out.put("changedPayload", purchase(db, run, "same", "different", run + "-same", false));
            stock(db, run + "-different", 1);
            out.set("differentKeyResults", Json.toJson(compete(workers,
                    () -> purchase(db, run, "a", "p", run + "-different", false),
                    () -> purchase(db, run, "b", "p", run + "-different", false))));
            out.set("differentKeyState", state(db, run, run + "-different"));
            stock(db, run + "-tenants", 2);
            out.put("tenantOne", purchase(db, run, "tenant-key", "p", run + "-tenants", false));
            out.put("tenantTwo", purchase(db, run + "-other", "tenant-key", "p", run + "-tenants", false));
            out.set("scope", scope(db, workers, run));
            out.set("lateCommit", lateCommit(db, workers, run));
            out.set("statementTimeout", statementTimeout(db, run));
            return out;
        } catch (RuntimeException | Error error) { primary = error; throw error; }
        finally {
            Throwable cleanup = null;
            boolean interrupted = Thread.currentThread().isInterrupted();
            try { close(workers); }
            catch (RuntimeException | Error error) { cleanup = error; }
            finally {
                interrupted |= Thread.interrupted();
                try { db.shutdown(); }
                catch (RuntimeException | Error error) { if (cleanup == null) cleanup = error; else cleanup.addSuppressed(error); }
                finally { if (interrupted) Thread.currentThread().interrupt(); }
            }
            if (cleanup != null) {
                if (primary != null) primary.addSuppressed(cleanup);
                else if (cleanup instanceof Error error) throw error;
                else throw (RuntimeException) cleanup;
            }
        }
    }

    private ObjectNode scope(Database db, Executor executor, String run) {
        CountDownLatch release = new CountDownLatch(1);
        try {
            CompletionStage<String> pending = db.withTransaction(connection -> {
                DbAccess.execute(connection, "INSERT INTO lab_inventory VALUES('" + run + "-scope',1)");
                return CompletableFuture.supplyAsync(() -> {
                    await(release);
                    try { DbAccess.scalar(connection, "SELECT 1"); return "unexpected-success"; }
                    catch (SQLException error) { return error.getSQLState() + ":closed=" + closed(connection); }
                }, executor);
            });
            ObjectNode out = Json.newObject().put("stageDoneAfterTransactionReturned", pending.toCompletableFuture().isDone());
            try (Connection observer = access.observer()) {
                out.put("committedBeforeStageRelease", DbAccess.scalar(observer, "SELECT count(*) FROM lab_inventory WHERE sku='" + run + "-scope'"));
            }
            release.countDown(); return out.put("asyncConnectionOutcome", get(pending.toCompletableFuture()));
        } catch (SQLException error) { throw new IllegalStateException(error); }
        finally { release.countDown(); }
    }

    private ObjectNode lateCommit(Database db, Executor executor, String run) {
        String sku = run + "-late"; stock(db, sku, 1);
        CountDownLatch transactionOpen = new CountDownLatch(1), release = new CountDownLatch(1);
        try {
            CompletableFuture<String> task = CompletableFuture.supplyAsync(() -> db.withTransaction(connection -> {
                try (PreparedStatement statement = connection.prepareStatement("INSERT INTO lab_orders VALUES(?,?,?,?)")) {
                    statement.setQueryTimeout(5); statement.setString(1, run); statement.setString(2, "late"); statement.setString(3, "p"); statement.setString(4, sku); statement.executeUpdate();
                }
                DbAccess.execute(connection, "UPDATE lab_inventory SET remaining=0 WHERE sku='" + sku + "'");
                transactionOpen.countDown(); await(release); return "committed";
            }), executor);
            await(transactionOpen);
            String outcome = get(futures.timeout(task, Duration.ofMillis(100)).handle((value, error) -> error == null ? value : "TIMEOUT").toCompletableFuture());
            ObjectNode out = Json.newObject().put("responseOutcome", outcome).put("taskDoneAtTimeout", task.isDone());
            try (Connection observer = access.observer()) {
                out.put("ordersAtTimeout", DbAccess.scalar(observer, "SELECT count(*) FROM lab_orders WHERE tenant='" + run + "' AND idempotency_key='late'"));
            }
            release.countDown(); out.put("taskTerminal", get(task));
            try (Connection observer = access.observer()) {
                out.put("ordersAfterLateCommit", DbAccess.scalar(observer, "SELECT count(*) FROM lab_orders WHERE tenant='" + run + "' AND idempotency_key='late'"));
            }
            out.put("retryByKey", purchase(db, run, "late", "p", sku, false));
            return out.set("finalState", state(db, run, sku));
        } catch (SQLException error) { throw new IllegalStateException(error); }
        finally { release.countDown(); }
    }

    private ObjectNode statementTimeout(Database db, String run) {
        String sku = run + "-statement"; stock(db, sku, 1); ObjectNode out = Json.newObject();
        try {
            db.withTransaction(connection -> {
                DbAccess.execute(connection, "SET LOCAL statement_timeout='100ms'");
                DbAccess.execute(connection, "UPDATE lab_inventory SET remaining=0 WHERE sku='" + sku + "'");
                DbAccess.execute(connection, "SELECT pg_sleep(2)"); return null;
            });
        } catch (RuntimeException error) { out.put("sqlState", DbAccess.state(error)); }
        return out.set("stateAfterFailure", state(db, run, sku));
    }

    private List<String> compete(ExecutorService workers, Callable<String> first, Callable<String> second) {
        CountDownLatch ready = new CountDownLatch(2), start = new CountDownLatch(1);
        List<Future<String>> tasks = new ArrayList<>();
        try {
            for (Callable<String> operation : List.of(first, second)) tasks.add(workers.submit(() -> { ready.countDown(); await(start); return operation.call(); }));
            await(ready); start.countDown(); List<String> values = new ArrayList<>(); for (Future<String> task : tasks) values.add(get(task)); return values;
        } finally { start.countDown(); }
    }
    public static void stock(Database db, String sku, int quantity) {
        db.withConnection(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("INSERT INTO lab_inventory VALUES(?,?)")) {
                statement.setQueryTimeout(5); statement.setString(1, sku); statement.setInt(2, quantity); statement.executeUpdate();
            } return null;
        });
    }
    public static ObjectNode state(Database db, String tenant, String sku) {
        return db.withConnection(connection -> { return Json.newObject()
                .put("orders", DbAccess.scalar(connection, "SELECT count(*) FROM lab_orders WHERE sku='" + sku + "'"))
                .put("remaining", DbAccess.scalar(connection, "SELECT remaining FROM lab_inventory WHERE sku='" + sku + "'")); });
    }
    private static boolean closed(Connection connection) { try { return connection.isClosed(); } catch (SQLException error) { return true; } }
    private static final class StockConflict extends RuntimeException {}
}
