package labdb;

import static labasync.LabSupport.*;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import java.util.UUID;
import java.util.concurrent.*;
import play.db.Database;
import play.inject.ApplicationLifecycle;
import play.libs.Json;
import play.libs.concurrent.Futures;

@Singleton
public final class LateCommitLab {
    private final DbAccess access;
    private final Futures futures;
    private final ConcurrentMap<String, Job> jobs = new ConcurrentHashMap<>();
    private final ExecutorService worker = single("db-late-commit");
    private static final class Job {
        final String id = UUID.randomUUID().toString().replace("-", "");
        final CountDownLatch release = new CountDownLatch(1), inserted = new CountDownLatch(1);
        final CompletableFuture<String> task = new CompletableFuture<>();
    }
    @Inject public LateCommitLab(DbAccess access, Futures futures, ApplicationLifecycle lifecycle) {
        this.access = access; this.futures = futures;
        lifecycle.addStopHook(() -> {
            jobs.values().forEach(job -> job.release.countDown());
            return CompletableFuture.runAsync(() -> close(worker), runnable -> Thread.ofPlatform().name("db-late-stop").start(runnable));
        });
    }
    public synchronized CompletionStage<ObjectNode> start(boolean commitBeforeResponse) {
        if (jobs.size() >= 4 || jobs.values().stream().anyMatch(job -> !job.task.isDone())) throw new IllegalStateException("finite experiment busy or exhausted");
        Job job = new Job(); jobs.put(job.id, job);
        worker.execute(() -> {
            try {
                Database db = access.open("late", 2, 1000);
                Throwable primary = null;
                try {
                    db.withConnection(connection -> { DbAccess.execute(connection, "CREATE TABLE IF NOT EXISTS lab_late_orders(business_key text PRIMARY KEY)"); return null; });
                    db.withTransaction(connection -> {
                        DbAccess.execute(connection, "INSERT INTO lab_late_orders VALUES('" + job.id + "')");
                        if (!commitBeforeResponse) { job.inserted.countDown(); await(job.release); }
                        return null;
                    });
                    if (commitBeforeResponse) { job.inserted.countDown(); await(job.release); }
                } catch (RuntimeException | Error error) { primary = error; throw error; }
                finally { DbAccess.shutdown(db, primary); }
                job.task.complete("committed");
            } catch (Throwable error) { job.task.completeExceptionally(error); job.inserted.countDown(); }
        });
        return CompletableFuture.supplyAsync(() -> { await(job.inserted); return null; }, runnable -> Thread.ofPlatform().name("db-late-response").start(runnable))
                .thenCompose(ignored -> futures.timeout(job.task, java.time.Duration.ofMillis(100)))
                .handle((value, error) -> {
                    Throwable cause = error;
                    while (cause instanceof CompletionException && cause.getCause() != null) cause = cause.getCause();
                    return Json.newObject().put("id", job.id).put("response", cause == null ? value : cause instanceof TimeoutException ? "TIMEOUT" : "FAILED").put("taskDoneAtResponse", job.task.isDone());
                });
    }
    public ObjectNode status(String id, boolean release, boolean retry) {
        Job job = jobs.get(id); if (job == null) throw new IllegalArgumentException("unknown experiment");
        if (release) { job.release.countDown(); get(job.task); }
        try (var connection = access.observer()) {
            int inserted = -1;
            if (retry) {
                try (var statement = connection.createStatement()) {
                    statement.setQueryTimeout(3);
                    inserted = statement.executeUpdate("INSERT INTO lab_late_orders VALUES('" + job.id + "') ON CONFLICT DO NOTHING");
                }
            }
            long orders = DbAccess.scalar(connection, "SELECT count(*) FROM lab_late_orders WHERE business_key='" + job.id + "'");
            return Json.newObject().put("id", id).put("taskDone", job.task.isDone()).put("taskFailed", job.task.isCompletedExceptionally()).put("ordersOnNewConnection", orders).put("retryInserted", inserted);
        } catch (java.sql.SQLException error) { throw new IllegalStateException(error); }
    }
}
