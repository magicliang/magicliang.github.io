package labdb;

import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.inject.Inject;
import java.sql.Connection;
import java.util.*;
import play.db.Database;
import play.db.evolutions.Evolution;
import play.db.evolutions.Evolutions;
import play.libs.Json;

public final class EvolutionLab {
    private final DbAccess access;
    @Inject public EvolutionLab(DbAccess access) { this.access = access; }
    public ObjectNode run() {
        Database db = access.open("evolutions", 2, 2000);
        String schema = "e_" + UUID.randomUUID().toString().replace("-", "");
        ObjectNode out = Json.newObject().put("schema", schema);
        Throwable primary = null;
        try {
            db.withConnection(connection -> { DbAccess.execute(connection, "CREATE SCHEMA " + schema); return null; });
            Evolution one = new Evolution(1, "CREATE TABLE " + schema + ".items(id integer PRIMARY KEY, name text); INSERT INTO " + schema + ".items VALUES(1,'old');", "DROP TABLE " + schema + ".items;");
            Evolution two = new Evolution(2, "ALTER TABLE " + schema + ".items ADD COLUMN label text; UPDATE " + schema + ".items SET label=name; ALTER TABLE " + schema + ".items ALTER COLUMN label SET NOT NULL;", "ALTER TABLE " + schema + ".items DROP COLUMN label;");
            apply(db, schema, true, one); out.put("afterEmpty", count(db, schema + ".play_evolutions"));
            apply(db, schema, true, one); out.put("afterRestart", count(db, schema + ".play_evolutions"));
            apply(db, schema, true, one, two); out.put("afterRevisionTwo", count(db, schema + ".play_evolutions"));
            long backfilled = db.withConnection(connection -> { return DbAccess.scalar(connection, "SELECT count(*) FROM " + schema + ".items WHERE label='old'"); });
            long notNull = db.withConnection(connection -> { return DbAccess.scalar(connection, "SELECT count(*) FROM information_schema.columns WHERE table_schema='" + schema + "' AND table_name='items' AND column_name='label' AND is_nullable='NO'"); });
            out.put("backfilledRows", backfilled).put("notNullColumns", notNull);
            out.set("autocommitTrue", failed(db, schema + "_auto", true));
            out.set("autocommitFalse", failed(db, schema + "_tx", false));
            return out;
        } catch (RuntimeException | Error error) { primary = error; throw error; }
        finally { DbAccess.shutdown(db, primary); }
    }
    private ObjectNode failed(Database db, String schema, boolean autocommit) {
        db.withConnection(connection -> { DbAccess.execute(connection, "CREATE SCHEMA " + schema); return null; });
        ObjectNode out = Json.newObject().put("schema", schema).put("autocommit", autocommit);
        Evolution broken = new Evolution(1, "CREATE TABLE " + schema + ".partial(id integer); INSERT INTO " + schema + ".missing VALUES(1);", "DROP TABLE IF EXISTS " + schema + ".partial;");
        try { apply(db, schema, autocommit, broken); out.put("outcome", "unexpected-success"); }
        catch (RuntimeException error) { out.put("outcome", error.getClass().getSimpleName()); }
        long partial = db.withConnection(connection -> { return DbAccess.scalar(connection, "SELECT count(*) FROM information_schema.tables WHERE table_schema='" + schema + "' AND table_name='partial'"); });
        out.put("partialTableExists", partial);
        out.put("metadataRows", count(db, schema + ".play_evolutions"));
        String state = db.withConnection(connection -> {
            try (var statement = connection.createStatement()) {
                statement.setQueryTimeout(5);
                try (var rows = statement.executeQuery("SELECT coalesce(string_agg(state,','),'') FROM " + schema + ".play_evolutions")) { rows.next(); return rows.getString(1); }
            }
        });
        return out.put("metadataStates", state);
    }
    private void apply(Database db, String schema, boolean autocommit, Evolution... values) {
        Evolutions.applyEvolutions(db, Evolutions.fromMap(Map.of(db.getName(), Arrays.asList(values))), autocommit, schema);
    }
    private long count(Database db, String table) { return db.withConnection(connection -> { return DbAccess.scalar(connection, "SELECT count(*) FROM " + table); }); }
}
