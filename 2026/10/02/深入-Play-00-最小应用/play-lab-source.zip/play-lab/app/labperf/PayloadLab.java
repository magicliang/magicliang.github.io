package labperf;

import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import java.lang.management.ManagementFactory;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import org.apache.pekko.NotUsed;
import org.apache.pekko.stream.javadsl.Source;
import org.apache.pekko.util.ByteString;
import play.cache.AsyncCacheApi;
import play.libs.Json;

@Singleton
public final class PayloadLab {
    public static final int CHUNKS = 32, CHUNK_BYTES = 8192;
    private final PerformanceLab database;
    private final AsyncCacheApi cache;
    private final com.sun.management.ThreadMXBean threads = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
    private final Map<Integer,ObjectNode> rows = new ConcurrentHashMap<>();
    private final AtomicInteger queries = new AtomicInteger(), loaders = new AtomicInteger(), pending = new AtomicInteger();
    private String run, mode;
    private int limit;
    @Inject public PayloadLab(PerformanceLab database, AsyncCacheApi cache) { this.database = database; this.cache = cache; }
    public synchronized ObjectNode begin(String id, String kind, int count) {
        if (!id.matches("[a-zA-Z0-9_-]{1,64}") || !Set.of("aggregate", "stream", "uncached", "cold", "hot").contains(kind) || count < 1 || count > 100)
            throw new IllegalArgumentException("invalid bounded payload run");
        if (pending.get() != 0) throw new IllegalStateException("previous payload run not drained");
        run = id; mode = kind; limit = count; rows.clear(); queries.set(0); loaders.set(0);
        return snapshot();
    }
    private synchronized ObjectNode start(String id, int task) {
        if (!Objects.equals(run, id) || task < 0 || task >= limit || rows.containsKey(task)) throw new IllegalArgumentException("invalid payload task");
        ObjectNode row = Json.newObject().put("id", task).put("startedNanos", System.nanoTime()); rows.put(task, row); pending.incrementAndGet(); return row;
    }
    private void finish(ObjectNode row, String outcome, long allocation, int chunks) {
        synchronized (row) { row.put("terminalNanos", System.nanoTime()).put("outcome", outcome).put("constructionAllocatedBytes", allocation).put("chunksProduced", chunks); }
        pending.decrementAndGet();
    }
    public byte[] aggregate(String id, int task) {
        ObjectNode row = start(id, task); long before = allocated();
        try { byte[] bytes = bytes(0, CHUNKS * CHUNK_BYTES); finish(row, "constructed", delta(before), 1); return bytes; }
        catch (RuntimeException | Error error) { finish(row, "failed", delta(before), 0); throw error; }
    }
    public Source<ByteString,NotUsed> stream(String id, int task) {
        ObjectNode row = start(id, task); AtomicLong allocation = new AtomicLong(); AtomicInteger chunks = new AtomicInteger();
        return Source.range(0, CHUNKS - 1).map(index -> {
            long before = allocated(); ByteString bytes = ByteString.fromArray(bytes(index * CHUNK_BYTES, CHUNK_BYTES));
            allocation.addAndGet(delta(before)); chunks.incrementAndGet(); return bytes;
        }).watchTermination((unused, terminal) -> {
            terminal.whenComplete((done, error) -> finish(row, error == null ? "stream-terminated" : "stream-failed", allocation.get(), chunks.get()));
            return NotUsed.getInstance();
        });
    }
    private byte[] bytes(int offset, int count) {
        byte[] bytes = new byte[count]; for (int i = 0; i < count; i++) bytes[i] = (byte) ((offset + i) % 251); return bytes;
    }
    public synchronized CompletionStage<String> warm(String id, int key) {
        if (!Objects.equals(run, id) || !mode.equals("hot") || key < 0 || key > 3) throw new IllegalArgumentException("invalid warm key");
        return cached(key);
    }
    private String businessKey(int key) { return "tenant" + (key / 2) + ":item" + (key % 2); }
    private CompletionStage<String> load(int key) { loaders.incrementAndGet(); return database.value(businessKey(key), queries::incrementAndGet); }
    private CompletionStage<String> cached(int key) { return cache.getOrElseUpdate("performance:" + run + ":" + businessKey(key), () -> load(key), 60); }
    public CompletionStage<String> value(String id, int task) {
        ObjectNode row = start(id, task);
        CompletionStage<String> value;
        try { value = mode.equals("uncached") ? load(task % 4) : cached(task % 4); }
        catch (RuntimeException error) { finish(row, "failed", 0, 0); throw error; }
        return value.whenComplete((body, error) -> finish(row, error == null ? "value-completed" : "failed", 0, 0));
    }
    public synchronized ObjectNode snapshot() {
        ObjectNode out = Json.newObject().put("run", run).put("mode", mode).put("limit", limit).put("pending", pending.get()).put("postgresQueries", queries.get()).put("loaderCalls", loaders.get());
        var array = out.putArray("tasks"); rows.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(e -> { synchronized (e.getValue()) { array.add(e.getValue().deepCopy()); } });
        out.set("process", database.process());
        out.put("allocationScope", "aggregate byte-array fill or stream chunk mapping only; excludes framework, buffers outside mapping and HTTP transport");
        return out;
    }
    private long allocated() { return threads.isThreadAllocatedMemorySupported() ? threads.getThreadAllocatedBytes(Thread.currentThread().threadId()) : -1; }
    private long delta(long before) { return before < 0 ? -1 : allocated() - before; }
}
