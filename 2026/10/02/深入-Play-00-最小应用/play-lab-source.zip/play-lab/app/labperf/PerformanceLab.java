package labperf;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.zaxxer.hikari.HikariDataSource;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import java.lang.management.ManagementFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import labdb.DbAccess;
import org.apache.pekko.actor.ActorSystem;
import play.db.Database;
import play.inject.ApplicationLifecycle;
import play.libs.Json;

@Singleton
public final class PerformanceLab {
    public static final int SQL_MILLIS = 60;
    public static final int BUDGET_MILLIS = 100;
    private final DbAccess access;
    private final ActorSystem system;
    private final ThreadPoolExecutor dedicated = pool("perf-dedicated-", 64);
    private final ThreadPoolExecutor admission = pool("perf-admission-", 2);
    private final ScheduledThreadPoolExecutor clock = new ScheduledThreadPoolExecutor(1, Thread.ofPlatform().name("perf-deadline-", 0).factory());
    private final String schema = "perf_" + UUID.randomUUID().toString().replace("-", "");
    private Database database;
    private HikariDataSource hikari;
    private volatile Run current;
    private boolean stopping;
    private final com.sun.management.ThreadMXBean threads = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();

    @Inject public PerformanceLab(DbAccess access, ActorSystem system, ApplicationLifecycle lifecycle) {
        this.access = access; this.system = system;
        clock.setRemoveOnCancelPolicy(true);
        if (threads.isThreadAllocatedMemorySupported() && !threads.isThreadAllocatedMemoryEnabled()) threads.setThreadAllocatedMemoryEnabled(true);
        lifecycle.addStopHook(() -> { close(); return CompletableFuture.completedFuture(null); });
    }
    private static ThreadPoolExecutor pool(String name, int capacity) {
        return new ThreadPoolExecutor(2, 2, 0, TimeUnit.SECONDS, new ArrayBlockingQueue<>(capacity),
                Thread.ofPlatform().name(name, 0).factory(), new ThreadPoolExecutor.AbortPolicy());
    }
    private synchronized void initialize() {
        if (stopping) throw new IllegalStateException("stopping");
        if (database != null) return;
        Database candidate = access.open("performance", 2, 2000);
        try (Connection one = candidate.getConnection(); Connection two = candidate.getConnection()) {
            DbAccess.execute(one, "CREATE SCHEMA " + schema);
            DbAccess.execute(one, "CREATE TABLE " + schema + ".completed (run_id text NOT NULL, task_id integer NOT NULL, committed_at timestamptz DEFAULT clock_timestamp(), PRIMARY KEY(run_id,task_id))");
            database = candidate; hikari = (HikariDataSource) candidate.getDataSource();
        } catch (Exception error) { DbAccess.shutdown(candidate, error); throw new IllegalStateException(error); }
        dedicated.prestartAllCoreThreads(); admission.prestartAllCoreThreads();
    }
    public synchronized ObjectNode begin(String id, String mode, int limit) {
        if (!id.matches("[a-zA-Z0-9_-]{1,64}") || !Set.of("default", "dedicated", "admission").contains(mode) || limit < 1 || limit > 100)
            throw new IllegalArgumentException("invalid bounded run");
        initialize();
        if (current != null && (current.rows.size() != current.limit || current.rows.values().stream().anyMatch(t -> !t.done)))
            throw new IllegalStateException("previous run not drained");
        current = new Run(id, mode, limit);
        return snapshot();
    }
    public synchronized CompletionStage<ObjectNode> submit(String run, int id) {
        if (stopping || current == null || !current.id.equals(run) || id < 0 || id >= current.limit || current.rows.containsKey(id))
            throw new IllegalArgumentException("invalid or duplicate task");
        Run owner = current;
        Task task = new Task(id); owner.rows.put(id, task);
        task.data.put("submittedNanos", System.nanoTime());
        owner.pending.incrementAndGet();
        Executor target = switch (owner.mode) { case "default" -> system.dispatcher(); case "dedicated" -> dedicated; default -> admission; };
        try {
            target.execute(() -> execute(owner, task));
            task.timer = clock.schedule(() -> respond(task, 504), BUDGET_MILLIS, TimeUnit.MILLISECONDS);
            if (task.responseCode.get() != 0) task.timer.cancel(false);
        } catch (RejectedExecutionException rejected) {
            task.data.put("outcome", "rejected"); task.data.put("returnedNanos", System.nanoTime());
            owner.pending.decrementAndGet(); task.done = true; respond(task, 503);
        }
        sample(owner);
        return task.response;
    }
    private void execute(Run owner, Task task) {
        long allocatedBefore = allocated();
        task.data.put("thread", Thread.currentThread().getName()); task.data.put("startedNanos", System.nanoTime());
        owner.active.incrementAndGet(); sample(owner);
        try {
            task.data.put("borrowStartedNanos", System.nanoTime());
            try (Connection connection = database.getConnection()) {
                task.data.put("borrowedNanos", System.nanoTime()); sample(owner);
                connection.setAutoCommit(false);
                try {
                    DbAccess.execute(connection, "SET LOCAL statement_timeout='2000ms'");
                    task.data.put("sqlStartedNanos", System.nanoTime());
                    DbAccess.execute(connection, "SELECT pg_sleep(" + SQL_MILLIS + "/1000.0)");
                    try (PreparedStatement insert = connection.prepareStatement("INSERT INTO " + schema + ".completed(run_id,task_id) VALUES (?,?)")) {
                        insert.setQueryTimeout(2); insert.setString(1, owner.id); insert.setInt(2, task.id); insert.executeUpdate();
                    }
                    connection.commit(); task.data.put("committedNanos", System.nanoTime()); task.data.put("outcome", "committed");
                } catch (Exception failure) {
                    try { connection.rollback(); } catch (Exception rollback) { failure.addSuppressed(rollback); }
                    throw failure;
                }
            }
        } catch (Exception error) { task.data.put("outcome", "failed"); task.data.put("error", DbAccess.state(error)); }
        finally {
            task.data.put("returnedNanos", System.nanoTime()); task.data.put("allocatedBytes", allocatedBefore < 0 ? -1 : allocated() - allocatedBefore);
            owner.active.decrementAndGet(); owner.pending.decrementAndGet(); task.done = true; sample(owner);
            respond(task, "committed".equals(task.data.get("outcome")) ? 200 : 500);
        }
    }
    private long allocated() { return threads.isThreadAllocatedMemorySupported() ? threads.getThreadAllocatedBytes(Thread.currentThread().threadId()) : -1; }
    private void respond(Task task, int status) {
        if (!task.responseCode.compareAndSet(0, status)) return;
        boolean done = task.done;
        task.data.put("responseDecisionNanos", System.nanoTime()); task.data.put("doneAtResponseDecision", done);
        ScheduledFuture<?> timer = task.timer; if (timer != null) timer.cancel(false);
        task.response.complete(Json.newObject().put("id", task.id).put("status", status).put("doneAtResponseDecision", done));
    }
    public synchronized ObjectNode acknowledge(String run, int id) {
        if (current == null || !current.id.equals(run) || !current.rows.containsKey(id)) throw new IllegalArgumentException("unknown task");
        Task task = current.rows.get(id); long now = System.nanoTime(); task.data.put("clientAckNanos", now);
        return Json.newObject().put("id", id).put("serverAckNanos", now).put("taskDoneAtAck", task.done);
    }
    private void sample(Run run) {
        run.maxActive.accumulateAndGet(run.active.get(), Math::max);
        run.maxQueued.accumulateAndGet(Math.max(0, run.pending.get() - run.active.get()), Math::max);
        run.maxConnections.accumulateAndGet(hikari.getHikariPoolMXBean().getActiveConnections(), Math::max);
        run.maxBorrowWaiters.accumulateAndGet(hikari.getHikariPoolMXBean().getThreadsAwaitingConnection(), Math::max);
    }
    public synchronized ObjectNode snapshot() {
        ObjectNode out = Json.newObject();
        if (current == null) return out;
        Run r = current;
        out.put("run", r.id).put("mode", r.mode).put("limit", r.limit).put("pending", r.pending.get()).put("active", r.active.get());
        out.put("maxActive", r.maxActive.get()).put("maxApplicationQueued", r.maxQueued.get()).put("maxConnections", r.maxConnections.get()).put("maxBorrowWaiters", r.maxBorrowWaiters.get());
        out.put("poolActive", hikari.getHikariPoolMXBean().getActiveConnections()).put("poolIdle", hikari.getHikariPoolMXBean().getIdleConnections());
        out.put("dedicatedQueue", dedicated.getQueue().size()).put("admissionQueue", admission.getQueue().size()).put("deadlineQueue", clock.getQueue().size());
        var rows = out.putArray("tasks");
        r.rows.values().forEach(t -> { ObjectNode row = Json.newObject().put("id", t.id).put("done", t.done).put("responseStatus", t.responseCode.get()); row.set("events", Json.toJson(t.data)); rows.add(row); });
        out.set("process", process());
        return out;
    }
    public synchronized ObjectNode progress() {
        return Json.newObject().put("pending", current == null ? 0 : current.pending.get())
                .put("allTerminal", current == null || current.rows.values().stream().allMatch(t -> t.done && t.response.isDone()));
    }
    public synchronized ObjectNode committed() {
        if (current == null || current.pending.get() != 0) throw new IllegalStateException("run not drained");
        try (Connection connection = access.observer(); PreparedStatement query = connection.prepareStatement("SELECT count(*) FROM " + schema + ".completed WHERE run_id=?")) {
            query.setQueryTimeout(2); query.setString(1, current.id);
            try (var rows = query.executeQuery()) { rows.next(); return Json.newObject().put("run", current.id).put("committedOnNewConnection", rows.getInt(1)); }
        } catch (Exception error) { throw new IllegalStateException(error); }
    }
    public synchronized ObjectNode configuration() {
        initialize();
        ObjectNode out = Json.newObject().put("schema", schema).put("sqlMillis", SQL_MILLIS).put("responseBudgetMillis", BUDGET_MILLIS)
                .put("poolMaximum", hikari.getMaximumPoolSize()).put("poolMinimumIdle", hikari.getMinimumIdle()).put("borrowTimeoutMillis", hikari.getConnectionTimeout())
                .put("dedicatedThreads", dedicated.getMaximumPoolSize()).put("dedicatedQueueCapacity", dedicated.getQueue().size() + dedicated.getQueue().remainingCapacity())
                .put("admissionThreads", admission.getMaximumPoolSize()).put("admissionQueueCapacity", admission.getQueue().size() + admission.getQueue().remainingCapacity())
                .put("rejectionPolicy", admission.getRejectedExecutionHandler().getClass().getName()).put("jdk", System.getProperty("java.runtime.version"))
                .put("os", System.getProperty("os.name")).put("arch", System.getProperty("os.arch")).put("availableProcessors", Runtime.getRuntime().availableProcessors())
                .put("maxHeapBytes", Runtime.getRuntime().maxMemory()).put("allocatedBytesSupported", threads.isThreadAllocatedMemorySupported())
                .put("defaultExecutor", system.dispatcher().getClass().getName())
                .put("defaultParallelismMin", system.settings().config().getInt("pekko.actor.default-dispatcher.fork-join-executor.parallelism-min"))
                .put("defaultParallelismMax", system.settings().config().getInt("pekko.actor.default-dispatcher.fork-join-executor.parallelism-max"));
        try (Connection connection = database.getConnection()) {
            out.put("postgres", connection.getMetaData().getDatabaseProductVersion()).put("driver", connection.getMetaData().getDriverVersion());
        } catch (Exception error) { throw new IllegalStateException(error); }
        out.put("queueObservation", "max of sampled pending-active; not the Pekko internal queue; controller wait before submit excluded");
        out.put("budgetOrigin", "timer scheduled after executor submission, not at network arrival; dispatcher delay before controller excluded");
        out.put("allocationObservation", "worker-thread allocation delta during JDBC task, not whole HTTP allocation");
        out.set("process", process()); return out;
    }
    public CompletionStage<String> value(String key, Runnable queryStarted) {
        initialize();
        return CompletableFuture.supplyAsync(() -> {
            try (Connection connection = database.getConnection(); PreparedStatement query = connection.prepareStatement("SELECT ?::text || ':value' FROM pg_sleep(0.01)")) {
                queryStarted.run(); query.setString(1, key); query.setQueryTimeout(2);
                try (var rows = query.executeQuery()) { rows.next(); return rows.getString(1); }
            } catch (Exception error) { throw new CompletionException(error); }
        }, dedicated);
    }
    public ObjectNode process() {
        var os = (com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
        ObjectNode out = Json.newObject().put("nanoTime", System.nanoTime()).put("cpuNanos", os.getProcessCpuTime()).put("heapUsedBytes", ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed());
        long count = 0, millis = 0;
        for (var gc : ManagementFactory.getGarbageCollectorMXBeans()) { if (gc.getCollectionCount() >= 0) count += gc.getCollectionCount(); if (gc.getCollectionTime() >= 0) millis += gc.getCollectionTime(); }
        return out.put("gcCollections", count).put("gcMillis", millis);
    }
    private void close() {
        synchronized (this) { stopping = true; }
        Throwable failure = null; boolean interrupted = Thread.interrupted();
        dedicated.shutdown(); admission.shutdown(); clock.shutdown();
        long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(12);
        try {
            while (current != null && current.pending.get() > 0 && System.nanoTime() < deadline) Thread.sleep(10);
            if (current != null && current.pending.get() != 0) throw new IllegalStateException("tasks did not drain");
        } catch (Throwable error) { failure = error; interrupted |= error instanceof InterruptedException; }
        for (ExecutorService executor : List.of(dedicated, admission, clock)) {
            try { if (!executor.awaitTermination(3, TimeUnit.SECONDS)) { executor.shutdownNow(); throw new IllegalStateException("executor drain timeout"); } }
            catch (Throwable error) { interrupted |= error instanceof InterruptedException; if (failure == null) failure = error; else failure.addSuppressed(error); }
        }
        try { if (database != null) database.shutdown(); }
        catch (Throwable error) { if (failure == null) failure = error; else failure.addSuppressed(error); }
        finally { if (interrupted) Thread.currentThread().interrupt(); }
        System.out.println("PERF_CLEANUP dedicated=" + dedicated.isTerminated() + " admission=" + admission.isTerminated() + " clock=" + clock.isTerminated() + " poolClosed=" + (hikari == null || hikari.isClosed()));
        if (failure != null) throw new IllegalStateException("performance cleanup failed", failure);
    }
    private static final class Task {
        final int id; final Map<String,Object> data = new ConcurrentHashMap<>(); final CompletableFuture<ObjectNode> response = new CompletableFuture<>();
        final AtomicInteger responseCode = new AtomicInteger(); volatile boolean done; volatile ScheduledFuture<?> timer;
        Task(int id) { this.id = id; }
    }
    private static final class Run {
        final String id, mode; final int limit; final Map<Integer,Task> rows = new TreeMap<>();
        final AtomicInteger pending = new AtomicInteger(), active = new AtomicInteger(), maxActive = new AtomicInteger(), maxQueued = new AtomicInteger(), maxConnections = new AtomicInteger(), maxBorrowWaiters = new AtomicInteger();
        Run(String id, String mode, int limit) { this.id = id; this.mode = mode; this.limit = limit; }
    }
}
