package production;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.typesafe.config.Config;
import com.zaxxer.hikari.HikariDataSource;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.sql.*;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.pekko.Done;
import org.apache.pekko.actor.ActorSystem;
import org.apache.pekko.actor.CoordinatedShutdown;
import org.apache.pekko.stream.javadsl.Source;
import org.apache.pekko.util.ByteString;
import play.db.Database;
import play.db.Databases;
import play.inject.ApplicationLifecycle;
import play.libs.Json;

@Singleton
public final class ProductionProbe {
    private final Config config;
    private final ActorSystem system;
    private final AtomicInteger inFlight = new AtomicInteger();
    private final AtomicInteger streamsFinished = new AtomicInteger();
    private volatile boolean accepting;
    private Database db;
    private ExecutorService worker;
    private FileChannel resource;
    private Path journal;
    private String schema;
    @Inject public ProductionProbe(Config config, ActorSystem system, ApplicationLifecycle lifecycle) {
        this.config = config; this.system = system;
        if (!config.hasPath("prod.enabled") || !config.getBoolean("prod.enabled")) return;
        schema = config.getString("prod.schema");
        if (!schema.matches("prod_[a-f0-9]{12}")) throw new IllegalArgumentException("owned prod schema required");
        try {
            journal = Path.of(config.getString("prod.journal"));
            Files.createDirectories(journal.toAbsolutePath().getParent());
            resource = FileChannel.open(Path.of(journal + ".resource"), StandardOpenOption.CREATE, StandardOpenOption.WRITE);
            db = Databases.createFrom("production-probe", "org.postgresql.Driver", config.getString("prod.url"),
                    Map.of("username", "postgres", "password", "lab-only-password", "hikaricp.maximumPoolSize", 2,
                            "hikaricp.minimumIdle", 1, "hikaricp.connectionTimeout", "2s"));
            db.withConnection(c -> { execute(c, "CREATE TABLE IF NOT EXISTS " + schema + ".orders(id text PRIMARY KEY)"); return null; });
            worker = new ThreadPoolExecutor(2, 2, 0, TimeUnit.SECONDS, new ArrayBlockingQueue<>(2),
                    Thread.ofPlatform().name("prod-jdbc-", 0).factory());
            accepting = true; event("initialized", "pool-open,file-open,worker-ready");
        } catch (Throwable error) { closeResources(error); throw new IllegalStateException("production probe initialization", error); }
        CoordinatedShutdown.get(system).addTask(CoordinatedShutdown.PhaseBeforeServiceUnbind(), "prod-reject-new-work",
                (java.util.function.Supplier<CompletionStage<Done>>) () -> {
                    drain(); event("before-unbind", "inFlight=" + inFlight.get());
                    return CompletableFuture.completedFuture(Done.getInstance());
                });
        lifecycle.addStopHook(() -> CompletableFuture.runAsync(() -> {
            drain(); event("cleanup-start", "inFlight=" + inFlight.get()); closeResources(null);
            event("cleanup-done", "workerTerminated=" + worker.isTerminated() + ",poolClosed="
                    + ((HikariDataSource) db.getDataSource()).isClosed() + ",fileClosed=" + !resource.isOpen());
        }, runnable -> Thread.ofPlatform().name("prod-stop-driver").start(runnable)));
    }
    public synchronized void drain() { accepting = false; }
    public CompletionStage<ObjectNode> ready() {
        if (!accepting || db == null || worker.isShutdown()) return CompletableFuture.completedFuture(state().put("ready", false));
        try {
            return CompletableFuture.supplyAsync(() -> {
                boolean valid = db.withConnection(c -> { return c.isValid(1); });
                return state().put("databaseValid", valid).put("ready", valid && accepting);
            }, worker);
        } catch (RejectedExecutionException error) { return CompletableFuture.completedFuture(state().put("ready", false)); }
    }
    public synchronized CompletionStage<ObjectNode> work(String key, int millis) {
        if (!accepting) return CompletableFuture.failedFuture(new RejectedExecutionException("draining"));
        if (!key.matches("[a-z0-9_]{1,40}") || millis < 0 || millis > 4000) throw new IllegalArgumentException("invalid finite work");
        inFlight.incrementAndGet();
        try {
            return CompletableFuture.supplyAsync(() -> {
                try {
                    db.withTransaction(c -> {
                        try (PreparedStatement p = c.prepareStatement("INSERT INTO " + schema + ".orders VALUES(?)")) {
                            p.setQueryTimeout(6); p.setString(1, key); p.executeUpdate();
                        }
                        event("inserted-uncommitted", key);
                        execute(c, "SELECT pg_sleep(" + millis / 1000.0 + ") /* " + schema + " */"); return null;
                    });
                    event("committed", key);
                    return Json.newObject().put("id", key).put("committed", true).put("thread", Thread.currentThread().getName());
                } finally { inFlight.decrementAndGet(); }
            }, worker);
        } catch (RuntimeException error) { inFlight.decrementAndGet(); throw error; }
    }
    public Source<ByteString, ?> stream(int chunks) {
        if (chunks < 1 || chunks > 256) throw new IllegalArgumentException("finite stream required");
        ByteString chunk = ByteString.fromArray(new byte[32768]);
        return Source.tick(Duration.ZERO, Duration.ofMillis(40), chunk).take(chunks)
                .watchTermination((control, done) -> {
                    done.whenComplete((value, error) -> { streamsFinished.incrementAndGet(); event("stream-terminal", String.valueOf(error)); });
                    return control;
                });
    }
    public ObjectNode state() {
        return Json.newObject().put("accepting", accepting).put("inFlight", inFlight.get())
                .put("streamsFinished", streamsFinished.get()).put("label", config.hasPath("prod.label") ? config.getString("prod.label") : "packaged")
                .put("provider", config.getString("play.server.provider"))
                .put("actorSystemClass", system.getClass().getName())
                .put("playJar", play.Application.class.getProtectionDomain().getCodeSource().getLocation().toString())
                .put("probeJar", getClass().getProtectionDomain().getCodeSource().getLocation().toString());
    }
    private static void execute(Connection connection, String sql) throws SQLException {
        try (Statement statement = connection.createStatement()) { statement.setQueryTimeout(6); statement.execute(sql); }
    }
    private synchronized void event(String kind, String detail) {
        if (journal == null) return;
        try { Files.writeString(journal, Json.newObject().put("event", kind).put("detail", detail).toString() + "\n",
                StandardOpenOption.CREATE, StandardOpenOption.APPEND); }
        catch (java.io.IOException error) { throw new IllegalStateException(error); }
    }
    private void closeResources(Throwable primary) {
        Throwable failure = primary; boolean interrupted = Thread.interrupted();
        if (worker != null) {
            try {
                worker.shutdown();
                if (!worker.awaitTermination(6, TimeUnit.SECONDS)) {
                    worker.shutdownNow();
                    if (!worker.awaitTermination(2, TimeUnit.SECONDS)) throw new IllegalStateException("worker did not stop");
                }
            } catch (Throwable error) {
                if (error instanceof InterruptedException) interrupted = true;
                try { worker.shutdownNow(); } catch (Throwable second) { error.addSuppressed(second); }
                if (failure == null) failure = error; else failure.addSuppressed(error);
            }
        }
        try { if (db != null) db.shutdown(); }
        catch (Throwable error) { if (failure == null) failure = error; else failure.addSuppressed(error); }
        try { if (resource != null) resource.close(); }
        catch (Throwable error) { if (failure == null) failure = error; else failure.addSuppressed(error); }
        if (interrupted) Thread.currentThread().interrupt();
        if (primary == null && failure != null) throw new IllegalStateException("production cleanup failed", failure);
    }
}
