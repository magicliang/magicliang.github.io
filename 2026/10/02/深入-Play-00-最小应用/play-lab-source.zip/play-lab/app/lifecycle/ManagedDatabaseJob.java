package lifecycle;

import static labasync.LabSupport.*;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.typesafe.config.Config;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.sql.PreparedStatement;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import labdb.DbAccess;
import play.db.Database;
import play.inject.ApplicationLifecycle;
import play.libs.Json;

@Singleton
public final class ManagedDatabaseJob {
    private final DbAccess access;
    private final ApplicationLifecycle lifecycle;
    private final Config config;
    private Database db;
    private ScheduledExecutorService scheduler;
    private ExecutorService worker;
    private FileChannel file;
    private Path journal;
    private final AtomicInteger inFlight = new AtomicInteger();
    private volatile String terminal = "not-started";
    private volatile String thread = "";
    private volatile boolean stopping;
    @Inject public ManagedDatabaseJob(DbAccess access, ApplicationLifecycle lifecycle, Config config) {
        this.access = access; this.lifecycle = lifecycle; this.config = config;
        lifecycle.addStopHook(() -> { beginStop(); return CompletableFuture.completedFuture(null); });
    }

    private synchronized void initialize() {
        if (db != null) return;
        db = access.open("lifecycle", 2, 2000);
        try {
            db.withConnection(connection -> { DbAccess.execute(connection,
                    "CREATE TABLE IF NOT EXISTS lab_background(business_key text PRIMARY KEY, owner text NOT NULL)"); return null; });
        } catch (RuntimeException | Error error) { DbAccess.shutdown(db, error); db = null; throw error; }
        scheduler = Executors.newSingleThreadScheduledExecutor(Thread.ofPlatform().name("lab-owned-scheduler").factory());
        worker = Executors.newSingleThreadExecutor(Thread.ofPlatform().name("lab-owned-worker").factory());
        try {
            journal = config.hasPath("lab.lifecycle.journal") ? Path.of(config.getString("lab.lifecycle.journal")) : Files.createTempFile("play-lifecycle-", ".jsonl");
            Files.createDirectories(journal.toAbsolutePath().getParent());
            file = FileChannel.open(Path.of(journal + ".resource"), StandardOpenOption.CREATE, StandardOpenOption.WRITE);
        } catch (IOException | RuntimeException error) {
            try { scheduler.shutdownNow(); } catch (RuntimeException cleanup) { error.addSuppressed(cleanup); }
            try { worker.shutdownNow(); } catch (RuntimeException cleanup) { error.addSuppressed(cleanup); }
            DbAccess.shutdown(db, error); db = null; throw new IllegalStateException(error);
        }
        lifecycle.addStopHook(() -> {
            Throwable primary = null;
            try { DbAccess.shutdown(db, null); }
            catch (RuntimeException | Error error) { primary = error; throw error; }
            finally {
                try { file.close(); }
                catch (IOException error) { if (primary != null) primary.addSuppressed(error); else throw error; }
            }
            event("final-cleanup", "fileClosed=" + !file.isOpen() + ",workerTerminated=" + worker.isTerminated() + ",schedulerTerminated=" + scheduler.isTerminated() + ",poolClosed=" + ((com.zaxxer.hikari.HikariDataSource) db.getDataSource()).isClosed());
            return CompletableFuture.completedFuture(null);
        });
        lifecycle.addStopHook(() -> { event("async-failure", "synthetic"); return CompletableFuture.failedFuture(new IllegalStateException("synthetic failed stop stage")); });
        lifecycle.addStopHook(() -> { event("sync-failure", "synthetic"); throw new IllegalStateException("synthetic thrown stop hook"); });
        lifecycle.addStopHook(() -> {
            beginStop();
            event("drain-start", "inFlight=" + inFlight.get());
            return CompletableFuture.runAsync(() -> {
                Throwable primary = null;
                boolean interrupted = Thread.currentThread().isInterrupted();
                try { close(scheduler); }
                catch (RuntimeException | Error error) { primary = error; throw error; }
                finally {
                    interrupted |= Thread.interrupted();
                    try { close(worker); }
                    catch (RuntimeException | Error error) { if (primary != null) primary.addSuppressed(error); else throw error; }
                    finally { if (interrupted) Thread.currentThread().interrupt(); }
                }
                event("drain-end", "inFlight=" + inFlight.get() + ",terminal=" + terminal);
            }, runnable -> Thread.ofPlatform().name("lab-shutdown-driver").start(runnable));
        });
        event("initialized", "resources-open");
    }

    private synchronized void beginStop() { stopping = true; }

    public synchronized ObjectNode start(String key, int sleepMillis) {
        if (stopping) throw new RejectedExecutionException("background scheduler stopping");
        if (!key.matches("[A-Za-z0-9_-]{1,80}") || sleepMillis < 0 || sleepMillis > 2000) throw new IllegalArgumentException("invalid synthetic job");
        initialize();
        if (!inFlight.compareAndSet(0, 1)) throw new IllegalStateException("one finite job at a time");
        terminal = "scheduled";
        CountDownLatch started = new CountDownLatch(1);
        Runnable task = () -> {
            thread = Thread.currentThread().getName(); started.countDown(); event("task-start", key);
            try {
                int inserted = db.withTransaction(connection -> {
                    DbAccess.execute(connection, "SELECT pg_sleep(" + sleepMillis / 1000.0 + ")");
                    try (PreparedStatement statement = connection.prepareStatement("INSERT INTO lab_background VALUES(?,?) ON CONFLICT DO NOTHING")) {
                        statement.setQueryTimeout(5); statement.setString(1, key); statement.setString(2, config.getString("lab.lifecycle.owner")); return statement.executeUpdate();
                    }
                });
                terminal = "committed-inserted-" + inserted;
            } catch (RuntimeException error) { terminal = "failed-" + DbAccess.state(error); }
            finally { inFlight.decrementAndGet(); event("task-terminal", key + ":" + terminal); }
        };
        try {
            scheduler.schedule(() -> {
                try { worker.execute(task); }
                catch (RejectedExecutionException error) { rejected(key, started); }
            }, 0, TimeUnit.MILLISECONDS);
        } catch (RejectedExecutionException error) { rejected(key, started); throw error; }
        await(started);
        if (terminal.equals("rejected")) throw new RejectedExecutionException("background worker rejected");
        return status();
    }
    private void rejected(String key, CountDownLatch started) {
        inFlight.set(0); terminal = "rejected"; started.countDown(); event("task-rejected", key);
    }
    public ObjectNode status() {
        return Json.newObject().put("inFlight", inFlight.get()).put("terminal", terminal).put("thread", thread).put("stopping", stopping)
                .put("journal", journal == null ? "" : journal.toString());
    }
    private synchronized void event(String name, String detail) {
        try { Files.writeString(journal, Json.newObject().put("event", name).put("detail", detail).toString() + "\n", StandardOpenOption.CREATE, StandardOpenOption.APPEND); }
        catch (IOException error) { throw new IllegalStateException(error); }
    }
}
