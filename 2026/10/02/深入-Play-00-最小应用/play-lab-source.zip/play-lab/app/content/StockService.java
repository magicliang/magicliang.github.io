package content;

import java.util.concurrent.atomic.AtomicInteger;
import javax.inject.Singleton;

@Singleton
public final class StockService {
    private final AtomicInteger remaining = new AtomicInteger(1);

    public boolean reserve(int quantity) {
        if (quantity < 1 || quantity > 5) throw new IllegalArgumentException("quantity outside lab bounds");
        int current;
        do {
            current = remaining.get();
            if (current < quantity) return false;
        } while (!remaining.compareAndSet(current, current - quantity));
        return true;
    }

    public int remaining() { return remaining.get(); }
    public void reset() { remaining.set(1); }
}
