package content;

import com.fasterxml.jackson.databind.JsonNode;
import javax.inject.Inject;
import org.apache.pekko.util.ByteString;
import play.libs.F;
import play.libs.streams.Accumulator;
import play.mvc.BodyParser;
import play.mvc.Http;
import play.mvc.Result;
import play.mvc.Results;

public final class ApiJsonParser implements BodyParser<JsonNode> {
    private final BodyParser.Json parser;

    @Inject
    public ApiJsonParser(BodyParser.Json parser) {
        this.parser = parser;
    }

    @Override
    public Accumulator<ByteString, F.Either<Result, JsonNode>> apply(Http.RequestHeader request) {
        return parser.apply(request).map(parsed -> parsed.left
                .map(result -> F.Either.<Result, JsonNode>Left(Results.status(result.status(),
                        play.libs.Json.newObject().put("code", "INVALID_INPUT"))))
                .orElse(parsed), Runnable::run);
    }
}
