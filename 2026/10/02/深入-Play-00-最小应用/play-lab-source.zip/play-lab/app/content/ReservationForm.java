package content;

import java.util.ArrayList;
import java.util.List;
import play.data.validation.Constraints;
import play.data.validation.ValidationError;

@Constraints.Validate
public final class ReservationForm implements Constraints.Validatable<List<ValidationError>> {
    @Constraints.Required
    @Constraints.MaxLength(40)
    private String name;

    @Constraints.Required
    @Constraints.Min(1)
    @Constraints.Max(5)
    private Integer quantity;

    @Constraints.Required
    private Integer confirmation;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }
    public Integer getConfirmation() { return confirmation; }
    public void setConfirmation(Integer confirmation) { this.confirmation = confirmation; }

    @Override
    public List<ValidationError> validate() {
        List<ValidationError> errors = new ArrayList<>();
        if (name != null && name.isBlank()) errors.add(new ValidationError("name", "name.blank"));
        if (quantity != null && confirmation != null && !quantity.equals(confirmation)) {
            errors.add(new ValidationError("confirmation", "quantity.mismatch"));
        }
        return errors;
    }
}
