package services;

import com.typesafe.config.Config;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public final class ConfiguredInventoryService implements InventoryService {
    private final int stock;

    @Inject
    public ConfiguredInventoryService(Config config) {
        stock = config.getInt("lab.stock");
        if (stock < 0) {
            throw new IllegalArgumentException("lab.stock must be non-negative");
        }
    }

    @Override
    public int stock(long productId) {
        return stock;
    }
}
