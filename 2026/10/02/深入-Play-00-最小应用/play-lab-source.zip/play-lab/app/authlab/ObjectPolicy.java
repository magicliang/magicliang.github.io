package authlab;
import java.util.*;
import javax.inject.Singleton;
import play.libs.Json;
import com.fasterxml.jackson.databind.node.ObjectNode;
@Singleton
public final class ObjectPolicy {
    private final Set<String> revoked = new HashSet<>();
    private int updates;
    public static boolean amountAllowed(int amount) { return amount > 0 && amount <= 100; }
    public synchronized boolean allowed(String user, int id) {
        return !revoked.contains(user) && (("alice".equals(user) && id == 1) || ("bob".equals(user) && id == 2));
    }
    public synchronized boolean update(String user, int id) {
        if (!allowed(user,id)) return false;
        updates++; return true;
    }
    public synchronized void revoke(String user) { if (Set.of("alice","bob").contains(user)) revoked.add(user); }
    public synchronized ObjectNode snapshot() { return Json.newObject().put("updates",updates).put("revokedCount",revoked.size()); }
}
