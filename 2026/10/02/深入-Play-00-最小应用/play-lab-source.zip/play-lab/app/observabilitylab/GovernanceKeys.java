package observabilitylab;
import play.libs.typedmap.TypedKey;
public final class GovernanceKeys { public static final TypedKey<String> ID=TypedKey.create("gov.id"); private GovernanceKeys() {} }
