package observabilitylab;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Function;
import javax.inject.Inject;
import org.apache.pekko.stream.Materializer;
import play.mvc.*;
import play.http.HttpEntity;
public final class ObservationFilter extends Filter {
    private final RequestEvents events;
    @Inject public ObservationFilter(Materializer mat, RequestEvents events) { super(mat); this.events=events; }
    @Override public CompletionStage<Result> apply(Function<Http.RequestHeader,CompletionStage<Result>> next, Http.RequestHeader request) {
        if (!request.path().startsWith("/gov/observe/")) return next.apply(request);
        String supplied=request.header("X-Gov-Id").orElse("");
        String id=supplied.matches("[a-zA-Z0-9_-]{1,48}") ? supplied : UUID.randomUUID().toString();
        events.event(id,"request_started","accepted");
        return next.apply(request.addAttr(GovernanceKeys.ID,id)).thenApply(result -> {
            events.event(id,"result_ready",result.status()<400?"success":"error");
            var bytes=result.body().dataStream().watchTermination((mat,done)->{
                done.whenComplete((v,e)->events.event(id,"stream_terminal",e==null?"completed_or_cancelled":"failed"));
                return mat;
            });
            List<Http.Cookie> cookies=new ArrayList<>(); result.cookies().forEach(cookies::add);
            return new Result(new ResponseHeader(result.status(),result.headers(),result.reasonPhrase().orElse(null)), new HttpEntity.Streamed(bytes,result.body().contentLength(),result.body().contentType()),
                result.session(),result.flash(),cookies,result.attrs());
        }).whenComplete((r,e)->{if(e!=null)events.event(id,"result_failed","exception");});
    }
}
