package observabilitylab;
import java.util.*;
import javax.inject.Singleton;
import play.libs.Json;
import com.fasterxml.jackson.databind.node.*;
@Singleton
public final class RequestEvents {
    private static final org.slf4j.Logger LOG=org.slf4j.LoggerFactory.getLogger(RequestEvents.class);
    private long evictions;
    private final LinkedHashMap<String, ObjectNode> records = new LinkedHashMap<>();
    private final Map<String, Long> metrics = new TreeMap<>();
    public synchronized void event(String id, String phase, String outcome) {
        ObjectNode row = records.get(id);
        if (row == null) {
            if (records.size() == 128) { records.remove(records.keySet().iterator().next()); evictions++; }
            row = Json.newObject(); row.putArray("events"); records.put(id,row);
        }
        ArrayNode events = (ArrayNode)row.get("events");
        if (events.size() < 12) events.add(Json.newObject().put("phase",phase).put("outcome",outcome));
        // Both inputs are internal enums in callers; no path, user, body or request ID label.
        LOG.info("gov_event id={} phase={} outcome={}",id,phase,outcome);
        String key = phase + ":" + outcome;
        metrics.merge(key,1L,Long::sum);
    }
    public synchronized void produced(String id, int bytes) {
        ObjectNode row=records.get(id); if(row!=null) {
            row.put("producedChunks",row.path("producedChunks").asLong()+1);
            row.put("producedBytes",row.path("producedBytes").asLong()+bytes);
        }
    }
    public synchronized ObjectNode snapshot() {
        ObjectNode out=Json.newObject(), rows=out.putObject("records"), counts=out.putObject("metrics");
        records.forEach((k,v)->rows.set(k,v.deepCopy())); metrics.forEach(counts::put);
        out.put("evictions",evictions); return out;
    }
}
