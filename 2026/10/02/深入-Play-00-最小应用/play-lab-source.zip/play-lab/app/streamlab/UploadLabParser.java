package streamlab;

import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import javax.inject.Inject;
import org.apache.pekko.stream.Materializer;
import org.apache.pekko.stream.javadsl.FileIO;
import org.apache.pekko.util.ByteString;
import play.http.HttpErrorHandler;
import play.libs.F;
import play.libs.streams.Accumulator;
import play.mvc.*;

/** Each request owns its file list; failed parsers clean files without invoking an action. */
public final class UploadLabParser implements BodyParser<Http.MultipartFormData<Path>> {
    public static final long MAX_LENGTH = 65536;
    public static final Path ROOT = Path.of(System.getProperty("java.io.tmpdir"), "play-stream-files");
    private final Materializer materializer;
    private final HttpErrorHandler errors;
    @Inject public UploadLabParser(Materializer materializer, HttpErrorHandler errors) {
        this.materializer = materializer; this.errors = errors;
    }
    public Accumulator<ByteString, F.Either<Result, Http.MultipartFormData<Path>>> apply(Http.RequestHeader request) {
        final StreamLedger.Entry e;
        try { e = StreamLedger.open(request.getQueryString("id")); }
        catch (RuntimeException ex) { return Accumulator.done(F.Either.Left(Results.badRequest("invalid/reused id"))); }
        e.materialized = true;
        List<Path> created = Collections.synchronizedList(new ArrayList<>());
        java.util.concurrent.atomic.AtomicBoolean failed = new java.util.concurrent.atomic.AtomicBoolean();
        Runnable cleanup = () -> { synchronized (created) { for (Path path : created) remove(path); } };
        var parser = new BodyParser.DelegatingMultipartFormDataBodyParser<Path>(materializer, 1024, MAX_LENGTH, true, errors) {
            public java.util.function.Function<play.core.parsers.Multipart.FileInfo, Accumulator<ByteString, Http.MultipartFormData.FilePart<Path>>> createFilePartHandler() {
                return info -> {
                    try {
                        Files.createDirectories(ROOT.resolve("tmp"));
                        Path path = Files.createTempFile(ROOT.resolve("tmp"), "part-", ".tmp"); created.add(path);
                        return Accumulator.fromSink(FileIO.toPath(path).mapMaterializedValue(done -> {
                            e.fileStarted();
                            return done.whenComplete((ioResult, error) -> e.fileClosed());
                        })).mapFuture(io -> {
                            if (failed.get() || !io.wasSuccessful()) remove(path);
                            if (!io.wasSuccessful()) return CompletableFuture.failedFuture(io.getError());
                            e.produced(io.count());
                            return CompletableFuture.completedFuture(new Http.MultipartFormData.FilePart<Path>(info.partName(), info.fileName(), info.contentType().getOrElse(() -> "application/octet-stream"), path, io.count()));
                        }, Runnable::run).recover(error -> { remove(path); throw new CompletionException(error); }, Runnable::run);
                    } catch (java.io.IOException ex) { throw new java.io.UncheckedIOException(ex); }
                };
            }
        };
        return parser.apply(request).map(result -> {
            if (result.left.isPresent()) { failed.set(true); cleanup.run(); }
            e.close(null); return result;
        }, Runnable::run).recover(error -> {
            failed.set(true); cleanup.run(); e.close(error); throw new CompletionException(error);
        }, Runnable::run);
    }
    public static void remove(Path path) {
        try { Files.deleteIfExists(path); } catch (java.io.IOException ex) { throw new java.io.UncheckedIOException(ex); }
    }
}
