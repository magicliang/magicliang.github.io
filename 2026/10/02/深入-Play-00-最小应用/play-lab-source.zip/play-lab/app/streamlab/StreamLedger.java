package streamlab;

import java.util.*;
import com.fasterxml.jackson.databind.node.ObjectNode;
import play.libs.Json;

/** Bounded observations; active records are never silently evicted. */
public final class StreamLedger {
    private static final Map<String, Entry> entries = new LinkedHashMap<>();
    public static synchronized Entry open(String id) {
        if (!id.matches("[A-Za-z0-9_-]{1,64}")) throw new IllegalArgumentException("invalid id");
        if (entries.containsKey(id)) throw new IllegalArgumentException("id already used");
        if (entries.size() >= 128) {
            var it = entries.values().iterator();
            while (it.hasNext()) { if (it.next().terminated) { it.remove(); break; } }
        }
        if (entries.size() >= 128) throw new IllegalStateException("ledger capacity");
        Entry e = new Entry(id); entries.put(id, e); return e;
    }
    public static synchronized Entry get(String id) { return entries.get(id); }
    public static final class Entry {
        public final String id;
        public volatile boolean materialized, terminated;
        public long producedChunks, bytes;
        public int closeCount;
        public int fileIoStarted, fileIoClosed;
        public String failure = "";
        public volatile String workStage = "";
        public volatile boolean futureCancelled;
        Entry(String id) { this.id = id; }
        public synchronized void fileStarted() { fileIoStarted++; }
        public synchronized void fileClosed() { fileIoClosed++; }
        public synchronized void produced(long size) { producedChunks++; bytes += size; }
        public synchronized void close(Throwable error) {
            if (!terminated) { terminated = true; closeCount++; failure = error == null ? "" : error.getClass().getSimpleName(); }
        }
        public synchronized ObjectNode json() {
            return Json.newObject().put("id", id).put("materialized", materialized).put("terminated", terminated)
                .put("fileIoStarted", fileIoStarted).put("fileIoClosed", fileIoClosed)
                .put("workStage", workStage).put("futureCancelled", futureCancelled)
                .put("producedChunks", producedChunks).put("bytes", bytes).put("closeCount", closeCount).put("failure", failure);
        }
    }
}
