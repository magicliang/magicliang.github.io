package labasync;

import static labasync.LabSupport.*;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;
import java.util.function.Supplier;
import org.slf4j.MDC;
import play.libs.Json;
import play.libs.concurrent.ClassLoaderExecution;
import play.libs.typedmap.TypedKey;
import play.mvc.Http;

public final class ContextLab {
    private static final TypedKey<String> USER = TypedKey.create("lab-user");
    private static final TypedKey<String> REQUEST_ID = TypedKey.create("lab-request-id");
    private record RequestContext(Http.Request request, String requestId, String user, Map<String, String> mdc) {}
    private ContextLab() {}

    public static ObjectNode run(Http.Request original) {
        ExecutorService first = single("lab-context-a"), second = single("lab-context-b");
        Map<String, String> originalMdc = MDC.getCopyOfContextMap();
        ClassLoader originalLoader = Thread.currentThread().getContextClassLoader();
        ClassLoader workerLoader = new ClassLoader(originalLoader) {};
        CountDownLatch stagesStarted = new CountDownLatch(2);
        CompletableFuture<Void> aliceRelease = new CompletableFuture<>(), bobRelease = new CompletableFuture<>();
        List<ObjectNode> events = Collections.synchronizedList(new ArrayList<>());
        ObjectNode out = Json.newObject();
        try {
            get(first.submit(() -> { MDC.setContextMap(Map.of("worker", "a")); Thread.currentThread().setContextClassLoader(workerLoader); }));
            get(second.submit(() -> MDC.setContextMap(Map.of("worker", "b"))));
            RequestContext alice = capture(original, "request-alice", "alice");
            RequestContext bob = capture(original, "request-bob", "bob");
            restore(originalMdc);
            CompletableFuture<String> a = flow(alice, first, second, stagesStarted, aliceRelease, events, false);
            CompletableFuture<String> b = flow(bob, first, second, stagesStarted, bobRelease, events, true);
            await(stagesStarted);
            bobRelease.complete(null);
            String bobResult = get(b.handle((value, error) -> error == null ? value : "failed"));
            out.put("bobResult", bobResult);
            aliceRelease.complete(null);
            out.put("aliceResult", get(a));
            ArrayNode array = out.putArray("events"); events.forEach(array::add);
            out.put("originalRequestUnchanged", !original.attrs().containsKey(USER) && !original.attrs().containsKey(REQUEST_ID));
            out.set("workerAAfterReuse", get(first.submit(() -> Json.toJson(MDC.getCopyOfContextMap()))));
            out.set("workerBAfterReuse", get(second.submit(() -> Json.toJson(MDC.getCopyOfContextMap()))));
            out.set("classLoaderNormal", loader(first, workerLoader, false));
            out.set("classLoaderFailure", loader(first, workerLoader, true));
        } finally {
            aliceRelease.complete(null); bobRelease.complete(null);
            restore(originalMdc); Thread.currentThread().setContextClassLoader(originalLoader);
            closeAll(first, second);
        }
        return out.put("callerMdcRestored", java.util.Objects.equals(originalMdc, MDC.getCopyOfContextMap()))
                .put("callerClassLoaderRestored", originalLoader == Thread.currentThread().getContextClassLoader());
    }

    private static RequestContext capture(Http.Request original, String id, String user) {
        // Capture only this experiment's synthetic context, never serialize the caller's MDC.
        MDC.setContextMap(Map.of("requestId", id, "user", user));
        return new RequestContext(original.addAttr(REQUEST_ID, id).addAttr(USER, user), id, user,
                Map.copyOf(MDC.getCopyOfContextMap()));
    }

    private static CompletableFuture<String> flow(RequestContext context, Executor first, Executor second,
            CountDownLatch started, CompletableFuture<Void> release, List<ObjectNode> events, boolean fail) {
        return CompletableFuture.supplyAsync(() -> withMdc(context.mdc(), () -> {
            events.add(observe(context, "first")); started.countDown(); return context;
        }), first).thenCompose(value -> release.thenApply(ignored -> value))
                .thenApplyAsync(value -> withMdc(value.mdc(), () -> {
                    events.add(observe(value, "second"));
                    if (fail) throw new IllegalStateException("synthetic context failure");
                    return "ok";
                }), second);
    }

    private static ObjectNode observe(RequestContext context, String stage) {
        return Json.newObject().put("stage", stage).put("thread", Thread.currentThread().getName())
                .put("requestId", context.requestId()).put("user", context.user())
                .put("requestAttrId", context.request().attrs().get(REQUEST_ID))
                .put("requestAttrUser", context.request().attrs().get(USER))
                .put("mdcId", MDC.get("requestId")).put("mdcUser", MDC.get("user"));
    }

    private static <T> T withMdc(Map<String, String> captured, Supplier<T> work) {
        Map<String, String> previous = MDC.getCopyOfContextMap();
        MDC.setContextMap(captured);
        try { return work.get(); }
        finally { restore(previous); }
    }

    private static void restore(Map<String, String> previous) {
        if (previous == null) MDC.clear(); else MDC.setContextMap(previous);
    }

    private static ObjectNode loader(ExecutorService worker, ClassLoader baseline, boolean fail) {
        ClassLoader previous = Thread.currentThread().getContextClassLoader();
        Map<String, String> previousMdc = MDC.getCopyOfContextMap();
        ClassLoader marker = new ClassLoader(previous) {};
        CompletableFuture<Void> done = new CompletableFuture<>();
        ObjectNode out = Json.newObject();
        // Catch outside the Play wrapper, so its finally executes and the same worker survives.
        Executor guarded = command -> worker.execute(() -> {
            try { command.run(); done.complete(null); }
            catch (RuntimeException error) { done.completeExceptionally(error); }
        });
        try {
            Thread.currentThread().setContextClassLoader(marker);
            MDC.put("callerOnly", "synthetic");
            Executor captured = ClassLoaderExecution.fromThread(guarded);
            Thread.currentThread().setContextClassLoader(previous);
            restore(previousMdc);
            captured.execute(() -> {
                out.put("capturedLoaderSeen", marker == Thread.currentThread().getContextClassLoader())
                        .put("callerMdcCopied", MDC.get("callerOnly") != null)
                        .put("workerSentinel", MDC.get("worker")).put("thread", Thread.currentThread().getName());
                if (fail) throw new IllegalStateException("synthetic loader failure");
            });
            String outcome = get(done.handle((value, error) -> error == null ? "ok" : "failed"));
            out.put("outcome", outcome);
            out.put("workerLoaderRestored", get(worker.submit(() -> baseline == Thread.currentThread().getContextClassLoader())));
            out.put("workerMdcRestored", get(worker.submit(() -> Map.of("worker", "a").equals(MDC.getCopyOfContextMap()))));
        } finally { Thread.currentThread().setContextClassLoader(previous); restore(previousMdc); }
        return out;
    }
}
