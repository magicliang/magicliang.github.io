package labasync;

import java.util.concurrent.*;

public final class LabSupport {
    private LabSupport() {}

    public static void await(CountDownLatch latch) {
        try {
            if (!latch.await(5, TimeUnit.SECONDS)) throw new IllegalStateException("lab latch timeout");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException(e);
        }
    }

    public static <T> T get(Future<T> future) {
        try { return future.get(5, TimeUnit.SECONDS); }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException(e);
        }
        catch (Exception e) { throw new IllegalStateException(e); }
    }

    public static ExecutorService single(String name) {
        return Executors.newSingleThreadExecutor(Thread.ofPlatform().name(name).factory());
    }

    public static void closeAll(ExecutorService... pools) {
        boolean interrupted = Thread.interrupted();
        RuntimeException first = null;
        try {
            for (ExecutorService pool : pools) {
                try { close(pool); }
                catch (RuntimeException failure) {
                    if (first == null) first = failure;
                    else first.addSuppressed(failure);
                } finally { interrupted |= Thread.interrupted(); }
            }
            if (first != null) throw first;
        } finally { if (interrupted) Thread.currentThread().interrupt(); }
    }

    public static void close(ExecutorService pool) {
        pool.shutdown();
        try {
            if (!pool.awaitTermination(5, TimeUnit.SECONDS)) {
                pool.shutdownNow();
                if (!pool.awaitTermination(5, TimeUnit.SECONDS)) throw new IllegalStateException("lab shutdown timeout");
            }
        } catch (InterruptedException e) {
            pool.shutdownNow();
            Thread.currentThread().interrupt();
            throw new IllegalStateException(e);
        }
    }
}
