package labasync;

import static labasync.LabSupport.*;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;
import play.libs.Json;
import play.mvc.Result;
import play.mvc.Results;

public final class CompositionLab {
    private CompositionLab() {}

    public static ObjectNode composition() {
        ObjectNode out = Json.newObject();
        AtomicInteger prices = new AtomicInteger();
        CompletableFuture<String> inventory = new CompletableFuture<>();
        CompletableFuture<String> price = new CompletableFuture<>();
        CompletableFuture<String> serial = inventory.thenCompose(stock -> {
            prices.incrementAndGet();
            return price.thenApply(value -> stock + ":" + value);
        });
        out.put("serialPriceCallsBeforeInventory", prices.get());
        inventory.complete("stock");
        out.put("serialPriceCallsAfterInventory", prices.get());
        price.complete("price");
        out.put("serialResult", get(serial));
        ExecutorService inventoryPool = single("lab-inventory");
        ExecutorService pricePool = single("lab-price");
        CountDownLatch started = new CountDownLatch(2);
        CountDownLatch release = new CountDownLatch(1);
        try {
            CompletableFuture<String> a = CompletableFuture.supplyAsync(() -> {
                started.countDown(); await(release); return "stock";
            }, inventoryPool);
            CompletableFuture<String> b = CompletableFuture.supplyAsync(() -> {
                started.countDown(); await(release); return "price";
            }, pricePool);
            CompletableFuture<String> parallel = a.thenCombine(b, (stock, value) -> stock + ":" + value);
            await(started);
            out.put("parallelStartedBeforeRelease", 2 - started.getCount());
            out.put("parallelCompletedBeforeRelease", parallel.isDone());
            release.countDown();
            out.put("parallelResult", get(parallel));
        } finally { release.countDown(); closeAll(inventoryPool, pricePool); }
        return out;
    }

    public static CompletionStage<Result> result(String mode) {
        Supplier<CompletionStage<String>> operation = () -> {
            if (mode.equals("sync")) throw new IllegalStateException("synthetic sync failure");
            if (mode.equals("failed")) return CompletableFuture.failedFuture(new IllegalStateException("synthetic stage failure"));
            return CompletableFuture.completedFuture("ok");
        };
        CompletionStage<String> stage;
        try { stage = operation.get(); }
        catch (RuntimeException e) { stage = CompletableFuture.failedFuture(e); }
        return stage.handle((value, error) -> error == null
                ? Results.ok(Json.newObject().put("code", "OK").put("value", value))
                : Results.internalServerError(Json.newObject().put("code", "ASYNC_FAILURE")));
    }

    public static ObjectNode execution() {
        ObjectNode out = Json.newObject().put("driverThread", Thread.currentThread().getName());
        ExecutorService caller = single("lab-caller");
        ExecutorService worker = single("lab-worker");
        CountDownLatch entered = new CountDownLatch(1), release = new CountDownLatch(1);
        CountDownLatch enteredAsync = new CountDownLatch(1), releaseAsync = new CountDownLatch(1);
        try {
            Future<CompletableFuture<String>> invocation = caller.submit(() -> CompletableFuture.completedFuture(blocking(entered, release)));
            await(entered);
            out.put("completedFutureInvocationReturnedBeforeRelease", invocation.isDone());
            release.countDown();
            out.put("completedFutureWorkThread", get(get(invocation)));
            Future<CompletableFuture<String>> asyncInvocation = caller.submit(() -> CompletableFuture.supplyAsync(() -> blocking(enteredAsync, releaseAsync), worker));
            CompletableFuture<String> asyncStage = get(asyncInvocation);
            await(enteredAsync);
            out.put("supplyAsyncInvocationReturnedBeforeRelease", asyncInvocation.isDone());
            out.put("supplyAsyncStageDoneBeforeRelease", asyncStage.isDone());
            releaseAsync.countDown();
            out.put("supplyAsyncWorkThread", get(asyncStage));
            CompletableFuture<String> pending = new CompletableFuture<>();
            CompletableFuture<String> callback = pending.thenApply(value -> Thread.currentThread().getName());
            get(caller.submit(() -> pending.complete("ready")));
            out.put("pendingThenApplyThread", get(callback));
            String completedThread = get(CompletableFuture.completedFuture("ready").thenApply(value -> Thread.currentThread().getName()));
            String explicitThread = get(CompletableFuture.completedFuture("ready").thenApplyAsync(value -> Thread.currentThread().getName(), worker));
            out.put("completedThenApplyThread", completedThread);
            out.put("explicitThenApplyAsyncThread", explicitThread);
        } finally { release.countDown(); releaseAsync.countDown(); closeAll(caller, worker); }
        return out;
    }

    private static String blocking(CountDownLatch entered, CountDownLatch release) {
        entered.countDown(); await(release); return Thread.currentThread().getName();
    }
}
