package labasync;

import static labasync.LabSupport.*;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.typesafe.config.Config;
import jakarta.inject.Inject;
import java.util.UUID;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.pekko.actor.ActorSystem;
import play.libs.Json;

public final class ExecutorLab {
    private final ActorSystem applicationSystem;
    private final LabExecutionContext dedicated;
    private final Config config;

    @Inject
    public ExecutorLab(ActorSystem applicationSystem, LabExecutionContext dedicated, Config config) {
        this.applicationSystem = applicationSystem;
        this.dedicated = dedicated;
        this.config = config;
    }

    public ObjectNode placement() {
        ObjectNode out = Json.newObject();
        out.set("default", position(applicationSystem.dispatcher()));
        out.set("dedicated", position(dedicated.current()));
        out.set("cpuDefault", compute(applicationSystem.dispatcher()));
        out.set("cpuDedicated", compute(dedicated.current()));
        return out;
    }

    private ObjectNode compute(Executor executor) {
        return get(CompletableFuture.supplyAsync(() -> {
            int inputSize = 100_000;
            long checksum = 0;
            for (long value = 1; value <= inputSize; value++) checksum += value * value;
            return Json.newObject().put("thread", Thread.currentThread().getName())
                    .put("inputSize", inputSize).put("checksum", checksum);
        }, executor));
    }

    private ObjectNode position(Executor executor) {
        CountDownLatch entered = new CountDownLatch(1), release = new CountDownLatch(1);
        AtomicInteger active = new AtomicInteger();
        CompletableFuture<String> thread = new CompletableFuture<>();
        CompletableFuture<Void> done = new CompletableFuture<>();
        try {
            executor.execute(() -> {
                active.incrementAndGet();
                thread.complete(Thread.currentThread().getName());
                entered.countDown();
                try { await(release); done.complete(null); }
                catch (Throwable error) { done.completeExceptionally(error); }
                finally { active.decrementAndGet(); }
            });
            await(entered);
            ObjectNode out = Json.newObject().put("thread", get(thread)).put("inFlightBeforeRelease", active.get());
            release.countDown(); get(done);
            return out;
        } finally { release.countDown(); }
    }

    public ObjectNode pekko() {
        ActorSystem isolated = ActorSystem.create("lab-saturation-" + UUID.randomUUID(), config);
        Executor executor = new LabExecutionContext(isolated).current();
        CountDownLatch entered = new CountDownLatch(2), release = new CountDownLatch(1);
        AtomicInteger active = new AtomicInteger(), completed = new AtomicInteger();
        AtomicInteger submitted = new AtomicInteger(), started = new AtomicInteger();
        CompletableFuture<Void> first = new CompletableFuture<>(), second = new CompletableFuture<>(), third = new CompletableFuture<>();
        ObjectNode out = Json.newObject().put("driverThread", Thread.currentThread().getName());
        try {
            submitted.incrementAndGet();
            executor.execute(() -> { started.incrementAndGet(); blocked(entered, release, active, completed, first).run(); });
            submitted.incrementAndGet();
            executor.execute(() -> { started.incrementAndGet(); blocked(entered, release, active, completed, second).run(); });
            await(entered);
            submitted.incrementAndGet();
            executor.execute(() -> { started.incrementAndGet(); completed.incrementAndGet(); third.complete(null); });
            out.put("activeBeforeFourth", active.get());
            out.put("thirdStartedBeforeRelease", third.isDone());
            // The queued third task cannot start: both workers remain behind release.
            out.put("pendingBeforeFourth", submitted.get() - started.get());
            submitted.incrementAndGet();
            executor.execute(() -> {
                started.incrementAndGet();
                out.put("fourthThread", Thread.currentThread().getName())
                        .put("activeDuringFourth", active.incrementAndGet());
                active.decrementAndGet(); completed.incrementAndGet();
            });
            out.put("fourthCallerRuns", out.path("driverThread").asText().equals(out.path("fourthThread").asText()));
            release.countDown();
            get(first); get(second); get(third);
            out.put("completedAfterRelease", completed.get()).put("inFlightAfterRelease", active.get());
        } finally {
            release.countDown();
            isolated.terminate();
            get(isolated.getWhenTerminated().toCompletableFuture());
        }
        return out.put("actorSystemTerminated", isolated.getWhenTerminated().toCompletableFuture().isDone());
    }

    public ObjectNode abort() {
        ThreadPoolExecutor pool = new ThreadPoolExecutor(2, 2, 0L, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<>(1), Thread.ofPlatform().name("lab-abort-", 0).factory(), new ThreadPoolExecutor.AbortPolicy());
        CountDownLatch entered = new CountDownLatch(2), release = new CountDownLatch(1);
        AtomicInteger active = new AtomicInteger(), completed = new AtomicInteger();
        CompletableFuture<Void> first = new CompletableFuture<>(), second = new CompletableFuture<>(), third = new CompletableFuture<>();
        ObjectNode out = Json.newObject();
        try {
            pool.execute(blocked(entered, release, active, completed, first));
            pool.execute(blocked(entered, release, active, completed, second));
            await(entered);
            pool.execute(() -> { completed.incrementAndGet(); third.complete(null); });
            out.put("activeBeforeFourth", pool.getActiveCount()).put("queueBeforeFourth", pool.getQueue().size());
            try {
                pool.execute(() -> completed.incrementAndGet());
                out.put("fourthStatus", 200);
            } catch (RejectedExecutionException rejected) { out.put("fourthStatus", 503); }
            release.countDown(); get(first); get(second); get(third);
        } finally { release.countDown(); close(pool); }
        return out.put("completedAfterRelease", completed.get()).put("inFlightAfterRelease", active.get())
                .put("queueAfterRelease", pool.getQueue().size()).put("terminated", pool.isTerminated());
    }

    private Runnable blocked(CountDownLatch entered, CountDownLatch release, AtomicInteger active,
                             AtomicInteger completed, CompletableFuture<Void> done) {
        return () -> {
            active.incrementAndGet(); entered.countDown();
            Throwable failure = null;
            try { await(release); }
            catch (Throwable error) { failure = error; }
            finally { active.decrementAndGet(); completed.incrementAndGet(); }
            if (failure == null) done.complete(null); else done.completeExceptionally(failure);
        };
    }
}
