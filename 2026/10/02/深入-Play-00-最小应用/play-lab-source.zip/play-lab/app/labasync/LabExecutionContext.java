package labasync;

import jakarta.inject.Inject;
import org.apache.pekko.actor.ActorSystem;
import play.libs.concurrent.CustomExecutionContext;

public final class LabExecutionContext extends CustomExecutionContext {
    @Inject
    public LabExecutionContext(ActorSystem system) {
        super(system, "lab-blocking-dispatcher");
    }
}
