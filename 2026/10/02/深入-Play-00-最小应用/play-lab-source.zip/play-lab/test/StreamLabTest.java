import static org.junit.Assert.*;
import static play.test.Helpers.*;
import org.junit.Test;
import play.Application;
import play.inject.guice.GuiceApplicationBuilder;
import play.test.WithApplication;
import play.libs.EventSource;
import play.libs.Json;
import streamlab.StreamLedger;
import java.util.UUID;

public class StreamLabTest extends WithApplication {
    @Override protected Application provideApplication() { return new GuiceApplicationBuilder().build(); }
    private String id() { return UUID.randomUUID().toString(); }
    @Test public void knownAndUnknownLengthHaveExactFiniteBodies() {
        for (boolean known : new boolean[]{true, false}) {
            String id = id();
            var result = route(app, fakeRequest(GET, "/streamlab/data?id=" + id + "&chunks=4&known=" + known));
            assertEquals(200, result.status());
            assertEquals(65536, contentAsBytes(result, app.injector().instanceOf(org.apache.pekko.stream.Materializer.class)).size());
            var e = StreamLedger.get(id);
            assertEquals(4, e.producedChunks); assertEquals(65536, e.bytes);
            assertTrue(e.materialized); assertTrue(e.terminated); assertEquals(1, e.closeCount);
            assertEquals(known, result.body().contentLength().isPresent());
            System.out.println("STREAM known=" + known + " " + e.json());
        }
    }
    @Test public void limitsAndCursorRulesRejectInvalidInputs() {
        assertEquals(400, route(app, fakeRequest(GET, "/streamlab/data?id=" + id() + "&chunks=2049")).status());
        assertEquals(410, route(app, fakeRequest(GET, "/streamlab/sse?id=" + id()).header("Last-Event-ID", "99")).status());
        assertEquals(400, route(app, fakeRequest(GET, "/streamlab/sse?id=" + id()).header("Last-Event-ID", "121")).status());
        assertEquals(204, route(app, fakeRequest(GET, "/streamlab/sse?id=" + id()).header("Last-Event-ID", "120")).status());
    }
    @Test public void eventSourceEncodesEveryDataLine() {
        String encoded = EventSource.Event.event("first\nsecond").withId("101").withName("sample").formatted();
        assertTrue(encoded.contains("data: first\ndata: second\n"));
        assertTrue(encoded.contains("id: 101\n")); assertTrue(encoded.endsWith("\n\n"));
        System.out.println("SSE formatted=" + Json.toJson(encoded));
    }
    @Test public void applicationStopTerminatesMaterializedSse() throws Exception {
        Application local = new GuiceApplicationBuilder().build();
        start(local);
        String id = id();
        try {
            var result = route(local, fakeRequest(GET, "/streamlab/sse?id=" + id));
            var mat = local.injector().instanceOf(org.apache.pekko.stream.Materializer.class);
            var done = result.body().dataStream().runWith(org.apache.pekko.stream.javadsl.Sink.ignore(), mat);
            for (int i = 0; i < 100 && StreamLedger.get(id).producedChunks == 0; i++) Thread.sleep(10);
            assertTrue(StreamLedger.get(id).materialized);
            stop(local);
            for (int i = 0; i < 100 && !StreamLedger.get(id).terminated; i++) Thread.sleep(10);
            var e = StreamLedger.get(id);
            assertTrue(e.terminated); assertEquals(1, e.closeCount);
            assertTrue(done.toCompletableFuture().isDone());
            assertTrue(e.producedChunks < 39);
            System.out.println("STREAM application-stop=" + e.json());
        } finally { stop(local); }
    }
    @Test public void upstreamFailureClosesOnce() throws Exception {
        String id = id();
        var result = route(app, fakeRequest(GET, "/streamlab/data?id=" + id + "&chunks=100&failAt=3"));
        try { contentAsBytes(result, app.injector().instanceOf(org.apache.pekko.stream.Materializer.class)); fail("stream must fail"); } catch (RuntimeException expected) { }
        var e = StreamLedger.get(id);
        for (int i = 0; i < 100 && !e.terminated; i++) Thread.sleep(10);
        assertTrue(e.terminated); assertEquals(1, e.closeCount); assertFalse(e.failure.isEmpty());
        assertEquals(3, e.producedChunks); System.out.println("STREAM failure=" + e.json());
    }
}
