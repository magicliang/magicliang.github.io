import static org.junit.Assert.*;
import com.fasterxml.jackson.databind.JsonNode;
import labdb.PoolLab;
import labdb.TransactionLab;
import org.junit.Assume;
import org.junit.Test;
import play.Application;
import play.inject.guice.GuiceApplicationBuilder;
import play.test.WithApplication;

public class DatabaseLabTest extends WithApplication {
    @Override protected Application provideApplication() { return new GuiceApplicationBuilder().build(); }
    private void enabled() { Assume.assumeTrue("DB fixture is opt-in", "true".equals(System.getenv("PLAY_LAB_DB_ENABLED"))); }
    @Test public void stopStartRaceRejectsNewWorkWithoutInventingInFlightJobs() {
        enabled(); var job = app.injector().instanceOf(lifecycle.ManagedDatabaseJob.class);
        job.start("race_" + java.util.UUID.randomUUID().toString().replace("-", ""), 700);
        var stopped = java.util.concurrent.CompletableFuture.runAsync(() -> play.test.Helpers.stop(app));
        try {
            PoolLab.poll(() -> job.status().path("stopping").asBoolean());
            try { job.start("rejected_during_stop", 0); fail("stop must reject new scheduling"); }
            catch (java.util.concurrent.RejectedExecutionException expected) { }
            labasync.LabSupport.get(stopped);
            JsonNode state = job.status(); System.out.println("DATABASE stop-start-race " + state);
            assertEquals(0, state.path("inFlight").asInt()); assertEquals("committed-inserted-1", state.path("terminal").asText());
            try { job.start("rejected_after_stop", 0); fail("stopped owner must reject scheduling"); }
            catch (java.util.concurrent.RejectedExecutionException expected) { }
            assertEquals(0, job.status().path("inFlight").asInt());
        } finally { labasync.LabSupport.get(stopped); }
    }
    @Test public void interruptedExecutorCloseStillClosesJdbcPoolAndPreservesPrimary() {
        enabled(); JsonNode out = app.injector().instanceOf(PoolLab.class).interruptedCleanup();
        System.out.println("DATABASE interrupted-cleanup " + out);
        assertEquals(1, out.path("selectOneBeforeInterrupt").asInt()); assertEquals("synthetic primary failure", out.path("primary").asText());
        assertEquals(1, out.path("suppressed").asInt()); assertTrue(out.path("interrupted").asBoolean());
        assertTrue(out.path("poolClosed").asBoolean()); assertTrue(out.path("executorTerminated").asBoolean());
        assertFalse(Thread.currentThread().isInterrupted());
    }
    @Test public void responseTimeoutCanPrecedeOrFollowCommitAndRetryRemainsUnique() {
        enabled(); var late = app.injector().instanceOf(labdb.LateCommitLab.class);
        for (boolean committed : new boolean[]{false, true}) {
            JsonNode response = labasync.LabSupport.get(late.start(committed).toCompletableFuture());
            String id = response.path("id").asText();
            try {
                JsonNode before = late.status(id, false, false);
                assertEquals("TIMEOUT", response.path("response").asText()); assertFalse(response.path("taskDoneAtResponse").asBoolean());
                assertEquals(committed ? 1 : 0, before.path("ordersOnNewConnection").asInt());
                JsonNode after = late.status(id, true, true);
                System.out.println("DATABASE HTTP-timeout-model committedFirst=" + committed + " response=" + response + " before=" + before + " after=" + after);
                assertTrue(after.path("taskDone").asBoolean()); assertEquals(1, after.path("ordersOnNewConnection").asInt()); assertEquals(0, after.path("retryInserted").asInt());
            } finally { late.status(id, true, false); }
        }
    }
    @Test public void evolutionsExpandBackfillAndExposeFailureState() {
        enabled(); JsonNode out = app.injector().instanceOf(labdb.EvolutionLab.class).run(); System.out.println("DATABASE evolutions " + out);
        assertEquals(1, out.path("afterEmpty").asInt()); assertEquals(1, out.path("afterRestart").asInt());
        assertEquals(2, out.path("afterRevisionTwo").asInt()); assertEquals(1, out.path("backfilledRows").asInt());
        assertEquals(1, out.path("notNullColumns").asInt());
        assertNotEquals("unexpected-success", out.path("autocommitTrue").path("outcome").asText());
        assertNotEquals("unexpected-success", out.path("autocommitFalse").path("outcome").asText());
        assertEquals(1, out.path("autocommitTrue").path("partialTableExists").asInt());
        assertEquals(0, out.path("autocommitFalse").path("partialTableExists").asInt());
        assertEquals("applying_up", out.path("autocommitTrue").path("metadataStates").asText());
        assertEquals(1, out.path("autocommitTrue").path("metadataRows").asInt());
        assertEquals(0, out.path("autocommitFalse").path("metadataRows").asInt());
    }
    @Test public void stopHooksDrainWorkAndContinueAfterBothFailureKinds() throws Exception {
        enabled(); var job = app.injector().instanceOf(lifecycle.ManagedDatabaseJob.class);
        JsonNode started = job.start("unit_" + java.util.UUID.randomUUID().toString().replace("-", ""), 200);
        play.test.Helpers.stop(app);
        String journal = java.nio.file.Files.readString(java.nio.file.Path.of(started.path("journal").asText()));
        System.out.println("DATABASE lifecycle " + journal);
        assertTrue(journal.contains("committed-inserted-1"));
        assertTrue(journal.indexOf("drain-start") < journal.indexOf("drain-end"));
        assertTrue(journal.indexOf("drain-end") < journal.indexOf("sync-failure"));
        assertTrue(journal.indexOf("sync-failure") < journal.indexOf("async-failure"));
        assertTrue(journal.indexOf("async-failure") < journal.indexOf("final-cleanup"));
        assertTrue(journal.contains("fileClosed=true,workerTerminated=true,schedulerTerminated=true"));
        assertTrue(journal.contains("poolClosed=true"));
    }
    @Test public void poolAndExecutorQueuesAreDistinctAndFailuresReturnConnections() {
        enabled(); JsonNode out = app.injector().instanceOf(PoolLab.class).run(); System.out.println("DATABASE pools " + out);
        assertEquals(2, out.path("executor4").path("waitingForConnection").asInt());
        assertEquals(0, out.path("executor4").path("executorQueued").asInt());
        assertEquals(0, out.path("executor2").path("waitingForConnection").asInt());
        assertEquals(2, out.path("executor2").path("executorQueued").asInt());
        for (String name : new String[]{"executor4", "executor2"}) {
            assertEquals(0, out.path(name).path("activeAfterTasks").asInt());
            assertEquals(4, out.path(name).path("tasks").size());
            for (JsonNode task : out.path(name).path("tasks")) {
                assertEquals("ok", task.path("outcome").asText());
                assertTrue(task.path("startedMicros").asLong() >= task.path("submittedMicros").asLong());
                assertTrue(task.path("borrowedMicros").asLong() >= task.path("borrowStartedMicros").asLong());
                assertTrue(task.path("returnedMicros").asLong() >= task.path("sqlFinishedMicros").asLong());
            }
        }
        assertEquals("22012", out.path("recovery").path("sqlError").asText());
        assertEquals(0, out.path("recovery").path("activeAfterFailures").asInt());
        assertEquals(1, out.path("recovery").path("selectOneAfterFailures").asInt());
        assertNotEquals("unexpected-success", out.path("recovery").path("borrowTimeout").asText());
        assertTrue(out.path("defaultSql").path("thread").asText().contains("default-dispatcher"));
        assertTrue(out.path("dedicatedSql").path("thread").asText().contains("lab-blocking-dispatcher"));
    }
    @Test public void realTransactionsRollbackDeduplicateAndOutliveResponseTimeouts() {
        enabled(); JsonNode out = app.injector().instanceOf(TransactionLab.class).run(); System.out.println("DATABASE transactions " + out);
        assertEquals("CREATED", out.path("success").asText());
        assertEquals(1, out.path("successState").path("orders").asInt());
        assertEquals(0, out.path("rollbackState").path("orders").asInt());
        assertEquals(1, out.path("rollbackState").path("remaining").asInt());
        assertEquals(1, out.path("sameKeyState").path("orders").asInt());
        assertEquals(0, out.path("sameKeyState").path("remaining").asInt());
        assertEquals("CONFLICT", out.path("changedPayload").asText());
        assertEquals(1, out.path("differentKeyState").path("orders").asInt());
        assertEquals(0, out.path("differentKeyState").path("remaining").asInt());
        assertFalse(out.path("scope").path("stageDoneAfterTransactionReturned").asBoolean());
        assertEquals(1, out.path("scope").path("committedBeforeStageRelease").asInt());
        assertTrue(out.path("scope").path("asyncConnectionOutcome").asText().contains("closed=true"));
        assertFalse(out.path("lateCommit").path("taskDoneAtTimeout").asBoolean());
        assertEquals(0, out.path("lateCommit").path("ordersAtTimeout").asInt());
        assertEquals(1, out.path("lateCommit").path("ordersAfterLateCommit").asInt());
        assertEquals("REPLAY", out.path("lateCommit").path("retryByKey").asText());
        assertEquals("57014", out.path("statementTimeout").path("sqlState").asText());
        assertEquals(1, out.path("statementTimeout").path("stateAfterFailure").path("remaining").asInt());
    }
}
