import static org.junit.Assert.*;
import static play.test.Helpers.*;

import com.fasterxml.jackson.databind.JsonNode;
import labbudget.CacheLab;
import labbudget.TimeoutLab;
import labbudget.WsLab;
import labbudget.WsBoundaryLab;
import org.junit.Test;
import play.Application;
import play.inject.guice.GuiceApplicationBuilder;
import play.libs.Json;
import play.test.WithApplication;

public class BudgetTest extends WithApplication {
    @Override protected Application provideApplication() { return new GuiceApplicationBuilder().build(); }

    private JsonNode report(String name, JsonNode out) {
        System.out.println("BUDGET " + name + " " + out); return out;
    }

    @Test public void timeoutDoesNotCancelAndCooperativeProtocolStopsEffect() {
        JsonNode out = report("timeout", app.injector().instanceOf(TimeoutLab.class).run());
        assertEquals("TimeoutException", out.path("timeoutOutcome").asText());
        assertFalse(out.path("originalDoneAtTimeout").asBoolean());
        assertFalse(out.path("originalCancelledAtTimeout").asBoolean());
        assertEquals("late-success", out.path("lateOutcome").asText());
        assertEquals("TimeoutException", out.path("cooperativeTimeoutOutcome").asText());
        assertEquals("cooperatively-cancelled", out.path("cooperativeTerminal").asText());
        assertEquals(0, out.path("cooperativeSideEffects").asInt());
        assertEquals(3, out.path("retrySuccess").path("attempts").asInt());
        assertEquals("ok", out.path("retrySuccess").path("outcome").asText());
        assertEquals(3, out.path("retryExhausted").path("attempts").asInt());
        assertEquals("failed", out.path("retryExhausted").path("outcome").asText());
        assertEquals(1, out.path("retryFatal").path("attempts").asInt());
        assertTrue(out.path("workerTerminated").asBoolean());
    }

    @Test public void realLoopbackWsShowsCompletionTimeoutAndRedirectBoundaries() {
        JsonNode out = report("ws", app.injector().instanceOf(WsLab.class).run());
        assertFalse(out.path("aggregateDoneAfterPrefix").asBoolean());
        assertTrue(out.path("streamResponseDoneBeforeBodyRelease").asBoolean());
        assertFalse(out.path("streamBodyDoneBeforeRelease").asBoolean());
        assertEquals("prefix-suffix", out.path("aggregateBody").asText());
        assertEquals("prefix-suffix", out.path("streamBody").asText());
        assertEquals(13, out.path("streamConsumedBytes").asInt());
        assertEquals("completed", out.path("aggregateServerTerminal").asText());
        assertEquals("completed", out.path("streamServerTerminal").asText());
        assertEquals("TimeoutException", out.path("outerTimeoutOutcome").asText());
        assertFalse(out.path("wsDoneAtOuterTimeout").asBoolean());
        assertFalse(out.path("wsCancelledAtOuterTimeout").asBoolean());
        assertEquals(200, out.path("outerLateStatus").asInt());
        assertEquals("completed", out.path("outerServerTerminal").asText());
        assertEquals("TimeoutException", out.path("wsTimeoutOutcome").asText());
        assertTrue(out.path("wsDoneAtOwnTimeout").asBoolean());
        assertFalse(out.path("ownServerTerminal").asText().isEmpty());
        assertEquals(302, out.path("redirectDisabledStatus").asInt());
        assertEquals(0, out.path("targetCallsWhenDisabled").asInt());
        assertEquals(200, out.path("redirectEnabledStatus").asInt());
        assertEquals(1, out.path("targetCallsWhenEnabled").asInt());
        assertEquals("redirect-target", out.path("redirectBody").asText());
        assertNotEquals(out.path("originPort").asInt(), out.path("targetPort").asInt());
        // Regression for the observed pinned client: same IP, different port, explicit follow=true.
        assertEquals(3, out.path("redirectTargetHeaders").size());
        assertEquals("Bearer synthetic-only", out.path("redirectTargetHeaders").path("authorization").asText());
        assertEquals("lab=synthetic-only", out.path("redirectTargetHeaders").path("cookie").asText());
        assertEquals("synthetic-only", out.path("redirectTargetHeaders").path("customCredential").asText());
        assertTrue(out.path("serverWorkersTerminated").asBoolean());
        assertTrue(out.path("allGatedHandlersDone").asBoolean());
        JsonNode bounds = out.path("boundaries");
        assertEquals(1, bounds.path("effectiveMaxConnectionsPerHost").asInt());
        assertEquals(2, bounds.path("effectiveMaxConnectionsTotal").asInt());
        assertTrue(bounds.path("consumedBeforeTakeCancellation").asInt() > 0);
        assertTrue(bounds.path("consumedBeforeTakeCancellation").asInt() <= 32 * 1024);
        assertTrue(bounds.path("consumedBeforeTakeCancellation").asInt() < bounds.path("plannedLargeBodyBytes").asInt());
        assertEquals(200, bounds.path("requestAfterCancellationStatus").asInt());
        assertEquals("REJECTED_TARGET", bounds.path("initialOutside").path("outcome").asText());
        assertEquals(0, bounds.path("initialOutside").path("requestsSent").asInt());
        assertEquals(0, bounds.path("outsideCallsAfterInitialRejection").asInt());
        assertEquals("REJECTED_TARGET", bounds.path("redirectOutside").path("outcome").asText());
        assertEquals(1, bounds.path("redirectOutside").path("requestsSent").asInt());
        assertEquals(0, bounds.path("outsideCallsAfterRedirectRejection").asInt());
        assertEquals("OK", bounds.path("redirectInside").path("outcome").asText());
        assertEquals(2, bounds.path("redirectInside").path("requestsSent").asInt());
        assertEquals(1, bounds.path("outsideCallsAfterInitialOnlyValidation").asInt());
        assertTrue(bounds.path("largeHandlerDone").asBoolean());
        assertEquals(bounds.path("handlersStarted"), bounds.path("handlersFinished"));
        assertTrue(bounds.path("clientClosed").asBoolean());
        assertTrue(bounds.path("serverWorkersTerminated").asBoolean());
        assertTrue(bounds.path("deadlineCallerTerminated").asBoolean());
        assertTrue(bounds.path("deadlineTimerTerminated").asBoolean());
        JsonNode deadline = bounds.path("deadline");
        assertTrue(deadline.path("allFourHandlersDone").asBoolean());
        assertEquals(0, deadline.path("handlersForAlreadyExpired").asInt());
        JsonNode expired = deadline.path("alreadyExpired");
        assertEquals("DEADLINE_EXHAUSTED", expired.path("outcome").asText());
        assertEquals(0, expired.path("requestsSent").asInt());
        assertEquals(0, expired.path("requestTimeoutMillis").size());
        JsonNode exceeded = deadline.path("exceededAcrossHops");
        assertEquals("TIMEOUT", exceeded.path("outcome").asText());
        assertEquals("TimeoutException", exceeded.path("failureClass").asText());
        assertEquals(2, exceeded.path("requestsSent").asInt());
        assertEquals(1, exceeded.path("responseStatuses").size());
        assertEquals(302, exceeded.path("responseStatuses").get(0).asInt());
        assertTrue(exceeded.path("secondEnteredBeforeOutcome").asBoolean());
        assertFalse(exceeded.path("secondReleasedBeforeOutcome").asBoolean());
        assertFalse(exceeded.path("secondDoneBeforeOutcome").asBoolean());
        assertTrue(exceeded.path("secondIndependentlyReleased").asBoolean());
        assertEquals(1350, exceeded.path("secondReleaseDelayMillis").asInt());
        assertEquals("completed", exceeded.path("firstHandlerTerminal").asText());
        assertFalse(exceeded.path("secondHandlerTerminal").asText().isEmpty());
        JsonNode enough = deadline.path("enoughAcrossHops");
        assertEquals("OK", enough.path("outcome").asText());
        assertEquals(200, enough.path("status").asInt());
        assertEquals("deadline-ok", enough.path("body").asText());
        assertEquals(2, enough.path("requestsSent").asInt());
        assertEquals(302, enough.path("responseStatuses").get(0).asInt());
        assertEquals(200, enough.path("responseStatuses").get(1).asInt());
        assertTrue(enough.path("remainingNanosAtTerminal").asLong() > 0);
        assertEquals("completed", enough.path("firstHandlerTerminal").asText());
        assertEquals("completed", enough.path("secondHandlerTerminal").asText());
        for (JsonNode scenario : new JsonNode[] {exceeded, enough}) {
            assertEquals(2, scenario.path("remainingMillisBeforeRequests").size());
            assertEquals(2, scenario.path("requestTimeoutMillis").size());
            assertTrue(scenario.path("requestTimeoutMillis").get(1).asLong()
                    < scenario.path("requestTimeoutMillis").get(0).asLong());
            for (int hop = 0; hop < 2; hop++) {
                long remaining = scenario.path("remainingMillisBeforeRequests").get(hop).asLong();
                long configured = scenario.path("requestTimeoutMillis").get(hop).asLong();
                assertTrue(configured > 0);
                assertEquals(Math.min(3000, remaining), configured);
            }
        }
    }

    @Test public void interruptedCoordinatorClosesEveryWsResource() throws Exception {
        var fixture = app.injector().instanceOf(WsBoundaryLab.class);
        var task = new java.util.concurrent.FutureTask<>(fixture::interruptedRun);
        Thread coordinator = Thread.ofPlatform().name("lab-interrupted-ws").start(task);
        JsonNode out = report("ws-interrupted", task.get(10, java.util.concurrent.TimeUnit.SECONDS));
        coordinator.join(5000);
        assertFalse(coordinator.isAlive());
        assertEquals("IllegalStateException", out.path("failureClass").asText());
        assertEquals("InterruptedException", out.path("failureCause").asText());
        for (String field : new String[] {"coordinatorInterruptRestored", "clientClosed", "largeHandlerDone",
                "serverWorkersTerminated", "deadlineCallerTerminated", "deadlineTimerTerminated",
                "deadlineShortTaskDone", "deadlineSecondEntered", "deadlineEnteredHandlersDone"}) {
            assertTrue(field, out.path(field).asBoolean());
        }
        assertEquals(out.path("handlersStarted"), out.path("handlersFinished"));
        for (String field : new String[] {"allowedOrigin", "outsideOrigin"}) {
            var uri = java.net.URI.create(out.path(field).asText());
            try (var socket = new java.net.Socket()) {
                try {
                    socket.connect(new java.net.InetSocketAddress(uri.getHost(), uri.getPort()), 1000);
                    fail(field + " still accepts connections");
                } catch (java.net.ConnectException expected) { }
            }
        }
    }

    @Test public void caffeineCoalescesColdLoadsEvictsFailuresExpiresAndSeparatesSubjects() {
        JsonNode out = report("cache", app.injector().instanceOf(CacheLab.class).run());
        assertEquals(4, out.path("coldCallers").asInt());
        assertEquals(1, out.path("loadsBeforeRelease").asInt());
        assertEquals(0, out.path("callersDoneBeforeRelease").asInt());
        assertEquals(4, out.path("coldCompleted").asInt());
        assertEquals("loaded", out.path("hotValue").asText());
        assertEquals(1, out.path("loadsAfterHot").asInt());
        assertEquals("IllegalStateException", out.path("failedLoadOutcome").asText());
        assertTrue(out.path("failedEntryRemoved").asBoolean());
        assertEquals(2, out.path("failureLoaderCalls").asInt());
        assertEquals("reloaded", out.path("reloadValue").asText());
        assertTrue(out.path("ttlInitiallyPresent").asBoolean());
        assertTrue(out.path("ttlExpired").asBoolean());
        assertTrue(out.path("zeroPresentAfterTtlExpired").asBoolean());
        assertEquals("alice-private", out.path("aliceValue").asText());
        assertEquals("bob-private", out.path("bobValue").asText());
        assertTrue(out.path("allExperimentKeysRemoved").asBoolean());
        assertTrue(out.path("callersTerminated").asBoolean());
        assertEquals("v1", out.path("beforeUpdateVersion").asText());
        assertEquals("v2", out.path("afterUpdateVersion").asText());
        assertFalse(out.path("oldReaderDoneAfterNewSet").asBoolean());
        assertEquals("new-v2", out.path("cacheAfterNewSet").asText());
        assertEquals(1, out.path("oldLoaderCalls").asInt());
        assertEquals("old-v1", out.path("oldReaderLateValue").asText());
        assertEquals("new-v2", out.path("cacheAfterOldLoaderCompletes").asText());
    }

    @Test public void timeoutRouteReturnsStructuredResult() {
        var result = route(app, fakeRequest(GET, "/budget/timeout"));
        assertEquals(200, result.status());
        assertEquals("late-success", Json.parse(contentAsString(result)).path("lateOutcome").asText());
    }
}
