import static org.junit.Assert.*;
import org.junit.Test;
import capstone.*;
public class CapstoneTest {
    @Test public void signedIdentityCoordinatesMustBeKnown() {
        assertEquals("alice",new Principal("t1","alice").subject());
        for(String tenant:new String[]{"","t3","t1;drop schema"}) {
            try{new Principal(tenant,"alice");fail("invalid tenant");}catch(IllegalArgumentException expected){}
        }
        try{new Principal("t1","mallory");fail("unknown subject");}catch(IllegalArgumentException expected){}
    }
    @Test public void orderInputHasFiniteBounds() {
        OrderRepository.validate("key",1,"note",0);OrderRepository.validate("key",3,"x".repeat(80),2000);
        for(int quantity:new int[]{0,4,Integer.MAX_VALUE})try{OrderRepository.validate("key",quantity,"note",0);fail();}catch(IllegalArgumentException expected){}
        try{OrderRepository.validate("key",1,"secret".repeat(20),0);fail();}catch(IllegalArgumentException expected){}
        try{OrderRepository.validate("key",1,"note",2001);fail();}catch(IllegalArgumentException expected){}
    }
}
