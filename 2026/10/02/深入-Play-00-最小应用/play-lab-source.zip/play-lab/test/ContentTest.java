import static org.junit.Assert.*;
import static play.test.Helpers.*;

import com.fasterxml.jackson.databind.JsonNode;
import content.ReservationForm;
import content.StockService;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.junit.Test;
import play.Application;
import play.data.FormFactory;
import play.data.validation.Constraints;
import play.inject.guice.GuiceApplicationBuilder;
import play.libs.Json;
import play.mvc.Http;
import play.mvc.Result;
import play.test.WithApplication;

public class ContentTest extends WithApplication {
    @Override
    protected Application provideApplication() {
        return new GuiceApplicationBuilder().build();
    }

    private Http.RequestBuilder json(String body) {
        return fakeRequest(POST, "/content/json").header("X-Play-Lab", "synthetic")
                .bodyText(body).header("Content-Type", "application/json");
    }

    private Http.RequestBuilder form(String path, String body) {
        return fakeRequest(POST, path).header("X-Play-Lab", "synthetic")
                .bodyText(body).header("Content-Type", "application/x-www-form-urlencoded");
    }

    private void invalidJson(String input, int status) {
        Result result = route(app, json(input));
        assertEquals(status, result.status());
        assertEquals(Json.parse("{\"code\":\"INVALID_INPUT\"}"), Json.parse(contentAsString(result)));
        System.out.println("CONTENT09 rejected status=" + status + " input=" + input + " body=" + contentAsString(result));
    }

    @Test
    public void strictJsonFieldAndAmountContract() {
        for (String input : List.of("{}", "null", "[]", "{\"name\":\"book\"}",
                "{\"name\":null,\"amount\":\"1\"}", "{\"name\":\"book\",\"amount\":null}",
                "{\"name\":\"book\",\"amount\":\"1\",\"internalCost\":\"0.01\"}",
                "{\"name\":\"book\",\"amount\":1}", "{\"name\":true,\"amount\":\"1\"}",
                "{\"name\":\"\",\"amount\":\"1\"}", "{\"name\":\"   \",\"amount\":\"1\"}",
                Json.stringify(Json.newObject().put("name", "x".repeat(41)).put("amount", "1")))) {
            invalidJson(input, 400);
        }
        for (String amount : List.of("", "0", "-1", "+1", "01", "1e2", "NaN", "1.001", " 1", "1000000000")) {
            invalidJson(Json.stringify(Json.newObject().put("name", "book").put("amount", amount)), 400);
        }
        for (String amount : List.of("0.01", "1", "999999999.99")) {
            Result result = route(app, json(Json.stringify(Json.newObject().put("name", "book").put("amount", amount))));
            assertEquals(201, result.status());
            JsonNode output = Json.parse(contentAsString(result));
            assertEquals(2, output.size());
            assertEquals("book", output.get("name").asText());
            assertEquals(new java.math.BigDecimal(amount).setScale(2).toPlainString(), output.get("amount").asText());
            System.out.println("CONTENT09 accepted " + output);
        }
        String supplementary = "😀".repeat(40);
        assertEquals(201, route(app, json(Json.stringify(Json.newObject()
                .put("name", supplementary).put("amount", "1")))).status());
        invalidJson(Json.stringify(Json.newObject().put("name", supplementary + "😀").put("amount", "1")), 400);
    }

    @Test
    public void parserErrorsUsePublicEnvelopeAndMapperIsObserved() {
        invalidJson("{", 400);
        invalidJson("x".repeat(1025), 413);
        Result wrongType = route(app, json("{}").header("Content-Type", "text/plain"));
        assertEquals(415, wrongType.status());
        assertEquals(Json.parse("{\"code\":\"INVALID_INPUT\"}"), Json.parse(contentAsString(wrongType)));
        JsonNode observation = Json.parse(contentAsString(route(app, fakeRequest(GET, "/content/json/mapper"))));
        assertEquals("123456789.123456789", observation.get("stringDecimal").asText());
        assertEquals("DoubleNode", observation.get("injectedNodeClass").asText());
        assertEquals("DoubleNode", observation.get("activeNodeClass").asText());
        assertNotEquals(observation.get("literal"), observation.get("activeTreeText"));
        System.out.println("CONTENT09 mapper " + observation);
    }

    @Test
    public void formBindingValidationAndRawValuesAreDistinct() {
        assertTrue(new Constraints.RequiredValidator().isValid("   "));
        for (String body : List.of("name=&quantity=1&confirmation=1", "name=++&quantity=1&confirmation=1",
                "name=book&quantity=abc&confirmation=1", "name=book&quantity=0&confirmation=0",
                "name=book&quantity=6&confirmation=6", "name=book&quantity=1&confirmation=2",
                "name=book&confirmation=1", "name=book&quantity=1")) {
            Result result = route(app, form("/content/form", body));
            assertEquals(400, result.status());
            assertTrue(contentAsString(result).contains("FORM_INVALID"));
            assertEquals(1, app.injector().instanceOf(StockService.class).remaining());
            System.out.println("CONTENT10 invalid=" + body + " stock=1");
        }
        Result xss = route(app, form("/content/form", "name=%3Cscript%3Ebad%3C%2Fscript%3E&quantity=abc&confirmation=1"));
        assertEquals(400, xss.status());
        String page = contentAsString(xss);
        assertTrue(page.contains("value=\"&lt;script&gt;bad&lt;/script&gt;\""));
        assertTrue(page.contains("name=\"quantity\" value=\"abc\""));
        assertFalse(page.contains("<script>bad</script>"));
        Result queryOnlyName = route(app, form("/content/form?name=fromQuery", "quantity=1&confirmation=1"));
        assertEquals(400, queryOnlyName.status());
        assertTrue(contentAsString(queryOnlyName).contains("name:error.required"));
        System.out.println("CONTENT10 binding-error raw=abc preserved; template escaped; POST query does not fill name");
    }

    @Test
    public void duplicateScalarsRejectBeforeOrdinaryBindingCollapsesThem() {
        String duplicate = "name=book&quantity=1&quantity=5&confirmation=1";
        Result strict = route(app, form("/content/form", duplicate));
        assertEquals(400, strict.status());
        assertTrue(contentAsString(strict).contains("DUPLICATE_FIELD"));
        assertTrue(contentAsString(strict).contains("data-field=\"quantity\">5</li>"));
        JsonNode ordinary = Json.parse(contentAsString(route(app, form("/content/form/ordinary", duplicate))));
        assertEquals("1", ordinary.get("data").get("quantity").asText());
        assertFalse(ordinary.get("hasErrors").asBoolean());
        assertEquals(1, app.injector().instanceOf(StockService.class).remaining());
        Result unknown = route(app, form("/content/form", "name=book&quantity=1&confirmation=1&admin=true"));
        assertEquals(400, unknown.status());
        assertTrue(contentAsString(unknown).contains("UNKNOWN_FIELD"));
        System.out.println("CONTENT10 duplicate strict=400 ordinary=" + ordinary + " stock=1");
    }

    @Test
    public void twoValidRequestsCompeteForOneInMemoryUnit() throws Exception {
        StockService stock = app.injector().instanceOf(StockService.class);
        stock.reset();
        String body = "name=book&quantity=1&confirmation=1";
        assertFalse(app.injector().instanceOf(FormFactory.class).form(ReservationForm.class)
                .bindFromRequest(fakeRequest(POST, "/content/form").bodyForm(java.util.Map.of(
                        "name", "book", "quantity", "1", "confirmation", "1")).build()).hasErrors());
        CountDownLatch ready = new CountDownLatch(2);
        CountDownLatch start = new CountDownLatch(1);
        try (var pool = Executors.newFixedThreadPool(2)) {
            List<Future<Integer>> requests = new ArrayList<>();
            for (int index = 0; index < 2; index++) {
                requests.add(pool.submit(() -> {
                    ready.countDown();
                    assertTrue(start.await(5, TimeUnit.SECONDS));
                    return route(app, form("/content/form", body)).status();
                }));
            }
            assertTrue(ready.await(5, TimeUnit.SECONDS));
            start.countDown();
            List<Integer> statuses = new ArrayList<>();
            for (Future<Integer> request : requests) statuses.add(request.get(5, TimeUnit.SECONDS));
            statuses.sort(Integer::compareTo);
            assertEquals(List.of(201, 409), statuses);
            assertEquals(0, stock.remaining());
            System.out.println("CONTENT10 barrier ready=2 statuses=" + statuses + " remaining=" + stock.remaining());
        } finally {
            start.countDown();
        }
    }

    @Test
    public void browserFormCarriesCsrfAndPreservesFailureInput() {
        Result page = route(app, fakeRequest(GET, "/content/form").header("Accept", "text/html"));
        assertEquals(200, page.status());
        Matcher action = Pattern.compile("<form method=\"post\" action=\"([^\"]+)\"").matcher(contentAsString(page));
        assertTrue(action.find());
        assertTrue(action.group(1).contains("csrfToken="));
        java.util.Map<String, String> session = page.session().data();
        assertTrue(session.containsKey("csrfToken"));
        Result failure = route(app, fakeRequest(POST, action.group(1)).session(session).header("Cookie", "lab=1")
                .bodyText("name=book&quantity=oops&confirmation=1")
                .header("Content-Type", "application/x-www-form-urlencoded"));
        assertEquals(400, failure.status());
        assertTrue(contentAsString(failure).contains("FORM_INVALID"));
        assertTrue(contentAsString(failure).contains("value=\"oops\""));
        Result rejected = route(app, fakeRequest(POST, "/content/form").session(session).header("Cookie", "lab=1")
                .bodyText("name=book&quantity=1&confirmation=1")
                .header("Content-Type", "application/x-www-form-urlencoded"));
        assertEquals(403, rejected.status());
        System.out.println("CONTENT10 browser form valid CSRF reaches validation400; missing CSRF403; raw oops preserved");
    }

    @Test
    public void twirlEscapesStringsAndAssetsRouteIsPresent() {
        Result escaped = route(app, fakeRequest(GET, "/content/twirl"));
        Result raw = route(app, fakeRequest(GET, "/content/twirl?raw=true"));
        assertEquals(200, escaped.status());
        assertEquals(200, raw.status());
        String safe = contentAsString(escaped);
        String trusted = contentAsString(raw);
        assertTrue(safe.contains("&lt;img"));
        assertFalse(safe.contains("<img id=\"twirl-payload\""));
        assertTrue(trusted.contains("<img id=\"twirl-payload\""));
        assertTrue(trusted.contains("<script>window.recordTwirlProbe('script')</script>"));
        assertTrue(safe.contains("href=\"/assets/lab.css\""));
        Result asset = route(app, fakeRequest(GET, "/assets/lab.css"));
        assertEquals(200, asset.status());
        assertTrue(contentAsString(asset, mat).contains("#rendered"));
        assertEquals(404, route(app, fakeRequest(GET, "/assets/missing.css")).status());
        System.out.println("CONTENT11 String escaped; Html literal; un-fingerprinted URL=/assets/lab.css; asset200 missing404");
    }
}
