import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import labperf.PerformanceLab;
import org.junit.Assume;
import org.junit.Test;
import play.Application;
import play.inject.guice.GuiceApplicationBuilder;
import play.test.WithApplication;

public class PerformanceTest extends WithApplication {
    @Override protected Application provideApplication() {
        return new GuiceApplicationBuilder()
                .configure("pekko.actor.default-dispatcher.fork-join-executor.parallelism-min", 2)
                .configure("pekko.actor.default-dispatcher.fork-join-executor.parallelism-max", 2).build();
    }
    @Test public void finiteStreamAndAggregateYieldExactlyTheSameBytes() throws Exception {
        var payload = app.injector().instanceOf(labperf.PayloadLab.class);
        payload.begin("aggregate_unit", "aggregate", 1); byte[] aggregate = payload.aggregate("aggregate_unit", 0);
        payload.begin("stream_unit", "stream", 1);
        byte[] stream = payload.stream("stream_unit", 0).runFold(org.apache.pekko.util.ByteString.emptyByteString(), (all, part) -> all.concat(part), app.injector().instanceOf(org.apache.pekko.stream.Materializer.class)).toCompletableFuture().get(5, TimeUnit.SECONDS).toArray();
        assertEquals(262144, stream.length); assertArrayEquals(aggregate, stream);
    }
    @Test public void cachePreservesTenantKeyAndAvoidsRepeatedRealQueries() throws Exception {
        Assume.assumeTrue("DB fixture is opt-in", "true".equals(System.getenv("PLAY_LAB_DB_ENABLED")));
        var payload = app.injector().instanceOf(labperf.PayloadLab.class);
        for (String mode : new String[]{"uncached", "cold", "hot"}) {
            String run = mode + System.nanoTime(); payload.begin(run, mode, 8);
            if (mode.equals("hot")) for (int key = 0; key < 4; key++) payload.warm(run, key).toCompletableFuture().get(5, TimeUnit.SECONDS);
            int before = payload.snapshot().path("postgresQueries").asInt();
            for (int id = 0; id < 8; id++) assertEquals("tenant" + ((id % 4) / 2) + ":item" + (id % 2) + ":value", payload.value(run, id).toCompletableFuture().get(5, TimeUnit.SECONDS));
            assertEquals(mode.equals("uncached") ? 8 : mode.equals("cold") ? 4 : 0, payload.snapshot().path("postgresQueries").asInt() - before);
            System.out.println("PERFORMANCE CACHE UNIT " + payload.snapshot());
        }
    }
    @Test public void finiteRunsAccountForEveryTaskAndNewConnectionConfirmsCommit() throws Exception {
        Assume.assumeTrue("DB fixture is opt-in", "true".equals(System.getenv("PLAY_LAB_DB_ENABLED")));
        var lab = app.injector().instanceOf(PerformanceLab.class);
        assertEquals(2, lab.configuration().path("poolMaximum").asInt());
        for (String mode : new String[]{"default", "dedicated", "admission"}) {
            String run = mode + System.nanoTime(); lab.begin(run, mode, 20);
            var responses = new ArrayList<java.util.concurrent.CompletableFuture<com.fasterxml.jackson.databind.node.ObjectNode>>();
            for (int i = 0; i < 20; i++) responses.add(lab.submit(run, i).toCompletableFuture());
            for (var response : responses) assertTrue(java.util.Set.of(200, 503, 504).contains(response.get(10, TimeUnit.SECONDS).path("status").asInt()));
            long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(10);
            while (lab.snapshot().path("pending").asInt() > 0 && System.nanoTime() < deadline) Thread.sleep(10);
            var state = lab.snapshot(); assertEquals(0, state.path("pending").asInt()); assertEquals(0, state.path("poolActive").asInt());
            int committed = 0, rejected = 0;
            for (var task : state.path("tasks")) {
                assertTrue(task.path("done").asBoolean()); String outcome = task.path("events").path("outcome").asText();
                if (outcome.equals("committed")) committed++; else { assertEquals("rejected", outcome); rejected++; }
            }
            assertEquals(20, committed + rejected); assertEquals(committed, lab.committed().path("committedOnNewConnection").asInt());
            if (!mode.equals("admission")) assertEquals(20, committed);
            System.out.println("PERFORMANCE UNIT " + state);
        }
    }
}
