import static org.junit.Assert.*;
import static play.test.Helpers.*;

import com.fasterxml.jackson.databind.JsonNode;
import labasync.CompositionLab;
import labasync.ContextLab;
import labasync.ExecutorLab;
import org.junit.Test;
import org.slf4j.MDC;
import play.Application;
import play.inject.guice.GuiceApplicationBuilder;
import play.libs.Json;
import play.mvc.Result;
import play.test.WithApplication;

public class AsyncTest extends WithApplication {
    @Override protected Application provideApplication() { return new GuiceApplicationBuilder().build(); }

    private JsonNode report(String label, JsonNode value) {
        System.out.println("ASYNC " + label + " " + value);
        return value;
    }

    @Test public void futureWaitPreservesTheInterruptSignal() throws InterruptedException {
        java.util.concurrent.atomic.AtomicBoolean restored = new java.util.concurrent.atomic.AtomicBoolean();
        Thread waiter = Thread.ofPlatform().name("lab-interrupted-waiter").start(() -> {
            Thread.currentThread().interrupt();
            try {
                labasync.LabSupport.get(new java.util.concurrent.CompletableFuture<>());
            } catch (IllegalStateException error) {
                restored.set(error.getCause() instanceof InterruptedException
                        && Thread.currentThread().isInterrupted());
            }
        });
        waiter.join(5_000);
        assertFalse("interrupted waiter must terminate", waiter.isAlive());
        assertTrue("the original interrupt signal must survive wrapping", restored.get());
    }

    @Test public void interruptedCleanupTerminatesBothExecutors() throws Exception {
        var task = new java.util.concurrent.FutureTask<>(() -> {
            var first = labasync.LabSupport.single("lab-cleanup-first");
            var second = labasync.LabSupport.single("lab-cleanup-second");
            var entered = new java.util.concurrent.CountDownLatch(2);
            var release = new java.util.concurrent.CountDownLatch(1);
            var a = first.submit(() -> { entered.countDown(); labasync.LabSupport.await(release); });
            var b = second.submit(() -> { entered.countDown(); labasync.LabSupport.await(release); });
            try {
                labasync.LabSupport.await(entered);
                Thread.currentThread().interrupt();
            } finally {
                release.countDown();
                labasync.LabSupport.closeAll(first, second);
            }
            return Json.newObject().put("firstTerminated", first.isTerminated())
                    .put("secondTerminated", second.isTerminated()).put("bothTasksDone", a.isDone() && b.isDone())
                    .put("interruptRestored", Thread.currentThread().isInterrupted());
        });
        Thread coordinator = Thread.ofPlatform().name("lab-cleanup-coordinator").start(task);
        JsonNode out = report("interrupted-cleanup", task.get(10, java.util.concurrent.TimeUnit.SECONDS));
        coordinator.join(5000);
        assertFalse(coordinator.isAlive());
        for (String field : new String[] {"firstTerminated", "secondTerminated", "bothTasksDone", "interruptRestored"})
            assertTrue(field, out.path(field).asBoolean());
    }

    @Test public void compositionStartsOnlyTheIntendedOperations() {
        JsonNode out = report("composition", CompositionLab.composition());
        assertEquals(0, out.path("serialPriceCallsBeforeInventory").asInt());
        assertEquals(1, out.path("serialPriceCallsAfterInventory").asInt());
        assertEquals(2, out.path("parallelStartedBeforeRelease").asInt());
        assertFalse(out.path("parallelCompletedBeforeRelease").asBoolean());
        assertEquals("stock:price", out.path("serialResult").asText());
        assertEquals("stock:price", out.path("parallelResult").asText());
    }

    @Test public void completionDoesNotMoveWorkButExplicitExecutorDoes() {
        JsonNode out = report("execution", CompositionLab.execution());
        assertFalse(out.path("completedFutureInvocationReturnedBeforeRelease").asBoolean());
        assertTrue(out.path("supplyAsyncInvocationReturnedBeforeRelease").asBoolean());
        assertFalse(out.path("supplyAsyncStageDoneBeforeRelease").asBoolean());
        assertEquals("lab-caller", out.path("completedFutureWorkThread").asText());
        assertEquals("lab-worker", out.path("supplyAsyncWorkThread").asText());
        assertEquals("lab-caller", out.path("pendingThenApplyThread").asText());
        assertEquals(out.path("driverThread"), out.path("completedThenApplyThread"));
        assertEquals("lab-worker", out.path("explicitThenApplyAsyncThread").asText());
    }

    @Test public void normalSyncThrowAndFailedStageHaveUniformResults() {
        for (String mode : new String[]{"ok", "sync", "failed"}) {
            Result result = route(app, fakeRequest(GET, "/async/result?mode=" + mode));
            JsonNode body = report("result-" + mode, Json.parse(contentAsString(result)));
            assertEquals(mode.equals("ok") ? 200 : 500, result.status());
            assertEquals(mode.equals("ok") ? "OK" : "ASYNC_FAILURE", body.path("code").asText());
            if (!mode.equals("ok")) assertEquals(1, body.size());
        }
    }

    @Test public void customContextUsesNamedDispatcher() {
        JsonNode out = report("placement", app.injector().instanceOf(ExecutorLab.class).placement());
        assertTrue(out.path("default").path("thread").asText().contains("default-dispatcher"));
        assertTrue(out.path("dedicated").path("thread").asText().contains("lab-blocking-dispatcher"));
        assertEquals(1, out.path("default").path("inFlightBeforeRelease").asInt());
        assertEquals(1, out.path("dedicated").path("inFlightBeforeRelease").asInt());
    }

    @Test public void pekkoBoundedQueueFallsBackToCallerAndDrains() {
        JsonNode out = report("pekko", app.injector().instanceOf(ExecutorLab.class).pekko());
        assertEquals(2, out.path("activeBeforeFourth").asInt());
        assertEquals(1, out.path("pendingBeforeFourth").asInt());
        assertFalse(out.path("thirdStartedBeforeRelease").asBoolean());
        assertTrue(out.path("fourthCallerRuns").asBoolean());
        assertEquals(3, out.path("activeDuringFourth").asInt());
        assertEquals(4, out.path("completedAfterRelease").asInt());
        assertEquals(0, out.path("inFlightAfterRelease").asInt());
        assertTrue(out.path("actorSystemTerminated").asBoolean());
    }

    @Test public void finiteCpuCalculationHasSameChecksumOnBothDispatchers() {
        JsonNode out = report("cpu", app.injector().instanceOf(ExecutorLab.class).placement());
        JsonNode normal = out.path("cpuDefault"), dedicated = out.path("cpuDedicated");
        assertEquals(100_000, normal.path("inputSize").asInt());
        assertEquals(normal.path("inputSize"), dedicated.path("inputSize"));
        long n = normal.path("inputSize").asLong();
        long expected = n * (n + 1) * (2 * n + 1) / 6;
        assertEquals(expected, normal.path("checksum").asLong());
        assertEquals(expected, dedicated.path("checksum").asLong());
        assertTrue(normal.path("thread").asText().contains("default-dispatcher"));
        assertTrue(dedicated.path("thread").asText().contains("lab-blocking-dispatcher"));
    }

    @Test public void abortPolicyRejectsFourthWith503AndDrains() {
        Result result = route(app, fakeRequest(GET, "/async/abort"));
        JsonNode out = report("abort", Json.parse(contentAsString(result)));
        assertEquals(503, result.status());
        assertEquals(2, out.path("activeBeforeFourth").asInt());
        assertEquals(1, out.path("queueBeforeFourth").asInt());
        assertEquals(503, out.path("fourthStatus").asInt());
        assertEquals(3, out.path("completedAfterRelease").asInt());
        assertEquals(0, out.path("inFlightAfterRelease").asInt());
        assertEquals(0, out.path("queueAfterRelease").asInt());
        assertTrue(out.path("terminated").asBoolean());
    }

    @Test public void requestMdcAndLoaderSurviveInterleavingAndFailure() {
        java.util.Map<String, String> original = MDC.getCopyOfContextMap();
        try {
            MDC.setContextMap(java.util.Map.of("caller", "sentinel"));
            JsonNode out = report("context", ContextLab.run(fakeRequest().build()));
            assertEquals(java.util.Map.of("caller", "sentinel"), MDC.getCopyOfContextMap());
            assertEquals("ok", out.path("aliceResult").asText());
            assertEquals("failed", out.path("bobResult").asText());
            assertTrue(out.path("originalRequestUnchanged").asBoolean());
            assertTrue(out.path("callerMdcRestored").asBoolean());
            assertTrue(out.path("callerClassLoaderRestored").asBoolean());
            assertEquals(4, out.path("events").size());
            String[] users = {"alice", "bob", "bob", "alice"};
            for (int i = 0; i < users.length; i++) {
                JsonNode event = out.path("events").get(i);
                assertEquals(users[i], event.path("user").asText());
                assertEquals(event.path("user"), event.path("requestAttrUser"));
                assertEquals(event.path("user"), event.path("mdcUser"));
                assertEquals(event.path("requestId"), event.path("requestAttrId"));
                assertEquals(event.path("requestId"), event.path("mdcId"));
                assertEquals(i < 2 ? "lab-context-a" : "lab-context-b", event.path("thread").asText());
            }
            assertEquals(Json.parse("{\"worker\":\"a\"}"), out.path("workerAAfterReuse"));
            assertEquals(Json.parse("{\"worker\":\"b\"}"), out.path("workerBAfterReuse"));
            for (String key : new String[]{"classLoaderNormal", "classLoaderFailure"}) {
                JsonNode loader = out.path(key);
                assertTrue(loader.path("capturedLoaderSeen").asBoolean());
                assertFalse(loader.path("callerMdcCopied").asBoolean());
                assertTrue(loader.path("workerLoaderRestored").asBoolean());
                assertTrue(loader.path("workerMdcRestored").asBoolean());
                assertEquals("a", loader.path("workerSentinel").asText());
                assertEquals(key.equals("classLoaderNormal") ? "ok" : "failed", loader.path("outcome").asText());
            }
        } finally { if (original == null) MDC.clear(); else MDC.setContextMap(original); }
    }
}
