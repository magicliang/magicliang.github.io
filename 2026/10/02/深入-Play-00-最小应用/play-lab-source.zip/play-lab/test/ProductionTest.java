import static org.junit.Assert.*;
import static play.test.Helpers.*;
import org.junit.Test;
import play.Application;
import play.inject.guice.GuiceApplicationBuilder;
import play.mvc.Http;
public final class ProductionTest {
    @Test public void disabledResourceIsNotReadyButProcessIsAlive() {
        Application app = new GuiceApplicationBuilder().build();
        running(app, () -> {
            assertEquals(200, route(app, new Http.RequestBuilder().uri("/production/health")).status());
            assertEquals(503, route(app, new Http.RequestBuilder().uri("/production/ready")).status());
            assertEquals(503, route(app, new Http.RequestBuilder().uri("/production/work?id=denied&millis=0")).status());
        });
    }
}
