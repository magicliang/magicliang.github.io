import static org.junit.Assert.*;
import static play.test.Helpers.*;

import com.fasterxml.jackson.databind.JsonNode;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import lab.AuditAction;
import lab.AuthorizationAction;
import lab.CountingJsonParser;
import lab.TraceLog;
import org.apache.pekko.stream.Materializer;
import org.apache.pekko.stream.javadsl.Source;
import org.apache.pekko.util.ByteString;
import org.junit.Test;
import play.Application;
import play.inject.guice.GuiceApplicationBuilder;
import play.libs.F;
import play.libs.Json;
import play.mvc.Action;
import play.mvc.Http;
import play.mvc.Result;
import play.test.WithApplication;

public class PipelineTest extends WithApplication {
    @Override
    protected Application provideApplication() {
        return new GuiceApplicationBuilder().build();
    }

    private Http.RequestBuilder request(String id, String path, String body) {
        return fakeRequest(POST, path).header("X-Play-Lab", "synthetic")
                .header("X-Pipeline-Id", id).header("X-Lab-Token", "allow")
                .bodyText(body).header("Content-Type", "application/json");
    }

    private List<String> events(String id) {
        return app.injector().instanceOf(TraceLog.class).events(id).stream()
                .map(e -> e.substring(id.length() + 1)).toList();
    }

    private JsonNode stats(String id) {
        return Json.parse(contentAsString(route(app, fakeRequest(GET, "/pipeline/stats?id=" + id))));
    }

    private void assertOrder(String id, String... expected) {
        List<String> actual = events(id).stream()
                .filter(e -> !e.startsWith("parser-bytes-") && !e.startsWith("parser-stream-")).toList();
        assertEquals(List.of(expected), actual);
        System.out.println("PIPELINE " + id + " " + stats(id));
    }

    @Test
    public void actionsComposeAndRejectWithoutBusiness() {
        assertEquals(200, route(app, request("normal", "/pipeline/json", "{}")).status());
        assertOrder("normal", "header-enter", "gate-enter", "parser-apply", "parser-result-200",
                "audit-enter", "auth-enter", "business", "auth-exit", "audit-exit",
                "gate-exit-200", "header-exit-200");
        int before = stats("denied").get("businessCalls").asInt();
        assertEquals(401, route(app, request("denied", "/pipeline/json", "{}")
                .header("X-Lab-Token", "deny")).status());
        assertEquals(before, stats("denied").get("businessCalls").asInt());
        assertOrder("denied", "header-enter", "gate-enter", "parser-apply", "parser-result-200",
                "audit-enter", "auth-enter", "auth-reject", "auth-exit", "audit-exit",
                "gate-exit-401", "header-exit-401");
        assertEquals(400, route(app, request("denied-malformed", "/pipeline/json", "{")
                .header("X-Lab-Token", "deny")).status());
        assertEquals(before, stats("denied-malformed").get("businessCalls").asInt());
        assertOrder("denied-malformed", "header-enter", "gate-enter", "parser-apply", "parser-result-400",
                "gate-exit-400", "header-exit-400");
    }

    @Test
    public void synchronousAndAsynchronousDelegateFailuresExitBothActions() {
        for (boolean synchronous : List.of(true, false)) {
            String id = synchronous ? "direct-sync" : "direct-async";
            AuditAction audit = app.injector().instanceOf(AuditAction.class);
            AuthorizationAction auth = app.injector().instanceOf(AuthorizationAction.class);
            audit.delegate = auth;
            auth.delegate = new Action.Simple() {
                @Override
                public java.util.concurrent.CompletionStage<Result> call(Http.Request request) {
                    if (synchronous) throw new IllegalStateException("injected");
                    return CompletableFuture.failedFuture(new IllegalStateException("injected"));
                }
            };
            try {
                audit.call(request(id, "/pipeline/json", "{}").build()).toCompletableFuture().join();
                fail("Expected injected failure");
            } catch (RuntimeException expected) {
                assertTrue(expected.toString().contains("injected"));
            }
            String failure = synchronous ? "sync-failed" : "failed";
            assertEquals(List.of("audit-enter", "auth-enter", "auth-" + failure, "auth-exit",
                    "audit-" + failure, "audit-exit"), events(id));
            System.out.println("PIPELINE " + id + " " + events(id));
        }
    }

    @Test
    public void filtersCoverUnknownRoutesAndShortCircuitParsing() {
        Result unknown = route(app, fakeRequest(GET, "/unknown-pipeline")
                .header("X-Pipeline-Id", "unknown"));
        assertEquals(404, unknown.status());
        assertEquals("applied", unknown.header("X-Pipeline-Security").orElseThrow());
        assertOrder("unknown", "header-enter", "gate-enter", "gate-exit-404", "header-exit-404");
        Result blocked = route(app, request("blocked", "/pipeline/json", "{")
                .header("X-Pipeline-Block", "yes"));
        assertEquals(403, blocked.status());
        assertEquals("applied", blocked.header("X-Pipeline-Security").orElseThrow());
        assertOrder("blocked", "header-enter", "gate-enter", "gate-reject", "gate-exit-403", "header-exit-403");
        assertEquals(0, stats("blocked").get("parserCalls").asInt());
        assertEquals(0, stats("blocked").get("requestBusinessCalls").asInt());
        assertEquals(403, route(app, fakeRequest(GET, "/unknown-pipeline")
                .header("X-Pipeline-Id", "blocked-unknown").header("X-Pipeline-Block", "yes")).status());
    }

    @Test
    public void parsingErrorsAndUtf8ByteBoundary() {
        String[] bodies = {"{", "{}", "\"" + "中".repeat(10) + "\"", "\"" + "中".repeat(11) + "\""};
        int[] statuses = {400, 415, 200, 413};
        for (int index = 0; index < bodies.length; index++) {
            String id = "matrix-" + index;
            Result result = route(app, request(id, "/pipeline/json", bodies[index])
                    .header("Content-Type", index == 1 ? "text/plain" : "application/json"));
            assertEquals(statuses[index], result.status());
            assertEquals(index == 2 ? 1 : 0, stats(id).get("requestBusinessCalls").asInt());
            assertEquals("applied", result.header("X-Pipeline-Security").orElseThrow());
            System.out.println("PIPELINE bytes=" + bodies[index].getBytes(StandardCharsets.UTF_8).length
                    + " status=" + result.status() + " " + stats(id));
        }
        assertEquals(32, bodies[2].getBytes(StandardCharsets.UTF_8).length);
        assertEquals(35, bodies[3].getBytes(StandardCharsets.UTF_8).length);
        Result text = route(app, request("text", "/pipeline/text", "你好")
                .header("Content-Type", "text/plain; charset=utf-8"));
        assertEquals(200, text.status());
        assertEquals("你好", Json.parse(contentAsString(text)).get("body").asText());
        assertEquals(415, route(app, request("text-wrong", "/pipeline/text", "{}")).status());
        Result empty = route(app, fakeRequest(POST, "/pipeline/any").header("X-Play-Lab", "synthetic")
                .header("X-Pipeline-Id", "empty"));
        assertEquals(200, empty.status());
        assertEquals("empty", Json.parse(contentAsString(empty)).get("kind").asText());
        System.out.println("PIPELINE text=200 wrong-text-type=415 empty=" + contentAsString(empty));
    }

    @Test
    public void parserStreamFailureAndChunkedLimit() throws Exception {
        CountingJsonParser parser = app.injector().instanceOf(CountingJsonParser.class);
        Materializer materializer = app.injector().instanceOf(Materializer.class);
        Http.RequestHeader header = request("chunks", "/pipeline/json", "").build();
        F.Either<Result, JsonNode> result = parser.apply(header).run(Source.from(List.of(
                ByteString.fromString("\"" + "中".repeat(5)),
                ByteString.fromString("中".repeat(6) + "\""))), materializer)
                .toCompletableFuture().get(5, TimeUnit.SECONDS);
        assertEquals(413, result.left.orElseThrow().status());
        assertEquals(35, stats("chunks").get("parserBytes").asInt());
        try {
            parser.apply(request("disconnect", "/pipeline/json", "").build())
                    .run(Source.<ByteString>failed(new IllegalStateException("client-disconnected")), materializer)
                    .toCompletableFuture().get(5, TimeUnit.SECONDS);
            fail("Expected source failure");
        } catch (java.util.concurrent.ExecutionException expected) {
            assertTrue(expected.getCause().toString().contains("client-disconnected"));
        }
        assertTrue(events("disconnect").contains("parser-stream-failed"));
        System.out.println("PIPELINE chunk-limit=" + stats("chunks") + " disconnect=" + stats("disconnect"));
    }
}
