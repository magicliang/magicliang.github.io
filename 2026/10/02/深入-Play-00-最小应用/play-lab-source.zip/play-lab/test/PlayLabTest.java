import static org.junit.Assert.*;
import static play.inject.Bindings.bind;
import static play.test.Helpers.*;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import controllers.LabController;
import java.util.List;
import javax.inject.Inject;
import lab.TraceLog;
import org.junit.Test;
import play.Application;
import play.inject.guice.GuiceApplicationBuilder;
import play.libs.typedmap.TypedKey;
import play.mvc.Http;
import play.mvc.Result;
import play.test.WithApplication;
import services.InventoryService;

public class PlayLabTest extends WithApplication {
    @Override
    protected Application provideApplication() {
        return new GuiceApplicationBuilder().build();
    }

    private Http.RequestBuilder request(String method, String path) {
        return fakeRequest(method, path).header("X-Play-Lab", "synthetic");
    }

    @Test
    public void healthAndTypedBinding() {
        Result health = route(app, request(GET, "/health"));
        assertEquals(200, health.status());
        assertEquals("play-lab-ok", contentAsString(health));
        assertEquals(200, route(app, request(GET, "/orders/42?verbose=true")).status());
        assertEquals(400, route(app, request(GET, "/orders/not-a-long")).status());
        assertEquals(400, route(app, request(GET, "/orders/42?verbose=wrong")).status());
        assertEquals(404, route(app, request(GET, "/missing")).status());
        assertEquals(404, route(app, request(POST, "/health")).status());
        System.out.println("LAB03: valid=200 path-binding=400 query-binding=400 unknown=404 method=404");
    }

    @Test
    public void reverseRouteRoundTrip() {
        String url = contentAsString(route(app, request(GET, "/reverse?id=42")));
        assertEquals("/orders/42", url);
        assertEquals(200, route(app, request(GET, url)).status());
        System.out.println("LAB03: reverse=" + url);
    }

    @Test
    public void parserShortCircuitsControllerAndRetainsFilter() {
        TraceLog trace = app.injector().instanceOf(TraceLog.class);
        trace.clear();
        Result good = route(app, request(POST, "/orders").header("X-Lab-Id", "good")
                .bodyText("{\"id\":42}").header("Content-Type", "application/json"));
        assertEquals(201, good.status());
        assertEquals(List.of("good:filter-enter", "good:controller", "good:result-available-201"), trace.events("good"));
        Result bad = route(app, request(POST, "/orders").header("X-Lab-Id", "bad")
                .bodyText("{").header("Content-Type", "application/json"));
        assertEquals(400, bad.status());
        assertEquals(List.of("bad:filter-enter", "bad:result-available-400"), trace.events("bad"));
        Result wrongType = route(app, request(POST, "/orders").header("Content-Type", "text/plain").bodyText("{}"));
        assertEquals(415, wrongType.status());
        Result big = route(app, request(POST, "/orders")
                .bodyText("{\"value\":\"" + "x".repeat(2048) + "\"}").header("Content-Type", "application/json"));
        assertEquals(413, big.status());
        System.out.println("LAB02: " + trace.events("good") + " / " + trace.events("bad") + "; type=415 size=413");
    }

    @Test
    public void requestAndResultUpdatesReturnNewObjects() {
        TypedKey<String> key = TypedKey.create("lab-key");
        Http.Request original = request(GET, "/health").build();
        Http.Request updated = original.addAttr(key, "v");
        assertFalse(original.attrs().containsKey(key));
        assertEquals("v", updated.attrs().get(key));
        Result first = play.mvc.Results.ok("hello");
        Result second = first.withHeader("X-Lab", "v");
        assertFalse(first.header("X-Lab").isPresent());
        assertEquals("v", second.header("X-Lab").orElseThrow());
        System.out.println("LAB04: request attr and result header updates preserve originals");
    }

    @Test
    public void responseShapesAndTemplateEscaping() {
        assertEquals(204, route(app, request(GET, "/shape/empty")).status());
        assertEquals(422, route(app, request(GET, "/shape/other")).status());
        String template = contentAsString(route(app, request(GET, "/template?name=%3Cscript%3Ex%3C%2Fscript%3E")));
        assertTrue(template.contains("&lt;script&gt;x&lt;/script&gt;"));
        assertFalse(template.contains("<script>"));
        System.out.println("LAB01/04: Twirl string escaped; empty=204 unknown-shape=422");
    }

    @Test
    public void injectorScopeAndOverrides() {
        assertNotSame(app.injector().instanceOf(LabController.class), app.injector().instanceOf(LabController.class));
        assertSame(app.injector().instanceOf(InventoryService.class), app.injector().instanceOf(InventoryService.class));
        InventoryService fake = product -> 99;
        Application replacement = new GuiceApplicationBuilder().configure("lab.stock", 11)
                .overrides(bind(InventoryService.class).toInstance(fake)).build();
        try {
            assertSame(fake, replacement.injector().instanceOf(InventoryService.class));
            assertEquals(11, replacement.injector().instanceOf(Config.class).getInt("lab.stock"));
            assertTrue(contentAsString(route(replacement, request(GET, "/orders/42"))).contains("99"));
        } finally {
            stop(replacement);
        }
        System.out.println("LAB05: direct controllers unscoped; inventory singleton; override=99 config=11");
    }

    @Test
    public void invalidConfigurationMissingBindingAndCycleFail() {
        assertDependencyFailure(new GuiceApplicationBuilder()
                .loadConfig(ConfigFactory.load().withoutPath("lab.stock")), LabController.class,
                "No configuration setting found");
        assertDependencyFailure(new GuiceApplicationBuilder().configure("lab.stock", -1), LabController.class,
                "non-negative");
        assertDependencyFailure(new GuiceApplicationBuilder().disable(Module.class), LabController.class,
                "InventoryService");
        assertDependencyFailure(new GuiceApplicationBuilder(), CycleA.class,
                "circular");
        System.out.println("LAB05: missing/invalid config, missing interface binding, circular dependency rejected");
    }

    private void assertDependencyFailure(GuiceApplicationBuilder builder, Class<?> type, String message) {
        Application candidate = null;
        try {
            candidate = builder.build();
            candidate.injector().instanceOf(type);
            fail("Expected dependency failure: " + message);
        } catch (RuntimeException failure) {
            String detail = failure.toString().toLowerCase();
            assertTrue(detail, detail.contains(message.toLowerCase()));
            System.out.println("LAB05-EXPECTED: " + message + " -> " + failure);
        } finally {
            if (candidate != null) stop(candidate);
        }
    }

    public static final class CycleA {
        @Inject public CycleA(CycleB other) { }
    }

    public static final class CycleB {
        @Inject public CycleB(CycleA other) { }
    }
}
