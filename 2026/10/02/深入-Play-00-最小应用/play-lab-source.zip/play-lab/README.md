# Play 00–11 累计实验

这是固定在 Play 3.0.6 的本机合成数据实验；不存在真实订单、数据库或业务下游。默认 HTTP 服务器为 Pekko HTTP。正文与源码从同一工程出发，后续批次继续在此增量修改。

## 重跑

需要 JDK 21、Python 3 和可访问 Maven Central 的网络。首次依赖解析写入用户的 sbt/Coursier 缓存。所有命令从此目录执行：

```bash
export JAVA_HOME=/path/to/jdk-21
mkdir -p .tools
curl -fL https://repo.maven.apache.org/maven2/org/scala-sbt/sbt-launch/1.10.7/sbt-launch-1.10.7.jar -o .tools/sbt-launch-1.10.7.jar
shasum -a 256 .tools/sbt-launch-1.10.7.jar
bash sbtw test stage
python3 lab/verify.py --dev
python3 lab/verify.py
python3 lab/verify.py --negative
python3 lab/pipeline_checks.py --dev
python3 lab/pipeline_checks.py
python3 lab/content_checks.py --dev
python3 lab/content_checks.py
```

launcher SHA-256：`3cca02818047327a83efde776103a1ef92f76f72c062badbbb062499a3270c07`。也可用 `PLAY_LAB_SBT_LAUNCHER` 指向已有 launcher。sbt 版本由 `project/build.properties` 固定，插件/Scala/测试依赖由构建定义固定；不要求安装全局 sbt。

## 断言与证据

`sbt test` 累计运行19项 JUnit 测试：原有12项覆盖请求、DI和Action/Filter/parser；新增7项覆盖JSON字段/金额、Form多值与约束、单JVM CAS竞争、Twirl转义、资源和真实CSRF路径。

`verify.py --dev` 启动 `sbt run`；不带参数启动 `target/universal/stage/bin/play-lab`。二者在空闲回环端口运行同一请求矩阵，并写入 `evidence/batch00-05/`。每次生成临时签名密钥，通过显式 HOCON 环境替换加载，不保存密钥。Cookie 是合成实验样本。

矩阵核验真实状态/正文/头、HEAD fallback、重复和编码 query/path、session 可读与签名篡改拒绝、flash 删除及旧 Cookie 重放、流头到正文结束的不同时间，以及 16 个并发 scope 请求。`/trace` 和无界内存队列仅用于有限实验；不是生产审计接口。CSRF header bypass 也仅供本机合成请求。

脚本 finally 向它启动的进程发送 SIGTERM，等待最多 15 秒，超时才 kill；正常观测退出码为 143。负例使用临时副本，只改 routes 参数类型、Twirl 参数类型或消费者的 dependsOn，要求编译非零退出且有编译错误，临时目录自动清理。不会修改原工程。

`pipeline_checks.py` 复用原有56请求回归，新增31组请求/计数查询，开发与生产各118请求通过，写入 `evidence/batch06-08/`。deferred采用routes的 `+ deferBodyParsing`；缺少allow头返回401，允许后才解析。显式JSON上限32bytes，默认Text配置1k；UTF-8按编码后字节检查。显式Text无charset或非法UTF8会返回替换字符，不保证严格编码拒绝。X-Pipeline-Id与X-Lab-Token只是合成实验头，不构成生产认证。计数仅反映进入parser的chunk，不能证明服务器零读入。

记录的耗时是单次本机功能验证，不是性能基准。deferred拒绝与parser失败Source已运行；真实TCP断连资源清理、自定义 handler/provider、数据库资源释放和生产容量均 NOT_RUN。HTTP 观测不替代上游全套测试。

`content_checks.py` 复用此前回归，DEV/PROD各185真实HTTP请求通过，其中37组内容检查。JSON金额为受限十进制字符串，重复JSON键当前折叠为末值；严格Form先拒绝重复标量，再绑定和验证，普通Form只观察首值。库存CAS只证明单JVM原子操作。UTF-16表单长度与JSON码点长度分别验收。

本批原始证据位于 `evidence/batch09-11/`。真实内置浏览器以Cookie与页面CSRF action提交无效表单，保存原输入；Twirl String路径事件none，Html路径script,img，两条路径截图独立于HTTP证据。临时模板payload类型改Int后compile退出1，失败位于Html(payload)，见twirl-negative.log。资源jar CSS与源字节一致、没有.md5；DEV no-cache，PROD max-age=3600和条件请求304。没有将versioned方法名当作摘要产物证明。

## 打包源码

```bash
python3 lab/package.py
```

该命令从博客源码目录生成第 00 篇的 `play-lab-source.zip` 与 SHA-256 文件，排除下载的 launcher、目标产物、用户缓存及全站 Hexo 生成日志。下载包解压后从 `play-lab/` 执行实验命令即可，无需再次打包。证据保留环境与原始观测，重新运行会覆盖本地 evidence 文件。
