package services;

/** The inventory boundary used by the route and dependency-injection experiments. */
public interface InventoryService {
    /**
     * Returns synthetic stock; this lab does not access a database.
     * @param productId the synthetic product identifier
     * @return the configured stock count
     */
    int stock(long productId);
}
