import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.function.Supplier;

// JDK 21 example; record requires Java 16, failedFuture requires Java 9.
public final class CommitThenNotify {
    record Receipt(String orderId, String notification) {}

    static CompletionStage<Receipt> submit(
            Supplier<String> synchronousTransaction,
            Function<String, CompletionStage<String>> notification,
            Executor executor) {
        return CompletableFuture.supplyAsync(synchronousTransaction, executor)
            .thenCompose(orderId -> {
                CompletionStage<String> attempt;
                try {
                    attempt = notification.apply(orderId);
                } catch (RuntimeException failure) {
                    attempt = CompletableFuture.failedFuture(failure);
                }
                return attempt.handle((status, failure) -> new Receipt(
                    orderId, failure == null ? status : "BUDGET_FAILED"));
            });
    }

    public static void main(String[] args) throws Exception {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        AtomicInteger notifications = new AtomicInteger();
        try {
            Receipt receipt = submit(() -> "committed-order", orderId -> {
                notifications.incrementAndGet();
                return CompletableFuture.failedFuture(
                    new java.util.concurrent.TimeoutException("synthetic budget"));
            }, executor).toCompletableFuture().get(2, TimeUnit.SECONDS);
            if (!receipt.equals(new Receipt("committed-order", "BUDGET_FAILED"))) {
                throw new AssertionError(receipt);
            }
            try {
                submit(() -> { throw new IllegalStateException("transaction failed"); },
                    orderId -> {
                        notifications.incrementAndGet();
                        return CompletableFuture.completedFuture("unexpected");
                    }, executor).toCompletableFuture().get(2, TimeUnit.SECONDS);
                throw new AssertionError("failure expected");
            } catch (java.util.concurrent.ExecutionException expected) {
                if (!(expected.getCause() instanceof IllegalStateException)) throw expected;
            }
            if (notifications.get() != 1) throw new AssertionError(notifications);
            System.out.println("PASS committed identity retained; failed transaction skipped notification");
        } finally {
            executor.shutdownNow();
            if (!executor.awaitTermination(2, TimeUnit.SECONDS)) {
                throw new AssertionError("executor did not terminate");
            }
        }
    }
}
