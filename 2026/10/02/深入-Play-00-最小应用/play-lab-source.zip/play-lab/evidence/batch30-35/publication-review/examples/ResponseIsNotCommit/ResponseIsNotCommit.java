import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public final class ResponseIsNotCommit {
    public static void main(String[] args) throws Exception {
        var response = new CompletableFuture<Integer>();
        var committed = new AtomicInteger();
        var release = new CountDownLatch(1);
        var worker = Executors.newSingleThreadExecutor();
        try {
            var task = worker.submit(() -> {
                try {
                    release.await();
                    committed.incrementAndGet();
                    response.complete(200);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException(e);
                }
            });
            if (!response.complete(504)) throw new AssertionError();
            if (response.join() != 504 || committed.get() != 0) {
                throw new AssertionError();
            }
            release.countDown();
            task.get(2, TimeUnit.SECONDS);
            if (response.join() != 504 || committed.get() != 1) {
                throw new AssertionError();
            }
            System.out.println("response=504 committed=1");
        } finally {
            release.countDown();
            worker.shutdownNow();
            if (!worker.awaitTermination(2, TimeUnit.SECONDS)) {
                throw new AssertionError("worker not terminated");
            }
        }
    }
}
