# Play 30–35 / E01–E08 出版审阅

审阅范围仅为原计划中的 14 篇文章及其示例、实验记录。未修改文章、应用源码、Git、状态或浏览器。此收据记录阅读、源码追踪和定向验证；不是重新执行全部实验的报告。

## 已修复问题历史

**R1 / E06 / 证据解析：空 Parent ID 跨行读取。** `examples/play-electives/e06-otel/otel_checks.py:43` 使用 `\s*` 匹配冒号后空白。Collector 输出空 Parent ID 时，匹配跨越换行，将下一行 `ID : <spanId>` 写入 parentId。从真实函数 AST 提取的最小输入已复现；公开 `isolated/run-final/spans.json` 有 22 条相同错误。收据为 `e06-parser-reproduction.json`。已交接 E06 接入负责人，建议限制为行内空白并增加根 span 回归断言，重新生成共享证据。

这不推翻正文引用的三条显式父子链：它们的 Parent ID 非空。审阅时复制 Collector 原始日志、spans 与 responses 到独立证据目录，重新执行当前 `analyze_collector.py`，三条链全部通过，见 `e06-lineage-recheck/recheck.log` 与 `scope-lineage.json`。

**R1 已修复并独立复审通过。** 修复后的 `collector_parser.py` 使用行内空白。审阅者重新运行 2 个 parser 回归测试，重新解析公共 integration 原始 Collector 日志，73 条结果与共享 spans.json 完全一致；逐条核对其中 23 个根 span 的原始 Parent ID 为空。三条显式父子链再次 PASS，共享 60 个 checks 均通过。详见 `e06-fixed-recheck/recheck.json`、`parser-tests.log` 和 `lineage.log`。旧错误证据保留用于说明缺陷，不代表当前状态。

## 逐篇覆盖

| 文章 | 对照原计划检查的内容 | 审阅结论与证据边界 |
| --- | --- | --- |
| 30 | stage/dist、独立生产进程、代理健康及流、SIGTERM 在途任务、强杀及回滚边界 | 公开 run-final-02 的 16 场景与正文吻合；未把 hook、响应和数据库提交混为一谈。 |
| 31 | 固定输入、负载、三轮吞吐及分位数、队列/分配/GC、超时后成本 | 重新统计 comparison.csv 为 48 cells、1440 测量请求，高并发 JDBC 三组状态和 p95 与正文吻合；文章限定闭环、有限样本及整个 JVM 的 GC。 |
| 32 | 2.8.22→2.9.6→3.0.6、routes/async/WS/流/stage、Scala 3 独立分支 | 正文与隔离 manifest 四个版本记录一致；旧 Play/JDK 21、旧配置静默失效和未测兼容性已说明。共享接入负责人已报告通过，本审阅不代替其完整复跑。 |
| 33 | 同一业务、事务、下游与错误语义，对照 MVC/WebFlux | 固定 Kernel、容量、池和热点行约束明确；超时后提交有独立观测；未将有限吞吐推广为框架排名。公开共享 summary 已记录 18 cells、396 请求、69 checks PASS。 |
| 34 | 线程饥饿、超时重复、取消后资源泄漏，诊断到回归 | 正文与 26 条运行断言范围一致；文件描述符、许可及终止回调分开，未把回调执行误当资源已关闭。公开共享 summary 已记录 6 cases、26 checks PASS。 |
| 35 | 创建/查询/取消/导出/订阅，身份/幂等/慢下游/停机 | 追踪 Controller、Repository、CSRF 配置和攻击矩阵；签名身份、tenant+subject SQL 权限、缺令牌/旧绕过头 403、提交后通知语义均有对应检查。 |
| E01 | 相同 Java/Scala HTTP 契约、类型请求、Future、独立 Scala 3 | 新稿已纳入；3 个完整文件在两个版本目录中共 6 次逐字节匹配（忽略末尾换行）；68 场景原始观测、4 JUnit 和编译失败负例支持正文。公开共享 run-final 与 negative 的 summary 均 PASS。 |
| E02 | 手动编译期 DI 对照、缺依赖、配置错误、测试替换、启动代价 | 手动 2 / Guice 1 JUnit、负例和 3 轮启动记录已检查；正文不声称少量启动样本证明稳定性能优势，GET 过滤器检查不冒充完整 CSRF 验证。 |
| E03 | 固定 ORM/plugin、增强、SQL、事务和异步边界 | 公开两次 HTTP 原始结果显示 Action 返回时 Stage 未完成、事务已退出；Ebean 晚写与 Hibernate 已关闭 EM 区分正确；正确整段事务在线程内执行。 |
| E04 | 两后端 parser、流、握手及停机差异 | 已完成公共工程实际编译及 36 场景接入验证；正文保留 Pekko Close 1002 与 Netty EOF、在途响应差异，不把工作回调完成当完整收包。 |
| E05 | Typed ask 超时、固定 mailbox、重启、停止、内存状态 | 记录明确 ask 超时后处理继续；容量 4、20 条投递的 processed/deadLetters 分开；supervision 重启状态归零及 stop 事件符合示例，未扩展集群或持久化结论。 |
| E06 | 固定 Agent/SDK、跨线程父子链、自动 WS、取消与真实接收端 | R1 修复后 parser、根 span、三条主链独立重验 PASS。队列丢弃探针与 Agent 实验分开，自动 scope 以 Collector 实收为据；共享 60 checks PASS。 |
| E07 | JDK 21、同连接池/SQL/负载、admission、资源与 pinning | 正文限定 JDK 21；monitor 与 ReentrantLock 正对照、JFR 阈值及 JDBC 无事件的局限明确；48 无 admission 虚拟任务的池等待不被写成吞吐优势。 |
| E08 | 语言优先级、Locale、Accept/q=0、缓存、转义和授权 | 真实框架 accepts existential 行为与自定义协商分开；精确 q=0 覆盖 wildcard、406、有限语法、Vary/私有缓存、tenant 身份及 Twirl String/Html 边界均已验证。 |

## 本次新执行的验证

从当前正文抽取 `NearestRank`、`ResponseIsNotCommit`、`OnceLease`、`CommitThenNotify`、`AdmissionExample` 和 `lab.Negotiator` 六个独立例子，使用 JDK 21 `javac --release 21` 编译并运行，退出码全部为 0。逐文件日志和正文 SHA 在 `standalone-examples.json` 与 `examples/`。E01 的六次源码匹配见 `e01-snippet-audit.json`；31 原始 CSV 重算见 `batch31-recalculation.json`。

## 限度

最终 14 篇正文的 SHA 与顺序写作审查见 `writing-final/01-anti-ai-tone.json` 和 `02-anti-persona-fabrication.json`。先执行 tech profile 辅助检查，14 篇各为 0 error / 0 warning，再人工检查三红线及十类拟人症状，确认无必须修改的句子。E08 的“无语言 cookie”含词表片段“无语”，人工判定为语言条件，不是作者情绪。最终浏览器检查作为单独工作等待整站生成，不影响本内容审阅的结论。

未在本审阅中重跑全部数据库、网络、停机、容量或所有平台矩阵；现存实验报告仅在检查过对应原始记录、源码和边界的范围内使用。E05/E07/E08 由本审阅者参与撰写，相关部分属于自检。有限本机记录不能支持跨平台、生产性能、未测取消语义或所有插件兼容性结论。最终站点与下载包由主负责人处理，未重复列为问题。
