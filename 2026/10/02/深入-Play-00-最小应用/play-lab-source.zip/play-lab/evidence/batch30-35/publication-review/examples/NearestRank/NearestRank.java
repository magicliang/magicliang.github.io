import java.util.Arrays;

public final class NearestRank {
    private NearestRank() {
    }

    public static long percentile(long[] samples, double fraction) {
        if (samples.length == 0 || !Double.isFinite(fraction)
                || fraction <= 0.0 || fraction > 1.0) {
            throw new IllegalArgumentException("nonempty samples and 0 < p <= 1 required");
        }
        long[] sorted = samples.clone();
        for (long sample : sorted) {
            if (sample < 0) {
                throw new IllegalArgumentException("negative duration");
            }
        }
        Arrays.sort(sorted);
        int index = (int) Math.ceil(fraction * sorted.length) - 1;
        return sorted[index];
    }

    public static void main(String[] args) {
        long[] samples = new long[40];
        for (int index = 0; index < samples.length; index++) {
            samples[index] = index + 1L;
        }
        long median = percentile(samples, 0.50);
        long p95 = percentile(samples, 0.95);
        long p99 = percentile(samples, 0.99);
        if (median != 20 || p95 != 38 || p99 != 40) {
            throw new AssertionError("nearest-rank mismatch");
        }
        System.out.printf("N=%d p50=%d p95=%d p99=%d%n",
                samples.length, median, p95, p99);
    }
}
