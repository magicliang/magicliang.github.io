# 第13篇有限CPU计算增量

计划6.2要求可控阻塞任务和CPU计算分别观察。本增量在两个执行器中分别计算1到100000的整数平方和，没有用latch模拟CPU，也没有记录耗时或进行性能排名。

隔离调用：

```bash
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn PLAY_LAB_SBT_LAUNCHER=/private/tmp/play-series-tools/sbt-launch-1.10.7.jar bash /private/tmp/play-async-work-20261002/sbtw 'testOnly AsyncTest'
```

2026-10-03 17:44:21结束，退出0，AsyncTest8项通过。新增场景finiteCpuCalculationHasSameChecksumOnBothDispatchers使用闭式公式n(n+1)(2n+1)/6独立验证循环结果。原始输出cpu-test.log，XML为cpu-TEST-AsyncTest.xml，结构化输出cpu-observations.json，准确源码哈希cpu-source-hashes.json。

GET /async/placement新增cpuDefault和cpuDedicated对象。两者inputSize=100000、checksum=333338333350000；thread分别包含default-dispatcher和lab-blocking-dispatcher。原default/dedicated对象仍是独立的可控阻塞位置实验。

仅ExecutorLab.java和AsyncTest.java同步到共享工程，两文件与隔离副本哈希一致。旧isolated-test-stage.log、XML、源码和stage哈希属于CPU增量之前的历史验收；本次没有重建共享或隔离stage。共享累计构建由主任务随后执行。真实JDBC与完整负载基准分别留待22和31，不由本计算替代。
