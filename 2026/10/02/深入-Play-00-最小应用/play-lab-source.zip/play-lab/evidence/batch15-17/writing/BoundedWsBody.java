import java.time.Duration;
import java.util.concurrent.CompletionStage;
import org.apache.pekko.stream.Materializer;
import org.apache.pekko.util.ByteString;
import play.libs.ws.WSClient;

public final class BoundedWsBody {
    public static CompletionStage<ByteString> fetch(
            WSClient client, Materializer materializer,
            String trustedUrl) {
        return client.url(trustedUrl)
            .setFollowRedirects(false)
            .setRequestTimeout(Duration.ofSeconds(3))
            .stream()
            .thenCompose(response -> response.getBodyAsSource()
                .limitWeighted(64, bytes -> (long) bytes.size())
                .completionTimeout(Duration.ofSeconds(3))
                .runFold(ByteString.emptyByteString(),
                    ByteString::concat, materializer));
    }
}
