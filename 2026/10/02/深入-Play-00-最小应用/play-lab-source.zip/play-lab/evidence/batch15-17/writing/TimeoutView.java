import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import play.libs.concurrent.Futures;

public final class TimeoutView {
    public static CompletionStage<String> observe(Futures futures) {
        CompletableFuture<String> original = new CompletableFuture<>();
        return futures.timeout(original, Duration.ofMillis(100))
            .handle((value, failure) -> {
                boolean done = original.isDone();
                boolean cancelled = original.isCancelled();
                original.complete("late-success");
                return "failed=" + (failure != null)
                    + ",done=" + done + ",cancelled=" + cancelled
                    + ",late=" + original.getNow("missing");
            });
    }
}
