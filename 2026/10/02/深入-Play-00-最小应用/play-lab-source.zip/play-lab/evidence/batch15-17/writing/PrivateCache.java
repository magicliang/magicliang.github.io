import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionStage;
import play.cache.AsyncCacheApi;

public final class PrivateCache {
    private static String part(String value) {
        return Base64.getUrlEncoder().withoutPadding()
            .encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    public static CompletionStage<String> load(
            AsyncCacheApi cache, String tenant, String subject,
            String item, Callable<CompletionStage<String>> loader) {
        String key = "private:v1:" + part(tenant) + ":"
            + part(subject) + ":" + part(item);
        return cache.getOrElseUpdate(key, loader, 10);
    }
}
