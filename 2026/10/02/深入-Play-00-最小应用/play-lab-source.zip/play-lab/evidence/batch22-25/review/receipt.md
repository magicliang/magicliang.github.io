# Play 22–25 independent read-only review

Verdict: **BLOCK — one actionable cleanup defect in the DB verification driver.** Review date: 2026-10-03. No application source, articles, configuration, Git, stage output or containers were changed. Only this receipt was written. No existing historical failure was treated as a final regression.

## P1: first process cleanup failure skips other processes and raw evidence

Location: `examples/play-lab/lab/database_checks.py:219–224`, with triggering stop implementation at `:81–90`.

The outer `finally` runs `item.stop()` sequentially without catching failures. A stop timeout sends kill and raises at line 89; a signal/wait exception can also escape. The first escaping exception prevents every remaining process from being stopped and skips all three JSON evidence writes. The timeout branch also skips `self.log.close()` at line 90. During a multi-server scenario, an earlier failure can therefore leave an independently owned stage process alive and lose the original scenario evidence. This is the same independent-resource cleanup boundary that article 25 correctly explains for Java executors.

Smallest repair: make each server stop and its log close independently attempted; in the outer finalizer attempt all server stops and all evidence writes, collect cleanup failures, and preserve the original scenario exception as the primary error (or use a structured exception group). Do not change database cases, fixture ownership or existing expected-negative outcomes. Add a bounded regression with two owned process stubs where the first stop fails, asserting the second stop and three writes still occur and the original failure remains visible. A real process stop timeout can be tested separately without touching the shared fixture.

Direct reproduction executed during this review: Python parsed the current file with `ast.parse`, selected the `main()` outer `try.finalbody`, compiled that exact AST and executed it with two no-process `Server` stubs and a no-filesystem evidence stub. The first `stop()` raises `AssertionError`; the second records its call. This does not start or stop any real process.

Actual command stdout:

```text
EXTRACTED_FINALLY_EXCEPTION synthetic stop deadline failure
EXTRACTED_FINALIZER_ACTIONS ['first']
CONFIRMED second stop and evidence writes skipped after first stop exception; no actual process started
```

The reproduction used this invocation body:

```python
import ast
from pathlib import Path
p = Path('examples/play-lab/lab/database_checks.py')
tree = ast.parse(p.read_text())
main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
block = next(n for n in main.body if isinstance(n, ast.Try))
module = ast.Module(body=block.finalbody, type_ignores=[])
calls = []
class Server:
    def __init__(self, name, fail): self.name, self.fail = name, fail
    def stop(self):
        calls.append(self.name)
        if self.fail: raise AssertionError('synthetic stop deadline failure')
class Evidence:
    def __truediv__(self, name): calls.append('write:' + name); return self
    def write_text(self, text): pass
try:
    exec(compile(module, str(p), 'exec'), {
        'processes': [Server('first', True), Server('second', False)],
        'evidence': Evidence(), 'json': __import__('json'),
        'records': [], 'sql_records': [], 'summary': {}})
except AssertionError as error:
    print('EXTRACTED_FINALLY_EXCEPTION', str(error))
print('EXTRACTED_FINALIZER_ACTIONS', calls)
assert calls == ['first']
```

## Verified final evidence and claim boundaries

The read-only verification command recomputed all entries in `examples/play-lab/evidence/batch22-25/final-source.json`, parsed every testcase in both shared XML directories, deduplicated by `(classname,name)` with any skipped notification marking the method skipped, parsed all HTTP/SQL observations, and hashed the actual staged application jar and nine named classes. Actual stdout:

```text
HASH_MATCH True 12
shared-junit raw 46 distinct 46 executed 46 skip 0 fail 0
shared-db-free-junit raw 53 distinct 46 executed 39 skip 7 fail 0
HTTP 37
SQL 20 all exit0 True
locks [{'preexistingLockTable': False, 'ready': [False, True], 'exits': [255, 143], 'metadata': '1|applied', 'rows': '1'}, {'preexistingLockTable': True, 'ready': [True, True], 'exits': [143, 143], 'metadata': '1|applied', 'rows': '1'}]
CURRENT_STAGE_APP_SHA_AND_NINE_CLASSES_MATCH examples/play-lab/target/universal/stage/lib/example.playlab.play-lab-0.1.0-sans-externalized.jar
```

The first exploratory jar glob also selected the assets-only jar and raised a missing-class KeyError; rerunning against the explicit `sans-externalized.jar` above passed. That review-command selection mistake is not an application failure.

| Reviewed claim | Source / evidence | Finding |
| --- | --- | --- |
| Transaction block returning pending Stage commits before asynchronous work completes | `app/labdb/TransactionLab.java:123–140`; fixed Play `Databases.scala:187–201`; `shared-http/summary.json` `transactions.scope` | Stage false, external observer sees committed row 1, delayed captured handle is closed; article 23 lines 23–45 matches. The null SQLSTATE is preserved, not invented. |
| Concurrent idempotency and tenant/payload scope | `TransactionLab.java:39–67,85–98`; driver `database_checks.py:136–142`; `shared-http/summary.json` `transactions` and `httpIdempotency` | Unique `(tenant,idempotency_key)`, same key CREATED/REPLAY, changed payload CONFLICT, independent tenant CREATED, remaining-stock conditional update and rollback are consistent. Article 23 explains fixed fixture SKU and synthetic payload at lines 69–73 and loopback-only mutating GET at line 148. |
| HTTP timeout is independent of persistent commit | `LateCommitLab.java:41–57,60–73`; driver `:143–149`; `shared-http/summary.json` `httpLateCommit` | Both HTTP504/taskDone=false observations, external counts 0 versus 1 before release, both final 1 and retryInserted0. Article 15 local backfill states these two separately from statement_timeout57014 and inventory rollback. |
| Pool versus executor queues and finite dispatcher comparison | `PoolLab.java:33–58,108–135`; driver `:114–128`; shared summary and SQL raw | Pool2/threads4 waiters2 queue0 versus pool2/threads2 waiters0 queue2, active0 after tasks. Default first health 1.582s versus dedicated0.012s is explicitly a finite sample, not throughput or a universal ratio; article13/22 preserve this boundary. |
| Evolutions rollback and migration locks | `EvolutionLab.java:36–54`; driver `:170–217`; `shared-http/sql-observations.json`; `lock-initial-a.log:5–6` | autocommit true leaves partial table/applying_up; false leaves no partial table or metadata rows. Production default refusal255/0table. First lock-table creation unique conflict is distinct from existing lock-row serialization; actual ready order [false,true] need not match the historical article table's [true,false]. The prose explicitly permits changing winner order. |
| Background stop/start, hook order, resources and two instances | `ManagedDatabaseJob.java:35,56–85,89–122`; `DatabaseLabTest.java:14–28,66–79`; shared XML; `shared-http/database-main.jsonl`; raw SQL | Direct Java stop/start test starts work first, then observes stopping and rejects later submissions. Real SIGTERM143 scenario separately confirms PgSleep before signal, commit, reverse hooks and file/pool/scheduler/worker terminal flags. Two process journals record inserted1/inserted0 and independent SQL one row. Article25 separates direct Java from HTTP and excludes SIGKILL/exactly-once. |

`writing-plans/play/validation-22-25.md:7–17` matches the independently recomputed final counts and actual SQL/process outcomes. `shared-test-stage.log` ends with successful stage generation; `shared-db-free-test.log` retains the runner's 53/46/7 raw report, correctly qualified in prose. The configuration delta keeps DB opt-in, adds actual pgJDBC42.7.5 with javaJdbc/evolutions, and the HTTP harness binds only 127.0.0.1. No additional blocker was found in the scoped source-to-evidence or prose attribution checks.

Review completion is not approval to commit until the P1 driver cleanup defect is repaired and its targeted regression evidence is captured. Existing successful real DB observations remain valid; the defect concerns failure-path ownership and evidence preservation.
