import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import play.inject.ApplicationLifecycle;

public final class LifecycleRegistration {
    private final List<String> events = new CopyOnWriteArrayList<>();

    public LifecycleRegistration(ApplicationLifecycle lifecycle) {
        lifecycle.addStopHook(() -> {
            events.add("cleanup");
            return CompletableFuture.completedFuture(null);
        });
        lifecycle.addStopHook(() -> {
            events.add("async-failure");
            return CompletableFuture.failedFuture(
                    new IllegalStateException("synthetic failed stage"));
        });
        lifecycle.addStopHook(() -> {
            events.add("sync-failure");
            throw new IllegalStateException("synthetic thrown hook");
        });
        lifecycle.addStopHook(() -> {
            events.add("drain");
            return CompletableFuture.completedFuture(null);
        });
    }

    public List<String> snapshot() {
        return List.copyOf(events);
    }
}
