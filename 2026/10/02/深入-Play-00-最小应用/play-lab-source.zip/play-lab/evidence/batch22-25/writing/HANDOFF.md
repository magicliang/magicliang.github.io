# Play 22–25 writing handoff

Owned deliverables are the four `source/_posts/2026-10-03-深入-Play-{22,23,24,25}-*.md` articles, their four `cover.svg` files, and this writing evidence directory. No lab source, configuration, plan, shared stage, Git operation or container lifecycle was changed in this writing slice.

## Acceptance and exact evidence

| Scenario | Invocation / observable | Captured artifact |
|---|---|---|
| Ordered prose checks before publication | `python3 check_writing.py ai --ai-script <installed anti-ai-tone checker>`; four tech-profile results have errors=0, warnings=0 | `anti-ai-tone-02.log` includes draft SHA-256 and raw checker output |
| Second prose scan | `python3 check_writing.py persona`; first scan PASS required before running, four prose hit lists empty; full draft manual support/progression/persona review | `anti-persona-01.log` references the preceding log SHA-256 and all draft hashes |
| Four complete Java classes | `JAVA_HOME=<JDK21> bash compile_examples.sh <isolated-stage-lib> <temporary-class-output>`; javac 21.0.11, `-Xlint:all -Werror`, exit 0 | `javac-final.log`; examples are byte-compared to Java blocks |
| Articles and navigation | `python3 check_writing.py receipt --isolated .omo/evidence/play-db-20261003`; article=draft bytes, at least 130 lines, previous/next/00 target files exist, 25 next26 remains plain text | `verification-receipt.log` contains article and cover SHA-256 |
| Cover structure | XML parse, 1200×480, #0c1422 background, node y165–255, all text above y300 | `verification-receipt.log`; no browser or pixel-render claim |
| Isolated outcome attribution | Parse original XML and summary directly: 38 JUnit cases without failure/error; 37 raw HTTP observations; summary PASS | `verification-receipt.log` freezes original summary SHA-256 |

The initial `anti-ai-tone-01.log` preserves an invalid multi-file CLI invocation, corrected by invoking the checker once per draft. `javac.log` preserves the initial serialVersionUID warning; the final example and final compile have repaired it. Missing basedpyright was not installed; Python verification ran directly.

The isolated source jars used by compilation are under `/private/tmp/play-db-work-20261003/target/universal/stage/lib`. This is a build provenance path in evidence, not a reader command. Articles use repository-relative commands and configure JAVA_HOME explicitly. The published raw experiment evidence location is `examples/play-lab/evidence/batch22-25/isolated`, to be copied by the parent; direct attribution checks used the already verified original `.omo/evidence/play-db-20261003` files.

## Review boundaries

The articles preserve default/dedicated SQL health timings as one finite functional observation, not a benchmark; the two HTTP 504 cases have different commit states; initial migration-lock creation observed one successful starter and one failed starter, while precreated locks admitted both; shutdown observed JDBC commit, reverse hooks and resource terminal states but does not promise crash survival or exactly-once effects.

Shared sbt/stage, generated pages and browser checks remain the parent's responsibility. The PostgreSQL fixture is left running for that independent revalidation. All listed source links use the fixed Play SHA. The four Java examples are complete compilable classes, while runtime scenario evidence belongs to the cumulative lab rather than an unclaimed execution of these extracted classes.
