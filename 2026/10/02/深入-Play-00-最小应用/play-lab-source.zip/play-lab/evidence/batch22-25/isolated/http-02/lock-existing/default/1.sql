# --- !Ups
CREATE TABLE items(id integer PRIMARY KEY, name text);
INSERT INTO items VALUES(1,'old');
SELECT pg_sleep(0.6);
# --- !Downs
DROP TABLE items;
