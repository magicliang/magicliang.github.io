# Play 22–25 isolated implementation handoff

Implementation root: `/private/tmp/play-db-work-20261003`. Shared `examples/play-lab`, articles, and Git were not modified by this slice. No commit or push was made.

## Final verification after review fixes

The final executable is from `full-test-stage-07.log`: **38/38 tests and stage PASS**, completed 2026-10-03 18:39:35. XML is in `full-test-07-xml/`. The final production matrix is **`http-04/summary.json` result PASS**, with 37 raw HTTP observations and all PostgreSQL queries preserved alongside it. Earlier runs below are retained history.

`db-optout-final-test.log` and `db-optout-final-xml/` confirm the final source still passes the original 31 test cases without a JDBC URL; seven DB methods are skipped by assumptions. The runner duplicates success/skipped notifications, so raw sbt totals are 45 / Passed 38 / Skipped 7; do not interpret those as 38 independently executed DB-free tests. The final PostgreSQL observation reports zero other database connections after all owned application processes stopped.

Cleanup review fixed executor-close exceptions skipping database shutdown, scheduler-close exceptions skipping worker shutdown, and pool-close exceptions skipping file close. Main exceptions retain cleanup failures as suppressed; interrupt status is restored. The new `/db/interrupted-cleanup` scenario executes a real SELECT 1, interrupts its cleanup driver, and observes the original primary exception, suppressed=1, interrupted=true, poolClosed=true, executorTerminated=true. Both the JUnit output and `http-04/summary.json.interruptedCleanup` record these values.

`/db/load?dedicated=false|true` is the bounded real JDBC saturation scenario. The harness starts an additional isolated process with default dispatcher parallelism min=max=2, reads those values back, and externally observes two PostgreSQL PgSleep queries before sending health probes. Each SQL task records submission/start/borrow/SQL-end/return times and actual thread name. In final http-04, default-dispatcher health calls took 0.881692 / 0.005473 / 0.005100 seconds; dedicated-dispatcher calls took 0.010628 / 0.005715 / 0.004915 seconds. All returned 200. These are finite observations under the stated configuration, not a throughput benchmark or general performance claim.

ManagedDatabaseJob now marks stopping at the start/drain synchronization boundary, rejects new work before resource access, and repairs inFlight/terminal state when scheduler or worker submission is rejected. A real start/stop race test begins an accepted 700 ms SQL job, observes stopping, rejects new jobs both during and after stop, and ends at inFlight=0/committed-inserted-1/stopping=true. The controller maps a scheduling rejection to 503 DB_STOPPING; the race itself is exercised through the Java owner, not a claim that an HTTP request was accepted after the server stopped listening.

The final fixture is **still running for the parent's independent shared verification**, as requested: container `play-db-lab-20261003-pipeline-43`, id `2754552e6407a556535afa804ab00c7ade4969399d0eeeca376c949d04ab1a46`, loopback PostgreSQL port **35711**. `container-followup-inspect.json` freezes its identity. `postgres-followup-final-state.txt` and `postgres-followup-server.log` record terminal state after the owned application processes exited. Parent owns final stop/removal after its verification; do not act on unrelated containers.

The final `manifest.json` supersedes the initial hashes. No Java/config source was edited after final stage. The Python harness subsequently removed the redundant one-query 1-second observation window, whose sampling failure is retained in `http-03.log`; the stronger two-query saturation scenario preserves and expands that coverage. No acceptance assertion about active JDBC work or light HTTP traffic was removed without replacement.

## Initial verified runs retained

- `full-test-stage-04.log`: `sbtw test stage`, DB opt-in, 36 tests passed; final stage success at 2026-10-03 18:25:12. Raw XML is in `full-test-04-xml/`.
- `http-02.log`, `http-02/summary.json`: complete production-stage HTTP/PostgreSQL matrix PASS; 35 HTTP observations in `http-02/http-observations.json`, SQL invocations and terminal results in `http-02/sql-observations.json`.
- `db-optout-baseline-test.log`, `db-optout-xml/`: the original 31 test cases passed with DB disabled and no JDBC URL. The five DB methods use JUnit assumptions and are skipped. The JUnit interface emits duplicate success/skipped entries for those methods (raw sbt says Total 41 / Passed 36 / Skipped 5); do not describe this as 36 DB-independent assertions or five passing DB tests.
- `no-container-stage.json` / `.log`: production startup after this task's container was removed, no JDBC URL environment variable; `/health` 200 and `/db/pools` 503.
- `postgres-final-state.txt`: PostgreSQL version and final background rows; zero other connections to the experiment database after all owned stage processes stopped. `container-stop.txt` and `container-remove.txt` identify the only container stopped/removed.

## Scope and manifest

Exactly nine new source files:

1. `app/controllers/DatabaseLabController.java`
2. `app/labdb/DbAccess.java`
3. `app/labdb/PoolLab.java`
4. `app/labdb/TransactionLab.java`
5. `app/labdb/EvolutionLab.java`
6. `app/labdb/LateCommitLab.java`
7. `app/lifecycle/ManagedDatabaseJob.java`
8. `test/DatabaseLabTest.java`
9. `lab/database_checks.py`

Three existing files have additive changes only: `build.sbt`, `conf/application.conf`, `conf/routes`. Exact integration diffs are `build.sbt.patch`, `conf-application.conf.patch`, `conf-routes.patch`. Preserve concurrent shared edits when applying them. `manifest.json` includes source and final stage application/assets jar SHA-256; no source change followed that build.

Dependencies added: `javaJdbc`, `evolutions`, `org.postgresql:postgresql:42.7.5`. `resolved-jdbc-artifacts.json` records actual stage jars, manifests, and SHA-256, including HikariCP 5.0.1 and PostgreSQL JDBC 42.7.5. No other dependency was added.

DB is off by default. Opt in using `PLAY_LAB_DB_ENABLED=true` and `PLAY_LAB_JDBC_URL=jdbc:postgresql://127.0.0.1:<port>/play_lab?connectTimeout=3&socketTimeout=5`. Synthetic default user/password are postgres / lab-only-password. `db {}` leaves Play without an automatic default pool. Migration runners create their own explicit `db.default` configuration.

## HTTP contract and observed results

All endpoints are finite synthetic lab GETs, designed for loopback verification. Each request may create small experiment pools; this is not a production per-request pool recommendation.

| Endpoint | Result and observation |
|---|---|
| `/db/pools` | pool maximum 2; executor 4 produced 2 connection waiters and queue 0; executor 2 produced 0 connection waiters and queue 2. Each task records submitted/start/borrow/SQL-finished/returned microseconds. All four tasks in each case ended `ok`, active connections returned to 0. |
| `/db/placement?dedicated=false` / `true` | Real `pg_sleep(1)` then SELECT 1 ran on `application-pekko.actor.default-dispatcher-7` / `application-lab-blocking-dispatcher-22`; three concurrent `/health` calls per case returned 200. The six observed light HTTP times were roughly 4–8 ms, only this finite run; no capacity/performance ranking. |
| `/db/transactions` | Successful order/debit, forced exception rollback, same-key one CREATED plus one REPLAY, changed-payload CONFLICT, different-key stock=1 one winner, separate tenant keys, closed connection after returning pending Stage, late commit, statement timeout rollback. |
| `/db/order/prepare` then `/db/order?id=<id>&key=same&payload=p` | Fixture starts stock=1. Two concurrent same-key calls return 201/200, exactly one order/debit. Changing payload returns real HTTP 409, order remains 1 and stock 0. |
| `/db/late/start?committed=false` | Real HTTP 504 while task is unfinished; `/db/late/status?id=<id>` uses a new connection and sees 0 orders. |
| `/db/late/start?committed=true` | Real HTTP 504 while task is unfinished, but new connection already sees 1 committed order. |
| `/db/late/status?id=<id>&release=true&retry=true` | Both modes end taskDone=true, ordersOnNewConnection=1 and retryInserted=0. Start accepts at most four jobs per application, one pending job at a time. Release latch and SQL waits are bounded. |
| `/db/evolutions` | Distinct generated schemas; empty/restart metadata 1/1, revision two metadata 2, label backfilled and NOT NULL. Broken script with autocommit=true left partialTableExists=1, metadataRows=1/state applying_up; false left partialTableExists=0, metadataRows=0. |
| `/db/background/start?key=<synthetic>&millis=1500` and `/db/background/status` | Managed scheduler, executor, JDBC pool, and file; key limited to 80 safe characters, sleep 0–2000 ms. Owner and journal may be set with `PLAY_LAB_OWNER` and `PLAY_LAB_LIFECYCLE_JOURNAL`. |

Borrow timeout is a real Hikari `SQLTransientConnectionException`. Recovery first waits until both connections are initialized, holds both, then asks for the third with a 300 ms budget. SQL division by zero gives 22012; application exception also returns the borrowed connection. After failures, active=0 and SELECT 1 succeeds.

Statement timeout is PostgreSQL SQLSTATE 57014 with inventory restored to 1. Returning a pending CompletionStage from `withTransaction` commits before that Stage is released; a later use of its captured connection observes `closed=true`. Those are actual JDBC tests, not mocks.

## Production migration and lifecycle process evidence

`lab/database_checks.py` launches only its own production-stage processes with unique PID files, ports, logs, and finite waits. Its generated configs/scripts are preserved under `http-02/`.

- Production default autoApply=false: startup exit 255, application table count 0 (`production-default-rejected.log`). Explicit true applied revision 1; restart stayed at one applied revision; revision 2 produced `1|old|old` and nullable=`NO`.
- Two starters, useLocks=true, pool maximum/minimum 2: **initial lock-table creation** observed ready `[true,false]`, exits `[143,255]`. Losing process hit PostgreSQL duplicate `pg_type_typname_nsp_index` for `play_evolutions_lock`; see `lock-initial-b.log`. Metadata/data still one applied revision and one row. Do not generalize this run to guaranteed failure or guaranteed success.
- With lock table precreated, both starters reached ready, both stopped with 143, and metadata/data remained one revision/one row. See `lock-existing-a.log` and `lock-existing-b.log`.
- Real SIGTERM was sent only after an external `pg_stat_activity` query saw PgSleep. Journal started drain with inFlight=1; task committed one row; drain ended at 0; synchronous and asynchronous failing hooks were logged; final hook still ran. `database-main.jsonl` reports fileClosed, workerTerminated, schedulerTerminated, poolClosed all true. A fresh PostgreSQL query then confirmed one committed background row.
- Two production processes scheduled the same business key. Terminal journals recorded committed-inserted-0 and committed-inserted-1, and database count was 1. This is unique-key idempotency, not durable scheduling or Actor persistence.

## Frozen environment and reproduction

Play 3.0.6 source was read from `/private/tmp/play-series-source/playframework-3.0.6`; supplied source SHA is `2e56aff7d4e7a74af61e4bd39ec9e3ed7f300cd6`. The extracted directory has no Git metadata; `source-evidence.json` records exact source file hashes and line excerpts instead of claiming a locally verified Git HEAD.

PostgreSQL server: 17.6 (Debian 17.6-2.pgdg13+1), aarch64. Image metadata and RepoDigests are in `image-inspect.json`; digest entries are `sha256:00bc86618629af00d2937fdc5a5d63db3ff8450acf52f0636ec813c7f4902929` and `sha256:ac74e8c63c516b1f81fbaaede0663981399f80e42369431136b2455557f8547b`. Owned container was `play-db-lab-20261003-pipeline-42`, id `f8049469e056914ee65cde0e8a20979e57a23d28e47c2f019fc1581726f6c139`, loopback port 42081; it has been removed.

Build invocation used JDK `/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn`, launcher `/private/tmp/play-series-tools/sbt-launch-1.10.7.jar`, and `bash /private/tmp/play-db-work-20261003/sbtw test stage` with the opt-in environment above.

For a new owned PostgreSQL 17.6 fixture, rebuild if needed, then run this one-line harness command (substitute that fixture's container and port):

`JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn python3 /private/tmp/play-db-work-20261003/lab/database_checks.py --container <owned-container> --jdbc-url 'jdbc:postgresql://127.0.0.1:<port>/play_lab?connectTimeout=3&socketTimeout=5' --evidence <fresh-evidence-directory>`

## Preserved failed attempts and boundaries

- `phase22-23-test-01.log`: initial Java overload compilation failures; repaired before the successful second run.
- `http-01.log` plus `http-01/`: external container observation missed the original 200 ms sleep. Final experiment uses a finite 1 s query, with actual PgSleep checked before sending light HTTP probes.
- `full-test-stage-02.log` and `failed-02-TEST-DatabaseLabTest.xml`: initial 300 ms borrow timeout also caught pool initialization. Final recovery experiment waits for two idle physical connections before measuring the third borrow; full-test-stage-03 and -04 passed.
- This slice proves finite local PostgreSQL, JDBC, Play production processes, migration failures, and cooperative shutdown. It does not prove performance under production load, distributed exactly-once scheduling, or forced-kill/crash durability. Real client-disconnect coverage remains with the 18–21 slice; a CompletableFuture cancellation is not substituted for that evidence.
