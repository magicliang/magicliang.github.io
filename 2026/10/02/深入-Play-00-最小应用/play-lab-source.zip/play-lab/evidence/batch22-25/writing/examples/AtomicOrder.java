import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import play.db.Database;

public final class AtomicOrder {
    private static final class StockConflict extends RuntimeException {
        private static final long serialVersionUID = 1L;
    }

    public static String purchase(Database database, String tenant,
            String key, String payload, String sku) {
        try {
            return database.withTransaction(connection -> {
                int inserted;
                try (PreparedStatement statement = connection.prepareStatement(
                        "INSERT INTO lab_orders VALUES(?,?,?,?) "
                        + "ON CONFLICT(tenant,idempotency_key) DO NOTHING")) {
                    statement.setQueryTimeout(5);
                    statement.setString(1, tenant);
                    statement.setString(2, key);
                    statement.setString(3, payload);
                    statement.setString(4, sku);
                    inserted = statement.executeUpdate();
                }
                if (inserted == 0) {
                    try (PreparedStatement statement = connection.prepareStatement(
                            "SELECT payload FROM lab_orders "
                            + "WHERE tenant=? AND idempotency_key=?")) {
                        statement.setQueryTimeout(5);
                        statement.setString(1, tenant);
                        statement.setString(2, key);
                        try (ResultSet rows = statement.executeQuery()) {
                            if (!rows.next()) {
                                throw new SQLException("missing idempotency row");
                            }
                            return rows.getString(1).equals(payload)
                                    ? "REPLAY" : "CONFLICT";
                        }
                    }
                }
                try (PreparedStatement statement = connection.prepareStatement(
                        "UPDATE lab_inventory SET remaining=remaining-1 "
                        + "WHERE sku=? AND remaining>0")) {
                    statement.setQueryTimeout(5);
                    statement.setString(1, sku);
                    if (statement.executeUpdate() != 1) {
                        throw new StockConflict();
                    }
                }
                return "CREATED";
            });
        } catch (StockConflict conflict) {
            return "CONFLICT";
        }
    }
}
