import argparse
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = pathlib.Path(__file__).resolve().parents[5]
HERE = pathlib.Path(__file__).resolve().parent
NAMES = {
    22: "JDBC与连接池",
    23: "事务与幂等",
    24: "Evolutions与模式升级",
    25: "生命周期与后台任务",
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["ai", "persona", "receipt"])
    parser.add_argument("--ai-script")
    parser.add_argument("--isolated")
    args = parser.parse_args()
    print("invocation:", " ".join(sys.argv), flush=True)
    print("utc:", time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), flush=True)
    drafts = [HERE / "drafts" / f"{number}.md" for number in NAMES]
    for draft in drafts:
        print("sha256:", draft.name, digest(draft), flush=True)
    if args.mode == "ai":
        assert args.ai_script
        for draft in drafts:
            command = [sys.executable, args.ai_script, "--profile", "tech", str(draft)]
            print("command:", " ".join(command), flush=True)
            result = subprocess.run(command, text=True, timeout=30)
            print("exit:", result.returncode, flush=True)
            assert result.returncode == 0
    elif args.mode == "persona":
        ai_log = HERE / "anti-ai-tone-02.log"
        assert ai_log.exists() and "RESULT PASS" in ai_log.read_text()
        print("preceding anti-ai-tone log sha256:", digest(ai_log))
        pattern = re.compile("我|我们|咱|本人|你|让我们|各位看官|话说|且说|欲知后事|"
                             "愣住|鼻子一酸|花了一个下午|朋友说|亲身|原稿认为|原文声称")
        for draft in drafts:
            prose = re.sub(r"```.*?```", "", draft.read_text(), flags=re.S)
            hits = [(index, line) for index, line in enumerate(prose.splitlines(), 1)
                    if pattern.search(line)]
            print("persona/red-line prose scan:", draft.name, json.dumps(hits, ensure_ascii=False))
            assert not hits
        print("Manual review: source/log support, paragraph progress, connected technical prose;")
        print("no first-person narrative, invented lived experience, anthropomorphism or storyteller framing.")
        print("Pattern scan is auxiliary; complete prose received manual review after anti-ai-tone.")
    else:
        assert args.isolated
        evidence = pathlib.Path(args.isolated)
        summary = json.loads((evidence / "http-04/summary.json").read_text())
        records = json.loads((evidence / "http-04/http-observations.json").read_text())
        assert summary["result"] == "PASS" and len(records) == 37
        xmls = sorted((evidence / "full-test-07-xml").glob("*.xml"))
        cases = []
        for path in xmls:
            tree = ET.parse(path)
            assert not tree.findall(".//failure") and not tree.findall(".//error")
            cases.extend(tree.findall(".//testcase"))
        assert len(cases) == 38
        print("ISOLATED evidence: 38 JUnit cases, 37 HTTP observations; summary SHA256", digest(evidence / "http-04/summary.json"))
        print("No shared build, browser or performance benchmark claim is made.")
        ns = "{http://www.w3.org/2000/svg}"
        for number, name in NAMES.items():
            post = ROOT / "source/_posts" / f"2026-10-03-深入-Play-{number:02}-{name}.md"
            draft = HERE / "drafts" / f"{number}.md"
            assert post.read_bytes() == draft.read_bytes()
            text = post.read_text()
            assert len(text.splitlines()) >= 130
            assert "../../02/深入-Play-00-最小应用/" in text
            assert "2e56aff7d4e7a74af61e4bd39ec9e3ed7f300cd6" in text
            blocks = re.findall(r"```java\n(.*?)```", text, re.S)
            assert len(blocks) == 1
            class_name = re.search(r"public final class (\w+)", blocks[0]).group(1)
            sample = HERE / "examples" / (class_name + ".java")
            assert sample.read_text().strip() == blocks[0].strip()
            cover = post.with_suffix("") / "cover.svg"
            svg = ET.parse(cover).getroot()
            assert svg.attrib["viewBox"] == "0 0 1200 480"
            assert svg.attrib["width"] == "1200" and svg.attrib["height"] == "480"
            assert svg.find(ns + "rect").attrib["fill"] == "#0c1422"
            for element in svg.iter():
                if element.tag == ns + "text":
                    assert float(element.attrib["y"]) < 300
                if element.attrib.get("class") == "node":
                    assert float(element.attrib["y"]) >= 165
                    assert float(element.attrib["y"]) + float(element.attrib["height"]) <= 255
            for destination in re.findall(r"\]\((\.\./[^)]+)\)", text):
                slug = destination.rstrip("/").split("/")[-1]
                assert list((ROOT / "source/_posts").glob(f"*-{slug}.md")), destination
            if number == 25:
                assert "下一篇：26 认证与授权（待发布）" in text
            print("ARTICLE", post.relative_to(ROOT), "lines", len(text.splitlines()), "sha256", digest(post))
            print("JAVA", sample.relative_to(ROOT), "sha256", digest(sample))
            print("COVER", cover.relative_to(ROOT), "sha256", digest(cover))
            print("NAVIGATION local targets present; SVG geometry and blank lower title band checked.")
        for name in ["anti-ai-tone-02.log", "anti-persona-01.log", "javac-final.log"]:
            artifact = HERE / name
            assert artifact.stat().st_size > 40
            print("RAW", name, "sha256", digest(artifact))
    print("RESULT PASS", flush=True)


if __name__ == "__main__":
    main()
