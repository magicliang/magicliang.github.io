# --- !Ups
ALTER TABLE items ADD COLUMN label text;
UPDATE items SET label=name;
ALTER TABLE items ALTER COLUMN label SET NOT NULL;
# --- !Downs
ALTER TABLE items DROP COLUMN label;
