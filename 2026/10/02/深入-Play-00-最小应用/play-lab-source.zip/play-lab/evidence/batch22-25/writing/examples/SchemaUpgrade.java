import java.util.List;
import java.util.Map;
import play.db.Database;
import play.db.evolutions.Evolution;
import play.db.evolutions.Evolutions;

public final class SchemaUpgrade {
    public static void apply(Database database, String schema) {
        if (!schema.matches("[a-z][a-z0-9_]{0,40}")) {
            throw new IllegalArgumentException("invalid schema name");
        }
        Evolution first = new Evolution(1,
                "CREATE TABLE " + schema
                        + ".items(id integer PRIMARY KEY, name text);"
                        + "INSERT INTO " + schema
                        + ".items VALUES(1,'old');",
                "DROP TABLE " + schema + ".items;");
        Evolution second = new Evolution(2,
                "ALTER TABLE " + schema
                        + ".items ADD COLUMN label text;"
                        + "UPDATE " + schema + ".items SET label=name;"
                        + "ALTER TABLE " + schema
                        + ".items ALTER COLUMN label SET NOT NULL;",
                "ALTER TABLE " + schema + ".items DROP COLUMN label;");
        Evolutions.applyEvolutions(database,
                Evolutions.fromMap(Map.of(database.getName(),
                        List.of(first, second))), false, schema);
    }
}
