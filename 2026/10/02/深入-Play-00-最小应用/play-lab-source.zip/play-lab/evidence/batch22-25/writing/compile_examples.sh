#!/usr/bin/env bash
set -euo pipefail
: "${JAVA_HOME:?Set JAVA_HOME to JDK 21}"
stage_lib=${1:?Pass the stage lib directory}
class_output=${2:?Pass a disposable class output directory}
writing_dir=$(cd -- "$(dirname -- "$0")" && pwd)
set -x
"$JAVA_HOME/bin/javac" -version
"$JAVA_HOME/bin/javac" -Xlint:all -Werror -verbose -cp "$stage_lib/*" -d "$class_output" "$writing_dir"/examples/*.java
set +x
echo 'RESULT PASS: four complete article classes compiled with -Xlint:all -Werror'
