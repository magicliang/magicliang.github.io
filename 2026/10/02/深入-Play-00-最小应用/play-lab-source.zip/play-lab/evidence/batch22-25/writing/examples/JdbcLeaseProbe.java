import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executor;
import play.db.Database;

public final class JdbcLeaseProbe {
    private final Database database;
    private final Executor executor;

    public JdbcLeaseProbe(Database database, Executor executor) {
        this.database = database;
        this.executor = executor;
    }

    public CompletionStage<Integer> selectOne() {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection connection = database.getConnection();
                 Statement statement = connection.createStatement()) {
                statement.setQueryTimeout(5);
                try (ResultSet rows = statement.executeQuery("SELECT 1")) {
                    if (!rows.next()) {
                        throw new SQLException("SELECT 1 returned no row");
                    }
                    return rows.getInt(1);
                }
            } catch (SQLException failure) {
                throw new CompletionException(failure);
            }
        }, executor);
    }
}
