from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

evidence = Path(__file__).resolve().parent
root = Path('/private/tmp/play-production-work-20261003')
draft = evidence / 'article-draft.md'
writing = evidence / 'writing'
writing.mkdir(exist_ok=True)
scan = subprocess.run(['python3', '/Users/magicliang/.codex/skills/anti-ai-tone/scripts/check_prose.py', '--profile', 'tech', '--json', str(draft)], capture_output=True, text=True, check=True)
(writing / '01-anti-ai-tone.json').write_text(scan.stdout)
assert json.loads(scan.stdout)['errors'] == 0 and json.loads(scan.stdout)['warnings'] == 0
prose = re.sub(r'```.*?```', '', draft.read_text(), flags=re.S)
persona = [term for term in ['我们', '咱们', '本人', '我觉得', '我认为', '花了一个下午', '各位看官', '欲知后事', '让我', '我在'] if term in prose]
assert not persona, persona
(writing / '02-anti-persona-fabrication.json').write_text(json.dumps({'status':'PASS', 'matches':persona, 'manualReview':'Non-personal prose; no invented experience, bodily state, writing narrative or storyteller transitions. Read after anti-ai-tone.'}, indent=2))
java = re.findall(r'```java\n(.*?)\n```', draft.read_text(), re.S)
assert len(java) == 1
expected = root / 'app/controllers/ProductionController.java'
assert java[0].strip() == expected.read_text().strip()
source = writing / 'ProductionController.java'
source.write_text(java[0] + '\n')
classes = writing / 'compiled'
classes.mkdir(exist_ok=True)
classpath = ':'.join(str(p) for p in (root / 'target/universal/stage/lib').glob('*.jar'))
command = [str(Path(os.environ['JAVA_HOME'])/'bin/javac'), '--release', '21', '-cp', classpath, '-d', str(classes), str(source)]
result = subprocess.run(command, capture_output=True, text=True)
(writing / 'javac.log').write_text(json.dumps(command) + '\n' + result.stdout + result.stderr + '\nEXIT=' + str(result.returncode))
assert result.returncode == 0 and (classes / 'controllers/ProductionController.class').stat().st_size > 0
tests = {}
junit = evidence/'junit-final'
junit.mkdir(exist_ok=True)
raw = 0
for p in (root/'target/test-reports').glob('TEST-*.xml'):
    shutil.copy2(p, junit/p.name)
    for t in ET.parse(p).getroot().iter('testcase'):
        raw += 1
        key = t.attrib['classname'] + '.' + t.attrib['name']
        skipped = t.find('skipped') is not None
        assert t.find('failure') is None and t.find('error') is None
        tests[key] = tests.get(key, False) or skipped
build = {'rawJUnitRecords':raw, 'distinctMethods':len(tests), 'skippedMethods':sum(tests.values()), 'executedMethods':sum(not v for v in tests.values())}
assert build['distinctMethods'] == 47 and build['executedMethods'] == 40 and build['skippedMethods'] == 7
jar = next((root/'target/universal/stage/lib').glob('example.playlab.play-lab-*-sans-externalized.jar'))
with zipfile.ZipFile(jar) as z:
    build['classByteEquality'] = {}
    for name in ['controllers/ProductionController.class','production/ProductionProbe.class']:
        binary = (root/'target/scala-2.13/classes'/name).read_bytes()
        assert binary == z.read(name)
        build['classByteEquality'][name] = hashlib.sha256(binary).hexdigest()
build['applicationJarSHA256'] = hashlib.sha256(jar.read_bytes()).hexdigest()
(evidence/'build-summary.json').write_text(json.dumps(build, indent=2))
baseline = json.loads((evidence/'baseline.json').read_text())
for path in ['build.sbt','conf/application.conf','project/plugins.sbt','project/build.properties']:
    assert hashlib.sha256((root/path).read_bytes()).hexdigest() == baseline[path], path
files = ['app/controllers/ProductionController.java','app/production/ProductionProbe.java','conf/production.conf','test/ProductionTest.java','lab/production_build.py','lab/production_checks.py','lab/PRODUCTION.md']
manifest = {'sources':[{'source':str(root/p), 'destination':'examples/play-lab/'+p, 'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in files],
            'routes':[line for line in (root/'conf/routes').read_text().splitlines() if '/production/' in line],
            'evidenceDestination':'examples/play-lab/evidence/batch30/isolated',
            'unchanged':['build.sbt','conf/application.conf','project/plugins.sbt','project/build.properties']}
(evidence/'integration-manifest.json').write_text(json.dumps(manifest, indent=2))
summary = json.loads((evidence/'run-final-02/summary.json').read_text())
assert summary['status'] == 'PASS'
events = json.loads((evidence/'run-final-02/observations.json').read_text())
exits = [e for e in events if e['scenario'].endswith('-exit')]
assert len(exits) == 4 and all(e['listenerClosed'] for e in exits)
assert len(re.findall(r'```mermaid', draft.read_text())) == 2
receipt = {'status':'PASS','build':build,'network':summary,'orderedWriting':['01-anti-ai-tone.json','02-anti-persona-fabrication.json'], 'articleSHA256':hashlib.sha256(draft.read_bytes()).hexdigest(),'mermaidDiagrams':2,'completeJavaExamplesCompiled':1,'sourceFiles':len(files),'routes':len(manifest['routes'])}
(evidence/'delivery.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps(receipt, indent=2))
