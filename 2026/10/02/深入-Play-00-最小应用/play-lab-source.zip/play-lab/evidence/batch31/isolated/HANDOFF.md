# Play 31 isolated experiment and article handoff

The final network run is `http-03`, not the historical `http-01` or `http-02`. All three comparison groups are measured through real HTTP against the isolated production stage. PostgreSQL remains the existing synthetic fixture on loopback port 35711. No shared lab source, plan, Git state, or container lifecycle was modified by this slice.

## Integration ownership

Copy only these five new files from `/private/tmp/play-performance-work-20261003` using an additive patch:

- `app/controllers/PerformanceController.java`
- `app/labperf/PerformanceLab.java`
- `app/labperf/PayloadLab.java`
- `test/PerformanceTest.java`
- `lab/performance_checks.py`

Append only the 13 `/perf/` routes in that isolated `conf/routes`. Do not copy the baseline routes file wholesale. `build.sbt` and `conf/application.conf` are byte-identical to the DB baseline and must not be copied. No new dependencies are required. The two default dispatcher parallelism settings are passed only as `-D` arguments to the owned performance stage process. The dedicated PerformanceTest application explicitly configures the same two-thread fixture.

The current source/JAR hashes, exact new-file manifest, and five class-byte comparisons are in `manifest.json`. The article and cover already exist in shared source:

- `source/_posts/2026-10-03-深入-Play-31-性能与容量.md`
- `source/_posts/2026-10-03-深入-Play-31-性能与容量/cover.svg`

Article hash: `9c87d06a07178bab6d32888333f675bbca4adf03924c80c5d9e707b7f9920f6e`. It contains 224 lines and two Mermaid mechanism diagrams. Keep the later chapter 30/32 navigation as plain text until the posts exist. Chapter 31 article references the eventual repository evidence destination `examples/play-lab/evidence/batch31/isolated/`; the parent owns copying the evidence there. Writing receipts can be copied to sibling `writing/`.

## Exact validation and artifacts

| Scenario | Invocation | Binary observable | Artifact |
|---|---|---|---|
| Complete isolated baseline regression | `bash sbtw test stage` with JDK 21, launcher and opt-in fixture environment | 41 tests, 0 failures/errors/skips; stage success | `full-test-stage-07.log`, `junit-final/*.xml` |
| Three JDBC modes at concurrency 1/8, three rounds, 40 requests per cell | `python3 lab/performance_checks.py --evidence <new-directory>` | 18 measured JDBC cells; all accepted tasks terminate; new-connection counts match commits | `http-03/observations.json`, `http-03/requests.jsonl` |
| Aggregate vs finite stream, concurrency 1/8, three rounds, 24 requests | same script | 12 cells; every HTTP body 262144 bytes and same SHA-256; stream 32 chunks and terminal | same raw artifacts |
| Uncached/cold/hot, concurrency 1/8, three rounds, 24 requests | same script | 18 cells; measured loader/SQL counts 24/4/0; tenant output checked per request | same raw artifacts |
| Actual HTTP timeout precedes commit | script's separate `late_0`, excluded from measurements | six tasks receive client 504 then server ACK before later SQL commit | `http-03/observations.json` first run; `requests.jsonl` ACK calls |
| Owned-resource termination | script sends SIGTERM to its own stage only | exit143; dedicated/admission/clock terminated; Hikari closed | `http-03/server.log`, final report cleanup fields |
| Independent evidence verification | `python3 .omo/evidence/play-performance-20261003/verify_receipt.py` | raw responses match 1440 measured rows; 16 cells each repeated3; timestamps ordered; bounds verified | `verification-receipt.log`, `comparison.csv` |
| Article example | JDK21 `javac -Xlint:all -Werror` with isolated stage classpath; `java NearestRank` | `N=40 p50=20 p95=38 p99=40` | `writing/java-compile.log`, `writing/java/NearestRank.java` |
| Prose scans in required order | installed anti-ai-tone checker, then persona regex plus manual review | no errors/warnings/findings; draft SHA equals final post | `writing/04-anti-ai-tone-final.json`, `writing/05-anti-persona-fabrication-final.json` |
| Article navigation and SVG geometry | XML/path/hash checks | correct existing relative targets, two diagrams, 1200×480, labels130/nodes165–255/lower180px blank | `writing/navigation-svg-receipt.json`, `writing/verification.log` |

The final test invocation used JDK `/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn`, launcher `/private/tmp/play-series-tools/sbt-launch-1.10.7.jar`, `PLAY_LAB_DB_ENABLED=true` and synthetic JDBC URL `jdbc:postgresql://127.0.0.1:35711/play_lab?connectTimeout=3&socketTimeout=5`. All waits are finite. The Python script chooses its own loopback HTTP port, creates a fresh evidence directory, and finally terminates only its recorded child process. Synthetic `perf_*` schemas are retained for readback; the PostgreSQL container was not stopped.

## Endpoint contract

`GET /perf/config` initializes the one application-owned pool and returns actual JDBC/JDK/pool/dispatcher settings. `GET /perf/begin?run=<id>&mode=default|dedicated|admission&count=1..100` starts a bounded run after the previous run has completely drained. `GET /perf/task?run=<id>&id=0..count-1` returns 200,503,504 with task id. The task ledger remains available after a timeout.

`GET /perf/progress` returns lightweight pending/allTerminal flags. `GET /perf/state` returns the per-task ledger and process counters. `GET /perf/committed` uses a new JDBC connection after drain to count committed rows for that run. `GET /perf/ack?run=<id>&id=<id>` records a same-server-clock timestamp after the client has received a 504; this is used only by the separate late-commit proof.

`GET /perf/payload/begin?run=<id>&mode=aggregate|stream|uncached|cold|hot&count=1..100` starts the payload/cache experiment. `/perf/payload/aggregate`, `/perf/payload/stream`, and `/perf/payload/value` take run/id. `/perf/payload/warm` takes run/key0..3 and is allowed only in hot mode. `/perf/payload/state` returns terminal records and loader/query/process counters. These are finite synthetic experiment controls, not a production workload service API.

## Observed final values and interpretation

Each high-concurrency JDBC round: default40×200 and40 commits; dedicated2×200+38×504 and40 commits; admission2×200+2×504+36×503 and4 commits. Default HTTP p95 in milliseconds is269.817/332.509/391.045, and health p95 is291.623/292.806/331.240. Dedicated health p95 is17.707/15.951/6.803; admission5.076/3.119/2.366. These results are observations from this bounded run, not production limits or latency guarantees.

Default dispatcher wait can occur outside the timer's measurement origin. The timer begins after executor submission; it is not an ingress deadline. Existing timestamps do not separate all framework wait before Action from response scheduling after the result. Dedicated HTTP completion throughput includes early504 while all40 SQL tasks continue. Admission throughput includes36 refusals and must not be labeled successful business throughput.

Client latency is full-body receive time. Quantiles use nearest-rank, `sorted[ceil(p*N)-1]`; no interpolation and no averaging of per-round percentiles. All statuses are included, with separate200/503/504/client-error counts. The generator is closed-loop and connection-per-request. Warmup samples, cache primes and ACK proof are excluded. The control flow rotates mode order and uses fixed counts; it does not claim steady-state JIT, open-loop saturation, external workload isolation, or production capacity.

Allocation values measure only JDBC worker tasks or aggregate array/stream mapping construction. Stream mapping includes the `ByteString.fromArray` copy confirmed by actual Pekko bytecode. Cache allocation fields are0 placeholders for an unmeasured scope; they do not mean no allocation. CPU/GC counters cover the whole JVM stage window; heap-used snapshots are not allocated bytes. JFR, disabling all instrumentation to measure observer cost, slow-client peak-memory capacity, and production traffic distributions were not run. Full payload integrity and repeated cache workload are measured, so neither group is left as a future acceptance item.

Application queued is sampled pending-minus-active, not Pekko internal queue size; active connection and borrower maxima are sampled. The per-task borrow duration is separately retained. Source excerpts with fixed SHA links are in `source-evidence.json`; actual dependency hashes and PostgreSQL fixture identity are in `manifest.json` and `fixture-inspect.log`.

Page generation and browser rendering remain parent-owned and were not claimed by this writing slice. No source commit or push was made.
