import collections
import csv
import hashlib
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET
import zipfile

root = Path(__file__).resolve().parent
work = Path('/private/tmp/play-performance-work-20261003')
baseline = Path('/private/tmp/play-db-work-20261003')
report = json.loads((root / 'http-03/observations.json').read_text())
assert report['status'] == 'PASS' and report['resourceCleanupObserved'] and report['serverExit'] == 143
measured = [r for r in report['rounds'] if not r['warmup']]
assert len(measured) == 48 and sum(len(r['requests']) for r in measured) == 1440
cells = collections.Counter((r['group'], r['mode'], r['concurrency']) for r in measured)
assert len(cells) == 16 and set(cells.values()) == {3}
raw = [json.loads(line) for line in (root / 'http-03/requests.jsonl').read_text().splitlines()]
for cell in measured:
    direct = [r for r in raw if r['tag'] == cell['run']]
    assert sorted(direct, key=lambda r: r['path']) == sorted(cell['requests'], key=lambda r: r['path']), cell['run']
    assert cell['clientErrors'] == cell['http500'] == 0
    assert cell['healthCount'] > 0 and set(cell['healthStatuses']) == {'200'}
    assert all(x >= 0 for x in cell['processDelta'].values())
    if cell['group'] == 'jdbc':
        state = cell['state']
        assert state['maxActive'] <= 2 and state['maxConnections'] <= 2 and state['poolActive'] == state['pending'] == 0
        for task in state['tasks']:
            assert task['done']
            event = task['events']
            if event['outcome'] == 'committed':
                names = ['submittedNanos', 'startedNanos', 'borrowStartedNanos', 'borrowedNanos', 'sqlStartedNanos', 'committedNanos', 'returnedNanos']
                values = [event[key] for key in names]
                assert values == sorted(values)
                assert event['allocatedBytes'] >= 0
                expected = 'default-dispatcher' if cell['mode'] == 'default' else 'perf-' + cell['mode'] + '-'
                assert expected in event['thread']
        assert cell['committedTasks'] == cell['committed']['committedOnNewConnection']
    elif cell['group'] == 'payload':
        assert all(row['bytes'] == 262144 for row in cell['requests'])
        assert cell['constructionAllocatedBytes'] > 0
    elif cell['group'] == 'cache':
        assert cell['queryDelta'] == cell['loaderDelta'] == {'uncached': 24, 'cold': 4, 'hot': 0}[cell['mode']]
late = next(r for r in report['rounds'] if r['run'] == report['lateHttpProofRun'])
assert late['lateAfterClientAck'] > 0
late_tasks = [t['id'] for t in late['state']['tasks'] if t['events'].get('committedNanos', 0) > t['events'].get('clientAckNanos', 10**30)]
print('PASS 48 measured cells; each of 16 cells has 3 rounds; 1440 full HTTP responses match raw JSONL')
print('PASS SQL timestamp ordering/thread positions/pool and executor bounds/new-connection commit counts')
print('PASS payload length/hash assertions and cache 24/4/0 query+loader counts')
print('PASS actual HTTP 504 -> subsequent server ACK -> later SQL commit; task IDs:', late_tasks)
print('PASS final owned process exited 143 with both executors, deadline scheduler and pool closed')

fields = ['run', 'group', 'mode', 'concurrency', 'requests', 'http200', 'http503', 'http504', 'clientErrors',
          'httpCompletedPerSecond', 'httpSuccessPerSecond', 'sqlCompletedPerSecond', 'p50', 'p95', 'p99',
          'healthP95', 'maxActive', 'maxApplicationQueued', 'maxConnections', 'maxBorrowWaiters',
          'borrowP95', 'queueP95', 'allocatedBytes', 'cpuNanos', 'gcCollections', 'gcMillis', 'queryDelta']
with (root / 'comparison.csv').open('w') as out:
    writer = csv.DictWriter(out, fieldnames=fields); writer.writeheader()
    for r in measured:
        state = r['state']
        row = {key: r.get(key, '') for key in fields}
        row.update(requests=len(r['requests']), http200=r['statuses'].get('200', 0), **r['httpLatencySeconds'], healthP95=r['healthLatencySeconds']['p95'],
                   allocatedBytes=r.get('taskAllocatedBytes', r.get('constructionAllocatedBytes', '')), **r['processDelta'])
        row.update({key: state.get(key, '') for key in ['maxActive', 'maxApplicationQueued', 'maxConnections', 'maxBorrowWaiters']})
        row['borrowP95'] = r.get('borrowWaitSeconds', {}).get('p95', '')
        row['queueP95'] = r.get('applicationQueueWaitSeconds', {}).get('p95', '')
        writer.writerow(row)

new = ['app/controllers/PerformanceController.java', 'app/labperf/PerformanceLab.java', 'app/labperf/PayloadLab.java', 'test/PerformanceTest.java', 'lab/performance_checks.py']
modified = ['conf/routes']
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = {'sourceBase': str(work), 'baseline': str(baseline), 'playSourceCommit': '2e56aff7d4e7a74af61e4bd39ec9e3ed7f300cd6',
            'new': {p: digest(work / p) for p in new}, 'modified': {p: digest(work / p) for p in modified}, 'buildChanged': False}
assert digest(work / 'build.sbt') == digest(baseline / 'build.sbt')
for subtree in ['app', 'conf', 'test', 'lab']:
    for old in (baseline / subtree).rglob('*'):
        if old.is_file() and '__pycache__' not in str(old):
            relative = str(old.relative_to(baseline))
            if relative not in modified:
                assert digest(old) == digest(work / relative), relative
classes = list((work / 'target/scala-2.13/classes/labperf').glob('*.class')) + [work / 'target/scala-2.13/classes/controllers/PerformanceController.class']
jar = next((work / 'target/universal/stage/lib').glob('*play-lab*.jar'))
manifest['stageJar'] = {'name': jar.name, 'sha256': digest(jar)}
manifest['classHashes'] = {}
with zipfile.ZipFile(jar) as archive:
    for source in classes:
        name = str(source.relative_to(work / 'target/scala-2.13/classes'))
        assert archive.read(name) == source.read_bytes()
        manifest['classHashes'][name] = digest(source)
manifest['runtimeJars'] = {p.name: digest(p) for p in (work / 'target/universal/stage/lib').glob('*.jar')
                           if any(term in p.name for term in ['HikariCP', 'postgresql', 'caffeine', 'pekko-actor_', 'play_2.13'])}
(root / 'manifest.json').write_text(json.dumps(manifest, indent=2))
reports = root / 'junit-final'; reports.mkdir(exist_ok=True)
totals = collections.Counter()
for source in (work / 'target/test-reports').glob('*.xml'):
    shutil.copy2(source, reports / source.name)
    suite = ET.parse(source).getroot()
    for key in ['tests', 'failures', 'errors', 'skipped']:
        totals[key] += int(suite.attrib.get(key, 0))
assert totals['failures'] == totals['errors'] == totals['skipped'] == 0 and totals['tests'] == 41, totals
print('PASS final JUnit XML:', dict(totals))
print('PASS unchanged DB baseline and application.conf; five new files and only route additions; no new dependencies')
print('PASS stage class bytes equal current compiled classes:', len(classes), 'stage sha256:', digest(jar))
print('Manifest:', root / 'manifest.json')
