import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET

repo = Path(__file__).resolve().parents[4]
here = Path(__file__).resolve().parent
post = repo / 'source/_posts/2026-10-03-深入-Play-31-性能与容量.md'
cover = post.with_suffix('') / 'cover.svg'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
text = post.read_text()
assert post.read_bytes() == (here / 'draft.md').read_bytes()
ai = json.loads((here / '04-anti-ai-tone-final.json').read_text())
persona = json.loads((here / '05-anti-persona-fabrication-final.json').read_text())
assert ai['errors'] == ai['warnings'] == 0 and not persona['findings']
assert persona['draftSha256'] == digest(post)
assert (here / '04-anti-ai-tone-final.json').stat().st_mtime <= (here / '05-anti-persona-fabrication-final.json').stat().st_mtime <= post.stat().st_mtime
assert text.count('```mermaid') == 2 and len(text.splitlines()) >= 130
example = re.search(r'```java\n(.*?)\n```', text, re.S).group(1)
java = here / 'java/NearestRank.java'
assert java.read_text().strip() == example.strip()
jdk = Path('/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn/bin')
commands = [[str(jdk / 'javac'), '-Xlint:all', '-Werror', '-cp', '/private/tmp/play-performance-work-20261003/target/universal/stage/lib/*', '-d', str(java.parent), str(java)], [str(jdk / 'java'), '-cp', str(java.parent), 'NearestRank']]
compile_output = []
for command in commands:
    result = subprocess.run(command, text=True, capture_output=True, timeout=30)
    output = 'COMMAND: ' + ' '.join(command) + '\nEXIT: ' + str(result.returncode) + '\n' + result.stdout + result.stderr
    print(output, end='')
    compile_output.append(output)
    assert result.returncode == 0
assert 'N=40 p50=20 p95=38 p99=40' in compile_output[-1]
(here / 'java-compile.log').write_text('\n'.join(compile_output))
svg = ET.parse(cover).getroot()
assert svg.attrib['width'] == '1200' and svg.attrib['height'] == '480'
nodes = [node for node in svg.iter() if node.attrib.get('class') == 'node']
assert len(nodes) == 4 and all(node.attrib['y'] == '165' and node.attrib['height'] == '90' for node in nodes)
assert all(float(node.attrib['y']) < 300 for node in svg.iter() if node.tag.endswith('text'))
assert any(node.attrib.get('y') == '130' for node in svg.iter())
assert any(node.attrib.get('fill') == '#0c1422' for node in svg.iter())
links = re.findall(r'\]\((\.\./[^)]+)\)', text)
checked = []
for link in links:
    slug = link.rstrip('/').split('/')[-1]
    day = '02' if link.startswith('../../02/') else '03'
    target = repo / ('source/_posts/2026-10-' + day + '-' + slug + '.md')
    assert target.is_file(), target
    checked.append({'url': link, 'source': str(target.relative_to(repo))})
assert '上一篇：30 生产打包与部署（待发布）' in text and '下一篇：32 Play 2.x 到 3.x 迁移（待发布）' in text
receipt = {'article': str(post.relative_to(repo)), 'sha256': digest(post), 'lines': len(text.splitlines()), 'mermaidCount': 2, 'cover': str(cover.relative_to(repo)), 'coverSha256': digest(cover), 'svgGeometry': '1200x480; label130; nodes165..255; no text below300', 'navigation': checked, 'pageGeneration': 'NOT_RUN by this writing slice', 'browser': 'NOT_RUN by this writing slice', 'exampleSha256': digest(java), 'scanOrder': ['04-anti-ai-tone-final.json', '05-anti-persona-fabrication-final.json'], 'scanFinalBytesMatch': True}
(here / 'navigation-svg-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print('PASS draft/final article SHA match; ordered prose scans clean; 224 lines and two Mermaid diagrams')
print('PASS Java example actual JDK21 javac -Xlint:all -Werror and runtime assertion')
print('PASS relative navigation source targets and SVG node/text geometry; page/browser NOT_RUN')
print('ARTICLE_SHA256', digest(post))
print('COVER_SHA256', digest(cover))
