import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import play.libs.Json;

public final class CookieFormProbe {
    private static HttpRequest get(String url) {
        return HttpRequest.newBuilder(URI.create(url))
            .timeout(Duration.ofSeconds(5)).GET().build();
    }

    private static HttpRequest post(String url, String body) {
        return HttpRequest.newBuilder(URI.create(url))
            .timeout(Duration.ofSeconds(5))
            .header("Content-Type", "application/x-www-form-urlencoded")
            .POST(HttpRequest.BodyPublishers.ofString(body)).build();
    }

    public static void main(String[] args) throws Exception {
        int port = Integer.parseInt(args[0]);
        if (port < 1 || port > 65535) throw new IllegalArgumentException("port");
        String base = "http://127.0.0.1:" + port;
        CookieManager cookies = new CookieManager(null, CookiePolicy.ACCEPT_ORIGINAL_SERVER);
        try (HttpClient client = HttpClient.newBuilder()
                .cookieHandler(cookies).connectTimeout(Duration.ofSeconds(5)).build()) {
            var body = HttpResponse.BodyHandlers.ofString();
            if (client.send(get(base + "/gov/login?user=alice"), body).statusCode() != 200) {
                throw new IllegalStateException("synthetic fixture disabled");
            }
            var form = client.send(get(base + "/gov/form"), body);
            String token = Json.parse(form.body()).get("csrfToken").asText();
            int missing = client.send(post(base + "/gov/objects/1", ""), body).statusCode();
            String encoded = URLEncoder.encode(token, StandardCharsets.UTF_8);
            int valid = client.send(post(base + "/gov/objects/1", "csrfToken=" + encoded), body).statusCode();
            if (missing != 403 || valid != 200) throw new AssertionError(missing + "/" + valid);
            System.out.println("PASS missing=403 valid=200");
        }
    }
}
