#!/usr/bin/env python3
"""Read-only article/asset receipt verification; not a site build or browser test."""
from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as ET
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
receipt=json.loads((HERE/'publication-receipt.json').read_text())
rows=[]
for item in receipt['articles']:
    post=ROOT/item['path'];data=post.read_bytes();text=data.decode();n=item['article']
    assert hashlib.sha256(data).hexdigest()==item['sha256']
    assert f'date: 2026-10-03 17:{n}:00' in text
    assert '../../02/深入-Play-00-最小应用/' in text
    assert '@SHA@' not in text and '/private/tmp/' not in text and '.omo/' not in text
    assert '2e56aff7d4e7a74af61e4bd39ec9e3ed7f300cd6' in text
    assert 'evidence/batch26-29/isolated/' in text
    assert '```java' in text and '改动练习' in text and '```text' in text
    cover=ROOT/item['cover'];assert hashlib.sha256(cover.read_bytes()).hexdigest()==item['coverSha256']
    xml=ET.parse(cover).getroot();assert xml.get('viewBox')=='0 0 1200 480'
    ns={'s':'http://www.w3.org/2000/svg'};assert xml.find('s:title',ns) is not None and xml.find('s:desc',ns) is not None
    assert all(float(t.get('y','0'))<=255 for t in xml.findall('s:text',ns))
    frontcover=re.search(r'^cover: (.+)$',text,re.M).group(1)
    assert frontcover=='/2026/10/03/'+post.stem.removeprefix('2026-10-03-')+'/cover.svg'
    links=re.findall(r'\]\((\.\./深入-Play-[^)]*)\)',text)
    missing=[]
    for link in links:
        slug=link.removeprefix('../').rstrip('/')
        target=ROOT/'source/_posts'/('2026-10-03-'+slug+'.md')
        if not target.is_file():missing.append(str(target.relative_to(ROOT)))
    tone=json.loads((HERE/f'{n}-anti-ai-tone.json').read_text());assert tone['errors']==tone['warnings']==0
    persona=json.loads((HERE/f'{n}-anti-persona-fabrication.json').read_text());assert persona['order']==2 and persona['draftSha256']==item['sha256'] and persona['status']=='PASS'
    if n==29:assert not re.search(r'\]\([^)]*深入-Play-30',text)
    rows.append({'article':n,'hash':'PASS','orderedScans':'PASS','dateCover':'PASS','svgXML':'PASS','heroBottomClear':'PASS','navigationMissing':missing})
for path in (HERE/'snippets').glob('*.java'):
    assert path.stat().st_size>0
assert 'EXIT 0' in (HERE/'snippet-compile.log').read_text()
assert 'PASS owner/revoke/mutation' in (HERE/'owned-counter-run.log').read_text()
assert 'PASS missing=403 valid=200' in (HERE/'cookie-form-probe-run.log').read_text()
result={'status':'PASS' if not any(r['navigationMissing'] for r in rows) else 'PENDING_ADJACENT_ARTICLE','articles':rows,'javaCompiled':4,'javaStandaloneRan':2,'notClaimed':['Hexo generation','browser rendering','database test','shared suite count','commit','push']}
(HERE/'navigation-svg-receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
