import static org.junit.Assert.*;
import static play.test.Helpers.*;
import java.util.List;
import org.junit.Test;
import play.Application;
import play.inject.guice.GuiceApplicationBuilder;
import play.libs.Json;
import org.apache.pekko.stream.Materializer;
import authlab.ObjectPolicy;
import observabilitylab.RequestEvents;

public class DecisionLayersExample {
    @Test
    public void ruleAndApplication() {
        Application app = new GuiceApplicationBuilder()
            .configure("play.filters.enabled", List.of("observabilitylab.ObservationFilter"))
            .build();
        running(app, () -> {
            Materializer materializer = app.injector().instanceOf(Materializer.class);
            int[] amounts = {1, 100, 0, 101};
            boolean[] accepted = {true, true, false, false};
            for (int index = 0; index < amounts.length; index++) {
                int amount = amounts[index];
                boolean expected = accepted[index];
                assertEquals(expected, ObjectPolicy.amountAllowed(amount));
                var result = route(app, fakeRequest(POST, "/gov/observe/decision")
                    .header("X-Gov-Id", "example-" + amount)
                    .bodyJson(Json.newObject().put("amount", amount)));
                assertEquals(expected ? 200 : 400, result.status());
                assertEquals(expected, Json.parse(contentAsString(result, materializer))
                    .get("accepted").asBoolean());
            }
            var malformed = route(app, fakeRequest(POST, "/gov/observe/decision")
                .header("X-Gov-Id", "malformed")
                .bodyText("{").header("Content-Type", "application/json"));
            assertEquals(400, malformed.status());
            contentAsString(malformed, materializer);
            var record = app.injector().instanceOf(RequestEvents.class)
                .snapshot().get("records").get("malformed");
            assertFalse(record.toString().contains("business_result"));
        });
    }
}
