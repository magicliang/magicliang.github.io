#!/usr/bin/env python3
"""Finite loopback-only governance experiments. JAVA_HOME must select JDK 21."""
import argparse, base64, concurrent.futures, contextlib, http.client, http.cookies
import json, os, pathlib, secrets, socket, struct, subprocess, threading, time, traceback, urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer

REPORT={}
SENTINEL='GOV_SENSITIVE_BODY_DO_NOT_LOG_8f46'

def port():
    with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]

class Client:
    def __init__(self,p):self.port=p;self.cookies={};self.cookieFlags={}
    def header(self):return '; '.join(k+'='+v for k,v in self.cookies.items())
    def call(self,method,path,body=None,headers=None):
        h=dict(headers or {})
        if self.cookies:h.setdefault('Cookie',self.header())
        c=http.client.HTTPConnection('127.0.0.1',self.port,timeout=6)
        try:
            c.request(method,path,body,h);r=c.getresponse();data=r.read()
            for k,v in r.getheaders():
                if k.lower()=='set-cookie':
                    jar=http.cookies.SimpleCookie();jar.load(v)
                    self.cookies.update({k:m.value for k,m in jar.items()})
                    self.cookieFlags.update({k:{a:m[a] for a in ('httponly','secure','samesite','path')} for k,m in jar.items()})
            return r.status,{k.lower():v for k,v in r.getheaders() if k.lower()!='set-cookie'},data
        finally:c.close()
    def get(self,path,headers=None):return self.call('GET',path,headers=headers)
    def post(self,path,body='',headers=None):
        h={'Content-Type':'application/x-www-form-urlencoded'};h.update(headers or {})
        return self.call('POST',path,body,h)
    def token(self):
        st,_,body=self.get('/gov/form');assert st==200,(st,body)
        return json.loads(body)['csrfToken']
    def login(self,user):
        assert self.get('/gov/login?user='+user)[0]==200
        return self.token()

@contextlib.contextmanager
def server(out,name,extra=()):
    root=pathlib.Path(__file__).resolve().parents[1];p=port();secret=secrets.token_hex(48)
    env=os.environ.copy();assert env.get('JAVA_HOME'),'JAVA_HOME required';env['APPLICATION_SECRET']=secret
    logfile=out/(name+'.log')
    with logfile.open('wb') as log:
        process=subprocess.Popen([str(root/'target/universal/stage/bin/play-lab'),'-Dconfig.resource=governance.conf','-Dlogger.resource=governance-logback.xml','-Dhttp.address=127.0.0.1','-Dhttp.port='+str(p),*extra],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
        try:
            deadline=time.monotonic()+35;c=Client(p)
            while time.monotonic()<deadline:
                if process.poll() is not None:raise AssertionError('server exited '+str(process.returncode))
                try:
                    if c.get('/gov/connection')[0]==200:break
                except OSError:pass
                time.sleep(.1)
            else:raise AssertionError('startup deadline')
            yield p
        finally:
            process.terminate()
            try:process.wait(timeout=10)
            except subprocess.TimeoutExpired:process.kill();process.wait(timeout=3)
    raw=logfile.read_text(errors='replace');assert secret not in raw;assert SENTINEL not in raw
    scanned=0
    for artifact in (root/'target/universal/stage').rglob('*'):
        if not artifact.is_file():continue
        scanned+=1;tail=b''
        with artifact.open('rb') as stream:
            while block:=stream.read(65536):
                assert secret.encode() not in tail+block,artifact
                tail=block[-len(secret):]
    REPORT.setdefault('processes',[]).append({'name':name,'exit':process.returncode,'secretAbsent':True,'sentinelAbsent':True,'port':p,'stagedFilesScannedForRuntimeSecret':scanned})

def wait_record(c,id,phase):
    end=time.monotonic()+7
    while time.monotonic()<end:
        rows=json.loads(c.get('/gov/observations')[2]);entry=rows['records'].get(id,{})
        if any(e['phase']==phase for e in entry.get('events',[])):return entry
        time.sleep(.04)
    raise AssertionError((id,phase,entry))

def exact(s,n):
    data=b''
    while len(data)<n:
        block=s.recv(n-len(data));assert block,'unexpected EOF';data+=block
    return data

def ws(c,id,track):
    s=socket.create_connection(('127.0.0.1',c.port),timeout=6)
    request=(f'GET /gov/socket/{id}?track={track} HTTP/1.1\r\nHost: localhost:{c.port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: '+base64.b64encode(b'0123456789abcdef').decode()+'\r\nSec-WebSocket-Version: 13\r\nOrigin: http://trusted.example\r\nCookie: '+c.header()+'\r\n\r\n')
    s.sendall(request.encode());h=b''
    while not h.endswith(b'\r\n\r\n') and len(h)<16384:h+=exact(s,1)
    status=int(h.split(b' ')[1]);return s,status

def sendframe(s,text):
    data=text.encode();mask=b'1234';assert len(data)<126
    s.sendall(bytes([0x81,0x80|len(data)])+mask+bytes(v^mask[i%4] for i,v in enumerate(data)))
def frame(s):
    a,b=exact(s,2);n=b&127
    if n==126:n=struct.unpack('!H',exact(s,2))[0]
    if n==127:n=struct.unpack('!Q',exact(s,8))[0]
    assert n<=8192;return a&15,exact(s,n)

def auth_and_security(p):
    anon=Client(p);alice=Client(p);bob=Client(p);at=alice.login('alice');bt=bob.login('bob')
    auth={}
    auth['anonymous']=anon.get('/gov/objects')[0];auth['fakeHeader']=anon.get('/gov/objects',{'X-User':'alice','X-Username':'alice'})[0]
    auth['aliceList']=json.loads(alice.get('/gov/objects')[2]);auth['bobList']=json.loads(bob.get('/gov/objects')[2])
    auth['aliceOwn']=alice.get('/gov/objects/1')[0];auth['aliceOther']=alice.get('/gov/objects/2')[0]
    tamper=Client(p);tamper.cookies=dict(alice.cookies);name=next(k for k in tamper.cookies if 'SESSION' in k);v=tamper.cookies[name];tamper.cookies[name]=v[:v.rfind('.')+1]+('x' if v[v.rfind('.')+1]!='x' else 'y')+v[v.rfind('.')+2:]
    auth['tamperedCookie']=tamper.get('/gov/objects')[0]
    assert auth=={'anonymous':401,'fakeHeader':401,'aliceList':[1],'bobList':[2],'aliceOwn':200,'aliceOther':403,'tamperedCookie':401},auth
    security={}
    security['missingToken']=alice.post('/gov/objects/1',SENTINEL)[0]
    security['wrongToken']=alice.post('/gov/objects/1',headers={'Csrf-Token':'wrong'})[0]
    security['oldBypassHeader']=alice.post('/gov/objects/1',headers={'X-Play-Lab':'synthetic'})[0]
    security['correctToken']=alice.post('/gov/objects/1',SENTINEL,{'Csrf-Token':at})[0]
    security['formBodyToken']=alice.post('/gov/objects/1',urllib.parse.urlencode({'csrfToken':at,'sensitive':SENTINEL}))[0]
    assert security['formBodyToken']==200
    security['otherObject']=alice.post('/gov/objects/2',headers={'Csrf-Token':at})[0]
    assert [security[k] for k in ('missingToken','wrongToken','oldBypassHeader','correctToken','otherObject')]==[403,403,403,200,403],security
    for name,origin in [('trusted','http://trusted.example'),('untrusted','http://evil.example')]:
        st,h,_=anon.call('OPTIONS','/gov/objects/1',headers={'Origin':origin,'Access-Control-Request-Method':'POST','Access-Control-Request-Headers':'Content-Type'})
        security[name+'Preflight']={'status':st,'headers':h}
    assert security['trustedPreflight']['status']==200
    assert security['trustedPreflight']['headers']['access-control-allow-origin']=='http://trusted.example'
    assert security['trustedPreflight']['headers']['access-control-allow-credentials']=='true'
    assert security['untrustedPreflight']['status']==403
    security['trustedOriginNoToken']=alice.post('/gov/objects/1',headers={'Origin':'http://trusted.example'})[0]
    assert security['trustedOriginNoToken']==200
    security['hostRejected']=anon.get('/gov/connection',{'Host':'evil.example'})[0];assert security['hostRejected']==400
    st,h,b=anon.get('/gov/connection',{'X-Forwarded-For':'203.0.113.50','X-Forwarded-Proto':'https'})
    security['untrustedForwarded']=json.loads(b);assert json.loads(b)=={'remote':'127.0.0.1','secure':False}
    security['headers']={k:h[k] for k in ('x-frame-options','x-content-type-options','referrer-policy')};assert h['x-frame-options']=='DENY' and h['x-content-type-options']=='nosniff'
    security['cookieNames']=list(alice.cookies);assert 'PLAY_SESSION' in alice.cookies
    security['cookieAttributes']=alice.cookieFlags
    assert alice.cookieFlags['PLAY_SESSION']['httponly'] and alice.cookieFlags['PLAY_SESSION']['samesite'].lower()=='lax'
    auth['bobOwn']=bob.get('/gov/objects/2')[0];auth['bobOther']=bob.get('/gov/objects/1')[0]
    auth['bobOwnUpdate']=bob.post('/gov/objects/2',headers={'Csrf-Token':bt})[0]
    auth['bobOtherUpdate']=bob.post('/gov/objects/1',headers={'Csrf-Token':bt})[0]
    assert [auth[k] for k in ('bobOwn','bobOther','bobOwnUpdate','bobOtherUpdate')]==[200,403,200,403]
    auth['crossSse']=[alice.get('/gov/events/2?track=cross-alice')[0],bob.get('/gov/events/1?track=cross-bob')[0]]
    assert auth['crossSse']==[403,403]
    s,status=ws(bob,1,'cross-bob');s.close();assert status==403
    auth['crossWs']=status
    auth['updatesBeforeRevocation']=json.loads(anon.get('/gov/policy')[2])['updates'];assert auth['updatesBeforeRevocation']==4
    # SSE uses alice; revoke while response remains connected, then wait for failure.
    c=http.client.HTTPConnection('127.0.0.1',p,timeout=6)
    try:
        c.request('GET','/gov/events/1?track=revoked-sse',headers={'Cookie':alice.header()});r=c.getresponse();assert r.status==200
        events=[]
        for _ in range(16):
            line=r.readline()
            if line.startswith(b'data:'):events.append(line.decode().strip());break
        assert len(events)==1
        assert alice.post('/gov/revoke',headers={'Csrf-Token':at})[0]==200
        failure=None
        try:r.read()
        except (http.client.IncompleteRead,ConnectionResetError) as e:failure=type(e).__name__
        assert failure
        auth['sseRevocation']={'first':events,'readError':failure,'terminal':wait_record(anon,'revoked-sse','subscription_terminal')}
    finally:c.close()
    assert alice.get('/gov/objects/1')[0]==403
    assert alice.post('/gov/objects/1',headers={'Csrf-Token':at})[0]==403
    for client,id,wanted in ((anon,1,401),(alice,2,403)):
        s,st=ws(client,id,'denied');s.close();assert st==wanted
    s,st=ws(bob,2,'revoked-ws')
    try:
        assert st==101;sendframe(s,'before');opcode,data=frame(s);assert (opcode,data)==(1,b'object-2:before')
        assert bob.post('/gov/revoke',headers={'Csrf-Token':bt})[0]==200
        sendframe(s,'after');opcode,data=frame(s);assert opcode==8,(opcode,data)
        auth['wsRevocation']={'closeCode':struct.unpack('!H',data[:2])[0],'terminal':wait_record(anon,'revoked-ws','subscription_terminal')}
    finally:s.close()
    assert json.loads(anon.get('/gov/policy')[2])['updates']==4
    REPORT['authorization']=auth;REPORT['securityDefault']=security

def observations(p):
    c=Client(p)
    def decide(i):
        amount=(1,100,0,101)[i%4]
        st,_,b=Client(p).post('/gov/observe/decision',json.dumps({'amount':amount}),{'Content-Type':'application/json','X-Gov-Id':'concurrent-'+str(i)})
        assert st==(200 if amount in (1,100) else 400)
        return {'id':'concurrent-'+str(i),'amount':amount,'status':st,'body':json.loads(b)}
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(decide,range(12),timeout=20))
    st,_,_=c.post('/gov/observe/decision','{',{'Content-Type':'application/json','X-Gov-Id':'parser-failure'});assert st==400
    parser=wait_record(c,'parser-failure','stream_terminal');assert not any(e['phase']=='business_result' for e in parser['events'])
    st,_,_=c.get('/gov/observe/timeout',{'X-Gov-Id':'deadline'});assert st==504
    deadline=wait_record(c,'deadline','business_result');assert deadline['events'][-1]=={'phase':'business_result','outcome':'completed_after_deadline'}
    conn=http.client.HTTPConnection('127.0.0.1',p,timeout=6)
    try:
        conn.request('GET','/gov/observe/stream',headers={'X-Gov-Id':'tcp-cancel'});r=conn.getresponse();assert r.status==200
        got=r.read(16384);assert len(got)==16384;r.close();conn.close()
    finally:conn.close()
    cancelled=wait_record(c,'tcp-cancel','stream_terminal')
    assert 0<cancelled['producedChunks']<2048,cancelled
    def overload(i):
        status=Client(p).get('/gov/observe/timeout',{'X-Gov-Id':'overload-'+str(i)})[0]
        assert status in (503,504);return status
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:overload_status=list(pool.map(overload,range(32),timeout=20))
    assert 503 in overload_status and 504 in overload_status,overload_status
    for i in range(32):wait_record(c,'overload-'+str(i),'business_result')
    snapshot=json.loads(c.get('/gov/observations')[2]);assert len(snapshot['metrics'])<20
    assert snapshot['workSlotsAvailable']==16 and snapshot['evictions']==0,snapshot
    REPORT['boundedTimerWork']={'statuses':overload_status,'slotsRestored':snapshot['workSlotsAvailable']}
    assert all('concurrent' not in k and 'tcp-cancel' not in k for k in snapshot['metrics'])
    for row in rows:wait_record(c,row['id'],'stream_terminal')
    REPORT['observations']={'concurrent':rows,'parseFailure':parser,'deadline':deadline,'tcpCancel':cancelled,'snapshot':snapshot,'cancelReceivedBytes':len(got)}

def strict_security(p):
    c=Client(p);token=c.login('alice')
    missing=c.post('/gov/objects/1',headers={'Origin':'http://trusted.example'})[0]
    valid=c.post('/gov/objects/1',headers={'Origin':'http://trusted.example','Csrf-Token':token})[0]
    assert (missing,valid)==(403,200),(missing,valid)
    REPORT['strictCsrf']={'trustedOriginMissing':missing,'trustedOriginValid':valid}

def proxy_test(p):
    class Proxy(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_GET(self):
            # Drop incoming forwarding claims, emit a fixed synthetic client and exact localhost hop.
            status,headers,body=Client(p).get('/gov/connection',{'X-Forwarded-For':'203.0.113.9','X-Forwarded-Proto':'https'})
            self.send_response(status);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    proxy=HTTPServer(('127.0.0.1',0),Proxy);thread=threading.Thread(target=proxy.serve_forever);thread.start()
    try:
        st,_,body=Client(proxy.server_port).get('/test',{'X-Forwarded-For':'198.51.100.88'});observed=json.loads(body)
        assert st==200 and observed=={'remote':'203.0.113.9','secure':True},observed
        direct=json.loads(Client(p).get('/gov/connection',{'X-Forwarded-For':'198.51.100.88, 203.0.113.9','X-Forwarded-Proto':'https'})[2])
        assert direct['remote']=='203.0.113.9',direct
        REPORT['trustedProxy']={'throughProxy':observed,'rightmostUntrustedStopsScan':direct,'boundary':'Every local process is inside the trusted 127.0.0.1 boundary; backend must not be exposed to untrusted local clients.'}
    finally:proxy.shutdown();proxy.server_close();thread.join(timeout=3);assert not thread.is_alive()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--evidence',required=True);args=ap.parse_args();out=pathlib.Path(args.evidence).resolve();out.mkdir(parents=True,exist_ok=True)
    try:
        with server(out,'default') as p:auth_and_security(p);observations(p)
        with server(out,'strict',['-Dplay.filters.csrf.bypassCorsTrustedOrigins=false']) as p:strict_security(p)
        with server(out,'proxy',['-Dconfig.resource=governance-proxy.conf']) as p:proxy_test(p)
        raw=(out/'default.log').read_text()
        for i in range(12):
            for phase in ('request_started','business_result','result_ready','stream_terminal'):
                assert f'gov_event id=concurrent-{i} phase={phase} ' in raw
        REPORT['logCorrelation']={'requests':12,'phasesPerRequest':4,'matched':48}
        REPORT['status']='PASS';print('PASS authorization security observations test-layers proxy')
    except BaseException:
        REPORT['status']='FAIL';REPORT['error']=traceback.format_exc();raise
    finally:(out/'observations.json').write_text(json.dumps(REPORT,indent=2)+'\n')
if __name__=='__main__':main()
