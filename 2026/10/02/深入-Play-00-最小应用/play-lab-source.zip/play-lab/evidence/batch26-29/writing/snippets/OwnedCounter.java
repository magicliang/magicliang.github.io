public final class OwnedCounter {
    private final String owner;
    private boolean revoked;
    private int changes;

    public OwnedCounter(String owner) {
        this.owner = java.util.Objects.requireNonNull(owner);
    }

    public synchronized boolean update(String principal) {
        if (revoked || !owner.equals(principal)) {
            return false;
        }
        changes++;
        return true;
    }

    public synchronized void revoke() {
        revoked = true;
    }

    public synchronized int changes() {
        return changes;
    }

    public static void main(String[] args) {
        OwnedCounter counter = new OwnedCounter("alice");
        if (counter.update("bob") || !counter.update("alice")) {
            throw new AssertionError("object policy");
        }
        counter.revoke();
        if (counter.update("alice") || counter.changes() != 1) {
            throw new AssertionError("revocation or mutation count");
        }
        System.out.println("PASS owner/revoke/mutation");
    }
}
