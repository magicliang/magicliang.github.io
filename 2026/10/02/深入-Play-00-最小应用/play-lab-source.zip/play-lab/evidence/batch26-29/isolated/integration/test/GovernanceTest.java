import static org.junit.Assert.*;
import static play.test.Helpers.*;
import org.junit.Test;
import play.Application;
import play.inject.guice.GuiceApplicationBuilder;
import authlab.ObjectPolicy;
import observabilitylab.RequestEvents;
import java.util.List;
public class GovernanceTest {
    @Test public void purePolicy() {
        assertTrue(ObjectPolicy.amountAllowed(1));assertTrue(ObjectPolicy.amountAllowed(100));
        assertFalse(ObjectPolicy.amountAllowed(0));assertFalse(ObjectPolicy.amountAllowed(101));
        ObjectPolicy p=new ObjectPolicy();assertFalse(p.update("alice",2));assertTrue(p.update("alice",1));
        p.revoke("alice");assertFalse(p.allowed("alice",1));assertEquals(1,p.snapshot().get("updates").asInt());
    }
    @Test public void routeUsesParserAndFilter() {
        Application app=new GuiceApplicationBuilder().configure("play.filters.enabled",List.of("observabilitylab.ObservationFilter")).build();
        running(app,()->{
            for(int amount:new int[]{1,100,0,101}) {
                var r=route(app,fakeRequest(POST,"/gov/observe/decision").header("X-Gov-Id","route-"+amount).bodyJson(play.libs.Json.newObject().put("amount",amount)));
                assertEquals(ObjectPolicy.amountAllowed(amount)?200:400,r.status());contentAsString(r,app.injector().instanceOf(org.apache.pekko.stream.Materializer.class));
            }
            var bad=route(app,fakeRequest(POST,"/gov/observe/decision").header("X-Gov-Id","parse").bodyText("{").header("Content-Type","application/json"));
            assertEquals(400,bad.status());contentAsString(bad,app.injector().instanceOf(org.apache.pekko.stream.Materializer.class));
            var json=app.injector().instanceOf(RequestEvents.class).snapshot();
            assertTrue(json.get("records").has("parse"));
            assertFalse(json.get("records").get("parse").toString().contains("business_result"));
            assertEquals(404,route(app,fakeRequest(GET,"/gov/login?user=alice")).status());
            assertEquals(401,route(app,fakeRequest(GET,"/gov/objects").header("X-User","alice")).status());
            assertEquals("[1]",contentAsString(route(app,fakeRequest(GET,"/gov/objects").session("username","alice"))));
        });
    }
    @Test public void ledgerBounded() {
        RequestEvents e=new RequestEvents();for(int i=0;i<300;i++)e.event("id"+i,"result_ready","success");
        assertEquals(128,e.snapshot().get("records").size());assertEquals(172,e.snapshot().get("evictions").asInt());assertEquals(1,e.snapshot().get("metrics").size());
    }
}
