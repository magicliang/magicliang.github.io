# Add-only integration

Copy exactly the10 addFiles in integration-manifest.json after checking destination absence and SHA256. Append its routes.append (14 routes) once. Do not copy build.sbt, application.conf, existing routes wholesale, baseline controllers/tests, target, staged libs, or generated files. The three new conf files are isolated test-process configurations. Normal application.conf remains owned by parent.

No new dependency. The implementation imports existing Play/Pekko/Guice/SLF4J/JUnit. The Python runner uses only the standard library and reads JAVA_HOME. All source/test/runner copies are identical to the frozen isolated files used by test-stage-final3.log and run-final3.
