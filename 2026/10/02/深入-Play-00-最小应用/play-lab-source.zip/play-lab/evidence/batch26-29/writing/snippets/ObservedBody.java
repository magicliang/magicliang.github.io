import java.util.Optional;
import java.util.function.Consumer;
import org.apache.pekko.stream.javadsl.Source;
import org.apache.pekko.util.ByteString;
import play.http.HttpEntity;

public final class ObservedBody {
    private ObservedBody() {}

    public static HttpEntity create(
            Source<ByteString, ?> source,
            Optional<Long> contentLength,
            String contentType,
            Consumer<String> terminal) {
        Source<ByteString, ?> observed = source.watchTermination((materialized, done) -> {
            done.whenComplete((value, failure) -> terminal.accept(
                failure == null ? "completed_or_cancelled" : "failed"));
            return materialized;
        });
        return new HttpEntity.Streamed(observed, contentLength, Optional.of(contentType));
    }
}
