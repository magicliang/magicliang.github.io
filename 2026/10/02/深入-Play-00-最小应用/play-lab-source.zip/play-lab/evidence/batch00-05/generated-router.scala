// @GENERATOR:play-routes-compiler
// @SOURCE:conf/routes

package router

import play.core.routing._
import play.core.routing.HandlerInvokerFactory._

import play.api.mvc._

import _root_.controllers.Assets.Asset
import _root_.play.libs.F

class Routes(
  override val errorHandler: play.api.http.HttpErrorHandler, 
  // @LINE:1
  LabController_0: controllers.LabController,
  val prefix: String
) extends GeneratedRouter {

  @javax.inject.Inject()
  def this(errorHandler: play.api.http.HttpErrorHandler,
    // @LINE:1
    LabController_0: controllers.LabController
  ) = this(errorHandler, LabController_0, "/")

  def withPrefix(addPrefix: String): Routes = {
    val prefix = play.api.routing.Router.concatPrefix(addPrefix, this.prefix)
    router.RoutesPrefix.setPrefix(prefix)
    new Routes(errorHandler, LabController_0, prefix)
  }

  private val defaultPrefix: String = {
    if (this.prefix.endsWith("/")) "" else "/"
  }

  def documentation = List(
    ("""GET""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """health""", """controllers.LabController.health()"""),
    ("""GET""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """trace""", """controllers.LabController.trace(id:String)"""),
    ("""GET""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """orders/""" + "$" + """id<[^/]+>""", """controllers.LabController.order(id:Long, verbose:Boolean ?= false)"""),
    ("""GET""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """reverse""", """controllers.LabController.reverse(id:Long)"""),
    ("""POST""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """orders""", """controllers.LabController.create(request:Request)"""),
    ("""GET""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """fail""", """controllers.LabController.fail()"""),
    ("""GET""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """async-fail""", """controllers.LabController.asyncFail()"""),
    ("""GET""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """session/set""", """controllers.LabController.setSession(request:Request, name:String)"""),
    ("""GET""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """session/read""", """controllers.LabController.readSession(request:Request)"""),
    ("""GET""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """flash/set""", """controllers.LabController.setFlash(request:Request)"""),
    ("""GET""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """flash/read""", """controllers.LabController.readFlash(request:Request)"""),
    ("""GET""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """shape/""" + "$" + """kind<[^/]+>""", """controllers.LabController.shape(kind:String)"""),
    ("""GET""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """scope""", """controllers.LabController.scope()"""),
    ("""GET""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """config""", """controllers.LabController.config()"""),
    ("""GET""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """template""", """controllers.LabController.template(name:String ?= "Play")"""),
    ("""GET""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """stream""", """controllers.LabController.stream()"""),
    Nil
  ).foldLeft(Seq.empty[(String, String, String)]) { (s,e) => e.asInstanceOf[Any] match {
    case r @ (_,_,_) => s :+ r.asInstanceOf[(String, String, String)]
    case l => s ++ l.asInstanceOf[List[(String, String, String)]]
  }}


  // @LINE:1
  private lazy val controllers_LabController_health0_route = Route("GET",
    PathPattern(List(StaticPart(this.prefix), StaticPart(this.defaultPrefix), StaticPart("health")))
  )
  private lazy val controllers_LabController_health0_invoker = createInvoker(
    LabController_0.health(),
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      "router",
      "controllers.LabController",
      "health",
      Nil,
      "GET",
      this.prefix + """health""",
      """""",
      Seq()
    )
  )

  // @LINE:2
  private lazy val controllers_LabController_trace1_route = Route("GET",
    PathPattern(List(StaticPart(this.prefix), StaticPart(this.defaultPrefix), StaticPart("trace")))
  )
  private lazy val controllers_LabController_trace1_invoker = createInvoker(
    LabController_0.trace(fakeValue[String]),
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      "router",
      "controllers.LabController",
      "trace",
      Seq(classOf[String]),
      "GET",
      this.prefix + """trace""",
      """""",
      Seq()
    )
  )

  // @LINE:3
  private lazy val controllers_LabController_order2_route = Route("GET",
    PathPattern(List(StaticPart(this.prefix), StaticPart(this.defaultPrefix), StaticPart("orders/"), DynamicPart("id", """[^/]+""", encodeable=true)))
  )
  private lazy val controllers_LabController_order2_invoker = createInvoker(
    LabController_0.order(fakeValue[Long], fakeValue[Boolean]),
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      "router",
      "controllers.LabController",
      "order",
      Seq(classOf[Long], classOf[Boolean]),
      "GET",
      this.prefix + """orders/""" + "$" + """id<[^/]+>""",
      """""",
      Seq()
    )
  )

  // @LINE:4
  private lazy val controllers_LabController_reverse3_route = Route("GET",
    PathPattern(List(StaticPart(this.prefix), StaticPart(this.defaultPrefix), StaticPart("reverse")))
  )
  private lazy val controllers_LabController_reverse3_invoker = createInvoker(
    LabController_0.reverse(fakeValue[Long]),
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      "router",
      "controllers.LabController",
      "reverse",
      Seq(classOf[Long]),
      "GET",
      this.prefix + """reverse""",
      """""",
      Seq()
    )
  )

  // @LINE:5
  private lazy val controllers_LabController_create4_route = Route("POST",
    PathPattern(List(StaticPart(this.prefix), StaticPart(this.defaultPrefix), StaticPart("orders")))
  )
  private lazy val controllers_LabController_create4_invoker = createInvoker(
    
    (req:play.mvc.Http.Request) =>
      LabController_0.create(fakeValue[play.mvc.Http.Request]),
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      "router",
      "controllers.LabController",
      "create",
      Seq(classOf[play.mvc.Http.Request]),
      "POST",
      this.prefix + """orders""",
      """""",
      Seq()
    )
  )

  // @LINE:6
  private lazy val controllers_LabController_fail5_route = Route("GET",
    PathPattern(List(StaticPart(this.prefix), StaticPart(this.defaultPrefix), StaticPart("fail")))
  )
  private lazy val controllers_LabController_fail5_invoker = createInvoker(
    LabController_0.fail(),
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      "router",
      "controllers.LabController",
      "fail",
      Nil,
      "GET",
      this.prefix + """fail""",
      """""",
      Seq()
    )
  )

  // @LINE:7
  private lazy val controllers_LabController_asyncFail6_route = Route("GET",
    PathPattern(List(StaticPart(this.prefix), StaticPart(this.defaultPrefix), StaticPart("async-fail")))
  )
  private lazy val controllers_LabController_asyncFail6_invoker = createInvoker(
    LabController_0.asyncFail(),
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      "router",
      "controllers.LabController",
      "asyncFail",
      Nil,
      "GET",
      this.prefix + """async-fail""",
      """""",
      Seq()
    )
  )

  // @LINE:8
  private lazy val controllers_LabController_setSession7_route = Route("GET",
    PathPattern(List(StaticPart(this.prefix), StaticPart(this.defaultPrefix), StaticPart("session/set")))
  )
  private lazy val controllers_LabController_setSession7_invoker = createInvoker(
    
    (req:play.mvc.Http.Request) =>
      LabController_0.setSession(fakeValue[play.mvc.Http.Request], fakeValue[String]),
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      "router",
      "controllers.LabController",
      "setSession",
      Seq(classOf[play.mvc.Http.Request], classOf[String]),
      "GET",
      this.prefix + """session/set""",
      """""",
      Seq()
    )
  )

  // @LINE:9
  private lazy val controllers_LabController_readSession8_route = Route("GET",
    PathPattern(List(StaticPart(this.prefix), StaticPart(this.defaultPrefix), StaticPart("session/read")))
  )
  private lazy val controllers_LabController_readSession8_invoker = createInvoker(
    
    (req:play.mvc.Http.Request) =>
      LabController_0.readSession(fakeValue[play.mvc.Http.Request]),
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      "router",
      "controllers.LabController",
      "readSession",
      Seq(classOf[play.mvc.Http.Request]),
      "GET",
      this.prefix + """session/read""",
      """""",
      Seq()
    )
  )

  // @LINE:10
  private lazy val controllers_LabController_setFlash9_route = Route("GET",
    PathPattern(List(StaticPart(this.prefix), StaticPart(this.defaultPrefix), StaticPart("flash/set")))
  )
  private lazy val controllers_LabController_setFlash9_invoker = createInvoker(
    
    (req:play.mvc.Http.Request) =>
      LabController_0.setFlash(fakeValue[play.mvc.Http.Request]),
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      "router",
      "controllers.LabController",
      "setFlash",
      Seq(classOf[play.mvc.Http.Request]),
      "GET",
      this.prefix + """flash/set""",
      """""",
      Seq()
    )
  )

  // @LINE:11
  private lazy val controllers_LabController_readFlash10_route = Route("GET",
    PathPattern(List(StaticPart(this.prefix), StaticPart(this.defaultPrefix), StaticPart("flash/read")))
  )
  private lazy val controllers_LabController_readFlash10_invoker = createInvoker(
    
    (req:play.mvc.Http.Request) =>
      LabController_0.readFlash(fakeValue[play.mvc.Http.Request]),
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      "router",
      "controllers.LabController",
      "readFlash",
      Seq(classOf[play.mvc.Http.Request]),
      "GET",
      this.prefix + """flash/read""",
      """""",
      Seq()
    )
  )

  // @LINE:12
  private lazy val controllers_LabController_shape11_route = Route("GET",
    PathPattern(List(StaticPart(this.prefix), StaticPart(this.defaultPrefix), StaticPart("shape/"), DynamicPart("kind", """[^/]+""", encodeable=true)))
  )
  private lazy val controllers_LabController_shape11_invoker = createInvoker(
    LabController_0.shape(fakeValue[String]),
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      "router",
      "controllers.LabController",
      "shape",
      Seq(classOf[String]),
      "GET",
      this.prefix + """shape/""" + "$" + """kind<[^/]+>""",
      """""",
      Seq()
    )
  )

  // @LINE:13
  private lazy val controllers_LabController_scope12_route = Route("GET",
    PathPattern(List(StaticPart(this.prefix), StaticPart(this.defaultPrefix), StaticPart("scope")))
  )
  private lazy val controllers_LabController_scope12_invoker = createInvoker(
    LabController_0.scope(),
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      "router",
      "controllers.LabController",
      "scope",
      Nil,
      "GET",
      this.prefix + """scope""",
      """""",
      Seq()
    )
  )

  // @LINE:14
  private lazy val controllers_LabController_config13_route = Route("GET",
    PathPattern(List(StaticPart(this.prefix), StaticPart(this.defaultPrefix), StaticPart("config")))
  )
  private lazy val controllers_LabController_config13_invoker = createInvoker(
    LabController_0.config(),
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      "router",
      "controllers.LabController",
      "config",
      Nil,
      "GET",
      this.prefix + """config""",
      """""",
      Seq()
    )
  )

  // @LINE:15
  private lazy val controllers_LabController_template14_route = Route("GET",
    PathPattern(List(StaticPart(this.prefix), StaticPart(this.defaultPrefix), StaticPart("template")))
  )
  private lazy val controllers_LabController_template14_invoker = createInvoker(
    LabController_0.template(fakeValue[String]),
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      "router",
      "controllers.LabController",
      "template",
      Seq(classOf[String]),
      "GET",
      this.prefix + """template""",
      """""",
      Seq()
    )
  )

  // @LINE:16
  private lazy val controllers_LabController_stream15_route = Route("GET",
    PathPattern(List(StaticPart(this.prefix), StaticPart(this.defaultPrefix), StaticPart("stream")))
  )
  private lazy val controllers_LabController_stream15_invoker = createInvoker(
    LabController_0.stream(),
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      "router",
      "controllers.LabController",
      "stream",
      Nil,
      "GET",
      this.prefix + """stream""",
      """""",
      Seq()
    )
  )


  def routes: PartialFunction[RequestHeader, Handler] = {
  
    // @LINE:1
    case controllers_LabController_health0_route(params@_) =>
      call { 
        controllers_LabController_health0_invoker.call(LabController_0.health())
      }
  
    // @LINE:2
    case controllers_LabController_trace1_route(params@_) =>
      call(params.fromQuery[String]("id", None)) { (id) =>
        controllers_LabController_trace1_invoker.call(LabController_0.trace(id))
      }
  
    // @LINE:3
    case controllers_LabController_order2_route(params@_) =>
      call(params.fromPath[Long]("id", None), params.fromQuery[Boolean]("verbose", Some(false))) { (id, verbose) =>
        controllers_LabController_order2_invoker.call(LabController_0.order(id, verbose))
      }
  
    // @LINE:4
    case controllers_LabController_reverse3_route(params@_) =>
      call(params.fromQuery[Long]("id", None)) { (id) =>
        controllers_LabController_reverse3_invoker.call(LabController_0.reverse(id))
      }
  
    // @LINE:5
    case controllers_LabController_create4_route(params@_) =>
      call { 
        controllers_LabController_create4_invoker.call(
          req => LabController_0.create(req))
      }
  
    // @LINE:6
    case controllers_LabController_fail5_route(params@_) =>
      call { 
        controllers_LabController_fail5_invoker.call(LabController_0.fail())
      }
  
    // @LINE:7
    case controllers_LabController_asyncFail6_route(params@_) =>
      call { 
        controllers_LabController_asyncFail6_invoker.call(LabController_0.asyncFail())
      }
  
    // @LINE:8
    case controllers_LabController_setSession7_route(params@_) =>
      call(params.fromQuery[String]("name", None)) { (name) =>
        controllers_LabController_setSession7_invoker.call(
          req => LabController_0.setSession(req, name))
      }
  
    // @LINE:9
    case controllers_LabController_readSession8_route(params@_) =>
      call { 
        controllers_LabController_readSession8_invoker.call(
          req => LabController_0.readSession(req))
      }
  
    // @LINE:10
    case controllers_LabController_setFlash9_route(params@_) =>
      call { 
        controllers_LabController_setFlash9_invoker.call(
          req => LabController_0.setFlash(req))
      }
  
    // @LINE:11
    case controllers_LabController_readFlash10_route(params@_) =>
      call { 
        controllers_LabController_readFlash10_invoker.call(
          req => LabController_0.readFlash(req))
      }
  
    // @LINE:12
    case controllers_LabController_shape11_route(params@_) =>
      call(params.fromPath[String]("kind", None)) { (kind) =>
        controllers_LabController_shape11_invoker.call(LabController_0.shape(kind))
      }
  
    // @LINE:13
    case controllers_LabController_scope12_route(params@_) =>
      call { 
        controllers_LabController_scope12_invoker.call(LabController_0.scope())
      }
  
    // @LINE:14
    case controllers_LabController_config13_route(params@_) =>
      call { 
        controllers_LabController_config13_invoker.call(LabController_0.config())
      }
  
    // @LINE:15
    case controllers_LabController_template14_route(params@_) =>
      call(params.fromQuery[String]("name", Some("Play"))) { (name) =>
        controllers_LabController_template14_invoker.call(LabController_0.template(name))
      }
  
    // @LINE:16
    case controllers_LabController_stream15_route(params@_) =>
      call { 
        controllers_LabController_stream15_invoker.call(LabController_0.stream())
      }
  }
}
