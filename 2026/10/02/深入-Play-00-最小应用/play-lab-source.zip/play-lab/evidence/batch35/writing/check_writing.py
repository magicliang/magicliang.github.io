#!/usr/bin/env python3
"""Read-only source article receipts; no site/browser or network claim."""
from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as ET
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[4]
hash=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pub=json.loads((HERE/'publication-receipt.json').read_text());post=ROOT/pub['path'];cover=ROOT/pub['cover'];text=post.read_text()
assert hash(post)==pub['sha256'] and hash(cover)==pub['coverSha256']
assert 'date: 2026-10-03 17:35:00' in text
assert '/2026/10/03/深入-Play-35-可验证的订单与订阅服务/cover.svg' in text
assert '../../02/深入-Play-00-最小应用/' in text
assert (ROOT/'source/_posts/2026-10-02-深入-Play-00-最小应用.md').is_file()
assert not re.search(r'\]\([^)]*深入-Play-(34|E01)',text)
assert all(marker not in text for marker in ['/private/tmp/','.omo/','@SNIPPET@'])
assert text.count('```mermaid')>=3 and '2e56aff7d4e7a74af61e4bd39ec9e3ed7f300cd6' in text
assert 'examples/play-lab/evidence/batch35/isolated/' in text
assert '改动练习一' in text and '改动练习二' in text and '尚未覆盖的故障' in text
assert (HERE/'snippets/CommitThenNotify.java').read_text().rstrip() in text
assert 'EXIT 0' in (HERE/'snippet-compile.log').read_text()
assert 'PASS committed identity retained; failed transaction skipped notification' in (HERE/'snippet-run.log').read_text()
tone=json.loads((HERE/'35-anti-ai-tone.json').read_text());persona=json.loads((HERE/'35-anti-persona-fabrication.json').read_text())
assert tone['errors']==tone['warnings']==0 and persona['order']==2 and persona['status']=='PASS' and persona['draftSha256']==pub['sha256']
xml=ET.parse(cover).getroot();ns={'s':'http://www.w3.org/2000/svg'};assert xml.get('viewBox')=='0 0 1200 480';assert xml.find('s:title',ns) is not None and xml.find('s:desc',ns) is not None
for node in xml.findall('.//s:text',ns):assert float(node.get('y','0'))<=255
for node in xml.findall('.//s:rect',ns):
 if node.get('height')=='480':continue
 assert 165<=float(node.get('y')) and float(node.get('y'))+float(node.get('height'))<=255
result={'status':'PASS','articleSha256':pub['sha256'],'coverSha256':pub['coverSha256'],'mechanismDiagrams':text.count('```mermaid'),'orderedScans':'PASS','javaCompiledAndRan':True,'svgParsed':True,'bottomHeroClear':True,'navigation':'00 resolved; 34/E01 intentionally text','notClaimed':['Hexo generation','Mermaid browser rendering','browser visual review','shared regression suite','commit','push']}
(HERE/'navigation-svg-receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
