# Play 35 隔离结课工程验收

状态：ISOLATED_VERIFIED_NOT_SHARED_INTEGRATED。只交 7 个新增文件、11 条追加 routes；不要覆盖隔离副本里的 build.sbt、application.conf 或任何累计基线。精确集成入口 integration-manifest.json。数据库依赖沿用 22–25 的 DbAccess，治理观测沿用 RequestEvents，Python HTTP 客户端沿用 governance_checks.Client。TransactionLab 的幂等事务算法和 ManagedDatabaseJob 的有界排空顺序被适配到自己的 capstone_* schema；没有调用它们固定 lab_* 表及故意失败的演示 stop hook。

## 重跑

隔离根 /private/tmp/play-capstone-work-20261003。配置 JAVA_HOME 为 JDK 21，使用 sbtw 或现有 sbt 1.10.7 launcher。

```sh
bash sbtw 'testOnly CapstoneTest' stage
python3 lab/capstone_checks.py --out evidence/batch35/replay --container play-db-lab-20261003-pipeline-43 --pg-port 35711
```

脚本要求 out 不存在。公共 PostgreSQL 容器必须预先存在；脚本仅 CREATE/DROP 自身随机 capstone_* schema，不创建或停止数据库容器。脚本启动两个自己的 staged 进程和一个 loopback 慢下游，最后关闭这些自有资源。运行时随机 secret 只注入环境，日志与 246 个 stage 文件扫描未发现其字面量。capstone.conf 显式开启公开合成登录、调试观测、DDL fixture；这是 Prod 运行模式的实验配置，不是可直接发布的生产认证方案。默认应用未开启 capstone 功能。

## 场景、二元判据与产物

| 场景及实际调用 | 二元判据 | 原始产物 |
|---|---|---|
| testOnly CapstoneTest + stage | 2 tests, 0 failures/errors/skips；stage 成功 | build3.log、TEST-CapstoneTest.xml |
| matrix：匿名/伪造头/更改真实签名 | 全部401；缺CSRF/旧bypass全部403；客户端tenant字段400 | run-final/http.json、observations.httpMatrix |
| matrix：alice、bob、跨tenant的alice | 只列自己的对象；对方detail/cancel/SSE/CSV全403；自有读取与真实流200 | http.json、httpMatrix.objects |
| 同key并发4次与已有key冲突 | 同UUID一CREATED三REPLAY；4次不同payload全部409；库存只扣2 | httpMatrix.concurrentCreate/conflicts、sql.json、database.same-key |
| 全新key混合payload并发 | 2×200、2×409；成功方一CREATED一REPLAY，同UUID | httpMatrix.mixedPayloadRace、sql.json |
| 库存不足/取消并发 | 6次qty3成功、第7次409且订单占位回滚；取消一CANCELLED一REPLAY_CANCEL，库存恒等式成立 | insufficientStockRollback、concurrentCancel、database快照、sql.json |
| SSE状态更新/真实关闭/撤权 | 原连接观察CREATED→CANCELLED；closeCount1；撤权后连接错误和Denied；6种后续操作403 | statusSubscription、objects.*_sse、revocation、first.log |
| 流容量 | 同时4条原连接，第5条503；4条真实关闭后许可证恢复 | streamCapacity、first-journal.jsonl |
| CSV下载取消 | Content-Length24641555，客户端仅读16384后真实关闭，closeCount1且临时目录空 | downloadCancel、first-journal.jsonl |
| 固定127.0.0.1慢WS | 本机下游真实entered，120ms预算BUDGET_FAILED；先记录事务返回，独立SQL查到订单 | slowDownstream、downstream.json、sql.json、first-journal.jsonl |
| 重启持久性 | 新进程、新签名secret，订单与撤权状态保持 | restart、database.restart、second.log |
| SIGTERM时在途SQL | 独立pg_stat_activity为PgSleep；gate inFlight1，内部提交拒绝；原HTTP200，SQL一行提交 | sigterm、sql.json、second-journal.jsonl |
| 退出资源 | 两个exit143；file/pool/client/executor true，inFlight0，filesLeft0，streamPermits4，无cleanupFailure | processes、两份journal |

HTTP 原始响应不保留 Cookie 与 CSRF token；记录状态/普通头/订单body。CSV/SSE的大体积数据只保留实际读取字节数、事件及终态。stage-manifest.json 逐文件 SHA；artifacts 保存实际应用、assets、inventory-core jar 与启动脚本/专项配置。source-receipt.json 对四个本地上游源码文件逐字节对照官方 raw URL 固定完整 SHA。源码压缩包不是 Git checkout，该事实也记录在收据中。

## 实验边界及未覆盖故障

- 不声明全局 exactly-once：数据库唯一键约束只控制当前 tenant+subject+key 的本地事务。notifySlow 不属于payload，重放也可能再通知；没有 outbox、持久重试或通知幂等。
- JDBC异常回滚由同步 withTransaction 作用域控制。没有把 CompletionStage 放入 transaction block，连接不会跨异步通知复用。
- SSE是有限20次/5秒的状态轮询，每次重新查询权限。它没有持久事件历史/Last-Event-ID，无法证明每次中间状态都交付。已经授权并进入下游缓冲的事件存在撤权竞争窗口。
- CSV copies=524288 是明确压力fixture：同一授权行重复生成约24.6MB，用于真实取消，不代表数据库有524288个订单。sendPath/FileIO完成回调表示源资源释放，不表示客户端收到全部字节。
- 正常SIGTERM有1个在途2000ms SQL；不是队列全部满载、网络分区或强杀保证。新网络连接实际ConnectionRefusedError；503仅为应用提交门关闭的可能响应，未在该网络样本观察到。
- NOT_RUN：SIGKILL、DB崩溃/commit确认丢失、多实例竞争、故障转移、磁盘满/删除权限故障、HTTP/2/TLS、通知可靠投递、SSE重放、executor满队列关机、长周期内存/性能。
- 未运行共享累计suite；2个是本次针对性JUnit，不能与历史基线计数相加冒充当前全量结果。

## 保留的修正与失败

build1.log 保存 addingToSession 不支持四个字符串参数的编译失败；改为 Map 后 build2 通过。run1 显示 terminationTimeout12秒高于 requests-done 默认5秒警告；capstone.conf 将两个期限显式设为12秒，build3 与 run2/run-final 无该警告。run1、run2 保留作为历史有限样本，最终验收引用 run-final。
