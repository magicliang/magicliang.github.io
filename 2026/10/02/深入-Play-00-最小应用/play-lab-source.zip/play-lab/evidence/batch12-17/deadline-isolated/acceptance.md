# Play WS total-deadline experiment

VERIFIED_LOCAL: isolated application at `/private/tmp/play-deadline-work-20261003`; 32 JUnit tests passed, 0 failures/errors/skips, and stage completed with exit 0. The WS experiment made real HTTP requests to controlled loopback servers. Shared source, articles and Git state were not modified by this slice.

## Invocation

`JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn PLAY_LAB_SBT_LAUNCHER=/private/tmp/play-series-tools/sbt-launch-1.10.7.jar bash /private/tmp/play-deadline-work-20261003/sbtw test stage > .omo/evidence/play-deadline-20261003/test-stage.log 2>&1`

The first sandboxed launch could not write the existing sbt boot lock. `sandbox-launch-failure.log` preserves that failure. The same command then ran with tool-approved escalation for the sbt cache and loopback sockets; it exited 0. No user installation or unrelated source change was needed.

## Scenario, observable and artifact

All runtime scenarios execute in `BudgetTest.realLoopbackWsShowsCompletionTimeoutAndRedirectBoundaries` under the invocation above. Artifacts below are relative to this directory.

| Scenario | Binary observable | Artifact |
| --- | --- | --- |
| Already exhausted monotonic deadline | DEADLINE_EXHAUSTED; requestsSent=0; requestTimeoutMillis=[]; handler delta=0 | `observations.json`, `TEST-BudgetTest.xml`, `test-stage.log` |
| First redirect fits, second handler remains gated past total budget | First status302; 2 requests; TIMEOUT/TimeoutException; secondEnteredBeforeOutcome=true, secondReleasedBeforeOutcome=false, secondDoneBeforeOutcome=false | Same three artifacts |
| Per-hop request timeout uses remaining total budget | Short scenario configured [999,841] ms, equal to min(3000, remaining) for each hop; second timeout strictly smaller | `observations.json`, assertions in `BudgetTest.patch` |
| Two controlled hops fit sufficient total budget | 2 requests; statuses[302,200]; body deadline-ok; positive remainingNanosAtTerminal | `observations.json`, `TEST-BudgetTest.xml` |
| Task and resource termination | Four new gated handlers done; original+new handlers started=finished=11; clientClosed, serverWorkersTerminated, deadlineCallerTerminated, deadlineTimerTerminated all true | `observations.json`, `test-stage.log` |
| Cumulative compilation and regression | 32 tests, zero failures/errors/skips; stage exit0 | `test-stage.log`, all five `TEST-*.xml`, `manifest.json` |
| Packaged implementation matches compiled code | WsBoundaryLab.class and nested DeadlineGate.class bytes equal corresponding stage-jar entries | `stage-verification.json` |

The 1000ms scenario was observed after 1089ms in this run. The client timeout is scheduled, not a hard wall-clock upper bound; no assertion requires exact millisecond timing. Latches establish ordering. After the timeout observation, the second handler is explicitly released and this run records completed. A later socket write may instead reveal an IOException; the test requires a terminal value and cleanup, not a fixed network-write outcome.

## Exact integration manifest

Only two source files are delivered:

- `app/labbudget/WsBoundaryLab.java`: new three-scenario deadline observation; `fetchAllowedUntil` preserves fixed allowlist, disabled automatic redirects and three-hop limit. It recomputes monotonic remaining time before each request, rejects expired/sub-millisecond budget rather than configuring zero, uses min(cap,remaining), and checks deadline again before accepting a response. Existing finite handlers and client are reused.
- `test/BudgetTest.java`: assertions for new fields, event order, terminal states, request counts and positive shrinking request budgets. No new testcase replaces or weakens prior assertions.

`manifest.json` records shared base and implemented SHA-256 for both files. Apply `WsBoundaryLab.patch` and `BudgetTest.patch`, or integrate only those corresponding files from the isolated directory. `async_checks-deadline.patch` is an un-applied suggestion for the parent HTTP matrix; its Python syntax and assertion body were checked against this run's JSON. It changes expected handlers from7 to11 and adds deadline assertions.

`LabSupport.java` interrupt preservation and the expanded `AsyncTest.java` match shared SHA-256 values. Shared `CacheLab.java` gained a narrower exception catch after this copy; the parent explicitly owns that integration. Do not copy the isolated CacheLab or the entire directory over the shared application. The parent will run the final shared clean test/stage and HTTP matrix.

## Evidence boundary

This proves real outbound WS loopback behavior in the isolated Play application and staged-byte identity. It does not establish an externally started shared production GET endpoint, DNS rebinding defense, distributed cancellation or a strict real-time deadline. No article, README, STATUS, shared source, commit or push was changed by this slice.
