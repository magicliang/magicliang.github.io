# Play deadline and interrupted cleanup repair

Scope: isolated application at /private/tmp/play-deadline-work-20261003. No shared source, article, Git, or deployment mutation in this slice. Parent integrates seven files listed with exact source/destination and SHA-256 in manifest.json. CacheLab was refreshed from the shared baseline and must not be integrated back.

## Executed validation

All invocations ran from the isolated application with JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn and PLAY_LAB_SBT_LAUNCHER=/private/tmp/play-series-tools/sbt-launch-1.10.7.jar.

| Scenario | Invocation | Binary observable | Artifact |
| --- | --- | --- | --- |
| Focused actual WS and executor cleanup | bash ./sbtw 'testOnly BudgetTest AsyncTest' | 15 passed, zero failures, exit 0 | targeted.log; targeted-observations.json |
| One-second total deadline across two allowed hops | bash ./sbtw clean test stage | Exactly two requests, first status 302, TIMEOUT while second entered but neither released nor done; independent 1350 ms timer subsequently releases second and handler terminates | test-stage.log; observations.json BUDGET/ws.boundaries.deadline.exceededAcrossHops; TEST-BudgetTest.xml |
| Already exhausted and adequate budget | same final invocation | Exhausted sends zero; adequate sends two and returns body deadline-ok with statuses 302,200 | observations.json BUDGET/ws.boundaries.deadline |
| Interrupted WS coordinator after second entered | same final invocation | IllegalStateException caused by InterruptedException, interrupt restored; 9 started/9 finished handlers; client closed; server/caller/timer pools terminated; both listening sockets reject reconnects in assertions | observations.json BUDGET/ws-interrupted; TEST-BudgetTest.xml interruptedCoordinatorClosesEveryWsResource |
| Interrupted coordinator with two real executor workers | same final invocation | Both tasks done, both pools terminated, interrupt restored, coordinator joins | observations.json ASYNC/interrupted-cleanup; TEST-AsyncTest.xml interruptedCleanupTerminatesBothExecutors |
| Fixed per-hop 3000 ms negative mutation | bash ./sbtw 'testOnly BudgetTest' | Exit 1; one failing test: expected TIMEOUT but DEADLINE_EXHAUSTED; receives 302,200 after independent release | mutation-fixed-3000.log; mutation-fixed-3000-observations.json; mutation-TEST-BudgetTest.xml |
| Restored full cumulative application | bash ./sbtw clean test stage | Exit 0; 34 tests, zero failed/error/skipped; stage completed | test-stage.log; five TEST-*.xml; stage-verification.json |

The mutation changed only timeoutMillis from Math.min(3000, remainingMillis) to 3000. Existing post-response deadline validation remained, so the WS transport successfully received 200 but the application rejected its expired result. The mutation was restored before the final clean test stage. Exact commands, exit codes, and hashes are in manifest.json.

Timing values are samples, not timing guarantees: the final normal run sampled 999/845 ms request timeouts, TIMEOUT after 1085 ms, and second release 1350 ms after entry. Assertions use gated ordering and terminal states, with bounded waits for hung-test protection; they do not require exact elapsed milliseconds.

## Implementation and evidence boundaries

WsBoundaryLab owns the client, two HTTP servers, server workers, and WsDeadlineLab. Its try-with-resources preserves the body exception. Cleanup attempts every owned resource, retains the first cleanup exception with subsequent exceptions suppressed, temporarily clears interruption for bounded cleanup, and restores interruption. The large-body gate is released before shutdown. WsDeadlineLab independently releases its gates and uses try-with-resources to attempt both executor closes.

LabSupport.closeAll is restricted to executor groups. CompositionLab's two paired cleanups and ContextLab's paired cleanup now use it. It attempts every pool, retains failures rather than swallowing them, and restores interruption. Existing single-pool close and get interruption behavior remain unchanged.

WsBoundaryLab has 191 nonblank/noncomment lines and WsDeadlineLab 165; both are below 250. The isolated editor LSP did not resolve the sbt Play classpath; the authoritative clean compilation, actual socket tests, and packaged class hashes are captured above. Stage proves packaging only; parent owns shared production-mode HTTP verification.
