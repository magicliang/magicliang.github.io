import java.nio.file.Path;
import java.util.UUID;

public final class UploadDestination {
    public static Path create(Path directory, String originalName) {
        if (!originalName.matches("[A-Za-z0-9][A-Za-z0-9._-]{0,63}")
                || originalName.contains("..")) {
            throw new IllegalArgumentException("invalid filename metadata");
        }
        return directory.resolve(UUID.randomUUID().toString());
    }
}
