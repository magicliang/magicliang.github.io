# Play 18–21 isolated experiment handoff

Result: VERIFIED_LOCAL. Source remains in `/private/tmp/play-stream-work-20261003`; no shared application files, articles, plans, stage directories, or Git state changed by this worker. Exact add-only integration is in `integration-manifest.json` and `integration/`. Merge only the nine new `/streamlab/` route lines; do not replace the shared routes file. No dependency or application.conf changes.

## Fresh final evidence

- `test-stage-final-io.log`: `sbtw clean test stage`, 36 JUnit tests, 0 failures. Six XML files in `junit/` contain 31 cumulative and 5 new tests. Earlier incremental sbt runs discovered only the changed StreamLabTest; they are not cumulative proof.
- `socket-final-io.log` and `run-final-io/observations.json`: five complete groups, PASS, server exited 143 after controlled SIGTERM. The script owns the staged server and local proxy and shuts both down in finally.
- `acceptance.json`: each exact scenario, invocation, binary observable, captured artifact and JSON location. `evidence-check.json` verifies nonempty artifacts, staged file SHA-256 and 36 XML test cases.
- `play-tag.txt`, `pekko-tag.txt`: independently fetched remote refs. Play 3.0.6 peeled commit `2e56aff7d4e7a74af61e4bd39ec9e3ed7f300cd6`; Pekko 1.0.3 peeled commit `4f77c8108aaf548a65531d2c8807da13dbba8146`. `play-source-excerpts.txt` was read directly from the supplied Play archive checkout. Pekko source jar from Maven Central and extracted Java DSL Source/Flow/FileIO source are retained; upstream suites were NOT_RUN.

## Endpoint contract

| Route | Bound / behavior |
| --- | --- |
| GET /streamlab/data?id=...&chunks=2048&known=false&failAt=-1 | 1..2048 chunks; each 16 KiB allocated on demand; optional known content length or deterministic source failure. |
| GET /streamlab/state?id=... | Bounded 128-record ledger; active records are not evicted. It records produced chunks/bytes, materialization, termination, failure, close count, upload FileIO starts/completions and ordinary-work stage. |
| GET /streamlab/work?id=... | Synthetic 750 ms scheduler-backed ordinary CompletionStage; client disconnect does not automatically cancel its original future. |
| GET /streamlab/sse?id=... | Fixed retained events 101..120, two data lines each, interspersed comment heartbeat, maximum 20 events / 10 seconds; Last-Event-ID=100 starts log, <100 is 410, >120/invalid is 400, 120 is 204. mode=fail aborts after 3 events. |
| GET /streamlab/ws?id=...&token=synthetic-token | Exact Origin http://localhost:19018; authentication and Origin rejection happen before allocating the flow/ledger. At most 20 messages, 4096 Java UTF-16 code units per assembled text message, four-element fail-on-overflow queue, ten-second completion deadline. |
| POST /streamlab/upload?id=... | Explicit multipart total limit 65536 bytes; allowEmptyFiles=true lets controller explicitly reject empty uploads. Custom per-request parser tracks and cleans FileIO temporary paths even before controller execution. Exactly one file, safe restricted metadata name, server UUID destination. |
| GET /streamlab/files / DELETE /streamlab/files/:uuid | Directory snapshot / delete only one UUID named saved test file. |
| GET /streamlab/download?id=... | Generate finite 32 MiB file with reusable 16 KiB write block; sendPath streams it. Its FileIO completion callback deletes temporary file and increments close count, including cancellation. |

## Observed distinctions that the articles must preserve

1. Under this HTTP/1.1 Pekko server, known Streamed length produces Content-Length; unknown Streamed length produces Connection: close with neither CL nor TE. SSE uses explicit chunked. Do not equate unknown length with automatic chunked framing. A failure after HTTP 200 headers aborts the body; it does not send a second 500 status.
2. Paused real sockets stopped upstream production before the finite 32 MiB maximum. Cancellation completed the ledger once. This does not prove all buffers in every server/kernel/proxy are bounded by the application's inputBuffer. RSS was sampled 237 times, baseline 227648 KiB and peak 240544 KiB in the final run; this is a process sample, not constant-memory proof.
3. Application stopping a materialized SSE stream was independently tested and produced AbruptStageTerminationException with closeCount=1. Stream termination and ordinary CompletionStage cancellation are distinct: the latter completed its one synthetic work unit after TCP disconnect, with futureCancelled=false.
4. The local Python proxy compares immediate forwarding against a maximum 64 KiB buffer with a 2-second flush condition. It is not evidence for nginx or any deployed proxy. All retained SSE data is a fixed bounded synthetic log; its replay guarantee does not cover events beyond IDs101..120. Comment heartbeats in this example are interspersed with finite events, not an independently ticking idle heartbeat service.
5. WebSocket frame and application assembled-message limits are separate. In this exact backend, aggregateFrames checks its buffer limit on FrameData, whereas a complete FrameStart passes directly. A 65537-byte frame sent in 8192-byte writes produced close1009; a single send of the same frame reached the application 4096-character check in the recorded sample, with ledger IllegalArgumentException and close1000. Network segmentation can change that sample; do not claim the 64k config alone covers every path. Two 3000-character fragments also fail the application assembled-message check. A sequential 20-message case closes normally, while a 21-message burst observed BufferOverflowException / close1011. The slow-reader case did not prove queue overflow because kernel buffering can absorb its finite payload.
6. Multipart Content-Length overlimit allocated no file sink; chunked overlimit did allocate and complete one. The interrupted upload had a visible temporary file before TCP close, then fileIoStarted=fileIoClosed=1 and restored directory snapshot. Download resource-release evidence is sendPath's attached IO completion callback, not merely disappearance of a filename.

Out of scope / NOT_RUN: HTTP/2, external proxy products, Netty backend, production database cursor/transaction resources, production auth, unbounded-duration load, formal constant-memory proof, upstream Play/Pekko full test suites. No article/build/publication acceptance is claimed here.
