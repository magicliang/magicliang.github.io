import java.util.Optional;
import java.util.concurrent.CompletionStage;
import java.util.function.Consumer;
import org.apache.pekko.Done;
import org.apache.pekko.stream.Attributes;
import org.apache.pekko.stream.javadsl.Source;
import org.apache.pekko.util.ByteString;
import play.http.HttpEntity;

public final class FiniteExport {
    public static HttpEntity create(
            int chunks, boolean known,
            Consumer<CompletionStage<Done>> onMaterialized) {
        if (chunks < 1 || chunks > 2048) {
            throw new IllegalArgumentException("chunks must be 1..2048");
        }
        Source<ByteString, ?> data = Source.range(0, chunks - 1)
            .map(index -> {
                byte[] block = new byte[16384];
                java.util.Arrays.fill(block, (byte) ('a' + index % 26));
                return ByteString.fromArray(block);
            })
            .withAttributes(Attributes.inputBuffer(1, 1))
            .watchTermination((materialized, done) -> {
                onMaterialized.accept(done);
                return materialized;
            });
        return new HttpEntity.Streamed(
            data, known ? Optional.of(chunks * 16384L) : Optional.empty(),
            Optional.of("application/octet-stream"));
    }
}
