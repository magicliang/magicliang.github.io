import java.time.Duration;
import java.util.function.BiConsumer;
import org.apache.pekko.Done;
import org.apache.pekko.stream.Attributes;
import org.apache.pekko.stream.OverflowStrategy;
import org.apache.pekko.stream.javadsl.Flow;

public final class BoundedEcho {
    public static Flow<String, String, ?> create(
            BiConsumer<Done, Throwable> onTermination) {
        return Flow.of(String.class)
            .take(20)
            .map(text -> {
                if (text.length() > 4096) {
                    throw new IllegalArgumentException("message too long");
                }
                return "echo:" + text;
            })
            .buffer(4, OverflowStrategy.fail())
            .withAttributes(Attributes.inputBuffer(1, 1))
            .completionTimeout(Duration.ofSeconds(10))
            .watchTermination((materialized, done) -> {
                done.whenComplete(onTermination);
                return materialized;
            });
    }
}
