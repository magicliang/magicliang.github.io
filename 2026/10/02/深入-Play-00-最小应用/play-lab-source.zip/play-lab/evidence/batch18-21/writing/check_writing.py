#!/usr/bin/env python3
"""Validate the four assigned articles without generating or modifying public/ output."""
from pathlib import Path
import hashlib,json,posixpath,re,xml.etree.ElementTree as ET
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
SLUGS={18:'HTTP流式响应',19:'SSE与慢客户端',20:'WebSocket生命周期',21:'上传下载与临时文件'}
receipts=json.loads((HERE/'publication-receipt.json').read_text())
known=set()
for post in (ROOT/'source/_posts').glob('*.md'):
 m=re.match(r'(\d{4})-(\d{2})-(\d{2})-(.+)\.md$',post.name)
 if m:known.add('/'+'/'.join(m.groups())+'/')
checks=[]
for n,slug in SLUGS.items():
 stem=f'2026-10-03-深入-Play-{n}-{slug}';p=ROOT/'source/_posts'/f'{stem}.md';s=p.read_text()
 receipt=next(r for r in receipts if r['post'].endswith(p.name))
 assert hashlib.sha256(p.read_bytes()).hexdigest()==receipt['sha256']
 assert f'date: 2026-10-03 17:{n}:00' in s
 assert f'cover: /2026/10/03/深入-Play-{n}-{slug}/cover.svg' in s
 assert '/private/tmp/' not in s and '.omo/' not in s
 assert s.count('```')%2==0
 base=f'/2026/10/03/深入-Play-{n}-{slug}/'
 links=[]
 for target in re.findall(r'\]\(([^)]+)\)',s):
  if target.startswith('http'):continue
  if target=='cover.svg':assert(p.with_suffix('')/target).is_file();continue
  route=posixpath.normpath(posixpath.join(base,target))+'/'
  assert route in known,(p,target,route)
  links.append(route)
 assert '/2026/10/02/深入-Play-00-最小应用/' in links
 assert not re.search(r'\]\([^)]*Play-22',s) if n==21 else True
 svg=p.with_suffix('')/'cover.svg';tree=ET.parse(svg);ns='{http://www.w3.org/2000/svg}'
 assert tree.getroot().attrib['viewBox']=='0 0 1200 480'
 assert tree.find(ns+'title') is not None and tree.find(ns+'desc')is not None
 assert all(float(el.attrib['y'])<=255 for el in tree.iter(ns+'text'))
 tone=json.loads((HERE/f'{n}-anti-ai-tone.json').read_text());persona=json.loads((HERE/f'{n}-anti-persona-fabrication.json').read_text())
 assert tone['errors']==tone['warnings']==0 and persona['result']=='PASS'
 assert persona['draftSha256']==receipt['sha256']
 checks.append({'post':str(p.relative_to(ROOT)),'bodyLines':len(s.splitlines()),'navigation':links,'svgParse':'PASS','heroClearance':'PASS','orderedScanDigest':'MATCH','javaSnippetCompile':'PASS','privatePathLeak':False})
assert 'exit=0' in (HERE/'snippet-compile.log').read_text()
report={'status':'PASS','checks':checks,'notClaimed':['Hexo build','browser rendering','shared lab test run','production deployment']}
(HERE/'navigation-svg-receipt.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
