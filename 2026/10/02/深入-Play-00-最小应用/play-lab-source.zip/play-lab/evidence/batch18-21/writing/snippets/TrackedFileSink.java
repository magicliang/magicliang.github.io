import java.nio.file.Path;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.pekko.stream.IOResult;
import org.apache.pekko.stream.javadsl.FileIO;
import org.apache.pekko.stream.javadsl.Sink;
import org.apache.pekko.util.ByteString;

public final class TrackedFileSink {
    public static Sink<ByteString, CompletionStage<IOResult>> create(
            Path path, AtomicInteger started, AtomicInteger closed) {
        return FileIO.toPath(path).mapMaterializedValue(done -> {
            started.incrementAndGet();
            return done.whenComplete((result, failure) -> {
                closed.incrementAndGet();
            });
        });
    }
}
