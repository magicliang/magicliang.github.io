import java.time.Duration;
import org.apache.pekko.stream.javadsl.Source;
import org.apache.pekko.util.ByteString;
import play.libs.EventSource;
import play.mvc.Result;
import play.mvc.Results;

public final class FiniteSse {
    public static Result events() {
        Source<ByteString, ?> body = Source.range(101, 120)
            .throttle(1, Duration.ofMillis(450))
            .map(id -> EventSource.Event
                .event("line-one-" + id + "\nline-two-" + id)
                .withId(Integer.toString(id))
                .withName("sample"))
            .via(EventSource.flow())
            .intersperse(ByteString.fromString(": heartbeat\n\n"))
            .takeWithin(Duration.ofSeconds(10));
        return Results.ok().chunked(body)
            .as("text/event-stream")
            .withHeader("Cache-Control", "no-cache");
    }
}
