#!/usr/bin/env python3
import argparse
import base64
import concurrent.futures
import http.client
import json
import os
from pathlib import Path
import secrets
import shutil
import socket
import subprocess
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence/batch00-05"


def http_checks(development=False, extra_checks=None, evidence=None):
    evidence = evidence or EVIDENCE
    evidence.mkdir(parents=True, exist_ok=True)
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    env = dict(os.environ, APPLICATION_SECRET=secrets.token_hex(32))
    prefix = "dev" if development else "http"
    log_path = evidence / ("development.log" if development else "production.log")
    observations = []

    def request(path, method="GET", body=None, headers=None):
        connection = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
        start = time.monotonic()
        try:
            connection.request(method, path, body, {"X-Play-Lab": "synthetic", **(headers or {})})
            response = connection.getresponse()
            head = time.monotonic() - start
            data = response.read()
            record = dict(path=path, method=method, status=response.status,
                          headers=response.getheaders(), body=data.decode(),
                          headers_seconds=head, total_seconds=time.monotonic() - start)
            observations.append(record)
            return record
        finally:
            connection.close()

    def check(path, status=200, **kwargs):
        result = request(path, **kwargs)
        assert result["status"] == status, result
        return result

    with log_path.open("w") as output:
        command = [str(ROOT / "target/universal/stage/bin/play-lab"),
                   "-Dhttp.address=127.0.0.1", f"-Dhttp.port={port}", "-Dlab.stock=13"]
        if development:
            env["PLAY_LAB_JVM_ARGS"] = f"-Dhttp.address=127.0.0.1 -Dhttp.port={port} -Dlab.stock=13"
            command = ["bash", str(ROOT / "sbtw"), "run"]
        process = subprocess.Popen(command, cwd=ROOT, env=env,
                                   stdout=output, stderr=subprocess.STDOUT)
        try:
            deadline = time.monotonic() + 90
            while True:
                if process.poll() is not None:
                    raise RuntimeError(f"Server exited {process.returncode}; see {log_path}")
                try:
                    health = check("/health")
                    break
                except (OSError, http.client.HTTPException):
                    if time.monotonic() >= deadline:
                        raise
                    time.sleep(.1)
            assert health["body"] == "play-lab-ok"
            assert check("/config")["body"] == "13"
            traces = [("health", "/health", "GET", None, 200, ["filter-enter", "result-available-200"]),
                      ("missing", "/missing", "GET", None, 404, ["filter-enter", "result-available-404"]),
                      ("binding", "/orders/no", "GET", None, 400, ["filter-enter", "result-available-400"]),
                      ("parser", "/orders", "POST", "{", 400, ["filter-enter", "result-available-400"]),
                      ("sync", "/fail", "GET", None, 500, ["filter-enter", "stage-failed"]),
                      ("async", "/async-fail", "GET", None, 500, ["filter-enter", "stage-failed"])]
            for ident, path, method, body, status, events in traces:
                check(path, status, method=method, body=body,
                      headers={"X-Lab-Id": ident, "Content-Type": "application/json"})
                assert json.loads(check(f"/trace?id={ident}")["body"]) == [f"{ident}:{event}" for event in events]
            for path, status in [("/missing", 404), ("/orders/no", 400),
                                 ("/orders/42?verbose=no", 400), ("/reverse", 400),
                                 ("/reverse?id=no", 400), ("/fail", 500),
                                 ("/async-fail", 500), ("/shape/empty", 204)]:
                check(path, status)
            check("/health", 404, method="POST")
            assert check("/health", method="HEAD")["body"] == ""
            duplicate = check("/orders/42?verbose=true&verbose=false")
            assert json.loads(duplicate["body"])["verbose"] is True
            assert json.loads(check("/orders/%34%32")["body"])["id"] == 42
            url = check("/reverse?id=42")["body"]
            assert url == "/orders/42"
            assert json.loads(check(url)["body"]) == {"id": 42, "verbose": False, "stock": 13}
            for body, content_type, status in [("{\"id\":42}", "application/json", 201),
                                               ("{", "application/json", 400),
                                               ("{}", "text/plain", 415),
                                               (json.dumps({"v": "x" * 2048}), "application/json", 413)]:
                check("/orders", status, method="POST", body=body,
                      headers={"Content-Type": content_type})
            session = check("/session/set?name=Ada")
            raw_cookie = next(v for k, v in session["headers"]
                              if k.lower() == "set-cookie" and v.startswith("PLAY_SESSION="))
            assert "httponly" in raw_cookie.lower() and "samesite=lax" in raw_cookie.lower(), raw_cookie
            cookie = raw_cookie.split(";", 1)[0]
            assert check("/session/read", headers={"Cookie": cookie})["body"] == "Ada"
            token = cookie.split("=", 1)[1]
            parts = token.split(".")
            assert len(parts) == 3
            payload = json.loads(base64.urlsafe_b64decode(parts[1] + "=" * (-len(parts[1]) % 4)))
            assert "Ada" in json.dumps(payload)
            parts[2] = ("A" if parts[2][0] != "A" else "B") + parts[2][1:]
            assert check("/session/read", headers={"Cookie": "PLAY_SESSION=" + ".".join(parts)})["body"] == "absent"
            flash = check("/flash/set", 303)
            flash_cookie = next(v.split(";", 1)[0] for k, v in flash["headers"]
                                if k.lower() == "set-cookie" and v.startswith("PLAY_FLASH="))
            first = check("/flash/read", headers={"Cookie": flash_cookie})
            assert first["body"] == "saved"
            assert any("PLAY_FLASH=" in v and "Max-Age=0" in v
                       for k, v in first["headers"] if k.lower() == "set-cookie")
            assert check("/flash/read")["body"] == "absent"
            assert check("/flash/read", headers={"Cookie": flash_cookie})["body"] == "saved"
            stream = check("/stream")
            assert stream["body"] == "one\ntwo\nthree\n"
            assert ("X-Lab-Result", "available") in stream["headers"]
            assert stream["total_seconds"] - stream["headers_seconds"] >= .15, stream
            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
                scopes = list(pool.map(lambda _: json.loads(check("/scope")["body"]), range(16)))
            assert len({v["controller"] for v in scopes}) == 1
            assert len({v["service"] for v in scopes}) == 1
            summary = dict(result="PASS", requests=len(observations), session_payload=payload,
                           concurrent_requests=16, unique_controllers=1, unique_services=1,
                           stream_headers_seconds=stream["headers_seconds"],
                           stream_total_seconds=stream["total_seconds"])
            if extra_checks is not None:
                summary.update(extra_checks(check))
                summary["requests"] = len(observations)
        finally:
            process.terminate()
            try:
                process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
            observations_path = evidence / f"{prefix}-observations.json"
            observations_path.write_text(json.dumps(observations, ensure_ascii=False, indent=2) + "\n")
    summary["server_exit_code"] = process.returncode
    (evidence / f"{prefix}-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({key: value for key, value in summary.items() if key != "pipeline_cases"}))


def negative_compiles():
    cases = {
        "route-type": ("conf/routes", "id: Long, verbose:", "id: String, verbose:"),
        "template-type": ("app/views/greeting.scala.html", "@(name: String)", "@(name: Int)"),
        "missing-module": ("build.sbt", ".dependsOn(inventoryCore)", ""),
    }
    results = []
    for name, (relative, before, after) in cases.items():
        with tempfile.TemporaryDirectory(prefix=f"play-{name}-") as temp:
            fixture = Path(temp) / "play-lab"
            shutil.copytree(ROOT, fixture, ignore=shutil.ignore_patterns(
                "target", ".tools", ".bsp", ".metals", "evidence", "RUNNING_PID"))
            path = fixture / relative
            original = path.read_text()
            assert before in original
            path.write_text(original.replace(before, after, 1))
            with (EVIDENCE / f"negative-{name}.log").open("w") as output:
                run = subprocess.run(["bash", str(fixture / "sbtw"), "compile"],
                                     stdout=output, stderr=subprocess.STDOUT, timeout=180)
            assert run.returncode != 0, name
            detail = (EVIDENCE / f"negative-{name}.log").read_text()
            assert "[error]" in detail and ("javac returned non-zero" in detail or "Compilation failed" in detail), detail
            results.append(dict(case=name, exit_code=run.returncode, result="EXPECTED_COMPILE_FAILURE"))
    (EVIDENCE / "negative-summary.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--negative", action="store_true")
    parser.add_argument("--dev", action="store_true")
    args = parser.parse_args()
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    negative_compiles() if args.negative else http_checks(args.dev)
