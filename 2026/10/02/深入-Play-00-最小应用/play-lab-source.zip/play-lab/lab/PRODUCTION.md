# Production artifact experiment

Requires JDK 21 through `JAVA_HOME`, the pinned sbt launcher described in the root README, and an already running disposable local PostgreSQL 17 fixture. The fixture uses database `play_lab`, user `postgres`, and synthetic password `lab-only-password`; never use a production database. `podman` must be on PATH.

From the application directory:

```bash
python3 lab/production_build.py --log evidence/batch30/build.log
python3 lab/production_checks.py --evidence evidence/batch30/run --container "$PLAY_LAB_CONTAINER" --jdbc-url "$PLAY_LAB_JDBC_URL"
```

The helper creates its own random `prod_*` schema, starts four owned processes, and deletes only that schema at the end. It preserves the container. It sends SIGTERM to three owned processes and SIGKILL to one transaction-owning process. The evidence directory must not exist; `target/production-unpacked` must not exist. Archive earlier evidence before running another clean build.

`conf/production.conf` adds disabled-by-default lab configuration without changing the ordinary application profile. `/production/*` exposes unauthenticated synthetic diagnostics and management on loopback for this experiment only. The helper supplies random per-process secrets, fixed two-thread/two-slot JDBC work, and separate PID paths. It proves stage/dist byte equality, actual class origin, explicit config precedence, finite proxy streaming, in-flight graceful commit, killed uncommitted rollback, and same-artifact recovery. No cloud deployment, TLS, OOM, partition, or disk-full claim is made.
