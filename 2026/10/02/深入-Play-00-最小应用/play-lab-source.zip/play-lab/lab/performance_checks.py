#!/usr/bin/env python3
import argparse
import collections
import concurrent.futures
import hashlib
import http.client
import json
import math
import os
from pathlib import Path
import socket
import subprocess
import threading
import time
import traceback
import urllib.parse


def quantiles(values):
    ordered = sorted(values)
    return {name: ordered[max(0, math.ceil(p * len(ordered)) - 1)] if ordered else None
            for name, p in [('p50', .50), ('p95', .95), ('p99', .99)]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage-dir', type=Path, default=Path(__file__).resolve().parents[1] / 'target/universal/stage')
    parser.add_argument('--evidence', required=True, type=Path)
    args = parser.parse_args()
    args.evidence.mkdir(parents=True, exist_ok=False)
    if not os.environ.get('JAVA_HOME') or not os.environ.get('PLAY_LAB_JDBC_URL'):
        raise RuntimeError('Set JAVA_HOME to JDK 21 and PLAY_LAB_JDBC_URL to the synthetic PostgreSQL fixture')
    with socket.socket() as candidate:
        candidate.bind(('127.0.0.1', 0))
        port = candidate.getsockname()[1]
    stage = args.stage_dir.resolve()
    command = [str(stage / 'bin/play-lab'), '-J-Xms256m', '-J-Xmx768m', '-Dhttp.address=127.0.0.1',
               '-Dpekko.actor.default-dispatcher.fork-join-executor.parallelism-min=2',
               '-Dpekko.actor.default-dispatcher.fork-join-executor.parallelism-max=2',
               f'-Dhttp.port={port}', f'-Dpidfile.path={args.evidence.resolve() / "server.pid"}']
    env = dict(os.environ, PLAY_LAB_DB_ENABLED='true')
    report = {'status': 'RUNNING', 'command': command, 'port': port, 'rounds': [],
              'method': {'roundsPerCell': 3, 'jdbcRequests': 40, 'payloadRequests': 24,
                         'concurrency': [1, 8], 'warmupRequestsPerCell': 8,
                         'quantile': 'nearest-rank: sorted[ceil(p*N)-1], includes all statuses; no interpolation',
                         'client': 'finite closed-loop workers; one new HTTP connection per request; full body read',
                         'coordinatedOmission': 'closed-loop stalls reduce arrivals; this is not open-loop capacity or a production ranking',
                         'instrumentation': 'all modes record task events and health probes; no per-request server logging; logging-disabled cost comparison NOT_RUN',
                         'clock': 'client perf_counter_ns for HTTP, server System.nanoTime for SQL; never subtract across clocks',
                         'gcScope': 'whole JVM between snapshots, includes health and framework work',
                         'allocationScope': 'JDBC worker task or payload construction only; excludes full request allocation'}}
    raw = open(args.evidence / 'requests.jsonl', 'w')
    lock = threading.Lock()

    def save_report():
        (args.evidence / 'observations.json').write_text(json.dumps(report, indent=2))

    def request(path, fields=None, tag=None):
        path += ('?' + urllib.parse.urlencode(fields)) if fields else ''
        start = time.perf_counter_ns()
        row = {'tag': tag, 'path': path, 'startedNanos': start}
        connection = http.client.HTTPConnection('127.0.0.1', port, timeout=4)
        try:
            connection.request('GET', path, headers={'X-Play-Lab': 'synthetic'})
            response = connection.getresponse()
            row['headersNanos'] = time.perf_counter_ns()
            body = response.read(1024 * 1024 + 1)
            assert len(body) <= 1024 * 1024, 'response limit'
            row.update(status=response.status, bytes=len(body), sha256=hashlib.sha256(body).hexdigest(),
                       contentLength=response.getheader('Content-Length'), transferEncoding=response.getheader('Transfer-Encoding'))
            if 'application/json' in response.getheader('Content-Type', ''):
                row['body'] = json.loads(body)
            elif len(body) < 4096:
                row['bodyText'] = body.decode('utf-8', 'replace')
        except (OSError, http.client.HTTPException) as error:
            row.update(status=0, error=type(error).__name__ + ': ' + str(error))
        finally:
            row['endedNanos'] = time.perf_counter_ns()
            row['seconds'] = (row['endedNanos'] - start) / 1e9
            connection.close()
            with lock:
                raw.write(json.dumps(row) + '\n')
                raw.flush()
        return row

    def api(path, fields=None):
        row = request(path, fields, 'control')
        assert row['status'] == 200, row
        return row['body']

    def drain(path):
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline:
            if path == '/perf/state':
                progress = api('/perf/progress')
                if progress['pending'] == 0 and progress['allTerminal']:
                    return api(path)
                time.sleep(.05)
                continue
            state = api(path)
            if state['pending'] == 0 and all(t.get('done', 'outcome' in t) for t in state['tasks']):
                return state
            time.sleep(.02)
        raise AssertionError('tasks not drained')

    def burst(path, run, count, concurrency, acknowledge=False):
        barrier = threading.Barrier(concurrency + 1, timeout=5)
        health_stop = threading.Event()
        health = []
        def probe():
            while not health_stop.is_set() and len(health) < 400:
                health.append(request('/health', tag=run + ':health'))
                health_stop.wait(.04)
        def task(index):
            if index < concurrency:
                barrier.wait()
            row = request(path, {'run': run, 'id': index}, run)
            if acknowledge and row['status'] == 504:
                row['ack'] = api('/perf/ack', {'run': run, 'id': index})
            return row
        probe_thread = threading.Thread(target=probe, name='finite-health-probe')
        probe_thread.start()
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as workers:
                futures = [workers.submit(task, index) for index in range(count)]
                barrier.wait()
                rows = [future.result(timeout=20) for future in futures]
        finally:
            health_stop.set()
            probe_thread.join(timeout=5)
            assert not probe_thread.is_alive(), 'health probe did not terminate'
        return rows, health

    def summarize(rows, health):
        seconds = (max(r['endedNanos'] for r in rows) - min(r['startedNanos'] for r in rows)) / 1e9
        return {'statuses': dict(collections.Counter(str(r['status']) for r in rows)), 'httpSeconds': seconds,
                'clientErrors': sum(r['status'] == 0 for r in rows),
                'http500': sum(r['status'] == 500 for r in rows),
                'http503': sum(r['status'] == 503 for r in rows),
                'http504': sum(r['status'] == 504 for r in rows),
                'httpCompletedPerSecond': len(rows) / seconds,
                'httpSuccessPerSecond': sum(r['status'] == 200 for r in rows) / seconds,
                'httpLatencySeconds': quantiles([r['seconds'] for r in rows]),
                'healthLatencySeconds': quantiles([r['seconds'] for r in health]),
                'healthStatuses': dict(collections.Counter(str(r['status']) for r in health)),
                'healthCount': len(health)}

    def resource_delta(before, after):
        return {key: after[key] - before[key] for key in ['cpuNanos', 'gcCollections', 'gcMillis']}

    def jdbc_cell(run, mode, count, concurrency, warmup=False, acknowledge=False):
        before = api('/perf/begin', {'run': run, 'mode': mode, 'count': count})
        rows, health = burst('/perf/task', run, count, concurrency, acknowledge)
        state = drain('/perf/state')
        committed = api('/perf/committed')
        record = dict(group='jdbc', run=run, mode=mode, concurrency=concurrency, warmup=warmup,
                      before=before, state=state, committed=committed, requests=rows, health=health)
        record.update(summarize(rows, health))
        record['processDelta'] = resource_delta(before['process'], state['process'])
        tasks = state['tasks']
        successful = [t for t in tasks if t['events']['outcome'] == 'committed']
        record['committedTasks'] = len(successful)
        record['rejectedTasks'] = sum(t['events']['outcome'] == 'rejected' for t in tasks)
        record['lateAfterDecision'] = sum(t['events']['committedNanos'] > t['events']['responseDecisionNanos'] for t in successful)
        record['lateAfterClientAck'] = sum('clientAckNanos' in t['events'] and t['events']['committedNanos'] > t['events']['clientAckNanos'] for t in successful)
        if successful:
            record['sqlCompletedPerSecond'] = len(successful) * 1e9 / (max(t['events']['returnedNanos'] for t in successful) - min(t['events']['submittedNanos'] for t in tasks))
            record['borrowWaitSeconds'] = quantiles([(t['events']['borrowedNanos'] - t['events']['borrowStartedNanos']) / 1e9 for t in successful])
            record['applicationQueueWaitSeconds'] = quantiles([(t['events']['startedNanos'] - t['events']['submittedNanos']) / 1e9 for t in successful])
            record['taskAllocatedBytes'] = sum(t['events']['allocatedBytes'] for t in successful)
        report['rounds'].append(record)
        save_report()
        assert len(tasks) == count and all(t['done'] for t in tasks)
        assert committed['committedOnNewConnection'] == len(successful)
        assert len(successful) + record['rejectedTasks'] == count
        assert all(r['status'] in [200, 503, 504] for r in rows), rows
        assert state['poolActive'] == 0 and state['pending'] == 0
        assert all(r['status'] == 200 for r in health), health
        if mode != 'admission':
            assert len(successful) == count
        print(run, record['statuses'], 'committed', len(successful), 'health', record['healthLatencySeconds'], flush=True)
        return record

    payload_hash = hashlib.sha256(bytes(i % 251 for i in range(262144))).hexdigest()
    def payload_cell(run, mode, count, concurrency, warmup=False):
        api('/perf/payload/begin', {'run': run, 'mode': mode, 'count': count})
        if mode == 'hot':
            for key in range(4):
                warm = request('/perf/payload/warm', {'run': run, 'key': key}, run + ':prime')
                assert warm['status'] == 200
        before = api('/perf/payload/state')
        endpoint = mode if mode in ['aggregate', 'stream'] else 'value'
        rows, health = burst('/perf/payload/' + endpoint, run, count, concurrency)
        state = drain('/perf/payload/state')
        record = dict(group='payload' if endpoint != 'value' else 'cache', run=run, mode=mode, concurrency=concurrency,
                      warmup=warmup, before=before, state=state, requests=rows, health=health)
        record.update(summarize(rows, health))
        record['processDelta'] = resource_delta(before['process'], state['process'])
        record['queryDelta'] = state['postgresQueries'] - before['postgresQueries']
        record['loaderDelta'] = state['loaderCalls'] - before['loaderCalls']
        record['constructionAllocatedBytes'] = sum(t['constructionAllocatedBytes'] for t in state['tasks'])
        report['rounds'].append(record)
        save_report()
        assert len(state['tasks']) == count and all(r['status'] == 200 for r in rows)
        assert all(r['status'] == 200 for r in health)
        if endpoint != 'value':
            assert all(r['bytes'] == 262144 and r['sha256'] == payload_hash for r in rows)
            if mode == 'stream':
                assert all(t['chunksProduced'] == 32 and t['outcome'] == 'stream-terminated' for t in state['tasks'])
        else:
            assert record['queryDelta'] == (count if mode == 'uncached' else 4 if mode == 'cold' else 0)
            assert record['loaderDelta'] == record['queryDelta']
            for index, row in enumerate(rows):
                assert row['bodyText'] == f'tenant{(index % 4) // 2}:item{index % 2}:value'
        print(run, record['statuses'], 'queries', record['queryDelta'], 'p95', record['httpLatencySeconds']['p95'], flush=True)

    server_log = open(args.evidence / 'server.log', 'w')
    process = subprocess.Popen(command, cwd=stage, env=env, stdout=server_log, stderr=subprocess.STDOUT)
    try:
        deadline = time.monotonic() + 45
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise AssertionError('server exited during startup')
            if request('/health', tag='startup')['status'] == 200:
                break
            time.sleep(.15)
        else:
            raise AssertionError('server did not become ready')
        report['configuration'] = api('/perf/config')
        assert report['configuration']['poolMaximum'] == 2
        assert report['configuration']['defaultParallelismMin'] == report['configuration']['defaultParallelismMax'] == 2
        for attempt in range(3):
            late = jdbc_cell(f'late_{attempt}', 'dedicated', 8, 8, warmup=True, acknowledge=True)
            if late['lateAfterClientAck']:
                report['lateHttpProofRun'] = late['run']
                break
        else:
            raise AssertionError('no SQL commit observed after an actual client 504 acknowledgement')
        for round_id in range(3):
            for concurrency in [1, 8]:
                modes = ['default', 'dedicated', 'admission']
                for mode in modes[round_id:] + modes[:round_id]:
                    jdbc_cell(f'w_j{round_id}_c{concurrency}_{mode}', mode, 8, concurrency, warmup=True)
                    jdbc_cell(f'j{round_id}_c{concurrency}_{mode}', mode, 40, concurrency)
                for modes, prefix in [(['aggregate', 'stream'], 'p'), (['uncached', 'cold', 'hot'], 'c')]:
                    offset = round_id % len(modes)
                    for mode in modes[offset:] + modes[:offset]:
                        payload_cell(f'w_{prefix}{round_id}_c{concurrency}_{mode}', mode, 8, concurrency, warmup=True)
                        payload_cell(f'{prefix}{round_id}_c{concurrency}_{mode}', mode, 24, concurrency)
        measured = [r for r in report['rounds'] if not r['warmup']]
        assert len(measured) == 48
        report['measuredRequests'] = sum(len(r['requests']) for r in measured)
        assert report['measuredRequests'] == 1440
        assert any(r['mode'] == 'admission' and r.get('rejectedTasks', 0) > 0 for r in measured)
        report['status'] = 'PASS'
    except BaseException as error:
        report['status'] = 'FAIL'
        report['error'] = repr(error)
        report['traceback'] = traceback.format_exc()
        raise
    finally:
        process.terminate()
        try:
            report['serverExit'] = process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            process.kill()
            report['serverExit'] = process.wait(timeout=5)
            report['status'] = 'FAIL'
            report['cleanupError'] = 'server required kill'
        server_log.close()
        raw.close()
        cleanup = 'PERF_CLEANUP dedicated=true admission=true clock=true poolClosed=true'
        report['resourceCleanupObserved'] = cleanup in (args.evidence / 'server.log').read_text()
        if not report['resourceCleanupObserved']:
            report['status'] = 'FAIL'
        save_report()
    assert report['status'] == 'PASS', report.get('error', 'cleanup failed')
    print('PASS measuredRequests=1440 measuredCells=48 rounds=3 resourcesClosed=true', flush=True)


if __name__ == '__main__':
    main()
