#!/usr/bin/env python3
import argparse
import functools
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import secrets
import subprocess
import threading
import time
import urllib.request


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--evidence', required=True)
    arguments = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output = Path(arguments.evidence).resolve()
    output.mkdir(parents=True, exist_ok=True)
    assert Path(os.environ['JAVA_HOME'], 'bin/java').is_file()
    environment = dict(os.environ, APPLICATION_SECRET=secrets.token_hex(48))
    handler = functools.partial(SimpleHTTPRequestHandler, directory=str(root / 'lab'))
    web = ThreadingHTTPServer(('127.0.0.1', 56172), handler)
    thread = threading.Thread(target=web.serve_forever)
    thread.start()
    process = None
    log = (output / 'browser-security-server.log').open('wb')
    forced = False
    try:
        process = subprocess.Popen([
            str(root / 'target/universal/stage/bin/play-lab'),
            '-Dconfig.resource=governance-browser.conf',
            '-Dlogger.resource=governance-logback.xml',
            '-Dhttp.address=127.0.0.1', '-Dhttp.port=56173'],
            cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT)
        for attempt in range(100):
            if process.poll() is not None:
                raise RuntimeError('server exit ' + str(process.returncode))
            try:
                if urllib.request.urlopen('http://127.0.0.1:56173/gov/connection', timeout=1).status == 200:
                    break
            except OSError:
                time.sleep(.2)
        else:
            raise RuntimeError('readiness deadline')
        print('READY http://127.0.0.1:56172/browser-security.html', flush=True)
        while True:
            time.sleep(30)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            web.shutdown()
            web.server_close()
            thread.join(3)
        finally:
            try:
                if process is not None and process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(10)
                    except subprocess.TimeoutExpired:
                        forced = True
                        process.kill()
                        process.wait(3)
            finally:
                log.close()
                (output / 'browser-security-cleanup.json').write_text(json.dumps({
                    'exit': process.returncode if process else None,
                    'forcedKill': forced,
                    'pageServerThreadStopped': not thread.is_alive()}, indent=2) + '\n')


if __name__ == '__main__':
    main()
