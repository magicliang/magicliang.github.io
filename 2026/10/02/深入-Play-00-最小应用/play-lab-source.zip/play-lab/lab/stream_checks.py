#!/usr/bin/env python3
import argparse, base64, hashlib, http.client, json, os, pathlib, socket, struct
import subprocess, threading, time, traceback, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = 19018
REPORT = {}

def ident(prefix): return prefix + '-' + uuid.uuid4().hex[:10]
def connection(port=PORT): return http.client.HTTPConnection('127.0.0.1', port, timeout=12)
def get(path, headers=None, port=PORT):
    c = connection(port)
    try:
        c.request('GET', path, headers=headers or {})
        r = c.getresponse(); body = r.read()
        return r.status, dict(r.getheaders()), body
    finally: c.close()
def state(id):
    status, _, body = get('/streamlab/state?id=' + id)
    return json.loads(body) if status == 200 else None

def terminal(id, timeout=12):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        value = state(id)
        if value and value['terminated'] and value['fileIoClosed'] == value['fileIoStarted']:
            assert value['closeCount'] == 1, value
            return value
        time.sleep(.05)
    raise AssertionError(('not terminated', id, state(id)))

def http_streams():
    rows = []
    for known in (True, False):
        id = ident('complete'); c = connection()
        try:
            c.request('GET', f'/streamlab/data?id={id}&chunks=64&known={str(known).lower()}')
            r = c.getresponse(); headers = dict(r.getheaders()); n = 0
            while block := r.read(16384): n += len(block); time.sleep(.002)
            assert n == 64 * 16384 and r.version == 11
            assert headers.get('Content-Length') == (str(n) if known else None), headers
            assert headers.get('Transfer-Encoding') is None if known else (headers.get('Transfer-Encoding') == 'chunked' or headers.get('Connection') == 'close'), headers
            rows.append({'case': 'finite-slow-read', 'known': known, 'httpVersion': r.version, 'headers': headers, 'received': n, 'terminal': terminal(id)})
        finally: c.close()
    for known in (True, False):
        id = ident('cancel'); c = connection()
        try:
            c.request('GET', f'/streamlab/data?id={id}&known={str(known).lower()}')
            r = c.getresponse(); first = state(id); time.sleep(.6); paused = state(id)
            assert paused['producedChunks'] < 2048, paused
            prefix = r.read(16384); assert prefix
            rows.append({'case': 'pause-read-tcp-close', 'known': known, 'headers': dict(r.getheaders()), 'first': first, 'paused': paused, 'received': len(prefix)})
            r.close(); c.close()
            rows[-1]['terminal'] = terminal(id)
            assert rows[-1]['terminal']['bytes'] < 32 * 1024 * 1024
        finally: c.close()
    id = ident('fail'); c = connection()
    try:
        c.request('GET', f'/streamlab/data?id={id}&chunks=1024&known=true&failAt=512')
        r = c.getresponse(); error = None
        try: r.read()
        except (http.client.IncompleteRead, ConnectionResetError) as ex: error = type(ex).__name__
        assert error, 'upstream failure must abort body'
        rows.append({'case': 'upstream-failure-after-headers', 'status': r.status, 'headers': dict(r.getheaders()), 'readError': error, 'terminal': terminal(id)})
        assert rows[-1]['terminal']['failure']
    finally: c.close()
    id = ident('detached-work'); sock = socket.create_connection(('127.0.0.1', PORT), timeout=12)
    try:
        sock.sendall((f'GET /streamlab/work?id={id} HTTP/1.1\r\nHost: localhost:{PORT}\r\n\r\n').encode())
        end = time.monotonic() + 2
        while time.monotonic() < end and state(id) is None: time.sleep(.01)
        before = state(id); assert before['workStage'] == 'scheduled' and not before['terminated']
        sock.shutdown(socket.SHUT_RDWR)
    finally: sock.close()
    after = terminal(id)
    assert after['workStage'] == 'completed' and not after['futureCancelled'] and after['producedChunks'] == 1
    rows.append({'case': 'ordinary-completion-stage-after-client-disconnect', 'beforeDisconnect': before, 'terminal': after})
    assert get('/stream')[0] == 200
    REPORT['httpStreams'] = rows

def read_events(response, count=3):
    events = []; lines = []; comments = 0; first = None; start = time.monotonic()
    while len(events) < count:
        line = response.readline()
        if not line: break
        text = line.decode().rstrip('\r\n')
        if text.startswith(':'): comments += 1
        elif text: lines.append(text)
        elif lines:
            fields = {}
            for item in lines:
                k, _, v = item.partition(':'); fields.setdefault(k, []).append(v.lstrip(' '))
            events.append(fields); lines = []
            if first is None: first = time.monotonic() - start
    return {'events': events, 'comments': comments, 'firstEventSeconds': first}

def sse():
    id = ident('sse'); c = connection()
    try:
        c.request('GET', '/streamlab/sse?id=' + id); r = c.getresponse(); initial = read_events(r)
        assert [int(e['id'][0]) for e in initial['events']] == [101, 102, 103]
        assert all(len(e['data']) == 2 for e in initial['events']) and initial['comments'] >= 2
        r.close()
    finally: c.close()
    initial['terminal'] = terminal(id)
    id = ident('resume'); c = connection()
    try:
        c.request('GET', '/streamlab/sse?id=' + id, headers={'Last-Event-ID': '103'})
        r = c.getresponse(); resumed = read_events(r); r.close()
        assert [int(e['id'][0]) for e in resumed['events']] == [104, 105, 106]
    finally: c.close()
    resumed['terminal'] = terminal(id)
    cursors = {cursor: get('/streamlab/sse?id=' + ident('cursor'), {'Last-Event-ID': cursor})[0] for cursor in ('99', '120', '121', 'bad')}
    assert cursors == {'99': 410, '120': 204, '121': 400, 'bad': 400}, cursors
    id = ident('sse-failure'); c = connection()
    try:
        c.request('GET', '/streamlab/sse?id=' + id + '&mode=fail'); r = c.getresponse()
        observed = read_events(r)
        error = None
        try: r.read()
        except (http.client.IncompleteRead, ConnectionResetError) as ex: error = type(ex).__name__
        assert len(observed['events']) == 3 and error in ('IncompleteRead', 'ConnectionResetError')
        failed = {'status': r.status, 'headers': dict(r.getheaders()), 'events': observed, 'readError': error, 'terminal': terminal(id)}
        assert failed['terminal']['failure']
    finally: c.close()
    REPORT['sse'] = {'initial': initial, 'resumed': resumed, 'cursorStatuses': cursors, 'retainedRange': [101, 120], 'upstreamFailure': failed}

class Proxy(BaseHTTPRequestHandler):
    def log_message(self, *_): pass
    def do_GET(self):
        mode = self.path.split('?')[0].strip('/'); c = connection(); pending = bytearray(); start = time.monotonic()
        try:
            c.request('GET', '/streamlab/sse?id=' + ident('proxy')); r = c.getresponse()
            self.send_response(200); self.send_header('Content-Type', 'text/event-stream'); self.end_headers()
            last = start
            while block := r.read1(1024):
                pending.extend(block)
                assert len(pending) <= 65536
                if mode == 'direct' or len(pending) >= 64512 or time.monotonic() - last >= 2:
                    self.wfile.write(pending); self.wfile.flush(); pending.clear(); last = time.monotonic()
            if pending: self.wfile.write(pending); self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError): pass
        finally: c.close()

def proxy_comparison():
    server = ThreadingHTTPServer(('127.0.0.1', 0), Proxy); server.daemon_threads = False
    thread = threading.Thread(target=server.serve_forever); thread.start()
    rows = {}
    try:
        for mode in ('direct', 'buffered'):
            c = connection(server.server_port)
            try:
                c.request('GET', '/' + mode); r = c.getresponse(); rows[mode] = read_events(r, 20); r.read()
                assert len(rows[mode]['events']) == 20
            finally: c.close()
        assert rows['buffered']['firstEventSeconds'] > rows['direct']['firstEventSeconds'] + 1.0, rows
    finally: server.shutdown(); server.server_close(); thread.join(3)
    assert not thread.is_alive()
    REPORT['localProxyOnly'] = {'modes': rows, 'maxBufferBytes': 65536, 'flushSeconds': 2, 'notNginxEvidence': True}

def exact(sock, count):
    result = bytearray()
    while len(result) < count:
        part = sock.recv(count - len(result))
        if not part: raise EOFError('peer closed TCP')
        result.extend(part)
    return bytes(result)
def frame(sock, payload, opcode=1, fin=True, split=False):
    if isinstance(payload, str): payload = payload.encode()
    mask = b'lab!'; n = len(payload)
    head = bytes([(128 if fin else 0) | opcode])
    head += bytes([128 | n]) if n < 126 else (b'\xfe' + struct.pack('!H', n) if n < 65536 else b'\xff' + struct.pack('!Q', n))
    wire = head + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
    if split:
        for offset in range(0, len(wire), 8192):
            sock.sendall(wire[offset:offset + 8192]); time.sleep(.01)
    else: sock.sendall(wire)
def recv_frame(sock):
    a, b = exact(sock, 2); n = b & 127
    if n == 126: n = struct.unpack('!H', exact(sock, 2))[0]
    if n == 127: n = struct.unpack('!Q', exact(sock, 8))[0]
    assert n <= 131072 and not b & 128
    return a & 15, exact(sock, n)
def handshake(id, token='synthetic-token', origin='http://localhost:19018'):
    s = socket.create_connection(('127.0.0.1', PORT), timeout=12); s.settimeout(12)
    key = base64.b64encode(b'0123456789abcdef').decode()
    s.sendall((f'GET /streamlab/ws?id={id}&token={token} HTTP/1.1\r\nHost: localhost:{PORT}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\nOrigin: {origin}\r\n\r\n').encode())
    head = bytearray()
    while not head.endswith(b'\r\n\r\n'):
        head.extend(exact(s, 1)); assert len(head) < 16384
    code = int(head.split(b' ')[1])
    if code == 101:
        expected = base64.b64encode(hashlib.sha1((key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest())
        assert expected.lower() in bytes(head).lower()
    return s, code, head.decode()
def websocket():
    rows = []
    for token, origin, status in [('bad', 'http://localhost:19018', 401), ('synthetic-token', 'http://evil.invalid', 403)]:
        id = ident('reject'); s, code, head = handshake(id, token, origin)
        try: assert code == status and state(id) is None
        finally: s.close()
        rows.append({'case': 'reject-before-flow', 'status': code, 'ledgerAllocated': False, 'headers': head})
    for mode in ('normal', 'tcp-disconnect', 'half-close', 'slow-consumer', 'oversized-message', 'fragmented-message', 'frame-limit', 'large-frame-single-write', 'message-count', 'burst-overflow-or-cap'):
        id = ident('ws'); s, status, head = handshake(id); assert status == 101
        observed = []
        try:
            if mode == 'normal':
                frame(s, 'hello'); opcode, body = recv_frame(s); assert (opcode, body) == (1, b'echo:hello')
                frame(s, struct.pack('!H', 1000), 8); opcode, body = recv_frame(s); assert opcode == 8
                observed.append({'opcode': opcode, 'closeCode': struct.unpack('!H', body[:2])[0]})
            elif mode in ('tcp-disconnect', 'half-close'):
                frame(s, 'bye'); recv_frame(s)
                if mode == 'half-close':
                    started = time.monotonic()
                    s.shutdown(socket.SHUT_WR)
                    try:
                        opcode, body = recv_frame(s)
                        assert opcode == 8, (opcode, body)
                        outcome = {'kind': 'close-frame', 'closeCode': struct.unpack('!H', body[:2])[0]}
                    except EOFError:
                        outcome = {'kind': 'tcp-eof'}
                    before_full_close = terminal(id)
                    observed.append({'writeHalfClosed': True, 'readHalfKeptOpen': True,
                                     'observedBeforeFullClose': outcome,
                                     'secondsAfterWriteHalfClose': time.monotonic() - started,
                                     'terminalBeforeFullClose': before_full_close})
            elif mode == 'slow-consumer':
                for _ in range(20): frame(s, 'x' * 4096)
                time.sleep(.7); observed.append({'pausedState': state(id)})
                for _ in range(21):
                    try: opcode, body = recv_frame(s)
                    except EOFError: break
                    observed.append({'opcode': opcode, 'bytes': len(body)})
                    if opcode == 8: break
                    time.sleep(.02)
            else:
                if mode == 'oversized-message': frame(s, 'x' * 4097)
                elif mode == 'fragmented-message': frame(s, 'x' * 3000, fin=False); frame(s, 'x' * 3000, opcode=0)
                elif mode == 'frame-limit': frame(s, 'x' * 65537, split=True)
                elif mode == 'large-frame-single-write': frame(s, 'x' * 65537)
                elif mode == 'message-count':
                    for _ in range(19):
                        frame(s, 'x'); opcode, body = recv_frame(s); assert (opcode, body) == (1, b'echo:x')
                    frame(s, 'x')
                else:
                    for _ in range(21): frame(s, 'x')
                for _ in range(22):
                    try: opcode, body = recv_frame(s)
                    except EOFError: observed.append({'tcpEof': True}); break
                    observed.append({'opcode': opcode, 'bytes': len(body), 'closeCode': struct.unpack('!H', body[:2])[0] if opcode == 8 and len(body) >= 2 else None})
                    if opcode == 8: break
                assert any(x.get('opcode') == 8 or x.get('tcpEof') for x in observed), observed
        finally: s.close()
        final = terminal(id); assert final['producedChunks'] <= 20
        if mode == 'frame-limit': assert any(x.get('closeCode') == 1009 for x in observed) and final['producedChunks'] == 0
        if mode == 'message-count': assert final['producedChunks'] == 20
        if mode in ('oversized-message', 'fragmented-message'): assert final['producedChunks'] == 0 and final['failure']
        rows.append({'case': mode, 'handshake': status, 'observed': observed, 'terminal': final})
    REPORT['websocket'] = rows

def snapshot(): return json.loads(get('/streamlab/files')[2])
def multipart(name, content):
    return (f'--lab\r\nContent-Disposition: form-data; name="file"; filename="{name}"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode() + content + b'\r\n--lab--\r\n')
def upload(id, name, content, chunked=False):
    data = multipart(name, content); c = connection()
    try:
        headers = {'Content-Type': 'multipart/form-data; boundary=lab', 'X-Play-Lab': 'synthetic'}
        body = (data[i:i+4096] for i in range(0, len(data), 4096)) if chunked else data
        c.request('POST', '/streamlab/upload?id=' + id, body=body, headers=headers, encode_chunked=chunked)
        r = c.getresponse(); return r.status, r.read().decode(), terminal(id)
    finally: c.close()
def files():
    baseline = snapshot(); rows = []; stored = []
    try:
        for name, content, chunked, expected in [('good.bin', b'abc', False, 200), ('../bad', b'abc', False, 400), ('/absolute', b'abc', False, 400), ('empty.bin', b'', False, 400), ('large.bin', b'x' * 70000, False, 413), ('large.bin', b'x' * 70000, True, 413)]:
            id = ident('upload'); code, body, term = upload(id, name, content, chunked)
            assert code == expected, (name, chunked, code, body)
            if code == 200:
                value = json.loads(body); stored.append(value['stored']); assert value['stored'] != name
            assert snapshot()['tmp'] == baseline['tmp'], snapshot()
            rows.append({'case': name, 'chunked': chunked, 'status': code, 'body': body[:256], 'terminal': term, 'snapshot': snapshot()})
        id = ident('interrupted'); s = socket.create_connection(('127.0.0.1', PORT), timeout=12)
        try:
            prefix = multipart('interrupted.bin', b'x' * 20000)[:-11]
            s.sendall((f'POST /streamlab/upload?id={id} HTTP/1.1\r\nHost: localhost:{PORT}\r\nContent-Type: multipart/form-data; boundary=lab\r\nContent-Length: 50000\r\nX-Play-Lab: synthetic\r\n\r\n').encode() + prefix)
            end = time.monotonic() + 4
            while time.monotonic() < end and snapshot()['tmp'] == baseline['tmp']: time.sleep(.05)
            during = snapshot(); assert during['tmp'] != baseline['tmp'], during
            s.shutdown(socket.SHUT_RDWR)
        finally: s.close()
        term = terminal(id); assert term['fileIoStarted'] == term['fileIoClosed'] == 1
        end = time.monotonic() + 5
        while time.monotonic() < end and snapshot()['tmp'] != baseline['tmp']: time.sleep(.05)
        assert snapshot()['tmp'] == baseline['tmp'], snapshot()
        rows.append({'case': 'interrupted-upload-real-tcp-close', 'during': during, 'after': snapshot(), 'terminal': term})
        id = ident('download'); c = connection()
        try:
            c.request('GET', '/streamlab/download?id=' + id); r = c.getresponse(); headers = dict(r.getheaders())
            assert int(headers['Content-Length']) == 33554432 and headers['Content-Type'] == 'application/octet-stream'
            assert len(r.read(16384)) == 16384; time.sleep(.2); r.close()
        finally: c.close()
        term = terminal(id); assert snapshot()['tmp'] == baseline['tmp']
        rows.append({'case': 'cancel-download-real-tcp-close', 'headers': headers, 'terminal': term, 'snapshot': snapshot()})
    finally:
        for id in stored:
            c = connection()
            try: c.request('DELETE', '/streamlab/files/' + id, headers={'X-Play-Lab': 'synthetic'}); assert c.getresponse().status == 204
            finally: c.close()
    assert snapshot() == baseline
    REPORT['files'] = {'baseline': baseline, 'scenarios': rows, 'final': snapshot()}

def main():
    p = argparse.ArgumentParser(); p.add_argument('--evidence', required=True); args = p.parse_args()
    root = pathlib.Path(__file__).resolve().parents[1]; evidence = pathlib.Path(args.evidence).resolve(); evidence.mkdir(parents=True, exist_ok=True)
    runtime = root / 'runtime'; runtime.mkdir(exist_ok=True)
    env = dict(os.environ)
    java_home = env.get('JAVA_HOME')
    if not java_home or not (pathlib.Path(java_home) / 'bin/java').is_file():
        raise RuntimeError('Set JAVA_HOME to the JDK 21 installation used to build the lab')
    with socket.socket() as probe:
        probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        probe.bind(('127.0.0.1', PORT))
    log = (evidence / 'production.log').open('w'); proc = None; stop = threading.Event(); rss = []
    def sample():
        while not stop.wait(.1):
            try:
                output = subprocess.check_output(['ps', '-o', 'rss=', '-p', str(proc.pid)], text=True, timeout=2).strip()
                if output: rss.append(int(output))
            except (subprocess.SubprocessError, ValueError): pass
    sampler = None
    try:
        proc = subprocess.Popen([str(root / 'target/universal/stage/bin/play-lab'), '-Dhttp.address=127.0.0.1', '-Dhttp.port=' + str(PORT), '-Dpidfile.path=/dev/null', '-Djava.io.tmpdir=' + str(runtime), '-Dpekko.coordinated-shutdown.phases.service-requests-done.timeout=2s'], env=env, cwd=root, stdout=log, stderr=subprocess.STDOUT)
        end = time.monotonic() + 40
        while time.monotonic() < end:
            if proc.poll() is not None: raise RuntimeError('server exited')
            try:
                if get('/health')[0] == 200:
                    if proc.poll() is not None:
                        raise RuntimeError('owned server exited during readiness check')
                    break
            except (OSError, http.client.HTTPException): time.sleep(.2)
        else: raise AssertionError('server startup timeout')
        sampler = threading.Thread(target=sample); sampler.start()
        for check in (http_streams, sse, proxy_comparison, websocket, files):
            check(); print('PASS', check.__name__, flush=True)
            (evidence / 'observations.json').write_text(json.dumps(REPORT, indent=2))
        REPORT['status'] = 'PASS'
    except BaseException:
        REPORT['status'] = 'FAIL'; REPORT['error'] = traceback.format_exc(); raise
    finally:
        stop.set()
        if sampler: sampler.join(3)
        if proc:
            proc.terminate()
            try: proc.wait(timeout=15)
            except subprocess.TimeoutExpired: proc.kill(); proc.wait(timeout=5)
        REPORT['rssKiBSamples'] = {'baseline': rss[0] if rss else None, 'peak': max(rss) if rss else None, 'samples': rss, 'scope': 'sampled process RSS only; does not prove constant memory'}
        REPORT['serverExit'] = proc.returncode if proc else None
        (evidence / 'observations.json').write_text(json.dumps(REPORT, indent=2)); log.close()
if __name__ == '__main__': main()
