import ast
import io
import json
from pathlib import Path
import signal
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from database_checks import finish


class CleanupTest(unittest.TestCase):
    def servers(self, actions):
        def fail():
            actions.append('first')
            raise TimeoutError('synthetic stop failure')
        return [SimpleNamespace(name='first', stop=fail),
                SimpleNamespace(name='second', stop=lambda: actions.append('second'))]

    def test_first_stop_failure_preserves_primary_and_writes_all_receipts(self):
        actions = []
        primary = ValueError('original assertion')
        with tempfile.TemporaryDirectory() as temporary:
            evidence = Path(temporary)
            with self.assertRaises(ValueError) as caught:
                try:
                    raise primary
                finally:
                    finish(self.servers(actions), evidence, [{'status': 504}], [{'rows': 1}], {}, primary)
            self.assertIs(primary, caught.exception)
            self.assertEqual(['first', 'second'], actions)
            self.assertEqual([{'status': 504}], json.loads((evidence / 'http-observations.json').read_text()))
            self.assertEqual([{'rows': 1}], json.loads((evidence / 'sql-observations.json').read_text()))
            summary = json.loads((evidence / 'summary.json').read_text())
            self.assertEqual('FAIL', summary['result'])
            self.assertEqual('stop:first', summary['cleanupErrors'][0]['operation'])

    def test_cleanup_failure_cannot_leave_pass_result(self):
        actions = []
        with tempfile.TemporaryDirectory() as temporary:
            evidence = Path(temporary)
            with self.assertRaisesRegex(RuntimeError, 'stop:first'):
                finish(self.servers(actions), evidence, [], [], {'result': 'PASS'}, None)
            self.assertEqual(['first', 'second'], actions)
            self.assertEqual('FAIL', json.loads((evidence / 'summary.json').read_text())['result'])

    def test_first_write_failure_still_attempts_other_receipts(self):
        actions = []
        original = Path.write_text
        def write(path, text, *args, **kwargs):
            actions.append(path.name)
            if path.name == 'http-observations.json':
                raise OSError('synthetic disk error')
            return original(path, text, *args, **kwargs)
        with tempfile.TemporaryDirectory() as temporary, patch.object(Path, 'write_text', write):
            evidence = Path(temporary)
            with self.assertRaisesRegex(RuntimeError, 'write:http-observations.json'):
                finish([], evidence, [], [], {}, None)
            self.assertEqual(['http-observations.json', 'sql-observations.json', 'summary.json'], actions)
            self.assertTrue((evidence / 'sql-observations.json').exists())
            self.assertTrue((evidence / 'summary.json').exists())
            self.assertEqual('FAIL', json.loads((evidence / 'summary.json').read_text())['result'])

    def test_actual_nested_stop_closes_log_after_forced_kill(self):
        tree = ast.parse(Path(__file__).with_name('database_checks.py').read_text())
        method = next(node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef) and node.name == 'stop')
        namespace = {'signal': signal, 'subprocess': subprocess}
        exec(compile(ast.Module(body=[method], type_ignores=[]), 'database_checks.py', 'exec'), namespace)
        actions = []
        def wait(timeout):
            actions.append(('wait', timeout))
            if timeout == 18:
                raise subprocess.TimeoutExpired('synthetic process', timeout)
            return -9
        process = SimpleNamespace(poll=lambda: None, send_signal=lambda sig: actions.append(('signal', sig)),
                                  wait=wait, kill=lambda: actions.append(('kill',)), returncode=-9)
        log = io.StringIO()
        server = SimpleNamespace(process=process, log=log, name='first')
        with self.assertRaisesRegex(AssertionError, 'SIGTERM exceeded deadline'):
            namespace['stop'](server)
        self.assertTrue(log.closed)
        self.assertIn(('kill',), actions)
        self.assertEqual(('wait', 3), actions[-1])


if __name__ == '__main__':
    unittest.main()
