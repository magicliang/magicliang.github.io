#!/usr/bin/env python3
"""Finite real PostgreSQL + staged Play checks; never stops the shared PG fixture."""
import argparse, concurrent.futures, contextlib, hashlib, http.client, json, os
import pathlib, secrets, signal, socket, subprocess, threading, time, traceback
from http.server import HTTPServer, BaseHTTPRequestHandler
from governance_checks import Client, port

REPORT={}; SQL=[]; NETWORK=[]; NETWORK_LOCK=threading.Lock()
class CapClient(Client):
    def call(self,method,path,body=None,headers=None):
        response=super().call(method,path,body,headers)
        st,h,data=response
        # Cookies/tokens are deliberately excluded; order responses and HTTP framing are retained.
        public=data.decode(errors='replace') if path not in ('/caps/form',) and not path.startswith('/caps/login') else '[fixture credential response omitted]'
        with NETWORK_LOCK:
            assert len(NETWORK)<1000,'bounded HTTP receipt limit'
            NETWORK.append({'method':method,'path':path,'requestBytes':len(body.encode() if isinstance(body,str) else body or b''),'cookiePresent':bool(self.cookies),'status':st,'headers':h,'body':public})
        return response
    def login(self,tenant,subject):
        assert self.get('/caps/login?tenant='+tenant+'&subject='+subject)[0]==200
        st,_,b=self.get('/caps/form');assert st==200;self.csrf=json.loads(b)['csrfToken'];return self
    def write(self,path,body=None):
        return self.post(path,json.dumps(body) if body is not None else '',{'Content-Type':'application/json' if body is not None else 'application/x-www-form-urlencoded','Csrf-Token':self.csrf})
    def create(self,key,quantity=1,**extra):return self.write('/caps/orders',dict(key=key,quantity=quantity,note='fixture',**extra))

def decode(response,wanted=200):
    st,h,b=response;assert st==wanted,(st,b[:500]);return json.loads(b)
def wait_until(fn,seconds=7):
    until=time.monotonic()+seconds
    while time.monotonic()<until:
        value=fn()
        if value:return value
        time.sleep(.04)
    raise AssertionError('bounded wait expired')
def stream_closed(c,track):
    def check():
        row=decode(c.get('/caps/state'))['streams'].get(track,{})
        return row if row.get('closed') else None
    row=wait_until(check);assert row['closeCount']==1,row;return row

class Database:
    def __init__(self,args,out):self.args=args;self.out=out;self.schema='capstone_'+secrets.token_hex(6)
    def sql(self,query):
        p=subprocess.run(['podman','exec',self.args.container,'psql','-U','postgres','-d','play_lab','-X','-v','ON_ERROR_STOP=1','-At','-c',query],capture_output=True,text=True,timeout=8)
        entry={'sql':query,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr};SQL.append(entry)
        (self.out/'sql.json').write_text(json.dumps(SQL,indent=2));assert p.returncode==0,entry;return p.stdout.strip()
    def snapshot(self,label):
        s=self.schema
        data=json.loads(self.sql(f"SELECT json_build_object('stock',(SELECT json_agg(x ORDER BY tenant) FROM {s}.stock x),'orders',(SELECT coalesce(json_agg(x ORDER BY tenant,subject,idem_key),'[]') FROM {s}.orders x),'principals',(SELECT json_agg(x ORDER BY tenant,subject) FROM {s}.principals x))"))
        REPORT.setdefault('database',{})[label]=data
        for stock in data['stock']:
            used=sum(r['quantity'] for r in data['orders'] if r['tenant']==stock['tenant'] and r['status']=='CREATED')
            assert stock['remaining']==20-used,data
        return data

@contextlib.contextmanager
def slow_server(out):
    events=[]
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_GET(self):
            if self.path!='/slow':self.send_error(404);return
            events.append({'event':'entered','at':time.monotonic()})
            time.sleep(.7)
            try:self.send_response(200);self.send_header('Content-Length','4');self.end_headers();self.wfile.write(b'slow');events.append({'event':'written','at':time.monotonic()})
            except (BrokenPipeError,ConnectionResetError):events.append({'event':'peer-closed','at':time.monotonic()})
    srv=HTTPServer(('127.0.0.1',0),Handler);srv.timeout=1
    thread=threading.Thread(target=srv.serve_forever,kwargs={'poll_interval':.05},name='capstone-slow');thread.start()
    try:yield srv.server_port
    finally:
        srv.shutdown();srv.server_close();thread.join(3);assert not thread.is_alive()
        REPORT['downstream']={'events':events,'threadClosed':not thread.is_alive()};(out/'downstream.json').write_text(json.dumps(REPORT['downstream'],indent=2))

class Server:
    def __init__(self,out,name,db,downstream):self.out=out;self.name=name;self.db=db;self.downstream=downstream;self.process=None
    def __enter__(self):
        root=pathlib.Path(__file__).resolve().parents[1];self.root=root;self.port=port();self.secret=secrets.token_hex(48);self.journal=self.out/(self.name+'-journal.jsonl');self.files=self.out/(self.name+'-files')
        env=os.environ.copy();assert env.get('JAVA_HOME'),'JAVA_HOME required'
        env.update(APPLICATION_SECRET=self.secret,CAPSTONE_SCHEMA=self.db.schema,CAPSTONE_JOURNAL=str(self.journal),CAPSTONE_FILES=str(self.files),CAPSTONE_DOWNSTREAM='http://127.0.0.1:'+str(self.downstream)+'/slow',CAPSTONE_JDBC_URL='jdbc:postgresql://127.0.0.1:'+str(self.db.args.pg_port)+'/play_lab?ApplicationName='+self.db.schema+'&connectTimeout=3&socketTimeout=6')
        self.logfile=self.out/(self.name+'.log');self.log=self.logfile.open('wb')
        self.process=subprocess.Popen([str(root/'target/universal/stage/bin/play-lab'),'-Dconfig.resource=capstone.conf','-Dhttp.address=127.0.0.1','-Dhttp.port='+str(self.port)],cwd=root,env=env,stdout=self.log,stderr=subprocess.STDOUT)
        try:
            until=time.monotonic()+40
            while time.monotonic()<until:
                if self.process.poll() is not None:raise AssertionError('server exit '+str(self.process.returncode))
                try:
                    if CapClient(self.port).get('/caps/ready')[0]==200:return self
                except OSError:pass
                time.sleep(.12)
            raise AssertionError('ready deadline')
        except BaseException:self.__exit__(None,None,None);raise
    def journal_rows(self):return [json.loads(line) for line in self.journal.read_text().splitlines()] if self.journal.exists() else []
    def __exit__(self,*_):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try:self.process.wait(timeout=20)
            except subprocess.TimeoutExpired:self.process.kill();self.process.wait(timeout=3)
        self.log.close();raw=self.logfile.read_text(errors='replace');assert self.secret not in raw
        scanned=0
        for file in (self.root/'target/universal/stage').rglob('*'):
            if not file.is_file():continue
            scanned+=1;tail=b''
            with file.open('rb') as source:
                while block:=source.read(65536):
                    assert self.secret.encode() not in tail+block,file
                    tail=block[-len(self.secret):]
        rows=self.journal_rows();terminal=next((x for x in rows if x['event']=='final-cleanup'),None)
        REPORT.setdefault('processes',[]).append({'name':self.name,'exit':self.process.returncode,'port':self.port,'terminal':terminal,'secretAbsentInLog':True,'stageFilesScannedForRuntimeSecret':scanned})
        if _[0] is None:
            assert terminal,rows
            assert all(terminal[x] for x in ('fileClosed','poolClosed','clientClosed','executorTerminated')),terminal
            assert [terminal[x] for x in ('inFlight','filesLeft','streamPermits')]==[0,0,4] and not terminal['cleanupFailure'],terminal

@contextlib.contextmanager
def live(c,path):
    connection=http.client.HTTPConnection('127.0.0.1',c.port,timeout=7)
    try:
        connection.request('GET',path,headers={'Cookie':c.header()});response=connection.getresponse();yield connection,response
    finally:
        if 'response' in locals():response.close()
        connection.close()
def event(response):
    for _ in range(12):
        line=response.readline()
        if line.startswith(b'data:'):return json.loads(line[5:].strip())
        if not line:raise AssertionError('EOF before event')
    raise AssertionError('event missing')

def matrix(server,db):
    p=server.port;anon=CapClient(p);a=CapClient(p).login('t1','alice');b=CapClient(p).login('t1','bob');other=CapClient(p).login('t2','alice')
    checks={'anonymous':anon.get('/caps/orders')[0],'identityHeader':anon.get('/caps/orders',{'X-Username':'alice','X-Tenant':'t1'})[0]}
    tamper=CapClient(p);tamper.cookies=dict(a.cookies);name=next(k for k in tamper.cookies if 'SESSION' in k);value=tamper.cookies[name];ix=value.rfind('.')+1;tamper.cookies[name]=value[:ix]+('x' if value[ix]!='x' else 'y')+value[ix+1:]
    checks['tamperedSession']=tamper.get('/caps/orders')[0];assert list(checks.values())==[401]*3,checks
    checks['missingCsrf']=a.post('/caps/orders','{}',{'Content-Type':'application/json'})[0]
    # Assert JSON and form requests under the configured cookie-based CSRF policy.
    checks['missingFormCsrf']=a.post('/caps/orders','x=1')[0]
    checks['oldBypassFormCsrf']=a.post('/caps/orders','x=1',{'X-Play-Lab':'synthetic'})[0]
    assert checks['missingCsrf']==403 and checks['missingFormCsrf']==403 and checks['oldBypassFormCsrf']==403,checks
    checks['identityInBody']=a.write('/caps/orders',{'key':'forged','quantity':1,'note':'fixture','tenant':'t2'})[0];assert checks['identityInBody']==400
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        created=[decode(x) for x in pool.map(lambda _:a.create('same',2),range(4),timeout=15)]
    assert len({r['id'] for r in created})==1 and sorted(r['outcome'] for r in created)==['CREATED','REPLAY','REPLAY','REPLAY'],created
    aid=created[0]['id'];snap=db.snapshot('same-key');assert len(snap['orders'])==1 and snap['stock'][0]['remaining']==18
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        conflicts=list(pool.map(lambda _:a.create('same',3),range(4),timeout=15))
    assert all(r[0]==409 for r in conflicts),conflicts
    bid=decode(b.create('same'))['id'];oid=decode(other.create('same'))['id']
    checks['objects']={};checks['ownLists']={}
    for label,c,id,foreign in [('alice',a,aid,bid),('bob',b,bid,aid),('tenant2',other,oid,aid)]:
        rows=decode(c.get('/caps/orders'));assert [r['id'] for r in rows]==[id],rows;checks['ownLists'][label]=rows
        own=decode(c.get('/caps/orders/'+id));assert own['id']==id
        denied=[c.get('/caps/orders/'+foreign)[0],c.write('/caps/orders/'+foreign+'/cancel')[0],c.get('/caps/orders/'+foreign+'/events?track=deny-'+label)[0],c.get('/caps/orders/'+foreign+'/export?track=deny-csv-'+label)[0]]
        assert denied==[403]*4,denied;checks['objects'][label]=denied
        st,h,body=c.get('/caps/orders/'+id+'/export?track=full-'+label);assert st==200 and id.encode() in body and foreign.encode() not in body
        checks['objects'][label+'_csv']={'status':st,'bytes':len(body),'headers':h,'terminal':stream_closed(c,'full-'+label)}
        with live(c,'/caps/orders/'+id+'/events?track=own-'+label) as (connection,response):
            assert response.status==200;first=event(response);assert first['id']==id
        checks['objects'][label+'_sse']={'first':first,'terminal':stream_closed(c,'own-'+label)}
    with contextlib.ExitStack() as resources:
        for index in range(4):
            _,response=resources.enter_context(live(other,'/caps/orders/'+oid+'/events?track=capacity-'+str(index)))
            assert response.status==200;event(response)
        fifth=other.get('/caps/orders/'+oid+'/events?track=capacity-fifth')[0];assert fifth==503
    checks['streamCapacity']={'fifthStatus':fifth,'closed':[stream_closed(other,'capacity-'+str(i)) for i in range(4)]}
    checks['sameSubjectOtherTenant']=a.get('/caps/orders/'+oid)[0];assert checks['sameSubjectOtherTenant']==403
    # Same fresh key with racing, conflicting payloads: exactly one row wins this finite race.
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        racing=list(pool.map(lambda q:other.create('mixed-race',q),[1,2,1,2],timeout=15))
    winners=[decode(r) for r in racing if r[0]==200];losers=[r for r in racing if r[0]==409]
    assert len(winners)==2 and len(losers)==2 and len({r['id'] for r in winners})==1,racing
    assert sorted(r['outcome'] for r in winners)==['CREATED','REPLAY']
    decode(other.write('/caps/orders/'+winners[0]['id']+'/cancel'))
    checks['mixedPayloadRace']={'statuses':[r[0] for r in racing],'winners':winners}
    # Drain stock through real transactions, prove failed inserts rolled back, then restore once.
    stock_client=CapClient(p).login('t2','bob');bulk=[];stock_status=[]
    for i in range(7):
        response=stock_client.create('stock-'+str(i),3);stock_status.append(response[0])
        if response[0]==200:bulk.append(decode(response)['id'])
        else:assert response[0]==409,response
    assert len(bulk)==6 and stock_status[-1]==409,stock_status
    exhausted=db.snapshot('exhausted');assert sum(r['idem_key'].startswith('stock-') for r in exhausted['orders'])==6
    assert not any(r['idem_key']=='stock-6' for r in exhausted['orders'])
    for id in bulk:decode(stock_client.write('/caps/orders/'+id+'/cancel'))
    checks['insufficientStockRollback']={'statuses':stock_status,'successfulRows':len(bulk),'rolledBackKey':'stock-6'}
    before=db.snapshot('before-cancel')
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:cancelled=[decode(r) for r in pool.map(lambda _:a.write('/caps/orders/'+aid+'/cancel'),range(2),timeout=15)]
    assert sorted(r['outcome'] for r in cancelled)==['CANCELLED','REPLAY_CANCEL'],cancelled
    replay=decode(a.create('same',2));assert replay['status']=='CANCELLED' and replay['outcome']=='REPLAY'
    db.snapshot('after-cancel')
    with live(b,'/caps/orders/'+bid+'/events?track=status-change') as (connection,response):
        first=event(response);assert first['status']=='CREATED';decode(b.write('/caps/orders/'+bid+'/cancel'))
        changes=[first]
        for _ in range(19):
            row=event(response);changes.append(row)
            if row['status']=='CANCELLED':break
        assert changes[-1]['status']=='CANCELLED'
    checks['statusSubscription']={'events':changes,'terminal':stream_closed(b,'status-change')}
    with live(other,'/caps/orders/'+oid+'/export?track=large-cancel&copies=524288') as (connection,response):
        assert response.status==200;received=response.read(16384);assert len(received)==16384
        header=dict(response.getheaders());length=int(response.getheader('Content-Length'));assert length>16*1024*1024
    checks['downloadCancel']={'received':len(received),'length':length,'headers':header,'terminal':stream_closed(other,'large-cancel')};assert not list(server.files.iterdir())
    slow=decode(other.create('slow',notifySlow=True));assert slow['notification']=='BUDGET_FAILED',slow
    afterslow=db.snapshot('after-slow');assert any(r['id']==slow['id'] for r in afterslow['orders'])
    journal=server.journal_rows();commit=next(i for i,x in enumerate(journal) if x['event']=='transaction-returned' and x['detail'].startswith('slow:'));notify=next(i for i,x in enumerate(journal) if x['event']=='notification-terminal' and x['detail'].startswith('slow:'));assert commit<notify
    checks['slowDownstream']={'response':slow,'commitJournalIndex':commit,'notificationJournalIndex':notify}
    with live(a,'/caps/orders/'+aid+'/events?track=revoked') as (connection,response):
        first=event(response);decode(a.write('/caps/revoke'));failure=None
        try:response.read()
        except (http.client.IncompleteRead,ConnectionResetError) as error:failure=type(error).__name__
        assert failure
    terminal=stream_closed(a,'revoked');assert terminal['failure'],terminal
    denied=[a.get('/caps/orders')[0],a.get('/caps/orders/'+aid)[0],a.create('after-revoke')[0],a.write('/caps/orders/'+aid+'/cancel')[0],a.get('/caps/orders/'+aid+'/events?track=after-revoke')[0],a.get('/caps/orders/'+aid+'/export?track=after-revoke-csv')[0]]
    assert denied==[403]*6,denied
    checks['revocation']={'first':first,'clientError':failure,'terminal':terminal,'laterStatuses':denied}
    checks['concurrentCreate']=created;checks['conflicts']=[r[0] for r in conflicts];checks['concurrentCancel']=cancelled
    REPORT['httpMatrix']=checks;db.snapshot('before-restart');return {'alice':aid,'bob':bid,'tenant2':oid,'slow':slow['id']}

def restart_and_shutdown(server,db,ids):
    b=CapClient(server.port).login('t1','bob');other=CapClient(server.port).login('t2','alice');a=CapClient(server.port).login('t1','alice')
    assert decode(b.get('/caps/orders/'+ids['bob']))['status']=='CANCELLED';assert decode(other.get('/caps/orders/'+ids['tenant2']))['status']=='CREATED';assert a.get('/caps/orders')[0]==403
    REPORT['restart']={'bob':'CANCELLED','tenant2':'CREATED','revokedAlice':403};before=db.snapshot('restart')
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        future=pool.submit(other.create,'sigterm',1,delayMillis=2000)
        # Independent pg_stat_activity proves SQL actually entered, not merely queued in Java.
        active=wait_until(lambda: db.sql("SELECT pid||':'||wait_event||':'||query FROM pg_stat_activity WHERE application_name='"+db.schema+"' AND state='active' AND query LIKE 'SELECT pg_sleep%'"),seconds=5)
        server.process.send_signal(signal.SIGTERM)
        wait_until(lambda:any(x['event']=='admission-closed' for x in server.journal_rows()),seconds=4)
        try:new_status=CapClient(server.port).get('/caps/orders')[0]
        except OSError as error:new_status=type(error).__name__
        try:
            response=future.result(timeout=10);body=decode(response);old_status=response[0]
        except (OSError,http.client.HTTPException) as error:old_status=type(error).__name__;body=None
        server.process.wait(timeout=18)
    after=db.snapshot('after-sigterm');rows=[r for r in after['orders'] if r['idem_key']=='sigterm'];assert len(rows)==1 and rows[0]['status']=='CREATED',after
    journal=server.journal_rows();admission=next(x for x in journal if x['event']=='admission-closed');assert int(admission['detail'].split('=')[1])>=1,admission
    assert any(x['event']=='new-task-rejected' and x['detail']=='true' for x in journal)
    REPORT['sigterm']={'activeSql':active,'existingStatus':old_status,'existingResponse':body,'newConnectionOutcome':new_status,'admission':admission,'persistedOrder':rows[0]}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',required=True);parser.add_argument('--container',default='play-db-lab-20261003-pipeline-43');parser.add_argument('--pg-port',type=int,default=35711);args=parser.parse_args()
    out=pathlib.Path(args.out).resolve();out.mkdir(parents=True,exist_ok=False);db=Database(args,out);REPORT['schema']=db.schema
    try:
        REPORT['postgresVersion']=db.sql('SELECT version()');REPORT['databaseDefaultIsolation']=db.sql('SHOW default_transaction_isolation')
        with slow_server(out) as downstream:
            with Server(out,'first',db,downstream) as server:ids=matrix(server,db)
            with Server(out,'second',db,downstream) as server:restart_and_shutdown(server,db,ids)
        REPORT['result']='PASS'
    except BaseException:
        REPORT['result']='FAIL';REPORT['failure']=traceback.format_exc();raise
    finally:
        try:db.sql('DROP SCHEMA IF EXISTS '+db.schema+' CASCADE');REPORT['fixturePreserved']=db.sql('SELECT 1')=='1'
        finally:
            (out/'http.json').write_text(json.dumps(NETWORK,indent=2))
            (out/'observations.json').write_text(json.dumps(REPORT,indent=2))
    print(json.dumps({'result':REPORT['result'],'schema':db.schema,'fixturePreserved':REPORT['fixturePreserved']}))
if __name__=='__main__':main()
