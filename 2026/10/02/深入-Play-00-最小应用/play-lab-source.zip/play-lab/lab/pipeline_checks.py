#!/usr/bin/env python3
import argparse
import json

from verify import ROOT, http_checks


def checks(check):
    cases = []

    def case(name, path, status, body=b"{}", *, content_type="application/json",
             token="allow", blocked=False, method="POST", parser=None, business=0):
        ident = "pipeline-" + name
        headers = {"X-Pipeline-Id": ident, "X-Lab-Token": token,
                   "Content-Type": content_type}
        if blocked:
            headers["X-Pipeline-Block"] = "yes"
        response = check(path, status, method=method, body=body, headers=headers)
        stats = json.loads(check(f"/pipeline/stats?id={ident}")["body"])
        events = [event.removeprefix(ident + ":") for event in stats["events"]]
        assert stats["requestBusinessCalls"] == business, (name, stats)
        if parser is not None:
            assert stats["parserCalls"] == parser, (name, stats)
        if status != 500:
            assert any(k.lower() == "x-pipeline-security" and v == "applied"
                       for k, v in response["headers"]), response
            assert events[:2] == ["header-enter", "gate-enter"], events
            ordered = [event for event in events if not event.startswith("parser-stream-")]
            assert ordered[-2:] == [f"gate-exit-{status}", f"header-exit-{status}"], events
        cases.append({"case": name, "status": status, "stats": stats,
                      "response": response["body"],
                      "input_bytes": sum(map(len, body)) if isinstance(body, list) else len(body or b""),
                      "chunked": isinstance(body, list)})
        return events, stats

    normal, _ = case("normal", "/pipeline/json", 200, business=1, parser=1)
    stable = [event for event in normal if not event.startswith("parser-stream-")]
    assert stable == ["header-enter", "gate-enter", "parser-apply", "parser-bytes-2",
                      "parser-result-200", "audit-enter", "auth-enter", "business",
                      "auth-exit", "audit-exit", "gate-exit-200", "header-exit-200"], stable
    unauthorized, _ = case("unauthorized", "/pipeline/json", 401, token="deny", parser=1)
    assert "auth-reject" in unauthorized and "business" not in unauthorized
    for mode in ("sync", "async"):
        events, _ = case(mode, f"/pipeline/json?mode={mode}", 500, business=1, parser=1)
        assert any(event in events for event in ("auth-failed", "auth-sync-failed")), events
        assert any(event in events for event in ("audit-failed", "audit-sync-failed")), events
        assert "header-exit-500" not in events, events
    malformed, _ = case("malformed", "/pipeline/json", 400, b"{", parser=1)
    assert "audit-enter" not in malformed, malformed
    case("unauthorized-malformed", "/pipeline/json", 400, b"{", token="deny", parser=1)
    case("empty-json", "/pipeline/json", 200, b"", business=1, parser=1)
    assert json.loads(cases[-1]["response"])["body"] is None
    wrong_type, stats = case("wrong-type", "/pipeline/json", 415,
                             content_type="text/plain", parser=1)
    assert stats["parserBytes"] == 0 and "audit-enter" not in wrong_type
    exact = ('"' + "中" * 10 + '"').encode("utf-8")
    assert len(exact) == 32
    case("json-32", "/pipeline/json", 200, exact, business=1, parser=1)
    for name, body in (("json-33", ('"' + "中" * 10 + 'x"').encode("utf-8")),
                       ("json-35", ('"' + "中" * 11 + '"').encode("utf-8"))):
        events, stats = case(name, "/pipeline/json", 413, body, parser=1)
        assert stats["parserBytes"] == 0 and "audit-enter" not in events
    chunks = [exact[:16], exact[16:] + b"xxx"]
    _, stats = case("chunked-over", "/pipeline/json", 413, chunks, parser=1)
    assert stats["parserBytes"] > 32, stats
    case("chunked-exact", "/pipeline/json", 200, [exact[:16], exact[16:]], business=1, parser=1)
    for name, body in (("defer-malformed", b"{"), ("defer-too-large", b"x" * 35)):
        events, stats = case(name, "/pipeline/deferred", 401, body, token="deny", parser=0)
        assert stats["parserBytes"] == 0 and "auth-reject" in events
    events, _ = case("defer-normal", "/pipeline/deferred", 200, business=1, parser=1)
    assert events.index("auth-enter") < events.index("parser-apply") < events.index("business"), events
    events, _ = case("defer-authorized-malformed", "/pipeline/deferred", 400, b"{", parser=1)
    assert "audit-enter" in events and "business" not in events
    case("gate-short-circuit", "/pipeline/json", 403, b"{", blocked=True, parser=0)
    case("unknown-route", "/pipeline/not-a-route", 404, method="GET", body=None, parser=0)
    case("route-binding", "/orders/no", 400, method="GET", body=None, parser=0)
    for name, body, content_type, status, business in (
        ("text-empty", b"", "text/plain", 200, 1),
        ("text-wrong", b"{}", "application/json", 415, 0),
        ("text-1024", ("中" * 341 + "x").encode("utf-8"), "text/plain; charset=utf-8", 200, 1),
        ("text-1025", ("中" * 341 + "xx").encode("utf-8"), "text/plain; charset=utf-8", 413, 0),
    ):
        case(name, "/pipeline/text", status, body, content_type=content_type, business=business)
    case("text-no-charset", "/pipeline/text", 200, "你好".encode("utf-8"),
         content_type="text/plain", business=1)
    assert json.loads(cases[-1]["response"])["body"] != "你好", cases[-1]
    assert "\ufffd" in json.loads(cases[-1]["response"])["body"], cases[-1]
    case("text-invalid-utf8", "/pipeline/text", 200, b"\xff",
         content_type="text/plain; charset=utf-8", business=1)
    assert json.loads(cases[-1]["response"])["body"] == "\ufffd", cases[-1]
    case("default-malformed", "/pipeline/any", 400, b"{")
    for name, body, content_type, kind in (
        ("default-json", b"{}", "application/json", "json"),
        ("default-text", b"hello", "text/plain", "text"),
        ("default-raw", b"abc", "application/octet-stream", "raw"),
        ("default-empty", b"", "application/json", "empty"),
    ):
        case(name, "/pipeline/any", 200, body, content_type=content_type, business=1)
        assert json.loads(cases[-1]["response"])["kind"] == kind, cases[-1]
    return {"pipeline_cases": cases, "pipeline_case_count": len(cases)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dev", action="store_true")
    args = parser.parse_args()
    http_checks(args.dev, extra_checks=checks, evidence=ROOT / "evidence/batch06-08")
