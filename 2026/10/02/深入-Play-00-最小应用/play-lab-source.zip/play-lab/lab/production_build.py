from pathlib import Path
import argparse
import os
import signal
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--log', type=Path, required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
args.log.parent.mkdir(parents=True, exist_ok=True)
command = ['bash', str(root/'sbtw'), 'clean', 'test', 'stage', 'dist', 'show Compile / dependencyClasspath']
with args.log.open('w') as log:
    print('COMMAND', command, file=log, flush=True)
    started = time.monotonic()
    process = subprocess.Popen(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        code = process.wait(timeout=480)
    except BaseException:
        os.killpg(process.pid, signal.SIGTERM)
        try: process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL); process.wait(timeout=5)
        raise
    finally:
        print('PROCESS_TERMINATED', process.poll() is not None, 'SECONDS', time.monotonic()-started, file=log)
    print('EXIT_CODE', code, file=log)
print('BUILD_EXIT', code, args.log)
raise SystemExit(code)
