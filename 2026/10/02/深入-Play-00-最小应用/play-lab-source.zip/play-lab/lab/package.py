#!/usr/bin/env python3
import hashlib
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
destination = root.parents[1] / "source/_posts/2026-10-02-深入-Play-00-最小应用"
destination.mkdir(parents=True, exist_ok=True)
archive = destination / "play-lab-source.zip"
excluded = {"target", ".tools", ".bsp", ".metals", "__pycache__"}
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as output:
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if (path.is_file() and not excluded.intersection(relative.parts)
                and relative.parts[:2] != ("project", "project")
                and path.name not in {"RUNNING_PID", "hexo-build.log"}):
            entry = zipfile.ZipInfo("play-lab/" + relative.as_posix(), date_time=(2026, 10, 2, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o644 << 16
            output.writestr(entry, path.read_bytes())
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(destination / "SHA256SUMS").write_text(f"{digest}  {archive.name}\n")
print(f"{archive.name}: {digest}")
