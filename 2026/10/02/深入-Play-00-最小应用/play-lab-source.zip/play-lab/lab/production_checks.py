import argparse
import concurrent.futures
import hashlib
import http.client
import http.server
import json
import os
from pathlib import Path
import secrets
import shutil
import signal
import socket
import subprocess
import threading
import time
import zipfile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--container', required=True)
    parser.add_argument('--jdbc-url', required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    evidence = args.evidence.resolve()
    evidence.mkdir(parents=True, exist_ok=False)
    java_home = os.environ['JAVA_HOME']
    assert Path(java_home, 'bin/java').is_file()
    records, sql_records, servers = [], [], []
    summary = {'status': 'FAIL'}
    schema = 'prod_' + secrets.token_hex(6)
    podman = shutil.which('podman')
    assert podman, 'podman must be available on PATH'

    def record(name, **data):
        records.append({'scenario': name, **data})

    def sql(query):
        result = subprocess.run([podman, 'exec', args.container, 'psql', '-U', 'postgres', '-d', 'play_lab',
                                 '-v', 'ON_ERROR_STOP=1', '-Atc', query], capture_output=True, text=True, timeout=12)
        sql_records.append({'query': query, 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
        result.check_returncode()
        return result.stdout.strip()

    def free_port():
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 0))
            return sock.getsockname()[1]

    def call(port, path):
        connection = http.client.HTTPConnection('127.0.0.1', port, timeout=10)
        try:
            connection.request('GET', path)
            response = connection.getresponse()
            first = time.monotonic()
            body = response.read()
            return response.status, body, first
        finally:
            connection.close()

    def wait_until(predicate, seconds=15):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            try:
                if predicate(): return
            except (OSError, http.client.HTTPException): pass
            time.sleep(.05)
        raise AssertionError('condition did not become true')

    class Server:
        def __init__(self, directory, name, label=None, external=False):
            self.port, self.name = free_port(), name
            self.journal = evidence / (name + '.journal.jsonl')
            conf = evidence / (name + '.conf')
            config = 'include "production.conf"\n'
            config += 'prod.enabled=true\nprod.schema=' + json.dumps(schema) + '\n'
            config += 'prod.url=' + json.dumps(args.jdbc_url + ('&' if '?' in args.jdbc_url else '?') + 'ApplicationName=' + schema) + '\n'
            config += 'prod.journal=' + json.dumps(str(self.journal)) + '\n'
            config += 'play.server.http.address="127.0.0.1"\nplay.server.terminationTimeout=10s\n'
            config += 'pekko.coordinated-shutdown.phases.service-requests-done.timeout=12s\n'
            if external: config += 'prod.label="external"\n'
            conf.write_text(config)
            script = next(p for p in (directory / 'bin').iterdir() if not p.name.endswith('.bat'))
            command = ['bash', str(script), '-Dconfig.file=' + str(conf), '-Dhttp.port=' + str(self.port),
                       '-Dpidfile.path=' + str(evidence / (name + '.pid'))]
            if label: command.append('-Dprod.label=' + label)
            env = {**os.environ, 'JAVA_HOME': java_home, 'APPLICATION_SECRET': secrets.token_hex(32), 'PROD_LABEL': 'environment'}
            self.log = (evidence / (name + '.log')).open('w')
            self.process = subprocess.Popen(command, cwd=directory, env=env, stdout=self.log, stderr=subprocess.STDOUT)
            servers.append(self)
            wait_until(lambda: call(self.port, '/production/health')[0] == 200, 40)
            status, body, _ = call(self.port, '/production/ready')
            state = json.loads(body)
            assert status == 200 and state['ready'] and state['databaseValid'], state
            assert str(directory) in state['probeJar'], state
            assert 'PekkoHttpServerProvider' in state['provider'], state
            record(name + '-startup', status=status, state=state, pid=self.process.pid)

        def stop(self, kill=False):
            if self.process.poll() is not None:
                self.log.close()
                return
            began = time.monotonic()
            self.process.send_signal(signal.SIGKILL if kill else signal.SIGTERM)
            try:
                code = self.process.wait(timeout=18)
                with socket.socket() as listener:
                    listener.settimeout(1)
                    listener_closed = listener.connect_ex(('127.0.0.1', self.port)) != 0
                record(self.name + '-exit', signal='SIGKILL' if kill else 'SIGTERM', code=code, seconds=time.monotonic()-began, listenerClosed=listener_closed)
                assert listener_closed
                assert code in (-9, 137) if kill else code in (-15, 143), code
            except BaseException:
                if self.process.poll() is None:
                    self.process.kill(); self.process.wait(timeout=5)
                raise
            finally:
                self.log.close()

    class Proxy(http.server.BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.1'
        def log_message(self, *unused): pass
        def do_GET(self):
            backend = http.client.HTTPConnection('127.0.0.1', self.server.backend, timeout=12)
            try:
                backend.request('GET', self.path, headers={'Host': 'localhost'})
                response = backend.getresponse()
                self.send_response(response.status)
                self.send_header('Connection', 'close')
                self.end_headers()
                self.close_connection = True
                while True:
                    part = response.read1(32768)
                    if not part: break
                    self.wfile.write(part); self.wfile.flush()
            except (OSError, http.client.HTTPException):
                self.close_connection = True
            finally: backend.close()

    proxy = None
    try:
        sql('CREATE SCHEMA ' + schema)
        archive = next((root / 'target/universal').glob('*.zip'))
        unpack = root / 'target/production-unpacked'
        assert not unpack.exists(), 'preserve prior unpacked runs; clean or choose fresh build first'
        with zipfile.ZipFile(archive) as zipped: zipped.extractall(unpack)
        directory = next(p for p in unpack.iterdir() if p.is_dir())
        stage = root / 'target/universal/stage'
        hashes = {}
        for file in stage.rglob('*'):
            if file.is_file():
                relative = file.relative_to(stage)
                other = directory / relative
                assert other.is_file() and file.read_bytes() == other.read_bytes(), relative
                hashes[str(relative)] = hashlib.sha256(file.read_bytes()).hexdigest()
        (evidence / 'artifact.json').write_text(json.dumps({'archive': archive.name,
            'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'files': hashes}, indent=2))
        record('stage-dist-byte-equality', files=len(hashes), sourceDirectoriesPresent=any((directory/p).exists() for p in ['app','test','project']))
        staged = Server(stage, 'stage-system', 'system')
        assert json.loads(call(staged.port, '/production/state')[1])['label'] == 'system'
        assert call(staged.port, '/production/drain')[0] == 200
        assert call(staged.port, '/production/ready')[0] == 503
        assert call(staged.port, '/production/health')[0] == 200
        assert call(staged.port, '/production/work?id=drained&millis=0')[0] == 503
        record('readiness-drain', health=200, ready=503, work=503)
        staged.stop()
        dist = Server(directory, 'dist-graceful', external=True)
        assert json.loads(call(dist.port, '/production/state')[1])['label'] == 'external'
        proxy = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Proxy)
        proxy.backend = dist.port
        thread = threading.Thread(target=proxy.serve_forever, daemon=True); thread.start()
        pp = proxy.server_port
        for path in ['/production/health', '/production/ready']:
            status, body, _ = call(pp, path)
            assert status == 200
            record('proxy-' + path.rsplit('/', 1)[1], status=status, body=body.decode())
        stream = http.client.HTTPConnection('127.0.0.1', pp, timeout=8)
        start = time.monotonic(); stream.request('GET', '/production/stream?chunks=8'); response = stream.getresponse()
        first = response.read(32768); first_at = time.monotonic(); remainder = response.read(); ended = time.monotonic(); stream.close()
        assert response.status == 200 and len(first)+len(remainder) == 262144 and ended-first_at > .12
        assert first + remainder == bytes(262144)
        record('proxy-stream', bytes=len(first)+len(remainder), firstSeconds=first_at-start, totalSeconds=ended-start, sha256=hashlib.sha256(first+remainder).hexdigest())
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as requests:
            pending = requests.submit(call, pp, '/production/work?id=graceful&millis=1800')
            wait_until(lambda: dist.journal.exists() and 'inserted-uncommitted' in dist.journal.read_text())
            assert sql('SELECT count(*) FROM ' + schema + ".orders WHERE id='graceful'") == '0'
            dist.stop()
            status, body, _ = pending.result(timeout=3)
            assert status == 200 and json.loads(body)['committed']
            assert sql('SELECT count(*) FROM ' + schema + ".orders WHERE id='graceful'") == '1'
            assert 'cleanup-done' in dist.journal.read_text()
            record('sigterm-inflight', status=status, body=json.loads(body), committedRows=1)
        killed = Server(directory, 'dist-killed')
        assert json.loads(call(killed.port, '/production/state')[1])['label'] == 'environment'
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as requests:
            pending = requests.submit(call, killed.port, '/production/work?id=killed&millis=3500')
            wait_until(lambda: killed.journal.exists() and 'inserted-uncommitted' in killed.journal.read_text())
            assert sql('SELECT count(*) FROM ' + schema + ".orders WHERE id='killed'") == '0'
            killed.stop(kill=True)
            try: pending.result(timeout=5)
            except (OSError, http.client.HTTPException) as error: request_error = type(error).__name__
            else: raise AssertionError('killed request unexpectedly completed')
            assert 'cleanup-done' not in killed.journal.read_text()
            assert killed.journal.with_suffix(killed.journal.suffix + '.resource').exists()
            wait_until(lambda: sql("SELECT count(*) FROM pg_stat_activity WHERE application_name='" + schema + "'") == '0', 10)
            assert sql('SELECT count(*) FROM ' + schema + ".orders WHERE id='killed'") == '0'
            record('sigkill-uncommitted', requestError=request_error, rows=0, cleanupEvent=False, resourceFileRemains=True)
        restored = Server(directory, 'dist-recovery')
        assert call(restored.port, '/production/work?id=recovered&millis=0')[0] == 200
        restored.stop()
        assert sql('SELECT string_agg(id,\',\' ORDER BY id) FROM ' + schema + '.orders') == 'graceful,recovered'
        assert sql("SELECT count(*) FROM pg_stat_activity WHERE application_name='" + schema + "'") == '0'
        record('same-artifact-recovery', rows=['graceful', 'recovered'], remainingConnections=0)
        summary.update(status='PASS', scenarios=len(records), schema=schema)
    finally:
        cleanup_errors = []
        for server in servers:
            try: server.stop()
            except BaseException as error: cleanup_errors.append(repr(error))
        if proxy:
            proxy.shutdown(); proxy.server_close(); thread.join(timeout=3)
        try: sql('DROP SCHEMA IF EXISTS ' + schema + ' CASCADE')
        except BaseException as error: cleanup_errors.append(repr(error))
        if cleanup_errors: summary.update(status='FAIL', cleanupErrors=cleanup_errors)
        for name, data in [('summary.json', summary), ('observations.json', records), ('sql.json', sql_records)]:
            (evidence/name).write_text(json.dumps(data, ensure_ascii=False, indent=2))
        if cleanup_errors: raise RuntimeError(cleanup_errors)
    print(json.dumps(summary))


if __name__ == '__main__': main()
