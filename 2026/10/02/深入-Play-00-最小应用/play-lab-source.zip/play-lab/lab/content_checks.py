#!/usr/bin/env python3
import argparse
import concurrent.futures
from html.parser import HTMLParser
import json
import threading
from urllib.parse import urlencode

from pipeline_checks import checks as pipeline_checks
from verify import ROOT, http_checks


class FormPage(HTMLParser):
    def __init__(self, body):
        super().__init__()
        self.action = None
        self.values = {}
        self.feed(body)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "form":
            self.action = attrs["action"]
        if tag == "input":
            self.values[attrs["name"]] = attrs.get("value", "")


def checks(check, development):
    result = pipeline_checks(check)
    cases = []
    json_headers = {"Content-Type": "application/json"}

    def json_case(name, data, status=400, expected=None):
        response = check("/content/json", status, method="POST",
                         body=json.dumps(data).encode("utf-8"), headers=json_headers)
        value = json.loads(response["body"])
        assert value == (expected if expected is not None else {"code": "INVALID_INPUT"}), value
        cases.append({"case": name, "status": status, "output": value})

    valid = {"name": "Ada", "amount": "12.34"}
    json_case("valid", valid, 201, valid)
    json_case("normalization", {"name": "Ada", "amount": "12"}, 201,
              {"name": "Ada", "amount": "12.00"})
    for name, data in (("root-null", None), ("root-array", []), ("missing", {}),
                       ("explicit-null", {"name": None, "amount": "1"}),
                       ("unknown", {**valid, "internalId": "private"}),
                       ("blank", {**valid, "name": " "}),
                       ("name-41", {**valid, "name": "x" * 41}),
                       ("amount-number", {**valid, "amount": 12.34})):
        json_case(name, data)
    for money in ("0", "-1", "0.001", "1e2", "", "01", "1000000000", "9007199254740993.01", "x" * 100):
        json_case("money-" + (money if len(money) < 30 else "long"), {**valid, "amount": money})
    unicode_name = "😀" * 40
    json_case("unicode-40", {"name": unicode_name, "amount": "1"}, 201,
              {"name": unicode_name, "amount": "1.00"})
    json_case("unicode-41", {"name": unicode_name + "😀", "amount": "1"})
    for name, body, content_type, status in (
        ("json-malformed", b"{", "application/json", 400),
        ("json-empty", b"", "application/json", 400),
        ("json-wrong-type", b"{}", "text/plain", 415),
        ("json-over-limit", b" " * 1025, "application/json", 413),
    ):
        response = check("/content/json", status, method="POST", body=body,
                         headers={"Content-Type": content_type})
        assert json.loads(response["body"]) == {"code": "INVALID_INPUT"}, response
        cases.append({"case": name, "status": status})
    duplicate = check("/content/json", 201, method="POST",
                      body=b'{"name":"first","name":"last","amount":"1"}', headers=json_headers)
    assert json.loads(duplicate["body"]) == {"name": "last", "amount": "1.00"}, duplicate
    cases.append({"case": "duplicate-json-key-folded", "status": 201,
                  "output": json.loads(duplicate["body"])})
    mapper = json.loads(check("/content/json/mapper")["body"])
    assert mapper["injectedNodeClass"] == mapper["activeNodeClass"] == "DoubleNode", mapper
    assert mapper["stringDecimal"] == mapper["literal"] != mapper["activeTreeText"], mapper
    assert not mapper["injectedBigDecimalForFloats"] and not mapper["activeBigDecimalForFloats"], mapper

    def stock():
        return json.loads(check("/content/stock")["body"])["remaining"]

    def reset():
        assert json.loads(check("/content/stock/reset", method="POST")["body"])["remaining"] == 1

    def form_case(name, values, code, status=400, path="/content/form"):
        response = check(path, status, method="POST", body=urlencode(values).encode(),
                         headers={"Content-Type": "application/x-www-form-urlencoded"})
        assert f'id="result-code">{code}</p>' in response["body"], response
        assert stock() == 1
        cases.append({"case": name, "status": status, "code": code})
        return response

    reset()
    for name, values, code in (
        ("form-missing", [("quantity", "1"), ("confirmation", "1")], "FORM_INVALID"),
        ("form-empty", [("name", ""), ("quantity", "1"), ("confirmation", "1")], "FORM_INVALID"),
        ("form-blank", [("name", " "), ("quantity", "1"), ("confirmation", "1")], "FORM_INVALID"),
        ("form-number", [("name", "Ada"), ("quantity", "abc"), ("confirmation", "1")], "FORM_INVALID"),
        ("form-range", [("name", "Ada"), ("quantity", "0"), ("confirmation", "0")], "FORM_INVALID"),
        ("form-cross", [("name", "Ada"), ("quantity", "1"), ("confirmation", "2")], "FORM_INVALID"),
        ("form-duplicate", [("name", "Ada"), ("quantity", "1"), ("quantity", "5"), ("confirmation", "1")], "DUPLICATE_FIELD"),
        ("form-extra", [("name", "Ada"), ("quantity", "1"), ("confirmation", "1"), ("admin", "true")], "UNKNOWN_FIELD"),
    ):
        response = form_case(name, values, code)
        if name == "form-number":
            assert FormPage(response["body"]).values["quantity"] == "abc"
        if name == "form-duplicate":
            assert 'data-field="quantity">1</li>' in response["body"]
            assert 'data-field="quantity">5</li>' in response["body"]
    form_case("post-query-not-bound", [("quantity", "1"), ("confirmation", "1")],
              "FORM_INVALID", path="/content/form?name=Ada")
    evil = '<script>window.formProbe=1</script>'
    response = form_case("raw-input-retained", [("name", evil), ("quantity", "abc"), ("confirmation", "1")], "FORM_INVALID")
    assert FormPage(response["body"]).values["name"] == evil
    assert evil not in response["body"] and "&lt;script&gt;" in response["body"]
    form_case("form-utf16-length-42", [("name", "😀" * 21), ("quantity", "1"),
                                      ("confirmation", "1")], "FORM_INVALID")
    ordinary = []
    for quantities in (("1", "5"), ("5", "1")):
        values = [("name", "Ada"), *(('quantity', v) for v in quantities), ("confirmation", quantities[0])]
        response = check("/content/form/ordinary", method="POST", body=urlencode(values),
                         headers={"Content-Type": "application/x-www-form-urlencoded"})
        bound = json.loads(response["body"])
        assert not bound["hasErrors"] and bound["data"]["quantity"] == quantities[0], bound
        ordinary.append(bound)
    assert stock() == 1
    barrier = threading.Barrier(2)

    def racing_reserve(_):
        barrier.wait(timeout=5)
        response = check("/content/form", status=(201, 409), method="POST",
                         body=b"name=Ada&quantity=1&confirmation=1",
                         headers={"Content-Type": "application/x-www-form-urlencoded"})
        if response["status"] == 409:
            assert 'id="result-code">STOCK_CONFLICT</p>' in response["body"], response
        return response["status"]

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        statuses = sorted(pool.map(racing_reserve, range(2)))
    assert statuses == [201, 409] and stock() == 0, statuses
    reset()
    page_response = check("/content/form", headers={"X-Play-Lab": ""})
    page = FormPage(page_response["body"])
    assert "csrfToken=" in page.action, page.action
    cookie = "; ".join(v.split(";", 1)[0] for k, v in page_response["headers"] if k.lower() == "set-cookie")
    assert "PLAY_SESSION=" in cookie, page_response
    secure_headers = {"X-Play-Lab": "", "Cookie": cookie,
                      "Content-Type": "application/x-www-form-urlencoded"}
    response = check(page.action, 400, method="POST", body=b"name=Ada&quantity=oops&confirmation=1", headers=secure_headers)
    assert FormPage(response["body"]).values["quantity"] == "oops"
    check("/content/form", 403, method="POST", body=b"name=Ada&quantity=1&confirmation=1", headers=secure_headers)
    assert stock() == 1
    asset = check("/assets/lab.css")
    headers = {k.lower(): v for k, v in asset["headers"]}
    assert headers["content-type"].startswith("text/css"), headers
    assert "etag" in headers and "cache-control" in headers, headers
    if not development:
        assert "max-age=3600" in headers["cache-control"] and "31536000" not in headers["cache-control"], headers
    cached = check("/assets/lab.css", 304, headers={"If-None-Match": headers["etag"]})
    assert cached["body"] == ""
    check("/assets/" + "0" * 32 + "-lab.css", 404)
    for raw in (False, True):
        rendered = check("/content/twirl?raw=" + str(raw).lower())["body"]
        assert ('<img id="twirl-payload"' in rendered) == raw
        assert "window.twirlProbe = [];" in rendered
    result.update({"content_cases": cases, "content_case_count": len(cases),
                   "mapper": mapper, "ordinary_forms": ordinary,
                   "reservation_statuses": statuses, "final_stock": stock(),
                   "asset_headers": headers, "csrf_cookie_transport": "PASS"})
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dev", action="store_true")
    args = parser.parse_args()
    http_checks(args.dev, extra_checks=lambda check: checks(check, args.dev),
                evidence=ROOT / "evidence/batch09-11")
