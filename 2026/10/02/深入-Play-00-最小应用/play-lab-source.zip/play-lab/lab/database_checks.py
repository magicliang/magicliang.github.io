#!/usr/bin/env python3
import argparse
import concurrent.futures
import http.client
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[1]


def finish(processes, evidence, records, sql_records, summary, primary):
    failures = []
    for item in processes:
        try:
            item.stop()
        except BaseException as error:
            failures.append(('stop:' + item.name, error))
    if primary is not None:
        summary['result'] = 'FAIL'
        summary['primaryError'] = repr(primary)
    if failures:
        summary['result'] = 'FAIL'
        summary['cleanupErrors'] = [dict(operation=name, error=repr(error)) for name, error in failures]
    for name, value in [('http-observations.json', records), ('sql-observations.json', sql_records), ('summary.json', summary)]:
        try:
            (evidence / name).write_text(json.dumps(value, indent=2))
        except BaseException as error:
            failures.append(('write:' + name, error))
            summary['result'] = 'FAIL'
            summary['cleanupErrors'] = [dict(operation=operation, error=repr(failure)) for operation, failure in failures]
    if failures:
        message = 'Database experiment cleanup failed: ' + '; '.join(name + '=' + repr(error) for name, error in failures)
        if primary is not None:
            if hasattr(primary, 'add_note'):
                primary.add_note(message)
            print(message, file=sys.stderr)
        else:
            raise RuntimeError(message) from failures[0][1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--container', required=True)
    parser.add_argument('--jdbc-url', required=True)
    args = parser.parse_args()
    evidence = args.evidence.resolve()
    evidence.mkdir(parents=True, exist_ok=True)
    records, processes, sql_records = [], [], []

    def sql(query):
        result = subprocess.run(['podman', 'exec', args.container, 'psql', '-U', 'postgres', '-d', 'play_lab', '-v', 'ON_ERROR_STOP=1', '-Atc', query], capture_output=True, text=True, timeout=12)
        sql_records.append(dict(query=query, exit=result.returncode, stdout=result.stdout, stderr=result.stderr))
        assert result.returncode == 0, sql_records[-1]
        return result.stdout.strip()

    class Server:
        def __init__(self, name, config=None, enabled=True, limited=False):
            with socket.socket() as probe:
                probe.bind(('127.0.0.1', 0))
                self.port = probe.getsockname()[1]
            self.name = name
            self.log = (evidence / (name + '.log')).open('w')
            self.journal = evidence / (name + '.jsonl')
            env = dict(os.environ, PLAY_LAB_DB_ENABLED=str(enabled).lower(), PLAY_LAB_JDBC_URL=args.jdbc_url,
                       PLAY_LAB_OWNER=name, PLAY_LAB_LIFECYCLE_JOURNAL=str(self.journal))
            command = [str(ROOT / 'target/universal/stage/bin/play-lab'), '-J-Xms64m', '-J-Xmx384m',
                       '-Dhttp.address=127.0.0.1', f'-Dhttp.port={self.port}', f'-Dpidfile.path={evidence / (name + ".pid")}']
            if config:
                command.append('-Dconfig.file=' + str(config))
            if limited:
                command.extend(['-Dpekko.actor.default-dispatcher.fork-join-executor.parallelism-min=2', '-Dpekko.actor.default-dispatcher.fork-join-executor.parallelism-max=2'])
            self.process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=self.log, stderr=subprocess.STDOUT)
            processes.append(self)

        def request(self, path, expected=200):
            start = time.monotonic()
            connection = http.client.HTTPConnection('127.0.0.1', self.port, timeout=20)
            try:
                connection.request('GET', path, headers={'X-Play-Lab': 'synthetic'})
                response = connection.getresponse()
                raw = response.read().decode()
                try:
                    body = json.loads(raw)
                except ValueError:
                    body = raw
                record = dict(server=self.name, path=path, status=response.status, body=body, seconds=time.monotonic() - start)
                records.append(record)
                assert response.status in (expected if isinstance(expected, tuple) else (expected,)), record
                return body
            finally:
                connection.close()

        def ready(self):
            deadline = time.monotonic() + 40
            while time.monotonic() < deadline:
                if self.process.poll() is not None:
                    return False
                try:
                    return self.request('/health') == 'play-lab-ok'
                except (OSError, http.client.HTTPException):
                    time.sleep(.1)
            raise TimeoutError('stage startup ' + self.name)

        def stop(self):
            try:
                if self.process.poll() is None:
                    self.process.send_signal(signal.SIGTERM)
                    try:
                        self.process.wait(timeout=18)
                    except subprocess.TimeoutExpired:
                        self.process.kill()
                        self.process.wait(timeout=3)
                        raise AssertionError('SIGTERM exceeded deadline: ' + self.name)
            finally:
                self.log.close()
            return self.process.returncode

        def verify_journal(self):
            events = [json.loads(line) for line in self.journal.read_text().splitlines()]
            names = [row['event'] for row in events]
            assert [name for name in names if name in ['drain-start', 'drain-end', 'sync-failure', 'async-failure', 'final-cleanup']] == ['drain-start', 'drain-end', 'sync-failure', 'async-failure', 'final-cleanup'], events
            assert 'fileClosed=true,workerTerminated=true,schedulerTerminated=true' in events[-1]['detail'], events
            assert 'poolClosed=true' in events[-1]['detail'], events
            assert any('committed-inserted-' in row['detail'] for row in events if row['event'] == 'task-terminal'), events
            return events

    summary = {}
    try:
        summary['postgresVersion'] = sql('SELECT version()')
        disabled = Server('db-disabled', enabled=False)
        assert disabled.ready()
        assert disabled.request('/db/pools', 503)['code'] == 'DB_DISABLED'
        disabled.stop()
        limited = Server('jdbc-saturation', limited=True)
        assert limited.ready()
        summary['interruptedCleanup'] = limited.request('/db/interrupted-cleanup')
        assert summary['interruptedCleanup']['poolClosed'] and summary['interruptedCleanup']['executorTerminated'] and summary['interruptedCleanup']['interrupted'] and summary['interruptedCleanup']['suppressed'] == 1
        summary['saturation'] = []
        for dedicated in ['false', 'true']:
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
                pending = pool.submit(limited.request, '/db/load?dedicated=' + dedicated)
                deadline = time.monotonic() + 5
                query = "SELECT count(*) FROM pg_stat_activity WHERE datname='play_lab' AND wait_event='PgSleep' AND query LIKE '%jdbc_load_%' AND pid<>pg_backend_pid()"
                while sql(query) != '2':
                    assert time.monotonic() < deadline, 'two JDBC queries did not overlap'
                    time.sleep(.01)
                start_index = len(records)
                health = [limited.request('/health') for _ in range(3)]
                light = [row for row in records[start_index:] if row['server'] == 'jdbc-saturation' and row['path'] == '/health']
                result = pending.result(timeout=10)
                assert result['configuredDefaultMin'] == 2 and result['configuredDefaultMax'] == 2
                assert len(result['tasks']) == 2 and all(row['selectOne'] == 1 for row in result['tasks'])
                summary['saturation'].append(dict(dedicated=dedicated, activeSqlObserved=2, load=result, light=light, responses=health))
        limited.stop()
        server = Server('database-main')
        assert server.ready()
        for case in ['pools', 'transactions', 'evolutions']:
            summary[case] = server.request('/db/' + case)
        assert summary['pools']['executor4']['waitingForConnection'] == 2
        assert summary['pools']['executor2']['executorQueued'] == 2
        order = server.request('/db/order/prepare')
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(server.request, '/db/order?id=' + order['id'] + '&key=same&payload=p', (200, 201)) for _ in range(2)]
            same_key = [future.result(timeout=10) for future in futures]
        conflict = server.request('/db/order?id=' + order['id'] + '&key=same&payload=changed', 409)
        assert sorted(row['outcome'] for row in same_key) == ['CREATED', 'REPLAY'] and conflict['orders'] == 1 and conflict['remaining'] == 0
        summary['httpIdempotency'] = dict(sameKey=same_key, changedPayload=conflict)
        summary['httpLateCommit'] = []
        for committed in [False, True]:
            late = server.request('/db/late/start?committed=' + str(committed).lower(), 504)
            before = server.request('/db/late/status?id=' + late['id'])
            after = server.request('/db/late/status?id=' + late['id'] + '&release=true&retry=true')
            assert late['taskDoneAtResponse'] is False and before['ordersOnNewConnection'] == int(committed) and after['ordersOnNewConnection'] == 1 and after['retryInserted'] == 0
            summary['httpLateCommit'].append(dict(commitBeforeResponse=committed, response=late, before=before, after=after))
        key = 'sigterm_' + uuid.uuid4().hex
        started = server.request('/db/background/start?key=' + key + '&millis=1500')
        deadline = time.monotonic() + 5
        while sql("SELECT count(*) FROM pg_stat_activity WHERE datname='play_lab' AND wait_event='PgSleep'") == '0':
            assert time.monotonic() < deadline
        exit_code = server.stop()
        assert sql("SELECT count(*) FROM lab_background WHERE business_key='" + key + "'") == '1'
        summary['sigterm'] = dict(started=started, exit=exit_code, events=server.verify_journal(), committedRows=1)
        first, second = Server('background-first'), Server('background-second')
        assert first.ready() and second.ready()
        key = 'shared_' + uuid.uuid4().hex
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda item: item.request('/db/background/start?key=' + key + '&millis=300'), [first, second]))
        first.stop(); second.stop()
        journals = [first.verify_journal(), second.verify_journal()]
        assert sql("SELECT count(*) FROM lab_background WHERE business_key='" + key + "'") == '1'
        terminals = [row['detail'] for journal in journals for row in journal if row['event'] == 'task-terminal']
        assert sum('committed-inserted-1' in value for value in terminals) == 1 and sum('committed-inserted-0' in value for value in terminals) == 1
        summary['twoBackgroundInstances'] = dict(starts=results, terminals=terminals, committedRows=1)

        def migration(name, auto=None, prelock=False):
            schema = 'm_' + uuid.uuid4().hex
            sql('CREATE SCHEMA ' + schema)
            if prelock:
                sql('CREATE TABLE ' + schema + '.play_evolutions_lock(lock int PRIMARY KEY); INSERT INTO ' + schema + '.play_evolutions_lock VALUES(1)')
            scripts = evidence / name / 'default'
            scripts.mkdir(parents=True)
            (scripts / '1.sql').write_text('# --- !Ups\nCREATE TABLE items(id integer PRIMARY KEY, name text);\nINSERT INTO items VALUES(1,\'old\');\nSELECT pg_sleep(0.6);\n# --- !Downs\nDROP TABLE items;\n')
            config = evidence / (name + '.conf')
            lines = [f'include "{ROOT / "conf/application.conf"}"', 'db.default {', 'driver="org.postgresql.Driver"',
                     'url=' + json.dumps(args.jdbc_url + '&currentSchema=' + schema), 'username="postgres"', 'password="lab-only-password"',
                     'hikaricp.maximumPoolSize=2', 'hikaricp.minimumIdle=2', 'hikaricp.connectionTimeout=2s', '}',
                     'play.evolutions.path=' + json.dumps(str(scripts.parent)), 'play.evolutions.useLocks=true', 'play.evolutions.schema=' + json.dumps(schema)]
            if auto is not None:
                lines.append('play.evolutions.autoApply=' + str(auto).lower())
            config.write_text('\n'.join(lines) + '\n')
            return schema, config, scripts

        schema, config, scripts = migration('production-default')
        rejected = Server('production-default-rejected', config)
        assert not rejected.ready()
        summary['productionDefault'] = dict(exit=rejected.stop(), tables=sql("SELECT count(*) FROM information_schema.tables WHERE table_schema='" + schema + "' AND table_name='items'"))
        assert summary['productionDefault']['exit'] != 0 and summary['productionDefault']['tables'] == '0'
        with config.open('a') as output:
            output.write('play.evolutions.autoApply=true\n')
        for name in ['empty', 'restart']:
            instance = Server('migration-' + name, config)
            assert instance.ready()
            summary['migration-' + name] = sql('SELECT id,state FROM ' + schema + '.play_evolutions ORDER BY id')
            instance.stop()
        (scripts / '2.sql').write_text('# --- !Ups\nALTER TABLE items ADD COLUMN label text;\nUPDATE items SET label=name;\nALTER TABLE items ALTER COLUMN label SET NOT NULL;\n# --- !Downs\nALTER TABLE items DROP COLUMN label;\n')
        instance = Server('migration-revision-two', config)
        assert instance.ready()
        summary['migrationRevisionTwo'] = dict(metadata=sql('SELECT id,state FROM ' + schema + '.play_evolutions ORDER BY id'), data=sql('SELECT id,name,label FROM ' + schema + '.items'), notNull=sql("SELECT is_nullable FROM information_schema.columns WHERE table_schema='" + schema + "' AND table_name='items' AND column_name='label'"))
        instance.stop()
        summary['lockRaces'] = []
        for prelock in [False, True]:
            name = 'lock-existing' if prelock else 'lock-initial'
            schema, config, _ = migration(name, True, prelock)
            instances = [Server(name + '-a', config), Server(name + '-b', config)]
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
                ready = list(pool.map(lambda item: item.ready(), instances))
            exits = [item.stop() for item in instances]
            observed = dict(preexistingLockTable=prelock, ready=ready, exits=exits, metadata=sql('SELECT id,state FROM ' + schema + '.play_evolutions'), rows=sql('SELECT count(*) FROM ' + schema + '.items'))
            assert any(ready) and observed['rows'] == '1', observed
            if prelock:
                assert all(ready), observed
            summary['lockRaces'].append(observed)
        summary['result'] = 'PASS'
    finally:
        finish(processes, evidence, records, sql_records, summary, sys.exc_info()[1])
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
