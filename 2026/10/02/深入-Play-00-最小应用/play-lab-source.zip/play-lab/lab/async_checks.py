#!/usr/bin/env python3
import argparse
import json

from content_checks import checks as content_checks
from verify import ROOT, http_checks


def checks(check, development=False):
    result = content_checks(check, development)
    reports = {}

    def report(path, status=200):
        value = json.loads(check(path, status)["body"])
        reports[path] = value
        return value

    composition = report("/async/composition")
    assert composition["serialPriceCallsBeforeInventory"] == 0
    assert composition["serialPriceCallsAfterInventory"] == 1
    assert composition["parallelStartedBeforeRelease"] == 2
    assert composition["parallelCompletedBeforeRelease"] is False
    assert composition["serialResult"] == composition["parallelResult"] == "stock:price"
    execution = report("/async/execution")
    assert execution["completedFutureInvocationReturnedBeforeRelease"] is False
    assert execution["supplyAsyncInvocationReturnedBeforeRelease"] is True
    assert execution["supplyAsyncStageDoneBeforeRelease"] is False
    assert execution["completedFutureWorkThread"] == "lab-caller"
    assert execution["supplyAsyncWorkThread"] == "lab-worker"
    assert execution["pendingThenApplyThread"] == "lab-caller"
    assert execution["completedThenApplyThread"] == execution["driverThread"]
    assert execution["explicitThenApplyAsyncThread"] == "lab-worker"
    for mode, status, code in (("ok", 200, "OK"), ("sync", 500, "ASYNC_FAILURE"),
                               ("failed", 500, "ASYNC_FAILURE"), ("unknown", 400, "UNKNOWN_MODE")):
        value = report("/async/result?mode=" + mode, status)
        assert value["code"] == code
        if mode != "ok":
            assert set(value) == {"code"}
    placement = report("/async/placement")
    assert "default-dispatcher" in placement["default"]["thread"]
    assert "lab-blocking-dispatcher" in placement["dedicated"]["thread"]
    assert placement["default"]["inFlightBeforeRelease"] == 1
    assert placement["dedicated"]["inFlightBeforeRelease"] == 1
    for key, prefix in (("cpuDefault", "default-dispatcher"),
                        ("cpuDedicated", "lab-blocking-dispatcher")):
        assert prefix in placement[key]["thread"]
        assert placement[key]["inputSize"] == 100000
        assert placement[key]["checksum"] == 333338333350000
    pekko = report("/async/pekko")
    assert pekko["activeBeforeFourth"] == 2 and pekko["pendingBeforeFourth"] == 1
    assert pekko["thirdStartedBeforeRelease"] is False
    assert pekko["fourthCallerRuns"] is True
    assert pekko["driverThread"] == pekko["fourthThread"]
    assert pekko["activeDuringFourth"] == 3 and pekko["completedAfterRelease"] == 4
    assert pekko["inFlightAfterRelease"] == 0 and pekko["actorSystemTerminated"] is True
    abort = report("/async/abort", 503)
    assert abort["activeBeforeFourth"] == 2 and abort["queueBeforeFourth"] == 1
    assert abort["fourthStatus"] == 503 and abort["completedAfterRelease"] == 3
    assert abort["inFlightAfterRelease"] == abort["queueAfterRelease"] == 0
    assert abort["terminated"] is True
    context = report("/async/context")
    assert context["aliceResult"] == "ok" and context["bobResult"] == "failed"
    assert context["workerAAfterReuse"] == {"worker": "a"}
    assert context["workerBAfterReuse"] == {"worker": "b"}
    assert len(context["events"]) == 4
    for event, user, thread in zip(context["events"], ("alice", "bob", "bob", "alice"),
                                   ("lab-context-a", "lab-context-a", "lab-context-b", "lab-context-b")):
        assert event["user"] == event["requestAttrUser"] == event["mdcUser"] == user
        assert event["requestId"] == event["requestAttrId"] == event["mdcId"]
        assert event["thread"] == thread
    for key in ("originalRequestUnchanged", "callerMdcRestored", "callerClassLoaderRestored"):
        assert context[key] is True
    for key in ("classLoaderNormal", "classLoaderFailure"):
        loader = context[key]
        assert loader["capturedLoaderSeen"] is True and loader["callerMdcCopied"] is False
        assert loader["workerLoaderRestored"] is True and loader["workerMdcRestored"] is True
        assert loader["outcome"] == ("ok" if key == "classLoaderNormal" else "failed")
    timeout = report("/budget/timeout")
    assert timeout["timeoutOutcome"] == "TimeoutException"
    assert timeout["originalDoneAtTimeout"] is False and timeout["originalCancelledAtTimeout"] is False
    assert timeout["lateOutcome"] == "late-success"
    assert timeout["cooperativeTerminal"] == "cooperatively-cancelled"
    assert timeout["cooperativeSideEffects"] == 0 and timeout["workerTerminated"] is True
    assert timeout["retrySuccess"]["attempts"] == timeout["retryExhausted"]["attempts"] == 3
    assert timeout["retrySuccess"]["outcome"] == "ok" and timeout["retryExhausted"]["outcome"] == "failed"
    assert timeout["retryFatal"]["attempts"] == 1 and timeout["retryFatal"]["outcome"] == "failed"
    ws = report("/budget/ws")
    assert ws["originPort"] != ws["targetPort"]
    assert ws["aggregateDoneAfterPrefix"] is False
    assert ws["aggregateBody"] == ws["streamBody"] == "prefix-suffix"
    assert ws["streamResponseDoneBeforeBodyRelease"] is True and ws["streamBodyDoneBeforeRelease"] is False
    assert ws["streamConsumedBytes"] == 13
    assert ws["outerTimeoutOutcome"] == ws["wsTimeoutOutcome"] == "TimeoutException"
    assert ws["wsDoneAtOuterTimeout"] is False and ws["wsCancelledAtOuterTimeout"] is False
    assert ws["outerLateStatus"] == 200 and ws["wsDoneAtOwnTimeout"] is True
    assert ws["redirectDisabledStatus"] == 302 and ws["targetCallsWhenDisabled"] == 0
    assert ws["redirectEnabledStatus"] == 200 and ws["targetCallsWhenEnabled"] == 1
    assert ws["redirectTargetHeaders"] == {"authorization": "Bearer synthetic-only",
                                            "cookie": "lab=synthetic-only", "customCredential": "synthetic-only"}
    assert ws["serverWorkersTerminated"] is True and ws["allGatedHandlersDone"] is True
    boundary = ws["boundaries"]
    assert boundary["effectiveMaxConnectionsPerHost"] == 1
    assert boundary["effectiveMaxConnectionsTotal"] == 2
    assert boundary["plannedLargeBodyBytes"] == 4194304
    assert 0 < boundary["consumedBeforeTakeCancellation"] < boundary["plannedLargeBodyBytes"]
    assert boundary["largeHandlerDone"] is True
    assert boundary["requestAfterCancellationStatus"] == 200
    assert boundary["initialOutside"] == {"outcome": "REJECTED_TARGET", "requestsSent": 0}
    assert boundary["outsideCallsAfterInitialRejection"] == 0
    assert boundary["redirectOutside"] == {"outcome": "REJECTED_TARGET", "requestsSent": 1}
    assert boundary["outsideCallsAfterRedirectRejection"] == 0
    assert boundary["redirectInside"] == {"outcome": "OK", "status": 200, "requestsSent": 2}
    assert boundary["initialOnlyValidationStatus"] == 200
    assert boundary["outsideCallsAfterInitialOnlyValidation"] == 1
    assert boundary["handlersStarted"] == boundary["handlersFinished"] == 11
    assert boundary["clientClosed"] is True and boundary["serverWorkersTerminated"] is True
    assert boundary["deadlineCallerTerminated"] is True
    assert boundary["deadlineTimerTerminated"] is True
    deadline = boundary["deadline"]
    assert deadline["perRequestCapMillis"] == 3000
    assert deadline["allFourHandlersDone"] is True
    assert deadline["handlersForAlreadyExpired"] == 0
    expired = deadline["alreadyExpired"]
    assert expired["outcome"] == "DEADLINE_EXHAUSTED"
    assert expired["requestsSent"] == 0 and expired["requestTimeoutMillis"] == []
    exceeded = deadline["exceededAcrossHops"]
    assert exceeded["outcome"] == "TIMEOUT" and exceeded["failureClass"] == "TimeoutException"
    assert exceeded["requestsSent"] == 2 and exceeded["responseStatuses"] == [302]
    assert exceeded["secondEnteredBeforeOutcome"] is True
    assert exceeded["secondReleasedBeforeOutcome"] is False and exceeded["secondDoneBeforeOutcome"] is False
    assert exceeded["secondIndependentlyReleased"] is True
    assert exceeded["secondReleaseDelayMillis"] == 1350
    assert exceeded["secondReleaseAfterEnteredMillis"] >= 1350
    assert exceeded["firstHandlerTerminal"] == "completed" and exceeded["secondHandlerTerminal"]
    enough = deadline["enoughAcrossHops"]
    assert enough["outcome"] == "OK" and enough["status"] == 200 and enough["body"] == "deadline-ok"
    assert enough["requestsSent"] == 2 and enough["responseStatuses"] == [302, 200]
    assert enough["remainingNanosAtTerminal"] > 0
    assert enough["firstHandlerTerminal"] == enough["secondHandlerTerminal"] == "completed"
    for scenario in (exceeded, enough):
        remaining = scenario["remainingMillisBeforeRequests"]
        configured = scenario["requestTimeoutMillis"]
        assert len(remaining) == len(configured) == 2
        assert 0 < configured[1] < configured[0] <= 3000
        assert all(timeout == min(3000, budget) for timeout, budget in zip(configured, remaining))
    cache = report("/budget/cache")
    assert cache["coldCallers"] == cache["coldCompleted"] == 4
    assert cache["loadsBeforeRelease"] == cache["loadsAfterHot"] == 1
    assert cache["callersDoneBeforeRelease"] == 0 and cache["hotValue"] == "loaded"
    assert cache["failedEntryRemoved"] is True and cache["failureLoaderCalls"] == 2
    assert cache["reloadValue"] == "reloaded"
    assert cache["ttlInitiallyPresent"] is True and cache["ttlExpired"] is True
    assert cache["zeroPresentAfterTtlExpired"] is True
    assert cache["aliceValue"] == "alice-private" and cache["bobValue"] == "bob-private"
    assert cache["beforeUpdateVersion"] == "v1" and cache["afterUpdateVersion"] == "v2"
    assert cache["oldReaderDoneAfterNewSet"] is False
    assert cache["oldReaderLateValue"] == "old-v1" and cache["oldLoaderCalls"] == 1
    assert cache["cacheAfterNewSet"] == cache["cacheAfterOldLoaderCompletes"] == "new-v2"
    assert cache["allExperimentKeysRemoved"] is True and cache["callersTerminated"] is True
    result.update(async_case_count=10, budget_case_count=3, async_reports=reports)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dev", action="store_true")
    args = parser.parse_args()
    http_checks(args.dev, extra_checks=lambda check: checks(check, args.dev),
                evidence=ROOT / "evidence/batch12-17")
