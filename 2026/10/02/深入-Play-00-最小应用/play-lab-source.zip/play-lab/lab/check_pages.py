#!/usr/bin/env python3
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
from urllib.parse import unquote, urljoin, urlsplit
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BLOG = ROOT.parents[1]


def verify(batch, through=None):
    posts = sorted((BLOG / "source/_posts").glob("????-??-??-深入-Play-*.md"))
    if through is not None:
        posts = [post for post in posts
                 if (number := re.search(r"深入-Play-(\d{2})-", post.name))
                 and int(number.group(1)) <= through]
    assert posts, "No Play posts found"
    evidence = ROOT / "evidence" / batch
    evidence.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="play-hexo-") as directory:
        checkout = Path(directory)
        for name in ("_config.yml", "_config.butterfly.yml", "package.json"):
            shutil.copyfile(BLOG / name, checkout / name)
        (checkout / "node_modules").symlink_to(BLOG / "node_modules", target_is_directory=True)
        destination = checkout / "source/_posts"
        destination.mkdir(parents=True)
        for post in posts:
            shutil.copyfile(post, destination / post.name)
            shutil.copytree(post.with_suffix(""), destination / post.stem)
        with (evidence / "hexo-build.log").open("w") as output:
            build = subprocess.run(["npm", "run", "build"], cwd=checkout,
                                   stdout=output, stderr=subprocess.STDOUT, timeout=120)
        assert build.returncode == 0, evidence / "hexo-build.log"
        pages = []
        for post in posts:
            date_path = post.stem[:10].replace("-", "/")
            slug = post.stem[11:]
            page_path = f"/{date_path}/{slug}/"
            page = checkout / "public" / page_path.lstrip("/") / "index.html"
            html = page.read_text()
            assert '<figure class="highlight' in html or "<pre" in html, page
            assert "<table" in html, page
            ET.parse(post.with_suffix("") / "cover.svg")
            assert (page.parent / "cover.svg").read_bytes() == (post.with_suffix("") / "cover.svg").read_bytes()
            images = re.findall(r'src=[\"\x27]([^\"\x27]+)', html)
            local_images = 0
            for asset in post.with_suffix("").glob("*.png"):
                assert (page.parent / asset.name).read_bytes() == asset.read_bytes(), asset
                matches = [link for link in images
                           if unquote(urlsplit(link).path).rsplit("/", 1)[-1] == asset.name]
                assert matches, (page, asset.name, "image reference missing")
                for link in matches:
                    target_path = urlsplit(urljoin("https://local.invalid" + page_path, link)).path
                    assert (checkout / "public" / unquote(target_path).lstrip("/")).exists(), link
                local_images += 1
            links = re.findall(r'href=[\"\x27]([^\"\x27]+)', html)
            play_links = [link for link in links if "深入-Play-" in unquote(link)]
            for link in play_links:
                parsed = urlsplit(urljoin("https://local.invalid" + page_path, link))
                if parsed.netloc not in ("local.invalid", "magicliang.github.io"):
                    continue
                target = checkout / "public" / unquote(parsed.path).lstrip("/")
                assert target.exists(), (page, link, target)
            pages.append({"post": post.name, "code": True, "table": True,
                          "cover": "BYTE_IDENTICAL", "local_png_checked": local_images,
                          "play_links_checked": len(play_links)})
        assets = BLOG / "source/_posts/2026-10-02-深入-Play-00-最小应用"
        archive = assets / "play-lab-source.zip"
        digest = hashlib.sha256(archive.read_bytes()).hexdigest()
        assert (assets / "SHA256SUMS").read_text().split()[0] == digest
        with zipfile.ZipFile(archive) as package:
            package.testzip_result = package.testzip()
            assert package.testzip_result is None
            assert "play-lab/lab/pipeline_checks.py" in package.namelist()
            for name in package.namelist():
                relative = Path(name).relative_to("play-lab")
                assert not {"target", ".tools", ".bsp", ".metals", "__pycache__"}.intersection(relative.parts), name
                assert package.read(name) == (ROOT / relative).read_bytes(), name
        copied = checkout / "public/2026/10/02/深入-Play-00-最小应用/play-lab-source.zip"
        assert copied.read_bytes() == archive.read_bytes()
        result = {"result": "PASS", "scope": "isolated Play source/config/dependencies",
                  "whole_site_hooks_included": False, "pages": pages, "zip_sha256": digest}
        (BLOG / "writing-plans/play" / f"pages-{batch}.json").write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n")
        print(json.dumps({"result": "PASS", "pages": len(pages), "zip_sha256": digest}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--batch", default="batch06-08")
    parser.add_argument("--through", type=int, choices=range(36))
    arguments = parser.parse_args()
    verify(arguments.batch, arguments.through)
