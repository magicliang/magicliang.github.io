# MapStruct / Lombok 编译期实验

固定 MapStruct 1.6.3、Lombok 1.18.42、lombok-mapstruct-binding 0.2.0。源码 release8，实际运行 Zulu 8.0.472 与 Corretto 21.0.11。

在 examples/java-libraries 下运行：

```bash
./mvnw -B -ntp -s .mvn/settings.xml -f processors/pom.xml clean verify
javap -p -c -classpath processors/target/classes blog.libraries.processors.ProductView 'blog.libraries.processors.ProductView$ProductViewBuilder'
```

独立下载包自带 wrapper；进入包内 java-libraries-processors 目录后运行：

```bash
./mvnw -B -ntp -s .mvn/settings.xml clean verify
```

四个测试分别验证创建映射及列表复制、两种 null 更新策略、builder 列表共享和可变 hashCode、JavaCompiler 实际诊断。最后一项故意编译缺少 extra 映射的临时源码；只有编译失败且诊断命中预期，JUnit 才通过。

生成代码在 target/generated-sources/annotations/blog/libraries/processors/ProductMapperImpl.java。mapstruct-processor 的 test scope 用于测试中的 JavaCompiler，annotationProcessorPaths 则用于模块正常编译。lombok 是 provided；binding 只在处理器路径。不需要在业务运行时分发这些处理器。

本例不保证深复制、线程安全或任意目标容器可变性。IDE 集成、不可变目标更新和共享源/目标列表更新未运行。只对照两个指定 JDK，不代表全部 JDK 版本。
