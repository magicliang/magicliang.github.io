package blog.libraries.processors;

import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ProductInput {
    private String name;
    private Integer count;
    private List<String> tags;
}
