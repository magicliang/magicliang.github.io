package example.tasks

import io.ktor.client.request.get
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.http.contentType
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.server.testing.testApplication
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.URI
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import org.junit.jupiter.api.Tag
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.runBlocking

class TaskHttpRoutesTest {
    @Test
    fun testApplicationSeparatesAcceptedRequestFromCompletedTaskAndHandlesDuplicates() = runBlocking {
        val started = CompletableDeferred<Unit>()
        val release = CompletableDeferred<Unit>()
        val executions = AtomicInteger()
        val registry = TaskHttpRegistry(execute = {
            executions.incrementAndGet()
            started.complete(Unit)
            release.await()
            "done"
        })
        try {
            testApplication {
                application { taskHttpRoutes(registry) }
                val first = client.post("/tasks") {
                    contentType(ContentType.Application.Json)
                    setBody("""{"id":"task-34","text":"alpha"}""")
                }
                assertEquals(HttpStatusCode.Accepted, first.status)
                started.await()
                assertFalse(release.isCompleted)
                assertEquals(HttpStatusCode.OK, client.get("/tasks/task-34").status)
                val same = client.post("/tasks") {
                    contentType(ContentType.Application.Json)
                    setBody("""{"id":"task-34","text":"alpha"}""")
                }
                assertEquals(HttpStatusCode.OK, same.status)
                val conflicting = client.post("/tasks") {
                    contentType(ContentType.Application.Json)
                    setBody("""{"id":"task-34","text":"beta"}""")
                }
                assertEquals(HttpStatusCode.Conflict, conflicting.status)
                val invalid = client.post("/tasks") {
                    contentType(ContentType.Application.Json)
                    setBody("""{"id":" ","text":"alpha"}""")
                }
                assertEquals(HttpStatusCode.BadRequest, invalid.status)
                assertEquals(HttpStatusCode.NotFound, client.get("/tasks/unknown").status)
                release.complete(Unit)
                registry.await("task-34")
                assertEquals(1, executions.get())
                assertTrue(client.get("/tasks/task-34").bodyAsText().contains("Succeeded"))
                println("HTTP testApplication accepted_before_completion=true duplicate=200 conflict=409 invalid=400 executions=1 completed_after_gate=true")
            }
        } finally {
            release.complete(Unit)
            registry.stop()
        }
    }

    @Test
    fun cancellingRequestWaitsForTaskCleanupAndDoesNotAffectAnotherTask() = runBlocking {
        val started = CompletableDeferred<Unit>()
        val cleaned = CompletableDeferred<Unit>()
        val registry = TaskHttpRegistry(execute = { draft ->
            if (draft.id.value == "cancel-me") {
                try {
                    started.complete(Unit)
                    awaitCancellation()
                } finally {
                    cleaned.complete(Unit)
                }
            } else "other-completed"
        })
        try {
            testApplication {
                application { taskHttpRoutes(registry) }
                assertEquals(HttpStatusCode.Accepted, client.post("/tasks") {
                    contentType(ContentType.Application.Json)
                    setBody("""{"id":"cancel-me","text":"alpha"}""")
                }.status)
                started.await()
                val cancelled = client.post("/tasks/cancel-me/cancel")
                assertEquals(HttpStatusCode.OK, cancelled.status)
                assertTrue(cleaned.isCompleted)
                assertTrue(cancelled.bodyAsText().contains("Cancelled"))
                assertEquals(HttpStatusCode.Accepted, client.post("/tasks") {
                    contentType(ContentType.Application.Json)
                    setBody("""{"id":"other","text":"beta"}""")
                }.status)
                registry.await("other")
                assertTrue(client.get("/tasks/other").bodyAsText().contains("Succeeded"))
                println("HTTP cancellation_joined_cleanup=true unrelated_task_succeeded=true")
            }
        } finally {
            registry.stop()
        }
    }

    @Test
    fun capacityFullRejectsBeforeCreatingJob() = runBlocking {
        val started = CompletableDeferred<Unit>()
        val release = CompletableDeferred<Unit>()
        val executions = AtomicInteger()
        val registry = TaskHttpRegistry(
            execute = {
                executions.incrementAndGet()
                started.complete(Unit)
                release.await()
                "done"
            },
            maxActiveTasks = 1,
        )
        try {
            testApplication {
                application { taskHttpRoutes(registry) }
                assertEquals(HttpStatusCode.Accepted, client.post("/tasks") {
                    contentType(ContentType.Application.Json)
                    setBody("""{"id":"busy-39","text":"alpha"}""")
                }.status)
                started.await()
                val rejected = client.post("/tasks") {
                    contentType(ContentType.Application.Json)
                    setBody("""{"id":"rejected-39","text":"beta"}""")
                }
                assertEquals(HttpStatusCode.ServiceUnavailable, rejected.status)
                assertEquals(null, registry.status("rejected-39"))
                assertEquals(1, executions.get())
                release.complete(Unit)
                registry.await("busy-39")
                println("HTTP capacity_rejected_before_job=true status=503 executions=1")
            }
        } finally {
            release.complete(Unit)
            registry.stop()
        }
    }

    @Test
    fun persistedCapacityFullRejectsBeforeInsertOrJob() = runBlocking {
        IsolatedPostgres().use { postgres ->
            val started = CompletableDeferred<Unit>()
            val release = CompletableDeferred<Unit>()
            val jdbcDispatcher = Executors.newSingleThreadExecutor { task -> Thread(task, "kotlin-39-capacity-jdbc") }.asCoroutineDispatcher()
            val store = TaskJdbcStore(postgres.url, jdbcDispatcher)
            val registry = TaskHttpRegistry(
                execute = {
                    started.complete(Unit)
                    release.await()
                    "done"
                },
                persisted = store,
                maxActiveTasks = 1,
            )
            try {
                testApplication {
                    application { taskHttpRoutes(registry) }
                    assertEquals(HttpStatusCode.Accepted, client.post("/tasks") {
                        contentType(ContentType.Application.Json)
                        setBody("""{"id":"persisted-busy-39","text":"alpha"}""")
                    }.status)
                    started.await()
                    val rejected = client.post("/tasks") {
                        contentType(ContentType.Application.Json)
                        setBody("""{"id":"persisted-rejected-39","text":"beta"}""")
                    }
                    assertEquals(HttpStatusCode.ServiceUnavailable, rejected.status)
                    assertEquals(null, registry.status("persisted-rejected-39"))
                    assertEquals(null, store.readSnapshot(TaskId("persisted-rejected-39")))
                    release.complete(Unit)
                    registry.await("persisted-busy-39")
                    println("HTTP persisted_capacity_rejected_before_insert=true before_job=true status=503")
                }
            } finally {
                release.complete(Unit)
                registry.stop()
                jdbcDispatcher.close()
            }
        }
    }

    @Test
    fun cancelAfterPersistedFinishKeepsSucceededState() = runBlocking {
        IsolatedPostgres().use { postgres ->
            val finishReached = CountDownLatch(1)
            val releaseFinish = CountDownLatch(1)
            val jdbcDispatcher = Executors.newSingleThreadExecutor { task -> Thread(task, "kotlin-39-race-jdbc") }.asCoroutineDispatcher()
            val store = TaskJdbcStore(postgres.url, jdbcDispatcher) { id, _ ->
                if (id.value == "race-39") {
                    finishReached.countDown()
                    assertTrue(releaseFinish.await(5, TimeUnit.SECONDS))
                }
            }
            val registry = TaskHttpRegistry(
                execute = { "done" },
                persisted = store,
            )
            try {
                testApplication {
                    application { taskHttpRoutes(registry) }
                    assertEquals(HttpStatusCode.Accepted, client.post("/tasks") {
                        contentType(ContentType.Application.Json)
                        setBody("""{"id":"race-39","text":"alpha"}""")
                    }.status)
                    assertTrue(finishReached.await(10, TimeUnit.SECONDS))
                    val cancelled = async(Dispatchers.Default) { client.post("/tasks/race-39/cancel") }
                    assertTrue(waitUntil { registry.cancellationRequested("race-39") })
                    releaseFinish.countDown()
                    val response = cancelled.await()
                    assertEquals(HttpStatusCode.OK, response.status)
                    assertTrue(response.bodyAsText().contains("Succeeded"))
                    assertEquals(TaskState.Succeeded("done"), registry.status("race-39"))
                    assertEquals("Succeeded:done", store.readSnapshot(TaskId("race-39"))?.state)
                    assertTrue(client.get("/tasks/race-39").bodyAsText().contains("Succeeded"))
                    println("HTTP persisted_finish_cancel_race db=Succeeded memory=Succeeded cancel_response=Succeeded")
                }
            } finally {
                releaseFinish.countDown()
                registry.stop()
                jdbcDispatcher.close()
            }
        }
    }

    private fun waitUntil(condition: () -> Boolean): Boolean {
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(10)
        while (System.nanoTime() < deadline) {
            if (condition()) return true
            Thread.sleep(20)
        }
        return condition()
    }

    @Tag("loopback")
    @Test
    fun realLoopbackPortAcceptsRequestAndServesFinalStatus() = runBlocking {
        val port = ServerSocket(0).use { it.localPort }
        val registry = TaskHttpRegistry()
        val server = embeddedServer(Netty, host = "127.0.0.1", port = port) {
            taskHttpRoutes(registry)
        }.start(wait = false)
        try {
            val submit = URI("http://127.0.0.1:$port/tasks").toURL().openConnection() as HttpURLConnection
            val accepted = try {
                submit.requestMethod = "POST"
                submit.connectTimeout = 15000
                submit.readTimeout = 15000
                submit.setRequestProperty("Content-Type", "application/json")
                submit.doOutput = true
                submit.outputStream.use { output -> output.write("""{"id":"real-34","text":"alpha"}""".toByteArray()) }
                submit.responseCode
            } finally {
                submit.disconnect()
            }
            assertEquals(202, accepted)
            registry.await("real-34")
            val query = URI("http://127.0.0.1:$port/tasks/real-34").toURL().openConnection() as HttpURLConnection
            try {
                query.connectTimeout = 15000
                query.readTimeout = 15000
                assertEquals(200, query.responseCode)
                assertTrue(query.inputStream.bufferedReader().use { it.readText() }.contains("Succeeded"))
            } finally {
                query.disconnect()
            }
            println("REAL_HTTP loopback_post=202 query=200 state=Succeeded")
        } finally {
            server.stop(100, 1000)
            registry.stop()
        }
    }
}
