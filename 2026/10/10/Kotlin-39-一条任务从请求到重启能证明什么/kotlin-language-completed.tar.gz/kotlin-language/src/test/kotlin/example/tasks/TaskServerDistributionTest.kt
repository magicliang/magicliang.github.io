package example.tasks

import java.io.File
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.URI
import java.nio.file.Files
import java.util.concurrent.TimeUnit
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue
import org.junit.jupiter.api.Tag

@Tag("package")
class TaskServerDistributionTest {
    @Test
    fun installedLauncherStopsWorkerAndClosesRealPort() {
        val port = ServerSocket(0).use { it.localPort }
        val launcher = File("build/install/kotlin-task-language/bin/task-server").absoluteFile
        assertTrue(launcher.canExecute())
        val log = Files.createTempFile("kotlin-38-package-", ".log")
        val server = ProcessBuilder(launcher.path, "$port")
            .redirectErrorStream(true)
            .redirectOutput(log.toFile())
            .also(::useCurrentJava)
            .start()
        val output = { Files.readAllLines(log) }
        try {
            assertTrue(waitUntil(20_000) { output().any { it == "SERVER_STARTED port=$port" } })
            assertTrue(waitUntil(20_000) { responseCode(port, "GET", "/tasks/missing") == 404 })
            val accepted = URI("http://127.0.0.1:$port/tasks").toURL().openConnection() as HttpURLConnection
            accepted.requestMethod = "POST"
            accepted.connectTimeout = 2000
            accepted.readTimeout = 5000
            accepted.setRequestProperty("Content-Type", "application/json")
            accepted.setRequestProperty("X-Request-Id", "req-38-package")
            accepted.doOutput = true
            accepted.outputStream.use { it.write("""{"id":"packaged-38","text":"wait"}""".toByteArray()) }
            assertEquals(202, accepted.responseCode)
            assertEquals("req-38-package", accepted.getHeaderField("X-Request-Id"))
            accepted.disconnect()
            assertTrue(waitUntil(10_000) { output().any { it == "TASK_RUN request_id=req-38-package task_id=packaged-38" } })
            server.destroy()
            assertTrue(server.waitFor(20, TimeUnit.SECONDS))
            assertTrue(output().any { it == "SERVICE_STOP_ACCEPTING port=$port" }, output().joinToString("\n"))
            assertTrue(output().any { it == "TASK_FINAL request_id=req-38-package task_id=packaged-38 state=Cancelled" }, output().joinToString("\n"))
            assertTrue(output().any { it == "RESOURCE_CLOSED dispatcher=true worker=true jdbc=true engine=true" }, output().joinToString("\n"))
            assertEquals(null, responseCode(port, "GET", "/tasks/packaged-38"))
            println("PACKAGE real_post=202 request_id=req-38-package task_id=packaged-38 final=Cancelled port_closed=true dispatcher_closed=true exit=${server.exitValue()}")
            output().forEach(::println)
        } finally {
            if (server.isAlive) {
                server.destroy()
                if (!server.waitFor(5, TimeUnit.SECONDS)) server.destroyForcibly()
            }
        }
    }

    private fun useCurrentJava(command: ProcessBuilder) {
        val javaHome = System.getProperty("java.home")
        val environment = command.environment()
        environment["JAVA_HOME"] = javaHome
        environment["PATH"] = "$javaHome/bin:${environment["PATH"].orEmpty()}"
    }

    private fun waitUntil(timeoutMs: Long, condition: () -> Boolean): Boolean {
        val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMs)
        while (System.nanoTime() < deadline) {
            if (condition()) return true
            Thread.sleep(50)
        }
        return condition()
    }

    private fun responseCode(port: Int, method: String, path: String): Int? = try {
        val connection = URI("http://127.0.0.1:$port$path").toURL().openConnection() as HttpURLConnection
        try {
            connection.requestMethod = method
            connection.connectTimeout = 1000
            connection.readTimeout = 1000
            connection.responseCode
        } finally {
            connection.disconnect()
        }
    } catch (unreachable: java.io.IOException) {
        null
    }
}
