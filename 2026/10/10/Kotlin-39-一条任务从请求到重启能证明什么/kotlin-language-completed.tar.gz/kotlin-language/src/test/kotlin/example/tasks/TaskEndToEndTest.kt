package example.tasks

import java.io.File
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.URI
import java.sql.DriverManager
import java.nio.file.Files
import java.util.concurrent.TimeUnit
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.runBlocking
import org.junit.jupiter.api.Tag

@Tag("package")
class TaskEndToEndTest {
    @Test
    fun realHttpJobSqlFailureAndRestartUseOneIsolatedDatabase() = runBlocking {
        IsolatedPostgres().use { postgres ->
            val dispatcher = java.util.concurrent.Executors.newSingleThreadExecutor().asCoroutineDispatcher()
            val store = TaskJdbcStore(postgres.url, dispatcher)
            val port = ServerSocket(0).use { it.localPort }
            try {
                val first = startServer(port, postgres.url)
                try {
                    assertEquals(400, post(port, "bad-39", ""))
                    assertEquals(null, store.readSnapshot(TaskId("bad-39")))

                    assertEquals(202, post(port, "success-39", "alpha"))
                    assertTrue(store.readSnapshot(TaskId("success-39")) != null)
                    assertTrue(waitUntil { get(port, "success-39")?.contains("Succeeded") == true })
                    assertEquals("Succeeded:completed:success-39", store.readSnapshot(TaskId("success-39"))?.state)
                    assertEquals(200, post(port, "success-39", "alpha"))
                    assertEquals(409, post(port, "success-39", "changed"))

                    assertEquals(202, post(port, "failed-39", "fail"))
                    assertTrue(waitUntil { get(port, "failed-39")?.contains("Failed") == true })
                    assertEquals("Failed", store.readSnapshot(TaskId("failed-39"))?.state)

                    assertEquals(202, post(port, "cancel-39", "wait"))
                    assertTrue(store.readSnapshot(TaskId("cancel-39")) != null)
                    assertTrue(waitUntil { get(port, "cancel-39")?.contains("Running") == true })
                    assertEquals(200, request(port, "POST", "/tasks/cancel-39/cancel").first)
                    assertTrue(get(port, "cancel-39")?.contains("Cancelled") == true)
                    assertEquals("Cancelled", store.readSnapshot(TaskId("cancel-39"))?.state)
                    assertEquals(200, request(port, "POST", "/tasks/success-39/cancel").first)
                    assertEquals("Succeeded:completed:success-39", store.readSnapshot(TaskId("success-39"))?.state)

                    postgres.stop()
                    assertEquals(503, post(port, "outage-39", "beta"))
                    assertEquals(503, request(port, "GET", "/tasks/success-39").first)
                    postgres.restart()
                    assertEquals(null, store.readSnapshot(TaskId("outage-39")))
                    assertTrue(get(port, "success-39")?.contains("Succeeded") == true)

                    assertEquals(202, post(port, "shutdown-39", "wait", "req-39-shutdown"))
                    assertTrue(waitUntil { get(port, "shutdown-39")?.contains("Running") == true })
                } finally {
                    stopServer(first, "req-39-shutdown", "shutdown-39")
                    assertEquals("Cancelled", independentState(postgres.url, "shutdown-39"))
                }

                postgres.restart()
                val second = startServer(port, postgres.url)
                try {
                    assertTrue(get(port, "success-39")?.contains("Succeeded") == true)
                    assertTrue(get(port, "failed-39")?.contains("Failed") == true)
                    assertTrue(get(port, "cancel-39")?.contains("Cancelled") == true)
                    assertEquals(409, post(port, "success-39", "alpha"))
                    println("END_TO_END invalid=400 accepted=202 committed_before_202=true duplicate=200 conflict=409 failed=Failed cancel_before=Cancelled cancel_after=Succeeded db_outage=503 db_restart=Succeeded process_restart=Succeeded retry_after_restart=409")
                } finally {
                    stopServer(second)
                }
            } finally {
                dispatcher.close()
            }
        }
    }

    private data class ServerProcess(val process: Process, val log: File)

    private fun startServer(port: Int, jdbcUrl: String): ServerProcess {
        val launcher = File("build/install/kotlin-task-language/bin/task-server").absoluteFile
        val log = Files.createTempFile("kotlin-39-server-", ".log").toFile()
        val command = ProcessBuilder(launcher.path, "$port").redirectErrorStream(true).redirectOutput(log)
        command.environment()["TASK_DB_URL"] = jdbcUrl
        useCurrentJava(command)
        val process = command.start()
        val server = ServerProcess(process, log)
        assertTrue(waitUntil { log.readText().contains("SERVER_STARTED port=$port") && request(port, "GET", "/tasks/missing").first == 404 }, log.readText())
        return server
    }

    private fun useCurrentJava(command: ProcessBuilder) {
        val javaHome = System.getProperty("java.home")
        val environment = command.environment()
        environment["JAVA_HOME"] = javaHome
        environment["PATH"] = "$javaHome/bin:${environment["PATH"].orEmpty()}"
    }

    private fun stopServer(server: ServerProcess, expectedRequestId: String? = null, expectedTaskId: String? = null) {
        if (server.process.isAlive) server.process.destroy()
        if (!server.process.waitFor(20, TimeUnit.SECONDS)) server.process.destroyForcibly()
        val text = server.log.readText()
        assertTrue(text.contains("RESOURCE_CLOSED dispatcher=true worker=true jdbc=true engine=true"), text)
        if (expectedRequestId != null && expectedTaskId != null) {
            assertTrue(
                text.contains("TASK_FINAL request_id=$expectedRequestId task_id=$expectedTaskId state=Cancelled"),
                text,
            )
        }
        println("SERVER_SHUTDOWN exit=${server.process.exitValue()} ${server.log.readLines().filter { it.startsWith("TASK_FINAL ") }}")
    }

    private fun post(port: Int, id: String, text: String, requestId: String? = null): Int = request(
        port,
        "POST",
        "/tasks",
        """{"id":"$id","text":"$text"}""",
        requestId,
    ).first ?: error("HTTP server unavailable")

    private fun get(port: Int, id: String): String? = request(port, "GET", "/tasks/$id").second

    private fun request(port: Int, method: String, path: String, body: String? = null, requestId: String? = null): Pair<Int?, String?> = try {
        val connection = URI("http://127.0.0.1:$port$path").toURL().openConnection() as HttpURLConnection
        try {
            connection.requestMethod = method
            connection.connectTimeout = 1000
            connection.readTimeout = 5000
            if (requestId != null) connection.setRequestProperty("X-Request-Id", requestId)
            if (body != null) {
                connection.setRequestProperty("Content-Type", "application/json")
                connection.doOutput = true
                connection.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = connection.responseCode
            code to (if (code < 400) connection.inputStream.bufferedReader().use { it.readText() } else null)
        } finally {
            connection.disconnect()
        }
    } catch (unreachable: java.io.IOException) {
        null to null
    }

    private fun independentState(jdbcUrl: String, id: String): String? = DriverManager.getConnection(jdbcUrl).use { connection ->
        connection.prepareStatement("SELECT state FROM task_snapshot WHERE id = ?").use { statement ->
            statement.setString(1, id)
            statement.executeQuery().use { result -> if (result.next()) result.getString(1) else null }
        }
    }

    private fun waitUntil(condition: () -> Boolean): Boolean {
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(20)
        while (System.nanoTime() < deadline) {
            if (condition()) return true
            Thread.sleep(50)
        }
        return condition()
    }
}
