package example.tasks

import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.runBlocking

fun main(args: Array<String>) {
    val port = args.singleOrNull()?.toIntOrNull()
    require(port != null && port in 1..65535) { "Usage: task-server <port>" }
    val worker = boundedSingleThreadExecutor("kotlin-38-task-worker", 64)
    val dispatcher = worker.asCoroutineDispatcher()
    val jdbcUrl = System.getenv("TASK_DB_URL")?.takeIf(String::isNotBlank)
    val jdbcWorker = jdbcUrl?.let { boundedSingleThreadExecutor("kotlin-39-jdbc-worker", 64) }
    val jdbcDispatcher = jdbcWorker?.asCoroutineDispatcher()
    val store = jdbcUrl?.let { TaskJdbcStore(it, requireNotNull(jdbcDispatcher)) }
    val registry = TaskHttpRegistry(
        execute = { draft ->
            if (draft.text == "wait") awaitCancellation()
            if (draft.text == "fail") error("synthetic task failure")
            "completed:${draft.id.value}"
        },
        dispatcher = dispatcher,
        onRun = { requestId, taskId -> println("TASK_RUN request_id=$requestId task_id=$taskId") },
        persisted = store,
        maxActiveTasks = 16,
    )
    val server = embeddedServer(Netty, host = "127.0.0.1", port = port) { taskHttpRoutes(registry) }
    val terminated = CountDownLatch(1)
    Runtime.getRuntime().addShutdownHook(Thread({
        registry.stopAccepting()
        println("SERVICE_STOP_ACCEPTING port=$port")
        server.stop(500, 5000)
        runBlocking { registry.stop() }
        registry.snapshot().forEach { (taskId, entry) ->
            println("TASK_FINAL request_id=${entry.first} task_id=$taskId state=${entry.second::class.simpleName}")
        }
        dispatcher.close()
        val workerTerminated = worker.awaitTermination(5, TimeUnit.SECONDS)
        jdbcDispatcher?.close()
        val jdbcTerminated = jdbcWorker?.awaitTermination(5, TimeUnit.SECONDS) ?: true
        println("RESOURCE_CLOSED dispatcher=true worker=$workerTerminated jdbc=$jdbcTerminated engine=true")
        terminated.countDown()
    }, "kotlin-38-shutdown"))
    server.start(wait = false)
    println("SERVER_STARTED port=$port")
    terminated.await()
}

private fun boundedSingleThreadExecutor(threadName: String, queueCapacity: Int): ThreadPoolExecutor =
    ThreadPoolExecutor(
        1,
        1,
        0L,
        TimeUnit.MILLISECONDS,
        ArrayBlockingQueue(queueCapacity),
        { task -> Thread(task, threadName) },
        ThreadPoolExecutor.AbortPolicy(),
    )
