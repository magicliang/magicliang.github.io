#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="${KOTLIN_EVIDENCE_DIR:-$project/../../writing-plans/kotlin/verification/39}"
mkdir -p "$evidence"
cd "$project" || exit 1

find_pg_bin() {
    if [[ -n "${KOTLIN_PG_BIN:-}" && -x "$KOTLIN_PG_BIN/postgres" ]]; then
        printf '%s\n' "$KOTLIN_PG_BIN"
        return 0
    fi
    if [[ -n "${TASK_PG_BIN:-}" && -x "$TASK_PG_BIN/postgres" ]]; then
        printf '%s\n' "$TASK_PG_BIN"
        return 0
    fi
    for candidate in /opt/homebrew/opt/postgresql@16/bin /opt/homebrew/bin /usr/local/opt/postgresql@16/bin /usr/lib/postgresql/16/bin; do
        if [[ -x "$candidate/postgres" ]]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done
    return 1
}

pg_bin="$(find_pg_bin)" || { echo "Set KOTLIN_PG_BIN or TASK_PG_BIN to a PostgreSQL bin directory" >&2; exit 1; }

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && "$1/postgres" --version && ./gradlew --version' _ "$pg_bin" || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test loopbackTest packageTest distZip jmh || exit 1
suite_count=0
for xml in build/test-results/test/TEST-example.tasks.*.xml; do
    suite="${xml##*/}"
    suite="${suite#TEST-example.tasks.}"
    suite="${suite%.xml}"
    run "$suite" cat "$xml" || exit 1
    ((suite_count+=1))
done
run TaskHttpLoopbackTest cat build/test-results/loopbackTest/TEST-example.tasks.TaskHttpRoutesTest.xml || exit 1
run TaskServerDistributionTest cat build/test-results/packageTest/TEST-example.tasks.TaskServerDistributionTest.xml || exit 1
run TaskEndToEndTest cat build/test-results/packageTest/TEST-example.tasks.TaskEndToEndTest.xml || exit 1
run zipContents unzip -l build/distributions/kotlin-task-language.zip || exit 1
cp build/reports/jmh/results.json "$evidence/jmh-results.json" || exit 1
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit
invalid_result=$?

{
    printf 'suite_count=%s\ninvalid_exit=%s\n' "$suite_count" "$invalid_result"
    grep -Fq 'tests="1" skipped="0" failures="0" errors="0"' "$evidence/TaskEndToEndTest.txt" && echo integrated_suite=PASS || echo integrated_suite=FAIL
    grep -Fq 'END_TO_END invalid=400 accepted=202 committed_before_202=true duplicate=200 conflict=409 failed=Failed cancel_before=Cancelled cancel_after=Succeeded db_outage=503 db_restart=Succeeded process_restart=Succeeded retry_after_restart=409' "$evidence/TaskEndToEndTest.txt" && echo integrated_http_job_sql_restarts=PASS || echo integrated_http_job_sql_restarts=FAIL
    grep -Fq 'SERVER_SHUTDOWN exit=143' "$evidence/TaskEndToEndTest.txt" && echo process_exit_observed=PASS || echo process_exit_observed=FAIL
    grep -Fq 'PG_COMMAND=pg_ctl EXIT_CODE=0' "$evidence/TaskEndToEndTest.txt" && echo database_process_restarted=PASS || echo database_process_restarted=FAIL
    grep -Fq 'tests="1" skipped="0" failures="0" errors="0"' "$evidence/TaskServerDistributionTest.txt" && echo packaged_regression=PASS || echo packaged_regression=FAIL
    grep -Fq 'tests="1" skipped="0" failures="0" errors="0"' "$evidence/TaskHttpLoopbackTest.txt" && echo real_loopback_regression=PASS || echo real_loopback_regression=FAIL
    grep -Fq 'kotlin-task-language/bin/task-server' "$evidence/zipContents.txt" && echo runnable_zip=PASS || echo runnable_zip=FAIL
    jq -e 'length == 6' "$evidence/jmh-results.json" >/dev/null && echo six_jmh_regressions=PASS || echo six_jmh_regressions=FAIL
    grep -Fq 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" && echo valid_cli=PASS || echo valid_cli=FAIL
    grep -Fq 'Usage: submit <task text>' "$evidence/invalid.txt" && echo invalid_cli=PASS || echo invalid_cli=FAIL
} > "$evidence/assertions.txt"

test "$suite_count" -eq 40 && test "$invalid_result" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
