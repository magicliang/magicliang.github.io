#!/usr/bin/env bash
set -euo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="${KOTLIN_EVIDENCE_DIR:-$project/completion-evidence/local}"
mkdir -p "$evidence"
cd "$project"

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && ./gradlew --version'
run build ./gradlew --offline --no-daemon --console=plain clean test loopbackTest packageTest distZip
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha'
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit || invalid_result=$?

{
    printf 'evidence=%s\n' "$evidence"
    printf 'invalid_exit=%s\n' "${invalid_result:-0}"
    grep -Fq 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" && echo valid_cli=PASS || echo valid_cli=FAIL
    grep -Fq 'Usage: submit <task text>' "$evidence/invalid.txt" && echo invalid_cli=PASS || echo invalid_cli=FAIL
    grep -Fq 'BUILD SUCCESSFUL' "$evidence/build.txt" && echo build=PASS || echo build=FAIL
} > "$evidence/assertions.txt"

test "${invalid_result:-0}" -ne 0
! grep -Fq '=FAIL' "$evidence/assertions.txt"
