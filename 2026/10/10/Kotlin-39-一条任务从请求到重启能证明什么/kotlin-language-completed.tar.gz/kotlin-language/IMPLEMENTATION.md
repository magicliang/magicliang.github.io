# Kotlin 累计工程补齐记录

本目录从 `source/_posts/2026-10-11-Kotlin-E01-Compose离开页面后Flow还会收集吗/kotlin-language-E01.tar.gz` 安全解包恢复，包 SHA-256 为 `fe7d60de6d83ee75adb98967df4bfaee942e4e694615e634d3c2fc38ac63c3ab`。

本轮只补齐根累计工程和复现入口，不改原 48 个素材包、正文、写作台账或历史 review。实现范围：

1. HTTP 受理前加入有界容量许可；满载时返回 `503`，不落库、不创建后台 Job。
2. 修复持久化任务在 SQL 终态已提交、协程返回前被取消时的内存/数据库终态一致性。
3. 用真实 PostgreSQL 继续验证事务、取消、连接 close、SQL 停止和发行包关闭链。PG 工具目录优先读 `KOTLIN_PG_BIN`，兼容 `TASK_PG_BIN`。
4. 修复 E07 ABI 验证脚本的日志目录创建顺序，并避免依赖英文 javac 诊断文本。
5. 验证使用 JDK 21、Gradle 8.14 wrapper 和既有 `/private/tmp/kotlin-review-gradle-home` 缓存；不改 Kotlin/JDK/库版本。
