# 当前累计工程的版本

此表随最新源码包分发。仓库的完整历史版本、固定源码锚点与复跑记录见 `writing-plans/kotlin/VERSIONS.md` 和 `completion-evidence/`；历史章节包的运行记录不替代当前源码运行。

| 对象 | 固定值 |
|---|---|
| Kotlin/JVM、serialization 插件、编译器、stdlib | 2.2.21 |
| language / API / JVM target | 2.2 / 2.2 / 21 |
| Gradle Wrapper | 8.14 |
| coroutines core/test/reactor | 1.10.2 |
| serialization JSON | 1.9.0 |
| Ktor JVM | 3.3.1 |
| PostgreSQL JDBC | 42.7.7 |
| 实跑 PostgreSQL | 16.15，独立临时集群 |
| Spring AOP/R2DBC/TX（测试专用） | 6.2.11 |
| R2DBC PostgreSQL / pool / Reactor | 1.0.7.RELEASE / 1.0.2.RELEASE / 3.7.11 |
| JMH | 1.37 |

当前本地复跑使用 macOS arm64、Amazon Corretto 21.0.11、Node 22.22.2；源码要求 JDK 21。直接运行 `javac` 时还须将该 JDK 的 bin 放在 PATH 首位。Gradle 自带 Kotlin 2.0.21 是构建工具内部版本，不是此程序的编译器。

Gradle 分发包 SHA-256：`61ad310d3c7d3e5da131b76bbf22b5a4c0786e9d892dae8c1658d4b484de3caa`。Kotlin 源码 tag `v2.2.21` 对应 commit `2146684dcba708e5a304758b41a9e4ec9c7eff71`；coroutines `1.10.2` 对应 `5f8900478a8e20c073145b1608fbc71fe3d7378b`。具体生成字节码只对固定编译器和实际构建产物成立。

JVM、JS/Node、Wasm/Node 分别执行；Android 设备与 linuxX64 Native/C 在本轮 macOS 宿主未跑。主 JVM 工程通过不等于平台生命周期、C ABI、浏览器或 WASI 通过。真实插件/IR dump、生产流量和部署也未运行。
