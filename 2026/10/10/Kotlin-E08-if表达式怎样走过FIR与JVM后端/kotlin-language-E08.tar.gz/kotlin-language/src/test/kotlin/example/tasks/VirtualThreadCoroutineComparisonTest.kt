package example.tasks

import java.util.concurrent.Executors
import java.util.concurrent.Semaphore
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.system.measureNanoTime
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Semaphore as CoroutineSemaphore
import kotlinx.coroutines.sync.withPermit
import org.junit.jupiter.api.Tag
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

@Tag("comparison")
class VirtualThreadCoroutineComparisonTest {
    private val taskCount = 320
    private val limit = 32
    private val waitMilliseconds = 8L

    private data class Sample(val checksum: Int, val peak: Int)

    private fun virtualThreads(): Sample {
        val permits = Semaphore(limit)
        val active = AtomicInteger()
        val peak = AtomicInteger()
        Executors.newVirtualThreadPerTaskExecutor().use { executor ->
            val futures = (1..taskCount).map { number ->
                executor.submit<Int> {
                    permits.acquire()
                    try {
                        val current = active.incrementAndGet()
                        peak.updateAndGet { maxOf(it, current) }
                        Thread.sleep(waitMilliseconds)
                        number
                    } finally {
                        active.decrementAndGet()
                        permits.release()
                    }
                }
            }
            return Sample(futures.sumOf { it.get() }, peak.get())
        }
    }

    private fun coroutines(): Sample = runBlocking {
        val permits = CoroutineSemaphore(limit)
        val active = AtomicInteger()
        val peak = AtomicInteger()
        val results = (1..taskCount).map { number ->
            async(Dispatchers.Default) {
                permits.withPermit {
                    val current = active.incrementAndGet()
                    peak.updateAndGet { maxOf(it, current) }
                    try {
                        delay(waitMilliseconds)
                        number
                    } finally {
                        active.decrementAndGet()
                    }
                }
            }
        }.awaitAll()
        Sample(results.sum(), peak.get())
    }

    @Test
    fun boundedSyntheticWaitsHaveComparableWork() {
        val virtualTimes = mutableListOf<Long>()
        val coroutineTimes = mutableListOf<Long>()
        repeat(6) { round ->
            var virtualSample: Sample? = null
            var coroutineSample: Sample? = null
            val virtualNanos = measureNanoTime { virtualSample = virtualThreads() }
            val coroutineNanos = measureNanoTime { coroutineSample = coroutines() }
            for (sample in listOf(virtualSample, coroutineSample)) {
                assertEquals(taskCount * (taskCount + 1) / 2, sample?.checksum)
                assertTrue(sample!!.peak in 1..limit)
            }
            if (round > 0) {
                virtualTimes.add(virtualNanos)
                coroutineTimes.add(coroutineNanos)
            }
            println("ROUND=$round VIRTUAL_NS=$virtualNanos COROUTINE_NS=$coroutineNanos VIRTUAL_PEAK=${virtualSample!!.peak} COROUTINE_PEAK=${coroutineSample!!.peak}")
        }
        println("MEDIAN_NS virtual=${virtualTimes.sorted()[2]} coroutine=${coroutineTimes.sorted()[2]} taskCount=$taskCount limit=$limit waitMs=$waitMilliseconds")
    }

    @Test
    fun interruptAndCancelTerminateWaitingWork() {
        val interrupted = AtomicBoolean()
        val thread = Thread.ofVirtual().start {
            try {
                Thread.sleep(10_000)
            } catch (_: InterruptedException) {
                interrupted.set(true)
            }
        }
        thread.interrupt()
        thread.join()
        assertTrue(interrupted.get())

        val cancelled = AtomicBoolean()
        runBlocking {
            val started = CompletableDeferred<Unit>()
            val job = launch(Dispatchers.Default) {
                try {
                    started.complete(Unit)
                    delay(10_000)
                } finally {
                    cancelled.set(true)
                }
            }
            started.await()
            job.cancelAndJoin()
        }
        assertTrue(cancelled.get())
        println("LIFECYCLE virtualInterrupted=${interrupted.get()} coroutineFinally=${cancelled.get()}")
    }
}
