package example.tasks

import io.r2dbc.pool.ConnectionPool
import io.r2dbc.pool.ConnectionPoolConfiguration
import io.r2dbc.spi.ConnectionFactories
import java.sql.DriverManager
import java.time.Duration
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.reactor.ReactorContext
import kotlinx.coroutines.reactor.awaitSingle
import kotlinx.coroutines.reactor.awaitSingleOrNull
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.aopalliance.intercept.MethodInterceptor
import org.junit.jupiter.api.Tag
import org.springframework.aop.framework.ProxyFactory
import org.springframework.r2dbc.core.DatabaseClient
import org.springframework.transaction.reactive.TransactionalOperator
import org.springframework.transaction.reactive.executeAndAwait
import org.springframework.r2dbc.connection.R2dbcTransactionManager
import reactor.util.context.Context
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue

private interface SuspendedTaskReader {
    suspend fun read(): String
}

@Tag("spring")
class SpringCoroutineTransactionTest {
    @Test
    fun proxyInvocationReturnIsNotSuspendedCompletion() = runBlocking {
        val entered = CompletableDeferred<Unit>()
        val release = CompletableDeferred<Unit>()
        val intercepted = AtomicInteger()
        val target = object : SuspendedTaskReader {
            override suspend fun read(): String {
                entered.complete(Unit)
                release.await()
                return "done"
            }
        }
        val proxy = ProxyFactory(target).apply {
            setInterfaces(SuspendedTaskReader::class.java)
            addAdvice(MethodInterceptor { invocation ->
                val result = invocation.proceed()
                intercepted.incrementAndGet()
                result
            })
        }.proxy as SuspendedTaskReader
        val caller = async { proxy.read() }
        entered.await()
        assertEquals(1, intercepted.get())
        assertFalse(caller.isCompleted)
        release.complete(Unit)
        assertEquals("done", caller.await())
        println("SPRING_PROXY adviceReturned=1 callerCompletedBeforeRelease=false final=done")
    }

    @Test
    fun reactiveTransactionAwaitsSuccessFailureAndCancellation() = runBlocking {
        IsolatedPostgres().use { postgres ->
            DriverManager.getConnection(postgres.url).use { connection ->
                connection.createStatement().use { statement ->
                    statement.executeUpdate("CREATE TABLE e06_probe (label TEXT PRIMARY KEY)")
                }
            }
            val pool = ConnectionPool(
                ConnectionPoolConfiguration.builder(ConnectionFactories.get(postgres.r2dbcUrl))
                    .maxSize(1)
                    .maxAcquireTime(Duration.ofSeconds(5))
                    .build(),
            )
            val client = DatabaseClient.create(pool)
            val operator = TransactionalOperator.create(R2dbcTransactionManager(pool))

            suspend fun insert(label: String) {
                client.sql("INSERT INTO e06_probe (label) VALUES (:label)")
                    .bind("label", label).fetch().rowsUpdated().awaitSingle()
            }

            fun count(label: String): Int = DriverManager.getConnection(postgres.url).use { connection ->
                connection.prepareStatement("SELECT count(*) FROM e06_probe WHERE label = ?").use { statement ->
                    statement.setString(1, label)
                    statement.executeQuery().use { result -> result.next(); result.getInt(1) }
                }
            }

            try {
                val inserted = CompletableDeferred<Unit>()
                val release = CompletableDeferred<Unit>()
                val local = ThreadLocal<String>()
                val success = async(Dispatchers.Default + ReactorContext(Context.of("requestId", "synthetic-e06"))) {
                    operator.executeAndAwait {
                        insert("success")
                        Executors.newSingleThreadExecutor { task -> Thread(task, "e06-origin") }
                            .asCoroutineDispatcher().use { origin ->
                                withContext(origin) {
                                    local.set("origin-only")
                                    try {
                                        Executors.newSingleThreadExecutor { task -> Thread(task, "e06-context") }
                                            .asCoroutineDispatcher().use { destination ->
                                                withContext(destination) {
                                                    assertTrue(Thread.currentThread().name.startsWith("e06-context"))
                                                    val requestId = currentCoroutineContext()[ReactorContext]?.context?.get<String>("requestId")
                                                    assertEquals("synthetic-e06", requestId)
                                                    assertNull(local.get())
                                                }
                                            }
                                    } finally {
                                        assertEquals("origin-only", local.get())
                                        local.remove()
                                    }
                                }
                            }
                        inserted.complete(Unit)
                        release.await()
                        "committed"
                    }
                }
                inserted.await()
                assertFalse(success.isCompleted)
                assertEquals(0, count("success"))
                release.complete(Unit)
                assertEquals("committed", success.await())
                assertEquals(1, count("success"))

                assertFailsWith<IllegalStateException> {
                    operator.executeAndAwait {
                        insert("failed")
                        delay(1)
                        throw IllegalStateException("after-suspension")
                    }
                }
                assertEquals(0, count("failed"))

                val cancellationEntered = CompletableDeferred<Unit>()
                val cancelled = async {
                    operator.executeAndAwait {
                        insert("cancelled")
                        cancellationEntered.complete(Unit)
                        awaitCancellation()
                    }
                }
                cancellationEntered.await()
                assertEquals(0, count("cancelled"))
                cancelled.cancelAndJoin()
                assertEquals(0, count("cancelled"))
                val acquired = pool.metrics.orElseThrow().acquiredSize()
                val pending = pool.metrics.orElseThrow().pendingAcquireSize()
                assertEquals(0, acquired)
                assertEquals(0, pending)
                println("SPRING_R2DBC uncommitted=0 committed=1 failed=0 cancelled=0 requestId=synthetic-e06 acquired=$acquired pending=$pending")
            } finally {
                pool.disposeLater().awaitSingleOrNull()
            }
            assertTrue(pool.isDisposed)
        }
    }
}
