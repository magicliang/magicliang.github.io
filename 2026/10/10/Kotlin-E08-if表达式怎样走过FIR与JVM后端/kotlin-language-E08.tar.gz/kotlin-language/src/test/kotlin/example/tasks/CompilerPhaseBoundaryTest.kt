package example.tasks

import java.util.concurrent.atomic.AtomicInteger
import kotlin.test.Test
import kotlin.test.assertEquals

class CompilerPhaseBoundaryTest {
    @Test
    fun nonNullSourceIsReadOnceBeforeBranch() {
        val reads = AtomicInteger()
        val source = TaskTextSource { reads.incrementAndGet(); "task" }
        assertEquals(4, textLength(source))
        assertEquals(1, reads.get())
        println("E08_VALUE nonNull=4 getterReads=1")
    }

    @Test
    fun nullSourceIsReadOnceAndReturnsZero() {
        val reads = AtomicInteger()
        val source = TaskTextSource { reads.incrementAndGet(); null }
        assertEquals(0, textLength(source))
        assertEquals(1, reads.get())
        println("E08_VALUE null=0 getterReads=1")
    }
}
