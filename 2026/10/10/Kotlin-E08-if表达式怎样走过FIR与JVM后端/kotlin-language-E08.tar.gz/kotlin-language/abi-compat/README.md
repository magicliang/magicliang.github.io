# 隔离的本地库兼容性实验（E07）

在本目录使用上级 `../gradlew` 启动独立 Gradle build。通过 `-PlocalRepo=/tmp/新建目录` 指定仅测试使用的本地 Maven 仓库，不向全局 `~/.m2` 或公共仓库发布。`libraryVersion` 选择 1.0.0 / 1.1.0 / 2.0.0 的源码；consumer 默认只以 1.0.0 编译，运行时由 `runtimeVersion` 选择载入的库版本。`1.1.0` 更换默认后缀但保留旧调用符号；`2.0.0` 移除默认参数/Java 重载，旧二进制会链接失败。

原始构建、`javap`、旧消费者复跑与新源码编译拒绝见 `writing-plans/kotlin/verification/E07/`。此工程只对照本机 Kotlin/JVM 2.2.21 的样本 API，不是发布公共 Maven 仓库或所有 Kotlin 源码变更的兼容性证明。
