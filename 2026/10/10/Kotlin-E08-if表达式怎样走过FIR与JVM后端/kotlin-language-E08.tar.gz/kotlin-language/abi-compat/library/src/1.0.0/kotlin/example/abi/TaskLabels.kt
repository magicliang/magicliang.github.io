package example.abi

object TaskLabels {
    @JvmStatic
    @JvmOverloads
    fun render(id: String, suffix: String = "!"): String = id + suffix
}
