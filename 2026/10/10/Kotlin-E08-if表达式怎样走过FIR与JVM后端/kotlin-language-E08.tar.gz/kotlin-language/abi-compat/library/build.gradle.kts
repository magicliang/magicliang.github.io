import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    kotlin("jvm") version "2.2.21"
    `maven-publish`
}

group = "example.tasks"
version = providers.gradleProperty("libraryVersion").getOrElse("1.0.0")

repositories { mavenCentral() }

kotlin {
    jvmToolchain(21)
    compilerOptions.jvmTarget.set(JvmTarget.JVM_21)
}

sourceSets.main { kotlin.srcDir("src/$version/kotlin") }

publishing {
    publications {
        create<MavenPublication>("maven") {
            from(components["java"])
            artifactId = "task-labels"
        }
    }
    repositories {
        maven { url = uri(providers.gradleProperty("localRepo").get()) }
    }
}
