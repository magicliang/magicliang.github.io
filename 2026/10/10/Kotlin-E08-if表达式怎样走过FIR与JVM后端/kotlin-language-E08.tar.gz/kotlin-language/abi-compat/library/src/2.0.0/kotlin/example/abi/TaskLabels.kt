package example.abi

object TaskLabels {
    @JvmStatic
    fun render(id: String, suffix: String): String = id + suffix
}
