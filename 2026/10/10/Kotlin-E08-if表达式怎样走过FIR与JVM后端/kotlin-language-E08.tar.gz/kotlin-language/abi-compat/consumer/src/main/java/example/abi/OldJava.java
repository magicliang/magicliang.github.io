package example.abi;

public final class OldJava {
    public static String render() {
        return TaskLabels.render("id");
    }
}
