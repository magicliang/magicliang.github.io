package example.abi

private fun callOld(block: () -> String): String = try {
    block()
} catch (failure: NoSuchMethodError) {
    "NoSuchMethodError"
}

fun main() {
    val javaResult = callOld { OldJava.render() }
    val kotlinResult = callOld { TaskLabels.render("id") }
    val expected = when (System.getProperty("runtimeVersion")) {
        "1.0.0" -> "id!"
        "1.1.0" -> "id?"
        "2.0.0" -> "NoSuchMethodError"
        else -> error("unknown version")
    }
    check(javaResult == expected && kotlinResult == expected)
    println("OLD_CONSUMER java=$javaResult kotlin=$kotlinResult expected=$expected")
}
