import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    kotlin("jvm") version "2.2.21"
}

kotlin {
    jvmToolchain(21)
    compilerOptions.jvmTarget.set(JvmTarget.JVM_21)
}

repositories {
    maven { url = uri(providers.gradleProperty("localRepo").get()) }
    mavenCentral()
}

dependencies {
    compileOnly("example.tasks:task-labels:${providers.gradleProperty("compileVersion").getOrElse("1.0.0")}")
    runtimeOnly("example.tasks:task-labels:${providers.gradleProperty("runtimeVersion").getOrElse("1.0.0")}")
}

tasks.register<JavaExec>("oldConsumer") {
    dependsOn(tasks.classes)
    classpath = sourceSets.main.get().runtimeClasspath
    mainClass.set("example.abi.OldKotlinKt")
    systemProperty("runtimeVersion", providers.gradleProperty("runtimeVersion").getOrElse("1.0.0"))
}
