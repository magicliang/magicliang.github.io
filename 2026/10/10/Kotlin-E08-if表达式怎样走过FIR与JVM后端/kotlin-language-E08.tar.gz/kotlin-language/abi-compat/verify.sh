#!/usr/bin/env bash
set -euo pipefail

log_dir=$(realpath "${1:?pass an output directory}")
mkdir -p "$log_dir"
cd "$(dirname "$0")"
repo=$(mktemp -d /tmp/kotlin-e07-repo.XXXXXX)
printf 'LOCAL_REPO=%s\n' "$repo" > "$log_dir/environment.txt"

for version in 1.0.0 1.1.0 2.0.0; do
    ../gradlew --offline --no-daemon --console=plain :library:clean :library:publish \
        -PlibraryVersion="$version" -PlocalRepo="$repo" > "$log_dir/publish-$version.txt" 2>&1
    printf 'PUBLISH_%s_EXIT_CODE=0\n' "$version"
    jar="$repo/example/tasks/task-labels/$version/task-labels-$version.jar"
    sha256sum "$jar" >> "$log_dir/signatures.txt"
    javap -cp "$jar" -p example.abi.TaskLabels >> "$log_dir/signatures.txt"
done

for version in 1.0.0 1.1.0 2.0.0; do
    ../gradlew --offline --no-daemon --console=plain :consumer:oldConsumer \
        -PcompileVersion=1.0.0 -PruntimeVersion="$version" -PlocalRepo="$repo" > "$log_dir/old-$version.txt" 2>&1
    grep 'OLD_CONSUMER' "$log_dir/old-$version.txt"
done

../gradlew --offline --no-daemon --console=plain :consumer:clean :consumer:classes \
    -PcompileVersion=1.1.0 -PruntimeVersion=1.1.0 -PlocalRepo="$repo" > "$log_dir/source-1.1.0.txt" 2>&1
set +e
../gradlew --offline --no-daemon --console=plain :consumer:clean :consumer:classes \
    -PcompileVersion=2.0.0 -PruntimeVersion=2.0.0 -PlocalRepo="$repo" > "$log_dir/source-2.0.0.txt" 2>&1
kotlin_failure=$?
javac --release 21 -cp "$repo/example/tasks/task-labels/2.0.0/task-labels-2.0.0.jar" \
    -d "$repo" consumer/src/main/java/example/abi/OldJava.java > "$log_dir/java-source-2.0.0.txt" 2>&1
java_failure=$?
set -e
printf 'KOTLIN_SOURCE_2_EXIT_CODE=%s JAVA_SOURCE_2_EXIT_CODE=%s\n' "$kotlin_failure" "$java_failure"
test "$kotlin_failure" -ne 0 && test "$java_failure" -ne 0
grep -q "No value passed for parameter 'suffix'" "$log_dir/source-2.0.0.txt"
grep -q 'actual and formal argument lists differ in length' "$log_dir/java-source-2.0.0.txt"
