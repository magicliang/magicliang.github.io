rootProject.name = "abi-compat"
include(":library", ":consumer")
