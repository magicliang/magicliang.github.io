import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.jetbrains.kotlin.gradle.dsl.KotlinVersion
import org.gradle.jvm.application.tasks.CreateStartScripts

plugins {
    kotlin("jvm") version "2.2.21"
    kotlin("plugin.serialization") version "2.2.21"
    application
}

repositories {
    mavenCentral()
}

kotlin {
    jvmToolchain(21)
    compilerOptions {
        languageVersion.set(KotlinVersion.KOTLIN_2_2)
        apiVersion.set(KotlinVersion.KOTLIN_2_2)
        jvmTarget.set(JvmTarget.JVM_21)
    }
}

dependencies {
    implementation(project(":domain"))
    implementation("org.jetbrains.kotlin:kotlin-stdlib:2.2.21")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.10.2")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0")
    implementation("io.ktor:ktor-server-core-jvm:3.3.1")
    implementation("io.ktor:ktor-server-netty-jvm:3.3.1")
    implementation("io.ktor:ktor-server-content-negotiation-jvm:3.3.1")
    implementation("io.ktor:ktor-serialization-kotlinx-json-jvm:3.3.1")
    implementation("org.postgresql:postgresql:42.7.7")
    testImplementation(kotlin("test-junit5"))
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.10.2")
    testImplementation("io.ktor:ktor-server-test-host-jvm:3.3.1")
    testImplementation("org.openjdk.jmh:jmh-core:1.37")
    testImplementation("org.springframework:spring-aop:6.2.11")
    testImplementation("org.springframework:spring-r2dbc:6.2.11")
    testImplementation("org.springframework:spring-tx:6.2.11")
    testImplementation("org.postgresql:r2dbc-postgresql:1.0.7.RELEASE")
    testImplementation("io.r2dbc:r2dbc-pool:1.0.2.RELEASE")
    testImplementation("io.projectreactor:reactor-core:3.7.11")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-reactor:1.10.2")
    testAnnotationProcessor("org.openjdk.jmh:jmh-generator-annprocess:1.37")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher:1.12.2")
}

application {
    mainClass.set("example.tasks.MainKt")
}

tasks.test {
    useJUnitPlatform { excludeTags("loopback", "package", "comparison", "spring") }
}

tasks.register<Test>("springTest") {
    testClassesDirs = sourceSets.test.get().output.classesDirs
    classpath = sourceSets.test.get().runtimeClasspath
    useJUnitPlatform { includeTags("spring") }
    shouldRunAfter(tasks.test)
}

tasks.register<Test>("comparisonTest") {
    testClassesDirs = sourceSets.test.get().output.classesDirs
    classpath = sourceSets.test.get().runtimeClasspath
    useJUnitPlatform { includeTags("comparison") }
    shouldRunAfter(tasks.test)
}

tasks.register<Test>("loopbackTest") {
    testClassesDirs = sourceSets.test.get().output.classesDirs
    classpath = sourceSets.test.get().runtimeClasspath
    useJUnitPlatform { includeTags("loopback") }
    shouldRunAfter(tasks.test)
}

tasks.register<JavaExec>("jmh") {
    dependsOn(tasks.testClasses)
    classpath = sourceSets.test.get().runtimeClasspath
    mainClass.set("org.openjdk.jmh.Main")
    doFirst { layout.buildDirectory.dir("reports/jmh").get().asFile.mkdirs() }
    args(
        "example.tasks.TaskCostBenchmark", "-f", "2", "-wi", "3", "-i", "4",
        "-w", "250ms", "-r", "250ms", "-t", "1", "-prof", "gc",
        "-rf", "json", "-rff", layout.buildDirectory.file("reports/jmh/results.json").get().asFile.path,
    )
}

val serverStartScripts by tasks.registering(CreateStartScripts::class) {
    mainClass.set("example.tasks.TaskServerMainKt")
    applicationName = "task-server"
    outputDir = layout.buildDirectory.dir("server-scripts").get().asFile
    classpath = tasks.named<CreateStartScripts>("startScripts").get().classpath
}

distributions.main {
    contents {
        from(serverStartScripts) {
            into("bin")
            filePermissions { user.execute = true }
        }
    }
}

tasks.register<Test>("packageTest") {
    dependsOn(tasks.installDist)
    testClassesDirs = sourceSets.test.get().output.classesDirs
    classpath = sourceSets.test.get().runtimeClasspath
    useJUnitPlatform { includeTags("package") }
    shouldRunAfter(tasks.test)
}
