package main

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"testing"
	"time"

	"example.com/go-language-task/stats"
)

func TestLeaseReclaimFencesOldWorkerAndDeduplicatesEffect(t *testing.T) {
	db := openSQLTestDatabase(t)
	ctx := context.Background()
	repository, err := newLeaseRepository(ctx, db)
	if err != nil {
		t.Fatal(err)
	}
	id, err := repository.Submit(ctx, "Go one")
	if err != nil {
		t.Fatal(err)
	}
	defer db.ExecContext(ctx, "DELETE FROM go_task_effects WHERE task_id=$1", id)
	defer db.ExecContext(ctx, "DELETE FROM go_tasks WHERE id=$1", id)
	first, claimed, err := repository.Claim(ctx, id, "instance-A", 200*time.Millisecond)
	if err != nil || !claimed || first.Epoch != 1 {
		t.Fatalf("first claim=%+v claimed=%t err=%v", first, claimed, err)
	}
	if _, claimed, err := repository.Claim(ctx, id, "instance-B", time.Second); err != nil || claimed {
		t.Fatalf("early B claim=%t err=%v", claimed, err)
	}
	inserted, err := repository.ApplyEffect(ctx, first, "words=2")
	if err != nil || !inserted {
		t.Fatalf("first effect inserted=%t err=%v", inserted, err)
	}
	time.Sleep(230 * time.Millisecond)
	second, claimed, err := repository.Claim(ctx, id, "instance-B", time.Second)
	if err != nil || !claimed || second.Epoch != 2 {
		t.Fatalf("reclaim=%+v claimed=%t err=%v", second, claimed, err)
	}
	if _, err := repository.ApplyEffect(ctx, first, "words=2"); !errors.Is(err, errLeaseLost) {
		t.Fatalf("stale effect err=%v", err)
	}
	if err := repository.Finish(ctx, first, stats.Counts{Words: 9}, true); !errors.Is(err, errLeaseLost) {
		t.Fatalf("stale finish err=%v", err)
	}
	if inserted, err = repository.ApplyEffect(ctx, second, "words=2"); err != nil || inserted {
		t.Fatalf("duplicate effect inserted=%t err=%v", inserted, err)
	}
	if err := repository.Finish(ctx, second, stats.Analyze("Go one"), true); err != nil {
		t.Fatal(err)
	}
	snapshot, err := repository.Inspect(ctx, id)
	if err != nil || snapshot.Status != "SUCCEEDED" || snapshot.Epoch != 2 || snapshot.Words != 2 || snapshot.Effect.String != "words=2" || snapshot.Rows != 1 {
		t.Fatalf("snapshot=%+v err=%v", snapshot, err)
	}
	t.Logf("id=%s A epoch=1 B epoch=2 stale fenced; status=%s words=%d effect_rows=%d", id, snapshot.Status, snapshot.Words, snapshot.Rows)
}

func TestLeaseTwoConnectionsCannotClaimSameQueueRow(t *testing.T) {
	db := openSQLTestDatabase(t)
	db.SetMaxOpenConns(2)
	ctx := context.Background()
	repository, err := newLeaseRepository(ctx, db)
	if err != nil {
		t.Fatal(err)
	}
	id, err := repository.Submit(ctx, "Go")
	if err != nil {
		t.Fatal(err)
	}
	defer db.ExecContext(ctx, "DELETE FROM go_tasks WHERE id=$1", id)
	start := make(chan struct{})
	type claimResult struct {
		claimed bool
		err     error
	}
	results := make(chan claimResult, 2)
	var wait sync.WaitGroup
	for position := range 2 {
		wait.Add(1)
		go func() {
			defer wait.Done()
			<-start
			_, claimed, claimError := repository.Claim(ctx, id, fmt.Sprintf("worker-%d", position), time.Second)
			results <- claimResult{claimed: claimed, err: claimError}
		}()
	}
	close(start)
	wait.Wait()
	close(results)
	winners := 0
	for result := range results {
		if result.err != nil {
			t.Fatalf("concurrent claim failed: %v", result.err)
		}
		if result.claimed {
			winners++
		}
	}
	if winners != 1 {
		t.Fatalf("simultaneous claim winners=%d, want 1", winners)
	}
}
