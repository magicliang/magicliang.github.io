#!/usr/bin/env bash
set -u
evidence=$1
mkdir -p "$evidence"
capture() {
  local name=$1 command=$2 exit_code
  printf '%s\n' "$command" > "$evidence/$name.command"
  bash -c "$command" > "$evidence/$name.stdout" 2> "$evidence/$name.stderr"
  exit_code=$?
  printf '%s\n' "$exit_code" > "$evidence/$name.exit"
  printf '%s exit=%s\n' "$name" "$exit_code"
  return "$exit_code"
}
binary="$evidence/taskstats-lease"
capture build "GOWORK=off go build -o '$binary' ." || exit 1
capture invalid "'$binary' lease work --owner bad --id missing"
test "$(cat "$evidence/invalid.exit")" = 2 || exit 1
capture db-down "'$binary' lease inspect --sql-dsn 'host=127.0.0.1 port=1 user=admin dbname=postgres sslmode=disable connect_timeout=1' --id missing"
test "$(cat "$evidence/db-down.exit")" = 1 || exit 1
for stage in after-claim after-effect; do
  prefix=${stage#after-}
  capture "$prefix-submit" "'$binary' lease submit --sql-dsn '$GO_LANGUAGE_SQL_DSN' --text 'Go one'" || exit 1
  id=$(cat "$evidence/$prefix-submit.stdout")
  [[ "$id" =~ ^lease\[[a-f0-9]{24}\]$ ]] || exit 1
  printf '%s\n' "$id" > "$evidence/$prefix-task.id"
  capture "$prefix-queued" "'$binary' lease inspect --sql-dsn '$GO_LANGUAGE_SQL_DSN' --id '$id'" || exit 1
  rg -q 'status=QUEUED .*epoch=0 .*effect_rows=0' "$evidence/$prefix-queued.stdout" || exit 1
  capture "$prefix-worker-A" "'$binary' lease work --sql-dsn '$GO_LANGUAGE_SQL_DSN' --id '$id' --owner instance-A --ttl 2s --crash '$stage'"
  expected=72
  test "$stage" = after-effect && expected=73
  test "$(cat "$evidence/$prefix-worker-A.exit")" = "$expected" || exit 1
  rg -Fq "claimed id=$id owner=instance-A epoch=1" "$evidence/$prefix-worker-A.stdout" || exit 1
  capture "$prefix-running" "'$binary' lease inspect --sql-dsn '$GO_LANGUAGE_SQL_DSN' --id '$id'" || exit 1
  rg -q 'status=RUNNING owner=instance-A epoch=1' "$evidence/$prefix-running.stdout" || exit 1
  if [[ "$stage" == after-claim ]]; then
    rg -q 'effect_rows=0$' "$evidence/$prefix-running.stdout" || exit 1
  else
    rg -q 'effect=words=2 effect_rows=1$' "$evidence/$prefix-running.stdout" || exit 1
  fi
  capture "$prefix-worker-B-before-expiry" "'$binary' lease work --sql-dsn '$GO_LANGUAGE_SQL_DSN' --id '$id' --owner instance-B --ttl 2s"
  test "$(cat "$evidence/$prefix-worker-B-before-expiry.exit")" = 3 || exit 1
  capture "$prefix-wait-lease" 'sleep 2.2' || exit 1
  capture "$prefix-worker-B" "'$binary' lease work --sql-dsn '$GO_LANGUAGE_SQL_DSN' --id '$id' --owner instance-B --ttl 2s" || exit 1
  rg -Fq "claimed id=$id owner=instance-B epoch=2" "$evidence/$prefix-worker-B.stdout" || exit 1
  rg -Fq "finished id=$id status=SUCCEEDED words=2" "$evidence/$prefix-worker-B.stdout" || exit 1
  if [[ "$stage" == after-claim ]]; then
    rg -Fq "effect id=$id new=true" "$evidence/$prefix-worker-B.stdout" || exit 1
  else
    rg -Fq "effect id=$id new=false" "$evidence/$prefix-worker-B.stdout" || exit 1
  fi
  capture "$prefix-final" "'$binary' lease inspect --sql-dsn '$GO_LANGUAGE_SQL_DSN' --id '$id'" || exit 1
  rg -q 'status=SUCCEEDED owner= epoch=2 .*words=2 effect=words=2 effect_rows=1$' "$evidence/$prefix-final.stdout" || exit 1
  capture "$prefix-sql-final" "psql '$GO_LANGUAGE_SQL_DSN' -Atc \"SELECT t.id,t.status,t.words,t.lease_epoch,count(e.task_id) FROM go_tasks t LEFT JOIN go_task_effects e ON e.task_id=t.id WHERE t.id='$id' GROUP BY t.id\"" || exit 1
  rg -Fqx "$id|SUCCEEDED|2|2|1" "$evidence/$prefix-sql-final.stdout" || exit 1
  capture "$prefix-worker-A-late" "'$binary' lease work --sql-dsn '$GO_LANGUAGE_SQL_DSN' --id '$id' --owner instance-A --ttl 2s"
  test "$(cat "$evidence/$prefix-worker-A-late.exit")" = 3 || exit 1
done
