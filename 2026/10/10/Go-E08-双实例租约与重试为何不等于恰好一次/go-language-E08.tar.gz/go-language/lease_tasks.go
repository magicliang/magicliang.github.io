package main

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"time"

	"example.com/go-language-task/stats"
)

var errLeaseLost = errors.New("task lease no longer belongs to this worker")

type leaseRepository struct{ db *sql.DB }

type taskLease struct {
	ID       string
	Text     string
	Owner    string
	Epoch    int64
	Deadline time.Time
}

func newLeaseRepository(ctx context.Context, db *sql.DB) (*leaseRepository, error) {
	if _, err := newSQLTaskRepository(ctx, db); err != nil {
		return nil, err
	}
	for _, statement := range []string{
		`ALTER TABLE go_tasks ADD COLUMN IF NOT EXISTS lease_owner TEXT NOT NULL DEFAULT ''`,
		`ALTER TABLE go_tasks ADD COLUMN IF NOT EXISTS lease_epoch BIGINT NOT NULL DEFAULT 0`,
		`ALTER TABLE go_tasks ADD COLUMN IF NOT EXISTS lease_until TIMESTAMPTZ`,
		`CREATE TABLE IF NOT EXISTS go_task_effects (task_id TEXT PRIMARY KEY, payload TEXT NOT NULL)`,
	} {
		if _, err := db.ExecContext(ctx, statement); err != nil {
			return nil, fmt.Errorf("prepare lease schema: %w", err)
		}
	}
	return &leaseRepository{db: db}, nil
}

func (repository *leaseRepository) Submit(ctx context.Context, text string) (string, error) {
	var suffix [12]byte
	if _, err := rand.Read(suffix[:]); err != nil {
		return "", err
	}
	id := "lease[" + hex.EncodeToString(suffix[:]) + "]"
	return id, (&sqlTaskRepository{db: repository.db}).InsertQueued(ctx, id, text)
}

func (repository *leaseRepository) Claim(ctx context.Context, id, owner string, ttl time.Duration) (taskLease, bool, error) {
	var claim taskLease
	claim.ID, claim.Owner = id, owner
	err := repository.db.QueryRowContext(ctx, `UPDATE go_tasks SET status='RUNNING', lease_owner=$2,
		lease_epoch=lease_epoch+1, lease_until=clock_timestamp()+($3::bigint * interval '1 millisecond')
		WHERE id=$1 AND NOT cancel_requested AND
		(status='QUEUED' OR (status='RUNNING' AND lease_until < clock_timestamp()))
		RETURNING input_text,lease_epoch,lease_until`, id, owner, ttl.Milliseconds()).Scan(&claim.Text, &claim.Epoch, &claim.Deadline)
	if errors.Is(err, sql.ErrNoRows) {
		return taskLease{}, false, nil
	}
	if err != nil {
		return taskLease{}, false, fmt.Errorf("claim leased task: %w", err)
	}
	return claim, true, nil
}

func (repository *leaseRepository) ApplyEffect(ctx context.Context, claim taskLease, payload string) (bool, error) {
	tx, err := repository.db.BeginTx(ctx, nil)
	if err != nil {
		return false, err
	}
	defer tx.Rollback()
	var held int
	err = tx.QueryRowContext(ctx, `SELECT 1 FROM go_tasks WHERE id=$1 AND status='RUNNING'
		AND lease_owner=$2 AND lease_epoch=$3 AND lease_until>clock_timestamp() FOR UPDATE`, claim.ID, claim.Owner, claim.Epoch).Scan(&held)
	if errors.Is(err, sql.ErrNoRows) {
		return false, errLeaseLost
	}
	if err != nil {
		return false, err
	}
	result, err := tx.ExecContext(ctx, `INSERT INTO go_task_effects (task_id,payload) VALUES ($1,$2)
		ON CONFLICT (task_id) DO NOTHING`, claim.ID, payload)
	if err != nil {
		return false, err
	}
	inserted, err := result.RowsAffected()
	if err != nil {
		return false, err
	}
	var existing string
	if err := tx.QueryRowContext(ctx, `SELECT payload FROM go_task_effects WHERE task_id=$1`, claim.ID).Scan(&existing); err != nil {
		return false, err
	}
	if existing != payload {
		return false, fmt.Errorf("deduplicated effect differs from current result")
	}
	if err := tx.Commit(); err != nil {
		return false, err
	}
	return inserted == 1, nil
}

func (repository *leaseRepository) Finish(ctx context.Context, claim taskLease, counts stats.Counts, succeeded bool) error {
	terminal := StatusFailed
	if succeeded {
		terminal = StatusSucceeded
	}
	result, err := repository.db.ExecContext(ctx, `UPDATE go_tasks SET status=$4, words=$5, bytes=$6, runes=$7,
		lease_owner='', lease_until=NULL WHERE id=$1 AND status='RUNNING' AND lease_owner=$2
		AND lease_epoch=$3 AND lease_until>clock_timestamp()`, claim.ID, claim.Owner, claim.Epoch,
		terminal, counts.Words, counts.Bytes, counts.Runes)
	if err != nil {
		return err
	}
	changed, err := result.RowsAffected()
	if err != nil {
		return err
	}
	if changed != 1 {
		return errLeaseLost
	}
	return nil
}

type leaseSnapshot struct {
	ID       string
	Status   string
	Owner    string
	Epoch    int64
	Deadline sql.NullTime
	Words    int
	Effect   sql.NullString
	Rows     int
}

func (repository *leaseRepository) Inspect(ctx context.Context, id string) (leaseSnapshot, error) {
	var snapshot leaseSnapshot
	err := repository.db.QueryRowContext(ctx, `SELECT id,status,lease_owner,lease_epoch,lease_until,words,
		(SELECT payload FROM go_task_effects WHERE task_id=$1),
		(SELECT count(*) FROM go_task_effects WHERE task_id=$1)
		FROM go_tasks WHERE id=$1`, id).Scan(&snapshot.ID, &snapshot.Status, &snapshot.Owner,
		&snapshot.Epoch, &snapshot.Deadline, &snapshot.Words, &snapshot.Effect, &snapshot.Rows)
	return snapshot, err
}

func runLeaseTasks(args []string, stdout, stderr io.Writer) int {
	if len(args) == 0 {
		fmt.Fprintln(stderr, "usage: taskstats lease submit|work|inspect --sql-dsn DSN")
		return 2
	}
	action := args[0]
	flags := flag.NewFlagSet("taskstats lease", flag.ContinueOnError)
	flags.SetOutput(stderr)
	dsn := flags.String("sql-dsn", "", "isolated PostgreSQL DSN")
	id := flags.String("id", "", "task ID")
	text := flags.String("text", "", "task text")
	owner := flags.String("owner", "", "worker instance name")
	ttl := flags.Duration("ttl", 500*time.Millisecond, "lease duration")
	crash := flags.String("crash", "", "after-claim or after-effect")
	if err := flags.Parse(args[1:]); err != nil {
		return 2
	}
	if *dsn == "" || flags.NArg() != 0 || *ttl < 100*time.Millisecond || *ttl > 10*time.Second ||
		(action != "submit" && action != "work" && action != "inspect") ||
		(action == "submit" && (*text == "" || len(*text) > maxInputBytes)) ||
		(action != "submit" && *id == "") || (action == "work" && (*owner == "" || *crash != "" && *crash != "after-claim" && *crash != "after-effect")) {
		fmt.Fprintln(stderr, "invalid lease command arguments")
		return 2
	}
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Second)
	defer cancel()
	db, err := sql.Open("postgres", *dsn)
	if err != nil {
		fmt.Fprintln(stderr, err)
		return 1
	}
	defer db.Close()
	repository, err := newLeaseRepository(ctx, db)
	if err != nil {
		fmt.Fprintln(stderr, err)
		return 1
	}
	switch action {
	case "submit":
		newID, submitError := repository.Submit(ctx, *text)
		if submitError != nil {
			fmt.Fprintln(stderr, submitError)
			return 1
		}
		fmt.Fprintln(stdout, newID)
	case "inspect":
		snapshot, inspectError := repository.Inspect(ctx, *id)
		if inspectError != nil {
			fmt.Fprintln(stderr, inspectError)
			return 1
		}
		fmt.Fprintf(stdout, "id=%s status=%s owner=%s epoch=%d until=%s words=%d effect=%s effect_rows=%d\n",
			snapshot.ID, snapshot.Status, snapshot.Owner, snapshot.Epoch,
			snapshot.Deadline.Time.UTC().Format(time.RFC3339Nano), snapshot.Words, snapshot.Effect.String, snapshot.Rows)
	case "work":
		claim, claimed, claimError := repository.Claim(ctx, *id, *owner, *ttl)
		if claimError != nil {
			fmt.Fprintln(stderr, claimError)
			return 1
		}
		if !claimed {
			fmt.Fprintf(stdout, "not-claimed id=%s owner=%s\n", *id, *owner)
			return 3
		}
		fmt.Fprintf(stdout, "claimed id=%s owner=%s epoch=%d until=%s\n", claim.ID, claim.Owner, claim.Epoch, claim.Deadline.UTC().Format(time.RFC3339Nano))
		if *crash == "after-claim" {
			os.Exit(72)
		}
		counts, analyzeError := analyzeTaskAsyncContext(ctx, claim.Text, 3)
		if analyzeError == nil {
			inserted, effectError := repository.ApplyEffect(ctx, claim, fmt.Sprintf("words=%d", counts.Words))
			if effectError != nil {
				fmt.Fprintln(stderr, effectError)
				return 1
			}
			fmt.Fprintf(stdout, "effect id=%s new=%t\n", claim.ID, inserted)
			if *crash == "after-effect" {
				os.Exit(73)
			}
		} else {
			counts = stats.Counts{}
		}
		if err := repository.Finish(ctx, claim, counts, analyzeError == nil); err != nil {
			fmt.Fprintln(stderr, err)
			return 1
		}
		if analyzeError != nil {
			fmt.Fprintf(stdout, "failed id=%s reason=%v\n", claim.ID, analyzeError)
		} else {
			fmt.Fprintf(stdout, "finished id=%s status=SUCCEEDED words=%d\n", claim.ID, counts.Words)
		}
	}
	return 0
}
