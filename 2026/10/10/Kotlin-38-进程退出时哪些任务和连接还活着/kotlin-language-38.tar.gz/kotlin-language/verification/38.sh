#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/38"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && ./gradlew --version' || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test loopbackTest packageTest distZip jmh || exit 1
suite_count=0
for xml in build/test-results/test/TEST-example.tasks.*.xml; do
    suite="${xml##*/}"
    suite="${suite#TEST-example.tasks.}"
    suite="${suite%.xml}"
    run "$suite" cat "$xml" || exit 1
    ((suite_count+=1))
done
run TaskHttpLoopbackTest cat build/test-results/loopbackTest/TEST-example.tasks.TaskHttpRoutesTest.xml || exit 1
run TaskServerDistributionTest cat build/test-results/packageTest/TEST-example.tasks.TaskServerDistributionTest.xml || exit 1
run zipContents unzip -l build/distributions/kotlin-task-language.zip || exit 1
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit
invalid_result=$?

{
    printf 'suite_count=%s\ninvalid_exit=%s\n' "$suite_count" "$invalid_result"
    grep -Fq 'tests="1" skipped="0" failures="0" errors="0"' "$evidence/TaskServerLifecycleTest.txt" && echo stop_accepting_suite=PASS || echo stop_accepting_suite=FAIL
    grep -Fq 'LIFECYCLE request_id=req-38 task_id=task-38 rejected_after_stop=true final=Cancelled' "$evidence/TaskServerLifecycleTest.txt" && echo trace_and_cancel=PASS || echo trace_and_cancel=FAIL
    grep -Fq 'tests="1" skipped="0" failures="0" errors="0"' "$evidence/TaskServerDistributionTest.txt" && echo package_suite=PASS || echo package_suite=FAIL
    grep -Eq 'PACKAGE real_post=202 request_id=req-38-package task_id=packaged-38 final=Cancelled port_closed=true dispatcher_closed=true exit=(0|143)' "$evidence/TaskServerDistributionTest.txt" && echo real_process_exit=PASS || echo real_process_exit=FAIL
    grep -Fq 'RESOURCE_CLOSED dispatcher=true worker=true engine=true' "$evidence/TaskServerDistributionTest.txt" && echo resources_closed=PASS || echo resources_closed=FAIL
    grep -Fq 'kotlin-task-language/bin/task-server' "$evidence/zipContents.txt" && echo zip_has_server_launcher=PASS || echo zip_has_server_launcher=FAIL
    grep -Fq 'kotlin-task-language/lib/kotlin-task-language.jar' "$evidence/zipContents.txt" && echo zip_has_app_jar=PASS || echo zip_has_app_jar=FAIL
    grep -Fq 'tests="1" skipped="0" failures="0" errors="0"' "$evidence/TaskHttpLoopbackTest.txt" && echo real_loopback_regression=PASS || echo real_loopback_regression=FAIL
    grep -Fq 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" && echo valid_cli=PASS || echo valid_cli=FAIL
    grep -Fq 'Usage: submit <task text>' "$evidence/invalid.txt" && echo invalid_cli=PASS || echo invalid_cli=FAIL
} > "$evidence/assertions.txt"

test "$suite_count" -eq 40 && test "$invalid_result" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
