package example.tasks

import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.runBlocking

fun main(args: Array<String>) {
    val port = args.singleOrNull()?.toIntOrNull()
    require(port != null && port in 1..65535) { "Usage: task-server <port>" }
    val worker = Executors.newSingleThreadExecutor { task -> Thread(task, "kotlin-38-task-worker") }
    val dispatcher = worker.asCoroutineDispatcher()
    val registry = TaskHttpRegistry(
        execute = { draft ->
            if (draft.text == "wait") awaitCancellation()
            "completed:${draft.id.value}"
        },
        dispatcher = dispatcher,
        onRun = { requestId, taskId -> println("TASK_RUN request_id=$requestId task_id=$taskId") },
    )
    val server = embeddedServer(Netty, host = "127.0.0.1", port = port) { taskHttpRoutes(registry) }
    val terminated = CountDownLatch(1)
    Runtime.getRuntime().addShutdownHook(Thread({
        registry.stopAccepting()
        println("SERVICE_STOP_ACCEPTING port=$port")
        server.stop(500, 5000)
        runBlocking { registry.stop() }
        registry.snapshot().forEach { (taskId, entry) ->
            println("TASK_FINAL request_id=${entry.first} task_id=$taskId state=${entry.second::class.simpleName}")
        }
        dispatcher.close()
        val workerTerminated = worker.awaitTermination(5, TimeUnit.SECONDS)
        println("RESOURCE_CLOSED dispatcher=true worker=$workerTerminated engine=true")
        terminated.countDown()
    }, "kotlin-38-shutdown"))
    server.start(wait = false)
    println("SERVER_STARTED port=$port")
    terminated.await()
}
