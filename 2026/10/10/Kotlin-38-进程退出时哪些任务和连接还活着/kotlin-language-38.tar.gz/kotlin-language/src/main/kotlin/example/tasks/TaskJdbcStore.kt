package example.tasks

import java.sql.DriverManager
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext

class TaskJdbcStore(private val url: String, private val dispatcher: CoroutineDispatcher) {
    suspend fun insert(draft: TaskDraft, afterInsert: () -> Unit = {}): String = withContext(dispatcher) {
        DriverManager.getConnection(url).use { connection ->
            connection.autoCommit = false
            try {
                connection.prepareStatement("INSERT INTO task_snapshot (id, payload, state) VALUES (?, ?, ?)").use { statement ->
                    statement.setString(1, draft.id.value)
                    statement.setString(2, draft.text)
                    statement.setString(3, "Queued")
                    statement.executeUpdate()
                }
                afterInsert()
                connection.commit()
                Thread.currentThread().name
            } catch (failure: Exception) {
                connection.rollback()
                throw failure
            }
        }
    }

    suspend fun read(id: TaskId): String? = withContext(dispatcher) {
        DriverManager.getConnection(url).use { connection ->
            connection.prepareStatement("SELECT payload FROM task_snapshot WHERE id = ?").use { statement ->
                statement.setString(1, id.value)
                statement.executeQuery().use { result ->
                    if (result.next()) result.getString(1) else null
                }
            }
        }
    }
}
