package example.tasks

import io.ktor.http.HttpStatusCode
import io.ktor.server.application.Application
import io.ktor.server.application.install
import io.ktor.server.request.receive
import io.ktor.server.response.respond
import io.ktor.server.response.respondText
import io.ktor.server.response.header
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import io.ktor.server.routing.routing
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation
import io.ktor.serialization.kotlinx.json.json
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.coroutineContext

@Serializable
data class TaskHttpReply(val id: String, val state: String, val accepted: Boolean)

class TaskHttpRegistry(
    private val execute: suspend (TaskDraft) -> String = { "completed:${it.id.value}" },
    dispatcher: CoroutineDispatcher = Dispatchers.Default,
    private val onRun: (String, String) -> Unit = { _, _ -> },
) {
    private class Entry(val draft: TaskDraft, val requestId: String) {
        @Volatile var state: TaskState = TaskState.Queued
        lateinit var job: Job
    }

    private val owner = SupervisorJob()
    private val scope = CoroutineScope(owner + dispatcher)
    private val lock = Any()
    private val entries = mutableMapOf<String, Entry>()
    private var accepting = true

    fun submit(draft: TaskDraft, requestId: String = draft.id.value): SubmissionDecision = synchronized(lock) {
        check(accepting && owner.isActive) { "Task service has stopped" }
        val existing = entries[draft.id.value]
        if (existing != null) {
            return@synchronized if (existing.draft == draft) SubmissionDecision.Reused
            else SubmissionDecision.Rejected("Task ID already belongs to another draft")
        }
        val entry = Entry(draft, requestId)
        val job = scope.launch(start = CoroutineStart.LAZY) {
            entry.state = TaskState.Running
            try {
                onRun(entry.requestId, draft.id.value)
                val result = execute(draft)
                coroutineContext.ensureActive()
                entry.state = TaskState.Succeeded(result)
            } catch (cancelled: CancellationException) {
                entry.state = TaskState.Cancelled
                throw cancelled
            } catch (failure: Exception) {
                entry.state = TaskState.Failed(failure.message ?: "task failed")
            }
        }
        entry.job = job
        job.invokeOnCompletion { cause ->
            if (cause is CancellationException) entry.state = TaskState.Cancelled
        }
        entries[draft.id.value] = entry
        job.start()
        SubmissionDecision.Accepted
    }

    fun status(id: String): TaskState? = synchronized(lock) { entries[id]?.state }

    fun stopAccepting() = synchronized(lock) { accepting = false }

    fun snapshot(): Map<String, Pair<String, TaskState>> = synchronized(lock) {
        entries.mapValues { (_, entry) -> entry.requestId to entry.state }
    }

    suspend fun cancel(id: String): TaskState? {
        val entry = synchronized(lock) { entries[id] } ?: return null
        entry.job.cancelAndJoin()
        return entry.state
    }

    suspend fun await(id: String) {
        val entry = synchronized(lock) { entries[id] } ?: error("Unknown task ID")
        entry.job.join()
    }

    suspend fun stop() {
        stopAccepting()
        owner.cancelAndJoin()
    }
}

private fun reply(id: String, state: TaskState, accepted: Boolean) = TaskHttpReply(
    id,
    when (state) {
        TaskState.Queued -> "Queued"
        TaskState.Running -> "Running"
        is TaskState.Succeeded -> "Succeeded"
        is TaskState.Failed -> "Failed"
        TaskState.Cancelled -> "Cancelled"
    },
    accepted,
)

private val requestSequence = AtomicLong()

fun Application.taskHttpRoutes(registry: TaskHttpRegistry) {
    install(ContentNegotiation) { json() }
    routing {
        post("/tasks") {
            val requestId = call.request.headers["X-Request-Id"]
                ?.takeIf { it.matches(Regex("[a-zA-Z0-9_-]{1,64}")) }
                ?: "local-${requestSequence.incrementAndGet()}"
            call.response.header("X-Request-Id", requestId)
            val draft = try {
                call.receive<TaskRequestDto>().toDraft()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (invalid: Exception) {
                call.respondText("Invalid task request", status = HttpStatusCode.BadRequest)
                return@post
            }
            val decision = try {
                registry.submit(draft, requestId)
            } catch (stopped: IllegalStateException) {
                call.respondText("Task service has stopped", status = HttpStatusCode.ServiceUnavailable)
                return@post
            }
            when (decision) {
                SubmissionDecision.Accepted -> call.respond(HttpStatusCode.Accepted, reply(draft.id.value, TaskState.Queued, true))
                SubmissionDecision.Reused -> call.respond(HttpStatusCode.OK, reply(draft.id.value, registry.status(draft.id.value)!!, false))
                is SubmissionDecision.Rejected -> call.respondText("Task ID already exists", status = HttpStatusCode.Conflict)
            }
        }
        get("/tasks/{id}") {
            val id = call.parameters["id"] ?: return@get call.respond(HttpStatusCode.BadRequest)
            val state = registry.status(id) ?: return@get call.respond(HttpStatusCode.NotFound)
            call.respond(reply(id, state, false))
        }
        post("/tasks/{id}/cancel") {
            val id = call.parameters["id"] ?: return@post call.respond(HttpStatusCode.BadRequest)
            val state = registry.cancel(id) ?: return@post call.respond(HttpStatusCode.NotFound)
            call.respond(reply(id, state, false))
        }
    }
}
