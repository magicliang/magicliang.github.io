package example.tasks

import java.net.ServerSocket
import java.nio.file.Files
import java.nio.file.Path
import java.sql.DriverManager
import java.sql.SQLException
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.runBlocking

class TaskJdbcStoreTest {
    @Test
    fun transactionCommitRollbackAndRestartUseRealPostgres() = runBlocking {
        IsolatedPostgres().use { postgres ->
            val dispatcher = Executors.newSingleThreadExecutor { task -> Thread(task, "kotlin-35-jdbc") }.asCoroutineDispatcher()
            try {
                val store = TaskJdbcStore(postgres.url, dispatcher)
                val draft = makeTaskDraft(TaskId("task-35"), " alpha ", emptyList())
                val worker = store.insert(draft) {
                    assertEquals(null, independentRead(postgres.url, "task-35"))
                }
                assertTrue(worker.startsWith("kotlin-35-jdbc"))
                assertEquals("alpha", independentRead(postgres.url, "task-35"))
                assertEquals("alpha", store.read(TaskId("task-35")))
                assertFailsWith<IllegalStateException> {
                    store.insert(makeTaskDraft(TaskId("rollback-35"), "beta", emptyList())) {
                        assertEquals(null, independentRead(postgres.url, "rollback-35"))
                        throw IllegalStateException("injected before commit")
                    }
                }
                assertEquals(null, independentRead(postgres.url, "rollback-35"))
                postgres.restart()
                assertEquals("alpha", independentRead(postgres.url, "task-35"))
                assertEquals(null, independentRead(postgres.url, "rollback-35"))
                println("PG transaction_uncommitted_invisible=true committed_visible=true rollback_invisible=true restart_visible=true worker=kotlin-35-jdbc")
            } finally {
                dispatcher.close()
            }
        }
    }

    @Test
    fun driverCancelIsCheckedSeparatelyFromCoroutineCancellation() {
        IsolatedPostgres().use { postgres ->
            val statementRef = AtomicReference<java.sql.Statement>()
            val worker = Executors.newSingleThreadExecutor()
            try {
                val outcome = worker.submit(Callable {
                    DriverManager.getConnection(postgres.url).use { connection ->
                        connection.createStatement().use { statement ->
                            statementRef.set(statement)
                            try {
                                statement.executeQuery("SELECT pg_sleep(10)").use { it.next() }
                                "completed"
                            } catch (failure: SQLException) {
                                failure.sqlState
                            }
                        }
                    }
                })
                val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(5)
                var active = false
                while (!active && System.nanoTime() < deadline) {
                    active = DriverManager.getConnection(postgres.url).use { connection ->
                        connection.createStatement().use { statement ->
                            statement.executeQuery("SELECT count(*) FROM pg_stat_activity WHERE query = 'SELECT pg_sleep(10)' AND state = 'active'").use { result ->
                                result.next()
                                result.getInt(1) == 1
                            }
                        }
                    }
                    if (!active) Thread.sleep(20)
                }
                assertTrue(active)
                statementRef.get().cancel()
                assertEquals("57014", outcome.get(5, TimeUnit.SECONDS))
                println("PG driver_cancel_active_query=true sqlstate=57014 coroutine_cancellation_not_implied=true")
            } finally {
                worker.shutdownNow()
            }
        }
    }

    private fun independentRead(url: String, id: String): String? = DriverManager.getConnection(url).use { connection ->
        connection.prepareStatement("SELECT payload FROM task_snapshot WHERE id = ?").use { statement ->
            statement.setString(1, id)
            statement.executeQuery().use { result -> if (result.next()) result.getString(1) else null }
        }
    }
}

private class IsolatedPostgres : AutoCloseable {
    private val root = Files.createTempDirectory("kotlin-35-pg-")
    private val data = root.resolve("data")
    private val port = ServerSocket(0).use { it.localPort }
    private var running = false
    val url = "jdbc:postgresql://127.0.0.1:$port/postgres?sslmode=disable&user=admin"

    init {
        command("/usr/lib/postgresql/16/bin/initdb", "-A", "trust", "-U", "admin", "-D", data.toString(), "--no-instructions")
        start()
        DriverManager.getConnection(url).use { connection ->
            connection.createStatement().use { statement ->
                statement.executeUpdate("CREATE TABLE task_snapshot (id TEXT PRIMARY KEY, payload TEXT NOT NULL, state TEXT NOT NULL)")
            }
        }
    }

    fun restart() {
        stop()
        start()
    }

    private fun start() {
        command("/usr/lib/postgresql/16/bin/pg_ctl", "-D", data.toString(), "-l", root.resolve("server.log").toString(), "-o", "-h 127.0.0.1 -p $port -k $root", "-w", "start")
        running = true
    }

    private fun stop() {
        if (running) {
            command("/usr/lib/postgresql/16/bin/pg_ctl", "-D", data.toString(), "-m", "fast", "-w", "stop")
            running = false
        }
    }

    private fun command(vararg parts: String) {
        val process = ProcessBuilder(*parts).redirectErrorStream(true).start()
        val output = process.inputStream.bufferedReader().use { it.readText() }
        assertTrue(process.waitFor(45, TimeUnit.SECONDS), "Timed out: ${parts.first()}")
        assertEquals(0, process.exitValue(), output)
        println("PG_COMMAND=${parts.first().substringAfterLast('/')} EXIT_CODE=0")
    }

    override fun close() {
        try {
            stop()
        } finally {
            Files.walk(root).use { paths ->
                paths.sorted(Comparator.reverseOrder<Path>()).forEach(Files::deleteIfExists)
            }
        }
    }
}
