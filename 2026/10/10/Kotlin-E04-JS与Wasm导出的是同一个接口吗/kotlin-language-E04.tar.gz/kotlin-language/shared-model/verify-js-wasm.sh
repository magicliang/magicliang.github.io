#!/usr/bin/env bash
set -euo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$project"
bash verify-native.sh
../gradlew -p "$project" --offline --no-daemon --max-workers=2 --console=plain \
    jvmTest jsNodeTest wasmJsNodeTest jsDevelopmentExecutableCompileSync wasmJsDevelopmentExecutableCompileSync
node verify-js-wasm.mjs
