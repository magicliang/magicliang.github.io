import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const project = dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
const jsPath = resolve(project, 'build/compileSync/js/main/developmentExecutable/kotlin/kotlin-task-shared-model.js');
const wasmPath = resolve(project, 'build/compileSync/wasmJs/main/developmentExecutable/kotlin/kotlin-task-shared-model.mjs');
const js = require(jsPath).example.tasks;
const wasm = await import(pathToFileURL(wasmPath).href);

const text = 'hé🧪';
const expected = `Succeeded(result=${text})`;
assert.equal(js.taskReplyJs(text), expected);
assert.equal(wasm.taskReplyWasm(text), expected);
assert.equal(new TextEncoder().encode(text).length, 7);
assert.equal(text.length, 4);
assert.throws(() => js.taskReplyJs(' '), /Task text must not be blank/);
assert.throws(() => wasm.taskReplyWasm(' '), /Task text must not be blank/);

const asynchronous = js.taskReplyAsyncJs(text);
assert.equal(typeof asynchronous.then, 'function');
assert.equal(await asynchronous, expected);
await assert.rejects(js.taskReplyAsyncJs(' '), /Task text must not be blank/);

console.log('BOUNDARY JS=PASS WASM=PASS UNICODE_UTF8=7 JS_LENGTH=4 PROMISE_RESOLVE=PASS PROMISE_REJECT=PASS');
