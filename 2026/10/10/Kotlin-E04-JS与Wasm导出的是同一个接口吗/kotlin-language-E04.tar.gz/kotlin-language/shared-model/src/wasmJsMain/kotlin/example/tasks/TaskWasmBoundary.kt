@file:OptIn(kotlin.js.ExperimentalJsExport::class)

package example.tasks

import kotlin.js.JsExport

@JsExport
fun taskReplyWasm(text: String): String {
    require(text.isNotBlank()) { "Task text must not be blank" }
    return advanceTask(TaskState.Running, TaskSignal.Success(text)).toString()
}

fun main() {
    println("WASM_ENTRY ${taskReplyWasm("hé🧪")}")
}
