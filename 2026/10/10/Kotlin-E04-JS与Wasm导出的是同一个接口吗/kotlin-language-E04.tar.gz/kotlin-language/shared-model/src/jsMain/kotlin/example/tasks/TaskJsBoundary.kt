@file:OptIn(kotlin.js.ExperimentalJsExport::class)

package example.tasks

import kotlin.js.JsExport
import kotlin.js.Promise

@JsExport
fun taskReplyJs(text: String): String {
    require(text.isNotBlank()) { "Task text must not be blank" }
    return advanceTask(TaskState.Running, TaskSignal.Success(text)).toString()
}

@JsExport
fun taskReplyAsyncJs(text: String): Promise<String> = Promise { resolve, reject ->
    try {
        resolve(taskReplyJs(text))
    } catch (failure: Throwable) {
        reject(failure)
    }
}

fun main() {
    println("JS_ENTRY ${taskReplyJs("hé🧪")}")
}
