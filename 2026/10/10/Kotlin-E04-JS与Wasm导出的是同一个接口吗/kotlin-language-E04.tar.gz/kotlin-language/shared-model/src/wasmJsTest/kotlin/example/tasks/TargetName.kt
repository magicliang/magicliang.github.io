package example.tasks

actual fun targetName(): String = "Wasm/Node"
