import json
import pathlib
import statistics
import sys


evidence = pathlib.Path(sys.argv[1])
for fixture in ("trained", "unseen"):
    samples = {}
    for variant in ("off", "pgo"):
        files = sorted(evidence.glob(f"load-{fixture}-{variant}-*.stdout"))
        if len(files) != 5:
            raise ValueError(f"{fixture}/{variant}: expected 5 rounds, got {len(files)}")
        results = [json.loads(path.read_text()) for path in files]
        if any(result["go_tasks"] != 100 or result["server_exit"] != 0 or result["terminal"] != "SUCCEEDED" for result in results):
            raise ValueError(f"{fixture}/{variant}: invalid service result")
        samples[variant] = [result["elapsed_ns"] / 1_000_000 for result in results]
        print(f"{fixture}/{variant}: min={min(samples[variant]):.3f} median={statistics.median(samples[variant]):.3f} max={max(samples[variant]):.3f} ms")
    ratio = statistics.median(samples["pgo"]) / statistics.median(samples["off"])
    print(f"{fixture}: PGO/off median ratio={ratio:.3f}; <1 means faster in this run, >=1 means no observed gain")
