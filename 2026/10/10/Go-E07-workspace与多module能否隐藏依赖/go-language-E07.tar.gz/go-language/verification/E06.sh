#!/usr/bin/env bash
set -u
evidence=$1
mkdir -p "$evidence"
capture() {
  local name=$1 command=$2 exit_code
  printf '%s\n' "$command" > "$evidence/$name.command"
  bash -c "$command" > "$evidence/$name.stdout" 2> "$evidence/$name.stderr"
  exit_code=$?
  printf '%s\n' "$exit_code" > "$evidence/$name.exit"
  printf '%s exit=%s\n' "$name" "$exit_code"
  return "$exit_code"
}
capture train "go test -run '^\$' -bench '^BenchmarkTaskAnalyzeContext\$' -benchtime=3s -cpuprofile='$evidence/train.pprof' ." || exit 1
test -s "$evidence/train.pprof" || exit 1
capture profile-sha "sha256sum '$evidence/train.pprof'" || exit 1
if [[ -f go-language-task.test ]]; then capture test-binary-clean 'unlink ./go-language-task.test' || exit 1; fi
capture profile-top "go tool pprof -top -nodecount=20 '$evidence/train.pprof'" || exit 1
capture build-off "go build -trimpath -pgo=off -o '$evidence/taskstats-off' ." || exit 1
capture build-pgo "go build -trimpath -pgo='$evidence/train.pprof' -o '$evidence/taskstats-pgo' ." || exit 1
capture binary-versions "go version -m '$evidence/taskstats-off' && go version -m '$evidence/taskstats-pgo'" || exit 1
capture binary-sizes "python3 -c 'import os,sys; [print(path,os.path.getsize(path)) for path in sys.argv[1:]]' '$evidence/taskstats-off' '$evidence/taskstats-pgo' && sha256sum '$evidence/taskstats-off' '$evidence/taskstats-pgo'" || exit 1
capture missing-profile "go build -pgo='$evidence/missing.pprof' -o '$evidence/invalid-taskstats' ."
test "$(cat "$evidence/missing-profile.exit")" != 0 && test ! -e "$evidence/invalid-taskstats" || exit 1
for fixture in trained unseen; do
  for round in 1 2 3 4 5; do
    if (( round % 2 )); then variants=(off pgo); else variants=(pgo off); fi
    for variant in "${variants[@]}"; do
      capture "load-$fixture-$variant-$round" "python3 verification/E06-load.py '$evidence/taskstats-$variant' '$fixture'" || exit 1
    done
  done
done
capture summary "python3 verification/E06-summarize.py '$evidence'" || exit 1
