import json
import select
import signal
import subprocess
import sys
import time
import urllib.parse
import urllib.request


binary, fixture = sys.argv[1:]
if fixture == "trained":
    text, expected_words = "Go one two 你好 " * 128, 512
elif fixture == "unseen":
    text, expected_words = "新 任务 🌟 now " * 96, 384
else:
    raise ValueError(f"unknown fixture: {fixture}")

server = subprocess.Popen(
    [binary, "serve", "--listen", "127.0.0.1:0", "--admin", "127.0.0.1:0", "--workers", "2", "--queue-capacity", "8", "--max-words", "1000"],
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
)
server_error = ""
try:
    ready, _, _ = select.select([server.stdout], [], [], 10)
    if not ready:
        raise RuntimeError("service readiness timed out")
    address_line = server.stdout.readline().strip()
    if not address_line.startswith("http=127.0.0.1:"):
        raise RuntimeError(f"unexpected address line: {address_line}")
    address = address_line.split(" ", 1)[0].removeprefix("http=")
    base_url = f"http://{address}"

    def submit_and_confirm():
        payload = json.dumps({"text": text}).encode()
        request = urllib.request.Request(
            f"{base_url}/tasks", payload, {"Content-Type": "application/json"}, method="POST"
        )
        with urllib.request.urlopen(request, timeout=5) as response:
            if response.status != 202:
                raise RuntimeError(f"submit HTTP={response.status}")
            task_id = json.load(response)["id"]
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            encoded_id = urllib.parse.quote(task_id, safe="")
            with urllib.request.urlopen(f"{base_url}/tasks/{encoded_id}", timeout=5) as response:
                record = json.load(response)
            if record["status"] == "SUCCEEDED":
                if record["words"] != expected_words or record["id"] != task_id:
                    raise RuntimeError(f"wrong result: {record}")
                return task_id
            if record["status"] in ("FAILED", "CANCELED"):
                raise RuntimeError(f"task did not succeed: {record}")
            time.sleep(0.001)
        raise RuntimeError(f"task {task_id} did not finish")

    for _ in range(8):
        submit_and_confirm()
    started = time.perf_counter_ns()
    task_ids = [submit_and_confirm() for _ in range(100)]
    elapsed_ns = time.perf_counter_ns() - started
finally:
    if server.poll() is None:
        server.send_signal(signal.SIGTERM)
    _, server_error = server.communicate(timeout=10)

if server.returncode != 0:
    raise RuntimeError(f"server exit={server.returncode} stderr={server_error}")
print(json.dumps({
    "fixture": fixture,
    "binary": binary,
    "go_tasks": 100,
    "first_id": task_ids[0],
    "last_id": task_ids[-1],
    "terminal": "SUCCEEDED",
    "words_each": expected_words,
    "elapsed_ns": elapsed_ns,
    "server_exit": server.returncode,
    "server_stderr": server_error,
}, ensure_ascii=False))
