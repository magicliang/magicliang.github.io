#!/usr/bin/env bash
set -u
binary=$1 evidence=$2
mkdir -p "$evidence"
capture() {
  local name=$1 command=$2 exit_code
  printf '%s\n' "$command" > "$evidence/$name.command"
  bash -c "$command" > "$evidence/$name.stdout" 2> "$evidence/$name.stderr"
  exit_code=$?
  printf '%s\n' "$exit_code" > "$evidence/$name.exit"
  printf '%s exit=%s\n' "$name" "$exit_code"
  return "$exit_code"
}
capture bad-adapter "'$binary' serve --http-adapter nonexistent"
test "$(cat "$evidence/bad-adapter.exit")" = 2 && test ! -s "$evidence/bad-adapter.stdout" || exit 1
printf '%q ' "$binary" serve --http-adapter chi --workers 1 --queue-capacity 1 --sql-dsn "$GO_LANGUAGE_SERVE_DSN" > "$evidence/server.command"
printf '\n' >> "$evidence/server.command"
"$binary" serve --http-adapter chi --workers 1 --queue-capacity 1 --sql-dsn "$GO_LANGUAGE_SERVE_DSN" > "$evidence/server.stdout" 2> "$evidence/server.stderr" &
server_pid=$!
trap 'kill -TERM "$server_pid" 2>/dev/null || :; wait "$server_pid" 2>/dev/null || :' EXIT
ready=
for attempt in {1..50}; do
  if rg -q '^http=127\.0\.0\.1:[0-9]+ admin=127\.0\.0\.1:[0-9]+$' "$evidence/server.stdout"; then
    ready=$(rg '^http=' "$evidence/server.stdout" | head -1)
    break
  fi
  kill -0 "$server_pid" 2>/dev/null || exit 1
  sleep 0.1
done
test -n "$ready" || exit 1
app=${ready#http=}
app=${app%% admin=*}
admin=${ready##*admin=}
printf '%s\n' "$ready" > "$evidence/addresses.txt"
capture invalid "curl --globoff --silent --show-error --output '$evidence/invalid.body' --write-out 'HTTP_STATUS=%{http_code}\\n' -H 'Content-Type: application/json' -d '{\"text\":\"\"}' 'http://$app/tasks'" || exit 1
rg -q 'HTTP_STATUS=400' "$evidence/invalid.stdout" || exit 1
capture wrong-method "curl --globoff --silent --show-error --output '$evidence/wrong-method.body' --write-out 'HTTP_STATUS=%{http_code}\\n' 'http://$app/tasks'" || exit 1
rg -q 'HTTP_STATUS=405' "$evidence/wrong-method.stdout" || exit 1
capture missing "curl --globoff --silent --show-error --output '$evidence/missing.body' --write-out 'HTTP_STATUS=%{http_code}\\n' 'http://$app/tasks/missing'" || exit 1
rg -q 'HTTP_STATUS=404' "$evidence/missing.stdout" || exit 1
capture post "curl --globoff --silent --show-error --dump-header '$evidence/post.headers' --output '$evidence/post.body' --write-out 'HTTP_STATUS=%{http_code}\\n' -H 'X-Request-Id: known-chi-request' -H 'Content-Type: application/json' -d '{\"text\":\"Go one\"}' 'http://$app/tasks'" || exit 1
rg -q 'HTTP_STATUS=202' "$evidence/post.stdout" || exit 1
rg -qi '^X-Task-Request-Id: known-chi-request' "$evidence/post.headers" || exit 1
id=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["id"])' "$evidence/post.body")
encoded=$(python3 -c 'import sys; from urllib.parse import quote; print(quote(sys.argv[1],safe=""))' "$id")
printf '%s\n' "$id" > "$evidence/accepted.id"
finished=
for attempt in {1..50}; do
  capture "get-$attempt" "curl --globoff --silent --show-error --output '$evidence/get-$attempt.body' --write-out 'HTTP_STATUS=%{http_code}\\n' 'http://$app/tasks/$encoded'" || exit 1
  if rg -q '"status":"SUCCEEDED"' "$evidence/get-$attempt.body"; then finished=$attempt; break; fi
  sleep 0.1
done
test -n "$finished" || exit 1
printf 'id=%s SUCCEEDED poll=%s\n' "$id" "$finished" > "$evidence/terminal.txt"
capture sql-final "psql -h 127.0.0.1 -p $PGPORT -U admin -d goe05live -Atc \"SELECT id,status,words FROM go_tasks WHERE id='$id'\"" || exit 1
rg -Fqx "$id|SUCCEEDED|2" "$evidence/sql-final.stdout" || exit 1
capture sql-count "psql -h 127.0.0.1 -p $PGPORT -U admin -d goe05live -Atc 'SELECT count(*) FROM go_tasks'" || exit 1
test "$(cat "$evidence/sql-count.stdout")" = 1 || exit 1
capture app-debug "curl --globoff --silent --show-error --output '$evidence/app-debug.body' --write-out 'HTTP_STATUS=%{http_code}\\n' 'http://$app/debug/health'" || exit 1
rg -q 'HTTP_STATUS=404' "$evidence/app-debug.stdout" || exit 1
capture admin-health "curl --globoff --silent --show-error --output '$evidence/admin-health.body' --write-out 'HTTP_STATUS=%{http_code}\\n' 'http://$admin/debug/health'" || exit 1
rg -q 'HTTP_STATUS=200' "$evidence/admin-health.stdout" || exit 1
capture signal "kill -TERM $server_pid" || exit 1
printf 'wait %s\n' "$server_pid" > "$evidence/server-wait.command"
wait "$server_pid" > "$evidence/server-wait.stdout" 2> "$evidence/server-wait.stderr"
exit_code=$?
printf '%s\n' "$exit_code" > "$evidence/server-wait.exit"
test "$exit_code" = 0 || exit 1
trap - EXIT
