#!/usr/bin/env bash
set -u
evidence=$1
mkdir -p "$evidence"
capture() {
  local name=$1 command=$2 exit_code
  printf '%s\n' "$command" > "$evidence/$name.command"
  bash -c "$command" > "$evidence/$name.stdout" 2> "$evidence/$name.stderr"
  exit_code=$?
  printf '%s\n' "$exit_code" > "$evidence/$name.exit"
  printf '%s exit=%s\n' "$name" "$exit_code"
  return "$exit_code"
}
root=$(pwd)
reader=$(mktemp -d /tmp/go-language-E07-consumer.XXXXXX)
capture workspace-list 'go work edit -json && go env GOWORK' || exit 1
capture client-test 'cd client && GOWORK=off go test -count=1 -v ./...' || exit 1
capture workspace-build 'cd consumer && GOWORK=auto go build -o /dev/null .' || exit 1
capture copy-modules "cp -a '$root/client' '$root/consumer' '$reader/'" || exit 1
capture no-workspace-missing "cd '$reader/consumer' && GOWORK=off GOPROXY=off go build -mod=mod -o '$reader/missing-client' ."
test "$(cat "$evidence/no-workspace-missing.exit")" != 0 && test ! -e "$reader/missing-client" || exit 1
capture explicit-replace "cd '$reader/consumer' && GOWORK=off go mod edit -replace=example.com/go-language-task/client=../client" || exit 1
capture external-version "cd '$reader/consumer' && GOWORK=off go list -m -json example.com/go-language-task/client" || exit 1
rg -q '"Version": "v0.1.0"' "$evidence/external-version.stdout" || exit 1
rg -q '"Path": "../client"' "$evidence/external-version.stdout" || exit 1
capture external-build "cd '$reader/consumer' && GOWORK=off GOPROXY=off go build -o '$reader/consumer-binary' ." || exit 1
capture incompatible-copy "cp '$root/verification/E07-bad-consumer.go.txt' '$reader/consumer/bad.go'" || exit 1
capture incompatible-api "cd '$reader/consumer' && GOWORK=off GOPROXY=off go build -o '$reader/bad-consumer' bad.go"
test "$(cat "$evidence/incompatible-api.exit")" != 0 && test ! -e "$reader/bad-consumer" || exit 1
capture service-build "GOWORK=off go build -o '$reader/taskstats' ." || exit 1
printf '%q ' "$reader/taskstats" serve --sql-dsn "$GO_LANGUAGE_SQL_DSN" > "$evidence/service.command"
printf '\n' >> "$evidence/service.command"
"$reader/taskstats" serve --sql-dsn "$GO_LANGUAGE_SQL_DSN" > "$evidence/service.stdout" 2> "$evidence/service.stderr" &
service_pid=$!
trap 'kill -TERM "$service_pid" 2>/dev/null || :; wait "$service_pid" 2>/dev/null || :' EXIT
for attempt in {1..50}; do
  if rg -q '^http=127\.0\.0\.1:[0-9]+' "$evidence/service.stdout"; then break; fi
  kill -0 "$service_pid" 2>/dev/null || exit 1
  sleep 0.1
done
ready=$(rg '^http=' "$evidence/service.stdout" | head -1)
test -n "$ready" || exit 1
app=${ready#http=}
app=${app%% admin=*}
printf '%s\n' "$ready" > "$evidence/addresses.txt"
capture external-submit "'$reader/consumer-binary' 'http://$app'" || exit 1
id=$(sed -n 's/^accepted=//p' "$evidence/external-submit.stdout")
test -n "$id" && rg -Fqx "terminal=SUCCEEDED words=2 id=$id" "$evidence/external-submit.stdout" || exit 1
capture sql-result "psql '$GO_LANGUAGE_SQL_DSN' -Atc \"SELECT id,status,words FROM go_tasks WHERE id='$id'\"" || exit 1
rg -Fqx "$id|SUCCEEDED|2" "$evidence/sql-result.stdout" || exit 1
capture server-signal "kill -TERM $service_pid" || exit 1
printf 'wait %s\n' "$service_pid" > "$evidence/service-wait.command"
wait "$service_pid" > "$evidence/service-wait.stdout" 2> "$evidence/service-wait.stderr"
printf '%s\n' "$?" > "$evidence/service-wait.exit"
test "$(cat "$evidence/service-wait.exit")" = 0 || exit 1
trap - EXIT
