timeout 40s python3 -m http.server 41597 --bind 127.0.0.1 --directory '/tmp/go-language-hexo-E05.q7ORU1/public'
