bash verification/E05.sh /tmp/go-language-E05-taskstats '/home/admin/workspace/my-blogs/writing-plans/go-language/evidence/E05'
