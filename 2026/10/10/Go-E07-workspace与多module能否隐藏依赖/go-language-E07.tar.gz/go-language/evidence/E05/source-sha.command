sha256sum chi_tasks.go chi_tasks_test.go serve.go serve_test.go verification/E05.sh go.mod go.sum
