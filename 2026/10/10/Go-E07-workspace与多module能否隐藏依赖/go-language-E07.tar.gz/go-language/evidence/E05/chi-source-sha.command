cd "$(go env GOMODCACHE)/github.com/go-chi/chi/v5@v5.3.2" && sha256sum chi.go mux.go middleware/request_id.go
