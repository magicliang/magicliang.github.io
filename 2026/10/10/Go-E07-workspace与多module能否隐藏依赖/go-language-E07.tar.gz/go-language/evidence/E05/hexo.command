cd '/tmp/go-language-hexo-E05.q7ORU1' && PATH=/home/admin/.nvm/versions/node/v22.23.2/bin:$PATH ./node_modules/.bin/hexo generate --force --bail
