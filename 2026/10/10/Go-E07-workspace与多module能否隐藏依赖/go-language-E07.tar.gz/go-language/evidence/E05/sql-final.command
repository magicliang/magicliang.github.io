psql -h 127.0.0.1 -p 54401 -U admin -d goe05live -Atc "SELECT id,status,words FROM go_tasks WHERE id='task[0]'"
