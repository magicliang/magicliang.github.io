'/tmp/go-language-E05-taskstats' serve --http-adapter nonexistent
