/usr/lib/postgresql/16/bin/pg_ctl -D '/tmp/go-language-E05-pg.Y2do5J' -o '-h 127.0.0.1 -p 54401 -k /tmp/go-language-E05-pg.Y2do5J' -l '/tmp/go-language-E05-pg.Y2do5J/server.log' start
