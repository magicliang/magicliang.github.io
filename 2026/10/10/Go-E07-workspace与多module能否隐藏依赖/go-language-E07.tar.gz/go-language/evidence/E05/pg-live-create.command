psql -h 127.0.0.1 -p 54401 -U admin -d postgres -c 'CREATE DATABASE goe05live'
