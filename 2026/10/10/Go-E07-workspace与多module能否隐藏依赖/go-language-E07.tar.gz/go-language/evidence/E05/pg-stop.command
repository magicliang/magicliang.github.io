/usr/lib/postgresql/16/bin/pg_ctl -D '/tmp/go-language-E05-pg.Y2do5J' -m fast stop
