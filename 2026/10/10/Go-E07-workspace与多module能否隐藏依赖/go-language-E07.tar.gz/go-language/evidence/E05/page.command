python3 '/home/admin/workspace/my-blogs/writing-plans/go-language/scripts/check_page_00.py' '/tmp/go-language-hexo-E05.q7ORU1/public' 'E05'
