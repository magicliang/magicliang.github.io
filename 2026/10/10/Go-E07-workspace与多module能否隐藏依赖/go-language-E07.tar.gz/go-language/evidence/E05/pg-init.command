/usr/lib/postgresql/16/bin/initdb -D '/tmp/go-language-E05-pg.Y2do5J' -A trust -U admin --no-instructions
