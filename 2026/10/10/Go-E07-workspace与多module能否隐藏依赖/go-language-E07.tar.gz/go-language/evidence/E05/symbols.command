rg -n '^func (chiTaskHandler|TestChiAdapter|runTaskServer)' chi_tasks.go chi_tasks_test.go serve.go
