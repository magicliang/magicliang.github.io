psql -h 127.0.0.1 -p 54401 -U admin -d goe05live -Atc 'SELECT count(*) FROM go_tasks'
