(cd '/home/admin/workspace/my-blogs/source/_posts/2026-10-10-Go-E05-Web框架只替换哪一层' && sha256sum -c SHA256SUMS)
