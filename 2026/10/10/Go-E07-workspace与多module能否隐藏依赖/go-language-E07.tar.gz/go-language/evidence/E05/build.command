go build -trimpath -o /tmp/go-language-E05-taskstats .
