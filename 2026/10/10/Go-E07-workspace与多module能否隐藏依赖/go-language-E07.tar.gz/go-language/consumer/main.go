package main

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"os"
	"time"

	taskclient "example.com/go-language-task/client"
)

func main() {
	if len(os.Args) != 2 {
		fmt.Fprintln(os.Stderr, "usage: consumer http://127.0.0.1:port")
		os.Exit(2)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	client := taskclient.Client{BaseURL: os.Args[1], HTTP: &http.Client{Timeout: 2 * time.Second}}
	id, err := client.Submit(ctx, "Go one")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	fmt.Printf("accepted=%s\n", id)
	for ctx.Err() == nil {
		record, lookupError := client.Lookup(ctx, id)
		if lookupError != nil {
			err = lookupError
			break
		}
		if record.Status == "SUCCEEDED" && record.Words == 2 {
			fmt.Printf("terminal=%s words=%d id=%s\n", record.Status, record.Words, record.ID)
			return
		}
		if record.Status == "FAILED" || record.Status == "CANCELED" {
			err = fmt.Errorf("unexpected terminal state: %+v", record)
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if err == nil {
		err = ctx.Err()
	}
	if !errors.Is(err, context.Canceled) {
		fmt.Fprintln(os.Stderr, err)
	}
	os.Exit(1)
}
