module example.com/go-language-task/consumer

go 1.27.1

require example.com/go-language-task/client v0.1.0
