package main

import (
	"net/http"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
)

func chiTaskHandler(service *taskHTTPService) http.Handler {
	router := chi.NewRouter()
	router.Use(middleware.RequestID)
	router.Use(func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(output http.ResponseWriter, request *http.Request) {
			output.Header().Set("X-Task-Request-ID", middleware.GetReqID(request.Context()))
			next.ServeHTTP(output, request)
		})
	})
	router.Get("/health", func(output http.ResponseWriter, request *http.Request) {
		service.Handler().ServeHTTP(output, request)
	})
	router.Post("/tasks", service.create)
	router.Get("/tasks/{id}", func(output http.ResponseWriter, request *http.Request) {
		request.SetPathValue("id", chi.URLParam(request, "id"))
		service.lookup(output, request)
	})
	router.Post("/tasks/{id}/cancel", func(output http.ResponseWriter, request *http.Request) {
		request.SetPathValue("id", chi.URLParam(request, "id"))
		service.cancelTask(output, request)
	})
	return router
}
