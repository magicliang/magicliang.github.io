package taskclient

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestClientStatusAndTaskID(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(output http.ResponseWriter, request *http.Request) {
		switch request.URL.Path {
		case "/tasks":
			output.WriteHeader(http.StatusAccepted)
			output.Write([]byte(`{"id":"task[0]"}`))
		case "/tasks/task%5B0%5D":
			output.Write([]byte(`{"id":"task[0]","status":"SUCCEEDED","words":2}`))
		default:
			output.WriteHeader(http.StatusNotFound)
		}
	}))
	defer server.Close()
	client := Client{BaseURL: server.URL, HTTP: server.Client()}
	id, err := client.Submit(context.Background(), "Go one")
	if err != nil || id != "task[0]" {
		t.Fatalf("submit id=%q err=%v", id, err)
	}
	_, err = client.Lookup(context.Background(), "missing")
	var problem *HTTPError
	if !errors.As(err, &problem) || problem.Status != http.StatusNotFound {
		t.Fatalf("lookup error=%v", err)
	}
}
