package taskclient

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
)

type Client struct {
	BaseURL string
	HTTP    *http.Client
}

type Record struct {
	ID              string `json:"id"`
	Status          string `json:"status"`
	Words           int    `json:"words"`
	CancelRequested bool   `json:"cancel_requested"`
	FailureReason   string `json:"failure_reason"`
}

type HTTPError struct {
	Status int
	Detail string
}

func (problem *HTTPError) Error() string {
	return fmt.Sprintf("task HTTP %d: %s", problem.Status, problem.Detail)
}

func (client Client) Submit(ctx context.Context, text string) (string, error) {
	body, err := json.Marshal(struct {
		Text string `json:"text"`
	}{Text: text})
	if err != nil {
		return "", err
	}
	var reply struct {
		ID string `json:"id"`
	}
	if err := client.call(ctx, http.MethodPost, "/tasks", bytes.NewReader(body), http.StatusAccepted, &reply); err != nil {
		return "", err
	}
	if reply.ID == "" {
		return "", fmt.Errorf("accepted task without ID")
	}
	return reply.ID, nil
}

func (client Client) Lookup(ctx context.Context, id string) (Record, error) {
	var record Record
	err := client.call(ctx, http.MethodGet, "/tasks/"+url.PathEscape(id), nil, http.StatusOK, &record)
	return record, err
}

func (client Client) Cancel(ctx context.Context, id string) (Record, error) {
	var record Record
	err := client.call(ctx, http.MethodPost, "/tasks/"+url.PathEscape(id)+"/cancel", nil, http.StatusAccepted, &record)
	return record, err
}

func (client Client) call(ctx context.Context, method, path string, body io.Reader, expected int, reply any) error {
	if client.HTTP == nil || !strings.HasPrefix(client.BaseURL, "http://127.0.0.1:") {
		return fmt.Errorf("client needs an HTTP client and a loopback task URL")
	}
	request, err := http.NewRequestWithContext(ctx, method, strings.TrimRight(client.BaseURL, "/")+path, body)
	if err != nil {
		return err
	}
	if body != nil {
		request.Header.Set("Content-Type", "application/json")
	}
	response, err := client.HTTP.Do(request)
	if err != nil {
		return err
	}
	defer response.Body.Close()
	if response.StatusCode != expected {
		limited, _ := io.ReadAll(io.LimitReader(response.Body, 1024))
		return &HTTPError{Status: response.StatusCode, Detail: string(limited)}
	}
	if err := json.NewDecoder(io.LimitReader(response.Body, 4096)).Decode(reply); err != nil {
		return fmt.Errorf("decode task response: %w", err)
	}
	return nil
}
