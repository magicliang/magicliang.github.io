module example.com/go-language-task/client

go 1.27.1
