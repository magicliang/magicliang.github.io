package main

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"sync"
	"testing"

	"example.com/go-language-task/stats"
)

func TestChiAdapterPreservesTaskHTTPContract(t *testing.T) {
	for _, variant := range []struct {
		name    string
		handler func(*taskHTTPService) http.Handler
	}{
		{"standard", func(service *taskHTTPService) http.Handler { return service.Handler() }},
		{"chi", chiTaskHandler},
	} {
		t.Run(variant.name, func(t *testing.T) {
			service := newTaskHTTPService(context.Background(), 1, 1, 3)
			defer service.Close()
			server := httptest.NewServer(variant.handler(service))
			defer server.Close()
			if status, _, _ := postTask(t, server.Client(), server.URL, `{"text":"   "}`, "application/json"); status != http.StatusBadRequest {
				t.Fatalf("blank POST=%d", status)
			}
			status, _, payload := postTask(t, server.Client(), server.URL, `{"text":"Go one"}`, "application/json")
			if status != http.StatusAccepted {
				t.Fatalf("POST=%d body=%s", status, payload)
			}
			var accepted struct{ ID string `json:"id"` }
			if err := json.Unmarshal([]byte(payload), &accepted); err != nil || accepted.ID == "" {
				t.Fatalf("accepted=%q error=%v", payload, err)
			}
			service.Close()
			if status, record := getTask(t, server.Client(), server.URL, accepted.ID); status != http.StatusOK || record.Status != StatusSucceeded || record.Words != 2 {
				t.Fatalf("GET=%d record=%+v", status, record)
			}
			if status, _ := getTask(t, server.Client(), server.URL, "absent"); status != http.StatusNotFound {
				t.Fatalf("unknown GET=%d", status)
			}
			if status, _ := cancelHTTPTask(t, server.Client(), server.URL, accepted.ID); status != http.StatusConflict {
				t.Fatalf("terminal cancel=%d", status)
			}
			request, err := http.NewRequest(http.MethodGet, server.URL+"/tasks", nil)
			if err != nil {
				t.Fatal(err)
			}
			request.Header.Set("X-Request-Id", "known-request")
			response, err := server.Client().Do(request)
			if err != nil {
				t.Fatal(err)
			}
			response.Body.Close()
			if response.StatusCode != http.StatusMethodNotAllowed {
				t.Fatalf("wrong method=%d", response.StatusCode)
			}
			observed := response.Header.Get("X-Task-Request-ID")
			if variant.name == "chi" && observed != "known-request" || variant.name == "standard" && observed != "" {
				t.Fatalf("middleware request ID=%q", observed)
			}
			t.Logf("adapter=%s id=%s accepted=202 result=SUCCEEDED/words=2 bad=400 unknown=404 cancel=409 method=405 middleware=%q", variant.name, accepted.ID, observed)
		})
	}
}

func TestChiAdapterCancelWaitsForSQLWorker(t *testing.T) {
	db := openSQLTestDatabase(t)
	started := make(chan struct{})
	release := make(chan struct{})
	releaseWork := sync.OnceFunc(func() { close(release) })
	service, err := newTaskHTTPServiceWithSQLUsing(context.Background(), 1, 1, 3, db, func(context.Context, string, int) (stats.Counts, error) {
		close(started)
		<-release
		return stats.Counts{Words: 1}, nil
	})
	if err != nil {
		t.Fatal(err)
	}
	defer service.Close()
	defer releaseWork()
	if _, err := db.ExecContext(context.Background(), "TRUNCATE go_tasks"); err != nil {
		t.Fatal(err)
	}
	server := httptest.NewServer(chiTaskHandler(service))
	defer server.Close()
	status, _, payload := postTask(t, server.Client(), server.URL, `{"text":"Go"}`, "application/json")
	if status != http.StatusAccepted {
		t.Fatalf("submit=%d payload=%s", status, payload)
	}
	var accepted struct{ ID string `json:"id"` }
	if err := json.Unmarshal([]byte(payload), &accepted); err != nil || accepted.ID == "" {
		t.Fatalf("accepted=%q error=%v", payload, err)
	}
	<-started
	if status, record := cancelHTTPTask(t, server.Client(), server.URL, accepted.ID); status != http.StatusAccepted || record.Status != StatusRunning || !record.CancelRequested {
		t.Fatalf("cancel=%d record=%+v", status, record)
	}
	before, _, err := service.sqlStore.Lookup(context.Background(), accepted.ID)
	if err != nil || before.Status != StatusRunning || !before.CancelRequested {
		t.Fatalf("before exit=%+v error=%v", before, err)
	}
	t.Logf("chi cancel id=%s HTTP=202 while SQL=RUNNING/cancel_requested=true", accepted.ID)
	releaseWork()
	service.Close()
	if status, record := getTask(t, server.Client(), server.URL, accepted.ID); status != http.StatusOK || record.Status != StatusCanceled || record.Words != 0 {
		t.Fatalf("terminal=%d record=%+v", status, record)
	}
	t.Logf("worker exit id=%s final CANCELED/words=0", accepted.ID)
}
