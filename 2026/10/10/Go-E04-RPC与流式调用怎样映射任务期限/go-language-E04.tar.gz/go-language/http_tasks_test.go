package main

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"sync"
	"testing"

	"example.com/go-language-task/stats"
)

func postTask(t *testing.T, client *http.Client, base, body, contentType string) (int, string, string) {
	t.Helper()
	request, err := http.NewRequest(http.MethodPost, base+"/tasks", strings.NewReader(body))
	if err != nil {
		t.Fatal(err)
	}
	request.Header.Set("Content-Type", contentType)
	response, err := client.Do(request)
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	payload, err := io.ReadAll(response.Body)
	if err != nil {
		t.Fatal(err)
	}
	return response.StatusCode, response.Header.Get("Location"), string(payload)
}

func getTask(t *testing.T, client *http.Client, base, id string) (int, jsonTask) {
	t.Helper()
	response, err := client.Get(base + "/tasks/" + url.PathEscape(id))
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		return response.StatusCode, jsonTask{}
	}
	var record jsonTask
	if err := json.NewDecoder(response.Body).Decode(&record); err != nil {
		t.Fatal(err)
	}
	return response.StatusCode, record
}

func TestHTTPAckBeforeTaskCompletion(t *testing.T) {
	started := make(chan struct{})
	release := make(chan struct{})
	var once sync.Once
	service := newTaskHTTPServiceUsing(context.Background(), 1, 1, 3, func(_ context.Context, text string, _ int) (stats.Counts, error) {
		close(started)
		<-release
		return stats.Analyze(text), nil
	})
	server := httptest.NewServer(service.Handler())
	t.Cleanup(func() {
		once.Do(func() { close(release) })
		service.Close()
		server.Close()
	})
	status, location, body := postTask(t, server.Client(), server.URL, `{"text":"Go 写 Go"}`, "application/json; charset=utf-8")
	var accepted struct {
		ID string `json:"id"`
	}
	if status != http.StatusAccepted || json.Unmarshal([]byte(body), &accepted) != nil || accepted.ID != "task[0]" || location != "/tasks/task[0]" {
		t.Fatalf("status=%d location=%q body=%q", status, location, body)
	}
	<-started
	status, record := getTask(t, server.Client(), server.URL, accepted.ID)
	if status != http.StatusOK || record.Status != StatusRunning || record.Words != 0 {
		t.Fatalf("after handler returned status=%d record=%+v", status, record)
	}
	once.Do(func() { close(release) })
	service.Close()
	status, record = getTask(t, server.Client(), server.URL, accepted.ID)
	if status != http.StatusOK || record.Status != StatusSucceeded || record.Words != 3 {
		t.Fatalf("after worker exited status=%d record=%+v", status, record)
	}
	t.Logf("POST=202 id=%s; after handler GET=RUNNING; after worker exit GET=%s words=%d", accepted.ID, record.Status, record.Words)
}

func TestHTTPMethodsValidationAndOverload(t *testing.T) {
	started := make(chan struct{})
	release := make(chan struct{})
	var once sync.Once
	service := newTaskHTTPServiceUsing(context.Background(), 1, 1, 3, func(_ context.Context, text string, _ int) (stats.Counts, error) {
		if text == "hold" {
			close(started)
			<-release
		}
		return stats.Analyze(text), nil
	})
	server := httptest.NewServer(service.Handler())
	t.Cleanup(func() {
		once.Do(func() { close(release) })
		service.Close()
		server.Close()
	})
	response, err := server.Client().Get(server.URL + "/health")
	if err != nil {
		t.Fatal(err)
	}
	response.Body.Close()
	if response.StatusCode != http.StatusOK {
		t.Fatalf("health status=%d", response.StatusCode)
	}
	response, err = server.Client().Post(server.URL+"/health", "application/json", strings.NewReader("{}"))
	if err != nil {
		t.Fatal(err)
	}
	response.Body.Close()
	if response.StatusCode != http.StatusMethodNotAllowed {
		t.Fatalf("wrong method status=%d", response.StatusCode)
	}
	for _, testCase := range []struct {
		body        string
		contentType string
		want        int
	}{
		{`{"text":"Go"}`, "text/plain", http.StatusUnsupportedMediaType},
		{`{"text":"Go"}`, "application/json; charset=latin1", http.StatusUnsupportedMediaType},
		{`{"text":`, "application/json", http.StatusBadRequest},
		{`{"text":""}`, "application/json", http.StatusBadRequest},
		{`{"text":"   "}`, "application/json", http.StatusBadRequest},
		{`{"text":"Go","extra":1}`, "application/json", http.StatusBadRequest},
		{`{"text":"Go"}{}`, "application/json", http.StatusBadRequest},
		{`{"text":"` + strings.Repeat("a", maxInputBytes) + `"}`, "application/json", http.StatusRequestEntityTooLarge},
	} {
		status, _, body := postTask(t, server.Client(), server.URL, testCase.body, testCase.contentType)
		if status != testCase.want || !strings.Contains(body, `"error"`) {
			t.Fatalf("bad input status=%d want=%d body=%q", status, testCase.want, body)
		}
	}
	status, _, body := postTask(t, server.Client(), server.URL, `{"text":"hold"}`, "application/json")
	if status != http.StatusAccepted || !strings.Contains(body, `"id":"task[0]"`) {
		t.Fatalf("first accepted status=%d body=%q", status, body)
	}
	<-started
	status, _, body = postTask(t, server.Client(), server.URL, `{"text":"Go"}`, "application/json")
	if status != http.StatusAccepted || !strings.Contains(body, `"id":"task[1]"`) {
		t.Fatalf("second accepted status=%d body=%q", status, body)
	}
	status, _, body = postTask(t, server.Client(), server.URL, `{"text":"extra"}`, "application/json")
	if status != http.StatusServiceUnavailable || !strings.Contains(body, `"error"`) {
		t.Fatalf("overloaded status=%d body=%q", status, body)
	}
	if status, _ := getTask(t, server.Client(), server.URL, "task[2]"); status != http.StatusNotFound {
		t.Fatalf("rejected task visible: status=%d", status)
	}
	once.Do(func() { close(release) })
	service.Close()
	for _, id := range []string{"task[0]", "task[1]"} {
		if status, record := getTask(t, server.Client(), server.URL, id); status != http.StatusOK || record.Status != StatusSucceeded {
			t.Fatalf("accepted %s after close: status=%d record=%+v", id, status, record)
		}
	}
	t.Log("health=200 wrong-method=405 malformed/blank/unknown/trailing=400 size=413 media=415; queued accepted=202 overload=503 rejected lookup=404")
}

func TestHTTPAcceptedTaskCanFailBusinessValidation(t *testing.T) {
	service := newTaskHTTPService(context.Background(), 1, 1, 3)
	server := httptest.NewServer(service.Handler())
	t.Cleanup(func() {
		service.Close()
		server.Close()
	})
	status, _, body := postTask(t, server.Client(), server.URL, `{"text":"one two three four"}`, "application/json")
	if status != http.StatusAccepted || !strings.Contains(body, `"id":"task[0]"`) {
		t.Fatalf("acceptance status=%d body=%q", status, body)
	}
	service.Close()
	if status, record := getTask(t, server.Client(), server.URL, "task[0]"); status != http.StatusOK || record.Status != StatusFailed || record.Words != 0 {
		t.Fatalf("execution failed record status=%d record=%+v", status, record)
	}
	t.Log("HTTP 202 accepted; original analyzer rejects four words under maxWords=3; lookup FAILED")
}
