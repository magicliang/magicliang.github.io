package main

import (
	"bytes"
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"runtime"
	"runtime/pprof"
	"runtime/trace"
	"strings"
	"sync"
	"testing"
	"time"

	"example.com/go-language-task/stats"
)

func TestTaskWaitProfiles(t *testing.T) {
	profileDir := os.Getenv("GO_LANGUAGE_PROFILE_DIR")
	if profileDir == "" {
		profileDir = t.TempDir()
	}
	traceFile, err := os.Create(filepath.Join(profileDir, "trace.out"))
	if err != nil {
		t.Fatal(err)
	}
	defer traceFile.Close()
	if err := trace.Start(traceFile); err != nil {
		t.Fatal(err)
	}
	defer trace.Stop()
	runtime.SetBlockProfileRate(1)
	defer runtime.SetBlockProfileRate(0)
	previousMutexRate := runtime.SetMutexProfileFraction(1)
	defer runtime.SetMutexProfileFraction(previousMutexRate)

	started := make(chan struct{})
	release := make(chan struct{})
	var releaseOnce sync.Once
	service := newTaskHTTPServiceUsing(context.Background(), 1, 1, 2, func(ctx context.Context, text string, _ int) (stats.Counts, error) {
		if text == "hold" {
			trace.WithRegion(ctx, "task[0] analyzer wait", func() {
				close(started)
				<-release
			})
		}
		return stats.AnalyzeContext(ctx, text)
	})
	t.Cleanup(func() {
		releaseOnce.Do(func() { close(release) })
		service.Close()
	})
	handler := service.Handler()
	submit := func(text string) int {
		request := httptest.NewRequest(http.MethodPost, "/tasks", strings.NewReader(`{"text":"`+text+`"}`))
		request.Header.Set("Content-Type", "application/json")
		response := httptest.NewRecorder()
		handler.ServeHTTP(response, request)
		return response.Code
	}
	traceContext, traceTask := trace.NewTask(context.Background(), "task-service-36")
	defer traceTask.End()
	if status := submit("hold"); status != http.StatusAccepted {
		t.Fatalf("task[0] POST status=%d", status)
	}
	<-started
	waitStart := time.Now()
	trace.Log(traceContext, "task", "task[0] RUNNING")
	if status := submit("next"); status != http.StatusAccepted {
		t.Fatalf("task[1] POST status=%d", status)
	}
	trace.Log(traceContext, "task", "task[1] QUEUED")
	if status := submit("overflow"); status != http.StatusServiceUnavailable {
		t.Fatalf("queue overcapacity POST status=%d", status)
	}
	first, exists := service.store.Lookup("task[0]")
	if !exists || first.Status != StatusRunning {
		t.Fatalf("task[0] before release exists=%t record=%+v", exists, first)
	}
	second, exists := service.store.Lookup("task[1]")
	if !exists || second.Status != StatusQueued {
		t.Fatalf("task[1] before release exists=%t record=%+v", exists, second)
	}
	if _, exists := service.store.Lookup("task[2]"); exists {
		t.Fatal("overload created task[2]")
	}
	lookupStarted := make(chan struct{})
	lookupDone := make(chan int, 1)
	service.store.mu.Lock()
	go func() {
		request := httptest.NewRequest(http.MethodGet, "/tasks/task[0]", nil)
		response := httptest.NewRecorder()
		close(lookupStarted)
		handler.ServeHTTP(response, request)
		lookupDone <- response.Code
	}()
	<-lookupStarted
	var goroutineProfile bytes.Buffer
	blocked := false
	for deadline := time.Now().Add(2 * time.Second); time.Now().Before(deadline); {
		goroutineProfile.Reset()
		if err := pprof.Lookup("goroutine").WriteTo(&goroutineProfile, 2); err != nil {
			service.store.mu.Unlock()
			t.Fatal(err)
		}
		for _, stack := range strings.Split(goroutineProfile.String(), "goroutine ") {
			if strings.Contains(stack, "TaskStore).Lookup") && strings.Contains(stack, "[sync.Mutex.Lock]") {
				blocked = true
				break
			}
		}
		if blocked {
			break
		}
		runtime.Gosched()
	}
	service.store.mu.Unlock()
	if !blocked {
		t.Fatalf("GET was not observed waiting on store mutex:\n%s", goroutineProfile.String())
	}
	if status := <-lookupDone; status != http.StatusOK {
		t.Fatalf("GET status=%d", status)
	}
	blockedWall := time.Since(waitStart)
	releaseOnce.Do(func() { close(release) })
	service.Close()
	completionWall := time.Since(waitStart)
	for _, item := range []struct {
		id    string
		words int
	}{{"task[0]", 1}, {"task[1]", 1}} {
		record, found := service.store.Lookup(item.id)
		if !found || record.Status != StatusSucceeded || record.Words != item.words {
			t.Fatalf("%s found=%t record=%+v", item.id, found, record)
		}
		trace.Logf(traceContext, "task", "%s SUCCEEDED words=%d", item.id, item.words)
	}
	for _, kind := range []string{"block", "mutex"} {
		file, err := os.Create(filepath.Join(profileDir, kind+".pprof"))
		if err != nil {
			t.Fatal(err)
		}
		if err := pprof.Lookup(kind).WriteTo(file, 0); err != nil {
			file.Close()
			t.Fatal(err)
		}
		if err := file.Close(); err != nil {
			t.Fatal(err)
		}
	}
	t.Logf("task[0]=SUCCEEDED task[1]=SUCCEEDED rejected=503; GET task[0] blocked on TaskStore.Lookup mutex; blockedWall=%s completionWall=%s; release and service.Close confirmed", blockedWall, completionWall)
}
