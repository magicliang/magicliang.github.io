package main

import (
	"context"
	"fmt"
	"strings"

	"example.com/go-language-task/stats"
)

func analyzeTaskAsyncContext(ctx context.Context, text string, maxWords int) (stats.Counts, error) {
	done := make(chan struct{})
	var counts stats.Counts
	var err error
	go func() {
		defer close(done)
		counts, err = analyzeTaskContext(ctx, text, maxWords)
	}()
	<-done
	return counts, err
}

func analyzeTaskContext(ctx context.Context, text string, maxWords int) (stats.Counts, error) {
	if err := ctx.Err(); err != nil {
		return stats.Counts{}, err
	}
	if strings.TrimSpace(text) == "" {
		return stats.Counts{}, fmt.Errorf("text must not be empty: %w", ErrInvalidInput)
	}
	counts, err := stats.AnalyzeContext(ctx, text)
	if err != nil {
		return stats.Counts{}, err
	}
	if counts.Words > maxWords {
		return counts, fmt.Errorf("word count %d exceeds max-words %d: %w", counts.Words, maxWords, ErrInvalidInput)
	}
	return counts, nil
}
