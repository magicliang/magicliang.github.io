package main

import (
	"context"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestSQLHTTPPoolWaitDeadlineAndRecovery(t *testing.T) {
	db := openSQLTestDatabase(t)
	service, err := newTaskHTTPServiceWithSQL(context.Background(), 1, 1, 3, db)
	if err != nil {
		t.Fatal(err)
	}
	defer service.Close()
	service.sqlRequestTimeout = 60 * time.Millisecond
	if _, err := db.ExecContext(context.Background(), "TRUNCATE go_tasks"); err != nil {
		t.Fatal(err)
	}
	if err := service.sqlStore.InsertQueued(context.Background(), "held", "Go"); err != nil {
		t.Fatal(err)
	}
	server := httptest.NewServer(service.Handler())
	defer server.Close()
	connection, err := db.Conn(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	defer connection.Close()
	before := db.Stats()
	for _, request := range []struct {
		name string
		call func() int
	}{
		{"GET", func() int { status, _ := getTask(t, server.Client(), server.URL, "held"); return status }},
		{"POST", func() int {
			status, _, _ := postTask(t, server.Client(), server.URL, `{"text":"Go"}`, "application/json")
			return status
		}},
		{"cancel", func() int { status, _ := cancelHTTPTask(t, server.Client(), server.URL, "held"); return status }},
	} {
		start := time.Now()
		status := request.call()
		elapsed := time.Since(start)
		if status != http.StatusServiceUnavailable || elapsed > time.Second {
			t.Fatalf("%s with occupied connection: status=%d elapsed=%s", request.name, status, elapsed)
		}
		t.Logf("pool occupied: %s HTTP=%d elapsed=%s", request.name, status, elapsed)
	}
	after := db.Stats()
	if after.MaxOpenConnections != 1 || after.InUse != 1 || after.WaitCount-before.WaitCount < 3 {
		t.Fatalf("pool wait not exercised: before=%+v after=%+v", before, after)
	}
	if err := connection.Close(); err != nil {
		t.Fatal(err)
	}
	if status, record := getTask(t, server.Client(), server.URL, "held"); status != http.StatusOK || record.Status != StatusQueued {
		t.Fatalf("GET after release status=%d record=%+v", status, record)
	}
	if status, _, _ := postTask(t, server.Client(), server.URL, `{"text":"Go"}`, "application/json"); status != http.StatusAccepted {
		t.Fatalf("POST after release status=%d", status)
	}
	service.Close()
	if status, record := getTask(t, server.Client(), server.URL, "task[0]"); status != http.StatusOK || record.Status != StatusSucceeded || record.Words != 1 {
		t.Fatalf("accepted task after worker exit status=%d record=%+v", status, record)
	}
	t.Logf("connection released: GET=200 QUEUED; POST=202; worker exit GET=200 SUCCEEDED words=1; WaitCount delta=%d WaitDuration delta=%s", after.WaitCount-before.WaitCount, after.WaitDuration-before.WaitDuration)
}

func TestSQLDriverQueryDeadlineAndRecovery(t *testing.T) {
	db := openSQLTestDatabase(t)
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Millisecond)
	defer cancel()
	start := time.Now()
	_, err := db.ExecContext(ctx, "SELECT pg_sleep(2)")
	if err == nil || ctx.Err() != context.DeadlineExceeded || time.Since(start) > time.Second {
		t.Fatalf("slow SQL deadline: err=%v context=%v elapsed=%s", err, ctx.Err(), time.Since(start))
	}
	t.Logf("slow SQL: error=%q caller context=%v elapsed=%s", err, ctx.Err(), time.Since(start))
	recoveryContext, cancelRecovery := context.WithTimeout(context.Background(), time.Second)
	defer cancelRecovery()
	var value int
	if err := db.QueryRowContext(recoveryContext, "SELECT 1").Scan(&value); err != nil || value != 1 {
		t.Fatalf("SQL after timed-out query: value=%d err=%v", value, err)
	}
	t.Log("SQL after timed-out query: SELECT 1 returned 1")
}
