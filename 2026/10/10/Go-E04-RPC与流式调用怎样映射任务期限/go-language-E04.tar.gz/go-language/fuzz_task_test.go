package main

import (
	"bytes"
	"context"
	"net/http"
	"net/http/httptest"
	"testing"

	"example.com/go-language-task/stats"
)

func FuzzHTTPTaskSubmission(f *testing.F) {
	for _, input := range [][]byte{
		[]byte(`{"text":"Go"}`),
		[]byte(`{"text":"你好 Go"}`),
		[]byte(`{"text":" "}`),
		[]byte(`{"text":1}`),
		[]byte(`{"text":"Go","unknown":true}`),
		[]byte(`{"text":"Go"}{"text":"again"}`),
		[]byte(`{"text":"` + string(bytes.Repeat([]byte("a"), maxInputBytes)) + `"}`),
	} {
		f.Add(input)
	}
	f.Fuzz(func(t *testing.T, payload []byte) {
		if len(payload) > maxInputBytes+64 {
			return
		}
		service := newTaskHTTPService(context.Background(), 1, 1, 3)
		defer service.Close()
		request := httptest.NewRequest(http.MethodPost, "/tasks", bytes.NewReader(payload))
		request.Header.Set("Content-Type", "application/json")
		response := httptest.NewRecorder()
		service.Handler().ServeHTTP(response, request)
		service.Close()
		status := response.Code
		record, exists := service.store.Lookup("task[0]")
		if status == http.StatusAccepted {
			if !exists || service.nextID != 1 || record.Status != StatusSucceeded && record.Status != StatusFailed {
				t.Fatalf("accepted input without exactly one completed task: status=%d record=%+v exists=%v nextID=%d", status, record, exists, service.nextID)
			}
			return
		}
		if status != http.StatusBadRequest && status != http.StatusRequestEntityTooLarge {
			t.Fatalf("unexpected HTTP status=%d payload-length=%d", status, len(payload))
		}
		if exists || service.nextID != 0 {
			t.Fatalf("rejected input created task: status=%d record=%+v exists=%v nextID=%d", status, record, exists, service.nextID)
		}
	})
}

func FuzzTaskStateSequence(f *testing.F) {
	for _, sequence := range [][]byte{
		{},
		{0, 1, 3, 2},
		{3, 0, 1},
		{0, 3, 1},
		{2, 0, 2, 1},
	} {
		f.Add(sequence)
	}
	f.Fuzz(func(t *testing.T, sequence []byte) {
		if len(sequence) > 64 {
			return
		}
		store := newTaskStore(nil)
		store.Add("task[0]")
		for _, operation := range sequence {
			before, _ := store.Lookup("task[0]")
			switch operation % 4 {
			case 0:
				store.Start("task[0]")
			case 1:
				store.Complete("task[0]", stats.Counts{Words: 1, Bytes: 2, Runes: 2})
			case 2:
				store.Fail("task[0]")
			case 3:
				store.Cancel("task[0]")
			}
			after, _ := store.Lookup("task[0]")
			if before.Status == StatusSucceeded || before.Status == StatusFailed || before.Status == StatusCanceled {
				if after != before {
					t.Fatalf("terminal state changed on operation %d: before=%+v after=%+v", operation, before, after)
				}
			}
			if store.TerminalCount() > 1 {
				t.Fatalf("task became terminal more than once: count=%d", store.TerminalCount())
			}
			if after.Status != StatusSucceeded && after.Counts != (stats.Counts{}) {
				t.Fatalf("partial result in non-success state: %+v", after)
			}
		}
	})
}
