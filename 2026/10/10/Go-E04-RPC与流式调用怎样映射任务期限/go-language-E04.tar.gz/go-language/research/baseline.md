# Go 00 基线：2026-10-07

## 已冻结

| 对象 | 实际值与证据 |
|---|---|
| 工具链 | 官方 `go1.27.1.linux-amd64.tar.gz`，`go version go1.27.1 linux/amd64`；下载 SHA-256 `63d339f0da5ab53635a56f2490a7984dfe12dfcff22ad749f63edaf590168445`，`evidence/00/toolchain-sha.*` 的 `sha256sum -c` 退出 0 |
| 源码 | tag `go1.27.1`；完整 Git SHA `862c888e612ac346c7c4d99c9392bdfd265f33b0`（Gitee 镜像 `git ls-remote` 实测，`evidence/00/source-sha.*`），未直接从官方 Gitiles 交叉校验 |
| 环境 | Ubuntu 24.04.4 LTS，内核 `5.10.134-013.16.kangaroo.al8.x86_64`，linux/amd64，cgroup v1，CPU quota `400000/100000`，cpuset `0-3`，memory limit `8589934592` 字节；`evidence/00/platform.*`、`os-release.txt`、`resource-limits.*` |
| 编译运行 | `GOTOOLCHAIN=local`，`GOMAXPROCS=2`，`CGO_ENABLED=0`；`evidence/00/environment.txt`、`go-env.*`；race detector 本章 `NOT_RUN` |
| module | `example.com/go-language-task`；`go.mod` 指令 `go 1.27.1`，无 `toolchain` 指令，无第三方依赖或 `go.sum`；`evidence/00/module-list.*` |

`go.mod` 初稿含与 `go` 指令完全同版的 `toolchain`，`go mod tidy -diff` 要求移除，初次 `go test` 因此退出 1（`initial-test.*`）；调整后 `tidy-check.exit=0`、`test.exit=0`。首次失败不能隐去，也不能算成业务反例。

## 一手资料与边界

- 版本说明与下载：<https://go.dev/dl/>；本次按官方 `dl.google.com` 提供的 `.sha256` 与实际下载文件校验。源码安装包中的 `doc/go_spec.html` 是这版的语言规范；在线入口 <https://go.dev/ref/spec> 随版本更新，不单独充当冻结快照。
- `package main`、`func main`：`go1.27.1` 的 `doc/go_spec.html` 中 Packages 与 Program execution 段；`go help build`、`go help test` 是当前实际命令行的约定入口。
- 统计口径：本版 `src/strings/strings.go` 的 `Fields`（约第 359–365 行），公开契约按 `unicode.IsSpace` 分字段，纯空白返回空切片；在线 API <https://pkg.go.dev/strings#Fields>。
- 测试框架：本版 `src/testing/testing.go` 和 `go help test`；<https://pkg.go.dev/testing> 的当前页只作为入口。
- 工具链与 module 区别：<https://go.dev/doc/modules/gomod-ref>；已记录实际 `go` 指令、无 `toolchain` 指令、`GOTOOLCHAIN=local` 和可执行文件的 `go version -m` 输出，不能从网页推出本机已成功构建。

00 的结果只涉及单进程顺序统计；不使用内存模型、调度源码或 race 结果推断未来章节。本次 Git tag SHA 来自镜像，官方源码服务访问失败，因此官方远端比对仍为 `NOT_RUN`；在源码解析章节进一步核实源码文件和符号。
