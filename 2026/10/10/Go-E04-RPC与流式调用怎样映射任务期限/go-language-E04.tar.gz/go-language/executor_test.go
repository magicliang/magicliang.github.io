package main

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"sync/atomic"
	"testing"

	"example.com/go-language-task/stats"
)

func TestExecutorConcurrentSubmitAndRepeatedClose(t *testing.T) {
	texts := make([]string, 64)
	for position := range texts {
		texts[position] = "Go"
	}
	store := newTaskStore(texts)
	started := make(chan struct{}, 2)
	release := make(chan struct{})
	var active atomic.Int32
	executor := newTaskExecutor(context.Background(), len(texts), 3, 2, 1, func(_ context.Context, text string, _ int) (stats.Counts, error) {
		active.Add(1)
		started <- struct{}{}
		<-release
		active.Add(-1)
		return stats.Analyze(text), nil
	}, store)
	for position := 0; position < 3; position++ {
		if position == 2 {
			<-started
			<-started
		}
		if err := executor.Submit(context.Background(), queuedTask{position: position, text: "Go"}, false); err != nil {
			t.Fatal(err)
		}
	}
	start := make(chan struct{})
	accepted := make(chan int, len(texts)-3)
	refused := make(chan error, len(texts)-3)
	var callers sync.WaitGroup
	for position := 3; position < len(texts); position++ {
		callers.Add(1)
		go func(position int) {
			defer callers.Done()
			<-start
			if err := executor.Submit(context.Background(), queuedTask{position: position, text: "Go"}, false); err != nil {
				refused <- err
			} else {
				accepted <- position
			}
		}(position)
	}
	var closers sync.WaitGroup
	for range 3 {
		closers.Add(1)
		go func() {
			defer closers.Done()
			<-start
			executor.Close()
		}()
	}
	close(start)
	closers.Wait()
	callers.Wait()
	close(accepted)
	close(refused)
	for err := range refused {
		if !errors.Is(err, ErrExecutorClosed) {
			t.Fatalf("closed executor returned %v", err)
		}
	}
	if err := executor.Submit(context.Background(), queuedTask{position: 3, text: "Go"}, false); !errors.Is(err, ErrExecutorClosed) {
		t.Fatalf("post-close submission=%v", err)
	}
	if active.Load() != 2 {
		t.Fatalf("Close claimed worker exit while active=%d", active.Load())
	}
	close(release)
	results := executor.Wait()
	if active.Load() != 0 || len(results) != len(texts) {
		t.Fatalf("wait returned active=%d results=%d", active.Load(), len(results))
	}
	acceptedCount := 3
	for position := range accepted {
		acceptedCount++
		record, _ := store.Lookup(fmt.Sprintf("task[%d]", position))
		if record.Status != StatusSucceeded || results[position].counts.Words != 1 {
			t.Fatalf("accepted task[%d] record=%+v outcome=%+v", position, record, results[position])
		}
	}
	for position := 0; position < 3; position++ {
		record, _ := store.Lookup(fmt.Sprintf("task[%d]", position))
		if record.Status != StatusSucceeded || results[position].counts.Words != 1 {
			t.Fatalf("accepted task[%d] record=%+v outcome=%+v", position, record, results[position])
		}
	}
	if store.TerminalCount() != uint64(acceptedCount) {
		t.Fatalf("terminal=%d accepted=%d", store.TerminalCount(), acceptedCount)
	}
	t.Logf("close callers=3; accepted=%d; rejected=%d; post-close rejected; active-after-wait=%d", acceptedCount, len(texts)-acceptedCount, active.Load())
}

func TestExecutorShutdownWaitsForWorkerAndCancelsAccepted(t *testing.T) {
	store := newTaskStore([]string{"hold", "Go"})
	started := make(chan struct{})
	release := make(chan struct{})
	finished := make(chan struct{})
	executor := newTaskExecutor(context.Background(), 2, 3, 1, 1, func(_ context.Context, text string, _ int) (stats.Counts, error) {
		close(started)
		<-release
		close(finished)
		return stats.Analyze(text), nil
	}, store)
	if err := executor.Submit(context.Background(), queuedTask{position: 0, text: "hold"}, false); err != nil {
		t.Fatal(err)
	}
	<-started
	if err := executor.Submit(context.Background(), queuedTask{position: 1, text: "Go"}, false); err != nil {
		t.Fatal(err)
	}
	returned := make(chan struct{})
	go func() {
		executor.Shutdown()
		close(returned)
	}()
	<-executor.ctx.Done()
	select {
	case <-returned:
		t.Fatal("shutdown returned while work was still blocked")
	default:
	}
	close(release)
	<-returned
	<-finished
	executor.Shutdown()
	if err := executor.Submit(context.Background(), queuedTask{position: 0, text: "Go"}, false); !errors.Is(err, ErrExecutorClosed) {
		t.Fatalf("post-shutdown submission=%v", err)
	}
	for position := 0; position < 2; position++ {
		record, _ := store.Lookup(fmt.Sprintf("task[%d]", position))
		if record.Status != StatusCanceled || record.Words != 0 {
			t.Fatalf("accepted task[%d] after shutdown=%+v", position, record)
		}
	}
	if store.TerminalCount() != 2 {
		t.Fatalf("terminal=%d", store.TerminalCount())
	}
	t.Log("shutdown requested; worker still blocked; after release both accepted tasks canceled and exited; repeated shutdown safe")
}
