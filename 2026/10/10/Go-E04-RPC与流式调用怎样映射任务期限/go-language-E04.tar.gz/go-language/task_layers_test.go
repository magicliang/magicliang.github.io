package main

import (
	"context"
	"database/sql"
	"fmt"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"strings"
	"sync/atomic"
	"testing"

	"example.com/go-language-task/stats"
)

var isolatedDatabaseNumber atomic.Uint64

func openIsolatedSQLTestDatabase(t *testing.T) *sql.DB {
	t.Helper()
	dsn := os.Getenv("GO_LANGUAGE_SQL_DSN")
	if dsn == "" {
		t.Skip("set GO_LANGUAGE_SQL_DSN to run the PostgreSQL integration subtest")
	}
	admin, err := sql.Open("postgres", dsn)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { admin.Close() })
	databaseName := fmt.Sprintf("go_task_29_%d_%d", os.Getpid(), isolatedDatabaseNumber.Add(1))
	if _, err := admin.ExecContext(context.Background(), "CREATE DATABASE "+databaseName); err != nil {
		t.Fatalf("create isolated database %s: %v", databaseName, err)
	}
	var db *sql.DB
	t.Cleanup(func() {
		if db != nil {
			if err := db.Close(); err != nil {
				t.Errorf("close isolated database: %v", err)
			}
		}
		if _, err := admin.ExecContext(context.Background(), "DROP DATABASE "+databaseName); err != nil {
			t.Errorf("drop isolated database %s: %v", databaseName, err)
		}
		var remaining int
		if err := admin.QueryRowContext(context.Background(), "SELECT count(*) FROM pg_database WHERE datname=$1", databaseName).Scan(&remaining); err != nil || remaining != 0 {
			t.Errorf("database cleanup %s: remaining=%d err=%v", databaseName, remaining, err)
		}
		t.Logf("isolated database %s dropped; pg_database remaining=%d", databaseName, remaining)
	})
	databaseDSN := dsn + " dbname=" + databaseName
	if strings.HasPrefix(dsn, "postgres://") || strings.HasPrefix(dsn, "postgresql://") {
		parsed, err := url.Parse(dsn)
		if err != nil {
			t.Fatal(err)
		}
		parsed.Path = "/" + databaseName
		databaseDSN = parsed.String()
	}
	db, err = sql.Open("postgres", databaseDSN)
	if err != nil {
		t.Fatal(err)
	}
	if err := db.PingContext(context.Background()); err != nil {
		t.Fatal(err)
	}
	t.Logf("isolated database %s created and pinged", databaseName)
	return db
}

func TestTaskInputAcrossUnitHTTPAndPostgreSQL(t *testing.T) {
	for _, testCase := range []struct {
		name string
		text string
		want stats.Counts
	}{
		{name: "ascii", text: "Go one two", want: stats.Counts{Words: 3, Bytes: 10, Runes: 10}},
		{name: "utf8", text: "你好 Go", want: stats.Counts{Words: 2, Bytes: 9, Runes: 5}},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			t.Run("unit", func(t *testing.T) {
				store := newTaskStore(nil)
				if !store.Add("task[0]") || !store.Start("task[0]") || !store.Complete("task[0]", stats.Analyze(testCase.text)) {
					t.Fatal("unit task transition failed")
				}
				record, ok := store.Lookup("task[0]")
				if !ok || record.Status != StatusSucceeded || record.Counts != testCase.want {
					t.Fatalf("unit record=%+v ok=%v want=%+v", record, ok, testCase.want)
				}
				t.Logf("unit %q -> SUCCEEDED %+v; no HTTP or SQL connection was made", testCase.text, record.Counts)
			})
			t.Run("http", func(t *testing.T) {
				service := newTaskHTTPService(context.Background(), 1, 1, 3)
				defer service.Close()
				server := httptest.NewServer(service.Handler())
				defer server.Close()
				status, _, _ := postTask(t, server.Client(), server.URL, fmt.Sprintf(`{"text":%q}`, testCase.text), "application/json")
				if status != http.StatusAccepted {
					t.Fatalf("HTTP POST status=%d", status)
				}
				service.Close()
				status, record := getTask(t, server.Client(), server.URL, "task[0]")
				if status != http.StatusOK || record.Status != StatusSucceeded || (stats.Counts{Words: record.Words, Bytes: record.Bytes, Runes: record.Runes}) != testCase.want {
					t.Fatalf("HTTP GET status=%d record=%+v want=%+v", status, record, testCase.want)
				}
				t.Logf("loopback HTTP POST=202, after worker exit GET=200 SUCCEEDED words=%d bytes=%d runes=%d", record.Words, record.Bytes, record.Runes)
			})
			t.Run("postgresql", func(t *testing.T) {
				db := openIsolatedSQLTestDatabase(t)
				service, _, err := newTaskHTTPServiceWithSQLRecovering(context.Background(), 1, 1, 3, db)
				if err != nil {
					t.Fatal(err)
				}
				defer service.Close()
				server := httptest.NewServer(service.Handler())
				defer server.Close()
				status, _, _ := postTask(t, server.Client(), server.URL, fmt.Sprintf(`{"text":%q}`, testCase.text), "application/json")
				if status != http.StatusAccepted {
					t.Fatalf("SQL-backed HTTP POST status=%d", status)
				}
				service.Close()
				status, record := getTask(t, server.Client(), server.URL, "task[0]")
				persisted, input, err := service.sqlStore.Lookup(context.Background(), "task[0]")
				if err != nil || status != http.StatusOK || record.Status != StatusSucceeded || persisted.Status != StatusSucceeded || persisted.Counts != testCase.want || input != testCase.text {
					t.Fatalf("SQL GET status=%d record=%+v persisted=%+v input=%q err=%v", status, record, persisted, input, err)
				}
				t.Logf("PostgreSQL POST=202, GET=200, persisted status=%s input=%q counts=%+v", persisted.Status, input, persisted.Counts)
			})
		})
	}
}

func TestHTTPBlankInputRejectedBeforeSQL(t *testing.T) {
	db := openIsolatedSQLTestDatabase(t)
	service, err := newTaskHTTPServiceWithSQL(context.Background(), 1, 1, 3, db)
	if err != nil {
		t.Fatal(err)
	}
	defer service.Close()
	server := httptest.NewServer(service.Handler())
	defer server.Close()
	status, _, _ := postTask(t, server.Client(), server.URL, `{"text":"  "}`, "application/json")
	if status != http.StatusBadRequest {
		t.Fatalf("blank input HTTP status=%d", status)
	}
	var count int
	if err := db.QueryRowContext(context.Background(), "SELECT count(*) FROM go_tasks").Scan(&count); err != nil || count != 0 {
		t.Fatalf("blank input SQL row count=%d err=%v", count, err)
	}
	t.Log("blank HTTP input rejected 400; isolated SQL table contains zero tasks")
}
