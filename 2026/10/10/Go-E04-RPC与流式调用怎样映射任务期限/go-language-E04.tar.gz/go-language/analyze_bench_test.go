package main

import (
	"context"
	"strings"
	"testing"

	"example.com/go-language-task/stats"
)

func BenchmarkTaskAnalyzeContext(b *testing.B) {
	text := strings.Repeat("Go one two 你好 ", 128)
	want := stats.Analyze(text)
	ctx := context.Background()
	b.ReportAllocs()
	for b.Loop() {
		got, err := stats.AnalyzeContext(ctx, text)
		if err != nil || got != want {
			b.Fatalf("counts=%+v want=%+v err=%v", got, want, err)
		}
	}
}
