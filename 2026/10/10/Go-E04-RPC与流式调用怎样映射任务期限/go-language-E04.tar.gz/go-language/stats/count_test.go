package stats

import (
	"context"
	"errors"
	"testing"
)

func TestCountWords(t *testing.T) {
	for _, testCase := range []struct {
		name string
		text string
		want int
	}{
		{name: "ASCII", text: "one two", want: 2},
		{name: "Chinese", text: "Go 写 Go", want: 3},
		{name: "Whitespace", text: "\t \n", want: 0},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			if got := CountWords(testCase.text); got != testCase.want {
				t.Errorf("CountWords(%q) = %d; want %d", testCase.text, got, testCase.want)
			}
		})
	}
}

func TestAnalyze(t *testing.T) {
	for _, testCase := range []struct {
		name string
		text string
		want Counts
	}{
		{name: "ASCII", text: "one two", want: Counts{Words: 2, Bytes: 7, Runes: 7}},
		{name: "Chinese", text: "Go 写 Go", want: Counts{Words: 3, Bytes: 9, Runes: 7}},
		{name: "Empty", text: "", want: Counts{}},
		{name: "Combining mark", text: "e\u0301", want: Counts{Words: 1, Bytes: 3, Runes: 2}},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			if got := Analyze(testCase.text); got != testCase.want {
				t.Errorf("Analyze(%q) = %+v; want %+v", testCase.text, got, testCase.want)
			}
		})
	}
}

func TestAnalyzeContextMatchesSequential(t *testing.T) {
	for _, text := range []string{"Go 写 Go", "one\ttwo", "\t\v\f\r\n Go", "e\u0301", "\u2003你好\nGo", "\xff", ""} {
		counts, err := AnalyzeContext(context.Background(), text)
		if err != nil || counts != Analyze(text) {
			t.Fatalf("text=%q counts=%+v want=%+v err=%v", text, counts, Analyze(text), err)
		}
	}
}

func TestAnalyzeContextCancellationBetweenRunes(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	started := make(chan struct{})
	release := make(chan struct{})
	returned := make(chan error, 1)
	go func() {
		first := true
		_, err := analyzeContextWith(ctx, "Go 写 Go", func() {
			if first {
				first = false
				close(started)
				<-release
			}
		})
		returned <- err
	}()
	<-started
	cancel()
	select {
	case err := <-returned:
		t.Fatalf("cancellation claimed completion before release: %v", err)
	default:
		t.Log("cancel requested while first rune checkpoint is held")
	}
	close(release)
	if err := <-returned; !errors.Is(err, context.Canceled) {
		t.Fatalf("returned %v; want context.Canceled", err)
	}
	t.Log("segmented computation confirmed context.Canceled after checkpoint")
}
