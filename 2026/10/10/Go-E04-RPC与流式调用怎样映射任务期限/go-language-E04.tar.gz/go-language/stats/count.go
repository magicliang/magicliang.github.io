package stats

import (
	"context"
	"unicode"
	"unicode/utf8"
)

type Counts struct {
	Words int
	Bytes int
	Runes int
}

func CountWords(text string) int {
	words := 0
	inWord := false
	for _, symbol := range text {
		if unicode.IsSpace(symbol) {
			inWord = false
		} else if !inWord {
			words++
			inWord = true
		}
	}
	return words
}

func Analyze(text string) Counts {
	return Counts{
		Words: CountWords(text),
		Bytes: len(text),
		Runes: utf8.RuneCountInString(text),
	}
}

func AnalyzeContext(ctx context.Context, text string) (Counts, error) {
	return analyzeContextWith(ctx, text, nil)
}

func analyzeContextWith(ctx context.Context, text string, afterRune func()) (Counts, error) {
	counts := Counts{Bytes: len(text)}
	inWord := false
	for len(text) > 0 {
		if err := ctx.Err(); err != nil {
			return Counts{}, err
		}
		r, size := utf8.DecodeRuneInString(text)
		text = text[size:]
		counts.Runes++
		space := false
		if r <= unicode.MaxASCII {
			space = r == ' ' || r >= '\t' && r <= '\r'
		} else {
			space = unicode.IsSpace(r)
		}
		if space {
			inWord = false
		} else if !inWord {
			inWord = true
			counts.Words++
		}
		if afterRune != nil {
			afterRune()
		}
	}
	if err := ctx.Err(); err != nil {
		return Counts{}, err
	}
	return counts, nil
}
