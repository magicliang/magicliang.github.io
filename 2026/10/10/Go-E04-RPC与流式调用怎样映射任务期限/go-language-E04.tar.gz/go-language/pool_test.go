package main

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"sync/atomic"
	"testing"

	"example.com/go-language-task/stats"
)

func TestCLIWorkerAndQueueLimits(t *testing.T) {
	var stdout, stderr bytes.Buffer
	if code := run([]string{"--batch", "Go|one two|Go", "--workers", "2", "--queue-capacity", "1"}, &stdout, &stderr); code != 0 || stderr.Len() != 0 || stdout.String() != "task[0] words=1 bytes=2 runes=2\ntask[1] words=2 bytes=7 runes=7\ntask[2] words=1 bytes=2 runes=2\n" {
		t.Fatalf("code=%d stdout=%q stderr=%q", code, stdout.String(), stderr.String())
	}
	stdout.Reset()
	stderr.Reset()
	if code := run([]string{"--text", "Go", "--workers", "0"}, &stdout, &stderr); code != 2 || stdout.Len() != 0 || stderr.String() != "workers and queue-capacity must be between 1 and 128\n" {
		t.Fatalf("invalid code=%d stdout=%q stderr=%q", code, stdout.String(), stderr.String())
	}
	t.Log("CLI workers=2 queue=1 preserves ordered results; workers=0 rejected before work")
}

func TestBoundedPoolPeakAndQueueReuse(t *testing.T) {
	started := make(chan struct{}, 2)
	release := make(chan struct{})
	var active, peak atomic.Int32
	analyze := func(_ context.Context, text string, _ int) (stats.Counts, error) {
		current := active.Add(1)
		for {
			previous := peak.Load()
			if previous >= current || peak.CompareAndSwap(previous, current) {
				break
			}
		}
		if text == "hold" {
			started <- struct{}{}
			<-release
		}
		defer active.Add(-1)
		return stats.Analyze(text), nil
	}
	returned := make(chan []taskOutcome, 1)
	go func() {
		results, _ := processTasksContextWithLimits(context.Background(), []string{"hold", "hold", "Go", "Go", "Go", "Go"}, 3, analyze, nil, 2, 1, false)
		returned <- results
	}()
	<-started
	<-started
	select {
	case <-returned:
		t.Fatal("returned with both worker slots held")
	default:
	}
	close(release)
	results := <-returned
	if len(results) != 6 || peak.Load() != 2 || active.Load() != 0 {
		t.Fatalf("results=%d peak=%d active=%d", len(results), peak.Load(), active.Load())
	}
	for position, result := range results {
		if result.position != position || result.counts.Words != 1 || result.err != nil {
			t.Fatalf("result[%d]=%+v", position, result)
		}
	}
	t.Logf("workers=2 queue=1 peak=%d completed=%d active-after-wait=%d", peak.Load(), len(results), active.Load())
}

func TestBoundedPoolRejectsFullQueue(t *testing.T) {
	inputs := make(chan queuedTask, 1)
	if err := submitTask(context.Background(), inputs, queuedTask{text: "first"}, true); err != nil {
		t.Fatal(err)
	}
	if err := submitTask(context.Background(), inputs, queuedTask{text: "second"}, true); !errors.Is(err, ErrQueueFull) {
		t.Fatalf("full queue error=%v", err)
	}
	if task := <-inputs; task.text != "first" {
		t.Fatalf("unexpected accepted task=%+v", task)
	}
	if err := submitTask(context.Background(), inputs, queuedTask{text: "third"}, true); err != nil {
		t.Fatalf("released queue slot not reusable: %v", err)
	}
	canceled, cancel := context.WithCancel(context.Background())
	cancel()
	if err := submitTask(canceled, inputs, queuedTask{}, true); !errors.Is(err, context.Canceled) {
		t.Fatalf("canceled submit error=%v", err)
	}
	texts := make([]string, 12)
	for position := range texts {
		texts[position] = "Go"
	}
	release := make(chan struct{})
	_, err := processTasksContextWithLimits(context.Background(), texts, 3, func(ctx context.Context, text string, _ int) (stats.Counts, error) {
		select {
		case <-release:
		case <-ctx.Done():
		}
		return stats.Analyze(text), nil
	}, nil, 2, 1, true)
	if !errors.Is(err, ErrQueueFull) {
		t.Fatalf("overload error=%v", err)
	}
	t.Logf("capacity=1: second rejected; dequeue restored slot; integrated overload=%v", err)
}

func TestBoundedPoolCancelWaitsForSlotsAndRecords(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	started := make(chan struct{}, 2)
	release := make(chan struct{})
	var active atomic.Int32
	store := newTaskStore([]string{"hold", "hold", "Go"})
	returned := make(chan error, 1)
	go func() {
		_, err := processTasksContextWithLimits(ctx, []string{"hold", "hold", "Go"}, 3, func(_ context.Context, text string, _ int) (stats.Counts, error) {
			active.Add(1)
			started <- struct{}{}
			<-release
			active.Add(-1)
			return stats.Analyze(text), nil
		}, store, 2, 1, false)
		returned <- err
	}()
	<-started
	<-started
	cancel()
	select {
	case err := <-returned:
		t.Fatalf("returned before worker exit: %v", err)
	default:
	}
	if active.Load() != 2 {
		t.Fatalf("cancel unexpectedly ended work: active=%d", active.Load())
	}
	close(release)
	if err := <-returned; !errors.Is(err, context.Canceled) || active.Load() != 0 {
		t.Fatalf("exit error=%v active=%d", err, active.Load())
	}
	for position := 0; position < 3; position++ {
		record, _ := store.Lookup(fmt.Sprintf("task[%d]", position))
		if record.Status != StatusCanceled {
			t.Fatalf("record[%d] after exit=%+v", position, record)
		}
	}
	t.Logf("cancel requested; workers released; active=%d terminal=%d", active.Load(), store.TerminalCount())
}
