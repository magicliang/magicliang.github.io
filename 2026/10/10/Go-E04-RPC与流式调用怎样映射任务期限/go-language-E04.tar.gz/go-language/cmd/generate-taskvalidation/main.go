package main

import (
	"bytes"
	"errors"
	"flag"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"os"
	"reflect"
	"strconv"
)

func main() {
	input := flag.String("input", "taskvalidation/schema.go", "task fields schema")
	output := flag.String("output", "taskvalidation/generated.go", "generated validator")
	flag.Parse()
	if flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "unexpected arguments")
		os.Exit(2)
	}
	contents, err := generate(*input)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := os.WriteFile(*output, contents, 0644); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func generate(input string) ([]byte, error) {
	parsed, err := parser.ParseFile(token.NewFileSet(), input, nil, 0)
	if err != nil {
		return nil, err
	}
	var fields *ast.StructType
	for _, declaration := range parsed.Decls {
		group, ok := declaration.(*ast.GenDecl)
		if !ok {
			continue
		}
		for _, specification := range group.Specs {
			typeSpec, ok := specification.(*ast.TypeSpec)
			if ok && typeSpec.Name.Name == "Fields" {
				fields, ok = typeSpec.Type.(*ast.StructType)
				if !ok {
					return nil, errors.New("Fields must be struct")
				}
			}
		}
	}
	if fields == nil || len(fields.Fields.List) == 0 {
		return nil, errors.New("Fields struct is missing or empty")
	}
	var body bytes.Buffer
	for _, field := range fields.Fields.List {
		if len(field.Names) != 1 || field.Tag == nil {
			return nil, errors.New("each field needs a name and a check tag")
		}
		typeName, ok := field.Type.(*ast.Ident)
		if !ok {
			return nil, fmt.Errorf("unsupported type for %s", field.Names[0].Name)
		}
		tag, err := strconv.Unquote(field.Tag.Value)
		if err != nil {
			return nil, err
		}
		name := field.Names[0].Name
		switch reflect.StructTag(tag).Get("check") {
		case "nonblank":
			if typeName.Name != "string" {
				return nil, fmt.Errorf("%s must be string for nonblank", name)
			}
			fmt.Fprintf(&body, "if strings.TrimSpace(input.%s) == \"\" { return errors.New(\"text must not be empty\") }\n", name)
		case "positive":
			if typeName.Name != "int" {
				return nil, fmt.Errorf("%s must be int for positive", name)
			}
			fmt.Fprintf(&body, "if input.%s <= 0 { return errors.New(\"max words must be positive\") }\n", name)
		default:
			return nil, fmt.Errorf("unsupported check tag %q on %s", reflect.StructTag(tag).Get("check"), name)
		}
	}
	source := fmt.Sprintf("package taskvalidation\nimport (\"errors\"; \"strings\")\nfunc Validate(input Fields) error {\n%sreturn nil\n}\n", body.String())
	return format.Source([]byte(source))
}
