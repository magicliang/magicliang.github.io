package main

import (
	"context"
	"errors"
	"fmt"
	"os"
	"sync"
	"time"

	"example.com/go-language-task/stats"
)

var ErrExecutorClosed = errors.New("task executor closed")

type taskExecutor struct {
	mu              sync.Mutex
	ctx             context.Context
	cancel          context.CancelFunc
	inputs          chan queuedTask
	stopAccepting   chan struct{}
	submissionsDone chan struct{}
	closing         bool
	submitters      int
	outputs         chan taskOutcome
	done            chan struct{}
	results         []taskOutcome
	workers         sync.WaitGroup
	maxWords        int
	analyze         func(context.Context, string, int) (stats.Counts, error)
	store           *TaskStore
	sqlStore        *sqlTaskRepository
	finished        func(string)
}

func newTaskExecutor(ctx context.Context, taskCount, maxWords, workerCount, queueCapacity int, analyze func(context.Context, string, int) (stats.Counts, error), store *TaskStore) *taskExecutor {
	return newTaskExecutorWithDone(ctx, taskCount, maxWords, workerCount, queueCapacity, analyze, store, nil)
}

func newTaskExecutorWithDone(ctx context.Context, taskCount, maxWords, workerCount, queueCapacity int, analyze func(context.Context, string, int) (stats.Counts, error), store *TaskStore, finished func(string)) *taskExecutor {
	workCtx, cancel := context.WithCancel(ctx)
	executor := &taskExecutor{
		ctx: workCtx, cancel: cancel, inputs: make(chan queuedTask, queueCapacity),
		stopAccepting: make(chan struct{}), submissionsDone: make(chan struct{}),
		outputs: make(chan taskOutcome), done: make(chan struct{}), results: make([]taskOutcome, taskCount),
		maxWords: maxWords, analyze: analyze, store: store, finished: finished,
	}
	executor.workers.Add(workerCount)
	for range workerCount {
		go executor.work()
	}
	go func() {
		executor.workers.Wait()
		close(executor.outputs)
	}()
	go func() {
		defer close(executor.done)
		for result := range executor.outputs {
			if result.position >= len(executor.results) {
				executor.results = append(executor.results, make([]taskOutcome, result.position-len(executor.results)+1)...)
			}
			executor.results[result.position] = result
		}
	}()
	return executor
}

func (executor *taskExecutor) Submit(ctx context.Context, task queuedTask, rejectFull bool) error {
	executor.mu.Lock()
	if executor.closing {
		executor.mu.Unlock()
		return ErrExecutorClosed
	}
	executor.submitters++
	executor.mu.Unlock()
	defer func() {
		executor.mu.Lock()
		executor.submitters--
		if executor.closing && executor.submitters == 0 {
			close(executor.inputs)
			close(executor.submissionsDone)
		}
		executor.mu.Unlock()
	}()
	if err := ctx.Err(); err != nil {
		return err
	}
	if err := executor.ctx.Err(); err != nil {
		return err
	}
	if rejectFull {
		select {
		case <-executor.stopAccepting:
			return ErrExecutorClosed
		case <-ctx.Done():
			return ctx.Err()
		case <-executor.ctx.Done():
			return executor.ctx.Err()
		case executor.inputs <- task:
			return nil
		default:
			return ErrQueueFull
		}
	}
	select {
	case <-executor.stopAccepting:
		return ErrExecutorClosed
	case <-ctx.Done():
		return ctx.Err()
	case <-executor.ctx.Done():
		return executor.ctx.Err()
	case executor.inputs <- task:
		return nil
	}
}

func (executor *taskExecutor) Close() {
	executor.mu.Lock()
	if !executor.closing {
		executor.closing = true
		close(executor.stopAccepting)
		if executor.submitters == 0 {
			close(executor.inputs)
			close(executor.submissionsDone)
		}
	}
	executor.mu.Unlock()
	<-executor.submissionsDone
}

func (executor *taskExecutor) Wait() []taskOutcome {
	<-executor.done
	if executor.ctx.Err() != nil && executor.store != nil {
		executor.store.CancelOpen()
	}
	if executor.ctx.Err() != nil && executor.sqlStore != nil {
		cleanupContext, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		if err := executor.sqlStore.CancelOpen(cleanupContext); err != nil {
			fmt.Fprintf(os.Stderr, "SQL shutdown cleanup failed: %v\n", err)
		}
		cancel()
	}
	return append([]taskOutcome(nil), executor.results...)
}

func (executor *taskExecutor) Shutdown() []taskOutcome {
	executor.cancel()
	executor.Close()
	return executor.Wait()
}

func (executor *taskExecutor) work() {
	defer executor.workers.Done()
	for {
		task, ok := receiveTask(executor.ctx, executor.inputs)
		if !ok || executor.ctx.Err() != nil {
			if task.cancel != nil {
				task.cancel()
			}
			if executor.finished != nil && ok {
				executor.finished(fmt.Sprintf("task[%d]", task.position))
			}
			return
		}
		executor.process(task)
	}
}

func (executor *taskExecutor) process(task queuedTask) {
	id := fmt.Sprintf("task[%d]", task.position)
	if executor.finished != nil {
		defer executor.finished(id)
	}
	if task.cancel != nil {
		defer task.cancel()
	}
	taskContext := executor.ctx
	if task.ctx != nil {
		taskContext = task.ctx
	}
	if taskContext.Err() != nil {
		return
	}
	if executor.sqlStore != nil {
		executor.processSQL(taskContext, id, task)
		return
	}
	if executor.store != nil && !executor.store.Start(id) {
		select {
		case <-executor.ctx.Done():
			return
		case executor.outputs <- taskOutcome{position: task.position, err: context.Canceled}:
		}
		return
	}
	counts, err := executor.analyze(taskContext, task.text, executor.maxWords)
	if executor.store != nil {
		if taskContext.Err() != nil {
			executor.store.Cancel(id)
		}
		if err == nil {
			if !executor.store.Complete(id, counts) {
				err = context.Canceled
			}
		} else if !executor.store.Fail(id) {
			err = context.Canceled
		}
	}
	select {
	case <-executor.ctx.Done():
		return
	case <-taskContext.Done():
		return
	case executor.outputs <- taskOutcome{position: task.position, counts: counts, err: err}:
	}
}

func (executor *taskExecutor) processSQL(ctx context.Context, id string, task queuedTask) {
	claimed, err := executor.sqlStore.Claim(ctx, id)
	var counts stats.Counts
	if err == nil && claimed {
		counts, err = executor.analyze(ctx, task.text, executor.maxWords)
		writeContext, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		if ctx.Err() != nil {
			if _, cancelError := executor.sqlStore.Cancel(writeContext, id); cancelError != nil {
				err = cancelError
			}
		}
		resultStatus, finishError := executor.sqlStore.Finish(writeContext, id, counts, err == nil)
		cancel()
		if finishError != nil {
			err = finishError
		} else if resultStatus == StatusCanceled {
			err = context.Canceled
		}
	}
	if err != nil && !claimed {
		err = executor.failUnstartedSQLTask(ctx, id)
	}
	if err == nil && !claimed {
		err = context.Canceled
	}
	select {
	case <-executor.ctx.Done():
	case <-ctx.Done():
	case executor.outputs <- taskOutcome{position: task.position, counts: counts, err: err}:
	}
}
func (executor *taskExecutor) failUnstartedSQLTask(ctx context.Context, id string) error {
	backoff := 25 * time.Millisecond
	for {
		if err := executor.ctx.Err(); err != nil {
			return err
		}
		if err := ctx.Err(); err != nil {
			return err
		}
		writeContext, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		status, err := executor.sqlStore.FailUnstarted(writeContext, id, sqlClaimFailureReason)
		cancel()
		if err == nil {
			if status == StatusCanceled {
				return context.Canceled
			}
			return errors.New(sqlClaimFailureReason)
		}
		if errors.Is(err, ErrSQLTaskNotRunning) || errors.Is(err, ErrSQLTaskNotFound) {
			return err
		}
		select {
		case <-executor.ctx.Done():
			return executor.ctx.Err()
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(backoff):
		}
		if backoff < 250*time.Millisecond {
			backoff *= 2
			if backoff > 250*time.Millisecond {
				backoff = 250 * time.Millisecond
			}
		}
	}
}
