package main

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"sync/atomic"
	"testing"

	"example.com/go-language-task/stats"
)

func cancelHTTPTask(t *testing.T, client *http.Client, base, id string) (int, jsonTask) {
	t.Helper()
	request, err := http.NewRequest(http.MethodPost, base+"/tasks/"+id+"/cancel", nil)
	if err != nil {
		t.Fatal(err)
	}
	response, err := client.Do(request)
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusAccepted {
		io.Copy(io.Discard, response.Body)
		return response.StatusCode, jsonTask{}
	}
	var record jsonTask
	if err := json.NewDecoder(response.Body).Decode(&record); err != nil {
		t.Fatal(err)
	}
	return response.StatusCode, record
}

func TestHTTPExplicitCancelWaitsForAnalysisExit(t *testing.T) {
	started := make(chan struct{})
	release := make(chan struct{})
	var once sync.Once
	service := newTaskHTTPServiceUsing(context.Background(), 1, 1, 3, func(_ context.Context, text string, _ int) (stats.Counts, error) {
		close(started)
		<-release
		return stats.Analyze(text), nil
	})
	server := httptest.NewServer(service.Handler())
	t.Cleanup(func() {
		once.Do(func() { close(release) })
		service.Close()
		server.Close()
	})
	status, _, _ := postTask(t, server.Client(), server.URL, `{"text":"hold"}`, "application/json")
	if status != http.StatusAccepted {
		t.Fatalf("submit status=%d", status)
	}
	<-started
	status, cancelRecord := cancelHTTPTask(t, server.Client(), server.URL, "task[0]")
	if status != http.StatusAccepted || cancelRecord.Status != StatusRunning || !cancelRecord.CancelRequested {
		t.Fatalf("cancel response=%d record=%+v", status, cancelRecord)
	}
	status, snapshot := getTask(t, server.Client(), server.URL, "task[0]")
	if status != http.StatusOK || snapshot.Status != StatusRunning || !snapshot.CancelRequested || service.store.TerminalCount() != 0 {
		t.Fatalf("still blocked status=%d snapshot=%+v terminals=%d", status, snapshot, service.store.TerminalCount())
	}
	if status, _ := cancelHTTPTask(t, server.Client(), server.URL, "task[0]"); status != http.StatusConflict {
		t.Fatalf("repeated cancel status=%d", status)
	}
	once.Do(func() { close(release) })
	service.Close()
	status, snapshot = getTask(t, server.Client(), server.URL, "task[0]")
	if status != http.StatusOK || snapshot.Status != StatusCanceled || snapshot.Words != 0 || service.store.TerminalCount() != 1 {
		t.Fatalf("after analysis exit status=%d snapshot=%+v terminals=%d", status, snapshot, service.store.TerminalCount())
	}
	if status, _ := cancelHTTPTask(t, server.Client(), server.URL, "task[missing]"); status != http.StatusNotFound {
		t.Fatalf("unknown cancel status=%d", status)
	}
	t.Log("cancel POST=202 then GET RUNNING cancel_requested=true terminals=0; after analysis exit GET CANCELED terminals=1; duplicate=409 missing=404")
}

func TestHTTPQueuedCancelDoesNotStartAnalysis(t *testing.T) {
	started := make(chan struct{})
	release := make(chan struct{})
	var once sync.Once
	var analyzed atomic.Int32
	service := newTaskHTTPServiceUsing(context.Background(), 1, 1, 3, func(_ context.Context, text string, _ int) (stats.Counts, error) {
		analyzed.Add(1)
		if text == "hold" {
			close(started)
			<-release
		}
		return stats.Analyze(text), nil
	})
	server := httptest.NewServer(service.Handler())
	t.Cleanup(func() {
		once.Do(func() { close(release) })
		service.Close()
		server.Close()
	})
	status, _, _ := postTask(t, server.Client(), server.URL, `{"text":"hold"}`, "application/json")
	if status != http.StatusAccepted {
		t.Fatalf("first status=%d", status)
	}
	<-started
	status, _, _ = postTask(t, server.Client(), server.URL, `{"text":"later"}`, "application/json")
	if status != http.StatusAccepted {
		t.Fatalf("queued status=%d", status)
	}
	status, record := cancelHTTPTask(t, server.Client(), server.URL, "task[1]")
	if status != http.StatusAccepted || record.Status != StatusCanceled || analyzed.Load() != 1 || service.store.TerminalCount() != 1 {
		t.Fatalf("queued cancel status=%d record=%+v analyzed=%d terminals=%d", status, record, analyzed.Load(), service.store.TerminalCount())
	}
	once.Do(func() { close(release) })
	service.Close()
	if analyzed.Load() != 1 || service.store.TerminalCount() != 2 {
		t.Fatalf("after close analyzed=%d terminals=%d", analyzed.Load(), service.store.TerminalCount())
	}
	t.Log("queued POST cancel=202 CANCELED without running analyzer; after close only first task analyzed, terminals=2")
}

func TestHTTPClientCancelAndServerShutdownDoNotWaitForBusiness(t *testing.T) {
	started := make(chan struct{})
	release := make(chan struct{})
	var once sync.Once
	service := newTaskHTTPServiceUsing(context.Background(), 1, 1, 3, func(_ context.Context, text string, _ int) (stats.Counts, error) {
		close(started)
		<-release
		return stats.Analyze(text), nil
	})
	server := httptest.NewServer(service.Handler())
	t.Cleanup(func() {
		once.Do(func() { close(release) })
		service.Close()
		server.Close()
	})
	clientContext, cancelClient := context.WithCancel(context.Background())
	defer cancelClient()
	request, err := http.NewRequestWithContext(clientContext, http.MethodPost, server.URL+"/tasks", strings.NewReader(`{"text":"hold"}`))
	if err != nil {
		t.Fatal(err)
	}
	request.Header.Set("Content-Type", "application/json")
	response, err := server.Client().Do(request)
	if err != nil {
		t.Fatal(err)
	}
	io.Copy(io.Discard, response.Body)
	response.Body.Close()
	if response.StatusCode != http.StatusAccepted {
		t.Fatalf("submit status=%d", response.StatusCode)
	}
	<-started
	cancelClient()
	if status, snapshot := getTask(t, server.Client(), server.URL, "task[0]"); status != http.StatusOK || snapshot.Status != StatusRunning || snapshot.CancelRequested {
		t.Fatalf("client cancel incorrectly stopped task: status=%d snapshot=%+v", status, snapshot)
	}
	if err := server.Config.Shutdown(context.Background()); err != nil {
		t.Fatal(err)
	}
	if snapshot, _ := service.store.Lookup("task[0]"); snapshot.Status != StatusRunning {
		t.Fatalf("HTTP shutdown stopped business: %+v", snapshot)
	}
	returned := make(chan struct{})
	go func() {
		service.Close()
		close(returned)
	}()
	select {
	case <-returned:
		t.Fatal("business Close returned while analyzer still blocked")
	default:
	}
	once.Do(func() { close(release) })
	<-returned
	if snapshot, _ := service.store.Lookup("task[0]"); snapshot.Status != StatusSucceeded {
		t.Fatalf("business result after worker exit=%+v", snapshot)
	}
	t.Log("client request canceled after 202; Server.Shutdown returned while task RUNNING; business Close waited for worker SUCCEEDED")
}
