package taskvalidation

import (
	"strings"
	"testing"
)

func TestGeneratedAndReflectValidateTaskFields(t *testing.T) {
	for _, sample := range []struct {
		name string
		input Fields
		want string
	}{
		{"valid", Fields{Text: "Go task", MaxWords: 3}, ""},
		{"blank", Fields{Text: " \t", MaxWords: 3}, "text must not be empty"},
		{"limit", Fields{Text: "Go", MaxWords: 0}, "max words must be positive"},
	} {
		t.Run(sample.name, func(t *testing.T) {
			generated := Validate(sample.input)
			reflected := ValidateReflect(sample.input)
			if sample.want == "" {
				if generated != nil || reflected != nil {
					t.Fatalf("generated=%v reflected=%v", generated, reflected)
				}
			} else if generated == nil || reflected == nil || generated.Error() != sample.want || reflected.Error() != sample.want {
				t.Fatalf("generated=%v reflected=%v want=%q", generated, reflected, sample.want)
			}
			t.Logf("generated=%v reflected=%v", generated, reflected)
		})
	}
	badRuntimeSchema := struct {
		Text string `check:"not-a-rule"`
	}{Text: "Go"}
	err := ValidateReflect(badRuntimeSchema)
	if err == nil || !strings.Contains(err.Error(), "unsupported check tag") {
		t.Fatalf("unknown runtime tag error=%v", err)
	}
	t.Logf("unknown schema tag discovered at reflection call: %v", err)
}

var benchmarkFields = Fields{Text: "Go task", MaxWords: 3}
var benchmarkValidationError error

func BenchmarkTaskFieldValidation(b *testing.B) {
	for _, sample := range []struct {
		name string
		check func() error
	}{
		{"generated", func() error { return Validate(benchmarkFields) }},
		{"reflection", func() error { return ValidateReflect(benchmarkFields) }},
	} {
		b.Run(sample.name, func(b *testing.B) {
			b.ReportAllocs()
			for b.Loop() {
				benchmarkValidationError = sample.check()
				if benchmarkValidationError != nil {
					b.Fatal(benchmarkValidationError)
				}
			}
		})
	}
}
