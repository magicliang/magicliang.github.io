package taskvalidation

import (
	"errors"
	"strings"
)

func Validate(input Fields) error {
	if strings.TrimSpace(input.Text) == "" {
		return errors.New("text must not be empty")
	}
	if input.MaxWords <= 0 {
		return errors.New("max words must be positive")
	}
	return nil
}
