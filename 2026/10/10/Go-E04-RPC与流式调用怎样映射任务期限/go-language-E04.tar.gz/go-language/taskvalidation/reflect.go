package taskvalidation

import (
	"errors"
	"fmt"
	"reflect"
	"strings"
)

func ValidateReflect(input any) error {
	value := reflect.ValueOf(input)
	if value.Kind() != reflect.Struct {
		return errors.New("expected task fields struct")
	}
	fields := value.Type()
	for position := 0; position < fields.NumField(); position++ {
		field := fields.Field(position)
		current := value.Field(position)
		switch field.Tag.Get("check") {
		case "nonblank":
			if current.Kind() != reflect.String {
				return fmt.Errorf("%s must be string", field.Name)
			}
			if strings.TrimSpace(current.String()) == "" {
				return errors.New("text must not be empty")
			}
		case "positive":
			if current.Kind() != reflect.Int {
				return fmt.Errorf("%s must be int", field.Name)
			}
			if current.Int() <= 0 {
				return errors.New("max words must be positive")
			}
		default:
			return fmt.Errorf("unsupported check tag %q on %s", field.Tag.Get("check"), field.Name)
		}
	}
	return nil
}
