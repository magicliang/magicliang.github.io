package taskvalidation

type Fields struct {
	Text     string `check:"nonblank"`
	MaxWords int    `check:"positive"`
}
