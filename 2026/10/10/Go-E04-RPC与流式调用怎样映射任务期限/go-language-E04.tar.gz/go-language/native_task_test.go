package main

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"example.com/go-language-task/native"
	"example.com/go-language-task/stats"
)

func TestNativeTaskUsesExistingHTTPAndTerminalRules(t *testing.T) {
	service := newTaskHTTPServiceUsing(context.Background(), 1, 2, 3, func(ctx context.Context, text string, maxWords int) (stats.Counts, error) {
		if _, err := native.SumASCII([]byte(text)); err != nil {
			return stats.Counts{}, err
		}
		return analyzeTaskContext(ctx, text, maxWords)
	})
	defer service.Close()
	server := httptest.NewServer(service.Handler())
	defer server.Close()
	for _, sample := range []struct {
		text string
		want TaskStatus
		words int
	}{
		{"Go one", StatusSucceeded, 2},
		{"中文", StatusFailed, 0},
	} {
		body, err := json.Marshal(struct{ Text string `json:"text"` }{Text: sample.text})
		if err != nil {
			t.Fatal(err)
		}
		status, _, payload := postTask(t, server.Client(), server.URL, string(body), "application/json")
		if status != http.StatusAccepted {
			t.Fatalf("input=%q submit=%d payload=%s", sample.text, status, payload)
		}
		var accepted struct{ ID string `json:"id"` }
		if err := json.Unmarshal([]byte(payload), &accepted); err != nil {
			t.Fatal(err)
		}
		found := false
		for attempt := 0; attempt < 100; attempt++ {
			status, record := getTask(t, server.Client(), server.URL, accepted.ID)
			if status == http.StatusOK && record.Status == sample.want {
				if record.Words != sample.words {
					t.Fatalf("id=%s record=%+v", accepted.ID, record)
				}
				t.Logf("id=%s input=%q status=%s words=%d", accepted.ID, sample.text, record.Status, record.Words)
				found = true
				break
			}
			time.Sleep(time.Millisecond)
		}
		if !found {
			t.Fatalf("input=%q never reached %s", sample.text, sample.want)
		}
	}
}
