package main

import (
	"fmt"
	"sync"
	"sync/atomic"

	"example.com/go-language-task/stats"
)

type TaskStore struct {
	mu            sync.Mutex
	records       map[string]TaskRecord
	terminalCount atomic.Uint64
}

func newTaskStore(tasks []string) *TaskStore {
	store := &TaskStore{records: make(map[string]TaskRecord, len(tasks))}
	for position := range tasks {
		id := fmt.Sprintf("task[%d]", position)
		store.records[id] = newTaskRecord(id)
	}
	return store
}

func (store *TaskStore) Add(id string) bool {
	store.mu.Lock()
	defer store.mu.Unlock()
	if _, exists := store.records[id]; exists {
		return false
	}
	store.records[id] = newTaskRecord(id)
	return true
}

func (store *TaskStore) RemoveQueued(id string) bool {
	store.mu.Lock()
	defer store.mu.Unlock()
	if record, exists := store.records[id]; !exists || record.Status != StatusQueued {
		return false
	}
	delete(store.records, id)
	return true
}

func (store *TaskStore) Lookup(id string) (TaskRecord, bool) {
	store.mu.Lock()
	defer store.mu.Unlock()
	record, ok := store.records[id]
	return record, ok
}

func (store *TaskStore) Start(id string) bool {
	store.mu.Lock()
	defer store.mu.Unlock()
	record, ok := store.records[id]
	if !ok || record.Status != StatusQueued {
		return false
	}
	record.Status = StatusRunning
	store.records[id] = record
	return true
}

func (store *TaskStore) Complete(id string, counts stats.Counts) bool {
	store.mu.Lock()
	defer store.mu.Unlock()
	record, ok := store.records[id]
	if !ok || record.Status != StatusRunning {
		return false
	}
	if record.CancelRequested {
		record.Status = StatusCanceled
		store.records[id] = record
		store.terminalCount.Add(1)
		return false
	}
	record.MarkSucceeded(counts)
	store.records[id] = record
	store.terminalCount.Add(1)
	return true
}

func (store *TaskStore) Fail(id string) bool {
	store.mu.Lock()
	defer store.mu.Unlock()
	record, ok := store.records[id]
	if !ok || record.Status != StatusRunning {
		return false
	}
	if record.CancelRequested {
		record.Status = StatusCanceled
	} else {
		record.Status = StatusFailed
	}
	store.records[id] = record
	store.terminalCount.Add(1)
	return !record.CancelRequested
}

func (store *TaskStore) Cancel(id string) bool {
	store.mu.Lock()
	defer store.mu.Unlock()
	record, ok := store.records[id]
	if !ok || record.Status != StatusQueued && record.Status != StatusRunning || record.CancelRequested {
		return false
	}
	if record.Status == StatusRunning {
		record.CancelRequested = true
	} else {
		record.Status = StatusCanceled
		store.terminalCount.Add(1)
	}
	store.records[id] = record
	return true
}

func (store *TaskStore) CancelOpen() {
	store.mu.Lock()
	defer store.mu.Unlock()
	for id, record := range store.records {
		if record.Status == StatusQueued || record.Status == StatusRunning {
			record.Status = StatusCanceled
			store.records[id] = record
			store.terminalCount.Add(1)
		}
	}
}

func (store *TaskStore) TerminalCount() uint64 {
	return store.terminalCount.Load()
}
