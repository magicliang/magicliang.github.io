package main

import (
	"bufio"
	"bytes"
	"context"
	"database/sql"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"strings"
	"testing"
	"time"

	"example.com/go-language-task/stats"
)

func TestSQLCrashChild(t *testing.T) {
	if os.Getenv("GO_LANGUAGE_CRASH_CHILD") != "1" {
		return
	}
	db, err := sql.Open("postgres", os.Getenv("GO_LANGUAGE_SQL_DSN"))
	if err != nil {
		t.Fatal(err)
	}
	service, err := newTaskHTTPServiceWithSQLUsing(context.Background(), 1, 1, 3, db, func(context.Context, string, int) (stats.Counts, error) {
		select {}
	})
	if err != nil {
		t.Fatal(err)
	}
	server := httptest.NewServer(service.Handler())
	fmt.Fprintln(os.Stdout, server.URL)
	select {}
}

func TestSQLRecoveryUpgradesPriorSchema(t *testing.T) {
	db := openSQLTestDatabase(t)
	if _, err := db.ExecContext(context.Background(), "DROP TABLE IF EXISTS go_tasks"); err != nil {
		t.Fatal(err)
	}
	if _, err := db.ExecContext(context.Background(), `CREATE TABLE go_tasks (
		id TEXT PRIMARY KEY, input_text TEXT NOT NULL, status TEXT NOT NULL,
		cancel_requested BOOLEAN NOT NULL DEFAULT FALSE,
		words INTEGER NOT NULL DEFAULT 0, bytes INTEGER NOT NULL DEFAULT 0, runes INTEGER NOT NULL DEFAULT 0
	)`); err != nil {
		t.Fatal(err)
	}
	if _, err := db.ExecContext(context.Background(), "INSERT INTO go_tasks(id,input_text,status) VALUES('task[0]','Go','RUNNING')"); err != nil {
		t.Fatal(err)
	}
	service, recovered, err := newTaskHTTPServiceWithSQLRecovering(context.Background(), 1, 1, 3, db)
	if err != nil {
		t.Fatal(err)
	}
	defer service.Close()
	if recovered.failed != 1 || recovered.nextID != 1 {
		t.Fatalf("migration recovery=%+v", recovered)
	}
	record, _, err := service.sqlStore.Lookup(context.Background(), "task[0]")
	if err != nil || record.Status != StatusFailed || record.FailureReason != "process exited before worker completion" {
		t.Fatalf("migration record=%+v err=%v", record, err)
	}
	t.Log("prior table without failure_reason upgraded; abandoned RUNNING gained failure_reason")
}

func TestSQLProcessCrashAndRecovery(t *testing.T) {
	db := openSQLTestDatabase(t)
	repository, err := newSQLTaskRepository(context.Background(), db)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := db.ExecContext(context.Background(), "TRUNCATE go_tasks"); err != nil {
		t.Fatal(err)
	}
	command := exec.Command(os.Args[0], "-test.run=^TestSQLCrashChild$")
	command.Env = append(os.Environ(), "GO_LANGUAGE_CRASH_CHILD=1")
	output, err := command.StdoutPipe()
	if err != nil {
		t.Fatal(err)
	}
	var childErrors bytes.Buffer
	command.Stderr = &childErrors
	if err := command.Start(); err != nil {
		t.Fatal(err)
	}
	defer func() {
		if command.ProcessState == nil {
			command.Process.Kill()
			command.Wait()
		}
	}()
	address := make(chan string, 1)
	go func() {
		line, _ := bufio.NewReader(output).ReadString('\n')
		address <- strings.TrimSpace(line)
	}()
	var serverURL string
	select {
	case serverURL = <-address:
	case <-time.After(5 * time.Second):
		t.Fatal("child HTTP server did not start")
	}
	if !strings.HasPrefix(serverURL, "http://127.0.0.1:") {
		t.Fatalf("unexpected child address %q", serverURL)
	}
	client := &http.Client{Timeout: 2 * time.Second}
	for position := range 2 {
		status, _, _ := postTask(t, client, serverURL, `{"text":"one two"}`, "application/json")
		if status != http.StatusAccepted {
			t.Fatalf("task[%d] POST status=%d", position, status)
		}
	}
	deadline := time.Now().Add(3 * time.Second)
	for {
		first, _, firstError := repository.Lookup(context.Background(), "task[0]")
		second, _, secondError := repository.Lookup(context.Background(), "task[1]")
		if firstError == nil && secondError == nil && first.Status == StatusRunning && second.Status == StatusQueued {
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("before crash: first=%+v err=%v second=%+v err=%v", first, firstError, second, secondError)
		}
		time.Sleep(10 * time.Millisecond)
	}
	if err := command.Process.Kill(); err != nil {
		t.Fatal(err)
	}
	waitError := command.Wait()
	if waitError == nil {
		t.Fatal("child exited normally instead of crashing")
	}
	t.Logf("child pid=%d signal termination=%v stderr=%q", command.Process.Pid, waitError, childErrors.String())
	first, _, err := repository.Lookup(context.Background(), "task[0]")
	if err != nil || first.Status != StatusRunning {
		t.Fatalf("after crash before recovery: record=%+v err=%v", first, err)
	}
	service, recovered, err := newTaskHTTPServiceWithSQLRecovering(context.Background(), 1, 1, 3, db)
	if err != nil {
		t.Fatal(err)
	}
	defer service.Close()
	if recovered.failed != 1 || len(recovered.queued) != 1 || recovered.nextID != 2 {
		t.Fatalf("recovery=%+v", recovered)
	}
	<-service.recoveryDone
	server := httptest.NewServer(service.Handler())
	defer server.Close()
	if status, record := getTask(t, server.Client(), server.URL, "task[0]"); status != http.StatusOK || record.Status != StatusFailed || record.FailureReason != "process exited before worker completion" || record.Words != 0 {
		t.Fatalf("abandoned task status=%d record=%+v", status, record)
	}
	service.Close()
	if status, record := getTask(t, server.Client(), server.URL, "task[1]"); status != http.StatusOK || record.Status != StatusSucceeded || record.Words != 2 {
		t.Fatalf("reclaimed queued task status=%d record=%+v", status, record)
	}
	t.Logf("crash: RUNNING kept until restart; recovery FAILED reason=%q, previously QUEUED -> SUCCEEDED words=2", "process exited before worker completion")
	newService, again, err := newTaskHTTPServiceWithSQLRecovering(context.Background(), 1, 1, 3, db)
	if err != nil {
		t.Fatal(err)
	}
	defer newService.Close()
	if again.failed != 0 || len(again.queued) != 0 || again.nextID != 2 {
		t.Fatalf("second recovery=%+v", again)
	}
	newServer := httptest.NewServer(newService.Handler())
	defer newServer.Close()
	if status, _, body := postTask(t, newServer.Client(), newServer.URL, `{"text":"Go"}`, "application/json"); status != http.StatusAccepted || !strings.Contains(body, "task[2]") {
		t.Fatalf("new task after restart status=%d body=%q", status, body)
	}
	newService.Close()
	if status, record := getTask(t, newServer.Client(), newServer.URL, "task[2]"); status != http.StatusOK || record.Status != StatusSucceeded {
		t.Fatalf("new task status=%d record=%+v", status, record)
	}
	t.Log("second restart changed no terminal row; next submission received task[2] and completed")
}
