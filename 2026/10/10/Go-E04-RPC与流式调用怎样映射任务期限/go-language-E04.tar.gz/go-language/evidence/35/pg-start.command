/usr/lib/postgresql/16/bin/pg_ctl -D '/tmp/go-language-35-pg.u6ZPW0' -o '-h 127.0.0.1 -p 54837 -k /tmp/go-language-35-pg.u6ZPW0' -l '/tmp/go-language-35-pg.u6ZPW0/server.log' start
