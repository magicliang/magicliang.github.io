/usr/lib/postgresql/16/bin/pg_ctl -D '/tmp/go-language-35-pg.u6ZPW0' -m fast stop
