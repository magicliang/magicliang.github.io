go test -count=1 -run "^TestAnalyzeContextMatchesSequential$|^TestAnalyzeContextCancellationBetweenRunes$" ./stats
