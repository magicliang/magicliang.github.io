git -C '/home/admin/workspace/my-blogs' archive cc57a93b examples/go-language | tar -xf - -C '/tmp/go-language-35-old.f50cA1'
