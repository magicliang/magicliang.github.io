psql -h 127.0.0.1 -p 54837 -U admin -d postgres -Atc 'select version()'
