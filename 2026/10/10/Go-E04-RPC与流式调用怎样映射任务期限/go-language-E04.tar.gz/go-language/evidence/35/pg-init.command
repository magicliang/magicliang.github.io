/usr/lib/postgresql/16/bin/initdb -D '/tmp/go-language-35-pg.u6ZPW0' -A trust -U admin --no-instructions
