git -C '/home/admin/workspace/my-blogs' show cc57a93b:examples/go-language/stats/count.go
