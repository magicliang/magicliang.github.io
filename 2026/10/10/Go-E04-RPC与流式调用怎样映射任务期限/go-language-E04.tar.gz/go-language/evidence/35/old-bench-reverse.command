cd '/tmp/go-language-35-old.f50cA1/examples/go-language' && go test -run '^$' -bench '^BenchmarkTask(AnalyzeContext|HTTPRead)$' -benchmem -benchtime=200ms -count=5 .
