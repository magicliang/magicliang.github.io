(cd '/home/admin/workspace/my-blogs/source/_posts/2026-10-09-Go-35-profile如何定位热点而不替代测量' && sha256sum -c SHA256SUMS)
