go build -trimpath -o /tmp/go-language-39-taskstats .
