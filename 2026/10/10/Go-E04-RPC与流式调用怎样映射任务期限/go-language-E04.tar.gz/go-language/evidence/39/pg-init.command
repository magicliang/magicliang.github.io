/usr/lib/postgresql/16/bin/initdb -D '/tmp/go-language-39-pg.af8Xut' -A trust -U admin --no-instructions
