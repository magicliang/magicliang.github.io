python3 '/home/admin/workspace/my-blogs/writing-plans/go-language/scripts/check_page_00.py' '/tmp/go-language-hexo-39.L58cjf/public' '39'
