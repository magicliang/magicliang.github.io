/usr/lib/postgresql/16/bin/pg_ctl -D '/tmp/go-language-39-pg.af8Xut' -o '-h 127.0.0.1 -p 55909 -k /tmp/go-language-39-pg.af8Xut' -l '/tmp/go-language-39-pg.af8Xut/restart.log' start
