(cd '/home/admin/workspace/my-blogs/source/_posts/2026-10-09-Go-39-空环境如何验收任务完整生命周期' && sha256sum -c SHA256SUMS)
