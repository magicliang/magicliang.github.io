rg -n '^func (runTaskServer|newTaskHTTPServiceWithSQLRecovering|\(.*\) (create|lookup|cancelTask|Claim|Finish|Close))' serve.go http_tasks.go sql_tasks.go executor.go
