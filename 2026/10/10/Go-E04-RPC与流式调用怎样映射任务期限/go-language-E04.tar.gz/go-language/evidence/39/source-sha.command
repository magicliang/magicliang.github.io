sha256sum main.go serve.go http_tasks.go sql_tasks.go executor.go verification/39.sh verification/39-claim.sql verification/39-finish.sql go.mod go.sum
