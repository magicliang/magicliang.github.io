/usr/lib/postgresql/16/bin/pg_ctl -D '/tmp/go-language-39-pg.af8Xut' -m fast stop
