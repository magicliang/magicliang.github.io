psql -h 127.0.0.1 -p 55909 -U admin -d postgres -c 'CREATE DATABASE go39live'
