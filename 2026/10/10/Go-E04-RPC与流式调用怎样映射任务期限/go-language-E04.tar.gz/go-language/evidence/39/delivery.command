bash verification/39.sh /tmp/go-language-39-taskstats '/home/admin/workspace/my-blogs/writing-plans/go-language/evidence/39'
