/usr/lib/postgresql/16/bin/pg_ctl -D '/tmp/go-language-27-pg.VPukq7' -o '-h 127.0.0.1 -p 36807 -k /tmp/go-language-27-pg.VPukq7' -l '/tmp/go-language-27-pg.VPukq7/server.log' start
