curl -L --max-time 15 -sS -w "\nHTTP_STATUS=%{http_code}\n" https://go.dev/doc/database/manage-connections
