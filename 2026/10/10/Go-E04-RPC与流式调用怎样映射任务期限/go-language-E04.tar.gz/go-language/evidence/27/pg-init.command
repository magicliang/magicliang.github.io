/usr/lib/postgresql/16/bin/initdb -D '/tmp/go-language-27-pg.VPukq7' -A trust -U admin --no-instructions
