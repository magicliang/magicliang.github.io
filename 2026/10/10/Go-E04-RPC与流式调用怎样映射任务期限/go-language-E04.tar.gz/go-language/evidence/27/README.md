# 27 原始证据索引

`doc-*`、`environment*`、`pg-init/start/query/stop.*` 是 Go 1.27.1 与 PostgreSQL 16.15 固定环境及一手文档；`go-connections.*` 为官方连接管理网页 HTTP 502 的失败抓取，不能用作成功引用。固定驱动源码符号与文件 SHA 见 `research/27.md`；`focused`/`repeat` 为真库连接饱和、恢复与服务端慢查询取消单次及 20 次复跑；`tests`/`race`/`cli-*` 保存全量 Go 路径和旧 CLI 正反。`cli-timeout.exit=2` 是预期应用失败，`http-server.exit=143` 是检查后主动停止临时静态服务器；第一次打包 16MB 和旧页面摘要的内部迭代已用新的包/下载覆盖，最终只以素材目录 SHA256SUMS 的 `17bcf3...` 为准。

`package`/`archive-sha` 保存最终归档生成及核验命令；同名素材目录 `unpack-*` 保存最终包的新工程目录、新数据库与新模块缓存下独立复跑的命令/双流/退出码。`hexo`/`page` 和 `http-*` 保存最终包在隔离站点的正文、导航、前置、素材与下载摘要核验，静态 HTTP 检查不能代替 SQL 实验。全站构建含 27、其他平台、重启恢复、外部副作用去重及发布 `NOT_RUN`。
