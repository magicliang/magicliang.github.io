/usr/lib/postgresql/16/bin/pg_ctl -D '/tmp/go-language-27-pg.VPukq7' -m fast stop
