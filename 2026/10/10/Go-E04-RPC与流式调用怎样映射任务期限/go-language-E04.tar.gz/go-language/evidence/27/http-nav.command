curl --globoff --fail --silent --show-error --output '/home/admin/workspace/my-blogs/writing-plans/go-language/evidence/27/http-nav.body' --write-out 'status=%{http_code} bytes=%{size_download}
' 'http://127.0.0.1:53819/go-language/'
