go doc database/sql.DB.Stats
