go doc database/sql.Result.RowsAffected
