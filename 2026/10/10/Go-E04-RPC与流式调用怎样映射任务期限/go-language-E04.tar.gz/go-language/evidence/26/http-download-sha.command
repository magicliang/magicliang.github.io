sha256sum '/home/admin/workspace/my-blogs/writing-plans/go-language/evidence/26/http-archive.body'
