/usr/lib/postgresql/16/bin/pg_ctl -D '/tmp/go-language-26-pg.3BV4u1' -o '-h 127.0.0.1 -p 46339 -k /tmp/go-language-26-pg.3BV4u1' -l '/tmp/go-language-26-pg.3BV4u1/server.log' start
