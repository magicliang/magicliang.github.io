/usr/lib/postgresql/16/bin/initdb -D '/tmp/go-language-26-pg.3BV4u1' -A trust -U admin --no-instructions
