# 26 原始证据索引

`environment.txt`、`pg-init/start/query/isolation.*`、固定 `go.mod`/`go.sum` 与 `doc-*` 记录工具链、真实 PostgreSQL 16.15、默认隔离级别及本版 `database/sql` 一手 API。`focused-initial` 保留首次漏 import 导致编译退出 1，`focused-rejected-get` 保留 SQL 变为查询状态来源后，旧 25 测试仍期待数据库断开时 404 的失败；修正断言为 DB 不可用返回 503 后，正式 `focused`、`repeat`、`tests`、`race`、CLI 正反的 `.command/.stdout/.stderr/.exit` 原样保留。故意失败的 `SELECT 1/0` 被测试捕获并要求 Rollback，不使测试套件失败；CLI 零期限应用退出 2 是预期路径。

两个数据库连接竞争 Claim 与事务回滚、SQL 运行中/排队取消、Shutdown 等待不合作分析器退出、分析失败清零都是真实 PostgreSQL/loopback HTTP 实验；仍非多实例租约、跨进程恢复或外部副作用恰好一次保证。`package`/`archive-sha`/`sha` 对应本章完整包与摘要；同名素材目录 `unpack-*` 记录在新目录、新数据库、新模块缓存下独立解包、数据库生命周期、两包回归/race、30 次竞争/取消与旧 CLI 正反的命令/双流/退出码。`hexo`/`page` 与 `http-*` 对应隔离 00–26 页面、前置/导航/素材/摘要，以及本地静态 HTTP 正文/导航/包/SHA/RUN 五次 200 与下载摘要/二进制对照。静态服务受 45 秒 timeout 停止，退出 124 属预期；页面 200 不替代 SQL/race 实验。全站构建含 26、其他平台、异常崩溃恢复和发布仍 `NOT_RUN`。
