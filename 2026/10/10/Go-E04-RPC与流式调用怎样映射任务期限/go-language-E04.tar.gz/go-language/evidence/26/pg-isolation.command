psql -h 127.0.0.1 -p 46339 -U admin -d postgres -Atc 'show default_transaction_isolation'
