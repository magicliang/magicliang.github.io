go mod verify
