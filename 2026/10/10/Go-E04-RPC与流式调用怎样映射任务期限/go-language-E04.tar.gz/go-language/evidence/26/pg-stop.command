/usr/lib/postgresql/16/bin/pg_ctl -D '/tmp/go-language-26-pg.3BV4u1' -m fast stop
