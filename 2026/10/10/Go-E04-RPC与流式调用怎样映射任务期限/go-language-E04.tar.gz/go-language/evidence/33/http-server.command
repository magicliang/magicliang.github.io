timeout 40s python3 -m http.server 41293 --bind 127.0.0.1 --directory '/tmp/go-language-hexo-33.ulxrMF/public'
