go doc runtime/metrics
