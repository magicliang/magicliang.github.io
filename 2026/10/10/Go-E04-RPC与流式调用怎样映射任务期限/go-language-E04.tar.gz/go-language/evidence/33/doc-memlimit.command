go doc runtime/debug.SetMemoryLimit
