/usr/lib/postgresql/16/bin/initdb -D '/tmp/go-language-33-pg.ouSgxr' -A trust -U admin --no-instructions
