go doc runtime.GC
