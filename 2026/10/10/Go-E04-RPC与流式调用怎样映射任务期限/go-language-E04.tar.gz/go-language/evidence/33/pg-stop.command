/usr/lib/postgresql/16/bin/pg_ctl -D '/tmp/go-language-33-pg.ouSgxr' -m fast stop
