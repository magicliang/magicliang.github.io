/usr/lib/postgresql/16/bin/pg_ctl -D '/tmp/go-language-33-pg.ouSgxr' -o '-h 127.0.0.1 -p 49037 -k /tmp/go-language-33-pg.ouSgxr' -l '/tmp/go-language-33-pg.ouSgxr/server.log' start
