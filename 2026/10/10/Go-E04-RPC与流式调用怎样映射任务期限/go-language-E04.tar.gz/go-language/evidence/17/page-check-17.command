python3 writing-plans/go-language/scripts/check_page_00.py /tmp/go-language-hexo-17.KaAyze/public 17
