sha256sum '/home/admin/workspace/my-blogs/writing-plans/go-language/evidence/17/http-archive.body'
