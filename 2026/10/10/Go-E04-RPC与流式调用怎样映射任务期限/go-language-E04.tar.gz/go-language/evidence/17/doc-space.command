go doc unicode.IsSpace
