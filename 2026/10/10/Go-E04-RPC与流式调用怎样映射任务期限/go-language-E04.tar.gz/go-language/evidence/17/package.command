tar -C /tmp/go-language-17-pack.EWkxRk -czf /home/admin/workspace/my-blogs/source/_posts/2026-10-08-Go-17-取消请求发出后工作是否真的退出/go-language-17.tar.gz go-language
