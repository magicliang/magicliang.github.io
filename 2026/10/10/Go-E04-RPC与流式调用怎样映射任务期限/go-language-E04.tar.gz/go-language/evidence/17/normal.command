/tmp/go-language-17-taskstats --text "Go 写 Go"
