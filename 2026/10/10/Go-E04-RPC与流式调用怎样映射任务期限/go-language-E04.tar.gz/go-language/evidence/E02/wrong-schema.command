go run ./cmd/generate-taskvalidation -input verification/E02-bad-schema.go.txt -output '/home/admin/workspace/my-blogs/writing-plans/go-language/evidence/E02/wrong-output.go.txt'
