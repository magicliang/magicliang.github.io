go run ./cmd/generate-taskvalidation -input taskvalidation/schema.go -output '/home/admin/workspace/my-blogs/writing-plans/go-language/evidence/E02/fresh-generated.go.txt'
