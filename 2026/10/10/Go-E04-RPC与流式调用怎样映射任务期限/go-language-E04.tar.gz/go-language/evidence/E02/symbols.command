rg -n '^func (Validate|ValidateReflect|TestGenerated|BenchmarkTask|generate|\(service \*taskHTTPService\) create)' http_tasks.go taskvalidation/*.go cmd/generate-taskvalidation/main.go
