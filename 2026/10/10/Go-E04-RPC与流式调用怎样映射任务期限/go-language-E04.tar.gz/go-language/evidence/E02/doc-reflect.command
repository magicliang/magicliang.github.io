go doc reflect.StructTag.Get
