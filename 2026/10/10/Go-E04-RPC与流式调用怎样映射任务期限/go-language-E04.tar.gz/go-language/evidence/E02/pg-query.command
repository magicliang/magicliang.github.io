psql -h 127.0.0.1 -p 49497 -U admin -d postgres -Atc 'select version()'
