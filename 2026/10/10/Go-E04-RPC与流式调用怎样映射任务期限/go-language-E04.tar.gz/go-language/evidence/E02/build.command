go build -trimpath -o /tmp/go-language-E02-taskstats .
