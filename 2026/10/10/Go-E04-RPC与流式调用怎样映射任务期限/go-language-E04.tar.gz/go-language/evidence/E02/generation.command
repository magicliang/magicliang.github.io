bash verification/E02.sh '/home/admin/workspace/my-blogs/writing-plans/go-language/evidence/E02'
