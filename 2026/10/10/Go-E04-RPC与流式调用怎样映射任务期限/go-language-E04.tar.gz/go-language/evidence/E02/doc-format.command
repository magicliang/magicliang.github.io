go doc go/format.Source
