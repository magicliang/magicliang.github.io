/usr/lib/postgresql/16/bin/pg_ctl -D '/tmp/go-language-E02-pg.l478FX' -o '-h 127.0.0.1 -p 49497 -k /tmp/go-language-E02-pg.l478FX' -l '/tmp/go-language-E02-pg.l478FX/server.log' start
