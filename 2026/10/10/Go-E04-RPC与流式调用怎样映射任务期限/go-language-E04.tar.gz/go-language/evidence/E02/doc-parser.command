go doc go/parser.ParseFile
