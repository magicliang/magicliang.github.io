/usr/lib/postgresql/16/bin/pg_ctl -D '/tmp/go-language-E02-pg.l478FX' -m fast stop
