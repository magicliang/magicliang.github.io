/usr/lib/postgresql/16/bin/initdb -D '/tmp/go-language-E02-pg.l478FX' -A trust -U admin --no-instructions
