go test -count=1 -run 'TestHTTPExplicitCancel|TestHTTPQueuedCancel|TestHTTPClientCancel' -v .
