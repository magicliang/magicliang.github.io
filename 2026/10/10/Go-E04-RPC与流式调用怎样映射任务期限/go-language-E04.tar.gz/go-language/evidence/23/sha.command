cd '/home/admin/workspace/my-blogs/source/_posts/2026-10-08-Go-23-请求取消与任务取消为何分别建模' && sha256sum -c SHA256SUMS
