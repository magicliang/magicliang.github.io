cd '/home/admin/workspace/my-blogs' && python3 writing-plans/go-language/scripts/check_page_00.py '/tmp/go-language-hexo-23.9i0Gst/public' 23
