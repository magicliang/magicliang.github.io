sha256sum '/tmp/go-language-hexo-23.9i0Gst/downloaded-go-language-23.tar.gz'
