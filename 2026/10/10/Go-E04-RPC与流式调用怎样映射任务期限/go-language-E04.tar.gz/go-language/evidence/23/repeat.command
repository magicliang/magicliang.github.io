go test -count=30 -run 'TestHTTPExplicitCancel|TestHTTPQueuedCancel|TestHTTPClientCancel' -v .
