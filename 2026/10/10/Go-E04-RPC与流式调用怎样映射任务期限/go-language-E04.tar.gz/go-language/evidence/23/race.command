go test -race -count=1 -run 'TestHTTPExplicitCancel|TestHTTPQueuedCancel|TestHTTPClientCancel' -v .
