package main

import (
	"bytes"
	"context"
	"net/http"
	"net/http/httptest"
	"testing"

	"example.com/go-language-task/stats"
)

func BenchmarkTaskHTTPRead(b *testing.B) {
	service := newTaskHTTPService(context.Background(), 1, 1, 3)
	defer service.Close()
	if !service.store.Add("task[0]") || !service.store.Start("task[0]") || !service.store.Complete("task[0]", stats.Counts{Words: 3, Bytes: 10, Runes: 10}) {
		b.Fatal("prepare completed task")
	}
	handler := service.Handler()
	request := httptest.NewRequest(http.MethodGet, "/tasks/task%5B0%5D", nil)
	wantStatus := []byte(`"status":"SUCCEEDED"`)
	wantWords := []byte(`"words":3`)
	b.ReportAllocs()
	for b.Loop() {
		response := httptest.NewRecorder()
		handler.ServeHTTP(response, request)
		if response.Code != http.StatusOK || !bytes.Contains(response.Body.Bytes(), wantStatus) || !bytes.Contains(response.Body.Bytes(), wantWords) {
			b.Fatalf("HTTP read status=%d body=%q", response.Code, response.Body.Bytes())
		}
	}
}
