package main

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"sync"
	"testing"

	"example.com/go-language-task/stats"
)

type electiveLookupError struct {
	message string
}

func (lookupError *electiveLookupError) Error() string {
	if lookupError == nil {
		return "typed nil lookup error"
	}
	return lookupError.message
}

func TestElectiveJavaTypedNilIsNotMissingTask(t *testing.T) {
	var absent *electiveLookupError
	var lookupError error = absent
	if lookupError == nil || absent != nil {
		t.Fatalf("interface error=%v pointer=%v", lookupError, absent)
	}
	store := newTaskStore(nil)
	if record, exists := store.Lookup("missing"); exists || record.ID != "" {
		t.Fatalf("missing record=%+v exists=%v", record, exists)
	}
	t.Logf("typed nil pointer=nil but error interface !=nil; real Lookup(missing) uses exists=false")
}

func TestElectiveJavaTaskSnapshotIsCopied(t *testing.T) {
	store := newTaskStore(nil)
	if !store.Add("task[0]") {
		t.Fatal("new task rejected")
	}
	snapshot, exists := store.Lookup("task[0]")
	if !exists || snapshot.Status != StatusQueued {
		t.Fatalf("snapshot=%+v exists=%v", snapshot, exists)
	}
	snapshot.Status, snapshot.Words = StatusSucceeded, 99
	current, exists := store.Lookup("task[0]")
	if !exists || current.Status != StatusQueued || current.Words != 0 {
		t.Fatalf("mutated snapshot leaked to store: %+v exists=%v", current, exists)
	}
	if !store.Start("task[0]") {
		t.Fatal("explicit store transition rejected")
	}
	current, _ = store.Lookup("task[0]")
	if current.Status != StatusRunning {
		t.Fatalf("store transition not visible: %+v", current)
	}
	t.Log("mutated snapshot=SUCCEEDED/words=99; store stayed QUEUED/words=0 until Start -> RUNNING")
}

func TestElectiveJavaCancelDoesNotJoinWorker(t *testing.T) {
	started := make(chan struct{})
	release := make(chan struct{})
	releaseWorker := sync.OnceFunc(func() { close(release) })
	service := newTaskHTTPServiceUsing(context.Background(), 1, 1, 3, func(context.Context, string, int) (stats.Counts, error) {
		close(started)
		<-release
		return stats.Counts{Words: 1}, nil
	})
	defer service.Close()
	defer releaseWorker()
	server := httptest.NewServer(service.Handler())
	defer server.Close()
	status, _, payload := postTask(t, server.Client(), server.URL, `{"text":"Go"}`, "application/json")
	if status != http.StatusAccepted {
		t.Fatalf("submit=%d payload=%s", status, payload)
	}
	var accepted struct{ ID string `json:"id"` }
	if err := json.Unmarshal([]byte(payload), &accepted); err != nil || accepted.ID == "" {
		t.Fatalf("accepted=%q error=%v", payload, err)
	}
	<-started
	if status, record := cancelHTTPTask(t, server.Client(), server.URL, accepted.ID); status != http.StatusAccepted || record.Status != StatusRunning || !record.CancelRequested {
		t.Fatalf("cancel response=%d record=%+v", status, record)
	}
	if status, record := getTask(t, server.Client(), server.URL, accepted.ID); status != http.StatusOK || record.Status != StatusRunning || !record.CancelRequested {
		t.Fatalf("before release=%d record=%+v", status, record)
	}
	t.Logf("id=%s cancel HTTP=202 while analyzer remains RUNNING/cancel_requested=true", accepted.ID)
	releaseWorker()
	service.Close()
	if status, record := getTask(t, server.Client(), server.URL, accepted.ID); status != http.StatusOK || record.Status != StatusCanceled || record.Words != 0 {
		t.Fatalf("after worker exit=%d record=%+v", status, record)
	}
	t.Logf("id=%s worker exit confirmed; final CANCELED/words=0", accepted.ID)
}
