package main

import (
	"bytes"
	"context"
	"errors"
	"strings"
	"testing"

	"example.com/go-language-task/stats"
)

func TestCancellationUnblocksFullSendAndEmptyReceive(t *testing.T) {
	for _, testCase := range []struct {
		name string
		run  func(context.Context) error
	}{
		{
			name: "full send",
			run: func(ctx context.Context) error {
				inputs := make(chan queuedTask, 1)
				inputs <- queuedTask{text: "first"}
				return sendTask(ctx, inputs, queuedTask{text: "second"})
			},
		},
		{
			name: "empty receive",
			run: func(ctx context.Context) error {
				inputs := make(chan queuedTask)
				_, ok := receiveTask(ctx, inputs)
				if ok {
					return errors.New("empty receive unexpectedly succeeded")
				}
				return ctx.Err()
			},
		},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			started := make(chan struct{})
			returned := make(chan error, 1)
			go func() {
				close(started)
				returned <- testCase.run(ctx)
			}()
			<-started
			select {
			case err := <-returned:
				t.Fatalf("returned before cancel: %v", err)
			default:
				t.Log("blocked operation has no matching channel action")
			}
			cancel()
			if err := <-returned; !errors.Is(err, context.Canceled) {
				t.Fatalf("cancel returned %v; want context.Canceled", err)
			}
			t.Log("cancellation request followed by blocked operation exit confirmation")
		})
	}
}

func TestCancelRequestWaitsForWorkerExit(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	started := make(chan struct{})
	release := make(chan struct{})
	workerFinished := make(chan struct{})
	returned := make(chan error, 1)
	go func() {
		_, err := processTasksContextUsing(ctx, []string{"Go", "later"}, 3, func(_ context.Context, text string, _ int) (stats.Counts, error) {
			close(started)
			<-release
			close(workerFinished)
			return stats.Analyze(text), nil
		})
		returned <- err
	}()
	<-started
	cancel()
	select {
	case err := <-returned:
		t.Fatalf("cancel returned before worker release: %v", err)
	default:
		t.Log("cancel requested; worker blocked; caller still waiting")
	}
	close(release)
	if err := <-returned; !errors.Is(err, context.Canceled) {
		t.Fatalf("returned %v; want context.Canceled", err)
	}
	<-workerFinished
	t.Log("worker confirmed exit before caller returned context.Canceled")
}

func TestDeadlineReturnsClassifiedError(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 0)
	defer cancel()
	results, err := processTasksContext(ctx, []string{"Go", "one two"}, 3)
	if !errors.Is(err, context.DeadlineExceeded) || results != nil {
		t.Fatalf("results=%+v err=%v", results, err)
	}
	var stdout, stderr bytes.Buffer
	if code := run([]string{"--text", "Go", "--timeout", "0s"}, &stdout, &stderr); code != 2 || stdout.Len() != 0 || !strings.Contains(stderr.String(), "task deadline exceeded") {
		t.Fatalf("code=%d stdout=%q stderr=%q", code, stdout.String(), stderr.String())
	}
	t.Logf("deadline: results=%v error=%v CLI stderr=%q", results, err, stderr.String())
}
