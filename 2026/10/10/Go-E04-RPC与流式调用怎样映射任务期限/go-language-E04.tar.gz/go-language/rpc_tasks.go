package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"net/url"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

type taskJSONCodec struct{}

func (taskJSONCodec) Name() string { return "json" }
func (taskJSONCodec) Marshal(value any) ([]byte, error) { return json.Marshal(value) }
func (taskJSONCodec) Unmarshal(data []byte, value any) error { return json.Unmarshal(data, value) }

type rpcSubmitRequest struct {
	Text string `json:"text"`
}

type rpcSubmitReply struct {
	ID string `json:"id"`
}

type rpcWatchRequest struct {
	ID string `json:"id"`
}

type rpcTaskServer interface {
	Submit(context.Context, *rpcSubmitRequest) (*rpcSubmitReply, error)
	Watch(*rpcWatchRequest, grpc.ServerStream) error
}

type rpcTaskAdapter struct{ tasks *taskHTTPService }

func (adapter *rpcTaskAdapter) Submit(ctx context.Context, input *rpcSubmitRequest) (*rpcSubmitReply, error) {
	body, err := json.Marshal(input)
	if err != nil {
		return nil, status.Error(codes.InvalidArgument, "invalid task")
	}
	request := httptest.NewRequestWithContext(ctx, http.MethodPost, "/tasks", bytes.NewReader(body))
	request.Header.Set("Content-Type", "application/json")
	response := httptest.NewRecorder()
	adapter.tasks.Handler().ServeHTTP(response, request)
	if response.Code == http.StatusBadRequest {
		return nil, status.Error(codes.InvalidArgument, "invalid task input")
	}
	if response.Code != http.StatusAccepted {
		return nil, status.Errorf(codes.Unavailable, "task submission returned HTTP %d", response.Code)
	}
	var reply rpcSubmitReply
	if err := json.Unmarshal(response.Body.Bytes(), &reply); err != nil {
		return nil, status.Error(codes.Internal, "invalid task response")
	}
	return &reply, nil
}

func (adapter *rpcTaskAdapter) Watch(input *rpcWatchRequest, stream grpc.ServerStream) error {
	if input.ID == "" {
		return status.Error(codes.InvalidArgument, "missing task ID")
	}
	ticker := time.NewTicker(10 * time.Millisecond)
	defer ticker.Stop()
	var previous TaskStatus
	for {
		if err := stream.Context().Err(); err != nil {
			return status.FromContextError(err).Err()
		}
		request := httptest.NewRequestWithContext(stream.Context(), http.MethodGet, "/tasks/"+url.PathEscape(input.ID), nil)
		response := httptest.NewRecorder()
		adapter.tasks.Handler().ServeHTTP(response, request)
		if response.Code == http.StatusNotFound {
			return status.Error(codes.NotFound, "task not found")
		}
		if response.Code != http.StatusOK {
			return status.Errorf(codes.Unavailable, "task query returned HTTP %d", response.Code)
		}
		var record jsonTask
		if err := json.Unmarshal(response.Body.Bytes(), &record); err != nil {
			return status.Error(codes.Internal, "invalid task state")
		}
		if record.Status != previous {
			if err := stream.SendMsg(&record); err != nil {
				return fmt.Errorf("stream task state: %w", err)
			}
			previous = record.Status
		}
		if record.Status == StatusSucceeded || record.Status == StatusFailed || record.Status == StatusCanceled {
			return nil
		}
		select {
		case <-ticker.C:
		case <-stream.Context().Done():
			return status.FromContextError(stream.Context().Err()).Err()
		}
	}
}

var rpcTaskService = grpc.ServiceDesc{
	ServiceName: "taskstats.Tasks",
	HandlerType: (*rpcTaskServer)(nil),
	Methods: []grpc.MethodDesc{{
		MethodName: "Submit",
		Handler: func(service any, ctx context.Context, decode func(any) error, interceptor grpc.UnaryServerInterceptor) (any, error) {
			var input rpcSubmitRequest
			if err := decode(&input); err != nil {
				return nil, err
			}
			if interceptor == nil {
				return service.(rpcTaskServer).Submit(ctx, &input)
			}
			info := &grpc.UnaryServerInfo{Server: service, FullMethod: "/taskstats.Tasks/Submit"}
			return interceptor(ctx, &input, info, func(ctx context.Context, request any) (any, error) {
				return service.(rpcTaskServer).Submit(ctx, request.(*rpcSubmitRequest))
			})
		},
	}},
	Streams: []grpc.StreamDesc{{
		StreamName:    "Watch",
		ServerStreams: true,
		Handler: func(service any, stream grpc.ServerStream) error {
			var input rpcWatchRequest
			if err := stream.RecvMsg(&input); err != nil {
				return err
			}
			return service.(rpcTaskServer).Watch(&input, stream)
		},
	}},
}
