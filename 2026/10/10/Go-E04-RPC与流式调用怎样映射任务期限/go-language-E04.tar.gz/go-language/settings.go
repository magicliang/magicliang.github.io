package main

import "sync"

type taskSettings struct {
	once   sync.Once
	config Config
	err    error
}

func (settings *taskSettings) Load(initialize func() (Config, error)) (Config, error) {
	settings.once.Do(func() {
		settings.config, settings.err = initialize()
	})
	return settings.config, settings.err
}
