package main

import (
	"fmt"

	"example.com/go-language-task/stats"
)

type TaskStatus string

const (
	StatusQueued    TaskStatus = "QUEUED"
	StatusRunning   TaskStatus = "RUNNING"
	StatusSucceeded TaskStatus = "SUCCEEDED"
	StatusFailed    TaskStatus = "FAILED"
	StatusCanceled  TaskStatus = "CANCELED"
)

type TaskResult struct {
	stats.Counts
}

func (result TaskResult) Summary() string {
	return fmt.Sprintf("words=%d bytes=%d runes=%d", result.Words, result.Bytes, result.Runes)
}

type TaskRecord struct {
	ID string
	TaskResult
	Status          TaskStatus
	CancelRequested bool
	FailureReason   string
}

func newTaskRecord(id string) TaskRecord {
	return TaskRecord{ID: id, Status: StatusQueued}
}

func (record *TaskRecord) MarkSucceeded(counts stats.Counts) {
	record.TaskResult = TaskResult{Counts: counts}
	record.Status = StatusSucceeded
}
