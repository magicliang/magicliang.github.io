package main

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"

	"example.com/go-language-task/stats"
)

const maxDownstreamBytes = 4096

var ErrDownstreamStatus = errors.New("downstream returned an error status")
var ErrDownstreamBodyTooLarge = errors.New("downstream response too large")

func probeDownstream(ctx context.Context, client *http.Client, baseURL, text string) error {
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, baseURL+"/check?text="+url.QueryEscape(text), nil)
	if err != nil {
		return err
	}
	response, err := client.Do(request)
	if err != nil {
		return fmt.Errorf("downstream request: %w", err)
	}
	defer response.Body.Close()
	readBytes, err := io.Copy(io.Discard, io.LimitReader(response.Body, maxDownstreamBytes+1))
	if err != nil {
		return fmt.Errorf("downstream body: %w", err)
	}
	if readBytes > maxDownstreamBytes {
		return ErrDownstreamBodyTooLarge
	}
	if response.StatusCode != http.StatusOK {
		return fmt.Errorf("%w: %d", ErrDownstreamStatus, response.StatusCode)
	}
	return nil
}

func newTaskHTTPServiceWithDownstream(ctx context.Context, workers, queueCapacity, maxWords int, client *http.Client, baseURL string) *taskHTTPService {
	return newTaskHTTPServiceUsing(ctx, workers, queueCapacity, maxWords, func(taskContext context.Context, text string, limit int) (stats.Counts, error) {
		if err := probeDownstream(taskContext, client, baseURL, text); err != nil {
			return stats.Counts{}, err
		}
		return analyzeTaskAsyncContext(taskContext, text, limit)
	})
}
