package main

import (
	"context"
	"io"
	"net"
	"testing"

	"example.com/go-language-task/stats"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/status"
)

func TestRPCSubmissionCancelStreamAndBusinessExit(t *testing.T) {
	db := openSQLTestDatabase(t)
	started := make(chan struct{})
	release := make(chan struct{})
	service, err := newTaskHTTPServiceWithSQLUsing(context.Background(), 1, 1, 3, db, func(context.Context, string, int) (stats.Counts, error) {
		close(started)
		<-release
		return stats.Counts{Words: 2, Bytes: 6, Runes: 6}, nil
	})
	if err != nil {
		t.Fatal(err)
	}
	defer service.Close()
	defer func() { select { case <-release: default: close(release) } }()
	if _, err := db.ExecContext(context.Background(), "TRUNCATE go_tasks"); err != nil {
		t.Fatal(err)
	}
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	server := grpc.NewServer(grpc.ForceServerCodec(taskJSONCodec{}))
	server.RegisterService(&rpcTaskService, &rpcTaskAdapter{tasks: service})
	defer server.Stop()
	serverDone := make(chan error, 1)
	go func() { serverDone <- server.Serve(listener) }()
	connection, err := grpc.NewClient(listener.Addr().String(), grpc.WithTransportCredentials(insecure.NewCredentials()), grpc.WithDefaultCallOptions(grpc.ForceCodec(taskJSONCodec{})))
	if err != nil {
		t.Fatal(err)
	}
	defer connection.Close()
	var invalid rpcSubmitReply
	if err := connection.Invoke(context.Background(), "/taskstats.Tasks/Submit", &rpcSubmitRequest{Text: " "}, &invalid); status.Code(err) != codes.InvalidArgument {
		t.Fatalf("invalid input error=%v", err)
	}
	var accepted rpcSubmitReply
	if err := connection.Invoke(context.Background(), "/taskstats.Tasks/Submit", &rpcSubmitRequest{Text: "Go one"}, &accepted); err != nil || accepted.ID == "" {
		t.Fatalf("RPC submit id=%q error=%v", accepted.ID, err)
	}
	<-started
	ctx, cancel := context.WithCancel(context.Background())
	stream, err := connection.NewStream(ctx, &grpc.StreamDesc{ServerStreams: true}, "/taskstats.Tasks/Watch")
	if err != nil {
		t.Fatal(err)
	}
	if err := stream.SendMsg(&rpcWatchRequest{ID: accepted.ID}); err != nil {
		t.Fatal(err)
	}
	if err := stream.CloseSend(); err != nil {
		t.Fatal(err)
	}
	var observed jsonTask
	if err := stream.RecvMsg(&observed); err != nil || observed.Status != StatusRunning {
		t.Fatalf("first event=%+v error=%v", observed, err)
	}
	cancel()
	var subsequent jsonTask
	if err := stream.RecvMsg(&subsequent); status.Code(err) != codes.Canceled {
		t.Fatalf("client cancellation error=%v", err)
	}
	before, _, err := service.sqlStore.Lookup(context.Background(), accepted.ID)
	if err != nil || before.Status != StatusRunning || before.Words != 0 {
		t.Fatalf("after client cancel SQL=%+v error=%v", before, err)
	}
	t.Logf("RPC id=%s; stream canceled, SQL still RUNNING/words=0", accepted.ID)
	server.GracefulStop()
	if err := <-serverDone; err != nil {
		t.Fatalf("gRPC serve exit=%v", err)
	}
	stillRunning, _, err := service.sqlStore.Lookup(context.Background(), accepted.ID)
	if err != nil || stillRunning.Status != StatusRunning {
		t.Fatalf("after RPC server exit SQL=%+v error=%v", stillRunning, err)
	}
	t.Logf("RPC server exited; business id=%s still RUNNING", accepted.ID)
	close(release)
	service.Close()
	final, _, err := service.sqlStore.Lookup(context.Background(), accepted.ID)
	if err != nil || final.Status != StatusSucceeded || final.Words != 2 {
		t.Fatalf("after business worker exit SQL=%+v error=%v", final, err)
	}
	t.Logf("business worker exited; SQL id=%s status=%s words=%d", accepted.ID, final.Status, final.Words)
}

func TestRPCWatchStreamsTerminalAndMissingTask(t *testing.T) {
	service := newTaskHTTPService(context.Background(), 1, 1, 3)
	defer service.Close()
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	server := grpc.NewServer(grpc.ForceServerCodec(taskJSONCodec{}))
	server.RegisterService(&rpcTaskService, &rpcTaskAdapter{tasks: service})
	defer server.Stop()
	go server.Serve(listener)
	connection, err := grpc.NewClient(listener.Addr().String(), grpc.WithTransportCredentials(insecure.NewCredentials()), grpc.WithDefaultCallOptions(grpc.ForceCodec(taskJSONCodec{})))
	if err != nil {
		t.Fatal(err)
	}
	defer connection.Close()
	var accepted rpcSubmitReply
	if err := connection.Invoke(context.Background(), "/taskstats.Tasks/Submit", &rpcSubmitRequest{Text: "Go one"}, &accepted); err != nil {
		t.Fatal(err)
	}
	watch := func(id string) grpc.ClientStream {
		t.Helper()
		stream, err := connection.NewStream(context.Background(), &grpc.StreamDesc{ServerStreams: true}, "/taskstats.Tasks/Watch")
		if err != nil {
			t.Fatal(err)
		}
		if err := stream.SendMsg(&rpcWatchRequest{ID: id}); err != nil {
			t.Fatal(err)
		}
		if err := stream.CloseSend(); err != nil {
			t.Fatal(err)
		}
		return stream
	}
	stream := watch(accepted.ID)
	var last jsonTask
	for event := 0; event < 4; event++ {
		if err := stream.RecvMsg(&last); err != nil {
			t.Fatal(err)
		}
		if last.Status == StatusSucceeded {
			break
		}
	}
	if last.Status != StatusSucceeded || last.Words != 2 || last.ID != accepted.ID {
		t.Fatalf("stream final=%+v", last)
	}
	if err := stream.RecvMsg(&last); err != io.EOF {
		t.Fatalf("terminal stream end=%v", err)
	}
	var missing jsonTask
	if err := watch("missing").RecvMsg(&missing); status.Code(err) != codes.NotFound {
		t.Fatalf("missing task error=%v", err)
	}
	t.Logf("RPC id=%s streamed SUCCEEDED/words=%d then EOF; missing ID=NotFound", accepted.ID, last.Words)
}
