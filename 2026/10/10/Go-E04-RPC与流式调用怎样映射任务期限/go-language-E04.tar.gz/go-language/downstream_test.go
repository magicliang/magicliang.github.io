package main

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func TestDownstreamResponseReuseAndTaskResults(t *testing.T) {
	var connections atomic.Int32
	downstream := httptest.NewUnstartedServer(http.HandlerFunc(func(output http.ResponseWriter, request *http.Request) {
		switch request.URL.Query().Get("text") {
		case "bad":
			output.WriteHeader(http.StatusServiceUnavailable)
			io.WriteString(output, "rejected")
		case "huge":
			io.WriteString(output, strings.Repeat("x", maxDownstreamBytes+1))
		default:
			io.WriteString(output, "ok")
		}
	}))
	downstream.Config.ConnState = func(_ net.Conn, state http.ConnState) {
		if state == http.StateNew {
			connections.Add(1)
		}
	}
	downstream.Start()
	defer downstream.Close()
	client := downstream.Client()
	client.Timeout = 2 * time.Second
	defer client.CloseIdleConnections()
	for index := 0; index < 40; index++ {
		text := "Go"
		if index%2 == 1 {
			text = "bad"
		}
		err := probeDownstream(context.Background(), client, downstream.URL, text)
		if text == "Go" && err != nil || text == "bad" && !errors.Is(err, ErrDownstreamStatus) {
			t.Fatalf("request %d text=%s error=%v", index, text, err)
		}
	}
	if err := probeDownstream(context.Background(), client, downstream.URL, "huge"); !errors.Is(err, ErrDownstreamBodyTooLarge) {
		t.Fatalf("oversize body error=%v", err)
	}
	if connections.Load() > 2 {
		t.Fatalf("40 drained responses opened %d connections", connections.Load())
	}
	service := newTaskHTTPServiceWithDownstream(context.Background(), 1, 2, 3, client, downstream.URL)
	server := httptest.NewServer(service.Handler())
	defer server.Close()
	for position, text := range []string{"Go", "bad", "huge"} {
		status, _, body := postTask(t, server.Client(), server.URL, `{"text":"`+text+`"}`, "application/json")
		if status != http.StatusAccepted || !strings.Contains(body, fmt.Sprintf(`"task[%d]"`, position)) {
			t.Fatalf("submitted %s status=%d body=%q", text, status, body)
		}
	}
	service.Close()
	for position, want := range []TaskStatus{StatusSucceeded, StatusFailed, StatusFailed} {
		id := fmt.Sprintf("task[%d]", position)
		if status, record := getTask(t, server.Client(), server.URL, id); status != http.StatusOK || record.Status != want {
			t.Fatalf("%s status=%d record=%+v want=%s", id, status, record, want)
		}
	}
	t.Logf("drained 40 alternating 200/503 bodies; new-connections=%d; task outcomes=SUCCEEDED,FAILED,FAILED; 4097-byte body rejected", connections.Load())
}

func TestDownstreamDialBoundaryAndSlowResponseDeadline(t *testing.T) {
	dialClient := &http.Client{Timeout: time.Second, Transport: &http.Transport{
		DialContext: func(ctx context.Context, _, _ string) (net.Conn, error) {
			connectContext, cancel := context.WithTimeout(ctx, 30*time.Millisecond)
			defer cancel()
			<-connectContext.Done()
			return nil, connectContext.Err()
		},
	}}
	defer dialClient.CloseIdleConnections()
	if err := probeDownstream(context.Background(), dialClient, "http://127.0.0.1:1", "Go"); !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("simulated blocked dial error=%v", err)
	}
	started := make(chan struct{})
	exited := make(chan struct{})
	downstream := httptest.NewServer(http.HandlerFunc(func(output http.ResponseWriter, request *http.Request) {
		close(started)
		<-request.Context().Done()
		close(exited)
	}))
	defer downstream.Close()
	transport := &http.Transport{DialContext: (&net.Dialer{Timeout: 30 * time.Millisecond}).DialContext}
	defer transport.CloseIdleConnections()
	client := &http.Client{Transport: transport, Timeout: 150 * time.Millisecond}
	result := make(chan error, 1)
	go func() {
		result <- probeDownstream(context.Background(), client, downstream.URL, "Go")
	}()
	<-started
	if err := <-result; !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("response deadline error=%v", err)
	}
	<-exited
	t.Log("simulated dial budget=30ms expires before any HTTP response; real localhost dial succeeds but Client.Timeout=150ms cancels slow headers")
}

func TestTaskCancelInterruptsDownstreamRequest(t *testing.T) {
	started := make(chan struct{})
	exited := make(chan struct{})
	downstream := httptest.NewServer(http.HandlerFunc(func(output http.ResponseWriter, request *http.Request) {
		close(started)
		<-request.Context().Done()
		close(exited)
	}))
	defer downstream.Close()
	client := downstream.Client()
	client.Timeout = 2 * time.Second
	defer client.CloseIdleConnections()
	service := newTaskHTTPServiceWithDownstream(context.Background(), 1, 1, 3, client, downstream.URL)
	server := httptest.NewServer(service.Handler())
	defer server.Close()
	status, _, _ := postTask(t, server.Client(), server.URL, `{"text":"Go"}`, "application/json")
	if status != http.StatusAccepted {
		t.Fatalf("submit status=%d", status)
	}
	<-started
	if status, _ := cancelHTTPTask(t, server.Client(), server.URL, "task[0]"); status != http.StatusAccepted {
		t.Fatalf("cancel status=%d", status)
	}
	<-exited
	service.Close()
	if status, record := getTask(t, server.Client(), server.URL, "task[0]"); status != http.StatusOK || record.Status != StatusCanceled {
		t.Fatalf("after outbound cancel status=%d record=%+v", status, record)
	}
	t.Log("service-owned task cancel propagates to in-flight downstream HTTP; task final status=CANCELED after request exits")
}

func TestDownstreamClientTimeoutFailsAcceptedTask(t *testing.T) {
	started := make(chan struct{})
	exited := make(chan struct{})
	downstream := httptest.NewServer(http.HandlerFunc(func(output http.ResponseWriter, request *http.Request) {
		close(started)
		<-request.Context().Done()
		close(exited)
	}))
	defer downstream.Close()
	client := downstream.Client()
	client.Timeout = 150 * time.Millisecond
	defer client.CloseIdleConnections()
	service := newTaskHTTPServiceWithDownstream(context.Background(), 1, 1, 3, client, downstream.URL)
	server := httptest.NewServer(service.Handler())
	defer server.Close()
	status, _, _ := postTask(t, server.Client(), server.URL, `{"text":"Go"}`, "application/json")
	if status != http.StatusAccepted {
		t.Fatalf("submit status=%d", status)
	}
	<-started
	service.Close()
	<-exited
	if status, record := getTask(t, server.Client(), server.URL, "task[0]"); status != http.StatusOK || record.Status != StatusFailed || record.CancelRequested {
		t.Fatalf("client timeout record status=%d record=%+v", status, record)
	}
	t.Log("accepted POST=202; downstream Client.Timeout=150ms without task cancel; task final status=FAILED")
}
