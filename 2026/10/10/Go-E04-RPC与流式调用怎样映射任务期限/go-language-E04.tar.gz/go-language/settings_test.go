package main

import (
	"errors"
	"sync/atomic"
	"testing"
)

func TestSettingsOnceInitializesForConcurrentCallers(t *testing.T) {
	settings := &taskSettings{}
	var calls atomic.Uint64
	start := make(chan struct{})
	result := make(chan Config, 64)
	for index := 0; index < cap(result); index++ {
		go func() {
			<-start
			config, err := settings.Load(func() (Config, error) {
				calls.Add(1)
				return Config{MaxWords: 3}, nil
			})
			if err != nil {
				result <- Config{}
				return
			}
			result <- config
		}()
	}
	close(start)
	for index := 0; index < cap(result); index++ {
		if config := <-result; config.MaxWords != 3 {
			t.Fatalf("different config: %+v", config)
		}
	}
	if calls.Load() != 1 {
		t.Fatalf("initializer calls=%d; want 1", calls.Load())
	}
	t.Logf("64 callers, initializer calls=%d", calls.Load())
}

func TestSettingsOnceRetainsInitializationError(t *testing.T) {
	settings := &taskSettings{}
	invalid := errors.New("invalid config")
	_, first := settings.Load(func() (Config, error) { return Config{}, invalid })
	_, second := settings.Load(func() (Config, error) {
		t.Fatal("failed config was silently retried")
		return Config{MaxWords: 3}, nil
	})
	if first != invalid || second != invalid {
		t.Fatalf("first=%v second=%v", first, second)
	}
}
