package native

/*
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

static uint64_t task_ascii_sum(const unsigned char *bytes, size_t length) {
    uint64_t result = 0;
    for (size_t position = 0; position < length; position++) {
        result += bytes[position];
    }
    return result;
}
*/
import "C"

import (
	"errors"
	"unsafe"
)

func SumASCII(input []byte) (uint64, error) {
	if len(input) == 0 || len(input) > 4096 {
		return 0, errors.New("native input length must be 1..4096")
	}
	for _, value := range input {
		if value == 0 || value > 127 {
			return 0, errors.New("native input must be non-NUL ASCII")
		}
	}
	buffer := C.CBytes(input)
	defer C.free(buffer)
	return uint64(C.task_ascii_sum((*C.uchar)(unsafe.Pointer(buffer)), C.size_t(len(input)))), nil
}
