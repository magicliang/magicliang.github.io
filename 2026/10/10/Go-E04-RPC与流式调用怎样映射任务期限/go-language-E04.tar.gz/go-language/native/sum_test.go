package native

import (
	"strings"
	"testing"
)

func TestLocalNativeFunctionAndInvalidInputs(t *testing.T) {
	for run := 0; run < 100; run++ {
		result, err := SumASCII([]byte("Go"))
		if err != nil || result != 182 {
			t.Fatalf("run=%d result=%d error=%v", run, result, err)
		}
	}
	for _, input := range [][]byte{nil, {}, []byte("Go\x00"), []byte("中文"), []byte(strings.Repeat("A", 4097))} {
		result, err := SumASCII(input)
		if err == nil || result != 0 {
			t.Fatalf("bad input bytes=%d result=%d error=%v", len(input), result, err)
		}
		t.Logf("input bytes=%d rejected: %v", len(input), err)
	}
	t.Log("Go -> ASCII sum=182 in 100 calls; C.CBytes paired with C.free on valid path")
}
