package main

import (
	"bytes"
	"context"
	"net/http"
	"net/http/httptest"
	"runtime"
	"runtime/pprof"
	"strings"
	"sync"
	"testing"
	"time"

	"example.com/go-language-task/stats"
)

func TestChannelWakeAndWorkerExit(t *testing.T) {
	for _, wake := range []string{"close", "send"} {
		t.Run(wake, func(t *testing.T) {
			release := make(chan struct{})
			started := make(chan struct{})
			received := make(chan bool, 1)
			var cleanup sync.Once
			service := newTaskHTTPServiceUsing(context.Background(), 1, 1, 2, func(ctx context.Context, text string, _ int) (stats.Counts, error) {
				if text == "Go one" {
					close(started)
					_, ok := <-release
					received <- ok
				}
				return stats.AnalyzeContext(ctx, text)
			})
			t.Cleanup(func() {
				cleanup.Do(func() { close(release) })
				service.Close()
			})
			handler := service.Handler()
			submit := func(text string) int {
				request := httptest.NewRequest(http.MethodPost, "/tasks", strings.NewReader(`{"text":"`+text+`"}`))
				request.Header.Set("Content-Type", "application/json")
				response := httptest.NewRecorder()
				handler.ServeHTTP(response, request)
				return response.Code
			}
			if status := submit("Go one"); status != http.StatusAccepted {
				t.Fatalf("first POST status=%d", status)
			}
			<-started
			if status := submit("Go"); status != http.StatusAccepted {
				t.Fatalf("queued POST status=%d", status)
			}
			if status := submit("overload"); status != http.StatusServiceUnavailable {
				t.Fatalf("overload POST status=%d", status)
			}
			first, exists := service.store.Lookup("task[0]")
			if !exists || first.Status != StatusRunning {
				t.Fatalf("first before release exists=%t record=%+v", exists, first)
			}
			second, exists := service.store.Lookup("task[1]")
			if !exists || second.Status != StatusQueued {
				t.Fatalf("second before release exists=%t record=%+v", exists, second)
			}
			if _, exists := service.store.Lookup("task[2]"); exists {
				t.Fatal("overload allocated task[2]")
			}
			var profile bytes.Buffer
			blocked := false
			for deadline := time.Now().Add(2 * time.Second); time.Now().Before(deadline); {
				profile.Reset()
				if err := pprof.Lookup("goroutine").WriteTo(&profile, 2); err != nil {
					t.Fatal(err)
				}
				for _, stack := range strings.Split(profile.String(), "goroutine ") {
					if strings.Contains(stack, "TestChannelWakeAndWorkerExit.func1.1") && strings.Contains(stack, "[chan receive]") {
						blocked = true
						break
					}
				}
				if blocked {
					break
				}
				runtime.Gosched()
			}
			if !blocked {
				t.Fatalf("worker was not observed in channel receive:\n%s", profile.String())
			}
			closeStarted := make(chan struct{})
			closeReturned := make(chan struct{})
			go func() {
				close(closeStarted)
				service.Close()
				close(closeReturned)
			}()
			<-closeStarted
			select {
			case <-closeReturned:
				t.Fatal("service.Close returned before worker release")
			default:
			}
			if wake == "close" {
				cleanup.Do(func() { close(release) })
			} else {
				release <- struct{}{}
			}
			select {
			case <-closeReturned:
			case <-time.After(5 * time.Second):
				t.Fatal("service.Close did not confirm worker exit")
			}
			ok := <-received
			if ok != (wake == "send") {
				t.Fatalf("wakeup=%s receive ok=%t", wake, ok)
			}
			for _, item := range []struct {
				id    string
				words int
			}{{"task[0]", 2}, {"task[1]", 1}} {
				record, found := service.store.Lookup(item.id)
				if !found || record.Status != StatusSucceeded || record.Words != item.words {
					t.Fatalf("%s found=%t record=%+v", item.id, found, record)
				}
			}
			t.Logf("wake=%s receive_ok=%t; task[0]=SUCCEEDED words=2 task[1]=SUCCEEDED words=1; close confirmed after release", wake, ok)
		})
	}
}
