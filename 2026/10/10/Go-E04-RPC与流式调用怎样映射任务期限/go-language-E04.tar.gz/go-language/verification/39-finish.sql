CREATE OR REPLACE FUNCTION delay_task_finish() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status = 'SUCCEEDED' THEN
    PERFORM pg_sleep(10);
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER delay_finish BEFORE UPDATE ON go_tasks FOR EACH ROW EXECUTE FUNCTION delay_task_finish();
