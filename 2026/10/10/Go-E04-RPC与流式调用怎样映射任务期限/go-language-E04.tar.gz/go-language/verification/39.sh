#!/usr/bin/env bash
set -u
binary=$1 evidence=$2
mkdir -p "$evidence"
capture() {
  local name=$1 command=$2 exit_code
  printf '%s\n' "$command" > "$evidence/$name.command"
  bash -c "$command" > "$evidence/$name.stdout" 2> "$evidence/$name.stderr"
  exit_code=$?
  printf '%s\n' "$exit_code" > "$evidence/$name.exit"
  printf '%s exit=%s\n' "$name" "$exit_code"
  return "$exit_code"
}
check_status() { rg -q "HTTP_STATUS=$2" "$evidence/$1.stdout" || exit 1; }
database="psql -X -v ON_ERROR_STOP=1 -h 127.0.0.1 -p $PGPORT -U admin -d go39live"
start_server() {
  local name=$1 ready=
  printf '%q ' "$binary" serve --listen 127.0.0.1:0 --admin 127.0.0.1:0 --workers 1 --queue-capacity 1 --max-words 3 --sql-dsn "$GO_LANGUAGE_SERVE_DSN" > "$evidence/$name.command"
  printf '\n' >> "$evidence/$name.command"
  "$binary" serve --listen 127.0.0.1:0 --admin 127.0.0.1:0 --workers 1 --queue-capacity 1 --max-words 3 --sql-dsn "$GO_LANGUAGE_SERVE_DSN" > "$evidence/$name.stdout" 2> "$evidence/$name.stderr" &
  server_pid=$!
  for attempt in {1..60}; do
    if rg -q '^http=127\.0\.0\.1:[0-9]+ admin=127\.0\.0\.1:[0-9]+$' "$evidence/$name.stdout"; then
      ready=$(rg '^http=' "$evidence/$name.stdout" | head -1)
      break
    fi
    kill -0 "$server_pid" 2>/dev/null || { echo "$name exited before ready" >&2; exit 1; }
    sleep 0.1
  done
  test -n "$ready" || exit 1
  app=${ready#http=}
  app=${app%% admin=*}
  printf '%s\n' "$ready" > "$evidence/$name.addresses"
}
stop_server() {
  local name=$1 signal=$2 expected=$3 exit_code
  capture "$name-signal" "kill -$signal $server_pid" || exit 1
  printf 'wait %s\n' "$server_pid" > "$evidence/$name-wait.command"
  wait "$server_pid" > "$evidence/$name-wait.stdout" 2> "$evidence/$name-wait.stderr"
  exit_code=$?
  printf '%s\n' "$exit_code" > "$evidence/$name-wait.exit"
  test "$exit_code" = "$expected" || exit 1
  server_pid=
}
request() {
  local name=$1 method=$2 url=$3 body=${4:-}
  if [[ "$method" == POST ]]; then
    capture "$name" "curl --globoff --max-time 15 --silent --show-error -H 'Content-Type: application/json' -d '$body' --output '$evidence/$name.body' --write-out 'HTTP_STATUS=%{http_code}\\n' 'http://$app$url'" || exit 1
  else
    capture "$name" "curl --globoff --max-time 15 --silent --show-error --output '$evidence/$name.body' --write-out 'HTTP_STATUS=%{http_code}\\n' 'http://$app$url'" || exit 1
  fi
}
task_id() { python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["id"])' "$evidence/$1.body"; }
task_path() { python3 -c 'import sys; from urllib.parse import quote; print("/tasks/"+quote(sys.argv[1],safe=""))' "$1"; }
poll_status() {
  local name=$1 id=$2 target=$3
  for attempt in {1..60}; do
    request "$name-$attempt" GET "$(task_path "$id")"
    if rg -q "\"status\":\"$target\"" "$evidence/$name-$attempt.body"; then
      printf 'id=%s status=%s poll=%s\n' "$id" "$target" "$attempt" > "$evidence/$name.terminal"
      return 0
    fi
    sleep 0.1
  done
  return 1
}
server_pid=
trap 'if [[ -n "$server_pid" ]]; then kill -TERM "$server_pid" 2>/dev/null || :; wait "$server_pid" 2>/dev/null || :; fi' EXIT
capture bad-config "'$binary' serve --admin 0.0.0.0:0"
test "$(cat "$evidence/bad-config.exit")" = 2 && test ! -s "$evidence/bad-config.stdout" || exit 1
start_server initial
request accepted POST /tasks '{"text":"Go one"}'
check_status accepted 202
accepted_id=$(task_id accepted)
printf '%s\n' "$accepted_id" > "$evidence/accepted.id"
poll_status completed "$accepted_id" SUCCEEDED || exit 1
capture accepted-sql "$database -Atc \"SELECT id,status,words,bytes,runes FROM go_tasks WHERE id='$accepted_id'\"" || exit 1
rg -Fqx "$accepted_id|SUCCEEDED|2|6|6" "$evidence/accepted-sql.stdout" || exit 1
request malformed POST /tasks '{"text":'
check_status malformed 400
request missing GET /tasks/nonexistent
check_status missing 404
request invalid-task POST /tasks '{"text":"one two three four"}'
check_status invalid-task 202
failed_id=$(task_id invalid-task)
poll_status failed "$failed_id" FAILED || exit 1
capture failed-sql "$database -Atc \"SELECT id,status,words,failure_reason FROM go_tasks WHERE id='$failed_id'\"" || exit 1
rg -Fq "$failed_id|FAILED|0|" "$evidence/failed-sql.stdout" || exit 1
request cancel-finished POST "$(task_path "$accepted_id")/cancel" '{}'
check_status cancel-finished 409
capture create-claim-trigger "$database -f verification/39-claim.sql" || exit 1
request running POST /tasks '{"text":"worker"}'
check_status running 202
running_id=$(task_id running)
request queued POST /tasks '{"text":"queued"}'
check_status queued 202
queued_id=$(task_id queued)
request overloaded POST /tasks '{"text":"overload"}'
check_status overloaded 503
capture rejected-sql "$database -Atc \"SELECT count(*) FROM go_tasks WHERE input_text='overload'\"" || exit 1
test "$(cat "$evidence/rejected-sql.stdout")" = 0 || exit 1
request cancel-queued POST "$(task_path "$queued_id")/cancel" '{}'
check_status cancel-queued 202
poll_status canceled "$queued_id" CANCELED || exit 1
request cancel-duplicate POST "$(task_path "$queued_id")/cancel" '{}'
check_status cancel-duplicate 409
poll_status running-completed "$running_id" SUCCEEDED || exit 1
capture drop-claim-trigger "$database -c 'DROP TRIGGER delay_claim ON go_tasks; DROP FUNCTION delay_task_claim()'" || exit 1
pg_control=${PG_CTL:-$(command -v pg_ctl)}
test -n "$pg_control" || { printf '%s\n' 'set PG_CTL to PostgreSQL 16.15 pg_ctl' >&2; exit 1; }
capture pg-fail "'$pg_control' -D '$PGDATA' -m fast stop" || exit 1
request unavailable GET "$(task_path "$accepted_id")"
check_status unavailable 503
request rejected-db POST /tasks '{"text":"db lost"}'
check_status rejected-db 503
capture pg-recover "'$pg_control' -D '$PGDATA' -o '-h 127.0.0.1 -p $PGPORT -k $PGDATA' -l '$PGDATA/restart.log' start" || exit 1
request recovered GET "$(task_path "$accepted_id")"
check_status recovered 200
stop_server initial TERM 0
capture initial-ports-released "python3 -c 'import socket,sys; [ (lambda address, sock: (sock.bind((\"127.0.0.1\",int(address.rsplit(\":\",1)[1]))),sock.close()))(address,socket.socket()) for address in sys.argv[1:] ]; print(\"ports released\")' '$app' '$(sed -n 's/^.* admin=//p' "$evidence/initial.addresses")'" || exit 1
start_server restart
request persisted GET "$(task_path "$accepted_id")"
check_status persisted 200
rg -q '"status":"SUCCEEDED"' "$evidence/persisted.body" || exit 1
capture create-finish-trigger "$database -f verification/39-finish.sql" || exit 1
request crash-task POST /tasks '{"text":"crash"}'
check_status crash-task 202
crash_id=$(task_id crash-task)
printf '%s\n' "$crash_id" > "$evidence/crash.id"
for attempt in {1..80}; do
  capture "crash-running-$attempt" "$database -Atc \"SELECT id,status,words FROM go_tasks WHERE id='$crash_id'\"" || exit 1
  rg -Fqx "$crash_id|RUNNING|0" "$evidence/crash-running-$attempt.stdout" && break
  sleep 0.05
done
rg -Fqx "$crash_id|RUNNING|0" "$evidence/crash-running-$attempt.stdout" || exit 1
stop_server restart KILL 137
capture release-crashed-connection "$database -Atc \"SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='go39live' AND pid<>pg_backend_pid() AND state='active' AND query LIKE '%UPDATE go_tasks SET%'\"" || exit 1
start_server recovered-process
poll_status crash-recovered "$crash_id" FAILED || exit 1
capture crash-sql "$database -Atc \"SELECT id,status,words,failure_reason FROM go_tasks WHERE id='$crash_id'\"" || exit 1
rg -Fqx "$crash_id|FAILED|0|process exited before worker completion" "$evidence/crash-sql.stdout" || exit 1
capture lost-sql "$database -Atc \"SELECT count(*) FROM go_tasks WHERE input_text='db lost'\"" || exit 1
test "$(cat "$evidence/lost-sql.stdout")" = 0 || exit 1
capture drop-finish-trigger "$database -c 'DROP TRIGGER delay_finish ON go_tasks; DROP FUNCTION delay_task_finish()'" || exit 1
stop_server recovered-process TERM 0
capture recovered-ports-released "python3 -c 'import socket,sys; [ (lambda address, sock: (sock.bind((\"127.0.0.1\",int(address.rsplit(\":\",1)[1]))),sock.close()))(address,socket.socket()) for address in sys.argv[1:] ]; print(\"ports released\")' '$app' '$(sed -n 's/^.* admin=//p' "$evidence/recovered-process.addresses")'" || exit 1
trap - EXIT
