#!/usr/bin/env bash
set -u
evidence=$1
mkdir -p "$evidence"
capture() {
  local name=$1 command=$2 exit_code
  printf '%s\n' "$command" > "$evidence/$name.command"
  bash -c "$command" > "$evidence/$name.stdout" 2> "$evidence/$name.stderr"
  exit_code=$?
  printf '%s\n' "$exit_code" > "$evidence/$name.exit"
  printf '%s exit=%s\n' "$name" "$exit_code"
  return "$exit_code"
}
capture dependency 'go list -m -json google.golang.org/grpc' || exit 1
rg -q '"Version": "v1.67.1"' "$evidence/dependency.stdout" || exit 1
capture dependency-graph 'go list -m all' || exit 1
capture rpc-cases 'go test -count=10 -v -run "^TestRPC" .' || exit 1
rg -q -- '--- PASS: TestRPCSubmissionCancelStreamAndBusinessExit' "$evidence/rpc-cases.stdout" || exit 1
rg -q -- '--- PASS: TestRPCWatchStreamsTerminalAndMissingTask' "$evidence/rpc-cases.stdout" || exit 1
if rg -q -- '--- SKIP: TestRPCSubmissionCancelStreamAndBusinessExit' "$evidence/rpc-cases.stdout"; then exit 1; fi
