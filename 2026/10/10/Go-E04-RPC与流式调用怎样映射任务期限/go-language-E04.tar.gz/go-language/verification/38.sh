#!/usr/bin/env bash
set -u
binary=$1 evidence=$2
mkdir -p "$evidence"
capture() {
  local name=$1 command=$2 exit_code
  printf '%s\n' "$command" > "$evidence/$name.command"
  bash -c "$command" > "$evidence/$name.stdout" 2> "$evidence/$name.stderr"
  exit_code=$?
  printf '%s\n' "$exit_code" > "$evidence/$name.exit"
  printf '%s exit=%s\n' "$name" "$exit_code"
  return "$exit_code"
}
capture build-version "go version -m '$binary'" || exit 1
capture invalid-admin "'$binary' serve --admin 0.0.0.0:0"
test "$(cat "$evidence/invalid-admin.exit")" = 2 || exit 1
capture invalid-workers "'$binary' serve --workers 0"
test "$(cat "$evidence/invalid-workers.exit")" = 2 || exit 1
serveArgs=(serve --listen 127.0.0.1:0 --admin 127.0.0.1:0 --workers 1 --queue-capacity 2 --max-words 3)
if [[ -n ${GO_LANGUAGE_SERVE_DSN:-} ]]; then
  serveArgs+=(--sql-dsn "$GO_LANGUAGE_SERVE_DSN")
fi
printf '%q ' "$binary" "${serveArgs[@]}" > "$evidence/server.command"
printf '\n' >> "$evidence/server.command"
"$binary" "${serveArgs[@]}" > "$evidence/server.stdout" 2> "$evidence/server.stderr" &
server_pid=$!
trap 'kill -TERM "$server_pid" 2>/dev/null || :; wait "$server_pid" 2>/dev/null || :' EXIT
ready=
for attempt in {1..40}; do
  if rg -q '^http=127\.0\.0\.1:[0-9]+ admin=127\.0\.0\.1:[0-9]+$' "$evidence/server.stdout"; then
    ready=$(rg '^http=' "$evidence/server.stdout" | head -1)
    break
  fi
  if ! kill -0 "$server_pid" 2>/dev/null; then
    echo 'server exited before ready' >&2
    exit 1
  fi
  sleep 0.1
done
test -n "$ready" || exit 1
app=${ready#http=}
app=${app%% admin=*}
admin=${ready##*admin=}
printf 'http=%s admin=%s\n' "$app" "$admin" > "$evidence/addresses.txt"
capture app-debug "curl --silent --show-error --output '$evidence/app-debug.body' --write-out 'HTTP_STATUS=%{http_code}\\n' 'http://$app/debug/health'" || exit 1
rg -q 'HTTP_STATUS=404' "$evidence/app-debug.stdout" || exit 1
capture admin-health "curl --silent --show-error --output '$evidence/admin-health.body' --write-out 'HTTP_STATUS=%{http_code}\\n' 'http://$admin/debug/health'" || exit 1
rg -q 'HTTP_STATUS=200' "$evidence/admin-health.stdout" || exit 1
capture admin-heap "curl --silent --show-error --output '$evidence/admin-heap.body' --write-out 'HTTP_STATUS=%{http_code}\\n' 'http://$admin/debug/pprof/heap'" || exit 1
rg -q 'HTTP_STATUS=200' "$evidence/admin-heap.stdout" || exit 1
capture admin-task "curl --silent --show-error --output '$evidence/admin-task.body' --write-out 'HTTP_STATUS=%{http_code}\\n' -H 'Content-Type: application/json' -d '{\"text\":\"Go one\"}' 'http://$admin/tasks'" || exit 1
rg -q 'HTTP_STATUS=404' "$evidence/admin-task.stdout" || exit 1
capture post "curl --silent --show-error --output '$evidence/post.body' --write-out 'HTTP_STATUS=%{http_code}\\n' -H 'Content-Type: application/json' -d '{\"text\":\"Go one\"}' 'http://$app/tasks'" || exit 1
rg -q 'HTTP_STATUS=202' "$evidence/post.stdout" || exit 1
id=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["id"])' "$evidence/post.body")
encoded=$(python3 -c 'import sys; from urllib.parse import quote; print(quote(sys.argv[1],safe=""))' "$id")
found=
for attempt in {1..20}; do
  capture "get-$attempt" "curl --silent --show-error --output '$evidence/get-$attempt.body' --write-out 'HTTP_STATUS=%{http_code}\\n' 'http://$app/tasks/$encoded'" || exit 1
  if rg -q '"status":"SUCCEEDED"' "$evidence/get-$attempt.body"; then
    found=$attempt
    break
  fi
  sleep 0.1
done
test -n "$found" || exit 1
printf '%s SUCCEEDED in poll %s\n' "$id" "$found" > "$evidence/terminal.txt"
capture signal "kill -TERM $server_pid" || exit 1
printf 'wait %s\n' "$server_pid" > "$evidence/server-wait.command"
wait "$server_pid" > "$evidence/server-wait.stdout" 2> "$evidence/server-wait.stderr"
exit_code=$?
printf '%s\n' "$exit_code" > "$evidence/server-wait.exit"
test "$exit_code" = 0 || exit 1
trap - EXIT
capture ports-released "python3 -c 'import socket,sys; [ (lambda s,a: (s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1),s.bind((\"127.0.0.1\",int(a.rsplit(\":\",1)[1]))),s.close()))(socket.socket(),address) for address in sys.argv[1:] ]; print(\"ports released\")' '$app' '$admin'" || exit 1
