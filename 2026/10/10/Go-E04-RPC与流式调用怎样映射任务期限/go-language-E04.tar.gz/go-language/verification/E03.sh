#!/usr/bin/env bash
set -u
evidence=$1
mkdir -p "$evidence"
capture() {
  local name=$1 command=$2 exit_code
  printf '%s\n' "$command" > "$evidence/$name.command"
  bash -c "$command" > "$evidence/$name.stdout" 2> "$evidence/$name.stderr"
  exit_code=$?
  printf '%s\n' "$exit_code" > "$evidence/$name.exit"
  printf '%s exit=%s\n' "$name" "$exit_code"
  return "$exit_code"
}
capture compiler "go env CGO_ENABLED CC && gcc --version" || exit 1
capture build-native "go test -c -o '$evidence/native.test' ./native" || exit 1
capture execute-native "'$evidence/native.test' -test.v -test.count=10 -test.run '^TestLocalNativeFunctionAndInvalidInputs$'" || exit 1
capture service 'go test -count=10 -v -run "^TestNativeTaskUsesExistingHTTPAndTerminalRules$" .' || exit 1
capture disabled 'CGO_ENABLED=0 go test ./native'
test "$(cat "$evidence/disabled.exit")" != 0 || exit 1
rg -q 'undefined: SumASCII|build constraints exclude all Go files' "$evidence/disabled.stderr" || exit 1
