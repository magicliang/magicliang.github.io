CREATE OR REPLACE FUNCTION delay_task_claim() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status = 'RUNNING' THEN
    PERFORM pg_sleep(6);
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER delay_claim BEFORE UPDATE ON go_tasks FOR EACH ROW EXECUTE FUNCTION delay_task_claim();
