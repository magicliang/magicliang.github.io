#!/usr/bin/env bash
set -u
evidence=$1
mkdir -p "$evidence"
capture() {
  local name=$1 command=$2 exit_code
  printf '%s\n' "$command" > "$evidence/$name.command"
  bash -c "$command" > "$evidence/$name.stdout" 2> "$evidence/$name.stderr"
  exit_code=$?
  printf '%s\n' "$exit_code" > "$evidence/$name.exit"
  printf '%s exit=%s\n' "$name" "$exit_code"
  return "$exit_code"
}
capture generate "go run ./cmd/generate-taskvalidation -input taskvalidation/schema.go -output '$evidence/fresh-generated.go.txt'" || exit 1
capture compare "cmp taskvalidation/generated.go '$evidence/fresh-generated.go.txt' && sha256sum taskvalidation/generated.go '$evidence/fresh-generated.go.txt'" || exit 1
capture wrong-schema "go run ./cmd/generate-taskvalidation -input verification/E02-bad-schema.go.txt -output '$evidence/wrong-output.go.txt'"
test "$(cat "$evidence/wrong-schema.exit")" = 1 && test ! -e "$evidence/wrong-output.go.txt" || exit 1
rg -q 'unsupported check tag' "$evidence/wrong-schema.stderr" || exit 1
capture correct-and-runtime-wrong 'go test -count=10 -v -run "^TestGeneratedAndReflectValidateTaskFields$" ./taskvalidation' || exit 1
capture bench 'go test -run "^$" -bench "^BenchmarkTaskFieldValidation$" -benchmem -benchtime=200ms -count=5 ./taskvalidation' || exit 1
