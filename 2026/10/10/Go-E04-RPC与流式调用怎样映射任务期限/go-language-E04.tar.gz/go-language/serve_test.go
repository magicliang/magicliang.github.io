package main

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestServerRejectsBadConfigurationBeforeListening(t *testing.T) {
	for _, args := range [][]string{
		{"--admin", "0.0.0.0:0"},
		{"--admin", "127.0.0.1"},
		{"--listen", "0.0.0.0:0"},
		{"--workers", "0"},
		{"--queue-capacity", "129"},
		{"--max-words", "0"},
	} {
		var output, errors bytes.Buffer
		if status := runTaskServer(args, &output, &errors); status != 2 || output.Len() != 0 || errors.Len() == 0 {
			t.Fatalf("args=%q status=%d output=%q errors=%q", args, status, output.String(), errors.String())
		}
	}
}

func TestDiagnosticHandlerIsNotTaskHandler(t *testing.T) {
	handler := diagnosticHandler()
	for _, path := range []string{"/debug/health", "/debug/pprof/heap", "/debug/pprof/goroutine"} {
		response := httptest.NewRecorder()
		handler.ServeHTTP(response, httptest.NewRequest(http.MethodGet, path, nil))
		if response.Code != http.StatusOK {
			t.Fatalf("admin path=%s status=%d", path, response.Code)
		}
	}
	response := httptest.NewRecorder()
	handler.ServeHTTP(response, httptest.NewRequest(http.MethodPost, "/tasks", strings.NewReader(`{"text":"Go"}`)))
	if response.Code != http.StatusNotFound {
		t.Fatalf("admin task POST status=%d", response.Code)
	}
}
