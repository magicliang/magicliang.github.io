package main

import (
	"bytes"
	"context"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"runtime"
	"runtime/pprof"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"example.com/go-language-task/stats"
)

func TestWorkerWaitKinds(t *testing.T) {
	for _, kind := range []string{"cpu", "channel", "network"} {
		t.Run(kind, func(t *testing.T) {
			started := make(chan struct{})
			release := make(chan struct{})
			var releaseOnce sync.Once
			var loopCount atomic.Uint64
			var listener net.Listener
			var remote net.Conn
			var connected chan net.Conn
			if kind == "network" {
				var err error
				listener, err = net.Listen("tcp", "127.0.0.1:0")
				if err != nil {
					t.Fatal(err)
				}
				connected = make(chan net.Conn, 1)
				go func() {
					connection, acceptError := listener.Accept()
					if acceptError == nil {
						connected <- connection
					}
				}()
			}
			service := newTaskHTTPServiceUsing(context.Background(), 1, 1, 3, func(ctx context.Context, text string, _ int) (stats.Counts, error) {
				switch kind {
				case "cpu":
					close(started)
					for {
						select {
						case <-release:
							return stats.AnalyzeContext(ctx, text)
						default:
							loopCount.Add(1)
						}
					}
				case "channel":
					close(started)
					<-release
				case "network":
					connection, err := net.Dial("tcp", listener.Addr().String())
					if err != nil {
						return stats.Counts{}, err
					}
					defer connection.Close()
					if err := connection.SetReadDeadline(time.Now().Add(5 * time.Second)); err != nil {
						return stats.Counts{}, err
					}
					close(started)
					var message [1]byte
					if _, err := io.ReadFull(connection, message[:]); err != nil {
						return stats.Counts{}, err
					}
				}
				return stats.AnalyzeContext(ctx, text)
			})
			t.Cleanup(func() {
				releaseOnce.Do(func() { close(release) })
				if remote != nil {
					remote.Close()
				}
				if listener != nil {
					listener.Close()
				}
				service.Close()
			})
			invalid := httptest.NewRequest(http.MethodPost, "/tasks", strings.NewReader(`{"text":""}`))
			invalid.Header.Set("Content-Type", "application/json")
			invalidResponse := httptest.NewRecorder()
			service.Handler().ServeHTTP(invalidResponse, invalid)
			if _, exists := service.store.Lookup("task[0]"); invalidResponse.Code != http.StatusBadRequest || exists {
				t.Fatalf("invalid POST status=%d allocatedID=%t", invalidResponse.Code, exists)
			}
			request := httptest.NewRequest(http.MethodPost, "/tasks", strings.NewReader(`{"text":"Go one"}`))
			request.Header.Set("Content-Type", "application/json")
			response := httptest.NewRecorder()
			service.Handler().ServeHTTP(response, request)
			if response.Code != http.StatusAccepted {
				t.Fatalf("POST status=%d body=%q", response.Code, response.Body.String())
			}
			select {
			case <-started:
			case <-time.After(5 * time.Second):
				t.Fatal("worker did not reach checkpoint")
			}
			if kind == "network" {
				select {
				case remote = <-connected:
				case <-time.After(5 * time.Second):
					t.Fatal("loopback server did not accept connection")
				}
			}
			var profile bytes.Buffer
			want := map[string]string{"cpu": "[runnable]", "channel": "[chan receive]", "network": "[IO wait]"}[kind]
			observed := false
			for deadline := time.Now().Add(2 * time.Second); time.Now().Before(deadline); {
				profile.Reset()
				if err := pprof.Lookup("goroutine").WriteTo(&profile, 2); err != nil {
					t.Fatal(err)
				}
				for _, stack := range strings.Split(profile.String(), "goroutine ") {
					if strings.Contains(stack, "TestWorkerWaitKinds.func1.2") && (strings.Contains(stack, want) || kind == "cpu" && strings.Contains(stack, "[running]")) {
						observed = true
						break
					}
				}
				if observed {
					break
				}
				runtime.Gosched()
			}
			if !observed {
				t.Fatalf("worker never reached %s in goroutine profile:\n%s", want, profile.String())
			}
			before, exists := service.store.Lookup("task[0]")
			if !exists || before.Status != StatusRunning {
				t.Fatalf("before release exists=%t record=%+v", exists, before)
			}
			t.Logf("kind=%s before release=RUNNING cpuIterations=%d\n%s", kind, loopCount.Load(), profile.String())
			if kind == "network" {
				if _, err := remote.Write([]byte{1}); err != nil {
					t.Fatal(err)
				}
			} else {
				releaseOnce.Do(func() { close(release) })
			}
			service.Close()
			after, exists := service.store.Lookup("task[0]")
			if !exists || after.Status != StatusSucceeded || after.Words != 2 {
				t.Fatalf("after release exists=%t record=%+v", exists, after)
			}
			t.Logf("kind=%s after worker exit=%s words=%d", kind, after.Status, after.Words)
		})
	}
}
