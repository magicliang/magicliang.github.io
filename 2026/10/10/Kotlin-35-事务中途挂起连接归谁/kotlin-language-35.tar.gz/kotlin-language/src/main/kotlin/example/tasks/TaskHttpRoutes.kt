package example.tasks

import io.ktor.http.HttpStatusCode
import io.ktor.server.application.Application
import io.ktor.server.application.install
import io.ktor.server.request.receive
import io.ktor.server.response.respond
import io.ktor.server.response.respondText
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import io.ktor.server.routing.routing
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation
import io.ktor.serialization.kotlinx.json.json
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlin.coroutines.coroutineContext

@Serializable
data class TaskHttpReply(val id: String, val state: String, val accepted: Boolean)

class TaskHttpRegistry(
    private val execute: suspend (TaskDraft) -> String = { "completed:${it.id.value}" },
    dispatcher: CoroutineDispatcher = Dispatchers.Default,
) {
    private class Entry(val draft: TaskDraft) {
        @Volatile var state: TaskState = TaskState.Queued
        lateinit var job: Job
    }

    private val owner = SupervisorJob()
    private val scope = CoroutineScope(owner + dispatcher)
    private val lock = Any()
    private val entries = mutableMapOf<String, Entry>()

    fun submit(draft: TaskDraft): SubmissionDecision = synchronized(lock) {
        check(owner.isActive) { "Task service has stopped" }
        val existing = entries[draft.id.value]
        if (existing != null) {
            return@synchronized if (existing.draft == draft) SubmissionDecision.Reused
            else SubmissionDecision.Rejected("Task ID already belongs to another draft")
        }
        val entry = Entry(draft)
        val job = scope.launch(start = CoroutineStart.LAZY) {
            entry.state = TaskState.Running
            try {
                val result = execute(draft)
                coroutineContext.ensureActive()
                entry.state = TaskState.Succeeded(result)
            } catch (cancelled: CancellationException) {
                entry.state = TaskState.Cancelled
                throw cancelled
            } catch (failure: Exception) {
                entry.state = TaskState.Failed(failure.message ?: "task failed")
            }
        }
        entry.job = job
        job.invokeOnCompletion { cause ->
            if (cause is CancellationException) entry.state = TaskState.Cancelled
        }
        entries[draft.id.value] = entry
        job.start()
        SubmissionDecision.Accepted
    }

    fun status(id: String): TaskState? = synchronized(lock) { entries[id]?.state }

    suspend fun cancel(id: String): TaskState? {
        val entry = synchronized(lock) { entries[id] } ?: return null
        entry.job.cancelAndJoin()
        return entry.state
    }

    suspend fun await(id: String) {
        val entry = synchronized(lock) { entries[id] } ?: error("Unknown task ID")
        entry.job.join()
    }

    suspend fun stop() {
        owner.cancelAndJoin()
    }
}

private fun reply(id: String, state: TaskState, accepted: Boolean) = TaskHttpReply(
    id,
    when (state) {
        TaskState.Queued -> "Queued"
        TaskState.Running -> "Running"
        is TaskState.Succeeded -> "Succeeded"
        is TaskState.Failed -> "Failed"
        TaskState.Cancelled -> "Cancelled"
    },
    accepted,
)

fun Application.taskHttpRoutes(registry: TaskHttpRegistry) {
    install(ContentNegotiation) { json() }
    routing {
        post("/tasks") {
            val draft = try {
                call.receive<TaskRequestDto>().toDraft()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (invalid: Exception) {
                call.respondText("Invalid task request", status = HttpStatusCode.BadRequest)
                return@post
            }
            when (registry.submit(draft)) {
                SubmissionDecision.Accepted -> call.respond(HttpStatusCode.Accepted, reply(draft.id.value, TaskState.Queued, true))
                SubmissionDecision.Reused -> call.respond(HttpStatusCode.OK, reply(draft.id.value, registry.status(draft.id.value)!!, false))
                is SubmissionDecision.Rejected -> call.respondText("Task ID already exists", status = HttpStatusCode.Conflict)
            }
        }
        get("/tasks/{id}") {
            val id = call.parameters["id"] ?: return@get call.respond(HttpStatusCode.BadRequest)
            val state = registry.status(id) ?: return@get call.respond(HttpStatusCode.NotFound)
            call.respond(reply(id, state, false))
        }
        post("/tasks/{id}/cancel") {
            val id = call.parameters["id"] ?: return@post call.respond(HttpStatusCode.BadRequest)
            val state = registry.cancel(id) ?: return@post call.respond(HttpStatusCode.NotFound)
            call.respond(reply(id, state, false))
        }
    }
}
