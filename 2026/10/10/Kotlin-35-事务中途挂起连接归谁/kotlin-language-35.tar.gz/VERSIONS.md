# Kotlin 累计实验版本账本

00 基线，核验日期：2026-10-07（UTC）。仅以下组合已在当前主机 `clean test`、合法/非法 CLI 和字节码检查中实际运行。后续依赖在**引入时**另列源码 SHA；不预填尚未运行的工具版本。

| 对象 | 冻结值与依据 | 已确认范围 |
|---|---|---|
| Kotlin Gradle Plugin / 编译器 / stdlib | `2.2.21`，`build.gradle.kts` 和 `runtimeClasspath`；上游源码 tag `v2.2.21` → `2146684dcba708e5a304758b41a9e4ec9c7eff71`（`git ls-remote`） | 实际编译、测试、运行；未追踪源码内部实现 |
| languageVersion / apiVersion / jvmTarget | `2.2` / `2.2` / `21`，显式 compilerOptions；`javap -verbose` 显示 class major `65` | 指定输出目标并验证生成物；不等同运行 JVM 的全部能力 |
| Gradle Wrapper | `8.14`，revision 与上游 tag `v8.14.0` SHA 均为 `34c560e3be961658a6fbcd7170ec2443a228b109`（`git ls-remote`） | `./gradlew --version` 为 8.14；自带 Kotlin 为 `2.0.21`，不是本程序编译器 |
| Gradle 分发包 | 官方 SHA-256 `61ad310d3c7d3e5da131b76bbf22b5a4c0786e9d892dae8c1658d4b484de3caa`；镜像下载后本地 `sha256sum -c` 通过；Wrapper properties 固定同值 | 当前网络无法解析官方 GitHub 重定向；使用华为云镜像作为下载地址，仅以官方 SHA 校验其字节 |
| Wrapper JAR | 本次 Gradle 8.14 `wrapper` 任务生成，SHA-256 `7d3a4ac4de1c32b59bc6a4eb8ecb8e612ccd0cf1ae1e99f66902da64df296172` | 本地校验指纹，尚未与公开 wrapper JAR 清单独立对照 |
| JDK / toolchain | Ubuntu OpenJDK `21.0.12.1+1-1-24.04.4-Ubuntu`，`/usr/lib/jvm/java-21-openjdk-amd64`，x86_64；toolchain 21 | Gradle launcher/daemon 与执行进程使用 JDK 21；`jvmTarget` 不是“当前 JDK 版本” |
| 测试 | `kotlin("test-junit5")` 随插件 `2.2.21`；JUnit Platform Launcher `1.12.2` | 已跑 JUnit 行为测试；运行时完整传递版本可查 `testRuntimeClasspath` |

21 模块拆分（2026-10-09）：`:domain` 与根工程都使用同一 Kotlin Gradle Plugin 2.2.21、显式 stdlib 2.2.21、language/API 2.2 与 jvmTarget 21；原始 `verification/21/environment.txt` 中的 Gradle **内嵌** Kotlin 为 2.0.21，两模块 runtimeClasspath 与 class major 65 的原始输出在同目录。仅调整工程布局与项目依赖，没有引入新的插件版本、运行库或源码 SHA；其余版本承接上表。

24 引入协程（2026-10-09 UTC）：`kotlinx-coroutines-core:1.10.2`、`kotlinx-coroutines-test:1.10.2`；JVM 制品 `core-jvm` / `test-jvm` 的实际解析树在 `verification/24/dependencies.txt`。上游 `1.10.2` tag SHA 是 `5f8900478a8e20c073145b1608fbc71fe3d7378b`（`git ls-remote`）；tag 是来源锚点，未证明已阅读内部调度器实现。实际解析 stdlib 为 `2.2.21`，不是协程依赖树中 POM 请求的 `2.1.0`。Kotlin 插件/编译器 2.2.21、Wrapper 8.14、JDK 21、language/API 2.2、jvmTarget 21 不变；在线与离线 clean test、真实单线程与虚拟调度测试各有原始日志。

33 引入 JSON DTO（2026-10-10 UTC）：`kotlin("plugin.serialization") version "2.2.21"`，与根工程 Kotlin/JVM 插件相同；运行库 `kotlinx-serialization-json:1.9.0`（JVM 制品及解析树见 `verification/33/dependencies.txt`，目标测试实际编译通过；完整离线 clean test 与解包另见 33 验证日志）。上游仓库 `v1.9.0` tag SHA `16306f4c97e21e4d134bf1bb95fc20a61927f6b0`（`git ls-remote`），CHANGELOG 说明基于 Kotlin 2.2.0，本机搭配 2.2.21 的具体行为由实际构建证明，不推断所有版本兼容。前述 Kotlin/Gradle/JDK/coroutines 基线均保持不变；未证明序列化插件内部生成逻辑或网络服务契约。

34 引入 Ktor（2026-10-10 UTC）：server core、Netty、content-negotiation、serialization-kotlinx-json 和 test-host（JVM 解析）均为 `3.3.1`；tag `3.3.1` 的 `git ls-remote` SHA 为 `49fb2bfb657cc74af6abadae9e11c765234dafa4`。实际运行应用内 `testApplication` 与 JDK 21 HttpURLConnection → Netty 回环端口分账，运行时/测试解析见 `verification/34/dependencies.txt` 与 `test_dependencies.txt`。声明的 `junit-platform-launcher:1.12.2` 在测试运行时被传递约束提升解析为 `1.13.4`（`test_dependencies.txt`），不是仍执行 1.12.2；Kotlin 2.2.21、serialization 1.9.0、coroutines 1.10.2、Gradle 8.14 与 JDK 21 不变。Ktor 服务测试不构成 HTTP 断线中途重试、负载均衡、数据库或部署验证。

35 引入 PostgreSQL（2026-10-10 UTC）：专用临时 PostgreSQL `16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)` 数据目录，用宿主 `/usr/lib/postgresql/16/bin/{initdb,pg_ctl,postgres}`，不使用系统默认/Go 会话数据库；JDBC `org.postgresql:postgresql:42.7.7` 运行依赖解析见 `verification/35/dependencies.txt`。tag `REL42.7.7` annotated object SHA `7d5a13de18cc77bdbc76a88de36fc61c00799022`，剥离后的源码 commit `9217ed16cb2918ab1b6b9258ae97e6ede244d8a0`（`git ls-remote`）。宿主 OS、Gradle/JDK/Kotlin/协程/Ktor 版本承接上表，单测运行会启动/停止自有集群；实际事务与 Statement.cancel 结果以 `verification/35/TaskJdbcStoreTest.txt` 为准。JDBC 同步取消并不推导任意驱动/外部进程的协程取消语义。

参考：[Kotlin Gradle 兼容表](https://kotlinlang.org/docs/gradle-configure-project.html)（2026-10-07 查阅，`2.2.20–2.2.21` 与 Gradle `7.6.3–8.14`）、[Kotlin 命令行编译](https://kotlinlang.org/docs/command-line.html)、[Gradle Wrapper 8.14 文档](https://docs.gradle.org/8.14/userguide/gradle_wrapper.html)、[Gradle 8.14 官方 SHA 文件](https://services.gradle.org/distributions/gradle-8.14-bin.zip.sha256)。滚动文档只用于交叉校验选型，成功构建与运行见原始证据。JSON DTO 行为仅限 33 的测试；Ktor/数据库 **NOT_RUN**；真实 HTTP/事务、协程到数据库取消/失败仍 **NOT_RUN**。
