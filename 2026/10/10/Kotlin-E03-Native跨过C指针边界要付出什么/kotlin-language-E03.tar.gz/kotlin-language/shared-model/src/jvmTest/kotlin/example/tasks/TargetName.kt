package example.tasks

actual fun targetName(): String = "JVM"
