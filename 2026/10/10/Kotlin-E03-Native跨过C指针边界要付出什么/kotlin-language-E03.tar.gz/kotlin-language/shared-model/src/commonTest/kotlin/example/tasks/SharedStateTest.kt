package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

expect fun targetName(): String

class SharedStateTest {
    @Test
    fun stateTransitionsAreSharedAcrossTargets() {
        val running = advanceTask(TaskState.Queued, TaskSignal.Start)
        assertEquals(TaskStage.ACTIVE, taskStage(running))
        assertEquals(TaskState.Succeeded("done"), advanceTask(running, TaskSignal.Success("done")))
        assertEquals(TaskState.Cancelled, advanceTask(TaskState.Queued, TaskSignal.Cancel))
        assertFailsWith<IllegalStateException> { advanceTask(TaskState.Queued, TaskSignal.Success("early")) }
        println("TARGET=${targetName()} running=$running cancelled=${TaskState.Cancelled}")
    }
}
