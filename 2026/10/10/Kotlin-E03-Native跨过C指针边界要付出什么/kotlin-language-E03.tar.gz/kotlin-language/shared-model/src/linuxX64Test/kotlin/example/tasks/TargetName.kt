package example.tasks

actual fun targetName(): String = "Linux/Native"
