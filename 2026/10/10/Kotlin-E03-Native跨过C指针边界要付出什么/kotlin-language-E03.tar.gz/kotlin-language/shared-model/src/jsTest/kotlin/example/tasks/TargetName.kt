package example.tasks

actual fun targetName(): String = "JS/Node"
