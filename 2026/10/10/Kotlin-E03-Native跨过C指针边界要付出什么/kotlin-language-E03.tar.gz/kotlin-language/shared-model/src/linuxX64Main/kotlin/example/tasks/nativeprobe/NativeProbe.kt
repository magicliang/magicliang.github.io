package example.tasks.nativeprobe

import example.tasks.TaskSignal
import example.tasks.TaskState
import example.tasks.advanceTask
import example.tasks.nativebridge.task_bytes_checksum
import example.tasks.nativebridge.task_utf8_bytes
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.reinterpret
import kotlinx.cinterop.usePinned
import kotlin.native.concurrent.ObsoleteWorkersApi
import kotlin.native.concurrent.TransferMode
import kotlin.native.concurrent.Worker

@OptIn(ExperimentalForeignApi::class, ObsoleteWorkersApi::class)
fun main() {
    val utf8Bytes = task_utf8_bytes("hé")
    check(utf8Bytes == 3)

    val bytes = byteArrayOf(1, 2, 3, 4)
    val checksum = bytes.usePinned { pinned ->
        task_bytes_checksum(pinned.addressOf(0).reinterpret(), bytes.size)
    }
    val invalidLength = bytes.usePinned { pinned ->
        task_bytes_checksum(pinned.addressOf(0).reinterpret(), -1)
    }
    check(checksum == 10 && invalidLength == -1)

    val worker = Worker.start()
    val running = try {
        worker.execute(TransferMode.SAFE, { TaskState.Queued }, { state ->
            advanceTask(state, TaskSignal.Start)
        }).result
    } finally {
        worker.requestTermination().result
    }
    check(running == TaskState.Running)
    println("NATIVE utf8Bytes=$utf8Bytes checksum=$checksum invalid=$invalidLength worker=$running")
}
