#!/usr/bin/env bash
set -euo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$project"
gcc -std=c11 -Wall -Wextra -Werror -c native/task_native.c -o native/task_native.o
ar rcs native/libtask_native.a native/task_native.o
../gradlew -p "$project" --offline --no-daemon --max-workers=2 --console=plain linuxX64Test linkDebugExecutableLinuxX64
"$project/build/bin/linuxX64/debugExecutable/kotlin-task-shared-model.kexe"
