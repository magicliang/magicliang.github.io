plugins {
    kotlin("multiplatform") version "2.2.21"
}

repositories {
    mavenCentral()
}

kotlin {
    jvm()
    js(IR) {
        nodejs()
    }
    linuxX64 {
        compilations.getByName("main") {
            cinterops.create("task_native") {
                defFile(file("src/nativeInterop/cinterop/task_native.def"))
                includeDirs(file("native"))
            }
        }
        binaries.executable {
            entryPoint = "example.tasks.nativeprobe.main"
        }
    }

    sourceSets {
        commonTest.dependencies {
            implementation(kotlin("test"))
        }
    }
}
