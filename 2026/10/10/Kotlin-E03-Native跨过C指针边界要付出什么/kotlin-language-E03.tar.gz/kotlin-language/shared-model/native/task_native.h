#ifndef TASK_NATIVE_H
#define TASK_NATIVE_H

#include <stdint.h>

int32_t task_utf8_bytes(const char *text);
int32_t task_bytes_checksum(const uint8_t *bytes, int32_t length);

#endif
