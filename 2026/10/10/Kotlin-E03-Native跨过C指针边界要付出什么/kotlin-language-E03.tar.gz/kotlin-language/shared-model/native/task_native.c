#include "task_native.h"

int32_t task_utf8_bytes(const char *text) {
    int32_t count = 0;
    while (text[count] != 0) {
        count++;
    }
    return count;
}

int32_t task_bytes_checksum(const uint8_t *bytes, int32_t length) {
    if (length < 0) {
        return -1;
    }
    int32_t result = 0;
    for (int32_t index = 0; index < length; index++) {
        result += bytes[index];
    }
    return result;
}
