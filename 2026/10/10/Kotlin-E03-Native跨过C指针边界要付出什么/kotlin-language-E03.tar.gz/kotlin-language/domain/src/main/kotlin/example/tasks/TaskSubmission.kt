package example.tasks

fun acceptSubmission(store: TaskStore, id: String, text: String): Boolean {
    val existing = store.find(id)
    if (existing != null) {
        require(existing == text) { "Task ID already belongs to another text" }
        return false
    }
    return store.putIfAbsent(id, text)
}
