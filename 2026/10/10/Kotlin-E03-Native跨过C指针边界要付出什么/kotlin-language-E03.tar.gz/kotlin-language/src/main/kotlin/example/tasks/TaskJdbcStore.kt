package example.tasks

import java.sql.DriverManager
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext

data class StoredTaskSnapshot(val payload: String, val state: String)

class TaskJdbcStore(private val url: String, private val dispatcher: CoroutineDispatcher) {
    suspend fun insert(draft: TaskDraft, afterInsert: () -> Unit = {}): String = withContext(dispatcher) {
        DriverManager.getConnection(url).use { connection ->
            connection.autoCommit = false
            try {
                connection.prepareStatement("INSERT INTO task_snapshot (id, payload, state) VALUES (?, ?, ?)").use { statement ->
                    statement.setString(1, draft.id.value)
                    statement.setString(2, draft.text)
                    statement.setString(3, "Queued")
                    statement.executeUpdate()
                }
                afterInsert()
                connection.commit()
                Thread.currentThread().name
            } catch (failure: Exception) {
                connection.rollback()
                throw failure
            }
        }
    }

    suspend fun read(id: TaskId): String? = readSnapshot(id)?.payload

    suspend fun readSnapshot(id: TaskId): StoredTaskSnapshot? = withContext(dispatcher) {
        DriverManager.getConnection(url).use { connection ->
            connection.prepareStatement("SELECT payload, state FROM task_snapshot WHERE id = ?").use { statement ->
                statement.setString(1, id.value)
                statement.executeQuery().use { result ->
                    if (result.next()) StoredTaskSnapshot(result.getString(1), result.getString(2)) else null
                }
            }
        }
    }

    suspend fun start(id: TaskId): Boolean = changeState(id, "Running", "Queued")

    suspend fun finish(id: TaskId, state: String): Boolean = changeState(id, state, "Running")

    suspend fun cancel(id: TaskId): Boolean = withContext(dispatcher) {
        DriverManager.getConnection(url).use { connection ->
            connection.prepareStatement("UPDATE task_snapshot SET state = 'Cancelled' WHERE id = ? AND state IN ('Queued', 'Running')").use { statement ->
                statement.setString(1, id.value)
                statement.executeUpdate() == 1
            }
        }
    }

    private suspend fun changeState(id: TaskId, state: String, current: String): Boolean = withContext(dispatcher) {
        DriverManager.getConnection(url).use { connection ->
            connection.prepareStatement("UPDATE task_snapshot SET state = ? WHERE id = ? AND state = ?").use { statement ->
                statement.setString(1, state)
                statement.setString(2, id.value)
                statement.setString(3, current)
                statement.executeUpdate() == 1
            }
        }
    }
}
