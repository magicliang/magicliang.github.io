package example.tasks

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

fun taskProgressFlow(id: TaskId, work: suspend () -> String): Flow<TaskState> = flow {
    emit(TaskState.Queued)
    emit(TaskState.Running)
    emit(TaskState.Succeeded(work()))
}
