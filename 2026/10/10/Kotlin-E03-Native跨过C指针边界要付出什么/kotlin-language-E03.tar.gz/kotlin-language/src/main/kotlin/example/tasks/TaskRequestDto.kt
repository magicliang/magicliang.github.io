package example.tasks

import kotlinx.serialization.Serializable

@Serializable
data class TaskRequestDto(
    val id: String,
    val text: String,
    val labels: List<String> = emptyList(),
    val note: String? = null,
)

fun TaskRequestDto.toDraft(): TaskDraft = makeTaskDraft(TaskId(id), text, labels)

@Serializable
data class TaskRequestV2Dto(
    val id: String,
    val text: String,
    val labels: List<String> = emptyList(),
    val note: String? = null,
    val priority: Int = 0,
)
