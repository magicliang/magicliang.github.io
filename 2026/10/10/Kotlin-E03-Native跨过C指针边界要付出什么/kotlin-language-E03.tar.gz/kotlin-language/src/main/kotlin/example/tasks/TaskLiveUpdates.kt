package example.tasks

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

class TaskLiveUpdates {
    private val currentState = MutableStateFlow<TaskState>(TaskState.Queued)
    private val notifications = MutableSharedFlow<String>()

    val state: StateFlow<TaskState> = currentState
    val events: SharedFlow<String> = notifications

    fun update(state: TaskState) {
        currentState.value = state
    }

    suspend fun notify(event: String) {
        notifications.emit(event)
    }
}
