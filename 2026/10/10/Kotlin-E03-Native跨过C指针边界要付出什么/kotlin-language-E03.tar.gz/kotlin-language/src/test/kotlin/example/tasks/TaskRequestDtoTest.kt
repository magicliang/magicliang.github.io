package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject

class TaskRequestDtoTest {
    private val strict = Json { encodeDefaults = true; explicitNulls = true }
    private val compatible = Json { ignoreUnknownKeys = true }

    @Test
    fun missingRequiredFieldFailsWhileOptionalMissingAndExplicitNullDecode() {
        assertFailsWith<SerializationException> {
            strict.decodeFromString<TaskRequestDto>("""{"id":"task-33"}""")
        }
        val missing = """{"id":"task-33","text":"alpha"}"""
        val explicitNull = """{"id":"task-33","text":"alpha","note":null}"""
        val decodedMissing = strict.decodeFromString<TaskRequestDto>(missing)
        val decodedNull = strict.decodeFromString<TaskRequestDto>(explicitNull)
        assertEquals(decodedMissing, decodedNull)
        assertFalse(strict.parseToJsonElement(missing).jsonObject.containsKey("note"))
        assertTrue(strict.parseToJsonElement(explicitNull).jsonObject.containsKey("note"))
        assertTrue(strict.encodeToString(decodedMissing).contains("\"note\":null"))
        println("JSON required_missing_rejected=true optional_missing_distinct_from_null_in_json=true decoded_equal=true")
    }

    @Test
    fun unknownFieldsAndWrongTypesAreRejectedUnlessExplicitlyAllowed() {
        val newPayload = """{"id":"task-33","text":"alpha","extra":"v2"}"""
        assertFailsWith<SerializationException> { strict.decodeFromString<TaskRequestDto>(newPayload) }
        assertEquals("task-33", compatible.decodeFromString<TaskRequestDto>(newPayload).id)
        assertFailsWith<SerializationException> {
            strict.decodeFromString<TaskRequestDto>("""{"id":33,"text":"alpha"}""")
        }
        assertFailsWith<SerializationException> {
            strict.decodeFromString<TaskRequestDto>("""{"id":null,"text":"alpha"}""")
        }
        println("JSON unknown_strict_rejected=true unknown_compatible_accepted=true wrong_type_and_null_id_rejected=true")
    }

    @Test
    fun syntacticallyValidJsonStillRequiresDomainValidation() {
        val blankId = strict.decodeFromString<TaskRequestDto>("""{"id":" ","text":"alpha"}""")
        val blankText = strict.decodeFromString<TaskRequestDto>("""{"id":"task-33","text":" "}""")
        val blankLabel = strict.decodeFromString<TaskRequestDto>("""{"id":"task-33","text":"alpha","labels":[" "]}""")
        assertFailsWith<IllegalArgumentException> { blankId.toDraft() }
        assertFailsWith<IllegalArgumentException> { blankText.toDraft() }
        assertFailsWith<IllegalArgumentException> { blankLabel.toDraft() }
        val good = strict.decodeFromString<TaskRequestDto>("""{"id":"task-33","text":" alpha ","labels":[" Kotlin "]}""")
        assertEquals(TaskDraft(TaskId("task-33"), "alpha", listOf("Kotlin")), good.toDraft())
        println("JSON decoded_blank_id_text_label_rejected_by_domain=true valid_draft=task-33")
    }

    @Test
    fun versionChangeNeedsExplicitDefaultsOrUnknownKeyPolicy() {
        val oldPayload = """{"id":"task-33","text":"alpha"}"""
        assertEquals(0, strict.decodeFromString<TaskRequestV2Dto>(oldPayload).priority)
        val newPayload = strict.encodeToString(TaskRequestV2Dto("task-33", "alpha", priority = 2))
        assertTrue(newPayload.contains("\"priority\":2"))
        assertFailsWith<SerializationException> { strict.decodeFromString<TaskRequestDto>(newPayload) }
        assertEquals("task-33", compatible.decodeFromString<TaskRequestDto>(newPayload).id)
        println("JSON old_to_v2_default_priority=0 v2_to_old_strict_rejected=true")
    }
}
