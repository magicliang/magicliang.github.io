package example.tasks

import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.http.contentType
import io.ktor.server.testing.testApplication
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.runBlocking

class TaskServerLifecycleTest {
    @Test
    fun explicitRequestIdSurvivesIntoTaskAndClosingRejectsNewSubmissions() = runBlocking {
        val entered = CompletableDeferred<Unit>()
        val trace = CopyOnWriteArrayList<Pair<String, String>>()
        val registry = TaskHttpRegistry(
            execute = { entered.complete(Unit); awaitCancellation() },
            onRun = { requestId, taskId -> trace += requestId to taskId },
        )
        try {
            testApplication {
                application { taskHttpRoutes(registry) }
                val response = client.post("/tasks") {
                    header("X-Request-Id", "req-38")
                    contentType(ContentType.Application.Json)
                    setBody("""{"id":"task-38","text":"wait"}""")
                }
                assertEquals(HttpStatusCode.Accepted, response.status)
                assertEquals("req-38", response.headers["X-Request-Id"])
                entered.await()
                assertEquals(listOf("req-38" to "task-38"), trace.toList())
                registry.stopAccepting()
                val stopped = client.post("/tasks") {
                    contentType(ContentType.Application.Json)
                    setBody("""{"id":"new-38","text":"alpha"}""")
                }
                assertEquals(HttpStatusCode.ServiceUnavailable, stopped.status)
            }
        } finally {
            registry.stop()
        }
        assertEquals(TaskState.Cancelled, registry.status("task-38"))
        assertFailsWith<IllegalStateException> {
            registry.submit(makeTaskDraft(TaskId("late-38"), "alpha", emptyList()))
        }
        assertTrue(registry.snapshot()["task-38"]?.first == "req-38")
        println("LIFECYCLE request_id=req-38 task_id=task-38 rejected_after_stop=true final=Cancelled")
    }
}
