package example.tasks

import kotlinx.coroutines.runBlocking

object TaskCostProbe {
    @JvmStatic
    fun labels(count: Int): List<String> = List(count - 1) { "Later" } + "Queued"

    @JvmStatic
    fun eager(labels: List<String>): List<String> = eagerTaskLabels(labels) {}

    @JvmStatic
    fun lazy(labels: List<String>): List<String> = lazyTaskLabels(labels) {}.toList()

    @JvmStatic
    fun rawIds(labels: List<String>): List<String> = labels.map { it }

    @JvmStatic
    fun boxedIds(labels: List<String>): List<TaskId> = labels.map(::TaskId)

    @JvmStatic
    fun direct(id: String): TaskState =
        advanceTask(advanceTask(TaskState.Queued, TaskSignal.Start), TaskSignal.Success("completed:$id"))

    @JvmStatic
    fun suspended(id: String): TaskState = runBlocking { executeSyntheticTask(TaskId(id)) {} }
}
