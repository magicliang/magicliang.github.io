package example.tasks

import kotlin.coroutines.Continuation
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class SuspendBytecodeShapeTest {
    @Test
    fun namedSuspendFunctionHasContinuationAndGeneratedStateOnThisCompiler() {
        val entry = Class.forName("example.tasks.SuspendTaskStepKt")
            .declaredMethods.single { it.name.startsWith("executeSyntheticTask-") }
        assertEquals(Continuation::class.java, entry.parameterTypes.last())
        assertEquals(Any::class.java, entry.returnType)

        val state = Class.forName("example.tasks.SuspendTaskStepKt\$executeSyntheticTask\$1")
        assertEquals(Int::class.javaPrimitiveType, state.getDeclaredField("label").type)
        assertEquals(Any::class.java, state.getDeclaredField("result").type)
        assertTrue(state.declaredMethods.any { it.name == "invokeSuspend" })
        println("BYTECODE continuation_last=true return_object=true state_label=true invoke_suspend=true")
    }
}
