package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals

class TaskCostProbeTest {
    @Test
    fun lastMatchProducesSameLabelResult() {
        val labels = TaskCostProbe.labels(1_024)
        assertEquals(1_024, labels.size)
        assertEquals(listOf("queued"), TaskCostProbe.eager(labels))
        assertEquals(TaskCostProbe.eager(labels), TaskCostProbe.lazy(labels))
    }

    @Test
    fun idAndStatePathsReturnEquivalentValues() {
        val labels = TaskCostProbe.labels(1_024)
        assertEquals(TaskCostProbe.rawIds(labels), TaskCostProbe.boxedIds(labels).map(TaskId::value))
        assertEquals(TaskCostProbe.direct("task-37"), TaskCostProbe.suspended("task-37"))
    }
}
