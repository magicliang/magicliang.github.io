package example.tasks

import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.withContext

class TaskProgressFlowTest {
    @Test
    fun flowBuilderDoesNotRunUntilCollectedAndRunsForEachCollection() = runTest {
        val executions = AtomicInteger()
        val progress = taskProgressFlow(TaskId("task-31")) {
            "run-${executions.incrementAndGet()}"
        }
        assertEquals(0, executions.get())
        val first = mutableListOf<TaskState>()
        progress.collect { first += it }
        val second = mutableListOf<TaskState>()
        progress.collect { second += it }
        assertEquals(listOf(TaskState.Queued, TaskState.Running, TaskState.Succeeded("run-1")), first)
        assertEquals(listOf(TaskState.Queued, TaskState.Running, TaskState.Succeeded("run-2")), second)
        assertEquals(2, executions.get())
        println("FLOW before_collect=0 first_collect=1 second_collect=2")
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun bufferedUpstreamCanFinishEmitWhileDownstreamIsWaiting() = runTest {
        val upstreamFinished = CompletableDeferred<Unit>()
        val downstreamEntered = CompletableDeferred<Unit>()
        val releaseDownstream = CompletableDeferred<Unit>()
        val collected = mutableListOf<Int>()
        val progress = flow {
            emit(1)
            emit(2)
            upstreamFinished.complete(Unit)
        }.buffer(1)
        val collector = async {
            progress.collect { value ->
                collected += value
                if (value == 1) {
                    downstreamEntered.complete(Unit)
                    releaseDownstream.await()
                }
            }
        }
        downstreamEntered.await()
        runCurrent()
        assertTrue(upstreamFinished.isCompleted)
        assertFalse(collector.isCompleted)
        releaseDownstream.complete(Unit)
        collector.await()
        assertEquals(listOf(1, 2), collected)
        println("FLOW buffered_upstream_finished=true downstream_first_waiting=true collected=2")
    }

    @Test
    fun flowOnChangesUpstreamThreadAndCatchDoesNotCatchDownstreamFailure() = runBlocking {
        val upstreamExecutor = ThreadPoolExecutor(1, 1, 0, TimeUnit.MILLISECONDS, LinkedBlockingQueue()) { task ->
            Thread(task, "kotlin-31-upstream")
        }
        val downstreamExecutor = ThreadPoolExecutor(1, 1, 0, TimeUnit.MILLISECONDS, LinkedBlockingQueue()) { task ->
            Thread(task, "kotlin-31-downstream")
        }
        val upstreamDispatcher = upstreamExecutor.asCoroutineDispatcher()
        val downstreamDispatcher = downstreamExecutor.asCoroutineDispatcher()
        try {
            val producerThreads = mutableListOf<String>()
            val collectorThreads = mutableListOf<String>()
            withContext(downstreamDispatcher) {
                taskProgressFlow(TaskId("task-31-thread")) {
                    producerThreads += Thread.currentThread().name
                    "done"
                }.flowOn(upstreamDispatcher).collect {
                    collectorThreads += Thread.currentThread().name
                }
            }
            assertEquals(1, producerThreads.size)
            assertEquals(3, collectorThreads.size)
            assertTrue(producerThreads.all { it.startsWith("kotlin-31-upstream") })
            assertTrue(collectorThreads.all { it.startsWith("kotlin-31-downstream") })

            val upstreamError = IllegalStateException("task-31 upstream")
            val caught = mutableListOf<Int>()
            flow<Int> {
                emit(1)
                throw upstreamError
            }.catch { emit(-1) }.collect { caught += it }
            assertEquals(listOf(1, -1), caught)
            val downstreamError = IllegalStateException("task-31 downstream")
            assertEquals(downstreamError.message, assertFailsWith<IllegalStateException> {
                flowOf(1).catch { emit(-1) }.collect { throw downstreamError }
            }.message)
            println("REAL flowOn_upstream=kotlin-31-upstream downstream=kotlin-31-downstream upstream_caught=true downstream_escaped=true")
        } finally {
            upstreamDispatcher.close()
            downstreamDispatcher.close()
            assertTrue(upstreamExecutor.awaitTermination(5, TimeUnit.SECONDS))
            assertTrue(downstreamExecutor.awaitTermination(5, TimeUnit.SECONDS))
        }
    }
}
