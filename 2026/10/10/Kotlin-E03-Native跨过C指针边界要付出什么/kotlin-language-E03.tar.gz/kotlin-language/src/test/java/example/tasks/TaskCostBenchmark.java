package example.tasks;

import java.util.List;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.BenchmarkMode;
import org.openjdk.jmh.annotations.Level;
import org.openjdk.jmh.annotations.Mode;
import org.openjdk.jmh.annotations.OutputTimeUnit;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;
import java.util.concurrent.TimeUnit;

@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@State(Scope.Thread)
public class TaskCostBenchmark {
    private List<String> labels;

    @Setup(Level.Trial)
    public void setUp() {
        labels = TaskCostProbe.labels(1_024);
    }

    @Benchmark
    public Object eager() {
        return TaskCostProbe.eager(labels);
    }

    @Benchmark
    public Object lazy() {
        return TaskCostProbe.lazy(labels);
    }

    @Benchmark
    public Object rawIds() {
        return TaskCostProbe.rawIds(labels);
    }

    @Benchmark
    public Object boxedIds() {
        return TaskCostProbe.boxedIds(labels);
    }

    @Benchmark
    public Object direct() {
        return TaskCostProbe.direct("task-37");
    }

    @Benchmark
    public Object suspended() {
        return TaskCostProbe.suspended("task-37");
    }
}
