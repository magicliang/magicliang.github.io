package example.tasks

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.shareIn
import kotlinx.coroutines.flow.take
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.channels.BufferOverflow

class TaskLiveUpdatesTest {
    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun stateConflatesEqualsAndSlowCollectorSeesLatest() = runTest {
        val updates = TaskLiveUpdates()
        assertEquals(TaskState.Queued, updates.state.value)
        val seen = mutableListOf<TaskState>()
        val entered = CompletableDeferred<Unit>()
        val release = CompletableDeferred<Unit>()
        val collector = backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            updates.state.collect { state ->
                seen += state
                if (state == TaskState.Running) {
                    entered.complete(Unit)
                    release.await()
                }
            }
        }
        updates.update(TaskState.Queued)
        runCurrent()
        assertEquals(listOf<TaskState>(TaskState.Queued), seen)
        updates.update(TaskState.Running)
        entered.await()
        updates.update(TaskState.Running)
        updates.update(TaskState.Succeeded("one"))
        updates.update(TaskState.Succeeded("two"))
        release.complete(Unit)
        runCurrent()
        assertEquals(listOf<TaskState>(TaskState.Queued, TaskState.Running, TaskState.Succeeded("two")), seen)
        collector.cancel()
        println("HOT state_equal_suppressed=true slow_collector_latest=two intermediate_missing=one")
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun eventWithoutSubscribersIsLostUnlessReplayIsConfigured() = runTest {
        val updates = TaskLiveUpdates()
        updates.notify("before-subscribe")
        assertTrue(updates.events.replayCache.isEmpty())
        val observed = mutableListOf<String>()
        val subscriber = backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            updates.events.take(1).toList(observed)
        }
        assertTrue(observed.isEmpty())
        updates.notify("after-subscribe")
        subscriber.join()
        assertEquals(listOf("after-subscribe"), observed)

        val replayed = MutableSharedFlow<String>(replay = 1)
        replayed.emit("remembered")
        assertEquals("remembered", replayed.first())
        println("HOT replay_zero_lost_before=true live_event=after-subscribe replay_one=remembered")
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun boundedEventBufferDropsIntermediateValueForSlowCollector() = runTest {
        val events = MutableSharedFlow<String>(extraBufferCapacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)
        val entered = CompletableDeferred<Unit>()
        val release = CompletableDeferred<Unit>()
        val observed = mutableListOf<String>()
        val subscriber = backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            events.collect { event ->
                observed += event
                if (event == "first") {
                    entered.complete(Unit)
                    release.await()
                }
            }
        }
        events.emit("first")
        entered.await()
        events.emit("middle")
        events.emit("latest")
        assertEquals(listOf("first"), observed)
        release.complete(Unit)
        runCurrent()
        assertEquals(listOf("first", "latest"), observed)
        subscriber.cancel()
        println("HOT slow_subscriber=first,latest dropped=middle")
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun sharingScopeCancellationStopsProducerButKeepsReplaySnapshot() = runTest {
        var stopped = false
        val owner = CoroutineScope(SupervisorJob() + StandardTestDispatcher(testScheduler))
        val shared = flow {
            try {
                emit("ready")
                awaitCancellation()
            } finally {
                stopped = true
            }
        }.shareIn(owner, SharingStarted.Eagerly, replay = 1)
        runCurrent()
        assertFalse(stopped)
        assertEquals("ready", shared.first())
        owner.cancel()
        runCurrent()
        assertTrue(stopped)
        assertEquals("ready", shared.first())
        println("HOT sharing_owner_stopped=true replay_snapshot_after_stop=ready")
    }
}
