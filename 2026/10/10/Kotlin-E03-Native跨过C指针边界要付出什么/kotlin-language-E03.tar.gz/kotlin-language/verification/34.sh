#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/34"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && ./gradlew --version' || exit 1
run dependencies ./gradlew --offline --no-daemon --console=plain dependencies --configuration runtimeClasspath || exit 1
run test_dependencies ./gradlew --offline --no-daemon --console=plain dependencies --configuration testRuntimeClasspath || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test loopbackTest || exit 1
suite_count=0
for xml in build/test-results/test/TEST-example.tasks.*.xml; do
    suite="${xml##*/}"
    suite="${suite#TEST-example.tasks.}"
    suite="${suite%.xml}"
    run "$suite" cat "$xml" || exit 1
    ((suite_count+=1))
done
run TaskHttpLoopbackTest cat build/test-results/loopbackTest/TEST-example.tasks.TaskHttpRoutesTest.xml || exit 1
run bytecode javap -classpath build/classes/kotlin/main -p -s example.tasks.TaskHttpRegistry || exit 1
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit
invalid_result=$?

{
    printf 'build_exit=0\nsuite_count=%s\nvalid_exit=0\ninvalid_exit=%s\n' "$suite_count" "$invalid_result"
    for xml in build/test-results/test/TEST-example.tasks.*.xml; do
        suite="${xml##*/}"
        suite="${suite#TEST-example.tasks.}"
        suite="${suite%.xml}"
        case "$suite" in
            CancellableTaskRunTest|TaskFailureBoundaryTest|TaskLiveUpdatesTest|TaskRequestDtoTest) expected=4 ;;
            BlockingTaskStepTest|ManagedTaskServiceTest|BoundedTaskQueueTest|TaskProgressFlowTest) expected=3 ;;
            *) expected=2 ;;
        esac
        grep -F "tests=\"$expected\" skipped=\"0\" failures=\"0\" errors=\"0\"" "$evidence/$suite.txt" >/dev/null && echo "$suite=PASS" || echo "$suite=FAIL"
    done
    for marker in \
        'HTTP testApplication accepted_before_completion=true duplicate=200 conflict=409 invalid=400 executions=1 completed_after_gate=true' \
        'HTTP cancellation_joined_cleanup=true unrelated_task_succeeded=true'; do
        grep -F "$marker" "$evidence/TaskHttpRoutesTest.txt" >/dev/null && echo "$marker=PASS" || echo "$marker=FAIL"
    done
    grep -F 'tests="1" skipped="0" failures="0" errors="0"' "$evidence/TaskHttpLoopbackTest.txt" >/dev/null && echo 'loopback_suite=PASS' || echo 'loopback_suite=FAIL'
    grep -F 'REAL_HTTP loopback_post=202 query=200 state=Succeeded' "$evidence/TaskHttpLoopbackTest.txt" >/dev/null && echo 'real_loopback=PASS' || echo 'real_loopback=FAIL'
    grep -F 'JSON decoded_blank_id_text_label_rejected_by_domain=true valid_draft=task-33' "$evidence/TaskRequestDtoTest.txt" >/dev/null && echo 'json_regression=PASS' || echo 'json_regression=FAIL'
    grep -F 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" >/dev/null && echo 'valid_cli=PASS' || echo 'valid_cli=FAIL'
    grep -F 'Usage: submit <task text>' "$evidence/invalid.txt" >/dev/null && echo 'invalid_cli=PASS' || echo 'invalid_cli=FAIL'
} > "$evidence/assertions.txt"

test "$suite_count" -eq 36 && test "$invalid_result" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
