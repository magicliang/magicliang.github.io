#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/37"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && ./gradlew --version' || exit 1
run dependencies ./gradlew --offline --no-daemon --console=plain dependencies --configuration testRuntimeClasspath || exit 1
run processor ./gradlew --offline --no-daemon --console=plain dependencies --configuration testAnnotationProcessor || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test loopbackTest || exit 1
suite_count=0
for xml in build/test-results/test/TEST-example.tasks.*.xml; do
    suite="${xml##*/}"
    suite="${suite#TEST-example.tasks.}"
    suite="${suite%.xml}"
    run "$suite" cat "$xml" || exit 1
    ((suite_count+=1))
done
run TaskHttpLoopbackTest cat build/test-results/loopbackTest/TEST-example.tasks.TaskHttpRoutesTest.xml || exit 1
run jmh ./gradlew --offline --no-daemon --console=plain jmh || exit 1
cp build/reports/jmh/results.json "$evidence/jmh-results.json" || exit 1
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit
invalid_result=$?

{
    printf 'suite_count=%s\ninvalid_exit=%s\n' "$suite_count" "$invalid_result"
    grep -Fq 'tests="2" skipped="0" failures="0" errors="0"' "$evidence/TaskCostProbeTest.txt" && echo same_workload_suite=PASS || echo same_workload_suite=FAIL
    grep -Fq 'tests="1" skipped="0" failures="0" errors="0"' "$evidence/TaskHttpLoopbackTest.txt" && echo real_loopback_regression=PASS || echo real_loopback_regression=FAIL
    grep -Fq 'org.openjdk.jmh:jmh-core:1.37' "$evidence/dependencies.txt" && echo jmh_runtime_version=PASS || echo jmh_runtime_version=FAIL
    grep -Fq 'org.openjdk.jmh:jmh-generator-annprocess:1.37' "$evidence/processor.txt" && echo jmh_processor_version=PASS || echo jmh_processor_version=FAIL
    jq -e 'length == 6 and all(.[]; .primaryMetric.score >= 0 and .secondaryMetrics."gc.alloc.rate.norm".score >= 0)' "$evidence/jmh-results.json" >/dev/null && echo six_jmh_methods_and_allocation=PASS || echo six_jmh_methods_and_allocation=FAIL
    grep -Fq 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" && echo valid_cli=PASS || echo valid_cli=FAIL
    grep -Fq 'Usage: submit <task text>' "$evidence/invalid.txt" && echo invalid_cli=PASS || echo invalid_cli=FAIL
} > "$evidence/assertions.txt"

test "$suite_count" -eq 39 && test "$invalid_result" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
