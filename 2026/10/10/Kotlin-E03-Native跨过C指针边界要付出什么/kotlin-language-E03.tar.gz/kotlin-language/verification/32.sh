#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/32"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && uname -a && java -version && ./gradlew --version' || exit 1
run dependencies ./gradlew --offline --no-daemon --console=plain dependencies --configuration testRuntimeClasspath || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test || exit 1
suite_count=0
for xml in build/test-results/test/TEST-example.tasks.*.xml; do
    suite="${xml##*/}"
    suite="${suite#TEST-example.tasks.}"
    suite="${suite%.xml}"
    run "$suite" cat "$xml" || exit 1
    ((suite_count+=1))
done
run bytecode javap -classpath build/classes/kotlin/main -p -s example.tasks.TaskLiveUpdates || exit 1
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit
invalid_result=$?

{
    printf 'build_exit=0\nsuite_count=%s\nvalid_exit=0\ninvalid_exit=%s\n' "$suite_count" "$invalid_result"
    for xml in build/test-results/test/TEST-example.tasks.*.xml; do
        suite="${xml##*/}"
        suite="${suite#TEST-example.tasks.}"
        suite="${suite%.xml}"
        case "$suite" in
            CancellableTaskRunTest|TaskFailureBoundaryTest|TaskLiveUpdatesTest) expected=4 ;;
            BlockingTaskStepTest|ManagedTaskServiceTest|BoundedTaskQueueTest|TaskProgressFlowTest) expected=3 ;;
            *) expected=2 ;;
        esac
        grep -F "tests=\"$expected\" skipped=\"0\" failures=\"0\" errors=\"0\"" "$evidence/$suite.txt" >/dev/null && echo "$suite=PASS" || echo "$suite=FAIL"
    done
    for marker in \
        'HOT state_equal_suppressed=true slow_collector_latest=two intermediate_missing=one' \
        'HOT replay_zero_lost_before=true live_event=after-subscribe replay_one=remembered' \
        'HOT slow_subscriber=first,latest dropped=middle' \
        'HOT sharing_owner_stopped=true replay_snapshot_after_stop=ready'; do
        grep -F "$marker" "$evidence/TaskLiveUpdatesTest.txt" >/dev/null && echo "$marker=PASS" || echo "$marker=FAIL"
    done
    grep -F 'FLOW before_collect=0 first_collect=1 second_collect=2' "$evidence/TaskProgressFlowTest.txt" >/dev/null && echo 'cold_flow_regression=PASS' || echo 'cold_flow_regression=FAIL'
    grep -F 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" >/dev/null && echo 'valid_cli=PASS' || echo 'valid_cli=FAIL'
    grep -F 'Usage: submit <task text>' "$evidence/invalid.txt" >/dev/null && echo 'invalid_cli=PASS' || echo 'invalid_cli=FAIL'
} > "$evidence/assertions.txt"

test "$suite_count" -eq 34 && test "$invalid_result" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
