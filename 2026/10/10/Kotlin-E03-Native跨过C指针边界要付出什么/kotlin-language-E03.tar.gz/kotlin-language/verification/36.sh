#!/usr/bin/env bash
set -uo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
evidence="$project/../../writing-plans/kotlin/verification/36"
mkdir -p "$evidence"
cd "$project" || exit 1

run() {
    local label="$1"
    shift
    printf 'COMMAND:' > "$evidence/$label.txt"
    printf ' %q' "$@" >> "$evidence/$label.txt"
    printf '\n' >> "$evidence/$label.txt"
    "$@" >> "$evidence/$label.txt" 2>&1
    local result=$?
    printf 'EXIT_CODE=%s\n' "$result" >> "$evidence/$label.txt"
    return "$result"
}

run environment bash -c 'date -u && java -version && ./gradlew --version' || exit 1
run build ./gradlew --offline --no-daemon --console=plain clean test loopbackTest || exit 1
suite_count=0
for xml in build/test-results/test/TEST-example.tasks.*.xml; do
    suite="${xml##*/}"
    suite="${suite#TEST-example.tasks.}"
    suite="${suite%.xml}"
    run "$suite" cat "$xml" || exit 1
    ((suite_count+=1))
done
run TaskHttpLoopbackTest cat build/test-results/loopbackTest/TEST-example.tasks.TaskHttpRoutesTest.xml || exit 1
run signature javap -classpath build/classes/kotlin/main -p -s example.tasks.SuspendTaskStepKt 'example.tasks.SuspendTaskStepKt$executeSyntheticTask$1' || exit 1
run instructions javap -classpath build/classes/kotlin/main -p -c example.tasks.SuspendTaskStepKt 'example.tasks.SuspendTaskStepKt$executeSyntheticTask$1' || exit 1
run valid ./gradlew --offline --no-daemon --console=plain run --args='submit alpha' || exit 1
run invalid ./gradlew --offline --no-daemon --console=plain run --args=submit
invalid_result=$?

{
    printf 'suite_count=%s\ninvalid_exit=%s\n' "$suite_count" "$invalid_result"
    grep -Fq 'tests="1" skipped="0" failures="0" errors="0"' "$evidence/SuspendBytecodeShapeTest.txt" && echo shape_suite=PASS || echo shape_suite=FAIL
    grep -Fq 'BYTECODE continuation_last=true return_object=true state_label=true invoke_suspend=true' "$evidence/SuspendBytecodeShapeTest.txt" && echo reflective_shape=PASS || echo reflective_shape=FAIL
    grep -Fq 'Lkotlin/coroutines/Continuation;)Ljava/lang/Object;' "$evidence/signature.txt" && echo continuation_descriptor=PASS || echo continuation_descriptor=FAIL
    grep -Fq 'COROUTINE_SUSPENDED' "$evidence/instructions.txt" && echo suspend_marker=PASS || echo suspend_marker=FAIL
    grep -Fq 'Field example/tasks/SuspendTaskStepKt$executeSyntheticTask$1.label:I' "$evidence/instructions.txt" && echo state_label=PASS || echo state_label=FAIL
    grep -Fq 'tests="1" skipped="0" failures="0" errors="0"' "$evidence/TaskHttpLoopbackTest.txt" && echo real_loopback_regression=PASS || echo real_loopback_regression=FAIL
    grep -Fq 'TASK input accepted (not persisted): alpha' "$evidence/valid.txt" && echo valid_cli=PASS || echo valid_cli=FAIL
    grep -Fq 'Usage: submit <task text>' "$evidence/invalid.txt" && echo invalid_cli=PASS || echo invalid_cli=FAIL
} > "$evidence/assertions.txt"

test "$suite_count" -eq 38 && test "$invalid_result" -ne 0 && ! grep -Fq '=FAIL' "$evidence/assertions.txt"
