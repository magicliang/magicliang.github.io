# 运行与复核

运行环境：JDK 21；Gradle Wrapper 8.14；Kotlin Gradle Plugin、编译器和 stdlib 2.2.21。精确 SHA、文档出处和已执行结果见 `../../writing-plans/kotlin/VERSIONS.md` 与 `../../writing-plans/kotlin/verification/00/`。Gradle Wrapper 固定分发包 SHA-256，即使从镜像下载也必须先通过校验。

```bash
cd examples/kotlin-language
bash verification/00.sh
bash verification/01.sh
bash verification/02.sh
bash verification/03.sh
bash verification/04.sh
bash verification/05.sh
bash verification/06.sh
bash verification/07.sh
bash verification/08.sh
bash verification/09.sh
bash verification/10.sh
bash verification/11.sh
bash verification/12.sh
bash verification/13.sh
bash verification/14.sh
bash verification/15.sh
bash verification/16.sh
bash verification/17.sh
bash verification/18.sh
bash verification/19.sh
bash verification/20.sh
```

脚本保存环境、clean test、合法/非法 CLI、字节码、依赖解析、测试报告的命令、原始输出、退出码和断言。`invalid` 的退出码预期非零。脚本依赖本仓库相对目录结构；若只拿到打包工程，请进入解包后的 `kotlin-language` 并运行 `./gradlew --no-daemon clean test`，随后分别运行 `./gradlew run --args='submit nightly-index'` 与 `./gradlew run --args=submit`。这是本机 JDK/Gradle 的实际运行，不包括 HTTP、数据库、协程或重启恢复。

01 的 `verification/01-val-reassignment.kt` 是特意放在默认源码集之外的失败样本；不要复制进 `src/main/kotlin` 的正常构建。若只有独立压缩包，版本账本位于解包根目录的 `VERSIONS.md`，实验原始输出位于 `verification/00/` 与 `verification/01/`。

02 的 `verification/02-unstable-smartcast.kt` 同样是隔离的编译失败样本，覆盖自定义 getter 与可变属性。打包快照的主工程可用 `./gradlew --offline --no-daemon clean test` 复核已缓存依赖的环境；不应把 `batch` 的本地计数或当前命令行输出理解为后台任务已入队。

03 的 `verification/03-java-named-args.kt` 演示 Java 方法无法从 Kotlin 使用命名实参，同样不能复制进正常工程。`TaskProposalTest` 验证 `taskProposal` 缺省与显式参数、`Unit` 动作、`Nothing` 异常和可空结果；`taskProposal` 目前没有接入 CLI，测试通过也不表示已经创建或运行任务。只有独立包时从根目录用 `./gradlew --offline --no-daemon clean test` 验证累计源码；相应原始证据在包内 `verification/03/`。

04 的 `TaskTextTest` 对中文、增补字符和组合字符比较三种计数，并断言正则整串匹配与子串搜索的区别。`verification/04/` 保存五组 2/2 测试、Unicode CLI 正反输入的命令与退出码；源码尚未调用 `inputMetrics` 检查 CLI。独立包从 `kotlin-language/` 运行 `./gradlew --offline --no-daemon --console=plain clean test`，预期依赖已缓存在本机；无缓存则先准备依赖，不能把离线解析失败记成测试失败。

05 的 `OptionalTaskNoteTest` 区分缺键/null/空串/普通值与 `!!`、未初始化 `lateinit` 的失败路径；`verification/05-nonnull-rejection.kt` 在默认源码集外展示非空声明拒绝 null。`verification/05/` 保存六组 2/2、CLI 正反和独立编译的退出码、原始输出与断言；这些结果不说明 CLI 已解析备注。

06 的 `TaskQueryTest` 用同一列表、集合和映射的可变别名证明读接口仍可观察变化；复制结构不能复制内部可变对象。`verification/06/` 保存七组 2/2、旧 CLI 正反的原始证据，尚未验证并发查询或底层存储。

07 的 `TaskLabelRulesTest` 断言同步 lambda 调用时读取的可变捕获值、急切规则调用次数、局部/非局部返回；隔离 `verification/07-nonlocal-return.kt` 验证非 inline 回调不能直接非局部 `return`。`verification/07/` 保存八组 2/2 与编译拒绝、旧 CLI 正反原始记录；规则尚未接入 CLI。

08 的 `TaskLabelPipelineTest` 记录急切 List 与 `List.asSequence()` 的 map/filter/take 轨迹和重复终端收集；`verification/08/` 保存九组 2/2、旧 CLI 正反的原始证据。没有以一次运行时间得出性能结论。

09 的 `TaskTest` 检查 Task 构造顺序、属性访问器与 lazy 的首次求值、未初始化 `lateinit` 访问异常及开放成员在基类构造期的派生字段风险；`verification/09/` 保存十组 2/2 和旧 CLI 正反原始证据。并非 CLI 中已创建任务。

10 的 `TaskRecordTest` 检查浅复制共享可变标签、主构造与类体属性的生成成员分界、哈希键内容改变后的查找问题及数组内容比较；`verification/10/` 保存十一组 2/2 和 CLI 正反原始证据。不是生产级任务状态模型。

11 的 `TaskStoreTest` 检查独立内存仓库、类委托与底层默认方法的接收者、observable 尝试日志及非法写入的负例；`verification/11/` 保存十二组 2/2 和 CLI 正反原始证据。`putIfAbsent` 未验证并发原子性，Store 不持久化且尚未接入 CLI。

12 的 `TaskStateTest` 只检查业务状态的**顺序**合法/非法转移与相同 ID 的顺序重试；`verification/12-missing-branch.kt` 是隔离的 when 编译拒绝样本。`verification/12/` 保存十三组 2/2、编译失败、旧 CLI 正反原始证据；没有真实线程竞争、Job 生命周期或持久化状态记录。

13 的 `SubmissionDecisionTest` 区分 `Rejected`、`Failed` 业务状态与注入的存储异常，保留异常对象；脚本保存十四组回归及 CLI 正反输出。模拟插入失败后重读的冲突，并非真正多线程测试；默认 `TaskStore.putIfAbsent` 不保证原子性。独立解包后可离线执行 `./gradlew --offline --no-daemon --console=plain clean test`，但 `verification/13.sh` 的证据路径依赖完整仓库。

14 的 `TaskFormattingTest` 检验 `TaskState` / `TaskState.Failed` 同一对象上扩展静态解析、真实成员与同名扩展同参数时成员优先，以及 let/run/apply/also 的返回形状。`verification/14/` 保存十五组累计回归及 CLI 正反结果；未将格式化函数接入旧 CLI，也未产生工作线程。

15 的 `TaskStatePortsTest` 以 `out` 的只读状态源与 `in` 的写入接收器核对类型赋值方向，并逐层检查 `List<*>` 嵌套元素；`verification/15-invalid-generic-checks.kt` 是单独编译的预期拒绝样本，不可放入主源码集。`verification/15/` 保存累计测试与诊断。该接口仍是同步内存代码，不承担实际任务执行或持久化。

16 的 `TypedTaskIdTest` 验证值类拒绝空 ID、强类型入口、同对象赋给 `Any`、`reified` 识别状态而不验证嵌套 List 元素；`verification/16-invalid-types.kt` 是隔离编译失败样本。`verification/16/bytecode.txt` 与 `bytecode-test.txt` 留存当前 2.2.21 生成方法和调用点，并不等于所有 Kotlin/JVM 版本的 ABI 或分配成本。

17 的 `TaskDraftTest` 对照 `taskDraft { ... }` 和普通 `makeTaskDraft(...)` 的同一构造/校验入口；内层显式 `this@taskDraft` 修改外层可编译，`verification/17-implicit-parent.kt` 的隐式跨层修改被 `@DslMarker` 拒绝。`verification/17/` 保存十八组累计回归和负例诊断；没有外部持久化或任务运行。

18 的 `TaskMetadataTest` 通过 JDK `Class.getAnnotation` 读取一个 `RUNTIME` 类注解、对照 `SOURCE` 注解不可在运行期读取；`verification/18-invalid-annotation-target.kt` 单独编译演示类注解不能贴在函数上。`verification/18/bytecode.txt` 保存本次 `javap -v` 的运行期注解表；没有引入 `kotlin-reflect`、扫描容器或编译插件。

19 的 `JavaInputBoundaryTest` 验证无空注解的 Java 文本返回 null、Java 泛型列表内 null 值、危险平台类型访问的运行时异常，以及显式校验后的内存任务提交和 Java SAM 同步回调。`verification/19/` 保存二十组累计回归、混合编译和 Java 类签名；没有异步任务、标签持久化或客户端网络测试。

20 的 `TaskJavaApiConsumerTest` 是真正的 Java JUnit 消费者：验证 `@JvmOverloads` 生成单/双参数 Java 重载、`@Throws` 可见的 IOException 和 Java 传 null 的运行路径。`verification/20-invalid-java-overload.java` 用单独 `javac` 验证仅有 Kotlin 默认值不足以生成 Java 单参数方法；`verification/20/` 存二十一组累计回归与当前 `javap`。不发布库或宣称未来 ABI 恒定。

21 把原任务状态、内存存储及记录源码移到 `:domain`，根项目负责 CLI 和 Java 适配，仍执行 `./gradlew --offline --no-daemon --console=plain clean test`（会运行两模块构建）和 `./gradlew --offline --no-daemon --console=plain run --args='submit alpha'`。`verification/21.sh` 保存版本、根和领域模块依赖图、两份 class major、二十二组回归、Java 消费者、CLI 正反及独立 `javac` 在未加入领域 classpath 时的预期拒绝；领域库不提供独立运行入口。原隔离反例脚本 12/15/16/17/18 已改为复制新的领域源码路径，原已发布归档仍携带各自旧结构。不将 Gradle 内嵌 Kotlin 2.0.21 混写成应用 Kotlin 插件/stdlib 2.2.21。

22 的 `TaskContractTest` 用有限状态/事件表和重试/冲突/合成故障结果检查业务契约；`verification/22-incomplete-state.kt` 仅在脚本生成的独立项目编译，预期缺 sealed `Cancelled` 分支，不能混进默认源码集。`verification/22.sh` 保存 00–22 二十三组回归、旧 CLI 正反及目标编译诊断，还将最新工程完整复制到 `/tmp` 复验旧 16 脚本，原始诊断留在 `verification/22/regression-16-*.txt`。旧 01/02/03/05/07/12/15/16/17/18 的隔离脚本改为去掉复制过来的项目依赖与模块定义：此举让负例只验证目标 Kotlin 诊断而非“找不到领域模块”；当前仅旧 16 已实际重新运行，其余没有新验收结果。默认测试不能替代真实并发、外部存储或漏测识别。

23 的 `TaskFilePortTest` 在 `src/test` 用真实临时 UTF-8 文件完成任务行的导出/导入，导入后显式调用 `submitValidated` 写入内存 Store；另用可计数 Reader 检查 EOF、提前遇到 `#stop` 和注入 IOException 各一次关闭。导出时先写同目录暂存文件、关闭 writer 后本地 `ATOMIC_MOVE`；模拟部分写入异常确认原文件保留、writer 关闭、暂存文件清理，但未证明跨 provider 原子替换或断电持久性。`TaskProcessProbeTest` 仅启动固定 JDK `java -version` / 固定无效选项子进程并分别核对退出码，不处理任意外部命令。`bash verification/23.sh` 记录 00–23 二十五组测试、CLI 正反、JUnit XML 的过程输出与断言；旧 CLI 本身尚未接入文件导入或进程探针。

24 的 `SuspendTaskStepTest` 将虚拟时钟中的空步骤与 `delay(1000)` 分账，再用真实单线程执行器及 Continuation/阻塞闸门区分实际挂起与线程占用；`bash verification/24.sh` 保存本机环境、26 组累计测试、依赖解析、字节码与 CLI 正反输入。`TaskState.Succeeded` 是函数返回的业务值，并未提交 Store；本篇没有将本地文件 I/O 改成自动可取消操作，也没有访问数据库。

25 的 `ManagedTaskServiceTest` 在 `runTest` 中用 `CompletableDeferred` 闸门分别检查同一 `coroutineScope` 子任务未退出前父级不交付业务成功、子任务故障传播与兄弟 `finally` 清理，以及服务所有者 `SupervisorJob.cancelAndJoin()` 对等待中任务的取消/清理和顺序停止后拒绝提交。`bash verification/25.sh` 保存 27 组累计测试、CLI 正反、解析树与当前 JVM 签名。初版 `assertSame` 失败记录于 `writing-plans/kotlin/verification/25/build-initial.txt`：协程异常堆栈恢复不能被写成稳定对象身份；未测试多线程 start/stop 竞争、真实阻塞 I/O 的取消、跨任务失败隔离或数据提交。

26 的 `BlockingTaskStepTest` 用两个真实单线程执行器和放闸前/后探针定位 `withContext` 后的阻塞工作者与可运行调用者；在第三条专用线程上验证 `ThreadLocal` 默认不传递、显式 `asContextElement` 传值及恢复，再用取消与同步 `CountDownLatch.await` 对照底层代码退出时刻。`bash verification/26.sh` 保存 28 组累计回归、CLI 正反、解析树及字节码。本地单工作者限制不能推断默认 `Dispatchers.IO` 的容量；初版测试在 `runBlocking` 自身线程同步等闸、以及对启用调试的协程线程名作完整相等比较均失败，原始输出见 `verification/26/build-initial.txt`。真实网络/JDBC 驱动是否支持中断和断电持久性 **NOT_RUN**。

27 的 `CancellableTaskRunTest` 分开记账：真实单线程有限循环用闸门检验每步 `ensureActive` 与不检查取消的 1/3 步差异；测试调度器中的完成优先/取消优先分别检查 lease 关闭 1 次、取消后才到达的挂起资源交付由回调关闭 1 次，`withTimeout` 的 t=100 和可挂起清理/关闭后的 t=102 分开观察。`bash verification/27.sh` 保存 29 组累计测试与旧 CLI 正反；不以虚拟超时异常证明真实阻塞 I/O、JDBC、网络或外部副作用停止。未覆盖多线程同时交付、重复资源回调、清理与关闭双重异常。

28 的 `TaskFailureBoundaryTest` 以普通 coroutineScope/受监督 scope 比较 `launch` 子故障引发的父级异常/兄弟清理、supervisor 中 handler 终端观察且兄弟存活、`async` 由 await 方领取异常；另外证实通用 `runCatching` 会捕获取消并可能换出错误默认值，专用 `captureTaskFailure` 让取消继续传播、普通异常进 Result。`bash verification/28.sh` 保存 30 组累计测试、CLI 正反与类签名；该 handler 不恢复原失败任务，也不代表外部结果或数据库提交。

29 的 `TaskConcurrentIndexTest` 用 `runTest` 闸门控制同一旧值被读两次后写回，使无锁内存 map 丢失更新（1），`TaskAttemptIndex` 通过 `Mutex.withLock` 保护整个读改写取得 2；另用单字段 `AtomicInteger` 证明两个调用都见到 Running 可令计数为 2，`TaskCompletionIndex` 用同一临界区包住状态比较/修改与计数，完成一次、计数 1。`bash verification/29.sh` 保存 31 组累计测试、CLI 正反和当前类签名；虚拟调度器中的交错不代表实际跨核线程数据竞争或数据库事务。

30 的 `BoundedTaskQueueTest` 用容量 1 的 Channel 分别控制第一次入列、第二个发送者等待、消费者取出后业务步骤尚未返回的窗口；还检查发送者取消未插入、close 拒新但既有元素可排空、消费者取出后故障不撤销发送、cancel 对未交付元素的回调。`bash verification/30.sh` 保存 32 组累计回归、CLI 正反与当前类签名。此队列是本机内存数据结构，未实现常驻消费者、重试/去重日志、进程重启恢复或数据库事务。

31 的 `TaskProgressFlowTest` 具体验证 `flow {}` 构造未执行任务、相同 Flow 被收集两次使合成步骤执行两次；测试调度器中的 `.buffer(1)` 让上游第二次 emit 完成时下游第一项仍在等待；两个真实单线程执行器验证 `.flowOn` 上游与 collect 下游的线程边界，catch 能发出替代上游数据但不会兜住下游收集 lambda 的错误。`bash verification/31.sh` 保存 33 组累计回归和旧 CLI 正反；没有把 Flow 输出写入 Store 或当作外部事务完成。

32 的 `TaskLiveUpdatesTest` 用等值更新及慢订阅者闸门验证 StateFlow 保留最新状态但跳过中间值；默认 SharedFlow 在无订阅者时丢失事件，显式 replay=1 只重放最后一项；额外容量 1 且 DROP_OLDEST 的慢订阅者错过中间通知；`shareIn` 所属作用域取消后上游进入 finally，已有 replay 快照仍可读取。`bash verification/32.sh` 保存 34 组累计回归和旧 CLI 正反；虚拟调度顺序不代表真实网络吞吐，热流不是任务确认或重启后可靠消息日志。

33 的 `TaskRequestDtoTest` 将无默认字段缺失与未知键/错误类型和可解码却违反 `TaskId`/`makeTaskDraft` 约束的值分开测试；默认 `Json` 严格拒未知键，显式宽容读取才接收，`JsonObject` 保留 note 有键与缺键差异而 DTO 已无法区分，V2 默认 priority 能读旧负载但旧严格 DTO 拒新字段。`bash verification/33.sh` 保存 35 组累计回归、解析树及 CLI 正反。序列化仅为 DTO 本地编解码，未接入 HTTP、CLI 提交或数据库事务。

34 的 `TaskHttpRoutesTest` 以 `testApplication` 闸门验证 202 先于任务结束、内存状态查询、重复提交执行一次/冲突/无效请求和取消清理；实际 Netty 回环端口测试须使用 `loopbackTest` 独立测试 JVM（与普通 `test` 同一 Gradle 命令 `clean test loopbackTest`），确认 POST 202 和完成后 GET 200。`bash verification/34.sh` 保存 36 组累计测试、独立真实端口与 CLI 正反。202 只表示受理，尚无 HTTP 中途断线成功、持久化、重启恢复或数据库事务证据；混跑超时的失败诊断见 `writing-plans/kotlin/verification/34/build-initial.txt`。

35 的 `TaskJdbcStoreTest` 在每组测试里以 PostgreSQL 16 的 initdb/pg_ctl 创建并停止独立临时集群；专用单线程 Dispatcher 内完整同步事务，独立 JDBC 连接证提交前不可见、提交后可见、注入故障回滚，进程重启后仍读取到已提交值。另一组由 pg_stat_activity 证实 pg_sleep 已活跃，再用驱动 Statement.cancel 得 SQLSTATE 57014；这不是 CoroutineScope.cancel 的等价证据。`bash verification/35.sh` 保存 37 组累计测试、单独回环测试 JVM、驱动依赖树和 CLI 正反；当前 HTTP registry 仍为内存实现，未接入 JDBC Store。

36 的 `SuspendBytecodeShapeTest` 只断言 Kotlin 编译器 2.2.21 下 `executeSyntheticTask` 的 JVM 方法和合成 continuation 形状；`bash verification/36.sh` 保存 38 组累计测试、独立回环测试、`javap` 方法签名/指令及 CLI 正反。源文件的 `suspend` 不会自动替 JDBC 同步调用实现非阻塞、持久化或驱动取消；生成类字段名不是跨版本 ABI。

37 的 `TaskCostProbeTest` 确认六个 JMH 方法的同批标签、包装前后 ID 值与空步骤状态；`bash verification/37.sh` 保存 39 组累计测试、真实回环端口、两 fork 的 JMH 平均时间/分配 JSON 和 CLI 正反。`verification/37/suspended.jfr` 是独立 fork 的 JFR 采样记录，不应与两 fork 无录制结果混合比较。JMH 和数据库二进制必须可用，测试仍使用隔离临时集群。
