use strict;
use warnings;
use Test::More;
use FindBin;
use File::Spec;
use IPC::Open3;
use Symbol 'gensym';
use lib "$FindBin::Bin/../lib";
use LogTool qw(report_rows);

my $root = File::Spec->catdir($FindBin::Bin, '..');
sub execute {
    my (@command) = @_;
    my $stderr = gensym;
    my $pid = open3(undef, my $stdout, $stderr, @command);
    binmode $stdout, ':raw';
    binmode $stderr, ':raw';
    local $/;
    my $out = <$stdout> // '';
    my $err = <$stderr> // '';
    waitpid($pid, 0);
    return ($? >> 8, $out, $err);
}

is $LogTool::VERSION, '0.100', 'own module has explicit version';
is_deeply report_rows([]), [['TOTAL', 0]], 'module returns defined rows for empty report';
my $lib = File::Spec->catdir($root, 'lib');
my ($status, $out, $err) = execute($^X, "-I$lib", '-e', 'use LogTool 0.100; print LogTool->VERSION, "\n";');
is_deeply [$status, $out, $err], [0, "0.100\n", ''], 'compatible module version loads';
($status, $out, $err) = execute($^X, "-I$lib", '-e', 'use LogTool 99;');
isnt $status, 0, 'newer unavailable version rejected';
is $out, '', 'version mismatch has no success output';
like $err, qr/LogTool version 99 required/, 'version error identifies requirement';
($status, $out, $err) = execute($^X, "-I$lib", '-e', 'use LogTool qw(not_exported);');
isnt $status, 0, 'non-exported function rejected';
is $out, '', 'invalid export has no stdout';
like $err, qr/not_exported.*not exported/, 'diagnostic identifies invalid import';

my $cli = File::Spec->catfile($root, 'bin', 'logtool.pl');
my $fixture = File::Spec->catfile($root, 'fixtures', 'demo.tsv');
($status, $out, $err) = execute($^X, $cli, 'report-csv', $fixture);
open my $gold, '<:raw', File::Spec->catfile($root, 'golden', 'report-csv.txt') or die $!;
{ local $/; is $out, <$gold>, 'CSV report matches gold bytes'; }
is $status, 0, 'CSV report succeeds';
is $err, '', 'CSV report has empty stderr';
($status, $out, $err) = execute($^X, $cli, 'report-csv', File::Spec->catfile($root, 'fixtures', 'invalid.tsv'));
is_deeply [$status, $out, $err], [2, '', "line 1: invalid record\n"],
    'CSV report rejects invalid source before writing rows';

my $vendor = File::Spec->catdir($root, 'vendor', 'lib', 'perl5');
($status, $out, $err) = execute($^X, "-I$vendor", '-MText::CSV', '-e',
    'my $csv=Text::CSV->new({binary=>1,eol=>"\n"}); $csv->combine("api,worker",2); print Text::CSV->backend,"\n",$csv->string;');
is_deeply [$status, $out, $err], [0, "Text::CSV_PP\n\"api,worker\",2\n", ''], 'isolated pure-Perl CSV escapes comma in field';

($status, $out, $err) = execute($^X, $cli, '--help');
is $status, 0, 'POD help succeeds';
like $out, qr/logtool\.pl.*synthetic UTF-8 TSV/s, 'POD help includes NAME';
like $out, qr/report-csv FILE/, 'POD help includes CSV contract';
is $err, '', 'help has no diagnostic';
($status, $out, $err) = execute($^X, $cli, '--help', 'unexpected');
is_deeply [$status, $out, $err],
    [2, '', "usage: perl bin/logtool.pl import|parse|query|report|report-csv|report-file|probe FILE [ARG]\n"],
    'help with extra argument is not silently accepted';

($status, $out, $err) = execute('prove', '-v', File::Spec->catfile($root, 'fixtures', 'deliberate-failure.t'));
isnt $status, 0, 'failing TAP fixture makes prove fail';
like $out, qr/not ok 1/, 'failing assertion visible';
like $out, qr/Result: FAIL/, 'prove summary records failure';

done_testing();
