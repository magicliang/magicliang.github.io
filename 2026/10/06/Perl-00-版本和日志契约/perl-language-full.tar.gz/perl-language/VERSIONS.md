# 版本冻结（2026-10-06 UTC）

| 对象 | 实测 / 校验 |
|---|---|
| 运行时 | `/usr/bin/perl`，`perl -v`: 5.38.2，Ubuntu `perl-base` 5.38.2-3.2ubuntu0.4 |
| 二进制身份 | `readlink -f /usr/bin/perl` = `/usr/bin/perl`；SHA-256 `fa36b75b21e94f424b61aa058b743cc62c94e7fa45a085fdeffb2bae687ed925` |
| 完整编译参数与已登记补丁 | `evidence/perl-V.txt`（`perl -V` 的完整原始 STDOUT；该文件 SHA-256 `3c6d8661b026723e6237a80ec71519464e33ded57eee92e3a25733a5d0fdf6ff`） |
| 执行环境 | Linux `session62378fcd8bd544fa8c-8ws6x`，内核 `5.10.134-013.16.kangaroo.al8.x86_64`，x86_64；`perl -V` 记录的是构建机的 Linux 6.1.0，与运行宿主不同 |
| Perl 5 文档与上游源码 | `perl-5.38.2.tar.gz` 自 [CPAN 官方源](https://www.cpan.org/src/5.0/perl-5.38.2.tar.gz) 所附 [SHA-256 文件](https://www.cpan.org/src/5.0/perl-5.38.2.tar.gz.sha256) 的期望值 `a0a31534451eb7b83c7d6594a497543a54d488bc90ca00f5e34762577f40655e`；Aliyun CPAN 镜像下载的压缩包实测 SHA-256 与之相同 |
| 上游 git 身份 | `git ls-remote https://github.com/Perl/perl5.git 'refs/tags/v5.38.2' 'refs/tags/v5.38.2^{}'`：注释 tag `82fb326b93c15a939564967f727ab7cf5790528b`；剥离后源码 commit `55dd2f792ffc8cefe614350a411f785374281b24` |

文档取自经 SHA-256 校验的上游 `perl-5.38.2.tar.gz` 中的 `pod/*.pod`，而不是指向可能变动的 latest 网页。CPAN 包的校验只能说明镜像包与官方公布的摘要一致，不能证明本地 Ubuntu 编译的二进制由该上游 tag 直接构建；系统包有独立补丁和编译选项。不能从本机 Linux 核验其他平台的运行语义。

00–22 阶段只使用本机随 Perl 安装的模块；23 起新增第三方 distribution，见下一节。已加载核心模块版本：`Encode 3.19`、`FindBin 1.53`、`Exporter 5.77`、`Test::More 1.302194`、`File::Spec 3.88`、`IPC::Open3 1.22`、`Symbol 1.09`、`Time::Local 1.30`、`Pod::Usage 2.03`。运行 `perl -Iexamples/perl-language/lib -MLogTool -e 'print join("\n", sort keys %INC)'` 实测该库加载 `Carp.pm, Encode.pm, Encode/Alias.pm, Encode/Config.pm, Encode/Encoding.pm, Encode/MIME/Name.pm, Exporter.pm, Exporter/Heavy.pm, Fcntl.pm, LogTool.pm, Storable.pm, Time/Local.pm, XSLoader.pm, bytes.pm, constant.pm, overloading.pm, parent.pm, strict.pm, warnings.pm, warnings/register.pm`。这是运行时已装载文件快照，并非所有输入、进程或模块装载顺序下都不变的锁文件。核心模块由上述 Ubuntu 安装提供；没有对其做独立 CPAN 安装。

## 第三方 distribution（23 开始）

`Text-CSV-2.06.tar.gz` 来自 `https://cpan.metacpan.org/authors/id/I/IS/ISHIGAKI/Text-CSV-2.06.tar.gz`，发行者目录的 `CHECKSUMS` 对该文件记录的 SHA-256 为 `dfcaec925a788b0ba41e51bc6d16e21b0e98b4c7af9b79395090add75f5e506f`，下载包实测相同。原发行 tar 保存在 `vendor/Text-CSV-2.06.tar.gz`（含元数据和上游许可证说明）。上游 `META.json` 声明运行时必需 `perl >= 5.006001`、`IO::Handle`、`Test::More >= 0.92`、`Test::Harness`，配置/构建需 `ExtUtils::MakeMaker`，可选推荐 `Text::CSV_XS >= 1.60`。本机必需模块实际版本为 `IO::Handle 1.52`、`Test::More 1.302194`、`Test::Harness 3.44`、`ExtUtils::MakeMaker 7.70`；推荐的 XS 后端不存在。本次安装 `Text::CSV 2.06`、`Text::CSV_PP 2.06`，`Text::CSV->backend` 实测 `Text::CSV_PP`，CLI 还显式强制该后端以避免本机有 XS 时隐式换实现。这是已解析的直接依赖及在当前 Perl 基础环境中由核心模块满足的传递依赖，**不是**对全平台二进制依赖的锁定。

安装在临时源码目录执行 `env -u PERL5LIB perl Makefile.PL INSTALL_BASE=/home/admin/workspace/my-blogs/examples/perl-language/vendor INSTALLMAN1DIR=none INSTALLMAN3DIR=none && make test && make install`。环境无全局 Text::CSV；结果安装到示例树的 `vendor/lib/perl5/Text/CSV.pm` 和 `Text/CSV_PP.pm`，未修改全局 Perl 库。发行包测试 `Files=40, Tests=52723, Result: PASS`，`t/00_pod.t` 因未安装可选的 `Test::Pod 1.00` 被跳过；测试期间打印了以 `# CSV_PP ERROR` 开头的预期诊断，不应误报为全程无诊断。未来若换 CPAN 版本，必须重新检查源包摘要、依赖和离线解包复跑。

## 26–39 与选修新增依赖 / 发行练习

传统对象 `LogTool::Record 0.100`、固定进程实验 `LogTool::Runner 0.100` 与保存模块 `LogTool::Report 0.100` 均为本系列自有代码，随 `lib/` 全量交付。后两者使用本机核心 `IPC::Open3 1.22`、`Symbol 1.09`、`Fcntl 1.15`、`File::Basename 2.86`、`File::Temp 0.2311`；选修 E03 单独使用 `Unicode::Normalize 1.32`。本机分别查询 `perl -M模块 -e 'print $模块::VERSION'` 的加载版本；不是从上游文档假设的版本。第三方仍只使用 Text::CSV 2.06；`Makefile.PL` 明确声明它和核心模块的运行时/测试时依赖，并将最低 Perl 写为本系列已测试的 5.38.2。安装依赖时尚须按发行元数据核对所安装环境；不能因为 examples 自带 vendor 而声称自动解析 CPAN 传递依赖。`ExtUtils::MakeMaker 7.70` 是本机创建 distribution 的核心工具。

MakeMaker 发行业务命令在临时副本中执行；隔离 Text::CSV 的上游源码包在另一个临时目录安装到同一 `INSTALL_BASE` 后，安装版 CLI 在 `PERL5LIB` 指向该目录下 `lib/perl5` 的条件下可运行 `report-csv`，得到 `TOTAL,3\nINFO,2\nWARN,1\n`。发行 tar 的 SHA-256、`make test` 与安装验证见 `evidence/32-39.md`；此本机练习未部署远端、未上传 CPAN。
