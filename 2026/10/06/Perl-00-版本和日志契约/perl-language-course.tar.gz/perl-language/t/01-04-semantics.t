use strict;
use warnings;
use Test::More;
use FindBin;
use File::Spec;
use IPC::Open3;
use Symbol 'gensym';

sub execute {
    my (@arguments) = @_;
    my $stderr = gensym;
    my $pid = open3(undef, my $stdout, $stderr, $^X, @arguments);
    local $/;
    my $out = <$stdout> // '';
    my $err = <$stderr> // '';
    waitpid($pid, 0);
    return ($? >> 8, $out, $err);
}

my $scripts = File::Spec->catdir($FindBin::Bin, '..', 'experiments');
my %gold = (
    '01-scope.pl' => "inside=worker\noutside=api\n",
    '02-context.pl' => "list=api|worker\nscalar=one\nscalar-array=2\nscalar-reverse=ba\nlist-reverse=b|a\n",
    '03-arrays.pl' => "source=api|worker\ncopy=api|worker|cache\nslice=api|worker\nlength=2\n",
    '04-values.pl' => "0:defined=0,truth=0\n1:defined=1,truth=0\n2:defined=1,truth=0\n3:defined=1,truth=0\n4:defined=1,truth=1\nempty-message-accepted\n",
);
for my $script (sort keys %gold) {
    my ($status, $out, $err) = execute(File::Spec->catfile($scripts, $script));
    is $status, 0, "$script succeeds";
    is $out, $gold{$script}, "$script matches gold";
    is $err, '', "$script has no warnings";
}

my ($status, $out, $err) = execute('-we', 'use strict; my $service = "api"; print $missing;');
isnt $status, 0, 'undeclared variable rejected by strict';
is $out, '', 'compile failure has no stdout';
like $err, qr/Global symbol "\$missing" requires explicit package name/, 'error identifies variable';

($status, $out, $err) = execute('-we', 'use strict; use warnings; my $value = undef; print $value + 1;');
is $status, 0, 'uninitialized arithmetic is not fatal by default';
is $out, '1', 'coercion produces a result';
like $err, qr/Use of uninitialized value/, 'warning is not a validation policy';

done_testing();
