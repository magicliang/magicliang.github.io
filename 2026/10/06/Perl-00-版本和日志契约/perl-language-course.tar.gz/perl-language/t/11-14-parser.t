use strict;
use warnings;
use Test::More;
use FindBin;
use File::Spec;
use File::Temp 'tempfile';
use IPC::Open3;
use Symbol 'gensym';

my $root = File::Spec->catdir($FindBin::Bin, '..');
my $cli = File::Spec->catfile($root, 'bin', 'logtool.pl');
sub inspect {
    my ($command, $text, $seed) = @_;
    my ($file, $path) = tempfile();
    binmode $file, ':raw';
    print {$file} $text;
    close $file or die $!;
    my $stderr = gensym;
    local $ENV{PERL_HASH_SEED} = $seed if defined $seed;
    my $pid = open3(undef, my $stdout, $stderr, $^X, $cli, $command, $path);
    binmode $stdout, ':raw';
    binmode $stderr, ':raw';
    local $/;
    my $out = <$stdout> // '';
    my $err = <$stderr> // '';
    waitpid($pid, 0);
    return ($? >> 8, $out, $err);
}

my $base = "2026-10-06T00:00:00Z\tINFO\tapi\t";
my ($status, $out, $err) = inspect('parse', $base);
is_deeply [$status, $out, $err], [0, "$base\n", ''], 'no final LF accepted and output adds one';
($status, $out, $err) = inspect('parse', "$base\r\n");
is_deeply [$status, $out, $err], [2, '', "line 1: invalid record\n"], 'CRLF rejected by documented LF-only contract';
($status, $out, $err) = inspect('parse', "2026-10-06T00:00:00Z\tINFO\tapi\n");
is_deeply [$status, $out, $err], [2, '', "line 1: expected four fields\n"], 'absent message field rejected';
($status, $out, $err) = inspect('parse', "${base}extra\tfield\n");
is_deeply [$status, $out, $err], [2, '', "line 1: expected four fields\n"], 'extra field rejected';
($status, $out, $err) = inspect('parse', "2025-02-29T00:00:00Z\tINFO\tapi\tqueued\n");
is_deeply [$status, $out, $err], [2, '', "line 1: invalid record\n"], 'non-leap February 29 rejected';
($status, $out, $err) = inspect('parse', "2024-02-29T00:00:00Z\tINFO\tAPI\t queued \n");
is_deeply [$status, $out, $err], [0, "2024-02-29T00:00:00Z\tINFO\tapi\t queued \n", ''], 'valid leap date and ASCII service normalization, message unchanged';

my $mixed = "2024-02-29T00:00:00Z\tWARN\tAPI\tone\n" .
    "2024-02-29T00:00:01Z\tERROR\tapi\ttwo\n" .
    "2024-02-29T00:00:02Z\tINFO\tapi\tthree\n";
for my $seed (1, 777) {
    ($status, $out, $err) = inspect('report', $mixed, $seed);
    is_deeply [$status, $out, $err], [0, "TOTAL\t3\nERROR\t1\nINFO\t1\nWARN\t1\n", ''], "fixed report order with hash seed $seed";
}

my $fixture = File::Spec->catfile($root, 'fixtures', 'normalized.tsv');
for my $case (['parse', 'normalized.txt'], ['report', 'report-mixed.txt']) {
    my ($command, $gold_name) = @$case;
    my $stderr = gensym;
    my $pid = open3(undef, my $stdout, $stderr, $^X, $cli, $command, $fixture);
    open my $gold, '<:raw', File::Spec->catfile($root, 'golden', $gold_name) or die $!;
    local $/;
    my $actual = <$stdout> // '';
    my $expected = <$gold> // '';
    my $diagnostic = <$stderr> // '';
    waitpid($pid, 0);
    is_deeply [$? >> 8, $actual, $diagnostic], [0, $expected, ''], "$command matches standalone gold";
}

done_testing();
