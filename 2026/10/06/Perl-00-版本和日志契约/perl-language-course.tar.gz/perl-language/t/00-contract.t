use strict;
use warnings;
use Test::More;
use FindBin;
use File::Spec;
use IPC::Open3;
use Symbol 'gensym';

my $root = File::Spec->catdir($FindBin::Bin, '..');
my $cli = File::Spec->catfile($root, 'bin', 'logtool.pl');
my $fixture = File::Spec->catfile($root, 'fixtures', 'demo.tsv');

sub run_command {
    my (@arguments) = @_;
    my $stderr = gensym;
    my $pid = open3(undef, my $stdout, $stderr, $^X, $cli, @arguments);
    binmode $stdout, ':raw';
    binmode $stderr, ':raw';
    local $/;
    my $out = <$stdout> // '';
    my $err = <$stderr> // '';
    waitpid($pid, 0);
    return ($? >> 8, $out, $err);
}

for my $command (qw(import parse report)) {
    my ($status, $out, $err) = run_command($command, $fixture);
    open my $gold, '<:raw', File::Spec->catfile($root, 'golden', "$command.txt") or die $!;
    local $/;
    is $out, <$gold>, "$command stdout matches gold";
    is $err, '', "$command stderr empty";
    is $status, 0, "$command exits successfully";
}
my ($status, $out, $err) = run_command('query', $fixture, 'WARN');
open my $gold, '<:raw', File::Spec->catfile($root, 'golden', 'query.txt') or die $!;
{ local $/; is $out, <$gold>, 'query stdout matches gold'; }
is $err, '', 'query stderr empty';
is $status, 0, 'query succeeds';

($status, $out, $err) = run_command('import', File::Spec->catfile($root, 'fixtures', 'invalid.tsv'));
is $status, 2, 'bad record rejected with documented status';
is $out, '', 'reject never emits success count';
like $err, qr/line 1: invalid record/, 'reject identifies line';

($status, $out, $err) = run_command('query', $fixture, 'ERROR');
is $status, 0, 'empty match succeeds';
is $out, '', 'empty match has deliberately empty stdout';
is $err, '', 'empty match has empty stderr';

done_testing();
