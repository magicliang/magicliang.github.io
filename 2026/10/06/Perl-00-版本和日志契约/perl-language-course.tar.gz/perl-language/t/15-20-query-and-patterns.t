use strict;
use warnings;
use Test::More;
use FindBin;
use File::Spec;
use IPC::Open3;
use Symbol 'gensym';

my $root = File::Spec->catdir($FindBin::Bin, '..');
sub run_command {
    my (@arguments) = @_;
    my $stderr = gensym;
    my $pid = open3(undef, my $stdout, $stderr, $^X, @arguments);
    binmode $stdout, ':raw';
    binmode $stderr, ':raw';
    local $/;
    my $out = <$stdout> // '';
    my $err = <$stderr> // '';
    waitpid($pid, 0);
    return ($? >> 8, $out, $err);
}

my $cli = File::Spec->catfile($root, 'bin', 'logtool.pl');
my $fixture = File::Spec->catfile($root, 'fixtures', 'demo.tsv');
my ($status, $out, $err) = run_command($cli, 'query', $fixture, 'WARN');
open my $gold, '<:raw', File::Spec->catfile($root, 'golden', 'query.txt') or die $!;
{ local $/; is $out, <$gold>, 'query matches gold'; }
is $status, 0, 'valid query succeeds';
is $err, '', 'valid query has no diagnostic';
($status, $out, $err) = run_command($cli, 'query', $fixture, 'DEBUG');
is_deeply [$status, $out, $err], [2, '', "query requires INFO, WARN or ERROR\n"], 'invalid filter explicitly rejected';
($status, $out, $err) = run_command($cli, 'query', $fixture, 'ERROR');
is_deeply [$status, $out, $err], [0, '', ''], 'valid empty result is not error';
($status, $out, $err) = run_command($cli, 'query', File::Spec->catfile($root, 'fixtures', 'invalid.tsv'), 'WARN');
is_deeply [$status, $out, $err], [2, '', "line 1: invalid record\n"], 'query does not skip malformed nonmatching lines';

my $experiment = File::Spec->catfile($root, 'experiments', '16-20-patterns.pl');
my %golden = (
    16 => "accepted:id:abc-01\nrejected:id=\n",
    17 => "capture=a:pos=1\ncapture=b:pos=3\nafter-failure=undef\nzero-width=0,1\n",
    18 => "unquoted=aXb\nliteral=a.b\n",
    19 => "size=6:partitions=32:rejected=1\nsize=8:partitions=128:rejected=1\nsize=10:partitions=512:rejected=1\n",
    20 => "tab-fields=4\nwhitespace-fields=5\nfixed-prefix=short\n",
);
for my $chapter (sort keys %golden) {
    ($status, $out, $err) = run_command($experiment, $chapter);
    is_deeply [$status, $out, $err], [0, $golden{$chapter}, ''], "chapter $chapter success and counterexample gold";
}
($status, $out, $err) = run_command($experiment, '21');
is $out, '', 'unsupported experiment has no stdout';
isnt $status, 0, 'unsupported experiment fails';
like $err, qr/choose chapter/, 'unsupported experiment has diagnosis';

done_testing();
