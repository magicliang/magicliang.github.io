use strict;
use warnings;
use Test::More;
use FindBin;
use File::Spec;
use IPC::Open3;
use Symbol 'gensym';
use lib "$FindBin::Bin/../lib";
use LogTool qw(read_records report_rows);
use LogTool::Record;
use LogTool::Runner 'run_probe';

my $root = File::Spec->catdir($FindBin::Bin, '..');
my $fixture = File::Spec->catfile($root, 'fixtures', 'demo.tsv');
my $cli = File::Spec->catfile($root, 'bin', 'logtool.pl');
sub execute {
    my (@arguments) = @_;
    my $stderr = gensym;
    my $pid = open3(undef, my $stdout, $stderr, $^X, $cli, @arguments);
    binmode $stdout, ':raw';
    binmode $stderr, ':raw';
    local $/;
    my $out = <$stdout> // '';
    my $err = <$stderr> // '';
    waitpid($pid, 0);
    return ($? >> 8, $out, $err);
}

my $fields = {time => '2026-10-06T00:00:00Z',
    level => 'INFO', service => 'api', message => ''};
my $record = LogTool::Record->new($fields);
isa_ok $record, 'LogTool::Record';
is $record->level, 'INFO', 'accessor returns level';
$fields->{level} = 'ERROR';
is $record->level, 'INFO', 'copy protects object from original hash mutation';
my $copy = $record->as_hash;
$copy->{level} = 'WARN';
is $record->level, 'INFO', 'returned hash is independent for string fields';
$record->{level} = 'WARN';
is $record->level, 'WARN', 'bless does not prohibit direct hash mutation';
my $result = eval { LogTool::Record->new({%$fields, level => 'DEBUG'}) };
ok !defined($result), 'invalid level constructor rejects';
like $@, qr/invalid record level/, 'constructor diagnostic is explicit';

my $records = read_records($fixture);
is scalar(@$records), 3, 'read_records returns expected count';
is_deeply report_rows($records), [['TOTAL', 3], ['INFO', 2], ['WARN', 1]],
    'blessed object is used for report counting';
my $missing = File::Spec->catfile($root, 'fixtures', 'definitely-absent.tsv');
my ($status, $out, $err) = execute('import', $missing);
is $status, 2, 'open error exits nonzero';
is $out, '', 'open error does not publish import result';
like $err, qr/\Acannot open input:/, 'open error retains diagnosis';
if ($^O eq 'linux') {
    ($status, $out, $err) = execute('import', File::Spec->catdir($root, 'fixtures'));
    is $status, 2, 'read error after successful open exits nonzero';
    is $out, '', 'read error does not publish partial success';
    like $err, qr/\Acannot read input:/, 'read error is not confused with EOF';
}
($status, $out, $err) = execute('query', $fixture, 'ERROR');
is_deeply [$status, $out, $err], [0, '', ''], 'valid empty result differs from I/O failure';
($status, $out, $err) = execute('query', File::Spec->catfile($root, 'fixtures', 'invalid.tsv'), 'WARN');
is_deeply [$status, $out, $err], [2, '', "line 1: invalid record\n"],
    'malformed input differs from empty query';

my $child = run_probe($^X, 'alpha;echo BAD');
is_deeply $child, {exit => 0, signal => 0,
    stdout => "arg=alpha;echo BAD\n", stderr => "probe note\n"},
    'argument metacharacters arrive literally with separate child streams';
($status, $out, $err) = execute('probe', $fixture, 'alpha;echo BAD');
is_deeply [$status, $out, $err], [0, "arg=alpha;echo BAD\n", "probe note\n"],
    'CLI publishes successful probe with child stderr kept separate';
$child = run_probe($^X, 'fail');
is_deeply $child, {exit => 7, signal => 0,
    stdout => '', stderr => "child failed\n"}, 'child failure is not startup failure';
($status, $out, $err) = execute('probe', $fixture, 'fail');
is_deeply [$status, $out, $err], [2, '', "probe exited 7: child failed\n"],
    'CLI never publishes failed child output as successful data';
$result = eval { run_probe('/definitely/missing/perl-program', 'safe') };
ok !defined($result), 'missing executable cannot launch';
like $@, qr/\Aprobe start failed: open3: exec of/, 'startup failure has its own diagnostic';
($status, $out, $err) = execute('probe', $fixture, "bad\ntoken");
is_deeply [$status, $out, $err],
    [2, '', "probe requires one ASCII token of at most 24 bytes\n"],
    'invalid token rejected before launching process';

done_testing();
