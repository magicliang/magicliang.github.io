use strict;
use warnings;
use Test::More;
use FindBin;
use File::Temp qw(tempdir);
use IPC::Open3;
use Symbol qw(gensym);
my $directory = tempdir('perl CLI space-XXXX', TMPDIR => 1, CLEANUP => 1);
my $cli = "$FindBin::Bin/../bin/logtool";
sub run {
    my (@args) = @_;
    my $error = gensym;
    my $pid = open3(undef, my $output, $error, $^X, $cli, @args);
    local $/;
    my ($stdout, $stderr) = (<$output> // '', <$error> // '');
    waitpid($pid, 0) == $pid or die $!;
    return ($? >> 8, $stdout, $stderr);
}
my ($accepted, $rejects) = ("$directory/accepted.jsonl", "$directory/rejected.jsonl");
my ($exit, $out, $err) = run('import', '--input', "$FindBin::Bin/../fixtures/course.tsv", '--output', $accepted, '--rejects', $rejects);
is($exit, 0, 'paths with spaces import');
is($out, "INPUT\t5\nACCEPTED\t4\nREJECTED\t1\n", 'import conservation gold');
is($err, '', 'successful import stderr empty');
($exit, $out, $err) = run('report', '--input', $accepted);
is($out, "TOTAL\t4\nERROR\t1\nINFO\t2\nWARN\t1\n", 'report sorted gold');
is($exit, 0, 'report successful');
($exit, $out, $err) = run('query', '--input', $accepted, '--min-duration', 0);
is(scalar(grep { length } split /\n/, $out), 3, 'zero option retained');
is($exit, 0, 'zero is legal');
for my $args (['query', '--input'], ['query', '--input', $accepted, '--unknown'], ['query', '--input', $accepted, '--output', 'x'], ['query', '--input', $accepted, '--min-duration', '00'], ['query', '--input', $accepted, 'extra']) {
    ($exit, $out, $err) = run(@$args);
    is($exit, 2, 'invalid CLI exit');
    is($out, '', 'invalid CLI stdout empty');
    ok(length($err), 'invalid CLI diagnostic');
}
link($accepted, "$directory/hard-link") or die $!;
($exit, $out, $err) = run('report', '--input', $accepted, '--output', "$directory/hard-link");
is($exit, 2, 'input hardlink destination rejected');
link($rejects, "$directory/reject-link") or die $!;
($exit, $out, $err) = run('import', '--input', "$FindBin::Bin/../fixtures/course.tsv", '--output', $rejects, '--rejects', "$directory/reject-link");
is($exit, 2, 'output pair hardlinks rejected');
($exit, $out, $err) = run('--help');
like($out, qr/--min-duration/, 'help current option');
is($exit, 0, 'help success');
($exit, $out, $err) = run('--version');
like($out, qr/LogTool::Course 0\.200 Perl v/, 'version reports actual interpreter');
is($exit, 0, 'version success');
done_testing;
