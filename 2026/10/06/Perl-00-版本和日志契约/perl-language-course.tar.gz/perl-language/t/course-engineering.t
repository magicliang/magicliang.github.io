use strict;
use warnings;
use Test::More;
use FindBin;
use File::Spec;
use File::Temp 'tempdir';
use IPC::Open3;
use JSON::PP ();
use Symbol 'gensym';
use Config ();
use lib "$FindBin::Bin/../lib";
use LogTool qw(read_records);
use LogTool::Course::Aggregator qw(aggregate_rows);
use LogTool::Course::Output qw(tsv_report jsonl_report);
use LogTool::Course::Parallel qw(parallel_rows publish_parallel_report);
use LogTool::Runner 'run_probe';

my $root = File::Spec->catdir($FindBin::Bin, '..');
my $fixture = File::Spec->catfile($root, 'fixtures', 'demo.tsv');
my $legacy_cli = File::Spec->catfile($root, 'bin', 'logtool.pl');
my $perl_path = File::Spec->file_name_is_absolute($^X) ? $^X : $Config::Config{perlpath};
my $tmp = tempdir(CLEANUP => 1);

sub slurp {
    my ($path) = @_;
    open my $input, '<:raw', $path or die $!;
    local $/;
    return <$input>;
}

sub run_perl {
    my (@arguments) = @_;
    my $stderr = gensym;
    my $pid = open3(undef, my $stdout, $stderr, $^X, @arguments);
    binmode $stdout, ':raw';
    binmode $stderr, ':raw';
    local $/;
    my $out = <$stdout> // '';
    my $err = <$stderr> // '';
    waitpid($pid, 0);
    return ($? >> 8, $? & 127, $out, $err);
}

my $records = read_records($fixture);
my $aggregate = LogTool::Course::Aggregator->new;
$aggregate->add($_) for @$records;
is_deeply $aggregate->rows,
    [{level => 'INFO', count => 2}, {level => 'WARN', count => 1}],
    'course aggregator returns sorted hash rows without total';
is_deeply aggregate_rows($records), $aggregate->rows,
    'function aggregator has parity with object aggregator';
my $independent = LogTool::Course::Aggregator->new;
$independent->add({level => 'ERROR'});
is_deeply $aggregate->rows,
    [{level => 'INFO', count => 2}, {level => 'WARN', count => 1}],
    'second aggregator instance does not share counts';
is_deeply $independent->rows,
    [{level => 'ERROR', count => 1}],
    'second aggregator keeps its own counts';
my $owned_rows = $aggregate->rows;
$owned_rows->[0]{count} = 99;
push @$owned_rows, {level => 'ERROR', count => 99};
is_deeply $aggregate->rows,
    [{level => 'INFO', count => 2}, {level => 'WARN', count => 1}],
    'rows result is a caller-owned copy';

is tsv_report(scalar(@$records), $aggregate->rows),
    "TOTAL\t3\nINFO\t2\nWARN\t1\n",
    'TSV output strategy keeps caller-owned total separate';

my @json = map { JSON::PP->new->decode($_) }
    grep { length } split /\n/, jsonl_report(scalar(@$records), $aggregate->rows);
is_deeply \@json,
    [
        {kind => 'total', count => 3},
        {kind => 'level', level => 'INFO', count => 2},
        {kind => 'level', level => 'WARN', count => 1},
    ],
    'JSON Lines output strategy carries typed rows';

is_deeply parallel_rows($records, 2), $aggregate->rows,
    'forked shard merge equals single-process aggregation';

my $parallel_report = File::Spec->catfile($tmp, 'parallel.tsv');
publish_parallel_report($records, $parallel_report, 2);
is slurp($parallel_report), "TOTAL\t3\nINFO\t2\nWARN\t1\n",
    'parallel publish writes complete merged report';

open my $old, '>:raw', $parallel_report or die $!;
print {$old} "OLD\n" or die $!;
close $old or die $!;
my $failed = eval {
    publish_parallel_report(
        [@$records, {level => 'ERROR', message => 'boom'}],
        $parallel_report,
        2,
        fail_if => sub { ($_[0]{message} // '') eq 'boom' },
    );
    1;
};
ok !$failed, 'worker failure aborts publish';
like $@, qr/\Aworker failed/, 'worker failure has explicit diagnostic';
is slurp($parallel_report), "OLD\n",
    'worker failure does not replace previous report';
is_deeply parallel_rows($records, 8), $aggregate->rows,
    'worker count is bounded by record count and keeps deterministic rows';

my $signal_script = File::Spec->catfile($tmp, 'terminate.pl');
open my $sig, '>:raw', $signal_script or die $!;
print {$sig} "#!$perl_path\nkill 'TERM', \$\$;\n";
close $sig or die $!;
chmod 0700, $signal_script or die $!;
my $signaled = run_probe($signal_script, 'safe');
is $signaled->{exit}, 0, 'signaled child has no normal exit code';
is $signaled->{signal}, 15, 'signal termination is reported separately';

my $large_input = File::Spec->catfile($tmp, 'large.tsv');
open my $large, '>:raw', $large_input or die $!;
for my $index (1 .. 20000) {
    print {$large} "2026-10-06T00:00:00Z\tINFO\tsvc\tmessage-$index\n" or die $!;
}
close $large or die $!;
pipe(my $reader, my $writer) or die $!;
close $reader or die $!;
my $pipe_pid = fork();
die "cannot fork pipe test: $!\n" unless defined $pipe_pid;
if ($pipe_pid == 0) {
    open STDOUT, '>&', $writer or die $!;
    open STDERR, '>', File::Spec->devnull or die $!;
    close $writer;
    exec $^X, $legacy_cli, 'parse', $large_input;
    exit 127;
}
close $writer;
waitpid($pipe_pid, 0);
ok(($? & 127) == 13 || ($? >> 8) != 0,
    'legacy parser closed downstream pipe produces SIGPIPE or nonzero write failure');

my $old_report = File::Spec->catfile($tmp, 'limited.tsv');
open my $seed, '>:raw', $old_report or die $!;
print {$seed} "OLD\n" or die $!;
close $seed or die $!;
my $limit_program =
    'use strict; use warnings; use lib q(lib); use LogTool::Report qw(save_report); '
    . 'save_report(q{x} x 2000, shift);';
my ($exit, $signal, $out, $err) = run_perl(
    '-e',
    'use strict; use warnings; use POSIX qw(SIGXFSZ); '
        . '$SIG{XFSZ} = "IGNORE"; '
        . 'require BSD::Resource; BSD::Resource::setrlimit(BSD::Resource::RLIMIT_FSIZE(), 1, 1); '
        . 'exec @ARGV;',
    $^X,
    '-Ilib',
    '-e',
    $limit_program,
    $old_report,
);
SKIP: {
    skip 'BSD::Resource is not installed for RLIMIT_FSIZE close-failure probe', 3
        if $err =~ /Can't locate BSD\/Resource\.pm/;
    ok($exit != 0 || $signal != 0, 'file-size limit makes save_report fail');
    like $err, qr/cannot (?:write|close) report:/,
        'write or close failure is diagnosed';
    is slurp($old_report), "OLD\n",
        'failed close/write keeps previous report';
}

my $cleanup_target = File::Spec->catfile($tmp, 'cleanup.tsv');
my $cleanup_program = <<'PERL';
BEGIN {
    *CORE::GLOBAL::close = sub (*;$) {
        CORE::close($_[0]);
        $! = 5;
        return 0;
    };
    *CORE::GLOBAL::unlink = sub (@) {
        $! = 13;
        return 0;
    };
}
use strict;
use warnings;
use LogTool::Report 'save_report';
eval { save_report("new report\n", shift) };
if ($@) {
    print STDERR $@;
    exit 2;
}
exit 0;
PERL
($exit, $signal, $out, $err) = run_perl('-Ilib', '-e', $cleanup_program, $cleanup_target);
is $exit, 2, 'cleanup injection reports save_report failure';
is $signal, 0, 'cleanup injection is not signal-terminated';
like $err, qr/cannot close report:/, 'primary close error is retained';
like $err, qr/cannot remove temporary report:/, 'temporary cleanup error is appended';
like $err, qr/cannot close report lock:/, 'lock close error is appended';

for my $script (qw(course-composition.pl course-lifecycle.pl course-performance.pl course-process.pl)) {
    my ($script_exit, $script_signal, $script_out, $script_err) =
        run_perl(File::Spec->catfile($root, 'experiments', $script));
    is [$script_exit, $script_signal]->[0], 0, "$script exits normally";
    is $script_signal, 0, "$script is not signal-terminated";
    is $script_err, '', "$script has empty stderr";
    like $script_out, qr/[a-z_]+=/, "$script prints key-value evidence";
    if ($script eq 'course-composition.pl') {
        like $script_out, qr/^inheritance_touches_internal_counts=1$/m,
            'composition experiment records inheritance internal coupling';
        like $script_out, qr/^composition_uses_rows_protocol=1$/m,
            'composition experiment records rows protocol boundary';
    }
    if ($script eq 'course-performance.pl') {
        like $script_out, qr/^output_equal=1$/m,
            'performance experiment asserts equivalent output bytes';
        like $script_out, qr/^output_sha256=[0-9a-f]{64}$/m,
            'performance experiment records output SHA-256';
    }
}

done_testing();
