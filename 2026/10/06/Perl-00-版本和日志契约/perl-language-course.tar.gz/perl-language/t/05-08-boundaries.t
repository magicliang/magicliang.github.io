use strict;
use warnings;
use Test::More;
use FindBin;
use File::Spec;
use IPC::Open3;
use Symbol 'gensym';

my $directory = File::Spec->catdir($FindBin::Bin, '..', 'experiments');
my %expected = (
    '05-references.pl' => "source=api|worker\nalias=api|worker\ncopy=api|cache\nshared=changed\n",
    '07-arguments.pl' => "after-alias=worker\nlocal=cache\nafter-copy=worker\n",
    '08-return.pl' => "list=api|queued\nscalar=queued\nref=ARRAY\ncount=2\n",
);
for my $script (sort keys %expected) {
    my $stderr = gensym;
    my $pid = open3(undef, my $stdout, $stderr, $^X, File::Spec->catfile($directory, $script));
    local $/;
    my $out = <$stdout> // '';
    my $err = <$stderr> // '';
    waitpid($pid, 0);
    is $? >> 8, 0, "$script exits successfully";
    is $out, $expected{$script}, "$script matches gold";
    is $err, '', "$script has no warnings";
}
{
    my $stderr = gensym;
    my $pid = open3(undef, my $stdout, $stderr, $^X, File::Spec->catfile($directory, '06-autovivify.pl'));
    local $/;
    my $out = <$stdout> // '';
    my $err = <$stderr> // '';
    waitpid($pid, 0);
    isnt $? >> 8, 0, 'unknown nested field rejected';
    is $out, "before=0\nafter-read=1\ncreated=HASH\n", 'read already changed tree';
    like $err, qr/\Amissing field\n\z/, 'rejection is explicit';
}
done_testing();
