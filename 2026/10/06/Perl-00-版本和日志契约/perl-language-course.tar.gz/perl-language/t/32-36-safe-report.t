use strict;
use warnings;
use Test::More;
use FindBin;
use File::Spec;
use File::Temp 'tempdir';
use IPC::Open3;
use Fcntl 'LOCK_EX';
use Symbol 'gensym';

my $root = File::Spec->catdir($FindBin::Bin, '..');
my $cli = File::Spec->catfile($root, 'bin', 'logtool.pl');
my $fixture = File::Spec->catfile($root, 'fixtures', 'demo.tsv');
my $mixed = File::Spec->catfile($root, 'fixtures', 'normalized.tsv');
my $invalid = File::Spec->catfile($root, 'fixtures', 'invalid.tsv');
my $directory = tempdir(CLEANUP => 1);
my $destination = File::Spec->catfile($directory, 'report.tsv');
sub run_cli {
    my (@arguments) = @_;
    my $stderr = gensym;
    my $pid = open3(undef, my $stdout, $stderr, $^X, $cli, @arguments);
    binmode $stdout, ':raw';
    binmode $stderr, ':raw';
    local $/;
    my $out = <$stdout> // '';
    my $err = <$stderr> // '';
    waitpid($pid, 0);
    return ($? >> 8, $out, $err);
}
sub file_bytes {
    my ($file) = @_;
    open my $input, '<:raw', $file or die $!;
    local $/;
    return <$input>;
}

my $gold = file_bytes(File::Spec->catfile($root, 'golden', 'report.txt'));
my $other_gold = file_bytes(File::Spec->catfile($root, 'golden', 'report-mixed.txt'));
my ($status, $stdout, $stderr) = run_cli('report-file', $fixture, $destination);
is_deeply [$status, $stdout, $stderr], [0, "SAVED\n", ''],
    'save emits acknowledgement only after writing';
is file_bytes($destination), $gold, 'saved bytes equal stable sorted report gold';
ok -f "$destination.lock", 'stable sidecar lock persists between calls';
($status, $stdout, $stderr) = run_cli('report-file', $fixture, $destination);
is_deeply [$status, $stdout, $stderr], [0, "SAVED\n", ''], 'same input repeat succeeds';
is file_bytes($destination), $gold, 'repeat output is byte-identical';

($status, $stdout, $stderr) = run_cli('report-file', $invalid, $destination);
is_deeply [$status, $stdout, $stderr], [2, '', "line 1: invalid record\n"],
    'malformed source is rejected before replacement';
is file_bytes($destination), $gold, 'bad input leaves previous valid artifact unchanged';
($status, $stdout, $stderr) = run_cli('report-file', $destination, $destination);
is_deeply [$status, $stdout, $stderr], [2, '', "report destination is input\n"],
    'report cannot replace its own input';
is file_bytes($destination), $gold, 'same-path error leaves previous artifact unchanged';
my $blocked = File::Spec->catdir($directory, 'blocked');
mkdir $blocked or die $!;
($status, $stdout, $stderr) = run_cli('report-file', $fixture, $blocked);
is $status, 2, 'directory destination rejects atomic replacement';
is $stdout, '', 'rename failure publishes no saved receipt';
like $stderr, qr/\Acannot replace report:/, 'rename failure diagnosed';
is file_bytes($destination), $gold, 'failed rename does not touch previous report';
my @temporaries = glob File::Spec->catfile($directory, '.logtool-*');
is scalar(@temporaries), 0, 'failed rename removes temporary';

($status, $stdout, $stderr) = run_cli('report-file', $fixture);
is_deeply [$status, $stdout, $stderr], [2, '', "report-file requires one destination\n"],
    'destination is mandatory';
my $missing_parent = File::Spec->catfile($directory, 'missing', 'report.tsv');
($status, $stdout, $stderr) = run_cli('report-file', $fixture, $missing_parent);
is $status, 2, 'missing parent rejects before creating output';
is $stdout, '', 'invalid destination does not publish success';
like $stderr, qr/\Acannot open report lock:/, 'lock creation error diagnosed';

my $parallel = File::Spec->catfile($directory, 'parallel.tsv');
my @children;
for my $input ($fixture, $mixed) {
    my $error = gensym;
    my $pid = open3(undef, my $output, $error, $^X, $cli,
        'report-file', $input, $parallel);
    push @children, [$pid, $output, $error];
}
for my $child (@children) {
    my ($pid, $output, $error) = @$child;
    local $/;
    my $out = <$output> // '';
    my $err = <$error> // '';
    waitpid($pid, 0);
    is_deeply [$? >> 8, $out, $err], [0, "SAVED\n", ''],
        'cooperating writer exits successfully';
}
my $final = file_bytes($parallel);
ok $final eq $gold || $final eq $other_gold,
    'final concurrent output is one complete report, not partial mixed bytes';
ok -f "$parallel.lock", 'cooperating writers share stable lock filename';
open my $lock, '>>', "$parallel.lock" or die $!;
flock($lock, LOCK_EX) or die $!;
open my $bypass, '>:raw', $parallel or die $!;
print {$bypass} "BYPASS\n" or die $!;
close $bypass or die $!;
is file_bytes($parallel), "BYPASS\n", 'advisory lock cannot restrain an uncooperative writer';
close $lock or die $!;
($status, $stdout, $stderr) = run_cli('report-file', $fixture, $parallel);
is_deeply [$status, $stdout, $stderr], [0, "SAVED\n", ''],
    'cooperating writer can replace bypassed artifact';
is file_bytes($parallel), $gold, 'restored report is complete';

my $oversized = File::Spec->catfile($directory, 'large.tsv');
open my $large, '>:raw', $oversized or die $!;
print {$large} 'x' x 1_048_577 or die $!;
close $large or die $!;
($status, $stdout, $stderr) = run_cli('import', $oversized);
is_deeply [$status, $stdout, $stderr], [2, '', "input exceeds 1048576 bytes\n"],
    'oversized regular file is rejected with recorded bound';

done_testing();
