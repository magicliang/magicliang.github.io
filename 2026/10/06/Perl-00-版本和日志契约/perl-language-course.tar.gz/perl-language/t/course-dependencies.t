use strict;
use warnings;
use utf8;
use Test::More;
use FindBin;
use File::Spec;
use IPC::Open3;
use Symbol 'gensym';

BEGIN {
    require FindBin;
    require File::Spec;
    my $root = File::Spec->catdir($FindBin::Bin, '..');
    unshift @INC,
        File::Spec->catdir($root, 'vendor', 'lib', 'perl5'),
        File::Spec->catdir($root, 'lib');
}

my $root = File::Spec->catdir($FindBin::Bin, '..');
use Text::CSV_XS ();
use DBI ();
use DBD::SQLite ();
use Moo ();
use LogTool::Course::Aggregator;
use LogTool::Course::MooAggregator;
use LogTool::Course::Role::LevelRows;

is($^V, v5.38.2, 'dependency lane runs on the frozen Perl 5.38.2 binary');
is($Text::CSV_XS::VERSION, '1.64', 'Text::CSV_XS isolated version');
is($DBI::VERSION, '1.655', 'DBI isolated version');
is($DBD::SQLite::VERSION, '1.78', 'DBD::SQLite isolated version');
is($DBD::SQLite::sqlite_version, '3.51.1', 'DBD::SQLite reports the actual SQLite engine version');
is($Moo::VERSION, '2.005005', 'Moo isolated version');
ok(LogTool::Course::MooAggregator->does('LogTool::Course::Role::LevelRows'), 'Moo aggregator composes the real level rows role');

my $csv = Text::CSV_XS->new({binary => 1, eol => "\n"});
ok($csv->parse(qq{id,"two\nlines","a""b"}), 'XS parses quoted multiline field bytes');
is_deeply([$csv->fields], ['id', "two\nlines", 'a"b'], 'XS keeps newline and quote escape as data');
ok(!$csv->parse(qq{id,"unterminated}), 'XS rejects malformed CSV');

{
    local $ENV{PERL_TEXT_CSV} = 'Text::CSV_PP';
    delete $INC{'Text/CSV.pm'};
    require Text::CSV;
    my $pp = Text::CSV->new({binary => 1, eol => "\n"});
    ok($pp->parse(qq{id,"two\nlines","a""b"}), 'PP backend parses same CSV record');
    is_deeply([$pp->fields], ['id', "two\nlines", 'a"b'], 'PP backend matches XS fields');
    isnt(Text::CSV->backend, 'Text::CSV_XS', 'PP backend is distinct from XS backend');
}

my $dbh = DBI->connect('dbi:SQLite:dbname=:memory:', '', '', {
    RaiseError => 1,
    PrintError => 0,
    AutoCommit => 1,
});
$dbh->do('CREATE TABLE events(level TEXT NOT NULL, message TEXT NOT NULL)');
$dbh->begin_work;
$dbh->do('INSERT INTO events(level, message) VALUES (?, ?)', undef, 'INFO', 'committed');
$dbh->commit;
$dbh->begin_work;
$dbh->do('INSERT INTO events(level, message) VALUES (?, ?)', undef, 'ERROR', 'rolled back');
$dbh->rollback;
is_deeply($dbh->selectall_arrayref('SELECT level, message FROM events ORDER BY rowid'),
    [['INFO', 'committed']], 'SQLite transaction rollback removes uncommitted row');
is($dbh->selectrow_array('SELECT COUNT(*) FROM events WHERE level = ?', undef, 'INFO'), 1,
    'parameterized SQLite query returns expected count');
my $payload = q{x' OR 1=1 --};
$dbh->do('INSERT INTO events(level, message) VALUES (?, ?)', undef, 'WARN', $payload);
is($dbh->selectrow_array('SELECT COUNT(*) FROM events WHERE message = ?', undef, $payload), 1,
    'SQLite binding treats quoted SQL-looking input as one value');
is($dbh->selectrow_array('SELECT COUNT(*) FROM events'), 2,
    'SQLite malicious-looking value does not expand result set');
ok($dbh->disconnect, 'SQLite handle disconnects explicitly after the experiment');

my @records = (
    {level => 'WARN'},
    {level => 'INFO'},
    {level => 'WARN'},
    {level => 'ERROR'},
);
my $classic = LogTool::Course::Aggregator->new;
my $moo = LogTool::Course::MooAggregator->new;
for my $record (@records) {
    is($classic->add($record), $classic, 'classic add is chainable');
    is($moo->add($record), $moo, 'Moo add is chainable');
}
is_deeply($moo->rows, $classic->rows, 'Moo aggregator rows match classic aggregator');
is_deeply($moo->rows, [
    {level => 'ERROR', count => 1},
    {level => 'INFO', count => 1},
    {level => 'WARN', count => 2},
], 'aggregator rows are sorted level/count hashes');

sub run_script {
    my ($script) = @_;
    my $stderr = gensym;
    my $path = File::Spec->catfile($root, 'experiments', $script);
    my $pid = open3(undef, my $stdout, $stderr, $^X, $path);
    binmode $stdout, ':raw';
    binmode $stderr, ':raw';
    local $/;
    my $out = <$stdout> // '';
    my $err = <$stderr> // '';
    waitpid($pid, 0);
    return ($? >> 8, $? & 127, $out, $err);
}

my %script_output;
for my $script (qw(course-csv-xs.pl course-sqlite.pl course-moo.pl course-oneliners.pl course-internals.pl course-legacy.pl course-class-bless.pl)) {
    my ($exit, $signal, $out, $err) = run_script($script);
    is($exit, 0, "$script exits 0");
    is($signal, 0, "$script has no signal");
    is($err, '', "$script has empty stderr");
    like($out, qr/\A[a-z0-9_.-]+=.+/m, "$script prints key-value evidence");
    $script_output{$script} = $out;
}

like($script_output{'course-csv-xs.pl'}, qr/^csv_auto\.backend=Text::CSV_XS$/m,
    'Text::CSV 2.06 selects the XS backend when available');
like($script_output{'course-csv-xs.pl'}, qr/^csv_pp\.backend=Text::CSV_PP$/m,
    'Text::CSV can be forced to the pure-Perl backend separately');
like($script_output{'course-sqlite.pl'}, qr/^sqlite\.engine=3\.51\.1$/m,
    'E03 records the actual SQLite engine version');
like($script_output{'course-oneliners.pl'}, qr/^oneliner\.inplace=ERROR\tworker$/m,
    'E01 in-place edit changes the target file');
like($script_output{'course-oneliners.pl'}, qr/^oneliner\.full_script_equal=1$/m,
    'E01 one-liner output matches the restored full script');
like($script_output{'course-oneliners.pl'}, qr/^oneliner\.backup=WARN\tworker$/m,
    'E01 in-place edit keeps the requested temporary backup');
like($script_output{'course-sqlite.pl'}, qr/^sqlite\.bound_payload=1$/m,
    'E03 SQLite bound malicious-looking payload is stored as one value');
like($script_output{'course-sqlite.pl'}, qr/^sqlite\.disconnected=1$/m,
    'E03 SQLite experiment explicitly disconnects');
like($script_output{'course-internals.pl'}, qr/^internals\.sv=PV$/m,
    'E07 B reports the scalar SV class');
like($script_output{'course-internals.pl'}, qr/^internals\.peek_has_pv=1$/m,
    'E07 Devel::Peek output contains PV details');
like($script_output{'course-internals.pl'}, qr/^internals\.peek_has_refcnt=1$/m,
    'E07 Devel::Peek output contains reference-count details');
like($script_output{'course-internals.pl'}, qr/^internals\.concise_has_const=1$/m,
    'E07 B::Concise output contains a constant op');
like($script_output{'course-internals.pl'}, qr/^internals\.concise_has_add=1$/m,
    'E07 B::Concise output contains the addition op');
like($script_output{'course-legacy.pl'}, qr/^legacy\.old_count=1$/m,
    'E08 legacy baseline runs before migration comparison');
like($script_output{'course-legacy.pl'}, qr/^legacy\.new_count=1$/m,
    'E08 migrated lexical-filehandle version preserves the count');
like($script_output{'course-legacy.pl'}, qr/^legacy\.global_dependency=removed_by_argument$/m,
    'E08 migration removes hidden global path dependency');
like($script_output{'course-legacy.pl'}, qr/^legacy\.two_arg_open=replaced_by_three_arg_open$/m,
    'E08 migration replaces two-argument open');
like($script_output{'course-legacy.pl'}, qr/^legacy\.global_filehandle=replaced_by_lexical_filehandle$/m,
    'E08 migration replaces global filehandle');
like($script_output{'course-class-bless.pl'}, qr/^class_bless\.warning=experimental_visible$/m,
    'E05 class experiment preserves experimental warning evidence');
like($script_output{'course-class-bless.pl'}, qr/^class_bless\.rows=INFO:1,WARN:1$/m,
    'E05 native class object and blessed object are added to the same aggregator');
like($script_output{'course-class-bless.pl'}, qr/^class_bless\.protocol=level_method$/m,
    'E05 class and bless interoperate through the shared method protocol');
like($script_output{'course-class-bless.pl'}, qr/^class_bless\.class_hash_boundary=hash_rejected$/m,
    'E05 class object does not share the blessed-hash direct dereference contract');

done_testing;
