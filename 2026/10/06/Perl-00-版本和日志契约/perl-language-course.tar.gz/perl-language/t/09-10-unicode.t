use strict;
use warnings;
use Test::More;
use FindBin;
use File::Spec;
use File::Temp 'tempfile';
use Encode qw(encode FB_CROAK);
use IPC::Open3;
use Symbol 'gensym';

my $root = File::Spec->catdir($FindBin::Bin, '..');
sub run_command {
    my (@arguments) = @_;
    my $stderr = gensym;
    local $ENV{LC_ALL} = 'C';
    my $pid = open3(undef, my $stdout, $stderr, $^X, @arguments);
    binmode $stdout, ':raw';
    binmode $stderr, ':raw';
    local $/;
    my $out = <$stdout> // '';
    my $err = <$stderr> // '';
    waitpid($pid, 0);
    return ($? >> 8, $out, $err);
}

my ($status, $out, $err) = run_command(File::Spec->catfile($root, 'experiments', '09-10-encoding.pl'));
is $status, 0, 'encoding experiment exits 0';
is $out, "characters=2\ninput-bytes=6\ndecoded-characters=2\noutput=\xe9\x87\x8d\xe8\xaf\x95\n", 'literal, decoded chars and encoded output agree';
is $err, '', 'encoding experiment has no warnings';

my $mutable_source = 'abc';
is encode('UTF-8', $mutable_source, FB_CROAK), 'abc', 'checked encode emits bytes';
is $mutable_source, '', 'CHECK flag without LEAVE_SRC consumes original scalar';

my ($file, $path) = tempfile();
binmode $file, ':raw';
print {$file} "2026-10-06T00:00:00Z\tINFO\tapi\t" . chr(255) . "\n";
close $file or die $!;
my $cli = File::Spec->catfile($root, 'bin', 'logtool.pl');
($status, $out, $err) = run_command($cli, 'import', $path);
is $status, 2, 'malformed UTF-8 is rejected';
is $out, '', 'malformed input never emits imported count';
is $err, "line 1: invalid UTF-8\n", 'malformed input error identifies line';

($status, $out, $err) = run_command($cli, 'query', File::Spec->catfile($root, 'fixtures', 'demo.tsv'), 'WARN');
open my $gold, '<:raw', File::Spec->catfile($root, 'golden', 'query.txt') or die $!;
{ local $/; is $out, <$gold>, 'UTF-8 output bytes match gold under C locale'; }
is $status, 0, 'Unicode query succeeds';
is $err, '', 'Unicode query has empty stderr';

done_testing();
