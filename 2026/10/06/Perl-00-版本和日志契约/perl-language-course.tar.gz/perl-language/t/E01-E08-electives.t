use strict;
use warnings;
use Test::More;
use FindBin;
use File::Spec;
use File::Temp 'tempdir';
use IPC::Open3;
use Symbol 'gensym';

my $root = File::Spec->catdir($FindBin::Bin, '..');
my $cli = File::Spec->catfile($root, 'bin', 'logtool.pl');
my $fixture = File::Spec->catfile($root, 'fixtures', 'demo.tsv');
sub execute {
    my (@command) = @_;
    my $error = gensym;
    my $pid = open3(undef, my $output, $error, @command);
    binmode $output, ':raw';
    binmode $error, ':raw';
    local $/;
    my $out = <$output> // '';
    my $err = <$error> // '';
    waitpid($pid, 0);
    return ($? >> 8, $out, $err);
}

my ($status, $out, $err) = execute($^X, '-e',
    'use feature "signatures"; sub level($value) { print "$value\n" } level("INFO")');
is_deeply [$status, $out, $err], [0, "INFO\n", ''], 'E01 signatures accepted without warning';
($status, $out, $err) = execute($^X, '-e',
    'use feature "signatures"; sub level($value) { print "$value\n" } level()');
is $out, '', 'E01 arity error emits no successful level';
like $err, qr/Too few arguments for subroutine/, 'E01 arity check rejects missing argument';
isnt $status, 0, 'E01 bad arity exits nonzero';

my $source = 'use feature "class"; class Event { field $level :param; '
    . 'method level { $level } }; print Event->new(level => "INFO")->level, "\n"';
($status, $out, $err) = execute($^X, '-e', $source);
is $status, 0, 'E02 class example runs on frozen version';
is $out, "INFO\n", 'E02 class matches record level output';
like $err, qr/class is experimental.*field is experimental.*method is experimental/s,
    'E02 experimental warnings remain visible';
($status, $out, $err) = execute($^X, '-e',
    'use feature "class"; class Event { field $level :param; method level { $level } }; Event->new()');
isnt $status, 0, 'E02 missing required field rejects';
like $err, qr/Required parameter 'level' is missing/, 'E02 refusal not masked by warnings';

($status, $out, $err) = execute($^X, '-e',
    'use Unicode::Normalize "NFC"; use Encode qw(encode FB_CROAK); '
    . 'my $text=NFC("e" . chr(0x301)); print "same=",($text eq chr(0xe9))," bytes=",length(encode("UTF-8",$text,FB_CROAK)),"\n"');
is_deeply [$status, $out, $err], [0, "same=1 bytes=2\n", ''],
    'E03 normalization runs after valid characters are available';
($status, $out, $err) = execute($^X, '-e',
    'use Encode qw(decode FB_CROAK); decode("UTF-8",pack("C",255),FB_CROAK)');
is $out, '', 'E03 undecodable bytes have no normalized output';
like $err, qr/UTF-8.*does not map to Unicode/, 'E03 decode rejects malformed bytes';
isnt $status, 0, 'E03 invalid bytes are not treated as text';

($status, $out, $err) = execute($^X,
    File::Spec->catfile($root, 'experiments', '16-20-patterns.pl'), '19');
is_deeply [$status, $out, $err],
    [0, "size=6:partitions=32:rejected=1\nsize=8:partitions=128:rejected=1\nsize=10:partitions=512:rejected=1\n", ''],
    'E04 intentionally short hostile inputs reject (combinatorial shape only)';
($status, $out, $err) = execute($^X,
    File::Spec->catfile($root, 'experiments', '16-20-patterns.pl'), '18');
is_deeply [$status, $out, $err],
    [0, "unquoted=aXb\nliteral=a.b\n", ''],
    'E04 unquoted dynamic pattern is counterexample to literal interpretation';

my $vendor = File::Spec->catdir($root, 'vendor', 'lib', 'perl5');
{
    local $ENV{PERL_TEXT_CSV} = 'Text::CSV_PP';
($status, $out, $err) = execute($^X, "-I$vendor", '-MText::CSV', '-e',
    'print $Text::CSV::VERSION," ",Text::CSV->backend,"\n"');
}
is_deeply [$status, $out, $err], [0, "2.06 Text::CSV_PP\n", ''],
    'E05 isolated version and backend are observable';
($status, $out, $err) = execute($^X, "-I$vendor", '-e', 'use Text::CSV 999;');
is $out, '', 'E05 unsatisfied version has no success output';
like $err, qr/Text::CSV version 999 required/, 'E05 incompatible dependency rejected';
isnt $status, 0, 'E05 incompatible version exits nonzero';

($status, $out, $err) = execute($^X, $cli, '--help');
is $status, 0, 'E06 help runs without perldoc';
like $out, qr/report-file FILE DESTINATION/, 'E06 POD includes written-file contract';
is $err, '', 'E06 success has no diagnostic';
($status, $out, $err) = execute($^X, '-MApp::Prove', '-e',
    'my $app = App::Prove->new; $app->process_args(@ARGV); exit($app->run ? 0 : 1);',
    '--', '-v',
    File::Spec->catfile($root, 'fixtures', 'deliberate-failure.t'));
isnt $status, 0, 'E06 deliberately failing TAP remains outside default suite';
like $out, qr/Result: FAIL/, 'E06 prove reports failure rather than silent pass';
like $err, qr/got:.*2.*expected:.*3/s, 'E06 failure details retained on stderr';

($status, $out, $err) = execute($^X, $cli, 'probe', $fixture, 'x y');
is_deeply [$status, $out, $err], [0, "arg=x y\n", "probe note\n"],
    'E07 Linux argument boundary accepts literal space';
($status, $out, $err) = execute($^X, $cli, 'probe', $fixture, "x\ny");
is_deeply [$status, $out, $err],
    [2, '', "probe requires one ASCII token of at most 24 bytes\n"],
    'E07 invalid token rejected before platform-specific launch';

my $directory = tempdir(CLEANUP => 1);
my $destination = File::Spec->catfile($directory, 'report.tsv');
($status, $out, $err) = execute($^X, $cli, 'report-file', $fixture, $destination);
is_deeply [$status, $out, $err], [0, "SAVED\n", ''],
    'E08 normal replace completed before success receipt';
($status, $out, $err) = execute($^X, $cli, 'report-file',
    File::Spec->catfile($root, 'fixtures', 'invalid.tsv'), $destination);
is_deeply [$status, $out, $err], [2, '', "line 1: invalid record\n"],
    'E08 malformed source cannot replace valid report';
open my $saved, '<:raw', $destination or die $!;
{ local $/; is <$saved>, "TOTAL\t3\nINFO\t2\nWARN\t1\n", 'E08 old valid bytes survive failed run'; }

done_testing();
