use strict;
use warnings;
use Test::More;
use FindBin;
use Errno qw(EIO);
use lib "$FindBin::Bin/../lib";
our ($fail_read, $fail_close);
BEGIN {
    *CORE::GLOBAL::sysread = sub (*\$$;$) {
        if ($fail_read) {
            $! = EIO;
            return undef;
        }
        return @_ == 4 ? CORE::sysread($_[0], ${$_[1]}, $_[2], $_[3])
                      : CORE::sysread($_[0], ${$_[1]}, $_[2]);
    };
    *CORE::GLOBAL::close = sub (*) {
        my $closed = CORE::close($_[0]);
        if ($fail_close) {
            $! = EIO;
            return 0;
        }
        return $closed;
    };
}
use LogTool::Course qw(import_records);
my $fixture = "$FindBin::Bin/../fixtures/course.tsv";
{
    local $fail_read = 1;
    eval { import_records($fixture) };
    like($@, qr/cannot read input:/, 'injected read failure is not EOF');
}
{
    local $fail_close = 1;
    eval { import_records($fixture) };
    like($@, qr/cannot close input:/, 'injected close failure propagates');
}
eval { import_records("$fixture.missing") };
like($@, qr/cannot open input:/, 'missing input open error');
is(import_records($fixture)->{input}, 5, 'fault flags restore before next batch');
done_testing;
