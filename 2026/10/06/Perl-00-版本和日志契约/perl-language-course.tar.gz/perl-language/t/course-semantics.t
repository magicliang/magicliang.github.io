use strict;
use warnings;
use utf8;
use Test::More;
use FindBin;
use IPC::Open3;
use Symbol qw(gensym);
use lib "$FindBin::Bin/../lib";
use LogTool::Course::Filter qw(make_filter);

my $script = "$FindBin::Bin/../experiments/course-semantics.pl";

sub run_case {
    my ($case) = @_;
    my $stderr = gensym;
    my $pid = open3(undef, my $stdout, $stderr, $^X, $script, $case);
    local $/;
    my $out = <$stdout> // '';
    my $err = <$stderr> // '';
    waitpid($pid, 0);
    return ($? >> 8, $out . $err);
}

my ($status, $out) = run_case('variables');
is($status, 0, 'variables case exits successfully');
like($out, qr/^scalar=api\narray_count=2 array_last=WARN\nhash_INFO=2\n\z/, 'scalar array and hash keep distinct shapes');

($status, $out) = run_case('list_context');
is($status, 0, 'list context case exits successfully');
like($out, qr/list_reverse=b\|a scalar_reverse=ba\ncontext_seen=list\|scalar\|void list_count=2 scalar=right\n/, 'list scalar and void context change expression results');

($status, $out) = run_case('scope');
is($status, 0, 'scope case exits successfully');
like($out, qr/my=LEXICAL our=INFO\nlocal_inside=WARN\nlocal_after=INFO\n/, 'my our and local have separate scope effects');

($status, $out) = run_case('filter_forms');
is($status, 0, 'filter forms case exits successfully');
like($out, qr/loop=api\ngrep=api\nmap_copy=API\|WORKER\nsource=api\|worker\ngrep_alias_source=API\|WORKER selected=API\n/, 'loop grep and map copy can preserve source when copies are explicit');

($status, $out) = run_case('comparison');
is($status, 0, 'comparison case exits successfully');
like($out, qr/string_eq=1 numeric_eq=1
default=fallback wrong_default=99 kept_zero=0 grouped=0 ungrouped=1
/, 'comparison operators defaults and precedence boundaries are explicit');

($status, $out) = run_case('refs');
is($status, 0, 'refs case exits successfully');
like($out, qr/alias_level=WARN\ncopy_nested=1\/9\nautoviv_before=0 after=missing value=undef\nlocal_nested_inside=WARN\nlocal_nested_after=INFO next_batch=ERROR\n/, 'references alias local restoration and autovivification boundaries are visible');

($status, $out) = run_case('unicode');
is($status, 0, 'unicode case exits successfully');
like($out, qr/decoded_chars=2 bytes=6\n/, 'decoded characters and encoded bytes have different counts');
like($out, qr/nfc_equal=1 codepoints=2 graphemes=1\n/, 'NFC and grapheme boundary are explicit');
like($out, qr/double_decode=error utf8_flag=1\n/, 'decoded character string is not decoded again as bytes');

($status, $out) = run_case('regex');
is($status, 0, 'regex case exits successfully');
like($out, qr/capture=abc-01\nfailed=failed old_capture=abc-01\n/, 'failed match does not reset old capture');
like($out, qr/g_parts=a\@1\|b\@3 final_pos=undef\n/, '/g state is observable and resets after default failed match');
like($out, qr/gc_failed=failed before=1 after=1\n/, '/gc failed match preserves position');
like($out, qr/unquoted=aXb\nliteral=a\.b\n/, 'dynamic literal must be quoted');
like($out, qr/redacted=token=\[REDACTED\] keep original=token=abc123 keep\n/, 'redaction copies message before substitution and preserves original');
like($out, qr/g_list=a\|b scalar_first=1 named=service:api zero=0\|1\n/, 'scalar list named and zero width global matches are explicit');

($status, $out) = run_case('backtracking');
is($status, 0, 'backtracking case exits successfully');
like($out, qr/size=6 partitions=32 rejected=1 elapsed_us=\d+\nsize=8 partitions=128 rejected=1 elapsed_us=\d+\nsize=10 partitions=512 rejected=1 elapsed_us=\d+\n/, 'bounded backtracking sample records size and elapsed time');

($status, $out) = run_case('eval_errors');
is($status, 0, 'eval errors case exits successfully');
like($out, qr/eval_ok=0 first=1\neval_success=1 after_success=empty saved=1\n/, 'eval clears current $@ on success and saved error must be copied');

($status, $out) = run_case('nested_eval');
is($status, 0, 'nested eval case exits successfully');
like($out, qr/nested_outer=0 main_saved=1 cleanup_slot=empty
outer_saved=1 main_still=1
/, 'nested eval preserves copied primary error after cleanup eval and outer die');

($status, $out) = run_case('parse_interface');
is($status, 0, 'parse interface case exits successfully');
like($out, qr/at_level=INFO signature_level=INFO\n/, '@_ and signatures wrappers parse the same line');
like($out, qr/scalar_ref=HASH list_count=1 list_ref=HASH\n/, 'parse_line returns one hash reference in scalar and list receivers');

($status, $out) = run_case('closure');
is($status, 0, 'closure case exits successfully');
like($out, qr/slow_error=1 warn_filter=0\nliteral_dot=1 bad_regex_like=0\nshared_error_after_warn=0 shared_warn=1\n/, 'independent closures keep copied conditions and shared global filters get polluted');

my $error_filter = make_filter(level => 'ERROR', min_duration_ms => 100, contains => 'disk.full');
my $warn_filter = make_filter(level => 'WARN', contains => 'disk.full');
ok($error_filter->({ level => 'ERROR', duration_ms => 101, message => 'disk.full' }), 'closure accepts matching record');
ok(!$error_filter->({ level => 'ERROR', duration_ms => 99, message => 'disk.full' }), 'closure rejects short duration');
ok(!$warn_filter->({ level => 'ERROR', duration_ms => 101, message => 'disk.full' }), 'independent closure keeps its own level');
ok(!$error_filter->({ level => 'ERROR', duration_ms => 101, message => 'diskXfull' }), 'contains is literal and does not treat dot as wildcard');

my $invalid = eval { make_filter(level => 'DEBUG'); 1 };
ok(!$invalid, 'invalid level is rejected when closure is built');
like($@, qr/level must be INFO/, 'invalid level diagnostic is stable');

done_testing;
