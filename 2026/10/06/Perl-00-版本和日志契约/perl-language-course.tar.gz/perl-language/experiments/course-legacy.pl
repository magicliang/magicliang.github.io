use strict;
use warnings;
use File::Temp qw(tempdir);
my $tmp = tempdir(CLEANUP => 1);
our $CURRENT_PATH = "$tmp/legacy.txt";
open my $out, '>', $CURRENT_PATH or die $!;
print {$out} "INFO api\n" or die $!;
close $out or die $!;
sub legacy_count {
    local (*FH, $_);
    open FH, $CURRENT_PATH or die $!;  # deliberate global path and two-argument open in isolated demo
    my $count = 0;
    $count++ while <FH>;
    close FH or die $!;
    return $count;
}
sub migrated_count {
    my ($file) = @_;
    open my $fh, '<', $file or die $!;
    my $count = 0;
    $count++ while <$fh>;
    close $fh or die $!;
    return $count;
}
print "legacy.old_count=" . legacy_count() . "\n";
print "legacy.new_count=" . migrated_count($CURRENT_PATH) . "\n";
print "legacy.global_dependency=removed_by_argument\n";
print "legacy.two_arg_open=replaced_by_three_arg_open\n";
print "legacy.global_filehandle=replaced_by_lexical_filehandle\n";
