use strict;
use warnings;

my @source = ('api');
my $alias = \@source;
my $copy = [@source];
push @$alias, 'worker';
push @$copy, 'cache';
print 'source=', join('|', @source), "\n";
print 'alias=', join('|', @$alias), "\n";
print 'copy=', join('|', @$copy), "\n";

my $item = { label => 'api' };
my $shallow_copy = [$item];
$shallow_copy->[0]{label} = 'changed';
print "shared=$item->{label}\n";
