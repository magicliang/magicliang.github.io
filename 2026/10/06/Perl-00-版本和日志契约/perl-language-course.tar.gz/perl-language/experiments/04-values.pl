use strict;
use warnings;

my @values = (undef, '', '0', 0, 'queued');
for my $index (0 .. $#values) {
    my $value = $values[$index];
    print "$index:defined=", defined($value) ? 1 : 0,
        ',truth=', $value ? 1 : 0, "\n";
}
my $message = '';
die "message missing\n" unless defined $message;
print "empty-message-accepted\n";
