use strict;
use warnings;

sub unsafe_fields {
    return ('api', 'queued');
}
sub stable_fields {
    return ['api', 'queued'];
}

my @list = unsafe_fields();
my $scalar = unsafe_fields();
my $record = stable_fields();
print 'list=', join('|', @list), "\n";
print "scalar=$scalar\n";
print 'ref=', ref($record), "\n";
print 'count=', scalar(@$record), "\n";
