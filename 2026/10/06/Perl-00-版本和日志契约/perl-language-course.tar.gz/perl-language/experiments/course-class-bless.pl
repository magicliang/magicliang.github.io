use strict;
use warnings;
use FindBin;
use File::Spec;
use IPC::Open3;
use Symbol 'gensym';
BEGIN {
    require FindBin;
    require File::Spec;
    my $root = File::Spec->catdir($FindBin::Bin, '..');
    unshift @INC, File::Spec->catdir($root, 'lib');
}
use LogTool::Course::Aggregator;

{
    package Course::BlessedRecord;
    sub new {
        my ($class, $level) = @_;
        return bless {level => $level}, $class;
    }
    sub level { return $_[0]->{level} }
}

sub run_class_record {
    my $source = <<'PERL';
use strict;
use warnings;
use FindBin;
use File::Spec;
BEGIN {
    require FindBin;
    require File::Spec;
    my $root = File::Spec->catdir($FindBin::Bin, '..');
    unshift @INC, File::Spec->catdir($root, 'lib');
}
use LogTool::Course::Aggregator;
{
    package Course::BlessedRecord;
    sub new {
        my ($class, $level) = @_;
        return bless {level => $level}, $class;
    }
    sub level { return $_[0]->{level} }
}
use feature "class";
class Course::ClassRecord {
    field $level :param;
    method level { $level }
}
my $classic = Course::BlessedRecord->new('INFO');
my $native = Course::ClassRecord->new(level => 'WARN');
my $aggregator = LogTool::Course::Aggregator->new;
$aggregator->add($classic);
$aggregator->add($native);
my $rows = join(',', map { "$_->{level}:$_->{count}" } @{$aggregator->rows});
print "classic_level=" . $classic->level . "\n";
print "class_level=" . $native->level . "\n";
print "rows=$rows\n";
my $deref = eval { my $x = $native->{level}; 1 } ? "hash_ok" : "hash_rejected";
print "class_hash_boundary=$deref\n";
PERL
    my $stderr = gensym;
    my $pid = open3(undef, my $stdout, $stderr, $^X, '-I', File::Spec->catdir($FindBin::Bin, '..', 'lib'), '-e', $source);
    binmode $stdout, ':raw';
    binmode $stderr, ':raw';
    local $/;
    my $out = <$stdout> // '';
    my $err = <$stderr> // '';
    waitpid($pid, 0);
    die "class subprocess failed: $err" if $? != 0;
    return ($out, $err);
}

my ($class_out, $class_err) = run_class_record();
my %class_data = map { split /=/, $_, 2 } grep { length } split /\n/, $class_out;

print "class_bless.classic_level=$class_data{classic_level}\n";
print "class_bless.class_level=$class_data{class_level}\n";
print "class_bless.rows=$class_data{rows}\n";
print "class_bless.class_hash_boundary=$class_data{class_hash_boundary}\n";
print "class_bless.warning=" . ($class_err =~ /class is experimental.*field is experimental.*method is experimental/s ? 'experimental_visible' : 'missing') . "\n";
print "class_bless.protocol=level_method\n";
