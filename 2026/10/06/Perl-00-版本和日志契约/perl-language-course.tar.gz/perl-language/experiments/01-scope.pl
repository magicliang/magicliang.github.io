use strict;
use warnings;

my $service = 'api';
{
    my $service = 'worker';
    print "inside=$service\n";
}
print "outside=$service\n";
