#!/usr/bin/env perl
use strict;
use warnings;
use Scalar::Util 'weaken';

{
    package CourseLifecycle::Node;
    use strict;
    use warnings;
    our @DESTROYED;
    sub new {
        my ($class, $name) = @_;
        return bless {name => $name}, $class;
    }
    sub link {
        my ($self, $other) = @_;
        $self->{other} = $other;
        return $self;
    }
    sub weak_link {
        my ($self, $other) = @_;
        $self->{other} = $other;
        Scalar::Util::weaken($self->{other});
        return $self;
    }
    sub DESTROY {
        my ($self) = @_;
        push @DESTROYED, $self->{name};
    }
}

{
    my $single = CourseLifecycle::Node->new('single');
}
print "single_destroyed=" . scalar(@CourseLifecycle::Node::DESTROYED) . "\n";

{
    my $left = CourseLifecycle::Node->new('cycle-left');
    my $right = CourseLifecycle::Node->new('cycle-right');
    $left->link($right);
    $right->link($left);
}
print "after_strong_cycle=" . scalar(@CourseLifecycle::Node::DESTROYED) . "\n";

{
    my $left = CourseLifecycle::Node->new('weak-left');
    my $right = CourseLifecycle::Node->new('weak-right');
    $left->link($right);
    $right->weak_link($left);
}
print "after_weak_cycle=" . scalar(@CourseLifecycle::Node::DESTROYED) . "\n";
