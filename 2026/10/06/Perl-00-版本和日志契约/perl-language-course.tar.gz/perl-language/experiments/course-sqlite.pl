use strict;
use warnings;
use FindBin;
use File::Spec;
use Config;
BEGIN {
    require FindBin;
    require File::Spec;
    my $root = File::Spec->catdir($FindBin::Bin, '..');
    my $local = File::Spec->catdir($root, 'vendor', 'perl-5.38.2-local', 'lib', 'perl5');
    unshift @INC,
        File::Spec->catdir($local, $Config::Config{archname}),
        $local;
}
use DBI;
my $dbh = DBI->connect('dbi:SQLite:dbname=:memory:', '', '', {RaiseError => 1, PrintError => 0, AutoCommit => 1});
$dbh->do('CREATE TABLE events(level TEXT NOT NULL, message TEXT NOT NULL)');
$dbh->begin_work;
$dbh->do('INSERT INTO events(level, message) VALUES (?, ?)', undef, 'INFO', 'kept');
$dbh->commit;
$dbh->begin_work;
$dbh->do('INSERT INTO events(level, message) VALUES (?, ?)', undef, 'ERROR', 'rollback');
$dbh->rollback;
print "sqlite.dbd_version=$DBD::SQLite::VERSION\n";
no warnings 'once';
print "sqlite.engine=$DBD::SQLite::sqlite_version\n";
use warnings;
print "sqlite.rows=" . $dbh->selectrow_array('SELECT COUNT(*) FROM events') . "\n";
my $payload = q{x' OR 1=1 --};
$dbh->do('INSERT INTO events(level, message) VALUES (?, ?)', undef, 'WARN', $payload);
print "sqlite.info=" . $dbh->selectrow_array('SELECT message FROM events WHERE level = ?', undef, 'INFO') . "\n";
print "sqlite.bound_payload=" . $dbh->selectrow_array('SELECT COUNT(*) FROM events WHERE message = ?', undef, $payload) . "\n";
print "sqlite.total_after_payload=" . $dbh->selectrow_array('SELECT COUNT(*) FROM events') . "\n";
$dbh->disconnect;
print "sqlite.disconnected=1\n";
