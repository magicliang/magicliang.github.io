use strict;
use warnings;

my $tree = {};
print 'before=', scalar(keys %$tree), "\n";
my $value = $tree->{missing}{count};
print 'after-read=', scalar(keys %$tree), "\n";
print 'created=', ref($tree->{missing}), "\n";

my $safe = {};
die "missing field\n" unless exists $safe->{missing};
