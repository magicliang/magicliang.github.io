use strict;
use warnings;

my @services = ('api', 'worker');
my @copy = @services;
push @copy, 'cache';
my @selected = @services[0, 1];
print 'source=', join('|', @services), "\n";
print 'copy=', join('|', @copy), "\n";
print 'slice=', join('|', @selected), "\n";
print 'length=', scalar(@services), "\n";
