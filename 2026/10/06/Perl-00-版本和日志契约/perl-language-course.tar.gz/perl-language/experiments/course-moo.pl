use strict;
use warnings;
use FindBin;
use File::Spec;
BEGIN {
    require FindBin;
    require File::Spec;
    my $root = File::Spec->catdir($FindBin::Bin, '..');
    my $local = File::Spec->catdir($root, 'vendor', 'perl-5.38.2-local', 'lib', 'perl5');
    unshift @INC,
        File::Spec->catdir($local, 'darwin-2level'),
        $local,
        File::Spec->catdir($root, 'lib');
}
use LogTool::Course::Aggregator;
use LogTool::Course::MooAggregator;
my @records = ({level => 'WARN'}, {level => 'INFO'}, {level => 'WARN'}, {level => 'ERROR'});
my $classic = LogTool::Course::Aggregator->new;
my $moo = LogTool::Course::MooAggregator->new;
$classic->add($_), $moo->add($_) for @records;
print "moo.version=$Moo::VERSION\n";
print "moo.rows=" . join(',', map { "$_->{level}:$_->{count}" } @{$moo->rows}) . "\n";
print "classic.rows=" . join(',', map { "$_->{level}:$_->{count}" } @{$classic->rows}) . "\n";
