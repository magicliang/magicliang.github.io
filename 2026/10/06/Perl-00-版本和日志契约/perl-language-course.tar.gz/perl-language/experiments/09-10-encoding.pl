use strict;
use warnings;
use utf8;
use Encode qw(decode encode FB_CROAK LEAVE_SRC);

my $source_literal = '重试';
my $bytes = encode('UTF-8', $source_literal, FB_CROAK | LEAVE_SRC);
my $decoded = decode('UTF-8', $bytes, FB_CROAK | LEAVE_SRC);
binmode STDOUT, ':raw' or die $!;
print STDOUT "characters=", length($source_literal), "\n";
print STDOUT "input-bytes=", length($bytes), "\n";
print STDOUT "decoded-characters=", length($decoded), "\n";
print STDOUT encode('UTF-8', "output=$decoded\n", FB_CROAK);
