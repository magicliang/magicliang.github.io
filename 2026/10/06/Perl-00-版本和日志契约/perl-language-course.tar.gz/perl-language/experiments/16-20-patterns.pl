use strict;
use warnings;

my ($chapter) = @ARGV;
die "choose chapter 16, 17, 18, 19 or 20\n"
    unless defined($chapter) && $chapter =~ /\A(?:16|17|18|19|20)\z/;

if ($chapter == 16) {
    for my $message ('id=abc-01', 'id=') {
        if ($message =~ /\A(?<key>[a-z]+)=(?<value>[a-z0-9-]+)\z/) {
            print "accepted:$+{key}:$+{value}\n";
        } else {
            print "rejected:$message\n";
        }
    }
} elsif ($chapter == 17) {
    my $text = 'a,b';
    while ($text =~ /([^,]+)/g) {
        print "capture=$1:pos=", pos($text), "\n";
    }
    print 'after-failure=', defined(pos($text)) ? pos($text) : 'undef', "\n";
    my $zero = 'ab';
    my @offsets;
    while ($zero =~ /(?=.)/g) {
        push @offsets, pos($zero);
        die "zero-length loop exceeded bound\n" if @offsets > 3;
    }
    print 'zero-width=', join(',', @offsets), "\n";
} elsif ($chapter == 18) {
    my $needle = 'a.b';
    my $text = 'aXb a.b';
    my ($unquoted) = $text =~ /($needle)/;
    my ($literal) = $text =~ /(\Q$needle\E)/;
    print "unquoted=$unquoted\nliteral=$literal\n";
} elsif ($chapter == 19) {
    for my $size (6, 8, 10) {
        my $input = ('a' x $size) . 'X';
        my $unsafe = $input =~ /\A(a+)+\z/;
        my $linear_shape = $input =~ /\Aa+\z/;
        my $partitions = 2 ** ($size - 1);
        print "size=$size:partitions=$partitions:rejected=",
            !$unsafe && !$linear_shape ? 1 : 0, "\n";
    }
} else {
    my $line = "2026-10-06T00:00:00Z\tINFO\tapi\tqueued again";
    my @fields = split /\t/, $line, -1;
    my @wrong = split /\s+/, $line;
    print 'tab-fields=', scalar(@fields), "\n";
    print 'whitespace-fields=', scalar(@wrong), "\n";
    print 'fixed-prefix=', substr('short', 0, 20), "\n";
}
