use strict;
use warnings;

sub describe_context {
    return wantarray ? ('api', 'worker') : defined(wantarray) ? 'one' : ();
}

my @services = describe_context();
my $service = describe_context();
describe_context();
print 'list=', join('|', @services), "\n";
print "scalar=$service\n";
print 'scalar-array=', scalar(@services), "\n";
print 'scalar-reverse=', scalar(reverse('a', 'b')), "\n";
print 'list-reverse=', join('|', reverse('a', 'b')), "\n";
