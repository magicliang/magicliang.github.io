#!/usr/bin/env perl
use strict;
use warnings;
use FindBin;
use lib "$FindBin::Bin/../lib";
use LogTool::Course::Aggregator;
use LogTool::Course::Output 'jsonl_report';

{
    package CourseComposition::InheritedAggregator;
    use strict;
    use warnings;
    our @ISA = ('LogTool::Course::Aggregator');

    sub add_error_alias {
        my ($self) = @_;
        $self->{counts}{ERROR}++;
        return $self;
    }
}

{
    package CourseComposition::JsonReporter;
    use strict;
    use warnings;

    sub new {
        my ($class, $aggregator) = @_;
        return bless {aggregator => $aggregator}, $class;
    }

    sub add {
        my ($self, $record) = @_;
        $self->{aggregator}->add($record);
        return $self;
    }

    sub jsonl {
        my ($self, $total) = @_;
        return LogTool::Course::Output::jsonl_report($total, $self->{aggregator}->rows);
    }
}

my @records = (
    {level => 'INFO'},
    {level => 'WARN'},
    {level => 'INFO'},
);

my $inherited = CourseComposition::InheritedAggregator->new;
$inherited->add($_) for @records;
$inherited->add_error_alias;
print "inheritance_rows="
    . join(',', map { "$_->{level}=$_->{count}" } @{$inherited->rows})
    . "\n";
print "inheritance_touches_internal_counts=1\n";

my $composed = CourseComposition::JsonReporter->new(LogTool::Course::Aggregator->new);
$composed->add($_) for @records;
my $jsonl = $composed->jsonl(scalar @records);
$jsonl =~ s/\n/|/g;
print "composition_jsonl=$jsonl\n";
print "composition_uses_rows_protocol=1\n";
