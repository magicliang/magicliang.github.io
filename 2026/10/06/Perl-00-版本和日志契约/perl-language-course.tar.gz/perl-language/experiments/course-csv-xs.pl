use strict;
use warnings;
use FindBin;
use File::Spec;
use Config;
use IPC::Open3;
use Symbol 'gensym';
BEGIN {
    require FindBin;
    require File::Spec;
    my $root = File::Spec->catdir($FindBin::Bin, '..');
    my $local = File::Spec->catdir($root, 'vendor', 'perl-5.38.2-local', 'lib', 'perl5');
    unshift @INC,
        File::Spec->catdir($local, $Config::Config{archname}),
        $local,
        File::Spec->catdir($root, 'vendor', 'lib', 'perl5');
}
use Text::CSV_XS ();
my $xs = Text::CSV_XS->new({binary => 1, eol => "\n"});
$xs->parse(qq{id,"two\nlines","a""b"}) or die $xs->error_diag;
my @fields = $xs->fields;
print "csv_xs.version=$Text::CSV_XS::VERSION\n";
print "csv_xs.fields=" . join('|', map { s/\n/\\n/gr } @fields) . "\n";
my $bad = $xs->parse(qq{id,"unterminated});
print "csv_xs.bad_record=" . ($bad ? 'accepted' : 'rejected') . "\n";

sub run_text_csv_child {
    my ($force_pp) = @_;
    my $code = <<'PERL';
use strict;
use warnings;
use Text::CSV;
my $csv = Text::CSV->new({binary => 1, eol => "\n"});
$csv->parse(qq{id,"two\nlines","a""b"}) or die $csv->error_diag;
print "backend=" . Text::CSV->backend . "\n";
print "fields=" . join('|', map { s/\n/\\n/gr } $csv->fields) . "\n";
PERL
    my $stderr = gensym;
    local $ENV{PERL5LIB} = join(':', @INC);
    local $ENV{PERL_TEXT_CSV};
    delete $ENV{PERL_TEXT_CSV};
    $ENV{PERL_TEXT_CSV} = 'Text::CSV_PP' if $force_pp;
    my $pid = open3(undef, my $stdout, $stderr, $^X, '-e', $code);
    binmode $stdout, ':raw';
    binmode $stderr, ':raw';
    local $/;
    my $out = <$stdout> // '';
    my $err = <$stderr> // '';
    waitpid($pid, 0);
    die "Text::CSV child failed: $err" if $? != 0;
    return $out;
}

my %auto = map { split /=/, $_, 2 } grep { length } split /\n/, run_text_csv_child(0);
my %pp = map { split /=/, $_, 2 } grep { length } split /\n/, run_text_csv_child(1);
print "csv_auto.backend=$auto{backend}\n";
print "csv_pp.backend=$pp{backend}\n";
print "csv_pp.fields=$pp{fields}\n";
