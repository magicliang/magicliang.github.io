#!/usr/bin/env perl
use strict;
use warnings;
use FindBin;
use lib "$FindBin::Bin/../lib";
use Config;
use File::Temp 'tempfile';
use LogTool::Runner 'run_probe';

my $normal = run_probe($^X, 'plain token');
print "normal_exit=$normal->{exit}\n";
print "normal_signal=$normal->{signal}\n";
print "normal_stdout=$normal->{stdout}";

my ($script, $path) = tempfile('course-process-XXXXXX', TMPDIR => 1, UNLINK => 0);
my $interpreter = $Config{perlpath} || $^X;
print {$script} "#!$interpreter\nkill 'TERM', \$\$;\n";
close $script or die $!;
chmod 0700, $path or die $!;

my $signaled = run_probe($path, 'ignored');
unlink $path;
print "signal_exit=$signaled->{exit}\n";
print "signal_number=$signaled->{signal}\n";
