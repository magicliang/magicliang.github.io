use strict;
use warnings;

sub mutate_argument {
    $_[0] = 'worker';
}
sub mutate_local_copy {
    my ($service) = @_;
    $service = 'cache';
    return $service;
}

my $service = 'api';
mutate_argument($service);
print "after-alias=$service\n";
print 'local=', mutate_local_copy($service), "\n";
print "after-copy=$service\n";
