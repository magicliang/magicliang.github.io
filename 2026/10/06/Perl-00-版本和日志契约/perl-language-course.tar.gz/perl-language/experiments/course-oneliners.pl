use strict;
use warnings;
use File::Temp qw(tempdir);
use IPC::Open3;
use Symbol 'gensym';

sub run_perl {
    my @args = @_;
    my $stderr = gensym;
    my $pid = open3(undef, my $stdout, $stderr, $^X, @args);
    binmode $stdout, ':raw';
    binmode $stderr, ':raw';
    local $/;
    my $out = <$stdout> // '';
    my $err = <$stderr> // '';
    waitpid($pid, 0);
    die "one-liner failed: @args\n$err" if $? != 0;
    return $out;
}

my $tmp = tempdir(CLEANUP => 1);
my $input = "$tmp/in.tsv";
open my $fh, '>', $input or die $!;
print {$fh} "INFO\tapi\nWARN\tworker\nINFO\tweb\n";
close $fh or die $!;

my $count_info = run_perl('-ane', 'print if $F[0] eq "INFO"', $input);

my $full_script = "$tmp/filter-info.pl";
open my $script_fh, '>', $full_script or die $!;
print {$script_fh} <<'SCRIPT';
use strict;
use warnings;
while (<>) {
    my @fields = split;
    print if $fields[0] eq "INFO";
}
SCRIPT
close $script_fh or die $!;
my $full_script_info = run_perl($full_script, $input);
my $edited = run_perl('-pe', 's/^WARN/ERROR/', $input);
$edited =~ s/\n/|/g;
my $fields = run_perl('-F\t', '-lane', 'print "$F[0]:$F[1]"', $input);
$fields =~ s/\n/,/g;

my $inplace = "$tmp/inplace.tsv";
open my $copy, '>', $inplace or die $!;
print {$copy} "WARN\tworker\n";
close $copy or die $!;
run_perl('-i.bak', '-pe', 's/^WARN/ERROR/', $inplace);
open my $new_fh, '<', $inplace or die $!;
my $new_text = do { local $/; <$new_fh> };
close $new_fh or die $!;
open my $bak_fh, '<', "$inplace.bak" or die $!;
my $bak_text = do { local $/; <$bak_fh> };
close $bak_fh or die $!;
chomp($new_text);
chomp($bak_text);

print "oneliner.n_a_count=" . (() = $count_info =~ /^INFO/mg) . "\n";
print "oneliner.full_script_equal=" . ($full_script_info eq $count_info ? 1 : 0) . "\n";
print "oneliner.p_edit=$edited\n";
print "oneliner.a_fields=$fields\n";
print "oneliner.inplace=$new_text\n";
print "oneliner.backup=$bak_text\n";
