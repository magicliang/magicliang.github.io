#!/usr/bin/env perl
use strict;
use warnings;
use utf8;
use Encode qw(decode encode FB_CROAK is_utf8);
use Unicode::Normalize qw(NFC);
use FindBin;
use lib "$FindBin::Bin/../lib";
use LogTool::Course qw(parse_line);
use LogTool::Course::Filter qw(make_filter);
use Time::HiRes qw(time);

binmode STDOUT, ':encoding(UTF-8)';
binmode STDERR, ':encoding(UTF-8)';

our $COURSE_LEVEL = 'INFO';
our %COURSE_SESSION = (current => { level => 'INFO' });
our %SHARED_CONDITIONS;

my $case = shift // 'all';
my %run = (
    variables      => \&variables,
    list_context   => \&list_context,
    scope          => \&scope,
    filter_forms   => \&filter_forms,
    comparison     => \&comparison,
    refs           => \&refs,
    unicode        => \&unicode,
    regex          => \&regex,
    backtracking   => \&backtracking,
    eval_errors    => \&eval_errors,
    nested_eval    => \&nested_eval,
    parse_interface => \&parse_interface,
    closure        => \&closure,
);

die "unknown case: $case\n" if $case ne 'all' && !exists $run{$case};

if ($case eq 'all') {
    for my $name (qw(variables list_context scope filter_forms comparison refs unicode regex backtracking eval_errors nested_eval parse_interface closure)) {
        print "[$name]\n";
        $run{$name}->();
    }
} else {
    $run{$case}->();
}

sub variables {
    my $service = 'api';
    my @levels = qw(INFO WARN);
    my %count = (INFO => 2, WARN => 1);
    print "scalar=$service\n";
    print "array_count=" . scalar(@levels) . " array_last=$levels[-1]\n";
    print "hash_INFO=$count{INFO}\n";
}

sub list_context {
    my @list_reverse = reverse qw(a b);
    my $scalar_reverse = reverse 'ab';
    my @observed;
    my $context_probe = sub {
        push @observed, defined(wantarray) ? (wantarray ? 'list' : 'scalar') : 'void';
        return qw(left right);
    };
    my @list = $context_probe->();
    my $scalar = $context_probe->();
    $context_probe->();
    print "list_reverse=" . join('|', @list_reverse) . " scalar_reverse=$scalar_reverse\n";
    print "context_seen=" . join('|', @observed) . " list_count=" . scalar(@list) . " scalar=$scalar\n";
}

sub scope {
    my $COURSE_LEVEL = 'LEXICAL';
    print "my=$COURSE_LEVEL our=$main::COURSE_LEVEL\n";
    {
        local $main::COURSE_LEVEL = 'WARN';
        print "local_inside=$main::COURSE_LEVEL\n";
    }
    print "local_after=$main::COURSE_LEVEL\n";
}

sub filter_forms {
    my @records = (
        { level => 'INFO', service => 'api', duration_ms => 12 },
        { level => 'WARN', service => 'worker', duration_ms => 40 },
    );
    my @loop;
    for my $record (@records) {
        push @loop, $record->{service} if $record->{level} eq 'INFO';
    }
    my @grep = grep { $_->{level} eq 'INFO' } @records;
    my @map = map { +{ %$_, service => uc $_->{service} } } @records;
    my @alias_input = map { +{ %$_ } } @records;
    my @alias_selected = grep { $_->{service} = uc $_->{service}; $_->{level} eq 'INFO' } @alias_input;
    print "loop=@loop\n";
    print "grep=" . join('|', map { $_->{service} } @grep) . "\n";
    print "map_copy=" . join('|', map { $_->{service} } @map) . "\n";
    print "source=" . join('|', map { $_->{service} } @records) . "\n";
    print "grep_alias_source=" . join('|', map { $_->{service} } @alias_input) . " selected=" . join('|', map { $_->{service} } @alias_selected) . "\n";
}

sub comparison {
    my $level = 'INFO';
    my $duration = 0;
    my $missing;
    my $default = defined($missing) ? $missing : 'fallback';
    my $wrong_default = $duration || 99;
    my $kept_zero = defined($duration) ? $duration : 99;
    my $bad_numeric = eval { no warnings 'numeric'; ($level == 'INFO') ? 1 : 0 };
    my $missing_duration;
    my $grouped = defined($missing_duration) && ($missing_duration == 0 || $level eq 'INFO') ? 1 : 0;
    my $ungrouped = (defined($missing_duration) && $missing_duration == 0 || $level eq 'INFO') ? 1 : 0;
    print "string_eq=" . ($level eq 'INFO' ? 1 : 0) . " numeric_eq=$bad_numeric\n";
    print "default=$default wrong_default=$wrong_default kept_zero=$kept_zero grouped=$grouped ungrouped=$ungrouped\n";
}

sub refs {
    my $record = { level => 'INFO', nested => { count => 1 } };
    my $alias = $record;
    my $copy = { %$record, nested => { %{ $record->{nested} } } };
    $alias->{level} = 'WARN';
    $copy->{nested}{count} = 9;
    my $tree = {};
    my $before = scalar keys %$tree;
    my $value = $tree->{missing}{count};
    print "alias_level=$record->{level}\n";
    print "copy_nested=$record->{nested}{count}/$copy->{nested}{count}\n";
    print "autoviv_before=$before after=" . join('|', sort keys %$tree) . " value=" . (defined($value) ? $value : 'undef') . "\n";
    {
        local $COURSE_SESSION{current}{level} = 'WARN';
        print "local_nested_inside=$COURSE_SESSION{current}{level}\n";
    }
    my %next_batch = (current => { level => 'ERROR' });
    print "local_nested_after=$COURSE_SESSION{current}{level} next_batch=$next_batch{current}{level}\n";
}

sub unicode {
    my $source_text = "日志";
    my $encode_check = 1;
    my $bytes = encode('UTF-8', $source_text, $encode_check);
    my $byte_count = length($bytes);
    my $bytes_for_decode = $bytes;
    my $decode_check = 1;
    my $text = decode('UTF-8', $bytes_for_decode, $decode_check);
    my $nfd = "e\x{301}";
    my $nfc = NFC($nfd);
    my @codepoints = split //, $nfd;
    my @graphemes = ($nfd =~ /\X/g);
    my $double_decode = eval { my $again_check = 1; decode('UTF-8', $text, $again_check); 1 } ? 'ok' : 'error';
    print "decoded_chars=" . length($text) . " bytes=$byte_count\n";
    print "nfc_equal=" . ($nfc eq "\x{e9}" ? 1 : 0) . " codepoints=" . scalar(@codepoints) . " graphemes=" . scalar(@graphemes) . "\n";
    print "double_decode=$double_decode utf8_flag=" . (is_utf8($text) ? 1 : 0) . "\n";
}

sub regex {
    my $message = 'id=abc-01';
    if ($message =~ /\Aid=([a-z0-9-]+)\z/) {
        print "capture=$1\n";
    }
    my $failed = ('id=' =~ /\Aid=([a-z0-9-]+)\z/) ? 'matched' : 'failed';
    print "failed=$failed old_capture=$1\n";

    my $csv = 'a,b';
    my @parts;
    while ($csv =~ /([^,]+)/g) {
        push @parts, "$1@" . pos($csv);
    }
    print "g_parts=" . join('|', @parts) . " final_pos=" . (defined(pos($csv)) ? pos($csv) : 'undef') . "\n";

    my $gc = 'a,b';
    $gc =~ /([^,]+)/gc;
    my $gc_before = pos($gc);
    my $gc_failed = ($gc =~ /\G;/gc) ? 'matched' : 'failed';
    print "gc_failed=$gc_failed before=$gc_before after=" . (defined(pos($gc)) ? pos($gc) : 'undef') . "\n";

    my $needle = 'a.b';
    my $haystack = 'aXb a.b';
    $haystack =~ /$needle/;
    print "unquoted=$&\n";
    $haystack =~ /\Q$needle\E/;
    print "literal=$&\n";

    my $original_message = 'token=abc123 keep';
    my $redacted_message = $original_message;
    $redacted_message =~ s/token=\w+/token=[REDACTED]/;
    print "redacted=$redacted_message original=$original_message\n";

    my @g_list = ('a,b' =~ /([^,]+)/g);
    my $g_scalar = ('a,b' =~ /([^,]+)/g) ? 1 : 0;
    'service=api' =~ /\A(?<name>[a-z]+)=(?<value>[a-z]+)\z/;
    my @zero_offsets;
    my $zero = 'ab';
    while ($zero =~ /(?=.)/g) {
        push @zero_offsets, pos($zero);
        last if @zero_offsets > 4;
    }
    print "g_list=" . join('|', @g_list) . " scalar_first=$g_scalar named=$+{name}:$+{value} zero=" . join('|', @zero_offsets) . "\n";
}

sub backtracking {
    for my $size (6, 8, 10) {
        my $input = ('a' x $size) . 'X';
        my $start = time;
        my $rejected = ($input =~ /\A(a+)+\z/) ? 0 : 1;
        my $elapsed_us = int((time - $start) * 1_000_000 + 0.5);
        my $partitions = 2 ** ($size - 1);
        print "size=$size partitions=$partitions rejected=$rejected elapsed_us=$elapsed_us\n";
    }
}

sub eval_errors {
    my $ok = eval { die "inner failure\n"; 1 };
    my $first_error = $@;
    my $second = eval { 1 };
    my $after_success = $@;
    print "eval_ok=" . ($ok ? 1 : 0) . " first=" . ($first_error =~ /inner failure/ ? 1 : 0) . "\n";
    print "eval_success=$second after_success=" . ($after_success eq '' ? 'empty' : 'set') . " saved=" . ($first_error =~ /inner failure/ ? 1 : 0) . "\n";
}

sub nested_eval {
    my $main_error;
    my $cleanup_error;
    my $outer = eval {
        eval { die "main failure\n"; 1 };
        $main_error = $@;
        eval { 1 };
        $cleanup_error = $@;
        die "outer failure after cleanup\n";
    };
    my $outer_error = $@;
    print "nested_outer=" . ($outer ? 1 : 0) . " main_saved=" . ($main_error =~ /main failure/ ? 1 : 0) . " cleanup_slot=" . ($cleanup_error eq '' ? 'empty' : 'set') . "\n";
    print "outer_saved=" . ($outer_error =~ /outer failure/ ? 1 : 0) . " main_still=" . ($main_error =~ /main failure/ ? 1 : 0) . "\n";
}

sub parse_interface {
    my $line = "2026-10-12T00:00:00Z	INFO	api	42	queued";
    my $from_at = parse_line_from_at($line);
    my $signature_parser = eval q{
        use feature "signatures";
        no warnings "experimental::signatures";
        sub ($line) { LogTool::Course::parse_line($line) }
    };
    die $@ if $@;
    my $from_signature = $signature_parser->($line);
    my $scalar = parse_line($line);
    my @list = parse_line($line);
    print "at_level=$from_at->{level} signature_level=$from_signature->{level}\n";
    print "scalar_ref=" . ref($scalar) . " list_count=" . scalar(@list) . " list_ref=" . ref($list[0]) . "\n";
}

sub parse_line_from_at {
    my ($line) = @_;
    return parse_line($line);
}

sub closure {
    my $slow_error = make_filter(level => 'ERROR', min_duration_ms => 100, contains => 'disk.full');
    my $warn_literal_dot = make_filter(level => 'WARN', contains => 'a.b');
    my %error_record = (level => 'ERROR', duration_ms => 120, message => 'disk.full on /data');
    my %warn_record = (level => 'WARN', duration_ms => 3, message => 'aXb then a.b');
    my %bad_record = (level => 'ERROR', duration_ms => 120, message => 'diskXfull');
    print "slow_error=" . $slow_error->(\%error_record) . " warn_filter=" . $slow_error->(\%warn_record) . "\n";
    print "literal_dot=" . $warn_literal_dot->(\%warn_record) . " bad_regex_like=" . $warn_literal_dot->(\%bad_record) . "\n";

    my $shared_error = make_shared_filter(level => 'ERROR');
    my $shared_warn = make_shared_filter(level => 'WARN');
    print "shared_error_after_warn=" . ($shared_error->(\%error_record) ? 1 : 0) . " shared_warn=" . ($shared_warn->(\%warn_record) ? 1 : 0) . "\n";
}

sub make_shared_filter {
    %SHARED_CONDITIONS = @_;
    return sub {
        my ($record) = @_;
        return $record->{level} eq $SHARED_CONDITIONS{level};
    };
}
