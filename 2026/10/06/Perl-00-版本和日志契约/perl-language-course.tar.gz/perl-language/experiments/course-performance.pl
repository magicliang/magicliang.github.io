#!/usr/bin/env perl
use strict;
use warnings;
use FindBin;
use lib "$FindBin::Bin/../lib";
use Digest::SHA 'sha256_hex';
use Time::HiRes 'time';
use LogTool::Course::Aggregator qw(aggregate_rows);
use LogTool::Course::Output 'tsv_report';

my $mode = 'both';
if (@ARGV) {
    die "usage: course-performance.pl [--mode naive|aggregator]\n"
        unless @ARGV == 2 && $ARGV[0] eq '--mode'
            && $ARGV[1] =~ /\A(?:naive|aggregator)\z/;
    $mode = $ARGV[1];
}

my @levels = qw(INFO WARN ERROR INFO);
my @records = map {
    {level => $levels[$_ % @levels], message => "record $_"}
} 0 .. 4999;

sub naive_rows {
    my ($records) = @_;
    my %naive;
    for my $level (qw(ERROR INFO WARN)) {
        $naive{$level} = scalar grep { $_->{level} eq $level } @$records;
    }
    return [
        map { {level => $_, count => $naive{$_}} } sort keys %naive
    ];
}

sub run_strategy {
    my ($name) = @_;
    my $start = time;
    my $rows = $name eq 'naive' ? naive_rows(\@records) : aggregate_rows(\@records);
    my $elapsed = time - $start;
    my $tsv = tsv_report(scalar(@records), $rows);
    print "strategy=$name\n";
    print "records=" . scalar(@records) . "\n";
    print "rows=" . join(',', map { "$_->{level}=$_->{count}" } @$rows) . "\n";
    print "output_sha256=" . sha256_hex($tsv) . "\n";
    printf "elapsed_seconds=%.6f\n", $elapsed;
    return ($rows, $tsv, $elapsed);
}

if ($mode ne 'both') {
    run_strategy($mode);
    exit 0;
}

my ($naive_rows, $naive_tsv, $naive_elapsed) = run_strategy('naive');
my ($rows, $aggregate_tsv, $aggregate_elapsed) = run_strategy('aggregator');

print "aggregator_rows=" . join(',', map { "$_->{level}=$_->{count}" } @$rows) . "\n";
print "output_equal=" . ($naive_tsv eq $aggregate_tsv ? 1 : 0) . "\n";
print "output_sha256=" . sha256_hex($aggregate_tsv) . "\n";
printf "naive_seconds=%.6f\n", $naive_elapsed;
printf "aggregator_seconds=%.6f\n", $aggregate_elapsed;
