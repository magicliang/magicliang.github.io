use strict;
use warnings;
use B qw(svref_2object class main_root);
use IPC::Open3;
use Symbol 'gensym';

my $array = [1, 2];
my $hash = {INFO => 2};
my $scalar = 'INFO';
print "internals.sv=" . class(svref_2object(\$scalar)) . "\n";
print "internals.av=" . class(svref_2object($array)) . "\n";
print "internals.hv=" . class(svref_2object($hash)) . "\n";
print "internals.op_root=" . main_root->name . "\n";
print "internals.refcount_boundary=diagnostic_only\n";

my $stderr = gensym;
my $pid = open3(undef, my $stdout, $stderr, $^X, '-MDevel::Peek', '-e', 'my $s = "INFO"; Dump($s)');
binmode $stdout, ':raw';
binmode $stderr, ':raw';
local $/;
my $peek_out = <$stdout> // '';
my $peek_err = <$stderr> // '';
waitpid($pid, 0);
die "Devel::Peek failed\n$peek_err" if $? != 0;
my $peek = $peek_out . $peek_err;
print "internals.peek_has_pv=" . ($peek =~ /\bPV\b/ ? 1 : 0) . "\n";
print "internals.peek_has_refcnt=" . ($peek =~ /REFCNT/ ? 1 : 0) . "\n";

my $concise_err = gensym;
my $concise_pid = open3(undef, my $concise_out_fh, $concise_err, $^X, '-MO=Concise,-exec', '-e', 'my ($x, $y) = (1, 2); print $x + $y');
binmode $concise_out_fh, ':raw';
binmode $concise_err, ':raw';
my $concise_out = <$concise_out_fh> // '';
my $concise_diag = <$concise_err> // '';
waitpid($concise_pid, 0);
die "B::Concise failed\n$concise_diag" if $? != 0;
my $concise = $concise_out . $concise_diag;
print "internals.concise_has_const=" . ($concise =~ /const/ ? 1 : 0) . "\n";
print "internals.concise_has_add=" . ($concise =~ /add/ ? 1 : 0) . "\n";
