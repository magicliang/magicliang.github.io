#!/usr/bin/env perl
use strict;
use warnings;
use Config;
use Cwd qw(abs_path getcwd);
use Digest::SHA ();
use File::Basename 'dirname';
use File::Path 'make_path';
use File::Spec;
use File::Temp 'tempdir';
use Getopt::Long qw(GetOptions);

sub usage {
    return "usage: $0 --prefix DIR [--build-dir EMPTY_DIR] [--skip-tests]\n";
}

my $prefix;
my $build_dir;
my $skip_tests = 0;
my $help = 0;
GetOptions(
    'prefix=s' => \$prefix,
    'build-dir=s' => \$build_dir,
    'skip-tests' => \$skip_tests,
    'help' => \$help,
) or die usage();
if ($help) {
    print usage();
    exit 0;
}
die usage() if @ARGV;
die usage() unless defined $prefix && length $prefix;

my $perl = abs_path($^X) || $Config::Config{perlpath} || $^X;
$prefix = File::Spec->rel2abs($prefix);
$build_dir = File::Spec->rel2abs($build_dir) if defined $build_dir;

my $script = abs_path($0) or die "cannot resolve script path\n";
my $root = abs_path(File::Spec->catdir(dirname($script), '..')) or die "cannot resolve course root\n";
my $dist_dir = File::Spec->catdir($root, 'vendor', 'dist');
if (defined $build_dir) {
    if (-e $build_dir) {
        opendir my $dh, $build_dir or die "cannot read build-dir $build_dir: $!\n";
        my @entries = grep { $_ ne '.' && $_ ne '..' } readdir $dh;
        closedir $dh;
        die "build-dir must be empty: $build_dir\n" if @entries;
    } else {
        make_path($build_dir);
    }
} else {
    $build_dir = tempdir('perl-course-deps-build-XXXXXX', TMPDIR => 1, CLEANUP => 0);
}
make_path($prefix);

my @dists = (
    ['DBI-1.655.tgz', '735a42a82e5a866b57869f8b92bf218f58c7fb62f75d6707a6345142d152762f'],
    ['DBD-SQLite-1.78.tar.gz', 'efbad7794bafaa4e7476c07445a33bbfe1040e380baa3395a02635eebe3859d5'],
    ['Class-Method-Modifiers-2.15.tar.gz', '65cd85bfe475d066e9186f7a8cc636070985b30b0ebb1cde8681cf062c2e15fc'],
    ['Role-Tiny-2.002004.tar.gz', 'd7bdee9e138a4f83aa52d0a981625644bda87ff16642dfa845dcb44d9a242b45'],
    ['Sub-Quote-2.006008.tar.gz', '94bebd500af55762e83ea2f2bc594d87af828072370c7110c60c238a800d15b2'],
    ['Moo-2.005005.tar.gz', 'fb5a2952649faed07373f220b78004a9c6aba387739133740c1770e9b1f4b108'],
    ['Text-CSV_XS-1.64.tgz', '65c5662d4fe8ef3039a1b32f641634d0aae6ab10eabbb24f740c75332f2caf30'],
);

my $lib = File::Spec->catdir($prefix, 'lib', 'perl5');
my $arch = File::Spec->catdir($lib, $Config::Config{archname});
my $env_lib = join ':', grep { length } ($arch, $lib, $ENV{PERL5LIB} // '');
local $ENV{PERL5LIB} = $env_lib;

sub run {
    my (@cmd) = @_;
    system @cmd;
    die "command failed (@cmd): exit " . ($? >> 8) . " signal " . ($? & 127) . "\n" if $? != 0;
}

for my $dist (@dists) {
    my ($file, $sha) = @$dist;
    my $path = File::Spec->catfile($dist_dir, $file);
    open my $fh, '<:raw', $path or die "cannot open $path: $!\n";
    my $actual = Digest::SHA->new(256)->addfile($fh)->hexdigest;
    die "sha256 mismatch for $file\n" unless $actual eq $sha;
    run('tar', '-xf', $path, '-C', $build_dir);
    (my $dir = $file) =~ s/\.t(?:ar\.)?gz\z//;
    my $cwd = getcwd();
    chdir File::Spec->catdir($build_dir, $dir) or die "cannot chdir $dir: $!\n";
    run($perl, 'Makefile.PL', "INSTALL_BASE=$prefix");
    run('make');
    run('make', 'test') unless $skip_tests;
    run('make', 'install');
    chdir $cwd or die "cannot restore cwd: $!\n";
    print "installed $file into $prefix\n";
}

print "PERL=$perl\n";
print "PERL5LIB=$arch:$lib\n";
