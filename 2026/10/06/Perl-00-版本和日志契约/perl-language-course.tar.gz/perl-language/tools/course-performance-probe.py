#!/usr/bin/env python3
import json
import os
import resource
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PERL = os.environ.get("PERL", "perl")
SCRIPT = ROOT / "experiments" / "course-performance.pl"


def run_with_usage(strategy):
    stdout_reader, stdout_writer = os.pipe()
    stderr_reader, stderr_writer = os.pipe()
    start = time.perf_counter()
    pid = os.fork()
    if pid == 0:
        os.close(stdout_reader)
        os.close(stderr_reader)
        os.dup2(stdout_writer, 1)
        os.dup2(stderr_writer, 2)
        os.close(stdout_writer)
        os.close(stderr_writer)
        os.chdir(ROOT)
        os.execvp(PERL, [PERL, str(SCRIPT), "--mode", strategy])
    os.close(stdout_writer)
    os.close(stderr_writer)
    waited_pid, status, usage = os.wait4(pid, 0)
    elapsed = time.perf_counter() - start
    assert waited_pid == pid
    stdout = os.read(stdout_reader, 1_000_000).decode("utf-8", "replace")
    stderr = os.read(stderr_reader, 1_000_000).decode("utf-8", "replace")
    os.close(stdout_reader)
    os.close(stderr_reader)
    parsed = {}
    for line in stdout.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            parsed[key] = value
    return {
        "strategy": strategy,
        "exit": status >> 8,
        "signal": status & 0x7F,
        "elapsed_seconds": round(elapsed, 6),
        "ru_maxrss": usage.ru_maxrss,
        "stdout": parsed,
        "stderr": stderr,
    }


def main():
    results = [run_with_usage("naive"), run_with_usage("aggregator")]
    hashes = [item["stdout"].get("output_sha256") for item in results]
    rss_unit = "bytes" if sys.platform == "darwin" else "KiB on Linux, platform-defined elsewhere"
    report = {
        "perl": PERL,
        "script": str(SCRIPT),
        "rss_unit": rss_unit,
        "sha_equal": all(hashes) and len(set(hashes)) == 1,
        "output_sha256": hashes,
        "results": results,
    }
    print(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2))
    if not report["sha_equal"] or any(item["exit"] or item["signal"] for item in results):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
