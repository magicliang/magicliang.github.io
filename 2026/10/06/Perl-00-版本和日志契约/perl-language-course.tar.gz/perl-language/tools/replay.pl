#!/usr/bin/env perl
use strict;
use warnings;
use FindBin;
use lib "$FindBin::Bin/../lib";
use Getopt::Long qw(GetOptions);
use File::Temp qw(tempdir);
use JSON::PP;
use Digest::SHA qw(sha256_hex);
my $case;
GetOptions('case=s' => \$case) or die "invalid replay options\n";
die "usage: perl tools/replay.pl --case all\n" unless defined($case) && $case eq 'all' && !@ARGV;
my $root = "$FindBin::Bin/..";
my $temporary = tempdir(CLEANUP => 1);
my @observed;
sub bytes {
    my ($path) = @_;
    open my $fh, '<:raw', $path or die "read $path: $!";
    local $/;
    my $data = <$fh> // '';
    close $fh or die $!;
    return $data;
}
sub put {
    my ($path, $data) = @_;
    open my $fh, '>:raw', $path or die $!;
    print {$fh} $data or die $!;
    close $fh or die $!;
}
sub run {
    my ($name, $expected, @args) = @_;
    return execute($name, $expected, $^X, "$root/bin/logtool", @args);
}
sub execute {
    my ($name, $expected, @command) = @_;
    my $pid = fork;
    die "fork: $!" unless defined($pid);
    if (!$pid) {
        open STDOUT, '>:raw', "$temporary/$name.stdout" or die $!;
        open STDERR, '>:raw', "$temporary/$name.stderr" or die $!;
        exec {$command[0]} @command;
        die "exec: $!";
    }
    waitpid($pid, 0) == $pid or die $!;
    my $status = $?;
    my ($out, $err) = (bytes("$temporary/$name.stdout"), bytes("$temporary/$name.stderr"));
    my $result = {case => $name, command => \@command,
        exit => $status >> 8, signal => $status & 127,
        stdout => $out, stderr => $err, stdout_sha256 => sha256_hex($out)};
    push @observed, $result;
    die "case $name unexpected status $status\n" if $result->{signal} || $result->{exit} != $expected;
    die "case $name unexpected stderr\n" if $expected == 0 && length($err);
    die "case $name missing diagnostic\n" if $expected != 0 && !length($err);
    return $out;
}
my $accepted = "$temporary/accepted.jsonl";
my $rejects = "$temporary/rejected.jsonl";
run('version', 0, '--version');
my $summary = run('import', 0, 'import', '--input', "$root/fixtures/course.tsv", '--output', $accepted, '--rejects', $rejects);
die "conservation summary differs\n" unless $summary eq "INPUT\t5\nACCEPTED\t4\nREJECTED\t1\n";
my $all = run('query-all', 0, 'query', '--input', $accepted);
die "query changed JSON bytes\n" unless $all eq bytes($accepted);
my $zero = run('query-zero', 0, 'query', '--input', $accepted, '--min-duration', '0');
die "null duration must not pass numeric filter\n" unless scalar(grep { length } split /\n/, $zero) == 3;
my $literal = run('literal-pattern', 0, 'query', '--input', $accepted, '--contains', '.*');
die "literal pattern changed meaning\n" unless scalar(grep { length } split /\n/, $literal) == 1;
{
    my $report = run('report', 0, 'report', '--input', $accepted);
    die "report gold differs\n" unless $report eq "TOTAL\t4\nERROR\t1\nINFO\t2\nWARN\t1\n";
}
run('unknown-option', 2, 'query', '--input', $accepted, '--unknown');
run('missing-option', 2, 'query', '--input');
run('invalid-level', 2, 'query', '--input', $accepted, '--level', 'INVALID');
run('negative-duration', 2, 'query', '--input', $accepted, '--min-duration', '-1');
run('missing-file', 2, 'report', '--input', "$temporary/missing");
run('input-output-alias', 2, 'report', '--input', $accepted, '--output', $accepted);
run('output-pair-alias', 2, 'import', '--input', "$root/fixtures/course.tsv", '--output', $accepted, '--rejects', $accepted);
put("$temporary/bad-byte.tsv", "\xff\n");
put("$temporary/report.tsv", "OLD\n");
run('bad-byte', 2, 'import', '--input', "$temporary/bad-byte.tsv", '--output', $accepted, '--rejects', $rejects);
run('bad-json', 2, 'report', '--input', "$temporary/bad-byte.tsv", '--output', "$temporary/report.tsv");
die "old report changed\n" unless bytes("$temporary/report.tsv") eq "OLD\n";
run('directory-output', 2, 'report', '--input', $accepted, '--output', $temporary);
run('missing-parent', 2, 'report', '--input', $accepted, '--output', "$temporary/no-parent/report");
put("$temporary/empty.tsv", '');
run('empty-import', 0, 'import', '--input', "$temporary/empty.tsv", '--output', "$temporary/empty.jsonl", '--rejects', "$temporary/empty.rejects");
die "empty query is not empty\n" if length run('empty-query', 0, 'query', '--input', "$temporary/empty.jsonl");
push @observed, {case => 'artifacts', accepted_sha256 => sha256_hex(bytes($accepted)), rejected_sha256 => sha256_hex(bytes($rejects))};
execute('kernel-faults', 0, 'python3', "$root/tools/cli-faults.py", '--perl', $^X);
execute('input-faults', 0, $^X, "$root/t/course-input-faults.t");
execute('data-contract', 0, $^X, "$root/t/course-core.t");
execute('worker-and-lifecycle', 0, $^X, "$root/t/course-engineering.t");
print JSON::PP->new->canonical->pretty->encode(\@observed);
