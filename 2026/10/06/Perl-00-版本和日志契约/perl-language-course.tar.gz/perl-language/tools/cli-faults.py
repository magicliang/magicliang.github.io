import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument("--perl", required=True)
args = parser.parse_args()
project = Path(__file__).resolve().parents[1]
cli = project / "bin/logtool"
records = []

def observe(name, command, **options):
    result = subprocess.run(command, stderr=subprocess.PIPE, timeout=30, **options)
    record = {"case": name, "command": list(map(str, command)), "exit": result.returncode,
              "stderr": result.stderr.decode("utf-8", errors="replace")}
    if isinstance(result.stdout, bytes):
        record["stdout"] = result.stdout.decode("utf-8")
    records.append(record)
    return result

with tempfile.TemporaryDirectory(prefix="perl-cli-faults-") as directory:
    root = Path(directory)
    accepted = root / "accepted.jsonl"
    rejected = root / "rejected.jsonl"
    imported = observe("prepare", [args.perl, cli, "import", "--input", project / "fixtures/course.tsv",
                                  "--output", accepted, "--rejects", rejected], stdout=subprocess.PIPE)
    assert imported.returncode == 0 and not imported.stderr
    read_fd, write_fd = os.pipe()
    os.close(read_fd)
    try:
        broken = observe("broken-pipe", [args.perl, cli, "report", "--input", accepted], stdout=write_fd)
    finally:
        os.close(write_fd)
    assert broken.returncode == 2 and b"stdout" in broken.stderr

    def limited():
        signal.signal(signal.SIGXFSZ, signal.SIG_IGN)
        resource.setrlimit(resource.RLIMIT_FSIZE, (8, 8))

    report = root / "report.tsv"
    old = b"OLD REPORT\n"
    report.write_bytes(old)
    failed = observe("report-close-failure", [args.perl, cli, "report", "--input", accepted, "--output", report],
                     stdout=subprocess.PIPE, preexec_fn=limited)
    assert failed.returncode == 2 and report.read_bytes() == old
    records[-1]["old_report_sha256"] = hashlib.sha256(report.read_bytes()).hexdigest()
    records[-1]["old_report_preserved"] = True
    with (root / "stdout-file").open("wb") as sink:
        flushed = observe("stdout-close-failure", [args.perl, cli, "query", "--input", accepted],
                          stdout=sink, preexec_fn=limited)
    assert flushed.returncode == 2 and b"stdout" in flushed.stderr
    # Opening a FIFO pairs with the reader; keeping it open without bytes blocks
    # sysread, so natural EOF cannot race with the externally delivered signal.
    json_path = root / "blocked.jsonl"
    os.mkfifo(json_path)
    child = subprocess.Popen([args.perl, cli, "query", "--input", json_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    with json_path.open("wb", buffering=0):
        child.send_signal(signal.SIGTERM)
        _, error = child.communicate(timeout=30)
        assert child.returncode == -signal.SIGTERM
    records.append({"case": "external-term", "exit": child.returncode,
                    "stderr": error.decode("utf-8", errors="replace")})
print(json.dumps(records, ensure_ascii=False, indent=2))
