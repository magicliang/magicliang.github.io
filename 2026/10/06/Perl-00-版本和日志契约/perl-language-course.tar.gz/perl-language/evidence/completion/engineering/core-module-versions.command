cwd=/Users/magicliang/Desktop/Programming/git/hexo-blog
perl -MConfig -MJSON::PP -MStorable -MScalar::Util -MTime::HiRes -e 'print "Config=$Config::VERSION
JSON::PP=$JSON::PP::VERSION
Storable=$Storable::VERSION
Scalar::Util=$Scalar::Util::VERSION
Time::HiRes=$Time::HiRes::VERSION
"'
