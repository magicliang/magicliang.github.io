# Perl dependency and distribution verification commands

## Fixed paths

- Perl: `/private/tmp/perl-5.38.2-independent/install/bin/perl`
- Archname: `darwin-2level`
- Fresh distribution work directory: `/private/tmp/perl-course-dist-final-6708`
- Fresh distribution install prefix for root independent verification: `/private/tmp/perl-course-dist-final-6708/install`
- Final installed module identity: `/private/tmp/perl-course-dist-final-6708/install/lib/perl5/LogTool/Course.pm`

## Source archive SHA verification

Evidence: command output was checked during the final lane; every `vendor/dist` archive SHA matched `COURSE-DEPENDENCIES.md`, including `Text-CSV_XS-1.64.tgz` as `65c5662d4fe8ef3039a1b32f641634d0aae6ab10eabbb24f740c75332f2caf30`.

## Backend/version probe

Evidence files: `backend-versions-final.stdout`, `backend-versions-final.stderr`.

```bash
PERL=/private/tmp/perl-5.38.2-independent/install/bin/perl
ARCH="$($PERL -MConfig -e 'print $Config::Config{archname}')"
DEPS="$PWD/examples/perl-language/vendor/perl-5.38.2-local/lib/perl5/$ARCH:$PWD/examples/perl-language/vendor/perl-5.38.2-local/lib/perl5:$PWD/examples/perl-language/vendor/lib/perl5"
PERL5LIB="$DEPS" "$PERL" -MDBD::SQLite -MText::CSV -e 'print "dbd=$DBD::SQLite::VERSION sqlite=$DBD::SQLite::sqlite_version\n"; my $csv=Text::CSV->new({binary=>1}); print "auto_backend=".Text::CSV->backend."\n"'
PERL_TEXT_CSV=Text::CSV_PP PERL5LIB="$DEPS" "$PERL" -MText::CSV -e 'my $csv=Text::CSV->new({binary=>1}); print "forced_backend=".Text::CSV->backend."\n"'
```

Recorded: `DBD::SQLite 1.78`, SQLite engine `3.51.1`, `Text::CSV 2.06` auto backend `Text::CSV_XS`, forced backend `Text::CSV_PP`.

## Final full TAP

Evidence files: `full-app-prove-r-t.final.stdout`, `full-app-prove-r-t.final.stderr`, `full-app-prove-r-t.final.exit`.

```bash
PERL=/private/tmp/perl-5.38.2-independent/install/bin/perl
ARCH="$($PERL -MConfig -e 'print $Config::Config{archname}')"
DEPS="$PWD/examples/perl-language/vendor/perl-5.38.2-local/lib/perl5/$ARCH:$PWD/examples/perl-language/vendor/perl-5.38.2-local/lib/perl5:$PWD/examples/perl-language/vendor/lib/perl5"
PERL_TEXT_CSV=Text::CSV_PP PERL5LIB="$DEPS" "$PERL" -MApp::Prove -e 'my $app=App::Prove->new; $app->process_args(@ARGV); exit($app->run ? 0 : 1)' -- -Iexamples/perl-language/lib -r examples/perl-language/t
```

Recorded under outer `PERL_TEXT_CSV=Text::CSV_PP`: 16 files, 410 tests, PASS, exit 0. This covers the regression where `course-csv-xs.pl` must clear the inherited environment before proving auto backend identity.

## Installer smoke with skipped upstream tests

Evidence files: `installer-smoke-skiptests.stdout`, `installer-smoke-skiptests.stderr`, `installer-smoke-skiptests.exit`, `installer-smoke-load.stdout`, `installer-smoke-load.stderr`, `installer-smoke-load.exit`.

This smoke intentionally used `--skip-tests` to verify installer path safety and loadability without rerunning every CPAN upstream test in the smoke prefix.

```bash
/private/tmp/perl-5.38.2-independent/install/bin/perl examples/perl-language/tools/install-course-dependencies.pl --prefix /private/tmp/perl-course-installer-smoke-prefix --build-dir /private/tmp/perl-course-installer-smoke-build --skip-tests
PERL5LIB=/private/tmp/perl-course-installer-smoke-prefix/lib/perl5/darwin-2level:/private/tmp/perl-course-installer-smoke-prefix/lib/perl5 /private/tmp/perl-5.38.2-independent/install/bin/perl -MText::CSV_XS -MDBI -MDBD::SQLite -MMoo -e 'print "$Text::CSV_XS::VERSION $DBI::VERSION $DBD::SQLite::VERSION $Moo::VERSION\n"'
```

Smoke prefix for independent use: `/private/tmp/perl-course-installer-smoke-prefix`.

## Upstream full reruns

Evidence files: `text-csv-xs-full-rerun.*`, `text-csv-xs-41-45-rerun.*`, `dbi-full-rerun.*`, `dbi-zvxgn-85gofer-rerun.*`, `install-perl-5.38.2.*`, `install-perl-5.38.2-continue.*`.

The original shell command lines were not captured in separate `.command` files. The surviving stdout/stderr records the build cwd paths below, and the commands here are the equivalent reconstruction from those paths and the fixed interpreter. No source archive was modified between the failed install run and the passing rerun.

### Text::CSV_XS 1.64

- Source archive: `examples/perl-language/vendor/dist/Text-CSV_XS-1.64.tgz`
- SHA-256: `65c5662d4fe8ef3039a1b32f641634d0aae6ab10eabbb24f740c75332f2caf30`
- Recorded build cwd: `/private/tmp/perl-course-deps-538-install-build.84ACBX/Text-CSV_XS-1.64`
- Initial failure: `install-perl-5.38.2-continue.stdout` shows `make test` under that cwd failed because `t/41_null.t` and `t/45_eol.t` were killed by signal 9; summary `Files=35, Tests=51300, Result: FAIL`.
- Narrow rerun: `text-csv-xs-41-45-rerun.stdout` shows `t/41_null.t` and `t/45_eol.t` passed, `Files=2, Tests=1310, Result: PASS`.
- Full rerun: `text-csv-xs-full-rerun.stdout` shows all 35 files and 52610 tests passed.

Reconstructed full rerun command:

```bash
cd /private/tmp/perl-course-deps-538-install-build.84ACBX/Text-CSV_XS-1.64
PERL=/private/tmp/perl-5.38.2-independent/install/bin/perl
PERL_DL_NONLAZY=1 "$PERL" -MExtUtils::Command::MM -MTest::Harness -e 'undef *Test::Harness::Switches; test_harness(0, "blib/lib", "blib/arch")' t/*.t
```

If the old build cwd has been cleaned, rebuild from the fixed source archive first:

```bash
WORK=/private/tmp/perl-course-deps-rerun-text-csv-xs
rm -rf "$WORK"
mkdir -p "$WORK"
tar -xzf examples/perl-language/vendor/dist/Text-CSV_XS-1.64.tgz -C "$WORK"
cd "$WORK/Text-CSV_XS-1.64"
/private/tmp/perl-5.38.2-independent/install/bin/perl Makefile.PL
make
PERL_DL_NONLAZY=1 /private/tmp/perl-5.38.2-independent/install/bin/perl -MExtUtils::Command::MM -MTest::Harness -e 'undef *Test::Harness::Switches; test_harness(0, "blib/lib", "blib/arch")' t/*.t
```

### DBI 1.655

- Source archive: `examples/perl-language/vendor/dist/DBI-1.655.tgz`
- SHA-256: `735a42a82e5a866b57869f8b92bf218f58c7fb62f75d6707a6345142d152762f`
- Recorded build cwd: `/private/tmp/perl-course-deps-538-install-build.84ACBX/DBI-1.655`
- Initial upstream failure: `install-perl-5.38.2.stdout` shows `t/zvxgn_85gofer.t` failed 1 subtest, test 138; summary `Files=216, Tests=9672, Result: FAIL`. `install-perl-5.38.2.stderr` records the failing Gofer pipeone path.
- Separate diagnostic: `dbi-absolute-prove.*` is not the final upstream rerun; it used system Perl 5.34 in parts and hit hardened-runtime relative `blib/arch/.../DBI.bundle` load failures, so it is retained only as a diagnostic false path.
- Narrow rerun: `dbi-zvxgn-85gofer-rerun.stdout` shows `t/zvxgn_85gofer.t` passed, `Files=1, Tests=234, Result: PASS`.
- Full rerun: `dbi-full-rerun.stdout` shows 216 files and 9690 tests passed with Perl 5.38.2; stderr only reports no thread support for this perl.

Reconstructed full rerun command:

```bash
cd /private/tmp/perl-course-deps-538-install-build.84ACBX/DBI-1.655
PERL=/private/tmp/perl-5.38.2-independent/install/bin/perl
PERL_DL_NONLAZY=1 "$PERL" -MExtUtils::Command::MM -MTest::Harness -e 'undef *Test::Harness::Switches; test_harness(0, "blib/lib", "blib/arch")' t/*.t
```

If the old build cwd has been cleaned, rebuild from the fixed source archive first:

```bash
WORK=/private/tmp/perl-course-deps-rerun-dbi
rm -rf "$WORK"
mkdir -p "$WORK"
tar -xzf examples/perl-language/vendor/dist/DBI-1.655.tgz -C "$WORK"
cd "$WORK/DBI-1.655"
/private/tmp/perl-5.38.2-independent/install/bin/perl Makefile.PL
make
PERL_DL_NONLAZY=1 /private/tmp/perl-5.38.2-independent/install/bin/perl -MExtUtils::Command::MM -MTest::Harness -e 'undef *Test::Harness::Switches; test_harness(0, "blib/lib", "blib/arch")' t/*.t
```

## Final distribution build, unpack test, install, and installed CLI

Evidence files: `dist-final-makefile.*`, `dist-final-manifest.*`, `dist-final-make-test.*`, `dist-final-make-dist.*`, `logtool-0.200-final-sha256.txt`, `dist-final-unpack-makefile.*`, `dist-final-unpack-test.*`, `dist-final-install.*`, `installed-cli-final.*`, `dist-final-workdir.txt`.

```bash
ROOT="$PWD"
PERL=/private/tmp/perl-5.38.2-independent/install/bin/perl
ARCH="$($PERL -MConfig -e 'print $Config::Config{archname}')"
DEPS="$ROOT/examples/perl-language/vendor/perl-5.38.2-local/lib/perl5/$ARCH:$ROOT/examples/perl-language/vendor/perl-5.38.2-local/lib/perl5:$ROOT/examples/perl-language/vendor/lib/perl5"
WORK=/private/tmp/perl-course-dist-final-6708
SRC="$WORK/perl-language"
UNPACK="$WORK/unpack"
INSTALL="$WORK/install"
cp -R "$ROOT/examples/perl-language" "$SRC"
cd "$SRC"
PERL5LIB="$DEPS" "$PERL" Makefile.PL
make manifest
PERL_TEXT_CSV=Text::CSV_PP PERL5LIB="$DEPS" make test
make dist
shasum -a 256 LogTool-0.200.tar.gz
mkdir -p "$UNPACK" "$INSTALL"
tar -xzf LogTool-0.200.tar.gz -C "$UNPACK"
cd "$UNPACK/LogTool-0.200"
PERL5LIB="$DEPS" "$PERL" Makefile.PL INSTALL_BASE="$INSTALL"
PERL_TEXT_CSV=Text::CSV_PP PERL5LIB="$DEPS" make test
PERL5LIB="$DEPS" make install
```

Installed CLI was executed from cwd `/private/tmp` with `PATH` prefixed by `/private/tmp/perl-5.38.2-independent/install/bin` so the installed `#!/usr/bin/env perl` script used Perl v5.38.2.

Final installed `PERL5LIB`:

```text
/private/tmp/perl-course-dist-final-6708/install/lib/perl5/darwin-2level:/private/tmp/perl-course-dist-final-6708/install/lib/perl5:/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/perl-language/vendor/perl-5.38.2-local/lib/perl5/darwin-2level:/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/perl-language/vendor/perl-5.38.2-local/lib/perl5:/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/perl-language/vendor/lib/perl5
```

Installed `%INC` check recorded `LogTool/Course.pm` from `/private/tmp/perl-course-dist-final-6708/install/lib/perl5/LogTool/Course.pm`. The installed CLI completed `--version`, `import`, `query`, and `report` with exit 0 while the outer environment set `PERL_TEXT_CSV=Text::CSV_PP`.

Final distribution SHA-256:

```text
c6616daa3203f8b0487c7f807c4a508c443f1f15702d9cd60bd96d52a5cbbff0  LogTool-0.200.tar.gz
```
