cwd=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/perl-language
/private/tmp/perl-5.38.2-independent/perl-5.38.2/perl -I/private/tmp/perl-5.38.2-independent/perl-5.38.2/lib -e 'print qq(ok\n)'
