cd examples/perl-language && /private/tmp/perl-5.38.2-independent/perl-5.38.2/perl -Ilib t/course-engineering.t
