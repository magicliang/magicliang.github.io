cwd=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/perl-language
prove -lr t/course-engineering.t t/26-31-objects-and-process.t t/32-36-safe-report.t t/course-core.t
