cwd=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/perl-language
python3 tools/course-performance-probe.py
