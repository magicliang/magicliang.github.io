# Perl 工程机制补课证据摘要

## 基线

- 系统解释器：`perl -V:version -V:osname -V:archname` 记录在 `system-perl-version.*`，为 macOS Perl 5.34.1。
- 官方 5.38.2 build-tree：`exact-538-smoke.*` 退出 0，输出 `ok`；安装态仍不作为本 lane 证据。
- 哈希：本 lane 修改的工程文件 SHA-256 记录在 `sha256sum.txt`。

## 课程槽位与落点

| 原定槽位 | 本次落点 | 本次结果 |
| --- | --- | --- |
| 28 JSON Lines / JSON::PP | `lib/LogTool/Course/Output.pm`；`source/_posts/2026-10-06-Perl-40-*.md` | 新增 TSV 与 JSON Lines 两种输出策略；JSON Lines 测试逐行 decode，确认 total/level 行和数字字段。 |
| 29 bless 有状态聚合器 | `lib/LogTool/Course/Aggregator.pm`；`source/_posts/2026-10-06-Perl-40-*.md` | 新增 `new/add/rows` 与 `aggregate_rows`；测试覆盖对象版/函数版 parity、两个实例状态独立、`rows` 返回值所有权。 |
| 30 继承与组合 | `experiments/course-composition.pl`；`source/_posts/2026-10-06-Perl-40-*.md` | 可运行继承反例直接依赖 `{counts}` 内部哈希；组合版只依赖 `rows` 协议并生成 JSON Lines。 |
| 31 引用生命周期与析构 | `experiments/course-lifecycle.pl`；`source/_posts/2026-10-06-Perl-41-*.md` | 记录普通对象、强引用环、弱引用打破环后的 `DESTROY` 计数；明确关键写入仍需显式 close。 |
| 33 信号/管道/输出失败 | `t/course-engineering.t`；`experiments/course-process.pl`；`source/_posts/2026-10-06-Perl-31-*.md` | TERM 信号与普通退出码分离；关闭读端管道导致 SIGPIPE 或非零写失败。 |
| 34 写入失败保留旧报表 | `lib/LogTool/Report.pm`；`t/course-engineering.t`；`source/_posts/2026-10-06-Perl-33-*.md`、`Perl-34-*.md` | 主发布错误先保存，cleanup unlink 与 lock close 错误只追加；独立子进程覆盖 `CORE::GLOBAL` 断言三个错误同时保留。 |
| 35 性能测量 | `experiments/course-performance.pl`；`tools/course-performance-probe.py`；`source/_posts/2026-10-06-Perl-42-*.md` | naive 与 Aggregator 独立进程输出 SHA-256 相等；Python 标准库 `fork/exec/wait4/resource` 记录 wall time 与 `ru_maxrss`。 |
| E06 并行 worker | `lib/LogTool/Course/Parallel.pm`；`source/_posts/2026-10-06-Perl-42-*.md` | 受控 fork 分片聚合；payload 限定三等级行；任一 worker 失败或 payload 异常不发布，fork/pipe 失败会回收已启动 child。 |
| E07 平台审计 | `source/_posts/2026-10-06-Perl-E07-*.md` | 将信号、管道、fork、RLIMIT、RSS 口径与 5.38.2 build-tree 结果按平台/解释器边界标注。 |

## 复跑结果

- `targeted-prove.*`：系统 Perl 5.34.1，`prove -lr t/course-engineering.t t/26-31-objects-and-process.t t/32-36-safe-report.t t/course-core.t`，退出 0，4 文件 123 测试通过。
- `exact-538-targeted-prove.*`：官方 Perl 5.38.2 build-tree，等价目标测试退出 0，4 文件 123 测试通过。
- `system-full-prove.*`：系统 Perl 5.34.1 全量 `prove -lr t` 退出 1，失败项为 E01 signatures 警告和 E02 class 不支持；这是版本不匹配，不作为工程机制失败。
- `exact-538-full-prove.*`：官方 Perl 5.38.2 build-tree 显式列出全部 `t/*.t` 后退出 255；失败集中在非本 lane 的 `t/21-25-modules-and-tap.t` 与 `t/E01-E08-electives.t` 后段，原因是测试内部调用系统 `/usr/bin/prove`，混用 build-tree 5.38.2 lib 后触发 `Cwd.bundle` XS ABI 错误。该结果记录为全量环境阻塞，不能替代目标通过证据。
- `cli-help.*`、`cli-report.*`、`cli-bad-input.*`：CLI 帮助、报表正例、坏输入反例均按预期退出。
- `experiment-composition.*`、`experiment-lifecycle.*`、`experiment-performance.*`、`experiment-process.*`：四个补课实验均退出 0，stderr 为空。
- `performance-probe.*`：Python 标准库采样脚本退出 0，记录 naive / aggregator 两个独立 Perl 进程的 wall time、`ru_maxrss`、退出码、信号和输出 SHA-256 等价性。

## 未扩张声明

- 未修改历史 review 目录、根依赖、其他语言系列或发布配置。
- 未把 `rename`、协作锁或本机管道结果写成断电持久化、非协作写入阻止或所有平台保证。
- `BSD::Resource` 在系统 Perl 下不可用时，`t/course-engineering.t` 的 RLIMIT 文件大小注入以 skip 记录；真实 RLIMIT、broken pipe 和 TERM 证据由 root lane 的工具输出集成，本 lane 不新增 CPAN 依赖。
