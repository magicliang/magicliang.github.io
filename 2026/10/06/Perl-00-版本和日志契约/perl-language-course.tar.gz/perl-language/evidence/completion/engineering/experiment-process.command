cwd=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/perl-language
perl experiments/course-process.pl
