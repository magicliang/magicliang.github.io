cwd=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/perl-language
perl bin/logtool.pl query fixtures/invalid.tsv WARN
