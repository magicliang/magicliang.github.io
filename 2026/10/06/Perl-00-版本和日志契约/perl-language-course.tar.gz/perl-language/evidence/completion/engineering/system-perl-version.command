cwd=/Users/magicliang/Desktop/Programming/git/hexo-blog
perl -V:version -V:osname -V:archname
