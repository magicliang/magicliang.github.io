cwd=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/perl-language
prove -lr t
