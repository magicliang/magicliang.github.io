cwd=/Users/magicliang/Desktop/Programming/git/hexo-blog/examples/perl-language
/private/tmp/perl-5.38.2-independent/perl-5.38.2/perl -I/private/tmp/perl-5.38.2-independent/perl-5.38.2/lib -Ilib -MTest::Harness -e 'runtests(@ARGV)' t/course-engineering.t t/26-31-objects-and-process.t t/32-36-safe-report.t t/course-core.t
