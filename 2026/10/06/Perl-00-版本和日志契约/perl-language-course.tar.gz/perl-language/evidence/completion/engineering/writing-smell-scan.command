cwd=/Users/magicliang/Desktop/Programming/git/hexo-blog
python3 -c '
from pathlib import Path
patterns = ['"'"'2026-10-06-Perl-26-*.md'"'"','"'"'2026-10-06-Perl-27-*.md'"'"','"'"'2026-10-06-Perl-31-*.md'"'"','"'"'2026-10-06-Perl-33-*.md'"'"','"'"'2026-10-06-Perl-34-*.md'"'"','"'"'2026-10-06-Perl-35-*.md'"'"','"'"'2026-10-06-Perl-36-*.md'"'"','"'"'2026-10-06-Perl-E07-*.md'"'"','"'"'2026-10-06-Perl-40-*.md'"'"','"'"'2026-10-06-Perl-41-*.md'"'"','"'"'2026-10-06-Perl-42-*.md'"'"']
terms = ['"'"'我'"'"','"'"'我们'"'"','"'"'本文'"'"','"'"'这篇'"'"','"'"'接下来'"'"','"'"'显然'"'"','"'"'毫无疑问'"'"','"'"'故事'"'"','"'"'旅程'"'"','"'"'助手'"'"','"'"'AI'"'"','"'"'大模型'"'"','"'"'——'"'"']
found = False
for pat in patterns:
    for p in sorted(Path('"'"'source/_posts'"'"').glob(pat)):
        for i,line in enumerate(p.read_text().splitlines(),1):
            if any(t in line for t in terms):
                found = True
                print(f'"'"'{p}:{i}:{line}'"'"')
print('"'"'scan-clean'"'"' if not found else '"'"'scan-found'"'"')
raise SystemExit(1 if found else 0)
'
