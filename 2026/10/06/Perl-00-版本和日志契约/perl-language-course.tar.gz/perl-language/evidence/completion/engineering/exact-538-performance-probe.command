cd examples/perl-language && PERL=/private/tmp/perl-5.38.2-independent/perl-5.38.2/perl python3 tools/course-performance-probe.py
