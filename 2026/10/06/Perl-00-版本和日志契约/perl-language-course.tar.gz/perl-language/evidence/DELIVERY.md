# 00–25 实际交付解包记录（2026-10-06 UTC）

Hexo 默认只渲染/复制 `source/`；`examples/perl-language/` 不在公开输出目录。用同名素材目录 `source/_posts/2026-10-06-Perl-00-版本和日志契约/` 交付 `perl-language-full.tar.gz`，包含完整工具、模块、金标输入、RUN/VERSIONS 与截至打包时的证据。最终包的 SHA-256 要从素材目录内的 `PACKAGE.txt` 独立核对；不在包内自指其自身的 SHA。打包命令：

```sh
tar --sort=name --mtime='UTC 2026-10-06' --owner=0 --group=0 --numeric-owner -C examples -czf source/_posts/2026-10-06-Perl-00-版本和日志契约/perl-language-full.tar.gz perl-language
sha256sum source/_posts/2026-10-06-Perl-00-版本和日志契约/perl-language-full.tar.gz
mkdir -p /tmp/perl-language-archive-check
tar -xzf source/_posts/2026-10-06-Perl-00-版本和日志契约/perl-language-full.tar.gz -C /tmp/perl-language-archive-check
prove -r /tmp/perl-language-archive-check/perl-language/t
```

最初 00–14 增量包的 SHA-256 是 `b98362c1804b72bf4980b760abf8bb7d48508b1f890e5348a34d2eb9dfb0b96b`，解包后 `Files=5, Tests=69`；15–20 包的 SHA-256 为 `8b825b9b58f76bb3720f29289c86682c3bf24bcae8a69becee8f4dbd46e2d167`，解包后 `Files=6, Tests=83`。两者都是历史快照，不能用于校验本次更新的包。本次加入 21–25 的 POD、模块、隔离 CSV 发行包及正反例后，重新解包测试的预期是 `Files=7, Tests=105`；需要实际执行后在素材目录 `PACKAGE.txt` 记录最终结果。生产服务器、Windows/macOS 复跑及真正的断电验证均 NOT_RUN。
