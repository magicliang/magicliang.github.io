# Perl course dependency bundle

The portable dependency source bundle is `vendor/dist/`. It contains CPAN source archives only. Machine-specific compiled trees such as `vendor/perl-5.38.2-local/` are local verification products and are ignored by Git.

## Build prerequisites

Use the same Perl interpreter that will run the course tests. XS distributions also need a working C compiler, `make`, and Perl core headers for that interpreter. The verification run used `/private/tmp/perl-5.38.2-independent/install/bin/perl` v5.38.2 on `darwin-2level`. `DBD::SQLite 1.78` reported SQLite engine `3.51.1`; the saved build log compiles bundled `sqlite3.c` directly and installs `auto/share/dist/DBD-SQLite/sqlite3.c`, `sqlite3.h`, and `sqlite3ext.h`, so the course records the actual engine version instead of assuming it from the distribution version.

## Source archives

| Distribution | Source URL | SHA-256 |
| --- | --- | --- |
| DBI-1.655 | https://cpan.metacpan.org/authors/id/H/HM/HMBRAND/DBI-1.655.tgz | `735a42a82e5a866b57869f8b92bf218f58c7fb62f75d6707a6345142d152762f` |
| DBD-SQLite-1.78 | https://cpan.metacpan.org/authors/id/I/IS/ISHIGAKI/DBD-SQLite-1.78.tar.gz | `efbad7794bafaa4e7476c07445a33bbfe1040e380baa3395a02635eebe3859d5` |
| Class-Method-Modifiers-2.15 | https://cpan.metacpan.org/authors/id/E/ET/ETHER/Class-Method-Modifiers-2.15.tar.gz | `65cd85bfe475d066e9186f7a8cc636070985b30b0ebb1cde8681cf062c2e15fc` |
| Role-Tiny-2.002004 | https://cpan.metacpan.org/authors/id/H/HA/HAARG/Role-Tiny-2.002004.tar.gz | `d7bdee9e138a4f83aa52d0a981625644bda87ff16642dfa845dcb44d9a242b45` |
| Sub-Quote-2.006008 | https://cpan.metacpan.org/authors/id/H/HA/HAARG/Sub-Quote-2.006008.tar.gz | `94bebd500af55762e83ea2f2bc594d87af828072370c7110c60c238a800d15b2` |
| Moo-2.005005 | https://cpan.metacpan.org/authors/id/H/HA/HAARG/Moo-2.005005.tar.gz | `fb5a2952649faed07373f220b78004a9c6aba387739133740c1770e9b1f4b108` |
| Text-CSV_XS-1.64 | https://cpan.metacpan.org/authors/id/H/HM/HMBRAND/Text-CSV_XS-1.64.tgz | `65c5662d4fe8ef3039a1b32f641634d0aae6ab10eabbb24f740c75332f2caf30` |

`vendor/Text-CSV-2.06.tar.gz` and `vendor/lib/perl5/Text/CSV*.pm` keep the earlier pure-Perl Text::CSV exercise. Pure Perl `Text::CSV_PP` and XS `Text::CSV_XS` are verified separately. With both distributions present, `Text::CSV 2.06` auto-selected `Text::CSV_XS`; a separate forced run with `PERL_TEXT_CSV=Text::CSV_PP` recorded the pure-Perl backend.

## Install and run

```bash
/path/to/perl tools/install-course-dependencies.pl --prefix /tmp/perl-course-deps
export PERL5LIB=/tmp/perl-course-deps/lib/perl5/$(/path/to/perl -MConfig -e 'print $Config::Config{archname}'):/tmp/perl-course-deps/lib/perl5:$PWD/vendor/lib/perl5:$PWD/lib
/path/to/perl -MApp::Prove -e 'my $app=App::Prove->new; $app->process_args(@ARGV); exit($app->run ? 0 : 1)' -- -Ilib -r t
```

`tools/install-course-dependencies.pl --help` prints the usage line. The script refuses extra arguments, converts `--prefix` and `--build-dir` to absolute paths before changing directories, and uses the absolute current interpreter path for every distribution build. If `--build-dir` is supplied, it must be empty; otherwise the script creates a fresh temporary build directory and never deletes an arbitrary existing directory.

## Verification boundary

The course verification used Perl v5.38.2 with Text::CSV_XS 1.64, Text::CSV 2.06, DBI 1.655, DBD::SQLite 1.78, SQLite engine 3.51.1 and Moo 2.005005. Text::CSV_XS and DBI both had an earlier failed upstream batch in this local environment; the saved reruns later passed, so the course records both the initial failure and the final passing rerun instead of treating one as if the other did not happen.
