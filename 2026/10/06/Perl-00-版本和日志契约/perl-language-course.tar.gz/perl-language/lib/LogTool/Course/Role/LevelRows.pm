package LogTool::Course::Role::LevelRows;
use Moo::Role;

sub level_from_record {
    my ($self, $record) = @_;
    die "invalid aggregate record\n" unless ref($record);

    my $level = ref($record) eq 'HASH' ? $record->{level}
        : $record->can('level') ? $record->level
        : undef;
    die "invalid aggregate level\n"
        unless defined($level) && $level =~ /\A(?:ERROR|INFO|WARN)\z/;
    return $level;
}

sub sorted_level_rows {
    my ($self, $counts) = @_;
    return [
        map { {level => $_, count => $counts->{$_}} }
        sort keys %$counts
    ];
}

1;
