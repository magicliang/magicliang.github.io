package LogTool::Course;
use strict;
use warnings;
use Encode qw(decode encode FB_CROAK LEAVE_SRC);
use JSON::PP;
use Unicode::Normalize qw(NFC);
use Time::Local qw(timegm_modern);
use Exporter 'import';
our $VERSION = '0.200';
our @EXPORT_OK = qw(parse_line import_records read_jsonl jsonl);
my $json = JSON::PP->new->canonical->allow_nonref(0);
my $maximum_line = 65536;

sub parse_line {
    my ($line) = @_;
    die "line must be defined text\n" unless defined($line) && !ref($line);
    my @fields = split /\t/, $line, -1;
    die "expected five fields\n" unless @fields == 5;
    my ($timestamp, $level, $service, $duration, $message) = @fields;
    my ($year, $month, $day, $hour, $minute, $second) =
        $timestamp =~ /\A([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})Z\z/;
    die "invalid timestamp\n" unless defined($year) && $year >= 1970 && $year <= 2099;
    my $valid_calendar = eval { timegm_modern($second, $minute, $hour, $day, $month - 1, $year); 1 };
    die "invalid calendar timestamp\n" unless $valid_calendar;
    die "invalid level\n" unless $level =~ /\A(?:INFO|WARN|ERROR)\z/;
    die "invalid service\n" unless $service =~ /\A[A-Za-z][A-Za-z0-9_-]*\z/;
    die "invalid duration\n" unless $duration eq '' || $duration =~ /\A(?:0|[1-9][0-9]{0,8})\z/;
    die "invalid message escape\n" unless $message =~ /\A(?:[^\\]|\\[tn\\])*\z/;
    die "unescaped control character\n" if $message =~ /[\x00-\x1f\x7f]/;
    $message =~ s/\\([tn\\])/$1 eq 't' ? "\t" : $1 eq 'n' ? "\n" : "\\"/ge;
    return {timestamp => $timestamp, level => $level, service => $service,
        duration_ms => $duration eq '' ? undef : 0 + $duration,
        message => NFC($message), raw_message => $message};
}

sub _lines {
    my ($path, $consume, $limit) = @_;
    $limit //= $maximum_line;
    open my $input, '<:raw', $path or die "cannot open input: $!\n";
    my ($buffer, $number, $total, $overflow) = ('', 0, 0, 0);
    while (1) {
        my $count = sysread($input, my $chunk, 4096);
        die "cannot read input: $!\n" unless defined($count);
        last unless $count;
        $total += $count;
        die "input exceeds 16777216 bytes\n" if $total > 16777216;
        for my $part (split /(?<=\n)/, $chunk) {
            $buffer .= $part unless $overflow;
            $overflow = 1 if length($buffer) > $limit;
            if ($part =~ /\n\z/) {
                ++$number;
                $buffer =~ s/\r?\n\z//;
                $consume->($buffer, $number, $overflow);
                ($buffer, $overflow) = ('', 0);
            }
        }
    }
    $consume->($buffer, ++$number, $overflow) if length($buffer) || $overflow;
    close $input or die "cannot close input: $!\n";
    return $number;
}

sub import_records {
    my ($path) = @_;
    my (@accepted, @rejected);
    my $count = _lines($path, sub {
        my ($bytes, $line_number, $overflow) = @_;
        if ($overflow) {
            push @rejected, {line => $line_number, error => 'line exceeds 65536 bytes'};
            return;
        }
        my $line = eval { decode('UTF-8', $bytes, FB_CROAK | LEAVE_SRC) };
        die "line $line_number: invalid UTF-8\n" if $@;
        my $record = eval { parse_line($line) };
        my $error = $@;
        if ($error) {
            $error =~ s/\s+\z//;
            push @rejected, {line => $line_number, raw => $line, error => $error};
        } else {
            push @accepted, $record;
        }
    });
    return {input => $count, accepted => \@accepted, rejected => \@rejected};
}

sub jsonl {
    my ($records) = @_;
    die "JSON Lines input must be an array reference\n" unless ref($records) eq 'ARRAY';
    return encode('UTF-8', join('', map { $json->encode($_) . "\n" } @$records), FB_CROAK | LEAVE_SRC);
}

sub read_jsonl {
    my ($path) = @_;
    my @records;
    _lines($path, sub {
        my ($bytes, $number, $overflow) = @_;
        die "JSON line $number exceeds 524288 bytes\n" if $overflow;
        my $line = eval { decode('UTF-8', $bytes, FB_CROAK | LEAVE_SRC) };
        die "JSON line $number: invalid UTF-8\n" if $@;
        my $record = eval { $json->decode($line) };
        die "invalid JSON line $number: $@" if $@;
        die "JSON line $number must be a record object\n" unless ref($record) eq 'HASH';
        my @keys = sort keys %$record;
        die "JSON line $number has unexpected fields\n"
            unless join(',', @keys) eq 'duration_ms,level,message,raw_message,service,timestamp';
        for my $field (qw(timestamp level service message raw_message)) {
            die "JSON line $number invalid $field\n" unless defined($record->{$field}) && !ref($record->{$field});
            die "JSON line $number invalid string type for $field\n"
                unless JSON::PP->new->allow_nonref->encode($record->{$field}) =~ /\A"/;
        }
        my $duration = $record->{duration_ms};
        die "JSON line $number invalid duration type\n" if defined($duration) && JSON::PP->new->allow_nonref->encode($duration) !~ /\A(?:0|[1-9][0-9]{0,8})\z/;
        my $escaped = $record->{raw_message};
        $escaped =~ s/\\/\\\\/g;
        $escaped =~ s/\t/\\t/g;
        $escaped =~ s/\n/\\n/g;
        my $validated = parse_line(join "\t", @{$record}{qw(timestamp level service)}, $duration // '', $escaped);
        die "JSON line $number inconsistent normalized message\n" unless $record->{message} eq $validated->{message};
        push @records, $validated;
    }, 524288);
    return \@records;
}

1;
