package LogTool::Course::Output;
use strict;
use warnings;
use Exporter 'import';
use JSON::PP ();

our $VERSION = '0.100';
our @EXPORT_OK = qw(tsv_report jsonl_report);

sub tsv_report {
    my ($total, $rows) = @_;
    die "invalid report total\n" unless defined($total) && $total =~ /\A\d+\z/;
    die "invalid report rows\n" unless ref($rows) eq 'ARRAY';

    my $output = "TOTAL\t$total\n";
    for my $row (@$rows) {
        _validate_row($row);
        $output .= "$row->{level}\t$row->{count}\n";
    }
    return $output;
}

sub jsonl_report {
    my ($total, $rows) = @_;
    die "invalid report total\n" unless defined($total) && $total =~ /\A\d+\z/;
    die "invalid report rows\n" unless ref($rows) eq 'ARRAY';

    my $json = JSON::PP->new->canonical(1)->utf8(0);
    my @lines = ($json->encode({kind => 'total', count => 0 + $total}));
    for my $row (@$rows) {
        _validate_row($row);
        push @lines, $json->encode({
            kind => 'level',
            level => $row->{level},
            count => 0 + $row->{count},
        });
    }
    return join("\n", @lines) . "\n";
}

sub _validate_row {
    my ($row) = @_;
    die "invalid report row\n"
        unless ref($row) eq 'HASH'
            && defined($row->{level})
            && $row->{level} =~ /\A(?:ERROR|INFO|WARN)\z/
            && defined($row->{count})
            && $row->{count} =~ /\A\d+\z/;
    return 1;
}

1;
