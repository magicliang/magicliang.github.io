package LogTool::Runner;
use strict;
use warnings;
use Exporter 'import';
use IPC::Open3;
use Symbol 'gensym';

our $VERSION = '0.100';
our @EXPORT_OK = qw(run_probe);

sub run_probe {
    my ($program, $token) = @_;
    die "invalid probe token\n"
        unless defined($token) && $token =~ /\A[\x20-\x7e]{1,24}\z/;

    my $child_stderr = gensym;
    my $child_stdout;
    my $child_code = 'use strict; use warnings; '
        . 'if ($ARGV[0] eq "fail") { print STDERR "child failed\n"; exit 7; } '
        . 'print "arg=$ARGV[0]\n"; print STDERR "probe note\n";';
    my $pid = eval {
        open3(undef, $child_stdout, $child_stderr,
            $program, '-e', $child_code, '--', $token);
    };
    die "probe start failed: $@" if $@;
    binmode $child_stdout, ':raw' or die "probe output mode failed: $!\n";
    binmode $child_stderr, ':raw' or die "probe error mode failed: $!\n";
    local $/;
    my $out = <$child_stdout> // '';
    my $err = <$child_stderr> // '';
    waitpid($pid, 0) == $pid or die "probe wait failed: $!\n";
    return {stdout => $out, stderr => $err,
        exit => $? >> 8, signal => $? & 127};
}

1;
