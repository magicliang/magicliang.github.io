package LogTool::Course::Aggregator;
use strict;
use warnings;
use Exporter 'import';

our $VERSION = '0.100';
our @EXPORT_OK = qw(aggregate_rows);

sub new {
    my ($class) = @_;
    return bless {counts => {}}, $class;
}

sub add {
    my ($self, $record) = @_;
    die "invalid aggregate record\n" unless ref($record);

    my $level = ref($record) eq 'HASH' ? $record->{level}
        : $record->can('level') ? $record->level
        : undef;
    die "invalid aggregate level\n"
        unless defined($level) && $level =~ /\A(?:ERROR|INFO|WARN)\z/;

    $self->{counts}{$level}++;
    return $self;
}

sub rows {
    my ($self) = @_;
    return [
        map { {level => $_, count => $self->{counts}{$_}} }
        sort keys %{$self->{counts}}
    ];
}

sub aggregate_rows {
    my ($records) = @_;
    die "invalid aggregate records\n" unless ref($records) eq 'ARRAY';
    my $aggregate = __PACKAGE__->new;
    $aggregate->add($_) for @$records;
    return $aggregate->rows;
}

1;
