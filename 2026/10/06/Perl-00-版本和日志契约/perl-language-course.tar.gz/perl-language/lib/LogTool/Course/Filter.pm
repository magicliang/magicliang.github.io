package LogTool::Course::Filter;

use strict;
use warnings;
use Exporter 'import';

our @EXPORT_OK = qw(make_filter);
our $VERSION = '0.001';

sub make_filter {
    my (%conditions) = @_;

    my $level = exists $conditions{level} ? $conditions{level} : undef;
    my $contains = exists $conditions{contains} ? $conditions{contains} : undef;
    my $min_duration_ms = exists $conditions{min_duration_ms} ? $conditions{min_duration_ms} : undef;

    die "level must be INFO, WARN or ERROR\n"
        if defined $level && $level !~ /\A(?:INFO|WARN|ERROR)\z/;
    die "contains must be defined when supplied\n"
        if exists $conditions{contains} && !defined $contains;
    die "min_duration_ms must be a non-negative integer\n"
        if defined $min_duration_ms && $min_duration_ms !~ /\A(?:0|[1-9][0-9]*)\z/;

    return sub {
        my ($record) = @_;
        return 0 if ref($record) ne 'HASH';
        return 0 if defined $level && (!defined $record->{level} || $record->{level} ne $level);
        return 0 if defined $min_duration_ms && (!defined $record->{duration_ms} || $record->{duration_ms} < $min_duration_ms);
        return 0 if defined $contains && (!defined $record->{message} || index($record->{message}, $contains) < 0);
        return 1;
    };
}

1;
