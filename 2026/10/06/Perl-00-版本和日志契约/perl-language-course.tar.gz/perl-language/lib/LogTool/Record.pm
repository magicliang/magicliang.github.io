package LogTool::Record;
use strict;
use warnings;

our $VERSION = '0.100';

sub new {
    my ($class, $fields) = @_;
    die "invalid record object\n"
        unless ref($fields) eq 'HASH'
            && !grep { !exists($fields->{$_}) || !defined($fields->{$_}) }
                qw(time level service message);
    die "invalid record level\n"
        unless $fields->{level} =~ /\A(?:INFO|WARN|ERROR)\z/;
    return bless { map { $_ => $fields->{$_} } qw(time level service message) }, $class;
}

sub level {
    my ($self) = @_;
    return $self->{level};
}

sub as_hash {
    my ($self) = @_;
    return { %$self };
}

1;
