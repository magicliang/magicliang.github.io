package LogTool::Report;
use strict;
use warnings;
use Exporter 'import';
use Fcntl 'LOCK_EX';
use File::Basename 'dirname';
use File::Temp 'tempfile';

our $VERSION = '0.100';
our @EXPORT_OK = qw(save_report);

sub save_report {
    my ($bytes, $destination) = @_;
    die "invalid report destination\n"
        unless defined($bytes) && !ref($bytes)
            && defined($destination) && length($destination);

    open my $lock, '>>', "$destination.lock"
        or die "cannot open report lock: $!\n";
    flock($lock, LOCK_EX) or die "cannot lock report: $!\n";

    my ($output, $temporary) = tempfile('.logtool-XXXXXX',
        DIR => dirname($destination), UNLINK => 1);
    my $saved = eval {
        binmode($output, ':raw') or die "cannot set report mode: $!\n";
        print {$output} $bytes or die "cannot write report: $!\n";
        close($output) or die "cannot close report: $!\n";
        rename($temporary, $destination) or die "cannot replace report: $!\n";
        1;
    };
    my $error = $saved ? '' : $@;
    if (!$saved && -e $temporary) {
        unlink($temporary)
            or $error .= "cannot remove temporary report: $!\n";
    }
    my $lock_closed = close($lock);
    if (!$lock_closed) {
        my $lock_error = "cannot close report lock: $!\n";
        die $lock_error if $saved;
        $error .= $lock_error;
    }
    die $error unless $saved;
    return 1;
}

1;
