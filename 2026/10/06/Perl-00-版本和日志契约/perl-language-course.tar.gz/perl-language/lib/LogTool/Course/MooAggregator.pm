package LogTool::Course::MooAggregator;
use Moo;
with 'LogTool::Course::Role::LevelRows';

our $VERSION = '0.100';

has counts => (
    is => 'ro',
    default => sub { {} },
);

sub add {
    my ($self, $record) = @_;
    my $level = $self->level_from_record($record);
    $self->counts->{$level}++;
    return $self;
}

sub rows {
    my ($self) = @_;
    return $self->sorted_level_rows($self->counts);
}

1;
