package LogTool::Course::Parallel;
use strict;
use warnings;
use Exporter 'import';
use POSIX ();
use Storable qw(freeze thaw);
use LogTool::Course::Aggregator qw(aggregate_rows);
use LogTool::Course::Output 'tsv_report';
use LogTool::Report 'save_report';

our $VERSION = '0.100';
our @EXPORT_OK = qw(parallel_rows publish_parallel_report);

sub parallel_rows {
    my ($records, $workers, %options) = @_;
    die "invalid records\n" unless ref($records) eq 'ARRAY';
    $workers = 1 unless defined($workers);
    die "invalid worker count\n"
        unless $workers =~ /\A[1-9]\d*\z/ && $workers <= 8;
    $workers = @$records if @$records && $workers > @$records;
    $workers ||= 1;

    my @children;
    for my $worker (0 .. $workers - 1) {
        my $pipe_opened = pipe(my $reader, my $writer);
        if (!$pipe_opened) {
            _wait_children(@children);
            die "cannot create worker pipe: $!\n";
        }
        my $pid = fork();
        if (!defined $pid) {
            close $reader;
            close $writer;
            _wait_children(@children);
            die "cannot fork worker: $!\n";
        }
        if ($pid == 0) {
            close $reader;
            my $ok = eval {
                my @shard;
                for (my $index = $worker; $index < @$records; $index += $workers) {
                    my $record = $records->[$index];
                    if ($options{fail_if} && $options{fail_if}->($record)) {
                        die "worker requested failure\n";
                    }
                    push @shard, $record;
                }
                my $rows = aggregate_rows(\@shard);
                binmode($writer, ':raw') or die "cannot set worker pipe: $!\n";
                print {$writer} freeze($rows)
                    or die "cannot write worker result: $!\n";
                close($writer) or die "cannot close worker pipe: $!\n";
                1;
            };
            POSIX::_exit($ok ? 0 : 1);
        }
        close $writer;
        push @children, {pid => $pid, reader => $reader};
    }

    my @parts;
    my @failures;
    for my $child (@children) {
        binmode($child->{reader}, ':raw') or die "cannot set parent pipe: $!\n";
        local $/;
        my $payload = readline($child->{reader}) // '';
        close($child->{reader}) or push @failures, "reader close failed";
        waitpid($child->{pid}, 0) == $child->{pid}
            or push @failures, "worker wait failed";
        my $status = $?;
        push @failures, "worker failed" if $status != 0;
        next if $status != 0;
        my $rows = eval { thaw($payload) };
        if ($@ || _invalid_rows($rows)) {
            push @failures, "worker payload failed";
            next;
        }
        push @parts, $rows;
    }
    die "worker failed\n" if @failures;

    my %counts;
    for my $rows (@parts) {
        for my $row (@$rows) {
            $counts{$row->{level}} += $row->{count};
        }
    }
    return [
        map { {level => $_, count => $counts{$_}} }
        sort keys %counts
    ];
}

sub _invalid_rows {
    my ($rows) = @_;
    return 1 unless ref($rows) eq 'ARRAY' && @$rows <= 3;
    for my $row (@$rows) {
        return 1
            unless ref($row) eq 'HASH'
                && defined($row->{level})
                && $row->{level} =~ /\A(?:ERROR|INFO|WARN)\z/
                && defined($row->{count})
                && $row->{count} =~ /\A\d+\z/;
    }
    return 0;
}

sub _wait_children {
    my (@children) = @_;
    for my $child (@children) {
        close $child->{reader};
        waitpid($child->{pid}, 0);
    }
    return 1;
}

sub publish_parallel_report {
    my ($records, $destination, $workers, %options) = @_;
    my $rows = parallel_rows($records, $workers, %options);
    save_report(tsv_report(scalar(@$records), $rows), $destination);
    return 1;
}

1;
