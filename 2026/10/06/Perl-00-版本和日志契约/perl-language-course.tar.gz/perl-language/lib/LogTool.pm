package LogTool;
use strict;
use warnings;
use Encode qw(decode FB_CROAK LEAVE_SRC);
use Exporter 'import';
use Time::Local 'timegm_modern';
use LogTool::Course::Aggregator 'aggregate_rows';
use LogTool::Record;
our $VERSION = '0.100';
our @EXPORT_OK = qw(read_records format_record report report_rows);

sub read_records {
    my ($path) = @_;
    open my $input, '<:raw', $path or die "cannot open input: $!\n";
    my $maximum_bytes = 1_048_576;
    my $file_size = -s $input;
    die "input exceeds $maximum_bytes bytes\n"
        if defined($file_size) && $file_size > $maximum_bytes;
    my @records;
    my $line_number = 0;
    my $bytes_read = 0;
    while (1) {
        $! = 0;
        my $bytes = <$input>;
        if (!defined($bytes)) {
            die "cannot read input: $!\n" if $!;
            last;
        }
        $bytes_read += length($bytes);
        die "input exceeds $maximum_bytes bytes\n" if $bytes_read > $maximum_bytes;
        ++$line_number;
        my $line = eval { decode('UTF-8', $bytes, FB_CROAK | LEAVE_SRC) };
        die "line $line_number: invalid UTF-8\n" if $@;
        $line =~ s/\n\z//;
        my @fields = split /\t/, $line, -1;
        die "line $line_number: expected four fields\n" unless @fields == 4;
        my ($time, $level, $service, $message) = @fields;
        my ($year, $month, $day, $hour, $minute, $second) =
            $time =~ /\A(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)Z\z/;
        die "line $line_number: invalid record\n"
            unless defined($year) && $year >= 1970 && $year <= 2099
                && $level =~ /\A(?:INFO|WARN|ERROR)\z/
                && $service =~ /\A[A-Za-z][A-Za-z0-9_-]*\z/
                && $message !~ /[\r\n]/;
        my $valid_date = eval {
            timegm_modern($second, $minute, $hour, $day, $month - 1, $year);
            1;
        };
        die "line $line_number: invalid record\n" unless $valid_date;
        push @records, {
            time => $time, level => $level,
            service => lc($service), message => $message,
        };
    }
    close $input or die "cannot close input: $!\n";
    return \@records;
}

sub format_record {
    my ($record) = @_;
    return join "\t", @{$record}{qw(time level service message)};
}

sub report {
    my ($records) = @_;
    return join '', map { join("\t", @$_) . "\n" } @{report_rows($records)};
}

sub report_rows {
    my ($records) = @_;
    my @objects = map { LogTool::Record->new($_) } @$records;
    my $rows = aggregate_rows(\@objects);
    return [['TOTAL', scalar(@$records)],
        map { [$_->{level}, $_->{count}] } @$rows];
}

1;
