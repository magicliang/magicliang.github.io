use strict;
use warnings;
use Test::More tests => 1;
use FindBin;
use lib "$FindBin::Bin/../lib";
use LogTool qw(read_records report);
my $records = read_records("$FindBin::Bin/demo.tsv");
is(report($records), "TOTAL\t4\nINFO\t2\nWARN\t1\n", 'deliberately corrupt total in report gold');
