# 本地复跑

## 2026-10-12 原定课程入口

先固定 Perl 5.38.2 的绝对路径。下文 `PERL` 是该路径，不是系统解释器的别名。源码自带纯 Perl Text::CSV 2.06；XS、DBI、SQLite、Moo 用 `tools/install-course-dependencies.pl` 和 vendor/dist 中的固定发行源码恢复到独立前缀，具体参数见该脚本的帮助和 COURSE-DEPENDENCIES.md。不要跨 Perl ABI 复用编译产物。

从 `examples/perl-language/` 运行：

```sh
PERL=/absolute/path/to/perl-5.38.2
"$PERL" bin/logtool --version
"$PERL" bin/logtool --help
work=$(mktemp -d)
"$PERL" bin/logtool import --input fixtures/course.tsv --output "$work/accepted.jsonl" --rejects "$work/rejected.jsonl"
"$PERL" bin/logtool query --input "$work/accepted.jsonl" --min-duration 0
"$PERL" bin/logtool report --input "$work/accepted.jsonl" --output "$work/report.tsv"
"$PERL" tools/replay.pl --case all
"$PERL" -MApp::Prove -e 'my $app=App::Prove->new; $app->process_args(@ARGV); exit($app->run ? 0 : 1)' -- -lr t
```

核心入口使用五字段 timestamp、level、service、duration_ms、message。耗时空字段映射为 JSON null，0 是有效数字；消息支持 `\\t`、`\\n`、`\\\\`，只对消息做 NFC，保留 raw_message 和 service 原样。格式坏行进入拒绝清单，非法 UTF-8、读取或关闭失败中止批次。最大 TSV 行 65536 字节、JSONL 行 524288 字节，单次输入最多 16 MiB。LF、CRLF、无末尾 LF 均接受。`INPUT = ACCEPTED + REJECTED`，示例结果为 5 = 4 + 1，报表 TOTAL 4。两个 import 输出各自原子替换，不能当成跨文件事务。

`tools/replay.pl --case all` 自动创建隔离临时目录，检查守恒、金标、拒绝清单、参数与路径边界、非法字节、JSON 类型、空结果、I/O 注入、资源限额、SIGTERM、断裂管道、旧报表保护和 worker 故障。`tools/cli-faults.py` 的资源限额和 FIFO 探针是 POSIX 实验；Windows 不在本次运行范围。默认累计 TAP 不包含 `fixtures/deliberate-*.t`：这两个文件故意给错期望，单独执行必须失败，正常金标无需修改。

当前精确环境和全量复跑结果见 VERSIONS.md 的补全节及仓库 `writing-plans/perl-language/completion/`。下面保存四字段历史入口，不能把它的参数直接用于新入口。

## 历史四字段入口

从仓库根目录运行，不设置生产日志路径：

```sh
perl examples/perl-language/bin/logtool.pl import examples/perl-language/fixtures/demo.tsv
perl examples/perl-language/bin/logtool.pl parse examples/perl-language/fixtures/demo.tsv
perl examples/perl-language/bin/logtool.pl query examples/perl-language/fixtures/demo.tsv WARN
perl examples/perl-language/bin/logtool.pl report examples/perl-language/fixtures/demo.tsv
perl examples/perl-language/bin/logtool.pl report-csv examples/perl-language/fixtures/demo.tsv
perl examples/perl-language/bin/logtool.pl --help
perl examples/perl-language/bin/logtool.pl probe examples/perl-language/fixtures/demo.tsv 'alpha;echo BAD'
perl examples/perl-language/bin/logtool.pl report-file examples/perl-language/fixtures/demo.tsv /tmp/my-synthetic-report.tsv
prove -r examples/perl-language/t
perl examples/perl-language/experiments/16-20-patterns.pl 16
perl examples/perl-language/experiments/16-20-patterns.pl 17
perl examples/perl-language/experiments/16-20-patterns.pl 18
perl examples/perl-language/experiments/16-20-patterns.pl 19
perl examples/perl-language/experiments/16-20-patterns.pl 20
```

输入是 UTF-8 TSV：`YYYY-MM-DDTHH:MM:SSZ<TAB>LEVEL<TAB>service<TAB>message<LF>`。LEVEL 为 INFO/WARN/ERROR，service 为 ASCII 名称（输入可含大写，输出规范为小写），message 可为空；时间范围为 1970–2099，使用 `Time::Local::timegm_modern` 检查有效 UTC 日历及秒数，但未验证源日志时间戳的真实性。行末 LF 可省略，CRLF 不接受。`import` 返回条数，`parse` 返回规范字段，`query` 以等级筛选，`report` 返回 TOTAL 和出现等级的排序计数。解析输出 UTF-8 字节，不依赖终端 locale。遇到无法打开的路径、无效 UTF-8 或错误字段，中止整个文件并返回非零，已解析部分不作为成功导入发布。`query ERROR` 在样本中无结果，成功且 STDOUT 为空；这属于记录过的空结果而非未运行。

金标位于 `fixtures/` 与 `golden/`，附加正则对照输出在 `t/15-20-query-and-patterns.t` 的 `%golden`。`t/00-contract.t` 用真实子进程逐字节比对 STDOUT、检查 STDERR 和退出码，包括拒绝样本。逐篇证据在 `evidence/00.md`、`evidence/15-20.md`、`evidence/21-25.md`、`evidence/26-31.md`、`evidence/32-39.md`、`evidence/E01-E08.md`。`fixtures/deliberate-failure.t` 是**明确要求 prove 失败**的 TAP 反例，不在默认 `t/` 累计回归中。`report-csv` 使用 `vendor/` 中隔离安装的 Text::CSV 2.06（强制纯 Perl 后端）；源包校验、版本与隔离安装见 `VERSIONS.md`。CLI 的 `probe` 用参数列表执行当前 Perl 的固定短脚本，不接受任意可执行文件路径；它不是通用进程管理器。`report-file` 先完整读取并编码报表，在同目录建立临时文件，成功关闭后 rename 替换目标并输出 `SAVED`；需要可信目录，持久化侧边锁文件 `.lock`，仅协作写入者互斥，未承诺断电持久性和跨平台语义。当前对稳定普通文件设 1 MiB 输入上限；流和竞态下的严格峰值内存上界 `NOT_RUN`。

本地仅用于发行练习（不上传 CPAN）：在临时目录复制本示例树，配置 `PERL5LIB=vendor/lib/perl5 perl Makefile.PL INSTALL_BASE=/tmp/.../install`，执行 `make manifest && make dist`；解开 `LogTool-0.100.tar.gz` 后再次配置，执行 `make test && make install`。再从随包 `vendor/Text-CSV-2.06.tar.gz` 单独隔离安装 Text::CSV 到同一 `INSTALL_BASE`；运行安装后的 `bin/logtool.pl` 前需将隔离路径 `lib/perl5` 放入 `PERL5LIB`。发行包的 `MANIFEST.SKIP` 不把测试过程证据塞进 distribution，完整证据由第 00 篇的素材包承载；每次重新发布前都需重新核对来源与复跑结果。
