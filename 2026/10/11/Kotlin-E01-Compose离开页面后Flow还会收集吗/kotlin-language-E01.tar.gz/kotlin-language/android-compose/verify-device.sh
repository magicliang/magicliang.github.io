#!/usr/bin/env bash
set -euo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
sdk="${ANDROID_HOME:?set ANDROID_HOME to the isolated SDK}"
evidence="${E01_EVIDENCE:-$project/../../../writing-plans/kotlin/verification/E01}"
mkdir -p "$evidence"
adb="$sdk/platform-tools/adb"
apk="$project/app/build/outputs/apk/debug/app-debug.apk"

"$adb" devices -l > "$evidence/adb-devices.txt"
test "$("$adb" shell getprop sys.boot_completed | tr -d '\r')" = 1
"$adb" shell getprop ro.build.fingerprint > "$evidence/device-fingerprint.txt"
"$adb" shell am force-stop example.tasks.compose
"$adb" shell settings put system accelerometer_rotation 0
"$adb" shell settings put system user_rotation 0
"$adb" logcat -c
"$adb" install -r "$apk" > "$evidence/install.txt"
"$adb" shell am start -W -n example.tasks.compose/.TaskActivity > "$evidence/launch.txt"
for attempt in {1..15}; do
    "$adb" logcat -d -t 300 -s KotlinE01:I > "$evidence/foreground.txt"
    if grep -q 'CREATE restored=false' "$evidence/foreground.txt" && grep -q 'COLLECT tick=' "$evidence/foreground.txt"; then
        break
    fi
    sleep 3
done
grep -q 'CREATE restored=false' "$evidence/foreground.txt"
grep -q 'COLLECT tick=' "$evidence/foreground.txt"

"$adb" shell uiautomator dump /sdcard/e01.xml > "$evidence/ui-dump-command.txt"
"$adb" shell cat /sdcard/e01.xml > "$evidence/ui-before.xml"
grep -q 'Tap count 0' "$evidence/ui-before.xml"
"$adb" shell input tap 170 180
"$adb" shell input tap 170 180
sleep 3
"$adb" shell uiautomator dump /sdcard/e01.xml >> "$evidence/ui-dump-command.txt"
"$adb" shell cat /sdcard/e01.xml > "$evidence/ui-clicked.xml"
grep -q 'Tap count 2' "$evidence/ui-clicked.xml"

"$adb" shell input keyevent KEYCODE_HOME
sleep 7
"$adb" logcat -d -t 300 -s KotlinE01:I > "$evidence/background-start.txt"
grep -q 'STOP' "$evidence/background-start.txt"
grep -q 'COLLECTION_STOP tick=' "$evidence/background-start.txt"
sleep 7
"$adb" logcat -d -t 300 -s KotlinE01:I > "$evidence/background-later.txt"
first_background_tick="$(grep 'COLLECT tick=' "$evidence/background-start.txt" | tail -1 | sed -E 's/.*COLLECT tick=([0-9]+).*/\1/')"
later_background_tick="$(grep 'COLLECT tick=' "$evidence/background-later.txt" | tail -1 | sed -E 's/.*COLLECT tick=([0-9]+).*/\1/')"
test "$first_background_tick" = "$later_background_tick"

"$adb" shell am start -W -n example.tasks.compose/.TaskActivity > "$evidence/resume.txt"
sleep 7
"$adb" logcat -d -t 300 -s KotlinE01:I > "$evidence/resumed.txt"
grep -q 'COLLECT tick=1$' "$evidence/resumed.txt"
"$adb" shell uiautomator dump /sdcard/e01.xml >> "$evidence/ui-dump-command.txt"
"$adb" shell cat /sdcard/e01.xml > "$evidence/ui-resumed.xml"
grep -q 'Tap count 2' "$evidence/ui-resumed.xml"

"$adb" shell settings put system accelerometer_rotation 0
"$adb" shell settings put system user_rotation 1
sleep 10
"$adb" logcat -d -t 300 -s KotlinE01:I > "$evidence/rotated.txt"
grep -q 'CREATE restored=true' "$evidence/rotated.txt"
"$adb" shell uiautomator dump /sdcard/e01.xml >> "$evidence/ui-dump-command.txt"
"$adb" shell cat /sdcard/e01.xml > "$evidence/ui-rotated.xml"
grep -q 'Tap count 2' "$evidence/ui-rotated.xml"

{
    printf 'background_first_last_tick=%s\n' "$first_background_tick"
    printf 'background_second_last_tick=%s\n' "$later_background_tick"
    printf 'resumed_tick_1=PASS\n'
    printf 'button_after_taps=2\nbutton_after_background=2\nbutton_after_rotation=2\nDEVICE_ASSERTIONS=PASS\n'
} > "$evidence/assertions.txt"
cat "$evidence/assertions.txt"
