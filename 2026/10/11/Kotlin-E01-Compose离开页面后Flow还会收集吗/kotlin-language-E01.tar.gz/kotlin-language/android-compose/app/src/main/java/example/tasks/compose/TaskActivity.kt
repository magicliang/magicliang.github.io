package example.tasks.compose

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.flow

class TaskActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i("KotlinE01", "CREATE restored=${savedInstanceState != null}")
        setContent {
            var clicks by rememberSaveable { mutableIntStateOf(0) }
            val progress = remember {
                flow {
                    var tick = 0
                    try {
                        while (true) {
                            delay(1000)
                            emit(++tick)
                            Log.i("KotlinE01", "COLLECT tick=$tick")
                        }
                    } finally {
                        Log.i("KotlinE01", "COLLECTION_STOP tick=$tick")
                    }
                }
            }
            val ticks by progress.collectAsStateWithLifecycle(initialValue = 0)
            SideEffect { Log.i("KotlinE01", "COMMIT clicks=$clicks ticks=$ticks") }
            Column {
                Text("Task progress $ticks")
                Button(onClick = { clicks++ }) { Text("Tap count $clicks") }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Log.i("KotlinE01", "START")
    }

    override fun onStop() {
        Log.i("KotlinE01", "STOP")
        super.onStop()
    }
}
