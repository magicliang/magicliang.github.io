# cache-consistency（第 25 章：缓存旧值回填与失效修复）

运行：`./run.sh`（启动集群 b3-25，端口 55425，库 cache25；编译并运行 `lab.cache.CacheLab`；输出写入 `../../evidence/25/`；最后停集群）。

| 文件 | 作用 |
|---|---|
| `src/lab/cache/VersionedCache.java` | 缓存替身：get、delete、add、gets/cas、putIfNewer、带版本墓碑 invalidate、租约 getOrLease/fillWithLease；手动时钟 TTL |
| `src/lab/cache/Store.java` | PostgreSQL 真相源：`item`（单调 version）与失效 outbox `cache_invalidation` |
| `src/lab/cache/CacheAside.java` | 五种回填/失效策略的读写路径，带测试注入点 |
| `src/lab/cache/CacheServer.java`、`CacheClient.java` | 本地 TCP 文本协议，供子进程写者与补删任务访问缓存 |
| `src/lab/cache/OutboxRelay.java` | 补删任务：`FOR UPDATE SKIP LOCKED` 领取，先发送后标记 |
| `src/lab/cache/Scanner.java` | 巡检：比较缓存版本与数据库版本并修复 |
| `src/lab/cache/CrashWriter.java` | 独立 JVM 写者，提交后等待父进程放行，用于 kill -9 |
| `src/lab/cache/CacheLab.java` | 用例 C1–C15 |

缓存是进程内替身，不是 memcached 或 Redis；限制见 `../../evidence/25/LIMITS.md`。
