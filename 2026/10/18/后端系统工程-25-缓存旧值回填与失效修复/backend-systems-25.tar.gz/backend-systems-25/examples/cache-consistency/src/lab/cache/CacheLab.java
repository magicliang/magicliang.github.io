package lab.cache;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import lab.cache.CacheAside.ReadResult;
import lab.cache.CacheAside.Strategy;
import lab.cache.VersionedCache.Put;
import lab.common.Check;
import lab.common.Db;

/** 第 25 章全部用例。读者、写者是真实线程，数据库是真实 PostgreSQL 16 事务；缓存 TTL 用手动时钟。 */
public final class CacheLab {
    static final long TTL = 100, TOMB_TTL = 1000, LEASE_TTL = 50;
    static final AtomicLong now = new AtomicLong();
    static final ExecutorService pool = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r);
        t.setDaemon(true);
        return t;
    });

    public static void main(String[] args) throws Exception {
        String db = System.getenv().getOrDefault("LAB_DB", "cache25");
        Db.recreate(db);
        try (Connection c = Db.connect()) {
            Store.schema(c);
        }
        c1Contract();
        c2NormalPath();
        c3AddDeleteRace();
        c4VersionWithoutTombstone();
        c5VersionTombstone();
        c6ReorderedInvalidations();
        c7TombstoneTtlTooShort();
        c8Lease();
        c9DoubleDelete();
        c10Stress();
        c11OutboxCrash();
        c12CrashWithoutOutbox();
        c13RelayCacheUnreachable();
        c14RelayConcurrent();
        c15Scanner();
        pool.shutdownNow();
        System.exit(Check.finish());
    }

    // ---------- 辅助 ----------

    static VersionedCache newCache() {
        now.set(0);
        return new VersionedCache(now::get);
    }

    static void await(CountDownLatch l) {
        try {
            if (!l.await(10, TimeUnit.SECONDS)) throw new IllegalStateException("latch timeout");
        } catch (InterruptedException e) {
            throw new IllegalStateException(e);
        }
    }

    static void seed(String key) throws Exception {
        try (Connection c = Db.connect()) {
            Store.seed(c, key, "p1");
        }
    }

    static long dbVersion(String key) throws Exception {
        try (Connection c = Db.connect()) {
            return Store.read(c, key).version();
        }
    }

    static String show(VersionedCache.Entry e) {
        if (e == null) return "MISS";
        return e.tombstone() ? "TOMB(v" + e.version() + ")" : "VALUE(v" + e.version() + "," + e.value() + ")";
    }

    record Race(ReadResult slowReader, long committed) {}

    /**
     * 固定交错：读者未命中并读到旧行后停住 → 写者线程提交并失效 → beforeFill → 读者回填。
     * 读者和写者各用自己的连接；顺序由闩锁保证，与线程调度无关。
     */
    static Race race(CacheAside aside, String key, String newPayload, Runnable beforeFill) throws Exception {
        CountDownLatch readDone = new CountDownLatch(1), fillGo = new CountDownLatch(1);
        Future<ReadResult> reader = pool.submit(() -> {
            try (Connection c = Db.connect()) {
                return aside.read(c, key, () -> {
                    readDone.countDown();
                    await(fillGo);
                });
            }
        });
        await(readDone);
        Future<Long> writer = pool.submit(() -> {
            try (Connection c = Db.connect()) {
                return aside.write(c, key, newPayload);
            }
        });
        long v = writer.get(10, TimeUnit.SECONDS);
        beforeFill.run();
        fillGo.countDown();
        return new Race(reader.get(10, TimeUnit.SECONDS), v);
    }

    // ---------- C1 缓存替身契约 ----------

    static void c1Contract() {
        Check.begin("C1", "缓存替身契约：add / gets+cas / 仅当版本更大 / 带版本墓碑 / TTL 边界");
        VersionedCache k = newCache();
        Check.equal(Put.NOT_FOUND, k.cas("a", "x", 1, TTL, 0), "键不存在时 cas 返回 NOT_FOUND（未命中时 cas 无从比较）");
        Check.equal(Put.STORED, k.add("a", "x", 1, TTL), "键不存在时 add");
        Check.equal(Put.NOT_STORED, k.add("a", "y", 2, TTL), "键已存在时 add 不覆盖，即使版本更大");
        long cas = k.gets("a");
        Check.equal(Put.STORED, k.cas("a", "y", 2, TTL, cas), "gets 得到的 cas 唯一值未变时 cas 成功");
        Check.equal(Put.EXISTS, k.cas("a", "z", 3, TTL, cas), "用旧 cas 唯一值再写返回 EXISTS");
        Check.equal(Put.REJECTED, k.putIfNewer("a", "old", 1, TTL), "仅当版本更大：v1 不能覆盖 v2");
        Check.equal(Put.REJECTED, k.putIfNewer("a", "same", 2, TTL), "仅当版本更大：同版本不覆盖值条目");
        Check.equal(Put.STORED, k.putIfNewer("a", "p3", 3, TTL), "仅当版本更大：v3 覆盖 v2");
        Check.equal(Put.IGNORED, k.invalidate("a", 3, TOMB_TTL), "失效版本不高于现有值版本时忽略（重复失效不删新值）");
        Check.equal(Put.STORED, k.invalidate("a", 4, TOMB_TTL), "失效 v4 写入墓碑");
        Check.equal(Put.IGNORED, k.invalidate("a", 3, TOMB_TTL), "更旧的失效不会调低墓碑版本");
        Check.equal(Put.REJECTED, k.putIfNewer("a", "p3", 3, TTL), "墓碑 v4 拒绝 v3 回填");
        Check.equal(Put.NOT_STORED, k.add("a", "p3", 3, TTL), "add 把墓碑当作已存在");
        Check.equal(Put.STORED, k.putIfNewer("a", "p4", 4, TTL), "墓碑 v4 接受同版本 v4 回填");
        now.set(TTL - 1);
        Check.equal("VALUE(v4,p4)", show(k.get("a")), "t=TTL-1 仍可读");
        now.set(TTL);
        Check.equal("MISS", show(k.get("a")), "t=TTL 过期（now >= expiresAt 视为不存在）");
    }

    // ---------- C2 正常路径 ----------

    static void c2NormalPath() throws Exception {
        Check.begin("C2", "正常路径（版本条件写 + 带版本墓碑）：未命中回填 → 命中 → 更新 → 回填新版本");
        String key = "sku-lab-02";
        seed(key);
        VersionedCache k = newCache();
        CacheAside a = new CacheAside(k, Strategy.VERSION_TOMBSTONE, TTL, TOMB_TTL, LEASE_TTL);
        try (Connection c = Db.connect()) {
            ReadResult r1 = a.read(c, key);
            Check.that(r1.source().equals("DB") && r1.version() == 1 && r1.fill() == Put.STORED, "首次读：未命中，读库 v1，回填 STORED");
            ReadResult r2 = a.read(c, key);
            Check.that(r2.source().equals("HIT") && r2.version() == 1, "再次读命中 v1");
            long v = a.write(c, key, "p2");
            Check.equal(2L, v, "写入后数据库版本");
            Check.equal("TOMB(v2)", show(k.get(key)), "提交后缓存为 v2 墓碑");
            ReadResult r3 = a.read(c, key);
            Check.that(r3.source().equals("DB") && r3.version() == 2 && r3.fill() == Put.STORED, "墓碑视为未命中，读库 v2 回填 STORED");
            Check.equal("VALUE(v2,p2)", show(k.get(key)), "缓存与数据库一致");
        }
    }

    // ---------- C3 Cache Aside 竞态（负向对照） ----------

    static void c3AddDeleteRace() throws Exception {
        Check.begin("C3", "负向对照：add 回填 + delete 失效。慢读者在写者提交并删除后回填 v1");
        String key = "sku-lab-03";
        seed(key);
        VersionedCache k = newCache();
        CacheAside a = new CacheAside(k, Strategy.ADD_DELETE, TTL, TOMB_TTL, LEASE_TTL);
        Race r = race(a, key, "p2", () -> now.set(5));
        Check.note("事件：t=0 读者未命中 → 读库 v1 → 停住；t=0 写者提交 v2 → delete；t=5 读者 add v1 = " + r.slowReader().fill());
        Check.equal(2L, dbVersion(key), "数据库已是 v2");
        Check.exposes(r.slowReader().fill() == Put.STORED && k.get(key).version() == 1, "删除之后的 add 成功，缓存存入 v1");
        now.set(5 + TTL - 1);
        Check.exposes(k.get(key) != null && k.get(key).version() == 1, "t=" + now.get() + "（回填后 TTL-1）缓存仍返回 v1");
        now.set(5 + TTL);
        Check.equal("MISS", show(k.get(key)), "t=" + now.get() + " 旧值随 TTL 过期");
        try (Connection c = Db.connect()) {
            ReadResult rr = a.read(c, key);
            Check.that(rr.version() == 2 && rr.fill() == Put.STORED, "过期后读库 v2 回填");
        }
        Check.note("旧值可见区间 [0, 105)：提交时刻 0 到 回填时刻 5 + TTL 100");
    }

    // ---------- C4 版本条件写但不留墓碑（负向对照） ----------

    static void c4VersionWithoutTombstone() throws Exception {
        Check.begin("C4", "负向对照：仅当版本更大写入 + 普通 delete。删除后键不存在，v1 被当作“更新”写入");
        String key = "sku-lab-04";
        seed(key);
        VersionedCache k = newCache();
        CacheAside a = new CacheAside(k, Strategy.VERSION_DELETE, TTL, TOMB_TTL, LEASE_TTL);
        Race r = race(a, key, "p2", () -> {});
        Check.note("事件：读者读库 v1 → 写者提交 v2 → delete → 读者 putIfNewer(v1) = " + r.slowReader().fill());
        Check.exposes(r.slowReader().fill() == Put.STORED && "VALUE(v1,p1)".equals(show(k.get(key))),
                "缓存存入 v1，而数据库为 v" + dbVersion(key));
    }

    // ---------- C5 带版本墓碑 ----------

    static void c5VersionTombstone() throws Exception {
        Check.begin("C5", "修复：仅当版本更大写入 + 带版本墓碑。同一交错下慢读者的 v1 回填被拒绝");
        String key = "sku-lab-05";
        seed(key);
        VersionedCache k = newCache();
        CacheAside a = new CacheAside(k, Strategy.VERSION_TOMBSTONE, TTL, TOMB_TTL, LEASE_TTL);
        Race r = race(a, key, "p2", () -> now.set(5));
        Check.note("事件：读者读库 v1 → 写者提交 v2 → 墓碑 v2 → t=5 读者 putIfNewer(v1) = " + r.slowReader().fill());
        Check.equal(Put.REJECTED, r.slowReader().fill(), "v1 回填被墓碑 v2 拒绝");
        Check.equal("TOMB(v2)", show(k.get(key)), "缓存仍为墓碑 v2");
        try (Connection c = Db.connect()) {
            ReadResult rr = a.read(c, key);
            Check.that(rr.version() == 2 && rr.fill() == Put.STORED, "下一次读回填 v2");
        }
    }

    // ---------- C6 乱序失效 ----------

    static void c6ReorderedInvalidations() throws Exception {
        Check.begin("C6", "边界：两个写者的失效乱序到达（先 v3 后 v2），慢读者持 v1、另一读者持 v2");
        String key = "sku-lab-06";
        seed(key);
        VersionedCache k = newCache();
        CacheAside a = new CacheAside(k, Strategy.VERSION_TOMBSTONE, TTL, TOMB_TTL, LEASE_TTL);
        long v2, v3;
        ReadResult slowV1;
        ReadResult readerV2;
        try (Connection rc = Db.connect(); Connection wc = Db.connect(); Connection rc2 = Db.connect()) {
            Store.Row old = Store.read(rc, key);                       // 读者 A：读到 v1，尚未回填
            v2 = Store.update(wc, key, "p2", false);                   // 写者 W2 提交 v2，失效延迟
            Store.Row mid = Store.read(rc2, key);                      // 读者 B：读到 v2，尚未回填
            v3 = Store.update(wc, key, "p3", false);                   // 写者 W3 提交 v3
            Check.equal(Put.STORED, k.invalidate(key, v3, TOMB_TTL), "W3 的失效先到：墓碑 v3");
            Check.equal(Put.IGNORED, k.invalidate(key, v2, TOMB_TTL), "W2 的失效后到：被忽略，墓碑不降级");
            slowV1 = new ReadResult(old.payload(), old.version(), "DB", k.putIfNewer(key, old.payload(), old.version(), TTL));
            readerV2 = new ReadResult(mid.payload(), mid.version(), "DB", k.putIfNewer(key, mid.payload(), mid.version(), TTL));
        }
        Check.note("事件：A 读 v1；W2 提交 v2；B 读 v2；W3 提交 v3；失效 v3 到达；失效 v2 到达；A 回填 v1；B 回填 v2");
        Check.equal(Put.REJECTED, slowV1.fill(), "A 的 v1 回填被拒绝");
        Check.equal(Put.REJECTED, readerV2.fill(), "B 的 v2 回填被拒绝（v2 已被 v3 取代）");
        Check.equal("TOMB(v3)", show(k.get(key)), "缓存保持墓碑 v3");
        try (Connection c = Db.connect()) {
            ReadResult rr = a.read(c, key);
            Check.that(rr.version() == v3 && rr.fill() == Put.STORED, "后续读回填 v3");
        }
    }

    // ---------- C7 墓碑寿命短于读者停顿 ----------

    static void c7TombstoneTtlTooShort() throws Exception {
        Check.begin("C7", "失效边界：墓碑 TTL=30 短于读者停顿 31，墓碑过期后 v1 回填重新成功");
        String key = "sku-lab-07";
        seed(key);
        VersionedCache k = newCache();
        CacheAside a = new CacheAside(k, Strategy.VERSION_TOMBSTONE, TTL, 30, LEASE_TTL);
        Race r = race(a, key, "p2", () -> now.set(31));
        Check.note("事件：t=0 读者读 v1；t=0 写者提交 v2、墓碑 v2（到期 t=30）；t=31 读者 putIfNewer(v1) = " + r.slowReader().fill());
        Check.exposes(r.slowReader().fill() == Put.STORED && k.get(key).version() == 1,
                "墓碑过期后保护消失，缓存重新存入 v1（数据库 v" + dbVersion(key) + "）");
    }

    // ---------- C8 租约 ----------

    static void c8Lease() throws Exception {
        Check.begin("C8", "租约令牌：未命中领令牌，delete 作废令牌；并发未命中者不回填");
        String key = "sku-lab-08";
        seed(key);
        VersionedCache k = newCache();
        CacheAside a = new CacheAside(k, Strategy.LEASE_DELETE, TTL, TOMB_TTL, LEASE_TTL);
        CountDownLatch readDone = new CountDownLatch(1), fillGo = new CountDownLatch(1);
        Future<ReadResult> slow = pool.submit(() -> {
            try (Connection c = Db.connect()) {
                return a.read(c, key, () -> {
                    readDone.countDown();
                    await(fillGo);
                });
            }
        });
        await(readDone);
        ReadResult second;
        try (Connection c = Db.connect()) {
            second = a.read(c, key);                                  // 租约被 A 持有：读库但不回填
        }
        Check.that(second.source().equals("DB") && second.fill() == Put.NOT_STORED, "租约期内的第二个未命中者读库但不回填");
        long v = pool.submit(() -> {
            try (Connection c = Db.connect()) {
                return a.write(c, key, "p2");
            }
        }).get(10, TimeUnit.SECONDS);
        fillGo.countDown();
        ReadResult r = slow.get(10, TimeUnit.SECONDS);
        Check.note("事件：A 领令牌 → 读 v1 → 停住；B 未命中（令牌已发出）读库不回填；写者提交 v" + v + " → delete 作废令牌；A 持旧令牌回填 = " + r.fill());
        Check.equal(Put.REJECTED, r.fill(), "被作废的令牌回填失败");
        Check.equal("MISS", show(k.get(key)), "缓存仍为空");
        try (Connection c = Db.connect()) {
            ReadResult rr = a.read(c, key);
            Check.that(rr.version() == 2 && rr.fill() == Put.STORED, "新未命中者领新令牌，回填 v2");
        }
    }

    // ---------- C9 延迟双删（负向对照） ----------

    static void c9DoubleDelete() throws Exception {
        Check.begin("C9", "负向对照：延迟双删。回填落在第二次删除之前被修复，落在之后仍留旧值");
        // (a) 读者回填发生在两次删除之间
        String ka = "sku-lab-09a";
        seed(ka);
        VersionedCache k = newCache();
        CacheAside a = new CacheAside(k, Strategy.DOUBLE_DELETE, TTL, TOMB_TTL, LEASE_TTL);
        CountDownLatch readDone = new CountDownLatch(1), fillGo = new CountDownLatch(1), fillDone = new CountDownLatch(1);
        Future<ReadResult> reader = pool.submit(() -> {
            try (Connection c = Db.connect()) {
                ReadResult rr = a.read(c, ka, () -> {
                    readDone.countDown();
                    await(fillGo);
                });
                fillDone.countDown();
                return rr;
            }
        });
        await(readDone);
        pool.submit(() -> {
            try (Connection c = Db.connect()) {
                return a.write(c, ka, "p2", () -> {
                    fillGo.countDown();
                    await(fillDone);
                });
            }
        }).get(10, TimeUnit.SECONDS);
        ReadResult ra = reader.get(10, TimeUnit.SECONDS);
        Check.note("(a) 读者读 v1；写者提交 v2 → delete#1 → 读者 add v1 = " + ra.fill() + " → delete#2");
        Check.equal("MISS", show(k.get(ka)), "(a) 第二次删除清掉了 v1");
        // (b) 读者停顿超过两次删除的间隔
        String kb = "sku-lab-09b";
        seed(kb);
        Race rb = race(a, kb, "p2", () -> {});
        Check.note("(b) 读者读 v1；写者提交 v2 → delete#1 → delete#2；读者 add v1 = " + rb.slowReader().fill());
        Check.exposes(k.get(kb) != null && k.get(kb).version() == 1, "(b) 第二次删除早于回填，v1 留在缓存直到 TTL");
    }

    // ---------- C10 并发压力 ----------

    static int stress(Strategy s, long seed, int[] fillCounts) throws Exception {
        String[] keys = {"sku-lab-10a", "sku-lab-10b", "sku-lab-10c", "sku-lab-10d"};
        VersionedCache k = newCache();
        CacheAside a = new CacheAside(k, s, 1_000_000, 1_000_000, LEASE_TTL);
        int threads = 8, ops = 300;
        AtomicInteger stored = new AtomicInteger(), rejected = new AtomicInteger(), writes = new AtomicInteger();
        List<Future<?>> fs = new ArrayList<>();
        CountDownLatch start = new CountDownLatch(1);
        for (int t = 0; t < threads; t++) {
            Random rnd = new Random(seed + t);
            fs.add(pool.submit(() -> {
                try (Connection c = Db.connect()) {
                    await(start);
                    for (int i = 0; i < ops; i++) {
                        String key = keys[rnd.nextInt(keys.length)];
                        if (rnd.nextInt(5) == 0) {
                            a.write(c, key, "w" + rnd.nextInt(1000));
                            writes.incrementAndGet();
                        } else {
                            int pause = rnd.nextInt(3);
                            ReadResult r = a.read(c, key, () -> {
                                try {
                                    Thread.sleep(pause);
                                } catch (InterruptedException e) {
                                    Thread.currentThread().interrupt();
                                }
                            });
                            if (r.fill() == Put.STORED) stored.incrementAndGet();
                            else if (r.fill() == Put.REJECTED || r.fill() == Put.NOT_STORED) rejected.incrementAndGet();
                        }
                    }
                }
                return null;
            }));
        }
        start.countDown();
        for (Future<?> f : fs) f.get(120, TimeUnit.SECONDS);
        int staleEntries = 0;
        for (String key : keys) {
            VersionedCache.Entry e = k.get(key);
            if (e != null && !e.tombstone() && e.version() != dbVersion(key)) staleEntries++;
        }
        fillCounts[0] = stored.get();
        fillCounts[1] = rejected.get();
        fillCounts[2] = writes.get();
        return staleEntries;
    }

    static void c10Stress() throws Exception {
        Check.begin("C10", "真实并发：8 线程 × 300 次操作、4 个键、约 20% 写，读者在读库与回填之间随机停 0–2ms");
        for (String key : new String[]{"sku-lab-10a", "sku-lab-10b", "sku-lab-10c", "sku-lab-10d"}) seed(key);
        int[] cnt = new int[3];
        int staleTomb = stress(Strategy.VERSION_TOMBSTONE, 2510, cnt);
        Check.note("VERSION_TOMBSTONE：写=" + cnt[2] + " 回填成功=" + cnt[0] + " 回填被拒=" + cnt[1] + " 静止后旧值条目=" + staleTomb);
        Check.equal(0, staleTomb, "静止后每个值条目的版本都等于数据库版本");
        int staleAdd = stress(Strategy.ADD_DELETE, 2510, cnt);
        Check.note("ADD_DELETE（同种子，交错不可重复）：写=" + cnt[2] + " 回填成功=" + cnt[0] + " 未写入=" + cnt[1]
                + " 静止后旧值条目=" + staleAdd + "（本次计数，不作断言）");
    }

    // ---------- C11 多进程：提交后崩溃，outbox 补删 ----------

    static Process spawnWriter(String mode, String key, String payload, int cachePort) throws Exception {
        String java = ProcessHandle.current().info().command().orElse("java");
        ProcessBuilder pb = new ProcessBuilder(java, "-cp", System.getProperty("java.class.path"),
                "lab.cache.CrashWriter", mode, key, payload, String.valueOf(cachePort), String.valueOf(TOMB_TTL));
        pb.redirectErrorStream(true);
        return pb.start();
    }

    static int kill9(Process p) throws Exception {
        Process k = new ProcessBuilder("kill", "-9", String.valueOf(p.pid())).start();
        k.waitFor();
        p.waitFor(10, TimeUnit.SECONDS);
        return p.exitValue();
    }

    static void restartPgImmediate() throws Exception {
        String sh = System.getenv("LAB_PG_SH"), name = System.getenv("LAB_PG_NAME"), port = System.getenv("LAB_PGPORT");
        Process p = new ProcessBuilder("bash", sh, "restart-immediate", name, port).redirectErrorStream(true).start();
        String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
        Check.equal(0, p.waitFor(), "pg.sh restart-immediate 退出码（输出：" + out + "）");
    }

    static void c11OutboxCrash() throws Exception {
        Check.begin("C11", "多进程：写者 JVM 同事务写 outbox，提交后 kill -9；数据库 immediate 重启；补删任务幂等修复");
        VersionedCache k = newCache();
        CacheAside a = new CacheAside(k, Strategy.VERSION_TOMBSTONE, TTL, TOMB_TTL, LEASE_TTL);
        try (CacheServer srv = new CacheServer(k)) {
            CacheClient client = new CacheClient(srv.port());
            // (a) 写者正常完成：提交 → 自己失效
            String k0 = "sku-lab-11a";
            seed(k0);
            try (Connection c = Db.connect()) {
                a.read(c, k0);
            }
            Process p0 = spawnWriter("outbox", k0, "p2", srv.port());
            BufferedReader o0 = new BufferedReader(new InputStreamReader(p0.getInputStream(), StandardCharsets.UTF_8));
            String l0 = o0.readLine();
            try (Writer w = new OutputStreamWriter(p0.getOutputStream(), StandardCharsets.UTF_8)) {
                w.write("go\n");
            }
            String l1 = o0.readLine();
            Check.equal(0, p0.waitFor(), "(a) 写者进程正常退出（输出：" + l0 + " / " + l1 + "）");
            Check.equal("TOMB(v2)", show(k.get(k0)), "(a) 写者经 TCP 写入墓碑 v2");
            try (Connection c = Db.connect()) {
                OutboxRelay.Outcome oc = OutboxRelay.runOnce(c, client, 10, TOMB_TTL, OutboxRelay.Fault.NONE);
                Check.equal(1, oc.marked(), "(a) outbox 行仍会被补删任务处理一次（重复失效被忽略）");
            }
            // (b) 写者提交后、失效前被 kill -9
            String key = "sku-lab-11b";
            seed(key);
            try (Connection c = Db.connect()) {
                Check.equal(Put.STORED, a.read(c, key).fill(), "(b) 预热：缓存存入 v1");
            }
            Process p = spawnWriter("outbox", key, "p2", srv.port());
            String line = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8)).readLine();
            int exit = kill9(p);
            Check.note("(b) 子进程 pid=" + p.pid() + " 输出 \"" + line + "\" 后收到 kill -9，退出码 " + exit);
            Check.equal(137, exit, "(b) 子进程被 SIGKILL 终止");
            Check.equal(2L, dbVersion(key), "(b) 提交已持久：数据库 v2");
            Check.equal("VALUE(v1,p1)", show(k.get(key)), "(b) 缓存仍是 v1：失效没有发出");
            restartPgImmediate();
            try (Connection c = Db.connect()) {
                Check.equal(2L, Store.read(c, key).version(), "(b) immediate 重启后数据库仍为 v2");
                Check.equal(1L, OutboxRelay.pending(c), "(b) immediate 重启后 outbox 待处理行仍在");
                OutboxRelay.Outcome crash = OutboxRelay.runOnce(c, client, 10, TOMB_TTL, OutboxRelay.Fault.CRASH_AFTER_SEND);
                Check.note("(b) 补删第 1 次：claimed=" + crash.claimed() + " marked=" + crash.marked() + " error=" + crash.error());
                Check.equal("TOMB(v2)", show(k.get(key)), "(b) 失效已送达缓存");
                Check.equal(1L, OutboxRelay.pending(c), "(b) 标记前崩溃，行仍待处理");
                ReadResult rr = a.read(c, key);
                Check.that(rr.version() == 2 && rr.fill() == Put.STORED, "(b) 读者回填 v2");
                OutboxRelay.Outcome ok = OutboxRelay.runOnce(c, client, 10, TOMB_TTL, OutboxRelay.Fault.NONE);
                Check.equal(1, ok.marked(), "(b) 补删第 2 次：重发并标记完成");
                Check.equal("VALUE(v2,p2)", show(k.get(key)), "(b) 重发的失效 v2 没有删掉已回填的 v2");
                Check.equal(0L, OutboxRelay.pending(c), "(b) 无待处理行");
            }
        }
    }

    // ---------- C12 多进程负向对照：没有 outbox ----------

    static void c12CrashWithoutOutbox() throws Exception {
        Check.begin("C12", "负向对照：写者不写 outbox，提交后 kill -9");
        VersionedCache k = newCache();
        CacheAside a = new CacheAside(k, Strategy.VERSION_TOMBSTONE, TTL, TOMB_TTL, LEASE_TTL);
        try (CacheServer srv = new CacheServer(k)) {
            String key = "sku-lab-12";
            seed(key);
            try (Connection c = Db.connect()) {
                a.read(c, key);
            }
            Process p = spawnWriter("plain", key, "p2", srv.port());
            String line = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8)).readLine();
            int exit = kill9(p);
            Check.note("子进程输出 \"" + line + "\" 后 kill -9，退出码 " + exit);
            try (Connection c = Db.connect()) {
                OutboxRelay.Outcome oc = OutboxRelay.runOnce(c, new CacheClient(srv.port()), 10, TOMB_TTL, OutboxRelay.Fault.NONE);
                Check.equal(0, oc.claimed(), "补删任务没有可处理的行");
            }
            now.set(TTL - 1);
            Check.exposes(k.get(key) != null && k.get(key).version() == 1 && dbVersion(key) == 2,
                    "t=TTL-1 缓存仍返回 v1，数据库为 v2；只能等 TTL 或巡检");
        }
    }

    // ---------- C13 缓存不可达 ----------

    static void c13RelayCacheUnreachable() throws Exception {
        Check.begin("C13", "恢复：补删时缓存不可达，行保持待处理；缓存恢复后补删成功");
        VersionedCache k = newCache();
        String key = "sku-lab-13";
        seed(key);
        CacheServer dead = new CacheServer(k);
        int deadPort = dead.port();
        dead.close();
        try (CacheServer srv = new CacheServer(k); Connection c = Db.connect()) {
            k.putIfNewer(key, "p1", 1, TTL);
            Store.update(c, key, "p2", true);
            OutboxRelay.Outcome fail = OutboxRelay.runOnce(c, new CacheClient(deadPort), 10, TOMB_TTL, OutboxRelay.Fault.NONE);
            Check.note("连接已关闭的端口：claimed=" + fail.claimed() + " marked=" + fail.marked() + " error=" + fail.error());
            Check.that(fail.error() != null && fail.marked() == 0, "发送失败，不标记完成");
            Check.equal(1L, OutboxRelay.pending(c), "行仍待处理");
            Check.equal("VALUE(v1,p1)", show(k.get(key)), "缓存不可达期间旧值仍在");
            OutboxRelay.Outcome ok = OutboxRelay.runOnce(c, new CacheClient(srv.port()), 10, TOMB_TTL, OutboxRelay.Fault.NONE);
            Check.equal(1, ok.marked(), "换到可达的缓存后补删完成");
            Check.equal("TOMB(v2)", show(k.get(key)), "缓存写入墓碑 v2");
        }
    }

    // ---------- C14 补删任务并发领取 ----------

    static void c14RelayConcurrent() throws Exception {
        Check.begin("C14", "补删任务并发：两个领取者用 FOR UPDATE SKIP LOCKED 处理 20 行");
        VersionedCache k = newCache();
        try (CacheServer srv = new CacheServer(k); Connection c = Db.connect()) {
            for (int i = 0; i < 20; i++) {
                String key = String.format("sku-lab-14-%02d", i);
                Store.seed(c, key, "p1");
                Store.update(c, key, "p2", true);
            }
            Check.equal(20L, OutboxRelay.pending(c), "待处理 20 行");
            CacheClient client = new CacheClient(srv.port());
            AtomicInteger marked = new AtomicInteger();
            List<Future<?>> fs = new ArrayList<>();
            for (int t = 0; t < 2; t++) {
                fs.add(pool.submit(() -> {
                    try (Connection rc = Db.connect()) {
                        while (true) {
                            OutboxRelay.Outcome o = OutboxRelay.runOnce(rc, client, 1, TOMB_TTL, OutboxRelay.Fault.NONE);
                            if (o.claimed() == 0) break;
                            marked.addAndGet(o.marked());
                        }
                    }
                    return null;
                }));
            }
            for (Future<?> f : fs) f.get(30, TimeUnit.SECONDS);
            Check.equal(0L, OutboxRelay.pending(c), "全部处理完");
            Check.equal(20, marked.get(), "标记完成 20 次");
            Check.equal(20, client.sent.get(), "失效命令发送 20 次（无行被两个领取者同时处理）");
            int tombs = 0;
            for (VersionedCache.Entry e : k.snapshot().values()) if (e.tombstone() && e.version() == 2) tombs++;
            Check.equal(20, tombs, "缓存中 20 个 v2 墓碑");
        }
    }

    // ---------- C15 巡检 ----------

    static void c15Scanner() throws Exception {
        Check.begin("C15", "巡检：比较缓存版本与数据库版本，发现旧值后用数据库版本修复");
        VersionedCache k = newCache();
        CacheAside naive = new CacheAside(k, Strategy.ADD_DELETE, TTL, TOMB_TTL, LEASE_TTL);
        CacheAside safe = new CacheAside(k, Strategy.VERSION_TOMBSTONE, TTL, TOMB_TTL, LEASE_TTL);
        String stale = "sku-lab-15a", fresh = "sku-lab-15b";
        seed(stale);
        seed(fresh);
        race(naive, stale, "p2", () -> {});
        try (Connection c = Db.connect()) {
            safe.read(c, fresh);
            Scanner.Result r1 = Scanner.scan(c, k, TOMB_TTL, () -> {});
            Check.note("第 1 轮：checked=" + r1.checked() + " stale=" + r1.stale() + " repaired=" + r1.repaired());
            Check.that(r1.checked() == 2 && r1.stale() == 1 && r1.repaired() == 1, "发现并修复 1 个旧值");
            Scanner.Result r2 = Scanner.scan(c, k, TOMB_TTL, () -> {});
            Check.that(r2.stale() == 0, "第 2 轮无旧值（checked=" + r2.checked() + "）");
            ReadResult rr = safe.read(c, stale);
            Check.that(rr.version() == 2 && rr.fill() == Put.STORED, "修复后读者回填 v2");
        }
        // 巡检读库之后、修复之前，又有写者提交 v3：修复命令带 v2，不会盖过墓碑 v3
        VersionedCache k2 = newCache();
        CacheAside naive2 = new CacheAside(k2, Strategy.ADD_DELETE, TTL, TOMB_TTL, LEASE_TTL);
        CacheAside safe2 = new CacheAside(k2, Strategy.VERSION_TOMBSTONE, TTL, TOMB_TTL, LEASE_TTL);
        String key = "sku-lab-15c";
        seed(key);
        race(naive2, key, "p2", () -> {});
        try (Connection c = Db.connect(); Connection wc = Db.connect()) {
            Scanner.Result r = Scanner.scan(c, k2, TOMB_TTL, () -> {
                try {
                    safe2.write(wc, key, "p3");
                } catch (Exception e) {
                    throw new IllegalStateException(e);
                }
            });
            Check.note("巡检读到 v2 后写者提交 v3 并写墓碑 v3：stale=" + r.stale() + " repaired=" + r.repaired() + " 缓存=" + show(k2.get(key)));
            Check.that(r.stale() == 1 && r.repaired() == 0, "巡检的 v2 修复被忽略");
            Check.equal("TOMB(v3)", show(k2.get(key)), "缓存保持墓碑 v3，没有被回退");
        }
    }
}
