package lab.cache;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicInteger;

/** CacheServer 的最小客户端：每条命令一个连接，带连接与读超时。 */
public final class CacheClient {
    private final int port;
    public final AtomicInteger sent = new AtomicInteger();

    public CacheClient(int port) {
        this.port = port;
    }

    public String call(String command) throws IOException {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress("127.0.0.1", port), 1000);
            s.setSoTimeout(2000);
            PrintWriter out = new PrintWriter(s.getOutputStream(), true, StandardCharsets.UTF_8);
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            out.println(command);
            String reply = in.readLine();
            if (reply == null) throw new IOException("connection closed without reply");
            sent.incrementAndGet();
            return reply;
        }
    }

    public String invalidate(String key, long version, long tombTtl) throws IOException {
        return call("INV " + key + " " + version + " " + tombTtl);
    }
}
