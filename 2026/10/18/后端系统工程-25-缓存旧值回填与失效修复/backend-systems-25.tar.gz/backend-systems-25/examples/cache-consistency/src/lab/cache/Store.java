package lab.cache;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import lab.common.Db;

/** 真相源：PostgreSQL 中带单调 version 列的行，以及同事务写入的失效 outbox。 */
public final class Store {
    private Store() {}

    public record Row(String payload, long version) {}

    public static void schema(Connection c) throws SQLException {
        Db.exec(c, """
            CREATE TABLE item (
              id      text PRIMARY KEY,
              payload text NOT NULL,
              version bigint NOT NULL CHECK (version > 0)
            );
            CREATE TABLE cache_invalidation (
              seq        bigserial PRIMARY KEY,
              item_id    text NOT NULL REFERENCES item(id),
              version    bigint NOT NULL,
              created_at timestamptz NOT NULL DEFAULT now(),
              done_at    timestamptz,
              UNIQUE (item_id, version)
            );
            CREATE INDEX cache_invalidation_pending ON cache_invalidation (seq) WHERE done_at IS NULL;
            """);
    }

    public static void seed(Connection c, String id, String payload) throws SQLException {
        Db.update(c, "INSERT INTO item(id, payload, version) VALUES (?, ?, 1)", id, payload);
    }

    public static Row read(Connection c, String id) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT payload, version FROM item WHERE id = ?")) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) throw new SQLException("no item " + id);
                return new Row(rs.getString(1), rs.getLong(2));
            }
        }
    }

    /**
     * 更新一行并把版本加一；withOutbox 为真时在同一事务内写入失效记录 (item_id, 新版本)。
     * 返回提交后的新版本。版本由数据库在行锁下递增，同一行的版本严格单调。
     */
    public static long update(Connection c, String id, String payload, boolean withOutbox) throws SQLException {
        boolean auto = c.getAutoCommit();
        c.setAutoCommit(false);
        try {
            long v;
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE item SET payload = ?, version = version + 1 WHERE id = ? RETURNING version")) {
                ps.setString(1, payload);
                ps.setString(2, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) throw new SQLException("no item " + id);
                    v = rs.getLong(1);
                }
            }
            if (withOutbox) {
                Db.update(c, "INSERT INTO cache_invalidation(item_id, version) VALUES (?, ?)", id, v);
            }
            c.commit();
            return v;
        } catch (SQLException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(auto);
        }
    }
}
