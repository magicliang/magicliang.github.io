#!/usr/bin/env bash
# 第 25 章：一条命令完成 启动集群 → 建库 → 编译 → 运行全部用例 → 写证据 → 停集群。
set -uo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
COMMON="$HERE/../common"
EVID="$HERE/../../evidence/25"
NAME=b3-25; PORT=55425
mkdir -p "$EVID"
export LAB_PGPORT=$PORT LAB_DB=cache25 LAB_PG_SH="$COMMON/pg.sh" LAB_PG_NAME=$NAME LAB_BUILD=/tmp/batch3-build/ch25
{
  echo "date: $(date -Is)"
  echo "uname: $(uname -a)"
  java -version 2>&1 | sed 's/^/java: /'
  echo "postgres: $(/usr/lib/postgresql/16/bin/postgres --version)"
  echo "pgjdbc: postgresql-42.7.7.jar"
} > "$EVID/env.txt"
cat > "$EVID/commands.txt" <<CMD
cd examples/cache-consistency && ./run.sh
  initdb -D /tmp/batch3-pg/$NAME -U postgres -A trust -E UTF8 --locale=C.UTF-8 -c dynamic_shared_memory_type=mmap（仅首次）
  ../common/pg.sh start $NAME $PORT
  LAB_PGPORT=$PORT LAB_DB=cache25 LAB_PG_SH=../common/pg.sh LAB_PG_NAME=$NAME ../common/lab.sh . lab.cache.CacheLab
  （C11、C12 用例内部启动子 JVM lab.cache.CrashWriter 并执行 kill -9 <pid>；C11 内部调用 ../common/pg.sh restart-immediate $NAME $PORT）
  ../common/pg.sh stop $NAME
CMD
# 本机 /dev/shm 容量小，预先以 mmap 动态共享内存 initdb；pg.sh 检测到 PG_VERSION 后不再 initdb。
PGDIR=${BATCH3_PG_ROOT:-/tmp/batch3-pg}/$NAME
if [ ! -f "$PGDIR/PG_VERSION" ]; then
  mkdir -p "$(dirname "$PGDIR")"
  /usr/lib/postgresql/16/bin/initdb -D "$PGDIR" -U postgres -A trust -E UTF8 --locale=C.UTF-8 \
    -c dynamic_shared_memory_type=mmap >/dev/null
fi
"$COMMON/pg.sh" start $NAME $PORT
"$COMMON/lab.sh" "$HERE" lab.cache.CacheLab > "$EVID/output.txt" 2>&1
rc=$?
"$COMMON/pg.sh" stop $NAME
echo "exit=$rc" >> "$EVID/commands.txt"
tail -n 3 "$EVID/output.txt"
exit $rc
