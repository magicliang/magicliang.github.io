package lab.cache;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

/**
 * 巡检：遍历缓存中的值条目，与数据库当前版本比较；缓存版本更低即为旧值，
 * 用数据库版本写带版本墓碑修复。修复命令带版本，巡检读到的数据库版本过时也不会回退缓存。
 */
public final class Scanner {
    public record Result(int checked, int stale, int repaired) {}

    private Scanner() {}

    public static Result scan(Connection c, VersionedCache cache, long tombTtl, Runnable afterDbRead) throws SQLException {
        int checked = 0, stale = 0, repaired = 0;
        for (Map.Entry<String, VersionedCache.Entry> en : cache.snapshot().entrySet()) {
            VersionedCache.Entry e = en.getValue();
            if (e.tombstone()) continue;
            checked++;
            long dbVersion = Store.read(c, en.getKey()).version();
            afterDbRead.run();
            if (e.version() < dbVersion) {
                stale++;
                if (cache.invalidate(en.getKey(), dbVersion, tombTtl) == VersionedCache.Put.STORED) repaired++;
            }
        }
        return new Result(checked, stale, repaired);
    }
}
