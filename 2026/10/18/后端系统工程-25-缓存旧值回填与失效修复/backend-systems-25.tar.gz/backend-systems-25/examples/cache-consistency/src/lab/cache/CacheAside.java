package lab.cache;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Cache Aside 读写路径。读：查缓存 → 未命中读库 → 回填；写：提交数据库 → 让缓存失效。
 * 五种策略只在“回填用哪条命令”和“失效用哪条命令”上不同，便于在同一交错下比较。
 */
public final class CacheAside {
    public enum Strategy {
        ADD_DELETE,        // 回填 add，失效 delete（基线）
        VERSION_DELETE,    // 回填“仅当版本更大”，失效 delete（不留墓碑）
        VERSION_TOMBSTONE, // 回填“仅当版本更大”，失效写带版本墓碑
        LEASE_DELETE,      // 未命中领租约，持令牌回填，失效 delete（作废令牌）
        DOUBLE_DELETE      // 回填 add，失效 delete → 等待 → 再 delete
    }

    public record ReadResult(String payload, long version, String source, VersionedCache.Put fill) {}

    private final VersionedCache cache;
    private final Strategy strategy;
    private final long ttl;
    private final long tombTtl;
    private final long leaseTtl;

    public CacheAside(VersionedCache cache, Strategy strategy, long ttl, long tombTtl, long leaseTtl) {
        this.cache = cache;
        this.strategy = strategy;
        this.ttl = ttl;
        this.tombTtl = tombTtl;
        this.leaseTtl = leaseTtl;
    }

    /** afterDbRead 在“读到数据库结果之后、回填之前”执行，测试用它把读者停在竞态窗口里。 */
    public ReadResult read(Connection c, String key, Runnable afterDbRead) throws SQLException {
        long token = 0;
        if (strategy == Strategy.LEASE_DELETE) {
            VersionedCache.LeaseGet lg = cache.getOrLease(key, leaseTtl);
            if (lg.hit() != null) return new ReadResult(lg.hit().value(), lg.hit().version(), "HIT", null);
            token = lg.token();
        } else {
            VersionedCache.Entry e = cache.get(key);
            if (e != null && !e.tombstone()) return new ReadResult(e.value(), e.version(), "HIT", null);
        }
        Store.Row row = Store.read(c, key);
        afterDbRead.run();
        VersionedCache.Put fill = switch (strategy) {
            case ADD_DELETE, DOUBLE_DELETE -> cache.add(key, row.payload(), row.version(), ttl);
            case VERSION_DELETE, VERSION_TOMBSTONE -> cache.putIfNewer(key, row.payload(), row.version(), ttl);
            case LEASE_DELETE -> token == 0 ? VersionedCache.Put.NOT_STORED
                    : cache.fillWithLease(key, row.payload(), row.version(), ttl, token);
        };
        return new ReadResult(row.payload(), row.version(), "DB", fill);
    }

    public ReadResult read(Connection c, String key) throws SQLException {
        return read(c, key, () -> {});
    }

    /** 先提交数据库，再失效缓存。betweenDeletes 只在 DOUBLE_DELETE 下执行，代表两次删除之间的等待。 */
    public long write(Connection c, String key, String payload, Runnable betweenDeletes) throws SQLException {
        long v = Store.update(c, key, payload, false);
        switch (strategy) {
            case VERSION_TOMBSTONE -> cache.invalidate(key, v, tombTtl);
            case DOUBLE_DELETE -> {
                cache.delete(key);
                betweenDeletes.run();
                cache.delete(key);
            }
            default -> cache.delete(key);
        }
        return v;
    }

    public long write(Connection c, String key, String payload) throws SQLException {
        return write(c, key, payload, () -> {});
    }
}
