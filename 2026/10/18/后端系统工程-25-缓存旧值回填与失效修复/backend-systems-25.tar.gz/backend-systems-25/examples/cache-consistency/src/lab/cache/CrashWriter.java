package lab.cache;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;

import lab.common.Db;

/**
 * 独立 JVM 中的写者。用法：CrashWriter <outbox|plain> <key> <payload> <cachePort> <tombTtl>
 * 提交数据库后打印 COMMITTED，然后等待父进程从标准输入发来 "go" 才去失效缓存。
 * 父进程在这段空档里 kill -9，即可得到“已提交、未失效”的崩溃点。
 */
public final class CrashWriter {
    public static void main(String[] args) throws Exception {
        boolean outbox = args[0].equals("outbox");
        String key = args[1];
        long v;
        try (Connection c = Db.connect()) {
            v = Store.update(c, key, args[2], outbox);
        }
        System.out.println("COMMITTED " + v);
        System.out.flush();
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String line = in.readLine();
        if ("go".equals(line)) {
            String reply = new CacheClient(Integer.parseInt(args[3])).invalidate(key, v, Long.parseLong(args[4]));
            System.out.println("INVALIDATED " + reply);
        }
    }
}
