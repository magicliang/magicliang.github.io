package lab.cache;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.LongSupplier;

/**
 * 单节点缓存替身。所有操作在同一把锁内完成，相当于单线程服务端逐条执行命令。
 * 时间来自注入的时钟（测试用手动时钟），TTL 到点即过期：now >= expiresAt 时视为不存在。
 *
 * 条目分两种：值条目（value + version）和墓碑（只有 version，表示“版本低于它的回填一律拒绝”）。
 * 另有一张租约表：未命中时发放令牌，delete 会作废该键的令牌。
 */
public final class VersionedCache {
    public record Entry(String value, long version, boolean tombstone, long expiresAt, long cas) {}

    public enum Put { STORED, NOT_STORED, REJECTED, EXISTS, NOT_FOUND, IGNORED }

    /** getOrLease 的结果：命中时 value 非空；未命中且拿到租约时 token > 0；未命中但租约已被别人持有时 token = 0。 */
    public record LeaseGet(Entry hit, long token) {}

    private record Lease(long token, long expiresAt) {}

    private final LongSupplier clock;
    private final Map<String, Entry> items = new HashMap<>();
    private final Map<String, Lease> leases = new HashMap<>();
    private long casCounter;
    private long leaseCounter;

    public VersionedCache(LongSupplier clock) {
        this.clock = clock;
    }

    private Entry live(String key) {
        Entry e = items.get(key);
        if (e != null && clock.getAsLong() >= e.expiresAt()) {
            items.remove(key);
            return null;
        }
        return e;
    }

    private Entry value(String value, long version, long ttl) {
        return new Entry(value, version, false, clock.getAsLong() + ttl, ++casCounter);
    }

    /** 返回值条目或墓碑；过期或不存在返回 null。调用方把墓碑当作未命中。 */
    public synchronized Entry get(String key) {
        return live(key);
    }

    /** memcached delete：删除条目，同时作废该键的租约。 */
    public synchronized boolean delete(String key) {
        leases.remove(key);
        return items.remove(key) != null;
    }

    /** memcached add：仅当键不存在时写入。墓碑也算“存在”。 */
    public synchronized Put add(String key, String v, long version, long ttl) {
        if (live(key) != null) return Put.NOT_STORED;
        items.put(key, value(v, version, ttl));
        return Put.STORED;
    }

    /** memcached gets 返回的 cas 唯一值；不存在返回 0。 */
    public synchronized long gets(String key) {
        Entry e = live(key);
        return e == null ? 0 : e.cas();
    }

    /** memcached cas：键不存在 NOT_FOUND；cas 唯一值不相等 EXISTS；相等则写入。比较是“相等”，不是“更大”。 */
    public synchronized Put cas(String key, String v, long version, long ttl, long casUnique) {
        Entry e = live(key);
        if (e == null) return Put.NOT_FOUND;
        if (e.cas() != casUnique) return Put.EXISTS;
        items.put(key, value(v, version, ttl));
        return Put.STORED;
    }

    /**
     * 仅当版本更大时写入（对应 Redis 中用 Lua 脚本原子比较后 SET）。
     * 值条目要求 version > 现有版本；墓碑要求 version >= 墓碑版本；键不存在时直接写入。
     */
    public synchronized Put putIfNewer(String key, String v, long version, long ttl) {
        Entry e = live(key);
        if (e != null) {
            boolean newer = e.tombstone() ? version >= e.version() : version > e.version();
            if (!newer) return Put.REJECTED;
        }
        items.put(key, value(v, version, ttl));
        return Put.STORED;
    }

    /**
     * 带版本的失效：写入版本为 version 的墓碑。现有值条目或墓碑的版本已不低于 version 时忽略，
     * 因此重复投递、乱序投递都不会把更新的值删掉或把墓碑版本调低。
     */
    public synchronized Put invalidate(String key, long version, long tombTtl) {
        leases.remove(key);
        Entry e = live(key);
        if (e != null && e.version() >= version) return Put.IGNORED;
        items.put(key, new Entry(null, version, true, clock.getAsLong() + tombTtl, ++casCounter));
        return Put.STORED;
    }

    /** 租约读：命中返回值；未命中且无有效租约时发放新令牌；已有有效租约返回 token=0（热点未命中，不回填）。 */
    public synchronized LeaseGet getOrLease(String key, long leaseTtl) {
        Entry e = live(key);
        if (e != null && !e.tombstone()) return new LeaseGet(e, 0);
        Lease l = leases.get(key);
        long now = clock.getAsLong();
        if (l != null && now < l.expiresAt()) return new LeaseGet(null, 0);
        long token = ++leaseCounter;
        leases.put(key, new Lease(token, now + leaseTtl));
        return new LeaseGet(null, token);
    }

    /** 持令牌回填：令牌仍是该键当前有效租约时写入并消耗令牌，否则拒绝。 */
    public synchronized Put fillWithLease(String key, String v, long version, long ttl, long token) {
        Lease l = leases.get(key);
        if (l == null || l.token() != token || clock.getAsLong() >= l.expiresAt()) return Put.REJECTED;
        leases.remove(key);
        items.put(key, value(v, version, ttl));
        return Put.STORED;
    }

    /** 巡检用：按键排序的快照（只含未过期条目）。 */
    public synchronized Map<String, Entry> snapshot() {
        Map<String, Entry> out = new TreeMap<>();
        for (String k : new java.util.ArrayList<>(items.keySet())) {
            Entry e = live(k);
            if (e != null) out.put(k, e);
        }
        return out;
    }
}
