package lab.cache;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import lab.common.Db;

/**
 * 失效补删任务：领取未完成的 outbox 行（FOR UPDATE SKIP LOCKED），逐条发送带版本的失效，
 * 全部发送成功后在同一事务内标记 done_at 并提交。发送之后、提交之前崩溃，行保持未完成，
 * 下次会重发；带版本的失效对重复投递幂等，所以重发不会删掉更新的值。
 */
public final class OutboxRelay {
    public enum Fault { NONE, CRASH_AFTER_SEND }

    public record Outcome(int claimed, int marked, String error) {}

    private OutboxRelay() {}

    private record Job(long seq, String item, long version) {}

    public static Outcome runOnce(Connection c, CacheClient client, int batch, long tombTtl, Fault fault)
            throws SQLException {
        c.setAutoCommit(false);
        try {
            List<Job> jobs = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement("""
                    SELECT seq, item_id, version FROM cache_invalidation
                    WHERE done_at IS NULL ORDER BY seq LIMIT ? FOR UPDATE SKIP LOCKED""")) {
                ps.setInt(1, batch);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) jobs.add(new Job(rs.getLong(1), rs.getString(2), rs.getLong(3)));
                }
            }
            int marked = 0;
            for (Job j : jobs) {
                try {
                    client.invalidate(j.item(), j.version(), tombTtl);
                } catch (IOException e) {
                    c.rollback();
                    return new Outcome(jobs.size(), 0, "cache unreachable: " + e.getClass().getSimpleName());
                }
                if (fault == Fault.CRASH_AFTER_SEND) {
                    c.rollback();
                    return new Outcome(jobs.size(), 0, "crashed after send, before mark");
                }
                marked += Db.update(c, "UPDATE cache_invalidation SET done_at = now() WHERE seq = ? AND done_at IS NULL",
                        j.seq());
            }
            c.commit();
            return new Outcome(jobs.size(), marked, null);
        } catch (SQLException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
    }

    public static long pending(Connection c) throws SQLException {
        return Db.queryLong(c, "SELECT count(*) FROM cache_invalidation WHERE done_at IS NULL");
    }
}
