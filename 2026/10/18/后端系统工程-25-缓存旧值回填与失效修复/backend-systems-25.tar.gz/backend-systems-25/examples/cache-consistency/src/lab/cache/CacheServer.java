package lab.cache;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 * 把 VersionedCache 暴露成一行一条命令的 TCP 文本协议，供独立 JVM 的写者和 outbox 任务调用。
 *   GET key            -> VALUE ver payload | TOMB ver | MISS
 *   INV key ver ttl    -> STORED | IGNORED
 *   DEL key            -> DELETED | NOT_FOUND
 */
public final class CacheServer implements AutoCloseable {
    private final VersionedCache cache;
    private final ServerSocket server;
    private final Thread acceptor;

    public CacheServer(VersionedCache cache) throws IOException {
        this.cache = cache;
        this.server = new ServerSocket(0, 50, InetAddress.getLoopbackAddress());
        this.acceptor = new Thread(this::acceptLoop, "cache-acceptor");
        acceptor.setDaemon(true);
        acceptor.start();
    }

    public int port() {
        return server.getLocalPort();
    }

    private void acceptLoop() {
        while (!server.isClosed()) {
            try {
                Socket s = server.accept();
                Thread t = new Thread(() -> serve(s), "cache-conn");
                t.setDaemon(true);
                t.start();
            } catch (IOException e) {
                return;
            }
        }
    }

    private void serve(Socket s) {
        try (s; BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
             PrintWriter out = new PrintWriter(s.getOutputStream(), true, StandardCharsets.UTF_8)) {
            String line;
            while ((line = in.readLine()) != null) {
                String[] p = line.split(" ");
                String reply = switch (p[0]) {
                    case "GET" -> {
                        VersionedCache.Entry e = cache.get(p[1]);
                        yield e == null ? "MISS" : e.tombstone() ? "TOMB " + e.version() : "VALUE " + e.version() + " " + e.value();
                    }
                    case "INV" -> cache.invalidate(p[1], Long.parseLong(p[2]), Long.parseLong(p[3])).name();
                    case "DEL" -> cache.delete(p[1]) ? "DELETED" : "NOT_FOUND";
                    default -> "ERROR unknown command";
                };
                out.println(reply);
            }
        } catch (IOException | RuntimeException e) {
            // 连接级错误只影响这一个客户端
        }
    }

    @Override
    public void close() throws IOException {
        server.close();
    }
}
