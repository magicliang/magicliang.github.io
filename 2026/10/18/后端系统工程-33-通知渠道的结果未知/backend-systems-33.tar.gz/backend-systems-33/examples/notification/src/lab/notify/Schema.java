package lab.notify;

import java.sql.Connection;
import java.sql.SQLException;

import lab.common.Db;

/** 通知实验的表结构。所有约束都在数据库里声明，代码只依赖这些约束的结果。 */
public final class Schema {
    private Schema() {}

    public static final String DDL = """
        CREATE TABLE channel_pref (
            user_id  text    NOT NULL,
            channel  text    NOT NULL CHECK (channel IN ('push', 'sms')),
            address  text    NOT NULL,
            enabled  boolean NOT NULL,
            version  bigint  NOT NULL DEFAULT 1,
            PRIMARY KEY (user_id, channel)
        );

        CREATE TABLE notification (
            id         bigserial   PRIMARY KEY,
            user_id    text        NOT NULL,
            event_key  text        NOT NULL,
            body       text        NOT NULL,
            expires_at timestamptz NOT NULL,
            created_at timestamptz NOT NULL DEFAULT now(),
            UNIQUE (user_id, event_key)
        );

        CREATE TABLE delivery_task (
            id                bigserial   PRIMARY KEY,
            notification_id   bigint      NOT NULL REFERENCES notification(id),
            channel           text        NOT NULL,
            state             text        NOT NULL CHECK (state IN
                                ('PENDING','SENDING','SENT','UNKNOWN','FAILED','SUPPRESSED')),
            attempt_count     int         NOT NULL DEFAULT 0,
            max_attempts      int         NOT NULL,
            next_attempt_at   timestamptz,
            lease_owner       text,
            lease_until       timestamptz,
            attempt_token     uuid,
            outcome_uncertain boolean     NOT NULL DEFAULT false,
            provider_msg_id   text,
            last_error        text,
            needs_review      boolean     NOT NULL DEFAULT false,
            updated_at        timestamptz NOT NULL DEFAULT now(),
            UNIQUE (notification_id, channel),
            CHECK (state <> 'SENDING' OR (lease_until IS NOT NULL AND attempt_token IS NOT NULL))
        );

        CREATE TABLE delivery_attempt (
            id            bigserial   PRIMARY KEY,
            task_id       bigint      NOT NULL REFERENCES delivery_task(id),
            attempt_no    int         NOT NULL,
            attempt_token uuid        NOT NULL UNIQUE,
            worker        text        NOT NULL,
            action        text        NOT NULL,
            started_at    timestamptz NOT NULL DEFAULT clock_timestamp(),
            finished_at   timestamptz,
            outcome       text,
            http_status   int,
            detail        text,
            late_outcome  text,
            UNIQUE (task_id, attempt_no)
        );
        """;

    public static void create(Connection c) throws SQLException {
        Db.exec(c, DDL);
    }
}
