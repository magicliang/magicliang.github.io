package lab.notify;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

import lab.common.Check;
import lab.common.Db;

public final class Main {
    static ChannelStub push, sms;
    static Map<String, Dispatcher.Channel> chans;

    public static void main(String[] args) throws Exception {
        String dbName = System.getenv().getOrDefault("LAB_DB", "notify33");
        Db.recreate(dbName);
        try (Connection c = Db.connect(dbName)) { Schema.create(c); }
        push = new ChannelStub("push", ChannelStub.Mode.IDEMPOTENT);
        sms = new ChannelStub("sms", ChannelStub.Mode.QUERYABLE);
        chans = Map.of("push", new Dispatcher.Channel("push", push.baseUrl(), true),
                       "sms", new Dispatcher.Channel("sms", sms.baseUrl(), false));
        try (Connection c = Db.connect(dbName)) {
            n1ConcurrentCreate(c);
            n2NormalDelivery(c);
            c1SkipLockedClaim(c);
            nc1NaiveClaim(c);
            t1IdempotentTimeout(c);
            t2QueryAfterTimeout(c);
            nc2NaiveResend(c);
            t3UnknownBudget(c);
            f1ServerErrors(c);
            b1SuppressAndExpire(c);
            b2ExpireAfterUnknown(c);
            b3RejectAfterUnknown(c);
            p1KillWorker(c);
            p2StaleToken(c);
        } finally {
            push.close();
            sms.close();
        }
        System.exit(Check.finish());
    }

    static Dispatcher safe(String w, long timeoutMs) {
        return new Dispatcher(chans, w, 3000, timeoutMs, 0, Dispatcher.Policy.SAFE);
    }

    static void reset(Connection c) throws Exception {
        Db.exec(c, "TRUNCATE delivery_attempt, delivery_task, notification, channel_pref");
    }

    static long onlyTask(Connection c, String user) throws Exception {
        return Db.queryLong(c, """
            SELECT t.id FROM delivery_task t JOIN notification n ON n.id = t.notification_id
             WHERE n.user_id = ?""", user);
    }

    static String state(Connection c, long task) throws Exception {
        return Db.queryString(c, "SELECT state FROM delivery_task WHERE id = ?", task);
    }

    static List<String> attempts(Connection c, long task) throws Exception {
        List<String> out = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT outcome FROM delivery_attempt WHERE task_id = ? ORDER BY attempt_no")) {
            ps.setLong(1, task);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) out.add(rs.getString(1)); }
        }
        return out;
    }

    static void n1ConcurrentCreate(Connection c) throws Exception {
        Check.begin("N1", "8 个线程并发创建同一 (user, event_key) 的通知");
        reset(c);
        Notifier.setPref(c, "user-0042", "push", "device-0042-a", true);
        Notifier.setPref(c, "user-0042", "sms", "sms-0042@sms.example.test", true);
        Notifier.setPref(c, "user-0043", "push", "device-0043-a", true);
        Notifier.setPref(c, "user-0043", "sms", "sms-0043@sms.example.test", false);
        int threads = 8;
        CyclicBarrier gate = new CyclicBarrier(threads);
        ExecutorService ex = Executors.newFixedThreadPool(threads);
        List<Future<Notifier.Created>> fs = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            fs.add(ex.submit(() -> {
                try (Connection own = Db.connect()) {
                    gate.await();
                    return Notifier.create(own, "user-0042", "order-shipped:ord-1001", "订单 ord-1001 已发货", 600, 3);
                }
            }));
        }
        int created = 0;
        long firstId = -1;
        boolean sameId = true;
        for (Future<Notifier.Created> f : fs) {
            Notifier.Created r = f.get();
            if (r.created()) created++;
            if (firstId < 0) firstId = r.notificationId(); else sameId &= firstId == r.notificationId();
        }
        ex.shutdown();
        Check.equal(1, created, "只有一个调用报告 created=true");
        Check.that(sameId, "8 个调用返回同一个 notification id");
        Check.equal(1L, Db.queryLong(c, "SELECT count(*) FROM notification"), "notification 行数");
        Check.equal(2L, Db.queryLong(c, "SELECT count(*) FROM delivery_task"), "user-0042 的两个启用渠道各一条任务");
        Notifier.Created other = Notifier.create(c, "user-0043", "order-shipped:ord-1002", "订单 ord-1002 已发货", 600, 3);
        Check.equal(1, other.tasks(), "user-0043 关闭了 sms，只生成 push 任务");
    }

    static void n2NormalDelivery(Connection c) throws Exception {
        Check.begin("N2", "正常路径：两个渠道各投递一次");
        safe("w-n2", 2000).drain(c, 5000);
        long tPush = Db.queryLong(c, """
            SELECT t.id FROM delivery_task t JOIN notification n ON n.id = t.notification_id
             WHERE n.user_id = 'user-0042' AND t.channel = 'push'""");
        long tSms = Db.queryLong(c, """
            SELECT t.id FROM delivery_task t JOIN notification n ON n.id = t.notification_id
             WHERE n.user_id = 'user-0042' AND t.channel = 'sms'""");
        Check.equal(3L, Db.queryLong(c, "SELECT count(*) FROM delivery_task WHERE state = 'SENT'"), "三条任务都到 SENT");
        Check.equal(1, push.acceptedFor(Dispatcher.ref(tPush)), "push 替身外发 1 次");
        Check.equal(1, sms.acceptedFor(Dispatcher.ref(tSms)), "sms 替身外发 1 次");
        Check.equal(List.of("ACCEPTED"), attempts(c, tSms), "sms 任务的投递记录");
    }

    static void c1SkipLockedClaim(Connection c) throws Exception {
        Check.begin("C1", "FOR UPDATE SKIP LOCKED：并发领取不重复");
        reset(c);
        Notifier.setPref(c, "user-0044", "push", "device-0044-a", true);
        Notifier.create(c, "user-0044", "digest:2026-10-18", "每日摘要", 600, 3);
        int threads = 8;
        CyclicBarrier gate = new CyclicBarrier(threads);
        ExecutorService ex = Executors.newFixedThreadPool(threads);
        List<Future<Boolean>> fs = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            final int k = i;
            fs.add(ex.submit(() -> {
                try (Connection own = Db.connect()) {
                    gate.await();
                    return safe("w-c1-" + k, 2000).claim(own).isPresent();
                }
            }));
        }
        int got = 0;
        for (Future<Boolean> f : fs) if (f.get()) got++;
        Check.equal(1, got, "1 条任务被 8 个线程同时领取，成功领取数");

        reset(c);
        int before = push.acceptedTotal();
        for (int i = 0; i < 20; i++) {
            String u = String.format("user-%04d", 100 + i);
            Notifier.setPref(c, u, "push", "device-" + u, true);
            Notifier.create(c, u, "digest:2026-10-18", "每日摘要", 600, 3);
        }
        List<Future<Integer>> ws = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            final int k = i;
            ws.add(ex.submit(() -> {
                try (Connection own = Db.connect()) {
                    Dispatcher d = safe("w-c1-drain-" + k, 2000);
                    int n = 0;
                    while (d.runOnce(own) != Dispatcher.Result.NOTHING) n++;
                    return n;
                }
            }));
        }
        int total = 0;
        StringBuilder per = new StringBuilder();
        for (Future<Integer> f : ws) { int n = f.get(); total += n; per.append(n).append(' '); }
        ex.shutdown();
        Check.note("4 个工作线程各自执行的尝试数: " + per.toString().trim());
        Check.equal(20, total, "4 个线程合计执行尝试数");
        Check.equal(20, push.acceptedTotal() - before, "替身新增外发数");
        Check.equal(20L, Db.queryLong(c, "SELECT count(*) FROM delivery_attempt"), "投递记录行数");
        Check.equal(0L, Db.queryLong(c, "SELECT count(*) FROM delivery_task WHERE attempt_count <> 1"), "attempt_count 不等于 1 的任务数");
    }

    static void nc1NaiveClaim(Connection c) throws Exception {
        Check.begin("NC1", "负向对照：普通 SELECT 后 UPDATE 领取（无行锁、无状态条件）");
        reset(c);
        Notifier.setPref(c, "user-0045", "sms", "sms-0045@sms.example.test", true);
        Notifier.create(c, "user-0045", "login-alert:0001", "新设备登录提醒", 600, 3);
        long task = onlyTask(c, "user-0045");
        CyclicBarrier afterRead = new CyclicBarrier(2);
        ExecutorService ex = Executors.newFixedThreadPool(2);
        AtomicInteger claimed = new AtomicInteger();
        List<Future<?>> fs = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            final int k = i;
            fs.add(ex.submit(() -> {
                try (Connection own = Db.connect()) {
                    long id = Db.queryLong(own, "SELECT id FROM delivery_task WHERE state = 'PENDING' ORDER BY id LIMIT 1");
                    afterRead.await();
                    claimed.addAndGet(Db.update(own, "UPDATE delivery_task SET state = 'SENDING', attempt_token = ?, lease_until = now() WHERE id = ?",
                            UUID.randomUUID(), id));
                    Dispatcher d = safe("w-naive-" + k, 2000);
                    d.call(new Dispatcher.Claim(id, "sms", "sms-0045@sms.example.test", "新设备登录提醒", 1, null, "SEND", Dispatcher.ref(id)));
                }
                return null;
            }));
        }
        for (Future<?> f : fs) f.get();
        ex.shutdown();
        Check.note("两个线程的 UPDATE 影响行数合计 " + claimed.get());
        Check.exposes(sms.acceptedFor(Dispatcher.ref(task)) == 2, "同一任务被两个线程领取并外发，替身外发数="
                + sms.acceptedFor(Dispatcher.ref(task)));
    }

    static void t1IdempotentTimeout(Connection c) throws Exception {
        Check.begin("T1", "支持幂等键的渠道：接受后响应超时，重试复用同一幂等键");
        reset(c);
        Notifier.setPref(c, "user-0046", "push", "device-0046-a", true);
        Notifier.create(c, "user-0046", "comment:cm-77", "收到一条新评论", 600, 3);
        long task = onlyTask(c, "user-0046");
        push.delayMs(1200);
        push.scriptSend(Dispatcher.ref(task), ChannelStub.Fault.DELAY_AFTER_ACCEPT);
        int req0 = push.sendRequests();
        safe("w-t1", 400).drain(c, 5000);
        Check.equal(List.of("TIMEOUT", "ACCEPTED_REPLAY"), attempts(c, task), "投递记录");
        Check.equal("SENT", state(c, task), "任务状态");
        Check.equal(2, push.sendRequests() - req0, "替身收到的 /send 请求数");
        Check.equal(1, push.acceptedFor(Dispatcher.ref(task)), "替身记录的外发次数");
    }

    static void t2QueryAfterTimeout(Connection c) throws Exception {
        Check.begin("T2", "不支持幂等键的渠道：超时后先查询，查到即收敛为 SENT");
        reset(c);
        Notifier.setPref(c, "user-0047", "sms", "sms-0047@sms.example.test", true);
        Notifier.create(c, "user-0047", "otp-expiry:0003", "验证码即将过期", 600, 3);
        long task = onlyTask(c, "user-0047");
        sms.delayMs(1200);
        sms.scriptSend(Dispatcher.ref(task), ChannelStub.Fault.DELAY_AFTER_ACCEPT);
        safe("w-t2", 400).drain(c, 5000);
        Check.equal(List.of("TIMEOUT", "QUERY_FOUND"), attempts(c, task), "投递记录");
        Check.equal("SENT", state(c, task), "任务状态");
        Check.that(Db.queryString(c, "SELECT provider_msg_id FROM delivery_task WHERE id = ?", task) != null, "查询结果写回 provider_msg_id");
        Check.equal(1, sms.acceptedFor(Dispatcher.ref(task)), "替身记录的外发次数");
    }

    static void nc2NaiveResend(Connection c) throws Exception {
        Check.begin("NC2", "负向对照：不支持幂等键的渠道超时后直接重发");
        reset(c);
        Notifier.setPref(c, "user-0048", "sms", "sms-0048@sms.example.test", true);
        Notifier.create(c, "user-0048", "otp-expiry:0004", "验证码即将过期", 600, 3);
        long task = onlyTask(c, "user-0048");
        sms.scriptSend(Dispatcher.ref(task), ChannelStub.Fault.DELAY_AFTER_ACCEPT);
        new Dispatcher(chans, "w-nc2", 3000, 400, 0, Dispatcher.Policy.NAIVE_RESEND).drain(c, 5000);
        Check.equal(List.of("TIMEOUT", "ACCEPTED"), attempts(c, task), "投递记录");
        Check.equal(1L, Db.queryLong(c, "SELECT count(*) FROM notification WHERE user_id = 'user-0048'"), "逻辑通知仍只有 1 条");
        Check.equal("SENT", state(c, task), "任务状态");
        Check.exposes(sms.acceptedFor(Dispatcher.ref(task)) == 2,
                "逻辑去重成立但替身外发次数=" + sms.acceptedFor(Dispatcher.ref(task)));
    }

    static void t3UnknownBudget(Connection c) throws Exception {
        Check.begin("T3", "结果未知且查询不可用：预算用尽后停在 UNKNOWN，等待人工处理");
        reset(c);
        Notifier.setPref(c, "user-0049", "sms", "sms-0049@sms.example.test", true);
        Notifier.create(c, "user-0049", "otp-expiry:0005", "验证码即将过期", 600, 3);
        long task = onlyTask(c, "user-0049");
        String ref = Dispatcher.ref(task);
        sms.scriptSend(ref, ChannelStub.Fault.DELAY_AFTER_ACCEPT);
        sms.scriptQuery(ref, ChannelStub.Fault.QUERY_503, ChannelStub.Fault.QUERY_503);
        Dispatcher d = safe("w-t3", 400);
        d.drain(c, 5000);
        Check.equal(List.of("TIMEOUT", "QUERY_FAILED", "QUERY_FAILED"), attempts(c, task), "投递记录");
        Check.equal("UNKNOWN", state(c, task), "任务状态");
        Check.equal("t", Db.queryString(c, "SELECT needs_review::text FROM delivery_task WHERE id = ?", task).substring(0, 1), "needs_review");
        Check.equal(0L, Db.queryLong(c, "SELECT count(*) FROM delivery_task WHERE id = ? AND next_attempt_at IS NOT NULL", task), "不再自动调度");
        Check.equal(Dispatcher.Result.NOTHING, d.runOnce(c), "工作进程不再领取该任务");
        Check.equal(1, sms.acceptedFor(ref), "替身外发次数（没有盲目重发）");
        Check.equal(1, Dispatcher.resolveManually(c, task, "SENT", "operator query found " + ref), "人工核对后标记 SENT");
        Check.equal(0, Dispatcher.resolveManually(c, task, "FAILED", "second operator"), "重复人工处理被拒绝");
        Check.equal(List.of("TIMEOUT", "QUERY_FAILED", "QUERY_FAILED", "MANUAL_SENT"), attempts(c, task), "投递记录");
    }

    static void f1ServerErrors(Connection c) throws Exception {
        Check.begin("F1", "接受前的 503 重试；400 终止为 FAILED");
        reset(c);
        Notifier.setPref(c, "user-0051", "push", "device-0051-a", true);
        Notifier.setPref(c, "user-0052", "sms", "sms-0052@sms.example.test", true);
        Notifier.create(c, "user-0051", "follow:u-9", "有新关注者", 600, 3);
        Notifier.create(c, "user-0052", "follow:u-9", "有新关注者", 600, 3);
        long tp = onlyTask(c, "user-0051");
        long ts = onlyTask(c, "user-0052");
        push.scriptSend(Dispatcher.ref(tp), ChannelStub.Fault.REJECT_503);
        sms.scriptSend(Dispatcher.ref(ts), ChannelStub.Fault.REJECT_400);
        safe("w-f1", 400).drain(c, 5000);
        Check.equal(List.of("HTTP_5XX", "ACCEPTED"), attempts(c, tp), "push 投递记录");
        Check.equal("SENT", state(c, tp), "push 状态");
        Check.equal(1, push.acceptedFor(Dispatcher.ref(tp)), "push 外发次数");
        Check.equal(List.of("REJECTED"), attempts(c, ts), "sms 投递记录");
        Check.equal("FAILED", state(c, ts), "sms 状态");
        Check.equal(0, sms.acceptedFor(Dispatcher.ref(ts)), "sms 外发次数");
    }

    static void b1SuppressAndExpire(Connection c) throws Exception {
        Check.begin("B1", "发送前关闭偏好 -> SUPPRESSED；超过 TTL -> FAILED，均不发请求");
        reset(c);
        Notifier.setPref(c, "user-0053", "push", "device-0053-a", true);
        Notifier.setPref(c, "user-0054", "push", "device-0054-a", true);
        Notifier.create(c, "user-0053", "promo:wk42", "本周活动", 600, 3);
        Notifier.create(c, "user-0054", "call:c-1", "来电提醒", 1, 3);
        Notifier.setPref(c, "user-0053", "push", "device-0053-a", false);
        Thread.sleep(1200);
        int req0 = push.sendRequests();
        safe("w-b1", 400).drain(c, 3000);
        long t53 = onlyTask(c, "user-0053"), t54 = onlyTask(c, "user-0054");
        Check.equal("SUPPRESSED", state(c, t53), "偏好关闭后的任务状态");
        Check.equal(List.of("PREF_DISABLED"), attempts(c, t53), "user-0053 投递记录");
        Check.equal("FAILED", state(c, t54), "过期通知的任务状态");
        Check.equal(List.of("TTL_EXPIRED"), attempts(c, t54), "user-0054 投递记录");
        Check.equal(0, push.sendRequests() - req0, "替身收到的请求数");
    }

    static void b2ExpireAfterUnknown(Connection c) throws Exception {
        Check.begin("B2", "结果未知之后 TTL 到期：不写成 FAILED，停在 UNKNOWN 交人工核对");
        reset(c);
        Notifier.setPref(c, "user-0055", "sms", "sms-0055@sms.example.test", true);
        Notifier.create(c, "user-0055", "otp-expiry:0006", "验证码即将过期", 2, 3);
        long task = onlyTask(c, "user-0055");
        String ref = Dispatcher.ref(task);
        sms.delayMs(1200);
        sms.scriptSend(ref, ChannelStub.Fault.DELAY_AFTER_ACCEPT);
        int q0 = sms.queryRequests();
        new Dispatcher(chans, "w-b2", 3000, 400, 2500, Dispatcher.Policy.SAFE).drain(c, 8000);
        Check.equal(List.of("TIMEOUT", "TTL_EXPIRED_UNCERTAIN"), attempts(c, task), "投递记录");
        Check.equal("UNKNOWN", state(c, task), "任务状态");
        Check.equal("t", Db.queryString(c, "SELECT needs_review::text FROM delivery_task WHERE id = ?", task).substring(0, 1), "needs_review");
        Check.equal(0, sms.queryRequests() - q0, "过期后不再查询或发送");
        Check.equal(1, sms.acceptedFor(ref), "替身外发次数（第 1 次尝试已被接受）");
        Check.equal(1, Dispatcher.resolveManually(c, task, "SENT", "operator query found " + ref), "人工核对后标记 SENT");
    }

    static void b3RejectAfterUnknown(Connection c) throws Exception {
        Check.begin("B3", "结果未知之后的 503：拒绝只说明这一次未被接受，预算用尽时停在 UNKNOWN，不写成 FAILED");
        reset(c);
        Notifier.setPref(c, "user-0056", "push", "device-0056-a", true);
        Notifier.create(c, "user-0056", "order-shipped:ord-2056", "订单 ord-2056 已发货", 600, 2);
        long task = onlyTask(c, "user-0056");
        String ref = Dispatcher.ref(task);
        push.delayMs(1200);
        push.scriptSend(ref, ChannelStub.Fault.DELAY_AFTER_ACCEPT, ChannelStub.Fault.REJECT_503);
        new Dispatcher(chans, "w-b3", 3000, 400, 200, Dispatcher.Policy.SAFE).drain(c, 8000);
        Check.equal(List.of("TIMEOUT", "HTTP_5XX"), attempts(c, task), "投递记录");
        Check.equal("UNKNOWN", state(c, task), "任务状态（第 1 次可能已被接受）");
        Check.equal("t", Db.queryString(c, "SELECT needs_review::text FROM delivery_task WHERE id = ?", task).substring(0, 1), "needs_review");
        Check.equal(1, push.acceptedFor(ref), "替身外发次数（第 1 次尝试已被接受）");
    }

    static void waitLeaseExpired(Connection c, long task) throws Exception {
        while (Db.queryLong(c, "SELECT count(*) FROM delivery_task WHERE id = ? AND lease_until >= now()", task) > 0)
            Thread.sleep(50);
    }

    static void p1KillWorker(Connection c) throws Exception {
        Check.begin("P1", "多进程：工作进程在调用渠道时被 kill -9，租约过期后被重新领取");
        reset(c);
        Notifier.setPref(c, "user-0060", "push", "device-0060-a", true);
        Notifier.create(c, "user-0060", "order-shipped:ord-2001", "订单 ord-2001 已发货", 600, 3);
        long task = onlyTask(c, "user-0060");
        String ref = Dispatcher.ref(task);
        push.scriptSend(ref, ChannelStub.Fault.HANG_AFTER_ACCEPT);
        Proc w1 = Proc.java("lab.notify.WorkerMain", "w-p1-a", "3000", "30000", push.baseUrl(), sms.baseUrl());
        Check.that(w1.await("CLAIMED", 15000) != null, "w-p1-a 领取任务");
        long end = System.currentTimeMillis() + 5000;
        while (push.acceptedFor(ref) == 0 && System.currentTimeMillis() < end) Thread.sleep(20);
        Check.equal(1, push.acceptedFor(ref), "kill 之前替身已接受外发");
        w1.signal("KILL");
        Check.that(w1.waitExit(5000) != 0, "w-p1-a 以非零码退出（SIGKILL）");
        Check.equal("SENDING", state(c, task), "kill 后任务停在 SENDING");
        Optional<Dispatcher.Claim> early = safe("w-probe", 400).claim(c);
        Check.that(early.isEmpty(), "租约未过期时探测领取得到空结果");
        waitLeaseExpired(c, task);
        Proc w2 = Proc.java("lab.notify.WorkerMain", "w-p1-b", "3000", "2000", push.baseUrl(), sms.baseUrl());
        Check.that(w2.await("RESULT", 15000) != null, "w-p1-b 完成一次尝试");
        w2.waitExit(5000);
        Check.that(w2.saw("CALLED outcome=ACCEPTED_REPLAY"), "w-p1-b 用同一幂等键重发，渠道返回原消息号");
        Check.equal("SENT", state(c, task), "任务状态");
        Check.equal(List.of("LEASE_EXPIRED", "ACCEPTED_REPLAY"), attempts(c, task), "投递记录");
        Check.equal("w-p1-a", Db.queryString(c, "SELECT worker FROM delivery_attempt WHERE task_id = ? AND attempt_no = 1", task), "第 1 次尝试的执行者");
        Check.equal(1, push.acceptedFor(ref), "替身外发次数");
    }

    static void p2StaleToken(Connection c) throws Exception {
        Check.begin("P2", "多进程：SIGSTOP 暂停持有者，新持有者完成后旧持有者的迟到结果被令牌拒绝");
        reset(c);
        Notifier.setPref(c, "user-0061", "push", "device-0061-a", true);
        Notifier.create(c, "user-0061", "order-shipped:ord-2002", "订单 ord-2002 已发货", 600, 3);
        long task = onlyTask(c, "user-0061");
        String ref = Dispatcher.ref(task);
        push.delayMs(4000);
        push.scriptSend(ref, ChannelStub.Fault.DELAY_AFTER_ACCEPT);
        Proc w3 = Proc.java("lab.notify.WorkerMain", "w-p2-a", "1000", "1500", push.baseUrl(), sms.baseUrl());
        Check.that(w3.await("CLAIMED", 15000) != null, "w-p2-a 领取任务");
        long end = System.currentTimeMillis() + 5000;
        while (push.acceptedFor(ref) == 0 && System.currentTimeMillis() < end) Thread.sleep(10);
        w3.signal("STOP");
        String oldToken = Db.queryString(c, "SELECT attempt_token::text FROM delivery_task WHERE id = ?", task);
        waitLeaseExpired(c, task);
        Dispatcher.Result r = safe("w-p2-b", 400).runOnce(c);
        Check.equal(Dispatcher.Result.SENT, r, "w-p2-b 在租约过期后领取并完成");
        String newToken = Db.queryString(c, "SELECT attempt_token::text FROM delivery_task WHERE id = ?", task);
        Check.that(!newToken.equals(oldToken), "任务当前令牌已更换");
        w3.signal("CONT");
        String last = w3.await("RESULT", 15000);
        w3.waitExit(5000);
        Check.equal("W w-p2-a RESULT STALE", last, "w-p2-a 的收尾被拒绝");
        String late = Db.queryString(c, "SELECT late_outcome FROM delivery_attempt WHERE task_id = ? AND attempt_no = 1", task);
        Check.note("w-p2-a 迟到观察 late_outcome=" + late);
        Check.equal("SENT", state(c, task), "任务状态未被迟到结果改写");
        Check.equal(List.of("LEASE_EXPIRED", "ACCEPTED_REPLAY"), attempts(c, task), "投递记录");
        Check.equal(1, push.acceptedFor(ref), "替身外发次数");

        Check.begin("NC3", "负向对照：只按任务 id 收尾（不检查令牌与状态），套用同一迟到观察");
        String naiveState = "TIMEOUT".equals(late) ? "UNKNOWN" : "SENT";
        int n = Db.update(c, "UPDATE delivery_task SET state = ?, outcome_uncertain = ? WHERE id = ?",
                naiveState, naiveState.equals("UNKNOWN"), task);
        Check.note("按 id 收尾影响行数 " + n + "，写入状态 " + naiveState);
        Check.exposes("UNKNOWN".equals(state(c, task)), "已 SENT 的任务被迟到的超时观察改回 UNKNOWN");
    }
}
