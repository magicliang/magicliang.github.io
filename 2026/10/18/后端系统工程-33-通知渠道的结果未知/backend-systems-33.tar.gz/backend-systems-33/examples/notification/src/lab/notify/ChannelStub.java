package lab.notify;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 本地假渠道。契约（仅对本替身成立）：
 * <ul>
 *   <li>POST /send：先记录“已接受外发”，再按脚本决定是否延迟响应；503 与 400 在接受之前返回，不产生外发。</li>
 *   <li>IDEMPOTENT 模式：同一 Idempotency-Key 的重复请求返回原消息号，不新增外发。</li>
 *   <li>QUERYABLE 模式：忽略 Idempotency-Key，每次接受都新增外发；提供 GET /messages?ref= 查询。</li>
 * </ul>
 */
public final class ChannelStub implements AutoCloseable {
    public enum Mode { IDEMPOTENT, QUERYABLE }
    public enum Fault { OK, DELAY_AFTER_ACCEPT, HANG_AFTER_ACCEPT, REJECT_503, REJECT_400, QUERY_503 }

    public record Accepted(String msgId, String ref, String idemKey, String to) {}

    private final Mode mode;
    private final HttpServer server;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final Map<String, Deque<Fault>> sendScript = new ConcurrentHashMap<>();
    private final Map<String, Deque<Fault>> queryScript = new ConcurrentHashMap<>();
    private final List<Accepted> accepted = new ArrayList<>();
    private final Map<String, String> byIdemKey = new HashMap<>();
    private final AtomicInteger sendRequests = new AtomicInteger();
    private final AtomicInteger queryRequests = new AtomicInteger();
    private final AtomicInteger seq = new AtomicInteger();
    private final String prefix;
    private volatile long delayMs = 1200;

    public ChannelStub(String name, Mode mode) throws IOException {
        this.mode = mode;
        this.prefix = name;
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 64);
        server.createContext("/send", this::send);
        server.createContext("/messages", this::query);
        server.setExecutor(pool);
        server.start();
    }

    public String baseUrl() { return "http://127.0.0.1:" + server.getAddress().getPort(); }
    public boolean idempotent() { return mode == Mode.IDEMPOTENT; }
    public void delayMs(long ms) { delayMs = ms; }

    public void scriptSend(String ref, Fault... faults) {
        sendScript.computeIfAbsent(ref, k -> new ArrayDeque<>()).addAll(List.of(faults));
    }

    public void scriptQuery(String ref, Fault... faults) {
        queryScript.computeIfAbsent(ref, k -> new ArrayDeque<>()).addAll(List.of(faults));
    }

    /** 替身视角的外发次数：被接受并会送往用户的消息条数。 */
    public synchronized int acceptedFor(String ref) {
        int n = 0;
        for (Accepted a : accepted) if (a.ref().equals(ref)) n++;
        return n;
    }

    public synchronized int acceptedTotal() { return accepted.size(); }
    public int sendRequests() { return sendRequests.get(); }
    public int queryRequests() { return queryRequests.get(); }

    private static Fault next(Map<String, Deque<Fault>> script, String ref) {
        Deque<Fault> q = script.get(ref);
        if (q == null) return Fault.OK;
        synchronized (q) {
            Fault f = q.poll();
            return f == null ? Fault.OK : f;
        }
    }

    private void send(HttpExchange ex) throws IOException {
        sendRequests.incrementAndGet();
        Map<String, String> form = parse(new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
        String ref = form.getOrDefault("ref", "");
        String key = ex.getRequestHeaders().getFirst("Idempotency-Key");
        Fault fault = next(sendScript, ref);
        if (fault == Fault.REJECT_503) { reply(ex, 503, "error=overloaded"); return; }
        if (fault == Fault.REJECT_400) { reply(ex, 400, "error=invalid_recipient"); return; }
        String msgId;
        boolean replayed = false;
        synchronized (this) {
            if (mode == Mode.IDEMPOTENT && key != null && byIdemKey.containsKey(key)) {
                msgId = byIdemKey.get(key);
                replayed = true;
            } else {
                msgId = prefix + "-msg-" + String.format("%04d", seq.incrementAndGet());
                accepted.add(new Accepted(msgId, ref, key, form.get("to")));
                if (mode == Mode.IDEMPOTENT && key != null) byIdemKey.put(key, msgId);
            }
        }
        try {
            if (fault == Fault.DELAY_AFTER_ACCEPT) Thread.sleep(delayMs);
            if (fault == Fault.HANG_AFTER_ACCEPT) Thread.sleep(60_000);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }
        try {
            reply(ex, replayed ? 200 : 201, "id=" + msgId + "\nreplayed=" + replayed);
        } catch (IOException clientGone) {
            // 客户端已超时断开：外发已经发生，只是响应丢失。
        }
    }

    private void query(HttpExchange ex) throws IOException {
        queryRequests.incrementAndGet();
        if (mode != Mode.QUERYABLE) { reply(ex, 405, "error=no_query"); return; }
        String q = ex.getRequestURI().getRawQuery();
        String ref = parse(q == null ? "" : q).getOrDefault("ref", "");
        if (next(queryScript, ref) == Fault.QUERY_503) { reply(ex, 503, "error=query_unavailable"); return; }
        List<String> ids = new ArrayList<>();
        synchronized (this) {
            for (Accepted a : accepted) if (a.ref().equals(ref)) ids.add(a.msgId());
        }
        if (ids.isEmpty()) reply(ex, 404, "found=0");
        else reply(ex, 200, "found=" + ids.size() + "\nid=" + ids.get(0));
    }

    private static void reply(HttpExchange ex, int status, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders(status, b.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(b); }
    }

    static Map<String, String> parse(String s) {
        Map<String, String> m = new HashMap<>();
        for (String part : s.split("[&\n]")) {
            int i = part.indexOf('=');
            if (i > 0) m.put(URLDecoder.decode(part.substring(0, i), StandardCharsets.UTF_8),
                             URLDecoder.decode(part.substring(i + 1), StandardCharsets.UTF_8));
        }
        return m;
    }

    @Override public void close() {
        server.stop(0);
        pool.shutdownNow();
    }
}
