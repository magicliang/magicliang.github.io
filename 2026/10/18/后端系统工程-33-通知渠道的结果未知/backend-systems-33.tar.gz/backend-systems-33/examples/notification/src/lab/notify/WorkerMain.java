package lab.notify;

import java.sql.Connection;
import java.util.Map;
import java.util.Optional;

import lab.common.Db;

/**
 * 独立 JVM 的投递工作进程，只执行一次“领取—调用—收尾”。
 * 参数: workerId leaseMs clientTimeoutMs pushUrl smsUrl
 * 每个阶段打印一行，父进程据此决定何时发送 SIGKILL / SIGSTOP。
 */
public final class WorkerMain {
    public static void main(String[] a) throws Exception {
        String worker = a[0];
        long lease = Long.parseLong(a[1]);
        long timeout = Long.parseLong(a[2]);
        Map<String, Dispatcher.Channel> chs = Map.of(
            "push", new Dispatcher.Channel("push", a[3], true),
            "sms", new Dispatcher.Channel("sms", a[4], false));
        Dispatcher d = new Dispatcher(chs, worker, lease, timeout, 0, Dispatcher.Policy.SAFE);
        try (Connection c = Db.connect()) {
            Optional<Dispatcher.Claim> cl = d.claim(c);
            if (cl.isEmpty()) { say(worker, "NOTHING"); return; }
            say(worker, "CLAIMED task=" + cl.get().taskId() + " attempt=" + cl.get().attemptNo()
                    + " action=" + cl.get().action());
            Dispatcher.Observation ob = d.call(cl.get());
            say(worker, "CALLED outcome=" + ob.outcome() + " msg=" + ob.msgId());
            Dispatcher.Result r = d.finish(c, cl.get(), ob);
            say(worker, "RESULT " + r);
        }
    }

    private static void say(String w, String s) {
        System.out.println("W " + w + " " + s);
        System.out.flush();
    }
}
