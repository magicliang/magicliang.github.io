package lab.notify;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/** 启动同一 classpath 下的子 JVM，收集其输出，并用 kill(1) 发送信号。 */
public final class Proc {
    private final Process p;
    private final LinkedBlockingQueue<String> lines = new LinkedBlockingQueue<>();
    private final List<String> all = new ArrayList<>();

    private Proc(Process p) {
        this.p = p;
        Thread t = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                String s;
                while ((s = r.readLine()) != null) {
                    synchronized (all) { all.add(s); }
                    lines.add(s);
                    System.out.println("  proc " + s);
                }
            } catch (Exception ignored) { }
        });
        t.setDaemon(true);
        t.start();
    }

    public static Proc java(String main, String... args) throws Exception {
        List<String> cmd = new ArrayList<>(List.of(
            System.getProperty("java.home") + "/bin/java", "-cp", System.getProperty("java.class.path"), main));
        cmd.addAll(List.of(args));
        return new Proc(new ProcessBuilder(cmd).redirectErrorStream(true).start());
    }

    public long pid() { return p.pid(); }

    /** 等待输出中出现包含 needle 的一行。 */
    public String await(String needle, long ms) throws InterruptedException {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) {
            String s = lines.poll(50, TimeUnit.MILLISECONDS);
            if (s != null && s.contains(needle)) return s;
        }
        return null;
    }

    public void signal(String sig) throws Exception {
        new ProcessBuilder("kill", "-" + sig, Long.toString(p.pid())).inheritIO().start().waitFor();
    }

    public int waitExit(long ms) throws Exception {
        if (!p.waitFor(ms, TimeUnit.MILLISECONDS)) { signal("KILL"); p.waitFor(); }
        Thread.sleep(100); // 让读线程取完剩余输出
        return p.exitValue();
    }

    public boolean saw(String needle) {
        synchronized (all) { return all.stream().anyMatch(s -> s.contains(needle)); }
    }
}
