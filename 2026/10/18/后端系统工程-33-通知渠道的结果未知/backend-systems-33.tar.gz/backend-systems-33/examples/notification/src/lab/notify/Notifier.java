package lab.notify;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import lab.common.Db;

/** 逻辑通知的写入入口：(user_id, event_key) 唯一，渠道任务随首次创建一起写入。 */
public final class Notifier {
    private Notifier() {}

    public record Created(long notificationId, boolean created, int tasks) {}

    public static void setPref(Connection c, String user, String channel, String address, boolean enabled)
            throws SQLException {
        Db.update(c, """
            INSERT INTO channel_pref(user_id, channel, address, enabled) VALUES (?, ?, ?, ?)
            ON CONFLICT (user_id, channel) DO UPDATE
               SET address = EXCLUDED.address, enabled = EXCLUDED.enabled,
                   version = channel_pref.version + 1
            """, user, channel, address, enabled);
    }

    /**
     * 同一 (user, event_key) 并发调用时，只有一个事务插入成功；其余事务在唯一索引上等待对方提交，
     * 然后走 DO NOTHING，再读到已提交的那一行。渠道任务只由插入成功的事务写入。
     */
    public static Created create(Connection c, String user, String eventKey, String body,
                                 int ttlSeconds, int maxAttempts) throws SQLException {
        boolean auto = c.getAutoCommit();
        c.setAutoCommit(false);
        try {
            Long id = null;
            try (PreparedStatement ps = c.prepareStatement("""
                    INSERT INTO notification(user_id, event_key, body, expires_at)
                    VALUES (?, ?, ?, now() + make_interval(secs => ?))
                    ON CONFLICT (user_id, event_key) DO NOTHING
                    RETURNING id""")) {
                ps.setString(1, user);
                ps.setString(2, eventKey);
                ps.setString(3, body);
                ps.setInt(4, ttlSeconds);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) id = rs.getLong(1);
                }
            }
            if (id == null) {
                long existing = Db.queryLong(c,
                    "SELECT id FROM notification WHERE user_id = ? AND event_key = ?", user, eventKey);
                c.commit();
                return new Created(existing, false, 0);
            }
            int tasks = Db.update(c, """
                INSERT INTO delivery_task(notification_id, channel, state, max_attempts, next_attempt_at)
                SELECT ?, channel, 'PENDING', ?, now()
                  FROM channel_pref WHERE user_id = ? AND enabled
                """, id, maxAttempts, user);
            c.commit();
            return new Created(id, true, tasks);
        } catch (SQLException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(auto);
        }
    }
}
