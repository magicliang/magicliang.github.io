package lab.notify;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import lab.common.Db;

/**
 * 渠道任务的领取与执行。一次“尝试”= 领取事务 + 一次 HTTP 调用 + 带令牌的收尾事务。
 * 正确性来自两处检查：领取时 FOR UPDATE SKIP LOCKED 加租约条件；收尾时 attempt_token 必须仍是当前令牌。
 */
public final class Dispatcher {
    /** SAFE：不支持幂等键的渠道在结果未知后先查询；NAIVE_RESEND：直接重发（负向对照）。 */
    public enum Policy { SAFE, NAIVE_RESEND }

    public record Channel(String name, String baseUrl, boolean idempotent) {}

    public record Claim(long taskId, String channel, String address, String body, int attemptNo,
                        UUID token, String action, String ref) {}

    public enum Result { NOTHING, SUPPRESSED, EXPIRED, SENT, UNKNOWN, RETRY, FAILED, STALE }

    private final Map<String, Channel> channels;
    private final String worker;
    private final long leaseMs;
    private final Duration clientTimeout;
    private final long retryDelayMs;
    private final Policy policy;
    private final HttpClient http;

    public Dispatcher(Map<String, Channel> channels, String worker, long leaseMs, long clientTimeoutMs,
                      long retryDelayMs, Policy policy) {
        this.channels = channels;
        this.worker = worker;
        this.leaseMs = leaseMs;
        this.clientTimeout = Duration.ofMillis(clientTimeoutMs);
        this.retryDelayMs = retryDelayMs;
        this.policy = policy;
        this.http = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1)
                .connectTimeout(Duration.ofSeconds(2)).build();
    }

    public static String ref(long taskId) { return "task-" + taskId; }

    /** 领取一条可执行任务；偏好关闭或已过期的任务在同一事务里直接终结，不发送。 */
    public Optional<Claim> claim(Connection c) throws SQLException {
        c.setAutoCommit(false);
        try {
            long taskId;
            String state, channel, address, body;
            boolean leaseExpired, enabled, expired, uncertain;
            int attempts;
            try (PreparedStatement ps = c.prepareStatement("""
                    SELECT t.id, t.state, t.channel, t.attempt_count, t.outcome_uncertain,
                           (t.state = 'SENDING') AS lease_expired,
                           coalesce(p.enabled, false), p.address, n.body, n.expires_at <= now()
                      FROM delivery_task t
                      JOIN notification n ON n.id = t.notification_id
                      LEFT JOIN channel_pref p ON p.user_id = n.user_id AND p.channel = t.channel
                     WHERE (t.state IN ('PENDING', 'UNKNOWN') AND t.next_attempt_at <= now())
                        OR (t.state = 'SENDING' AND t.lease_until < now())
                     ORDER BY t.id
                     LIMIT 1
                     FOR UPDATE OF t SKIP LOCKED""");
                 ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) { c.commit(); return Optional.empty(); }
                taskId = rs.getLong(1); state = rs.getString(2); channel = rs.getString(3);
                attempts = rs.getInt(4); uncertain = rs.getBoolean(5); leaseExpired = rs.getBoolean(6);
                enabled = rs.getBoolean(7); address = rs.getString(8); body = rs.getString(9);
                expired = rs.getBoolean(10);
            }
            if (leaseExpired) {
                // 上一个持有者失联：它的那次调用可能已被渠道接受，结果记为未知。
                Db.update(c, """
                    UPDATE delivery_attempt SET outcome = 'LEASE_EXPIRED', finished_at = clock_timestamp()
                     WHERE task_id = ? AND finished_at IS NULL""", taskId);
                uncertain = true;
            }
            if (!enabled || expired) {
                String why = !enabled ? "PREF_DISABLED" : "TTL_EXPIRED";
                // 之前的尝试可能已被渠道接受：此时不能写成“未发送”的终态，只停止自动调度并交人工核对。
                String terminal = uncertain ? "UNKNOWN" : (!enabled ? "SUPPRESSED" : "FAILED");
                if (uncertain) why = why + "_UNCERTAIN";
                Db.update(c, """
                    UPDATE delivery_task SET state = ?, last_error = ?, next_attempt_at = NULL,
                           lease_owner = NULL, lease_until = NULL, outcome_uncertain = ?,
                           needs_review = ?, updated_at = now()
                     WHERE id = ?""", terminal, why, uncertain, uncertain, taskId);
                Db.update(c, """
                    INSERT INTO delivery_attempt(task_id, attempt_no, attempt_token, worker, action,
                                                 finished_at, outcome)
                    VALUES (?, ?, ?, ?, 'NONE', clock_timestamp(), ?)""",
                    taskId, attempts + 1, UUID.randomUUID(), worker, why);
                Db.update(c, "UPDATE delivery_task SET attempt_count = attempt_count + 1 WHERE id = ?", taskId);
                c.commit();
                return Optional.of(new Claim(taskId, channel, address, body, attempts + 1, null, why, ref(taskId)));
            }
            Channel ch = channels.get(channel);
            String action = (uncertain && !ch.idempotent() && policy == Policy.SAFE) ? "QUERY" : "SEND";
            UUID token = UUID.randomUUID();
            Db.update(c, """
                UPDATE delivery_task
                   SET state = 'SENDING', attempt_count = attempt_count + 1, attempt_token = ?,
                       lease_owner = ?, lease_until = now() + make_interval(secs => ?::float8 / 1000),
                       outcome_uncertain = ?, updated_at = now()
                 WHERE id = ?""", token, worker, leaseMs, uncertain, taskId);
            Db.update(c, """
                INSERT INTO delivery_attempt(task_id, attempt_no, attempt_token, worker, action)
                VALUES (?, ?, ?, ?, ?)""", taskId, attempts + 1, token, worker, action);
            c.commit();
            return Optional.of(new Claim(taskId, channel, address, body, attempts + 1, token, action, ref(taskId)));
        } catch (SQLException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
    }

    /** 外部调用的观察结果。 */
    public record Observation(String outcome, Integer status, String msgId, String detail) {}

    public Observation call(Claim cl) throws InterruptedException {
        Channel ch = channels.get(cl.channel());
        try {
            HttpRequest req;
            if (cl.action().equals("QUERY")) {
                req = HttpRequest.newBuilder(URI.create(ch.baseUrl() + "/messages?ref=" + cl.ref()))
                        .timeout(clientTimeout).GET().build();
            } else {
                String form = "ref=" + enc(cl.ref()) + "&to=" + enc(cl.address()) + "&text=" + enc(cl.body());
                HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(ch.baseUrl() + "/send"))
                        .timeout(clientTimeout)
                        .header("Content-Type", "application/x-www-form-urlencoded")
                        .POST(HttpRequest.BodyPublishers.ofString(form));
                // 幂等键与任务绑定，跨尝试不变；是否生效取决于渠道契约。
                if (ch.idempotent()) b.header("Idempotency-Key", "ntf-" + cl.ref());
                req = b.build();
            }
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            Map<String, String> kv = ChannelStub.parse(resp.body());
            int st = resp.statusCode();
            if (cl.action().equals("QUERY")) {
                if (st == 200) return new Observation("QUERY_FOUND", st, kv.get("id"), "found=" + kv.get("found"));
                if (st == 404) return new Observation("QUERY_NOT_FOUND", st, null, null);
                return new Observation("QUERY_FAILED", st, null, resp.body());
            }
            if (st == 200 || st == 201) {
                boolean replay = "true".equals(kv.get("replayed"));
                return new Observation(replay ? "ACCEPTED_REPLAY" : "ACCEPTED", st, kv.get("id"), null);
            }
            if (st >= 500) return new Observation("HTTP_5XX", st, null, resp.body());
            return new Observation("REJECTED", st, null, resp.body());
        } catch (HttpTimeoutException e) {
            return new Observation("TIMEOUT", null, null, "client timeout " + clientTimeout.toMillis() + "ms");
        } catch (IOException e) {
            return new Observation("IO_ERROR", null, null, e.getClass().getSimpleName());
        }
    }

    /** 把观察结果映射成状态，并且只在令牌仍是当前令牌时提交。 */
    public Result finish(Connection c, Claim cl, Observation ob) throws SQLException {
        String state;
        boolean uncertain;
        boolean park = false;
        int max = (int) Db.queryLong(c, "SELECT max_attempts FROM delivery_task WHERE id = ?", cl.taskId());
        boolean budgetLeft = cl.attemptNo() < max;
        // 领取时写入的不确定标记：此前某次尝试可能已被渠道接受。
        boolean priorUncertain = "t".equals(Db.queryString(c,
                "SELECT outcome_uncertain::text FROM delivery_task WHERE id = ?", cl.taskId()).substring(0, 1));
        switch (ob.outcome()) {
            case "ACCEPTED", "ACCEPTED_REPLAY", "QUERY_FOUND" -> { state = "SENT"; uncertain = false; }
            case "QUERY_NOT_FOUND" -> { state = budgetLeft ? "PENDING" : "FAILED"; uncertain = false; }
            case "TIMEOUT", "IO_ERROR", "QUERY_FAILED" -> {
                state = "UNKNOWN"; uncertain = true; park = !budgetLeft;
            }
            case "HTTP_5XX", "REJECTED" -> {
                // 依据本替身契约：503/400 在接受之前返回，只说明“这一次”没有被接受。
                // 若此前有结果未知的尝试，这次拒绝不能证明之前那次未被接受：保留不确定标记，预算用尽则停放待人工。
                // 对没有“接受前拒绝”契约的渠道，5xx 本身也应按 UNKNOWN 处理。
                if (priorUncertain) {
                    state = "UNKNOWN"; uncertain = true; park = !budgetLeft || ob.outcome().equals("REJECTED");
                } else if (ob.outcome().equals("HTTP_5XX")) {
                    state = budgetLeft ? "PENDING" : "FAILED"; uncertain = false;
                } else {
                    state = "FAILED"; uncertain = false;
                }
            }
            default -> { state = "FAILED"; uncertain = false; }
        }
        c.setAutoCommit(false);
        try {
            int n = Db.update(c, """
                UPDATE delivery_task
                   SET state = ?, outcome_uncertain = ?, provider_msg_id = coalesce(?, provider_msg_id),
                       last_error = ?, lease_owner = NULL, lease_until = NULL,
                       next_attempt_at = CASE WHEN ? IN ('PENDING', 'UNKNOWN') AND NOT ?
                                              THEN now() + make_interval(secs => ?::float8 / 1000) END,
                       needs_review = ?, updated_at = now()
                 WHERE id = ? AND state = 'SENDING' AND attempt_token = ?""",
                state, uncertain, ob.msgId(), ob.detail(), state, park, retryDelayMs, park,
                cl.taskId(), cl.token());
            if (n == 0) {
                // 令牌已被新的领取替换：本次结果只作为迟到观察记入投递记录，不改变任务状态。
                Db.update(c, "UPDATE delivery_attempt SET late_outcome = ? WHERE attempt_token = ?",
                        ob.outcome(), cl.token());
                c.commit();
                return Result.STALE;
            }
            Db.update(c, """
                UPDATE delivery_attempt SET outcome = ?, http_status = ?, detail = ?, finished_at = clock_timestamp()
                 WHERE attempt_token = ?""", ob.outcome(), ob.status(), ob.detail(), cl.token());
            c.commit();
        } catch (SQLException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
        return switch (state) {
            case "SENT" -> Result.SENT;
            case "UNKNOWN" -> Result.UNKNOWN;
            case "PENDING" -> Result.RETRY;
            default -> Result.FAILED;
        };
    }

    public Result runOnce(Connection c) throws SQLException, InterruptedException {
        Optional<Claim> cl = claim(c);
        if (cl.isEmpty()) return Result.NOTHING;
        if (cl.get().token() == null) {
            String a = cl.get().action();
            if (a.endsWith("_UNCERTAIN")) return Result.UNKNOWN;
            return a.equals("PREF_DISABLED") ? Result.SUPPRESSED : Result.EXPIRED;
        }
        return finish(c, cl.get(), call(cl.get()));
    }

    /** 反复执行直到没有可执行任务（留出 retryDelay 的等待），或超过 deadline。 */
    public void drain(Connection c, long deadlineMs) throws SQLException, InterruptedException {
        long end = System.currentTimeMillis() + deadlineMs;
        while (System.currentTimeMillis() < end) {
            if (runOnce(c) != Result.NOTHING) continue;
            long waiting = Db.queryLong(c, """
                SELECT count(*) FROM delivery_task
                 WHERE state IN ('PENDING', 'UNKNOWN', 'SENDING') AND next_attempt_at IS NOT NULL
                    OR state = 'SENDING'""");
            if (waiting == 0) return;
            Thread.sleep(20);
        }
    }

    /** 人工处理：只允许处理预算用尽而停在 UNKNOWN 的任务，并留下一条 MANUAL 记录。 */
    public static int resolveManually(Connection c, long taskId, String finalState, String note) throws SQLException {
        c.setAutoCommit(false);
        try {
            int n = Db.update(c, """
                UPDATE delivery_task SET state = ?, needs_review = false, last_error = ?,
                       attempt_count = attempt_count + 1, updated_at = now()
                 WHERE id = ? AND state = 'UNKNOWN' AND needs_review""", finalState, note, taskId);
            if (n == 1) {
                Db.update(c, """
                    INSERT INTO delivery_attempt(task_id, attempt_no, attempt_token, worker, action, finished_at, outcome, detail)
                    SELECT id, attempt_count, ?, 'operator', 'MANUAL', clock_timestamp(), ?, ? FROM delivery_task WHERE id = ?""",
                    UUID.randomUUID(), "MANUAL_" + finalState, note, taskId);
            }
            c.commit();
            return n;
        } catch (SQLException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
    }

    private static String enc(String s) { return URLEncoder.encode(s == null ? "" : s, StandardCharsets.UTF_8); }
}
