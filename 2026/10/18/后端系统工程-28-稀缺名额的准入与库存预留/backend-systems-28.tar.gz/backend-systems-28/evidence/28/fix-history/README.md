# C28-04 修复记录（2026-10-19）

- `pre-fix-output.txt`：修复前代码的真实输出（主控复核运行），`C28-04` 出现 `{HELD=1, REPLAY=14, USER_LIMIT=1}`，`SUMMARY passed=94 failed=1`。
- `post-fix-run1..3-output.txt`：修复 `Inventory.reserveInTx` 后的连续 3 次真实输出，均为 `SUMMARY passed=95 failed=0`；第 4 次即 `../output.txt`。
- 这些文件由 `run-28.sh` 产生后从 /tmp 拷入，未经编辑。
