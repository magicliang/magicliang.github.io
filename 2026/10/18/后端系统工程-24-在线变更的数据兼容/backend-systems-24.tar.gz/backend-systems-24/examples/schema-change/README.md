# schema-change（第 24 篇：在线变更的数据兼容）

把合成工单表 `ticket` 的 `priority int(1..3)` 迁到 `priority_level text(low/normal/high[/urgent])`，
分阶段执行 扩张 → 双写 → 分批回填 → 校验 → 切读 → 停写旧列 → 收缩，并在真实 PostgreSQL 16 上验证 DDL 锁与约束行为。

运行：`./run.sh`（端口 55424，集群 b3-24；输出写入 `../../evidence/24/`）。

| 文件 | 内容 |
|---|---|
| `Schema.java` | 各阶段 DDL、取值映射函数、兼容触发器、校验查询 |
| `Apps.java` | v1/v2/v3 三个应用版本的读写语句 |
| `Backfill.java` | 键集分页的条件回填（带断点）与应用侧读—算—写对照 |
| `Migration.java` | 阶段推进、不可逆点越过/撤回、回退守卫、收缩 |
| `DdlTools.java` | lock_timeout 重试、DEBUG1 消息捕获、pg_locks / pg_blocking_pids 观察 |
| `Traffic.java` | 并发业务写线程与逐行期望值 |
| `BackfillWorker.java` | 独立 JVM 回填进程（崩溃实验用） |
| `SchemaLab.java` | 用例 S1–S11 |

用例与边界见 `../../evidence/24/LIMITS.md`。
