package lab.schema;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import lab.common.Db;

/** 阶段推进与回退守卫。每个动作在单个事务内完成，并持有 migration_state 行锁。 */
public final class Migration {
    private Migration() {}

    public record Verdict(boolean allowed, String reason, long unrepresentable) {}

    /** P1：加列与兼容触发器放在同一事务，避免“列已存在但旧代码写入无人同步”的窗口。 */
    public static int expand(Connection c, long lockTimeoutMs, int maxAttempts) throws Exception {
        return DdlTools.withLockRetry(c, lockTimeoutMs, maxAttempts, null, tx -> {
            Db.exec(tx, Schema.EXPAND_COLUMN);
            Db.exec(tx, Schema.COMPAT_TRIGGER);
            Schema.setPhase(tx, "P1-expanded");
        });
    }

    /** P4：校验通过后，依次 NOT VALID → VALIDATE → SET NOT NULL（三个事务）。 */
    public static List<String> enforceNotNull(Connection c, long lockTimeoutMs) throws Exception {
        DdlTools.withLockRetry(c, lockTimeoutMs, 20, null, tx ->
            Db.exec(tx, "ALTER TABLE ticket ADD CONSTRAINT level_nn CHECK (priority_level IS NOT NULL) NOT VALID"));
        DdlTools.withLockRetry(c, lockTimeoutMs, 20, null, tx ->
            Db.exec(tx, "ALTER TABLE ticket VALIDATE CONSTRAINT level_nn"));
        List<String> msgs = new ArrayList<>();
        DdlTools.withLockRetry(c, lockTimeoutMs, 20, null, tx -> {
            msgs.clear();
            msgs.addAll(DdlTools.execDebug(tx, "ALTER TABLE ticket ALTER COLUMN priority_level SET NOT NULL"));
            Schema.setPhase(tx, "P4-verified");
        });
        return msgs;
    }

    /**
     * 越过不可逆点：删除“禁止 urgent”的约束并记录时间。之后新代码可以写出旧列无法表达的值。
     */
    public static void crossNoReturn(Connection c) throws Exception {
        DdlTools.withLockRetry(c, 500, 20, null, tx -> {
            Db.exec(tx, "SELECT 1 FROM migration_state FOR UPDATE");
            Db.exec(tx, "ALTER TABLE ticket DROP CONSTRAINT no_urgent_before_cutover");
            Db.update(tx, "UPDATE migration_state SET no_return_at = now(), phase = 'P6-no-return'");
        });
    }

    /**
     * 撤回越过动作：重新加约束（带全表校验）。只要存在 urgent 行，ADD CONSTRAINT 以 23514 失败，
     * 状态保持“已越过”。是否可撤回由数据库的校验决定，而不是由操作者判断。
     */
    public static void uncross(Connection c) throws Exception {
        DdlTools.withLockRetry(c, 500, 20, null, tx -> {
            Db.exec(tx, "SELECT 1 FROM migration_state FOR UPDATE");
            Db.exec(tx, "ALTER TABLE ticket ADD CONSTRAINT no_urgent_before_cutover CHECK (priority_level <> 'urgent')");
            Db.update(tx, "UPDATE migration_state SET no_return_at = NULL, phase = 'P6-new-only'");
        });
    }

    /** 回退到 v1 的守卫（dryRun=true 只判定不改阶段）。 */
    public static Verdict rollbackToV1(Connection c, boolean dryRun) throws SQLException {
        c.setAutoCommit(false);
        try {
            String phase; boolean crossed;
            try (PreparedStatement ps = c.prepareStatement("SELECT phase, no_return_at IS NOT NULL FROM migration_state FOR UPDATE");
                 ResultSet rs = ps.executeQuery()) {
                rs.next(); phase = rs.getString(1); crossed = rs.getBoolean(2);
            }
            Verdict v;
            if (phase.startsWith("P7")) {
                v = new Verdict(false, "old column dropped at " + phase, -1);
            } else if (crossed) {
                long n = Db.queryLong(c, "SELECT count(*) FROM ticket WHERE priority_level = 'urgent'");
                v = new Verdict(false, "no-return point crossed", n);
            } else {
                long nullOld = Db.queryLong(c, "SELECT count(*) FROM ticket WHERE priority IS NULL");
                long mismatch = Db.queryLong(c, Schema.COUNT_MISMATCH);
                v = (nullOld == 0 && mismatch == 0)
                    ? new Verdict(true, "old column authoritative-compatible", 0)
                    : new Verdict(false, "old column incomplete null=" + nullOld + " mismatch=" + mismatch, nullOld + mismatch);
                if (v.allowed() && !dryRun) Schema.setPhase(c, "P0-rolled-back");
            }
            c.commit();
            return v;
        } catch (SQLException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
    }

    /** P7 收缩：删除兼容触发器与旧列。此后不存在数据库内的回退路径。 */
    public static void contract(Connection c) throws Exception {
        DdlTools.withLockRetry(c, 500, 20, null, tx -> {
            Db.exec(tx, "SELECT 1 FROM migration_state FOR UPDATE");
            Db.exec(tx, "DROP TRIGGER ticket_compat ON ticket");
            Db.exec(tx, "ALTER TABLE ticket DROP COLUMN priority");
            Db.update(tx, "UPDATE migration_state SET phase = 'P7-contracted'");
        });
    }
}
