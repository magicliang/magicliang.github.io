package lab.schema;

import java.sql.Connection;

/**
 * 独立 JVM 回填进程。参数：库名、作业名、批大小、每批在提交前停顿的毫秒数。
 * 每批在提交前打印 IN_TX，提交后打印 COMMITTED，供父进程观察；父进程可在任意时刻 kill -9。
 */
public final class BackfillWorker {
    public static void main(String[] args) throws Exception {
        String db = args[0], job = args[1];
        int batch = Integer.parseInt(args[2]);
        long pause = Long.parseLong(args[3]);
        try (Connection c = DdlTools.connectAs(db, "backfill-worker")) {
            Backfill.init(c, job);
            int[] n = {0};
            Backfill.Hook inTx = pause <= 0 ? null : () -> {
                System.out.println("IN_TX batch=" + (n[0] + 1));
                System.out.flush();
                Thread.sleep(pause);
            };
            while (Backfill.step(c, job, batch, inTx)) {
                n[0]++;
                System.out.println("COMMITTED batch=" + n[0]);
                System.out.flush();
            }
            System.out.println("DONE batches=" + n[0]);
        }
    }
}
