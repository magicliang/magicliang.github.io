package lab.schema;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import lab.common.Db;

/** 分批回填 priority_level。 */
public final class Backfill {
    private Backfill() {}

    public interface Hook { void run() throws Exception; }

    /**
     * 建立断点记录。max_id 取开工时新列仍为空的最大主键：扩张之后插入的行已由新代码或触发器
     * 填好新列，不在回填范围内。
     */
    public static void init(Connection c, String job) throws SQLException {
        Db.update(c, """
            INSERT INTO backfill_progress (job, last_id, max_id)
            SELECT ?, 0, coalesce(max(id), 0) FROM ticket WHERE priority_level IS NULL
            ON CONFLICT (job) DO NOTHING""", job);
    }

    /**
     * 正确做法：一个批次 = 一个事务，内含“锁断点行 → 条件更新本批 → 推进断点”。
     * 新值在数据库内由当前行计算；WHERE priority_level IS NULL 保证已有新值的行不被改写。
     * 返回 false 表示已经完成。inTx 只用于崩溃实验：在本批 UPDATE 之后、提交之前执行。
     */
    public static boolean step(Connection c, String job, int batch, Hook inTx) throws Exception {
        c.setAutoCommit(false);
        try {
            long last, max;
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT last_id, max_id FROM backfill_progress WHERE job = ? FOR UPDATE")) {
                ps.setString(1, job);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) throw new SQLException("no progress row for " + job);
                    last = rs.getLong(1); max = rs.getLong(2);
                }
            }
            if (last >= max) { c.commit(); return false; }
            // 键集分页：本批上界 = 断点之后第 batch 行的主键（主键可以稀疏）
            long hi = Db.queryLong(c, """
                SELECT coalesce(max(id), ?) FROM (
                  SELECT id FROM ticket WHERE id > ? AND id <= ? ORDER BY id LIMIT ?) s""", max, last, max, batch);
            int n = Db.update(c, """
                UPDATE ticket SET priority_level = lvl_of(priority)
                WHERE id > ? AND id <= ? AND priority_level IS NULL""", last, hi);
            if (inTx != null) inTx.run();
            Db.update(c, """
                UPDATE backfill_progress SET last_id = ?, batches = batches + 1, rows_updated = rows_updated + ?
                WHERE job = ?""", hi, n, job);
            c.commit();
            return true;
        } catch (Exception e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
    }

    public static void runToEnd(Connection c, String job, int batch) throws Exception {
        init(c, job);
        while (step(c, job, batch, null)) { /* next batch */ }
    }

    /**
     * 应用侧“读—算—写”回填。conditional=false 是错误方案：按读到的旧值无条件写回；
     * conditional=true 在写回时加 WHERE priority_level IS NULL。hook 在读完、写回之前执行，
     * 用于确定性地插入一次并发业务写。返回实际写入的行数。
     */
    public static int appSideBatch(Connection c, long lo, long hi, boolean conditional, Hook hook) throws Exception {
        List<long[]> rows = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT id, priority FROM ticket WHERE id BETWEEN ? AND ? AND priority_level IS NULL ORDER BY id")) {
            ps.setLong(1, lo); ps.setLong(2, hi);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) rows.add(new long[] {rs.getLong(1), rs.getInt(2)});
            }
        }
        if (hook != null) hook.run();
        String sql = conditional
            ? "UPDATE ticket SET priority_level = ? WHERE id = ? AND priority_level IS NULL"
            : "UPDATE ticket SET priority_level = ? WHERE id = ?";
        int written = 0;
        for (long[] r : rows) written += Db.update(c, sql, Apps.LVL_OF[(int) r[1]], r[0]);
        return written;
    }
}
