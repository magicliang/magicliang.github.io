package lab.schema;

import java.sql.Connection;
import java.sql.SQLException;
import lab.common.Db;

/**
 * 合成工单表 ticket 的各阶段 DDL。
 * 旧版本（v1）只认识整数列 priority（1/2/3）；新版本使用文本列 priority_level
 * （low/normal/high，越过不可逆点后再允许 urgent）。
 */
public final class Schema {
    private Schema() {}

    /** P0 基线：只有旧列。migration_state 记录阶段与不可逆点；backfill_progress 记录回填断点。 */
    public static final String BASE = """
        CREATE TABLE ticket (
          id         bigint PRIMARY KEY,
          title      text   NOT NULL,
          priority   int    CHECK (priority BETWEEN 1 AND 3),
          updated_by text   NOT NULL DEFAULT 'seed'
        );
        CREATE TABLE migration_state (
          singleton    boolean PRIMARY KEY DEFAULT true CHECK (singleton),
          phase        text NOT NULL,
          no_return_at timestamptz
        );
        INSERT INTO migration_state (phase) VALUES ('P0-baseline');
        CREATE TABLE backfill_progress (
          job          text PRIMARY KEY,
          last_id      bigint NOT NULL,
          max_id       bigint NOT NULL,
          batches      int    NOT NULL DEFAULT 0,
          rows_updated bigint NOT NULL DEFAULT 0
        );
        """;

    /** 新旧取值映射。int_of('urgent') 只能退化为 3，这一步有损。 */
    public static final String MAPPING = """
        CREATE FUNCTION lvl_of(p int) RETURNS text LANGUAGE sql IMMUTABLE AS
          $$ SELECT CASE p WHEN 1 THEN 'low' WHEN 2 THEN 'normal' WHEN 3 THEN 'high' END $$;
        CREATE FUNCTION int_of(l text) RETURNS int LANGUAGE sql IMMUTABLE AS
          $$ SELECT CASE l WHEN 'low' THEN 1 WHEN 'normal' THEN 2 WHEN 'high' THEN 3 WHEN 'urgent' THEN 3 END $$;
        """;

    /** P1 扩张：加可空新列（不带默认值，不重写表）与取值约束；urgent 在不可逆点之前由约束拒绝。 */
    public static final String EXPAND_COLUMN = """
        ALTER TABLE ticket
          ADD COLUMN priority_level text,
          ADD CONSTRAINT level_domain CHECK (priority_level IN ('low','normal','high','urgent')),
          ADD CONSTRAINT no_urgent_before_cutover CHECK (priority_level <> 'urgent')
        """;

    /**
     * 兼容触发器：哪一列被本条语句改了，就从它推导另一列。
     * 旧代码只改 priority → 推导 priority_level；只写新列的代码 → 推导 priority；
     * 两列都改（v2 双写）→ 原样保留。
     */
    public static final String COMPAT_TRIGGER = """
        CREATE FUNCTION ticket_compat() RETURNS trigger LANGUAGE plpgsql AS $$
        BEGIN
          IF TG_OP = 'INSERT' THEN
            IF NEW.priority_level IS NULL AND NEW.priority IS NOT NULL THEN
              NEW.priority_level := lvl_of(NEW.priority);
            ELSIF NEW.priority IS NULL AND NEW.priority_level IS NOT NULL THEN
              NEW.priority := int_of(NEW.priority_level);
            END IF;
          ELSE
            IF NEW.priority IS DISTINCT FROM OLD.priority
               AND NEW.priority_level IS NOT DISTINCT FROM OLD.priority_level THEN
              NEW.priority_level := lvl_of(NEW.priority);
            ELSIF NEW.priority_level IS DISTINCT FROM OLD.priority_level
               AND NEW.priority IS NOT DISTINCT FROM OLD.priority THEN
              NEW.priority := int_of(NEW.priority_level);
            END IF;
          END IF;
          RETURN NEW;
        END $$;
        CREATE TRIGGER ticket_compat BEFORE INSERT OR UPDATE ON ticket
          FOR EACH ROW EXECUTE FUNCTION ticket_compat();
        """;

    /** 校验查询：新列为空的行数、两列不一致的行数。 */
    public static final String COUNT_NULL = "SELECT count(*) FROM ticket WHERE priority_level IS NULL";
    public static final String COUNT_MISMATCH =
        """
        SELECT count(*) FROM ticket
        WHERE priority_level IS NOT NULL
          AND priority_level IS DISTINCT FROM lvl_of(priority)
          AND NOT (priority_level = 'urgent' AND priority = 3)""";

    public static void base(Connection c) throws SQLException {
        Db.exec(c, BASE);
        Db.exec(c, MAPPING);
    }

    public static void seed(Connection c, int n, long seed) throws SQLException {
        Db.update(c, """
            INSERT INTO ticket (id, title, priority)
            SELECT g, 'ticket-' || lpad(g::text, 5, '0'), 1 + ((g * ?::bigint) % 3)::int
            FROM generate_series(1, ?) g""", seed, n);
    }

    public static void setPhase(Connection c, String phase) throws SQLException {
        Db.update(c, "UPDATE migration_state SET phase = ?", phase);
    }

    public static String phase(Connection c) throws SQLException {
        return Db.queryString(c, "SELECT phase FROM migration_state");
    }
}
