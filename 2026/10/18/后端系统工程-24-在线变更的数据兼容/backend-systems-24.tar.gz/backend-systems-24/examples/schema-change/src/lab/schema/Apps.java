package lab.schema;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import lab.common.Db;

/** 三个应用版本对 ticket 的读写方式。每个方法是一条自动提交语句。 */
public final class Apps {
    private Apps() {}

    static final Map<String, Integer> INT_OF = Map.of("low", 1, "normal", 2, "high", 3);
    static final String[] LVL_OF = {null, "low", "normal", "high"};

    /** v1：只认识 priority（整数），不知道新列存在。 */
    public static final class V1 {
        private V1() {}
        public static int read(Connection c, long id) throws SQLException {
            return (int) Db.queryLong(c, "SELECT priority FROM ticket WHERE id = ?", id);
        }
        public static void setPriority(Connection c, long id, int p) throws SQLException {
            Db.update(c, "UPDATE ticket SET priority = ?, updated_by = 'v1' WHERE id = ?", p, id);
        }
        public static void create(Connection c, long id, String title, int p) throws SQLException {
            Db.update(c, "INSERT INTO ticket (id, title, priority, updated_by) VALUES (?, ?, ?, 'v1')", id, title, p);
        }
    }

    /** v2：双写两列；readNew=false 时读旧列（切读之前），true 时读新列。 */
    public static final class V2 {
        private V2() {}
        public static String read(Connection c, long id, boolean readNew) throws SQLException {
            if (readNew) return Db.queryString(c, "SELECT priority_level FROM ticket WHERE id = ?", id);
            return LVL_OF[(int) Db.queryLong(c, "SELECT priority FROM ticket WHERE id = ?", id)];
        }
        public static void setLevel(Connection c, long id, String level) throws SQLException {
            Integer p = INT_OF.get(level);
            if (p == null) throw new IllegalArgumentException("v2 cannot dual-write level " + level);
            Db.update(c, "UPDATE ticket SET priority_level = ?, priority = ?, updated_by = 'v2' WHERE id = ?", level, p, id);
        }
        public static void create(Connection c, long id, String title, String level) throws SQLException {
            Db.update(c, "INSERT INTO ticket (id, title, priority, priority_level, updated_by) VALUES (?, ?, ?, ?, 'v2')",
                id, title, INT_OF.get(level), level);
        }
    }

    /** v3：停写旧列，只读写 priority_level；不可逆点之后可以写 urgent。 */
    public static final class V3 {
        private V3() {}
        public static String read(Connection c, long id) throws SQLException {
            return Db.queryString(c, "SELECT priority_level FROM ticket WHERE id = ?", id);
        }
        public static void setLevel(Connection c, long id, String level) throws SQLException {
            Db.update(c, "UPDATE ticket SET priority_level = ?, updated_by = 'v3' WHERE id = ?", level, id);
        }
        public static void create(Connection c, long id, String title, String level) throws SQLException {
            Db.update(c, "INSERT INTO ticket (id, title, priority_level, updated_by) VALUES (?, ?, ?, 'v3')", id, title, level);
        }
    }
}
