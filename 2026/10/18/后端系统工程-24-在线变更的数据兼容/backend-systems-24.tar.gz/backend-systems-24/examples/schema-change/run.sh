#!/usr/bin/env bash
# 第 24 篇：一条命令完成 启动集群 → 编译 → 运行全部用例（各用例自建库）→ 写证据 → 停集群。
set -uo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
COMMON="$HERE/../common"
EVID="$HERE/../../evidence/24"
NAME=b3-24; PORT=55424
mkdir -p "$EVID"
export LAB_PGPORT=$PORT LAB_DB=schema24 LAB_BUILD=/tmp/batch3-build/ch24
{
  echo "date: $(date -Is)"
  echo "uname: $(uname -a)"
  java -version 2>&1 | sed 's/^/java: /'
  echo "postgres: $(/usr/lib/postgresql/16/bin/postgres --version)"
  echo "pgjdbc: postgresql-42.7.7.jar"
} > "$EVID/env.txt"
cat > "$EVID/commands.txt" <<CMD
cd examples/schema-change && ./run.sh
  initdb -D /tmp/batch3-pg/$NAME -U postgres -A trust -E UTF8 --locale=C.UTF-8 -c dynamic_shared_memory_type=mmap（仅首次）
  ../common/pg.sh start $NAME $PORT
  LAB_PGPORT=$PORT LAB_DB=schema24 ../common/lab.sh . lab.schema.SchemaLab
  （S11 用例内部启动子 JVM lab.schema.BackfillWorker，并对其执行 kill -9 <pid>）
  ../common/pg.sh stop $NAME
CMD
# 本机 /dev/shm 已满，默认 posix 动态共享内存会失败；预先以 mmap 初始化，pg.sh 检测到 PG_VERSION 后不再 initdb。
PGDIR=${BATCH3_PG_ROOT:-/tmp/batch3-pg}/$NAME
if [ ! -f "$PGDIR/PG_VERSION" ]; then
  mkdir -p "$(dirname "$PGDIR")"
  /usr/lib/postgresql/16/bin/initdb -D "$PGDIR" -U postgres -A trust -E UTF8 --locale=C.UTF-8 \
    -c dynamic_shared_memory_type=mmap >/dev/null
fi
"$COMMON/pg.sh" start $NAME $PORT
"$COMMON/lab.sh" "$HERE" lab.schema.SchemaLab > "$EVID/output.txt" 2>&1
rc=$?
"$COMMON/pg.sh" stop $NAME
echo "exit=$rc" >> "$EVID/commands.txt"
tail -n 3 "$EVID/output.txt"
exit $rc
