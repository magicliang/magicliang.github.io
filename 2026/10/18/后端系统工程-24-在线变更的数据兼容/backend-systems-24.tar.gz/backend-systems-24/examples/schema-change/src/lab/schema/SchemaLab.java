package lab.schema;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import lab.common.Check;
import lab.common.Db;

/** 第 24 篇全部用例：真实 PostgreSQL 16 DDL、锁、触发器、真实线程与独立 JVM 回填进程。 */
public final class SchemaLab {
    static final String P = System.getenv().getOrDefault("LAB_DB", "schema24");

    public static void main(String[] args) throws Exception {
        try (Connection c = Db.connect("postgres")) {
            Check.note("server_version=" + Db.queryString(c, "SHOW server_version"));
        }
        phasedMigrationUnderTraffic();   // S1
        lockQueueWithoutTimeout();       // S2
        lockTimeoutAndRetry();           // S3
        addColumnRewriteOrNot();         // S4
        checkNotValidThenValidate();     // S5
        setNotNullScanSkipped();         // S6
        concurrentIndexFailure();        // S7
        backfillOverwriteRace();         // S8
        oldCodeWritesOnlyOldColumn();    // S9
        noReturnPoint();                 // S10
        backfillWorkerKilled();          // S11
        System.exit(Check.finish());
    }

    static Connection fresh(String suffix) throws SQLException {
        Db.recreate(P + "_" + suffix);
        return Db.connect(P + "_" + suffix);
    }

    static long wrongVsExpected(Connection c) throws SQLException {
        long wrong = 0;
        try (Statement s = c.createStatement();
             ResultSet rs = s.executeQuery("SELECT id, priority_level FROM ticket")) {
            while (rs.next()) {
                String exp = Traffic.EXPECTED.get(rs.getLong(1));
                if (exp != null && !exp.equals(rs.getString(2))) wrong++;
            }
        }
        return wrong;
    }

    static void seedExpected(Connection c) throws SQLException {
        Traffic.EXPECTED.clear();
        try (Statement s = c.createStatement();
             ResultSet rs = s.executeQuery("SELECT id, lvl_of(priority) FROM ticket")) {
            while (rs.next()) Traffic.EXPECTED.put(rs.getLong(1), rs.getString(2));
        }
    }

    // ---------------------------------------------------------------- S1
    static void phasedMigrationUnderTraffic() throws Exception {
        Check.begin("S1", "正常路径：3000 行，v1/v2 写流量持续期间完成 扩张→双写→回填→校验→切读→停写旧列→收缩");
        String db = P + "_main";
        try (Connection c = fresh("main")) {
            Schema.base(c);
            Schema.seed(c, 3000, 7);
            seedExpected(c);
            Traffic.ERRORS.set(0); Traffic.WRITES_V1.set(0); Traffic.WRITES_V2.set(0); Traffic.INSERTS.set(0);
            List<Traffic> v1 = List.of(new Traffic(db, Traffic.Version.V1, 0, 4, 3000, 100_000, 11).start(),
                                       new Traffic(db, Traffic.Version.V1, 1, 4, 3000, 100_000, 12).start());
            Thread.sleep(300);
            int attempts = Migration.expand(c, 200, 20);
            Check.note("P1 expand committed on attempt " + attempts);
            Check.equal("P1-expanded", Schema.phase(c), "P1 加列与触发器在同一事务提交");
            Thread.sleep(300);
            Schema.setPhase(c, "P2-dual-write");
            List<Traffic> v2 = List.of(new Traffic(db, Traffic.Version.V2, 2, 4, 3000, 100_000, 13).start(),
                                       new Traffic(db, Traffic.Version.V2, 3, 4, 3000, 100_000, 14).start());
            Thread.sleep(300);
            Schema.setPhase(c, "P3-backfill");
            Backfill.runToEnd(c, "level-v1", 250);
            Thread.sleep(200);
            for (Traffic t : v1) t.stopAndJoin();
            for (Traffic t : v2) t.stopAndJoin();
            Check.note("writes v1=" + Traffic.WRITES_V1.get() + " v2=" + Traffic.WRITES_V2.get() + " inserts=" + Traffic.INSERTS.get()
                + " backfill batches=" + Db.queryLong(c, "SELECT batches FROM backfill_progress")
                + " backfill rows_updated=" + Db.queryLong(c, "SELECT rows_updated FROM backfill_progress"));
            Check.equal(0, Traffic.ERRORS.get(), "业务写入全程无错误");
            Check.that(Traffic.WRITES_V1.get() > 0 && Traffic.WRITES_V2.get() > 0, "新旧两版代码都在迁移期间写入");
            Check.equal(0L, Db.queryLong(c, Schema.COUNT_NULL), "P4 校验：新列无空值");
            Check.equal(0L, Db.queryLong(c, Schema.COUNT_MISMATCH), "P4 校验：新旧列逐行一致");
            Check.equal(0L, wrongVsExpected(c), "每行新列等于该行最后一次已提交业务写入（回填未覆盖新值）");
            List<String> msgs = Migration.enforceNotNull(c, 200);
            Check.that(DdlTools.anyContains(msgs, "sufficient to prove that it does not contain nulls"),
                "SET NOT NULL 由已验证 CHECK 证明，未扫描全表");
            Check.equal("NO", Db.queryString(c,
                "SELECT is_nullable FROM information_schema.columns WHERE table_name='ticket' AND column_name='priority_level'"),
                "priority_level 已为 NOT NULL");

            Schema.setPhase(c, "P5-read-new");
            long diff = 0;
            for (long id = 1; id <= 3000; id += 7) {
                if (!Apps.V2.read(c, id, false).equals(Apps.V2.read(c, id, true))) diff++;
            }
            Check.equal(0L, diff, "切读：抽样 429 行按旧列与按新列读出相同结果");

            Schema.setPhase(c, "P6-new-only");
            Traffic.ERRORS.set(0);
            Traffic v3 = new Traffic(db, Traffic.Version.V3, 0, 4, 3000, 200_000, 15).start();
            Thread.sleep(300);
            v3.stopAndJoin();
            Check.equal(0, Traffic.ERRORS.get(), "v3 只写新列无错误");
            Check.equal(0L, Db.queryLong(c, Schema.COUNT_MISMATCH), "v3 只写新列时，触发器仍维护旧列");
            Check.equal(0L, wrongVsExpected(c), "v3 写入后逐行核对通过");
            Migration.Verdict v = Migration.rollbackToV1(c, true);
            Check.that(v.allowed(), "不可逆点之前：回退到 v1 的守卫放行（" + v.reason() + "）");

            Migration.crossNoReturn(c);
            Apps.V3.setLevel(c, 2, "urgent");
            Migration.contract(c);
            Check.equal("P7-contracted", Schema.phase(c), "P7 收缩：触发器与旧列已删除");
            Check.equal("urgent", Apps.V3.read(c, 2), "v3 读写不受收缩影响");
            String st = null;
            try { Apps.V1.read(c, 1); } catch (SQLException e) { st = e.getSQLState(); }
            Check.equal("42703", st, "收缩后 v1 读取旧列失败（undefined_column）");
            Migration.Verdict after = Migration.rollbackToV1(c, true);
            Check.that(!after.allowed(), "收缩后回退守卫拒绝：" + after.reason());
        }
    }

    // ---------------------------------------------------------------- S2
    static void lockQueueWithoutTimeout() throws Exception {
        Check.begin("S2", "锁队列：长事务持 ACCESS SHARE，ALTER TABLE 排队等 ACCESS EXCLUSIVE，后来的 SELECT 排在它后面");
        String db = P + "_lock";
        try (Connection setup = fresh("lock")) {
            Schema.base(setup);
            Schema.seed(setup, 100, 7);
        }
        try (Connection obs = Db.connect(db);
             Connection longTx = DdlTools.connectAs(db, "long-reader");
             Connection ddl = DdlTools.connectAs(db, "ddl");
             Connection reader = DdlTools.connectAs(db, "late-reader")) {
            int pA = DdlTools.backendPid(longTx), pB = DdlTools.backendPid(ddl), pC = DdlTools.backendPid(reader);
            longTx.setAutoCommit(false);
            Db.queryLong(longTx, "SELECT count(*) FROM ticket");
            Check.equal(Set.of("AccessShareLock"), DdlTools.relLocks(obs, pA, "ticket", true), "长事务持有 AccessShareLock");

            CompletableFuture<String> alter = CompletableFuture.supplyAsync(() -> {
                try { Db.exec(ddl, "ALTER TABLE ticket ADD COLUMN note text"); return "ok"; }
                catch (SQLException e) { return e.getSQLState(); }
            });
            String w1 = DdlTools.waitUntilWaiting(obs, pB, 5000);
            Check.equal("relation:AccessExclusiveLock", w1, "ALTER TABLE 在等待 AccessExclusiveLock（granted=false）");
            Check.equal(Set.of("long-reader"), DdlTools.appNames(obs, DdlTools.blockingPids(obs, pB)), "ALTER 被长事务阻塞（hard block）");

            CompletableFuture<Long> late = CompletableFuture.supplyAsync(() -> {
                try { return Db.queryLong(reader, "SELECT count(*) FROM ticket"); }
                catch (SQLException e) { throw new RuntimeException(e); }
            });
            String w2 = DdlTools.waitUntilWaiting(obs, pC, 5000);
            Check.equal("relation:AccessShareLock", w2, "后来的普通 SELECT 也在等待 AccessShareLock");
            Check.equal(Set.of("ddl"), DdlTools.appNames(obs, DdlTools.blockingPids(obs, pC)),
                "pg_blocking_pids 显示 SELECT 被排队中的 ALTER 阻塞（soft block），而不是被长事务直接阻塞");
            Thread.sleep(300);
            Check.that(!late.isDone() && !alter.isDone(), "长事务不结束，ALTER 与 SELECT 都无法完成");

            longTx.commit();
            Check.equal("ok", alter.get(10, TimeUnit.SECONDS), "长事务提交后 ALTER 完成");
            Check.equal(100L, late.get(10, TimeUnit.SECONDS), "随后 SELECT 完成");
            Db.exec(ddl, "ALTER TABLE ticket DROP COLUMN note");
        }
    }

    // ---------------------------------------------------------------- S3
    static void lockTimeoutAndRetry() throws Exception {
        Check.begin("S3", "lock_timeout：DDL 拿不到锁时以 55P03 快速失败，不再挡住普通查询；释放后重试成功");
        String db = P + "_lock";
        try (Connection obs = Db.connect(db);
             Connection longTx = DdlTools.connectAs(db, "long-reader");
             Connection ddl = DdlTools.connectAs(db, "ddl");
             Connection reader = DdlTools.connectAs(db, "late-reader")) {
            longTx.setAutoCommit(false);
            Db.queryLong(longTx, "SELECT count(*) FROM ticket");
            String st = null;
            try {
                Db.exec(ddl, "SET lock_timeout = '300ms'");
                Db.exec(ddl, "ALTER TABLE ticket ADD COLUMN note text");
            } catch (SQLException e) { st = e.getSQLState(); }
            Check.equal("55P03", st, "lock_timeout 到期，ALTER 失败（lock_not_available）");
            Db.exec(ddl, "RESET lock_timeout");
            CompletableFuture<Long> late = CompletableFuture.supplyAsync(() -> {
                try { return Db.queryLong(reader, "SELECT count(*) FROM ticket"); }
                catch (SQLException e) { throw new RuntimeException(e); }
            });
            Check.equal(100L, late.get(5, TimeUnit.SECONDS), "DDL 放弃后，普通 SELECT 在长事务仍未结束时完成");
            Check.equal("idle in transaction", Db.queryString(obs,
                "SELECT state FROM pg_stat_activity WHERE application_name = 'long-reader'"), "此时长事务仍在进行");

            List<String> failures = new ArrayList<>();
            int attempts = DdlTools.withLockRetry(ddl, 300, 10, (n, e) -> {
                failures.add(n + ":" + e.getSQLState());
                if (n == 2) longTx.commit();      // 第二次失败后长事务结束
            }, tx -> Db.exec(tx, "ALTER TABLE ticket ADD COLUMN note text"));
            Check.equal(List.of("1:55P03", "2:55P03"), failures, "前两次尝试均为 55P03");
            Check.equal(3, attempts, "第三次尝试成功");
            Check.equal(1L, Db.queryLong(obs,
                "SELECT count(*) FROM information_schema.columns WHERE table_name='ticket' AND column_name='note'"), "列已加上");
        }
    }

    // ---------------------------------------------------------------- S4
    static void addColumnRewriteOrNot() throws Exception {
        Check.begin("S4", "ADD COLUMN：无默认值/非易变默认值不重写表；易变默认值重写表");
        try (Connection c = fresh("ddl")) {
            Db.exec(c, "CREATE TABLE probe (id int PRIMARY KEY, a int); INSERT INTO probe SELECT g, g FROM generate_series(1, 5000) g");
            long f0 = DdlTools.relfilenode(c, "probe");

            c.setAutoCommit(false);
            List<String> m1 = DdlTools.execDebug(c, "ALTER TABLE probe ADD COLUMN b text");
            Check.that(DdlTools.relLocks(c, DdlTools.backendPid(c), "probe", true).contains("AccessExclusiveLock"),
                "ADD COLUMN 持有 AccessExclusiveLock（直到事务结束）");
            c.commit(); c.setAutoCommit(true);
            Check.that(!DdlTools.anyContains(m1, "rewriting table"), "无默认值：无 rewriting table 消息");
            Check.that(f0 == DdlTools.relfilenode(c, "probe"), "无默认值：relfilenode 不变");

            List<String> m2 = DdlTools.execDebug(c, "ALTER TABLE probe ADD COLUMN c int DEFAULT 7");
            Check.that(!DdlTools.anyContains(m2, "rewriting table"), "常量默认值：无 rewriting table 消息");
            Check.that(f0 == DdlTools.relfilenode(c, "probe"), "常量默认值：relfilenode 不变");
            Check.equal("true", Db.queryString(c,
                "SELECT atthasmissing::text FROM pg_attribute WHERE attrelid='probe'::regclass AND attname='c'"),
                "常量默认值记录在 pg_attribute.atthasmissing/attmissingval");
            Check.equal(5000L, Db.queryLong(c, "SELECT count(*) FROM probe WHERE c = 7"), "既有行读到默认值 7");

            List<String> m3 = DdlTools.execDebug(c, "ALTER TABLE probe ADD COLUMN d timestamptz DEFAULT clock_timestamp()");
            Check.that(DdlTools.anyContains(m3, "rewriting table \"probe\""), "易变默认值 clock_timestamp()：出现 rewriting table 消息");
            Check.that(f0 != DdlTools.relfilenode(c, "probe"), "易变默认值：relfilenode 改变（表被重写）");
        }
    }

    // ---------------------------------------------------------------- S5
    static void checkNotValidThenValidate() throws Exception {
        Check.begin("S5", "CHECK ... NOT VALID：不扫描既有行，但约束新写入；VALIDATE 只持 SHARE UPDATE EXCLUSIVE");
        String db = P + "_ddl";
        try (Connection c = Db.connect(db); Connection other = Db.connect(db)) {
            Db.exec(c, """
                CREATE TABLE probe2 (id int PRIMARY KEY, v text, w int);
                INSERT INTO probe2 SELECT g, CASE WHEN g <= 10 THEN NULL ELSE 'x' END, 0 FROM generate_series(1, 1000) g""");
            List<String> m = DdlTools.execDebug(c, "ALTER TABLE probe2 ADD CONSTRAINT v_nn CHECK (v IS NOT NULL) NOT VALID");
            Check.that(!DdlTools.anyContains(m, "verifying table"), "NOT VALID：没有 verifying table 消息，既有 10 个空值未被检查");
            Check.equal("false", Db.queryString(c, "SELECT convalidated::text FROM pg_constraint WHERE conname='v_nn'"), "convalidated=false");
            String s1 = null;
            try { Db.update(c, "INSERT INTO probe2 VALUES (1001, NULL, 0)"); } catch (SQLException e) { s1 = e.getSQLState(); }
            Check.equal("23514", s1, "新插入的空值被拒绝（check_violation）");
            String s2 = null;
            try { Db.update(c, "UPDATE probe2 SET w = w + 1 WHERE id = 3"); } catch (SQLException e) { s2 = e.getSQLState(); }
            Check.equal("23514", s2, "边界：更新一条尚未修复的旧行的其他列，也因该行违反约束而失败");
            String s3 = null;
            try { Db.exec(c, "ALTER TABLE probe2 VALIDATE CONSTRAINT v_nn"); } catch (SQLException e) { s3 = e.getSQLState(); }
            Check.equal("23514", s3, "存在空值时 VALIDATE 失败");

            Db.update(c, "UPDATE probe2 SET v = 'fixed' WHERE v IS NULL");
            c.setAutoCommit(false);
            Db.exec(c, "ALTER TABLE probe2 VALIDATE CONSTRAINT v_nn");
            Check.equal(Set.of("ShareUpdateExclusiveLock"), DdlTools.relLocks(other, DdlTools.backendPid(c), "probe2", true),
                "VALIDATE 事务持有 ShareUpdateExclusiveLock");
            Db.exec(other, "SET lock_timeout = '2s'");
            int n = Db.update(other, "UPDATE probe2 SET w = w + 1 WHERE id = 500");
            Check.equal(1, n, "VALIDATE 未提交期间，另一会话的 UPDATE 不被阻塞");
            c.commit(); c.setAutoCommit(true);
            Check.equal("true", Db.queryString(c, "SELECT convalidated::text FROM pg_constraint WHERE conname='v_nn'"), "convalidated=true");
        }
    }

    // ---------------------------------------------------------------- S6
    static void setNotNullScanSkipped() throws Exception {
        Check.begin("S6", "SET NOT NULL：已验证 CHECK 可证明无空值时跳过全表扫描；NOT VALID 的 CHECK 不算");
        try (Connection c = Db.connect(P + "_ddl")) {
            c.setAutoCommit(false);
            List<String> m1 = DdlTools.execDebug(c, "ALTER TABLE probe2 ALTER COLUMN v SET NOT NULL");
            Check.that(DdlTools.relLocks(c, DdlTools.backendPid(c), "probe2", true).contains("AccessExclusiveLock"),
                "SET NOT NULL 持有 AccessExclusiveLock");
            c.commit(); c.setAutoCommit(true);
            Check.that(DdlTools.anyContains(m1, "existing constraints on column \"probe2.v\" are sufficient to prove"),
                "已验证 CHECK：出现“existing constraints ... sufficient to prove”");
            Check.that(!DdlTools.anyContains(m1, "verifying table"), "已验证 CHECK：没有 verifying table（未扫描）");

            Db.exec(c, """
                CREATE TABLE probe3 (id int PRIMARY KEY, v text);
                INSERT INTO probe3 SELECT g, 'x' FROM generate_series(1, 1000) g;
                ALTER TABLE probe3 ADD CONSTRAINT p3_nn CHECK (v IS NOT NULL) NOT VALID""");
            List<String> m2 = DdlTools.execDebug(c, "ALTER TABLE probe3 ALTER COLUMN v SET NOT NULL");
            Check.that(DdlTools.anyContains(m2, "verifying table \"probe3\"")
                    && !DdlTools.anyContains(m2, "sufficient to prove"),
                "负向对照：只有 NOT VALID 的 CHECK 时仍扫描全表（verifying table）");

            Db.exec(c, """
                CREATE TABLE probe4 (id int PRIMARY KEY, v text);
                INSERT INTO probe4 SELECT g, CASE WHEN g = 77 THEN NULL ELSE 'x' END FROM generate_series(1, 1000) g""");
            String st = null;
            try { Db.exec(c, "ALTER TABLE probe4 ALTER COLUMN v SET NOT NULL"); } catch (SQLException e) { st = e.getSQLState(); }
            Check.equal("23502", st, "无约束且存在空值：扫描发现空值，SET NOT NULL 失败（not_null_violation）");
        }
    }

    // ---------------------------------------------------------------- S7
    static void concurrentIndexFailure() throws Exception {
        Check.begin("S7", "CREATE INDEX CONCURRENTLY 失败后留下 INVALID 索引；IF NOT EXISTS 重试会掩盖它；删除后重建恢复");
        try (Connection c = Db.connect(P + "_ddl")) {
            Db.exec(c, """
                CREATE TABLE probe6 (id int PRIMARY KEY, code text);
                INSERT INTO probe6 SELECT g, 'code-' || g FROM generate_series(1, 2000) g;
                UPDATE probe6 SET code = 'code-1' WHERE id = 2000""");
            String st = null;
            try { Db.exec(c, "CREATE UNIQUE INDEX CONCURRENTLY probe6_code_uq ON probe6 (code)"); }
            catch (SQLException e) { st = e.getSQLState(); }
            Check.equal("23505", st, "重复值导致 CIC 失败（unique_violation）");
            String sel = "SELECT indisvalid::text FROM pg_index WHERE indexrelid = 'probe6_code_uq'::regclass";
            Check.equal("false", Db.queryString(c, sel), "失败后索引仍在目录中，pg_index.indisvalid=false");

            Db.exec(c, "SET enable_seqscan = off");
            String plan = explain(c, "SELECT * FROM probe6 WHERE code = 'code-5'");
            Check.that(!plan.contains("probe6_code_uq"), "INVALID 索引不被查询使用");

            List<String> m = DdlTools.execDebug(c, "CREATE UNIQUE INDEX CONCURRENTLY IF NOT EXISTS probe6_code_uq ON probe6 (code)");
            Check.exposes(DdlTools.anyContains(m, "already exists, skipping") && "false".equals(Db.queryString(c, sel)),
                "用 IF NOT EXISTS 重试“成功”返回，但索引仍是 INVALID");

            String st2 = null;
            c.setAutoCommit(false);
            try { Db.exec(c, "CREATE INDEX CONCURRENTLY probe6_tmp ON probe6 (code)"); }
            catch (SQLException e) { st2 = e.getSQLState(); }
            c.rollback(); c.setAutoCommit(true);
            Check.equal("25001", st2, "边界：CIC 不能在事务块内执行（active_sql_transaction）");

            Db.exec(c, "DROP INDEX CONCURRENTLY probe6_code_uq");
            Db.update(c, "UPDATE probe6 SET code = 'code-2000' WHERE id = 2000");
            Db.exec(c, "CREATE UNIQUE INDEX CONCURRENTLY probe6_code_uq ON probe6 (code)");
            Check.equal("true", Db.queryString(c, sel), "恢复：DROP INDEX CONCURRENTLY、修复重复值、重建后 indisvalid=true");
            Check.that(explain(c, "SELECT * FROM probe6 WHERE code = 'code-5'").contains("probe6_code_uq"), "重建后的索引被查询使用");
            Db.exec(c, "RESET enable_seqscan");
        }
    }

    static String explain(Connection c, String sql) throws SQLException {
        StringBuilder sb = new StringBuilder();
        try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("EXPLAIN " + sql)) {
            while (rs.next()) sb.append(rs.getString(1)).append('\n');
        }
        return sb.toString();
    }

    // ---------------------------------------------------------------- S8
    static void resetRace(Connection c) throws SQLException {
        // 关闭触发器后重新灌数，模拟“扩张之前就已存在、新列为空”的行
        Db.exec(c, "ALTER TABLE ticket DISABLE TRIGGER ticket_compat; TRUNCATE ticket; TRUNCATE backfill_progress");
        Schema.seed(c, 10, 7);
        Db.exec(c, "ALTER TABLE ticket ENABLE TRIGGER ticket_compat");
    }

    static void backfillOverwriteRace() throws Exception {
        Check.begin("S8", "回填与新代码写入交错：无条件写回覆盖新值；条件更新保留新值");
        String db = P + "_race";
        try (Connection c = fresh("race"); Connection app = Db.connect(db); Connection obs = Db.connect(db)) {
            Schema.base(c);
            Migration.expand(c, 500, 5);
            resetRace(c);
            long id = Db.queryLong(c, "SELECT min(id) FROM ticket WHERE priority = 1");
            Check.note("目标行 id=" + id + "，种子 priority=1（low）；并发写入把它改为 high");

            int w = Backfill.appSideBatch(c, 1, 10, false, () -> Apps.V2.setLevel(app, id, "high"));
            Check.note("无条件写回行数=" + w);
            String got = Db.queryString(c, "SELECT priority_level FROM ticket WHERE id = ?", id);
            Check.exposes(!"high".equals(got), "读—算—无条件写回把新写入的 high 覆盖为 " + got);
            Check.exposes(Db.queryLong(c, Schema.COUNT_MISMATCH) == 0,
                "被覆盖后新旧两列仍一致（mismatch=0），列间比对查不出这次丢失");

            resetRace(c);
            int w2 = Backfill.appSideBatch(c, 1, 10, true, () -> Apps.V2.setLevel(app, id, "high"));
            Check.equal(9, w2, "条件写回：10 行中跳过已有新值的 1 行");
            Check.equal("high", Db.queryString(c, "SELECT priority_level FROM ticket WHERE id = ?", id), "条件写回保留 high");

            // 数据库内单语句条件更新，真实行锁交错
            resetRace(c);
            app.setAutoCommit(false);
            Apps.V2.setLevel(app, id, "high");             // 未提交，持有行锁
            int appPid = DdlTools.backendPid(app);
            Backfill.init(c, "race");
            try (Connection bf = Db.connect(db)) {
                int bfPid = DdlTools.backendPid(bf);
                CompletableFuture<Boolean> step = CompletableFuture.supplyAsync(() -> {
                    try { return Backfill.step(bf, "race", 100, null); } catch (Exception e) { throw new RuntimeException(e); }
                });
                String waiting = DdlTools.waitUntilWaiting(obs, bfPid, 5000);
                Check.equal("transactionid:ShareLock", waiting, "回填 UPDATE 在目标行上等待业务事务结束");
                Check.that(DdlTools.blockingPids(obs, bfPid).equals(Set.of(appPid)), "阻塞者是未提交的业务事务");
                app.commit(); app.setAutoCommit(true);
                Check.that(step.get(10, TimeUnit.SECONDS), "回填批次提交");
            }
            Check.equal(9L, Db.queryLong(c, "SELECT rows_updated FROM backfill_progress WHERE job='race'"),
                "READ COMMITTED 下 WHERE priority_level IS NULL 在新版本行上重新求值，跳过该行");
            Check.equal("high", Db.queryString(c, "SELECT priority_level FROM ticket WHERE id = ?", id), "新值保留");

            // 不带 IS NULL 的数据库内重算：只在旧列能表达新值时碰巧正确
            Db.exec(c, "ALTER TABLE ticket DROP CONSTRAINT no_urgent_before_cutover");
            Apps.V3.setLevel(c, id, "urgent");
            Db.update(c, "UPDATE ticket SET priority_level = lvl_of(priority) WHERE id BETWEEN 1 AND 10");
            String g2 = Db.queryString(c, "SELECT priority_level FROM ticket WHERE id = ?", id);
            Check.exposes("high".equals(g2), "无条件 SET priority_level = lvl_of(priority) 把 urgent 改写为 " + g2);
        }
    }

    // ---------------------------------------------------------------- S9
    static void oldCodeWritesOnlyOldColumn() throws Exception {
        Check.begin("S9", "旧代码只写旧列：无触发器时新列落后；有兼容触发器时保持一致");
        try (Connection c = fresh("compat_neg")) {
            Schema.base(c);
            Schema.seed(c, 20, 7);
            Db.exec(c, Schema.EXPAND_COLUMN);                 // 只加列，不建触发器
            Backfill.runToEnd(c, "j", 5);
            Check.equal(0L, Db.queryLong(c, Schema.COUNT_NULL), "回填完成时新列无空值");
            int p7 = Apps.V1.read(c, 7);
            Apps.V1.setPriority(c, 7, p7 == 3 ? 1 : 3);
            Apps.V1.create(c, 21, "made-by-v1", 2);
            Check.exposes(Db.queryLong(c, Schema.COUNT_MISMATCH) == 1, "v1 更新后新列仍是旧值（mismatch=1）");
            Check.exposes(Db.queryLong(c, Schema.COUNT_NULL) == 1, "v1 新插入的行新列为空（null=1）");
        }
        try (Connection c = fresh("compat")) {
            Schema.base(c);
            Schema.seed(c, 20, 7);
            Migration.expand(c, 500, 5);
            Backfill.runToEnd(c, "j", 5);
            int p7 = Apps.V1.read(c, 7);
            Apps.V1.setPriority(c, 7, p7 == 3 ? 1 : 3);
            Apps.V1.create(c, 21, "made-by-v1", 2);
            Apps.V3.setLevel(c, 8, "low");
            Check.equal(0L, Db.queryLong(c, Schema.COUNT_MISMATCH), "触发器同步后 mismatch=0");
            Check.equal(0L, Db.queryLong(c, Schema.COUNT_NULL), "v1 插入的行由触发器填入新列");
            Check.equal("normal", Db.queryString(c, "SELECT priority_level FROM ticket WHERE id = 21"), "id 21：priority 2 → normal");
            Check.equal(1, Apps.V1.read(c, 8), "v3 只写新列 low，v1 读到 priority=1");
        }
    }

    // ---------------------------------------------------------------- S10
    static void noReturnPoint() throws Exception {
        Check.begin("S10", "不可逆点：urgent 写入之后，回退到 v1 不再无损，守卫拒绝");
        try (Connection c = fresh("noreturn")) {
            Schema.base(c);
            Schema.seed(c, 20, 7);
            Migration.expand(c, 500, 5);
            Backfill.runToEnd(c, "j", 5);
            Migration.enforceNotNull(c, 500);
            Schema.setPhase(c, "P6-new-only");
            String st = null;
            try { Apps.V3.setLevel(c, 4, "urgent"); } catch (SQLException e) { st = e.getSQLState(); }
            Check.equal("23514", st, "越过之前，数据库约束拒绝 urgent");
            Check.that(Migration.rollbackToV1(c, true).allowed(), "越过之前回退守卫放行");

            Migration.crossNoReturn(c);
            Migration.Verdict v1 = Migration.rollbackToV1(c, true);
            Check.that(!v1.allowed() && v1.unrepresentable() == 0, "已越过但尚无 urgent：守卫拒绝回退（" + v1.reason() + "）");
            Migration.uncross(c);
            Check.that(Migration.rollbackToV1(c, true).allowed(), "无 urgent 行时可以撤回越过动作，守卫重新放行");

            Migration.crossNoReturn(c);
            Apps.V3.setLevel(c, 4, "urgent");
            String st2 = null;
            try { Migration.uncross(c); } catch (SQLException e) { st2 = e.getSQLState(); }
            Check.equal("23514", st2, "存在 urgent 行时撤回失败：重新加约束的校验扫描发现违规");
            Migration.Verdict v2 = Migration.rollbackToV1(c, true);
            Check.that(!v2.allowed() && v2.unrepresentable() == 1, "守卫拒绝回退，报告 1 行旧格式无法表达");
            Check.equal("P6-no-return", Schema.phase(c), "阶段保持 P6-no-return");

            // 负向对照：绕过守卫，直接让 v1 上线
            Check.exposes(Apps.V1.read(c, 4) == 3, "v1 把 urgent 读成 priority=3（high），语义已丢失");
            Apps.V1.setPriority(c, 4, 2);
            Apps.V1.setPriority(c, 4, 3);
            String g = Db.queryString(c, "SELECT priority_level FROM ticket WHERE id = 4");
            Check.exposes("high".equals(g), "v1 改优先级再改回 3 后，新列变为 " + g + "，urgent 永久丢失");
        }
    }

    // ---------------------------------------------------------------- S11
    static void backfillWorkerKilled() throws Exception {
        Check.begin("S11", "回填进程在批次事务中被 kill -9：未提交批次回滚，断点不前进；重启后续跑，新值不被覆盖");
        String db = P + "_crash";
        try (Connection c = fresh("crash")) {
            Schema.base(c);
            Schema.seed(c, 4000, 7);
            Migration.expand(c, 500, 5);
            seedExpected(c);
            Traffic.ERRORS.set(0);
            List<Traffic> tr = List.of(new Traffic(db, Traffic.Version.V1, 0, 3, 4000, 100_000, 21).start(),
                                       new Traffic(db, Traffic.Version.V2, 1, 3, 4000, 100_000, 22).start(),
                                       new Traffic(db, Traffic.Version.V3, 2, 3, 4000, 100_000, 23).start());
            Process p = worker(db, 200, 1000);
            BufferedReader out = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String l;
            while ((l = out.readLine()) != null && !l.equals("IN_TX batch=4")) Check.note("worker: " + l);
            Check.note("worker: " + l);
            String state = Db.queryString(c, "SELECT state FROM pg_stat_activity WHERE application_name = 'backfill-worker'");
            Check.equal("idle in transaction", state, "kill 前，回填会话停在第 4 批事务内（已 UPDATE、未提交）");
            long before = Db.queryLong(c, "SELECT last_id FROM backfill_progress");
            new ProcessBuilder("kill", "-9", Long.toString(p.pid())).inheritIO().start().waitFor();
            Check.note("worker exit=" + p.waitFor() + " last_id at kill=" + before);
            long gone = 1;
            for (int i = 0; i < 200 && gone > 0; i++) {
                gone = Db.queryLong(c, "SELECT count(*) FROM pg_stat_activity WHERE application_name = 'backfill-worker'");
                if (gone > 0) Thread.sleep(20);
            }
            Check.equal(0L, gone, "服务端清理了被杀进程的会话");
            Check.equal(before, Db.queryLong(c, "SELECT last_id FROM backfill_progress"), "断点未前进：被中断批次整体回滚");
            long hi = before + 200;
            long nullsInBatch = Db.queryLong(c, "SELECT count(*) FROM ticket WHERE id > ? AND id <= ? AND priority_level IS NULL", before, hi);
            Check.that(nullsInBatch > 0, "被中断批次的未触碰行仍为空（" + nullsInBatch + " 行）");

            Process p2 = worker(db, 200, 0);
            BufferedReader out2 = new BufferedReader(new InputStreamReader(p2.getInputStream()));
            String line, last = null;
            while ((line = out2.readLine()) != null) last = line;
            Check.equal(0, p2.waitFor(), "重启的回填进程正常结束");
            Check.note("worker2: " + last);
            for (Traffic t : tr) t.stopAndJoin();
            Check.equal(0, Traffic.ERRORS.get(), "业务写入无错误");
            Check.equal(Db.queryLong(c, "SELECT max_id FROM backfill_progress"),
                Db.queryLong(c, "SELECT last_id FROM backfill_progress"), "断点到达 max_id");
            Check.equal(0L, Db.queryLong(c, Schema.COUNT_NULL), "新列无空值");
            Check.equal(0L, Db.queryLong(c, Schema.COUNT_MISMATCH), "新旧列一致");
            Check.equal(0L, wrongVsExpected(c), "每行等于最后一次已提交业务写入");
        }
    }

    static Process worker(String db, int batch, long pauseMs) throws Exception {
        String java = Path.of(System.getProperty("java.home"), "bin", "java").toString();
        return new ProcessBuilder(java, "-cp", System.getProperty("java.class.path"),
            "lab.schema.BackfillWorker", db, "level-v1", Integer.toString(batch), Long.toString(pauseMs))
            .redirectErrorStream(true).start();
    }

}
