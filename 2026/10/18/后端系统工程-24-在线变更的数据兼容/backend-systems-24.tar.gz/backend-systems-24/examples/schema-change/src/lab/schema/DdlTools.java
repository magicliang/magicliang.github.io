package lab.schema;

import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import lab.common.Db;

/** DDL 重试、调试消息捕获与 pg_locks 观察。 */
public final class DdlTools {
    private DdlTools() {}

    public interface TxBody { void run(Connection tx) throws Exception; }
    public interface OnFail { void failed(int attempt, SQLException e) throws Exception; }

    /** SQLSTATE 55P03 = lock_not_available，lock_timeout 到期时返回。 */
    public static final String LOCK_NOT_AVAILABLE = "55P03";

    /**
     * 在事务内设置 lock_timeout 后执行 body；拿不到锁就回滚、退避、重试。
     * 返回成功时的尝试序号。其他错误原样抛出，不重试。
     */
    public static int withLockRetry(Connection c, long lockTimeoutMs, int maxAttempts, OnFail onFail, TxBody body)
            throws Exception {
        SQLException last = null;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            c.setAutoCommit(false);
            try {
                Db.exec(c, "SET LOCAL lock_timeout = '" + lockTimeoutMs + "ms'");
                body.run(c);
                c.commit();
                return attempt;
            } catch (SQLException e) {
                c.rollback();
                if (!LOCK_NOT_AVAILABLE.equals(e.getSQLState())) throw e;
                last = e;
                if (onFail != null) onFail.failed(attempt, e);
                Thread.sleep(50L * attempt);
            } finally {
                c.setAutoCommit(true);
            }
        }
        throw last;
    }

    /** 以 client_min_messages=debug1 执行一条语句，返回服务端发来的 DEBUG/NOTICE 文本。 */
    public static List<String> execDebug(Connection c, String sql) throws SQLException {
        List<String> out = new ArrayList<>();
        Db.exec(c, "SET client_min_messages = debug1");
        try (Statement s = c.createStatement()) {
            s.execute(sql);
            for (SQLWarning w = s.getWarnings(); w != null; w = w.getNextWarning()) out.add(w.getMessage());
        } finally {
            Db.exec(c, "RESET client_min_messages");
        }
        return out;
    }

    public static boolean anyContains(List<String> msgs, String needle) {
        return msgs.stream().anyMatch(m -> m.contains(needle));
    }

    public static long relfilenode(Connection c, String table) throws SQLException {
        return Db.queryLong(c, "SELECT relfilenode FROM pg_class WHERE oid = ?::regclass", table);
    }

    public static int backendPid(Connection c) throws SQLException {
        return (int) Db.queryLong(c, "SELECT pg_backend_pid()");
    }

    public static Connection connectAs(String db, String appName) throws SQLException {
        return DriverManager.getConnection(Db.url(db) + "?ApplicationName=" + appName, "postgres", "");
    }

    /** pid 在 table 上持有（granted=true）或等待（granted=false）的表级锁模式。 */
    public static Set<String> relLocks(Connection obs, int pid, String table, boolean granted) throws SQLException {
        Set<String> modes = new TreeSet<>();
        try (PreparedStatement ps = obs.prepareStatement("""
                SELECT mode FROM pg_locks
                WHERE pid = ? AND locktype = 'relation' AND relation = ?::regclass AND granted = ?""")) {
            ps.setInt(1, pid); ps.setString(2, table); ps.setBoolean(3, granted);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) modes.add(rs.getString(1)); }
        }
        return modes;
    }

    /** 轮询直到 pid 出现一条未授予的锁请求；返回该锁的 locktype:mode，超时返回 null。 */
    public static String waitUntilWaiting(Connection obs, int pid, long timeoutMs) throws Exception {
        long deadline = System.nanoTime() + timeoutMs * 1_000_000;
        while (System.nanoTime() < deadline) {
            String s = Db.queryString(obs, "SELECT locktype || ':' || mode FROM pg_locks WHERE pid = ? AND NOT granted", pid);
            if (s != null) return s;
            Thread.sleep(20);
        }
        return null;
    }

    public static Set<Integer> blockingPids(Connection obs, int pid) throws SQLException {
        Set<Integer> out = new TreeSet<>();
        try (PreparedStatement ps = obs.prepareStatement("SELECT pg_blocking_pids(?)")) {
            ps.setInt(1, pid);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                Array a = rs.getArray(1);
                for (Integer i : (Integer[]) a.getArray()) out.add(i);
            }
        }
        return out;
    }

    /** 把 PID 集合换成 pg_stat_activity.application_name，便于输出稳定可比。 */
    public static Set<String> appNames(Connection obs, Set<Integer> pids) throws SQLException {
        Set<String> out = new TreeSet<>();
        for (int pid : pids) out.add(Db.queryString(obs, "SELECT application_name FROM pg_stat_activity WHERE pid = ?", pid));
        return out;
    }

    public static String sqlState(Exception e) {
        Throwable t = e;
        while (t != null) {
            if (t instanceof SQLException s) return s.getSQLState();
            t = t.getCause();
        }
        return null;
    }
}
