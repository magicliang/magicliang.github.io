package lab.schema;

import java.sql.Connection;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import lab.common.Db;

/**
 * 业务写流量。每个线程独占 id % owners == slot 的行，所以同一行的写入顺序就是该线程的程序顺序，
 * 线程记录每行“最后一次已提交写入”的期望 priority_level，供结束后逐行核对。
 */
public final class Traffic implements Runnable {
    public enum Version { V1, V2, V3 }

    public static final Map<Long, String> EXPECTED = new ConcurrentHashMap<>();
    public static final AtomicInteger ERRORS = new AtomicInteger();
    public static final AtomicLong WRITES_V1 = new AtomicLong(), WRITES_V2 = new AtomicLong(), INSERTS = new AtomicLong();

    private static final String[] LEVELS = {"low", "normal", "high"};

    final String db; final Version version; final int slot, owners; final long maxId, insertBase;
    final AtomicBoolean stop = new AtomicBoolean();
    final Random rnd;
    Thread thread;

    public Traffic(String db, Version v, int slot, int owners, long maxId, long insertBase, long seed) {
        this.db = db; this.version = v; this.slot = slot; this.owners = owners; this.maxId = maxId;
        this.insertBase = insertBase; this.rnd = new Random(seed);
    }

    public Traffic start() { thread = new Thread(this, "traffic-" + version + "-" + slot); thread.start(); return this; }

    public void stopAndJoin() throws InterruptedException { stop.set(true); thread.join(); }

    @Override public void run() {
        long nextInsert = insertBase + slot;
        try (Connection c = Db.connect(db)) {
            while (!stop.get()) {
                try {
                    if (rnd.nextInt(20) == 0) {
                        long id = nextInsert; nextInsert += owners;
                        String lvl = LEVELS[rnd.nextInt(3)];
                        switch (version) {
                            case V1 -> Apps.V1.create(c, id, "new-" + id, Apps.INT_OF.get(lvl));
                            case V2 -> Apps.V2.create(c, id, "new-" + id, lvl);
                            case V3 -> Apps.V3.create(c, id, "new-" + id, lvl);
                        }
                        EXPECTED.put(id, lvl);
                        INSERTS.incrementAndGet();
                    } else {
                        long id = 1 + rnd.nextInt((int) (maxId / owners)) * (long) owners + slot;
                        if (id > maxId) continue;
                        String lvl = LEVELS[rnd.nextInt(3)];
                        switch (version) {
                            case V1 -> { Apps.V1.setPriority(c, id, Apps.INT_OF.get(lvl)); WRITES_V1.incrementAndGet(); }
                            case V2 -> { Apps.V2.setLevel(c, id, lvl); WRITES_V2.incrementAndGet(); }
                            case V3 -> { Apps.V3.setLevel(c, id, lvl); WRITES_V2.incrementAndGet(); }
                        }
                        EXPECTED.put(id, lvl);
                    }
                    Thread.sleep(1);
                } catch (Exception e) {
                    ERRORS.incrementAndGet();
                    System.out.println("  note traffic error " + version + ": " + e.getMessage());
                }
            }
        } catch (Exception e) {
            ERRORS.incrementAndGet();
            System.out.println("  note traffic connect error: " + e.getMessage());
        }
    }
}
