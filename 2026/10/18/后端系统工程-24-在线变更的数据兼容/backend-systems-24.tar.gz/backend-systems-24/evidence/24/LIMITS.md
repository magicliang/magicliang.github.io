# 第 24 篇证据边界

运行入口：`examples/schema-change/run.sh`；主类 `lab.schema.SchemaLab`；子进程主类 `lab.schema.BackfillWorker`。
环境见 `env.txt`（PostgreSQL 16.15、OpenJDK 21、pgJDBC 42.7.7，单机）。输出 `output.txt` 由程序打印，未经手工编辑。

## 实验类别与状态

| 用例 | 类别 | 状态 | 证明了什么 | 不证明什么 |
|---|---|---|---|---|
| S1 分阶段迁移 | 真实组件实验（真实 PostgreSQL 事务、触发器、4 个真实写线程） | PASS | 在 3000 行种子数据、v1/v2 并发写入下，七个阶段依次完成；回填后新列无空值、两列一致、每行等于该行最后一次已提交业务写入；SET NOT NULL 由已验证 CHECK 免扫描；收缩后 v1 查询以 42703 失败 | 不证明更大数据量、更多写线程或其他调度下的结果；写入次数每次运行不同，只作为“确实有并发写”的旁证，不是吞吐数据 |
| S2 锁队列 | 真实组件实验 | PASS | 持有 AccessShareLock 的未结束事务使 ALTER TABLE 等待 AccessExclusiveLock，随后的普通 SELECT 被 pg_blocking_pids 报告为被 ALTER 阻塞 | 不测量阻塞时长；不覆盖 autovacuum、复制槽等其他持锁来源 |
| S3 lock_timeout 与重试 | 真实组件实验 | PASS | lock_timeout=300ms 时 DDL 以 55P03 失败，普通 SELECT 在长事务未结束时完成；两次失败后第三次成功（长事务在第二次失败后由用例提交，次数是用例构造的确定值） | 不给出 lock_timeout 的推荐值；不证明重试一定在有限次内成功（长事务若一直不结束，重试会耗尽） |
| S4 ADD COLUMN | 真实组件实验 | PASS | 无默认值、常量默认值：无 rewriting table 消息、relfilenode 不变、atthasmissing=true；clock_timestamp() 默认值：出现 rewriting table、relfilenode 改变；ADD COLUMN 持有 AccessExclusiveLock | 不测量重写耗时与磁盘占用；判断依据是 DEBUG1 消息和 relfilenode，未阅读 tablecmds.c 源码（本环境不可达） |
| S5 CHECK NOT VALID / VALIDATE | 真实组件实验 | PASS | NOT VALID 不检查既有空值但拒绝新空值；更新未修复旧行的其他列也会失败；VALIDATE 在有空值时 23514 失败，修复后成功且只持 ShareUpdateExclusiveLock，期间另一会话 UPDATE 不阻塞 | 不覆盖外键 NOT VALID；不测量 VALIDATE 扫描耗时 |
| S6 SET NOT NULL | 真实组件实验 | PASS | 已验证 CHECK 存在时出现“sufficient to prove”消息且无 verifying table；只有 NOT VALID CHECK 时仍 verifying table（负向对照）；有空值时 23502 | SET NOT NULL 仍取 AccessExclusiveLock，免扫描只缩短持锁时间，不消除锁排队 |
| S7 CREATE INDEX CONCURRENTLY | 真实组件实验 | PASS | 重复值导致 23505 并留下 indisvalid=false 的索引，计划不使用它；IF NOT EXISTS 重试只发 NOTICE、索引仍 INVALID（负向对照）；事务块内 25001；DROP INDEX CONCURRENTLY + 修复 + 重建后 indisvalid=true 并被计划使用 | 失败发生在构建扫描阶段；文档所述“第二次扫描失败后 INVALID 唯一索引仍约束唯一性”未构造实验 |
| S8 回填覆盖竞争 | 真实组件实验（确定性交错 + 真实行锁等待） | PASS | 应用侧读—算—无条件写回覆盖了并发写入的 high（负向对照），且覆盖后列间比对 mismatch=0；条件写回跳过该行；数据库内条件 UPDATE 等待未提交业务事务（transactionid:ShareLock，pg_blocking_pids 指向业务会话），提交后重新求值并跳过；不带 IS NULL 的库内重算把 urgent 改写为 high（负向对照） | 只验证 READ COMMITTED；REPEATABLE READ/SERIALIZABLE 下同一交错会以 40001 失败，未实验 |
| S9 旧代码只写旧列 | 真实组件实验 | PASS | 无触发器时 v1 更新使 mismatch=1、v1 插入使 null=1（负向对照）；有兼容触发器时二者为 0，v3 只写新列时 v1 读到推导出的旧值 | 触发器只覆盖经由 SQL 的写入；不覆盖 COPY FREEZE、逻辑复制回放等绕过或禁用触发器的路径（未实验） |
| S10 不可逆点 | 真实组件实验 | PASS | 越过前约束拒绝 urgent（23514）、守卫放行回退；越过且无 urgent 时可撤回；写入 urgent 后撤回因校验扫描 23514 失败，守卫拒绝并报告 1 行无法表达；绕过守卫让 v1 上线会把 urgent 读成 3，并在 3→2→3 后永久变为 high（负向对照） | 守卫只管数据库内的回退路径；外部已消费的 urgent（通知、报表、下游副本）不在本实验范围 |
| S11 回填进程被 kill -9 | 多进程集成（独立 JVM 子进程 + kill -9，真实 PostgreSQL） | PASS | 子进程停在第 4 批事务内时被 SIGKILL（exit=137）；服务端清理会话，断点仍为 600，该批未触碰行仍为空；重启后续跑到 max_id，三版本并发写入下新列无空值、两列一致、逐行等于最后一次已提交写入 | 不覆盖数据库服务端崩溃（未在本章做 restart-immediate）；不证明跨机器或网络分区下的行为 |

## 总体限制

- 单机单库实验，不证明多副本、逻辑复制、跨机房部署中的 schema 变更行为。
- “新旧代码并存”由同一 JVM 内不同类（Apps.V1/V2/V3）与不同线程模拟，未做真实滚动发布；F1 论文中的 schema 租约与写栅栏未实现，正文只作为概念出处。
- 不报告吞吐、延迟或 DDL 耗时。output.txt 中的写入次数、批次数、阻塞者 PID、relfilenode 数值每次运行不同，只用于说明本次运行确实发生了相应事件。
- 所有数据为合成数据（ticket-00001 形式的标题，优先级由公式生成）。
