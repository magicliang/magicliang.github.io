package lab.flash.order;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.atomic.AtomicReference;
import lab.common.Check;
import lab.common.Db;
import lab.flash.reserve.Inventory;

/** 第 29 章全部用例。每个用例从空 schema 开始；SKU 固定为 sku-lab-01，金额为模拟积分 1990。 */
public final class Ch29Main {
    static final String SKU = "sku-lab-01";
    static final int AMOUNT = 1990;
    static final Duration TIMEOUT = Duration.ofMillis(300);

    static FakeChannel channel;
    static Fulfillment consumer;
    static OrderServer server;
    static OrderService svc;
    static Recovery recovery;

    public static void main(String[] args) throws Exception {
        Db.recreate(System.getenv().getOrDefault("LAB_DB", "flash29"));
        channel = new FakeChannel();
        consumer = new Fulfillment();
        svc = new OrderService(new ChannelClient(channel.baseUrl()), null, 60_000);
        server = new OrderServer(svc, TIMEOUT, 0);
        svc.notifyUrl(server.baseUrl() + "/callbacks/payment");
        recovery = new Recovery(svc, TIMEOUT);
        try {
            normalPath();
            rejections();
            payCancelRace();
            timeoutButCharged();
            lateRequestClosed();
            duplicateAndReorderedCallbacks();
            expiryCompensation();
            expiryRaceConcurrent();
            outboxRelay();
            crashAfterCharge();
            crashBeforeCommit();
            crashRelay();
            mixedScenario();
            negTimeoutIsFailure();
            negNotFoundIsFailure();
            negBlindCallback();
            negConfirmIgnored();
            negConsumerNoDedup();
            negDualWrite();
        } finally {
            server.close();
            consumer.close();
            channel.close();
        }
        System.exit(Check.finish());
    }

    // ---------------- helpers ----------------

    static void reset(int total) throws SQLException {
        channel.reset();
        consumer.dedup = true;
        try (Connection c = Db.connect()) {
            Db.exec(c, "DROP SCHEMA IF EXISTS public CASCADE; CREATE SCHEMA public;");
            Db.exec(c, Inventory.SCHEMA);
            Db.exec(c, OrderService.SCHEMA);
            Db.exec(c, Fulfillment.SCHEMA);
            Inventory.addSku(c, SKU, total);
        }
    }

    static String user(int i) { return String.format("user-%04d", i); }

    static String order(Connection c, int userNo) throws SQLException {
        OrderService.Created r = svc.create(c, "req-" + user(userNo), user(userNo), SKU, AMOUNT);
        if (!r.outcome().equals("CREATED")) throw new IllegalStateException("create " + userNo + " -> " + r);
        return r.orderId();
    }

    /** 让订单当前预留到期（可控时钟：把 expires_at 改到过去），再运行第 28 章的到期释放。 */
    static int ageAndExpire(Connection c, List<String> ids) throws SQLException {
        Db.update(c, "UPDATE reservation SET expires_at = now() - interval '1 second' WHERE request_key IN "
            + "(SELECT reservation_key FROM orders WHERE order_id = ANY (?))", c.createArrayOf("text", ids.toArray()));
        return expireRetrying(c);
    }

    static int expireRetrying(Connection c) throws SQLException {
        while (true) {
            try {
                return Inventory.expire(c, null);
            } catch (SQLException e) {
                if (!Db.retryable(e)) throw e;
            }
        }
    }

    static int deliverUntilOk(FakeChannel.Notice n) throws InterruptedException {
        for (int i = 0; i < 50; i++) {
            int code = channel.deliver(n);
            if (code == 200) return code;
            Thread.sleep(50);
        }
        return -1;
    }

    static List<String> effects(Connection c, String id) throws SQLException {
        List<String> out = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement("SELECT kind || ':' || effect FROM payment_notification WHERE order_id = ? ORDER BY id")) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) out.add(rs.getString(1)); }
        }
        return out;
    }

    static void timeline(Connection c, String id) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT from_status, to_status, version, cause FROM order_transition WHERE order_id = ? ORDER BY id")) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                StringBuilder b = new StringBuilder("timeline " + id + ":");
                while (rs.next()) b.append(" [").append(rs.getString(1)).append("->").append(rs.getString(2))
                    .append(" v").append(rs.getInt(3)).append(" ").append(rs.getString(4)).append("]");
                Check.note(b.toString());
            }
        }
    }

    static Reconcile.Report reconcile(Connection c) throws Exception {
        Reconcile.Report r = Reconcile.run(c, svc.channel().statement(), SKU);
        Check.note("reconcile " + r.summary());
        for (String m : r.mismatches()) Check.note("  mismatch " + m);
        return r;
    }

    static String resvStatus(Connection c, String id) throws SQLException {
        return Db.queryString(c, "SELECT r.status FROM orders o JOIN reservation r ON r.request_key = o.reservation_key WHERE o.order_id = ?", id);
    }

    static long count(Connection c, String sql, Object... args) throws SQLException { return Db.queryLong(c, sql, args); }

    static Map<String, Long> group(Connection c, String sql) throws SQLException {
        Map<String, Long> m = new TreeMap<>();
        try (PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) m.put(rs.getString(1), rs.getLong(2));
        }
        return m;
    }

    interface Body { void run(int i, Connection c) throws Exception; }

    static void concurrently(int n, Body body) throws Exception {
        CountDownLatch ready = new CountDownLatch(n), go = new CountDownLatch(1), done = new CountDownLatch(n);
        AtomicReference<Throwable> err = new AtomicReference<>();
        for (int i = 0; i < n; i++) {
            final int id = i;
            Thread t = new Thread(() -> {
                try (Connection c = Db.connect()) {
                    ready.countDown();
                    go.await();
                    body.run(id, c);
                } catch (Throwable e) {
                    err.compareAndSet(null, e);
                } finally {
                    done.countDown();
                }
            });
            t.start();
        }
        ready.await();
        go.countDown();
        done.await();
        if (err.get() != null) throw new RuntimeException(err.get());
    }

    static void waitFor(String what, long ms, Check0 cond) throws Exception {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) {
            if (cond.ok()) return;
            Thread.sleep(25);
        }
        throw new IllegalStateException("timeout waiting for " + what);
    }

    interface Check0 { boolean ok() throws Exception; }

    // ---------------- 多进程 ----------------

    static Process startWorker(String mode, String orderId) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(
            System.getProperty("java.home") + "/bin/java", "-cp", System.getProperty("java.class.path"),
            "lab.flash.order.OrderWorker", mode, channel.baseUrl(), consumer.url(), orderId, server.baseUrl() + "/callbacks/payment");
        pb.redirectErrorStream(true);
        return pb.start();
    }

    static String awaitStage(Process p) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
        String line;
        while ((line = r.readLine()) != null) {
            Check.note("worker pid=" + p.pid() + " says: " + line);
            if (line.startsWith("STAGE")) return line;
        }
        return null;
    }

    static int kill9(Process p) throws Exception {
        new ProcessBuilder("kill", "-9", Long.toString(p.pid())).inheritIO().start().waitFor();
        return p.waitFor();
    }

    static void awaitWorkerGone(Connection c) throws Exception {
        waitFor("worker backend gone", 10_000,
            () -> count(c, "SELECT count(*) FROM pg_stat_activity WHERE application_name = 'b3-29-worker'") == 0);
    }

    // ---------------- 用例 ----------------

    static void normalPath() throws Exception {
        Check.begin("C29-01", "正常路径：HTTP 下单、重放、支付成功、重复回调、拒付归还库存、outbox 投递、对账");
        reset(5);
        channel.setDefault(FakeChannel.Fault.none().withCallbacks(2, 50));      // 每个回调发两份
        String base = server.baseUrl();
        Map<String, Object> f = Map.of("request_key", "req-0001", "user", user(42), "sku", SKU, "amount", AMOUNT);
        Http.Resp r1 = Http.post(base + "/orders", f, Duration.ofSeconds(5));
        Http.Resp r2 = Http.post(base + "/orders", f, Duration.ofSeconds(5));
        Check.note("POST /orders -> " + r1.code() + " " + r1.raw() + " ; replay -> " + r2.code() + " " + r2.raw());
        Check.equal(201, r1.code(), "首次下单 201");
        Check.equal("REPLAY", r2.get("outcome"), "同 request_key 重放");
        Check.equal(r1.get("order_id"), r2.get("order_id"), "重放返回同一订单");
        String id = r1.get("order_id");
        Http.Resp p = Http.post(base + "/orders/" + id + "/pay", Map.of(), Duration.ofSeconds(5));
        Check.note("POST /orders/" + id + "/pay -> " + p.code() + " " + p.raw());
        Check.equal("PAID", p.get("status"), "同步应答 CHARGED 后订单 PAID");
        try (Connection c = Db.connect()) {
            waitFor("2 callbacks", 5_000, () -> count(c, "SELECT count(*) FROM payment_notification WHERE order_id = ?", id) == 2);
            Check.note("callbacks " + effects(c, id));
            Check.equal(List.of("CHARGED:DUPLICATE PAID", "CHARGED:DUPLICATE PAID"), effects(c, id), "两份回调都判定为重复");
            Check.equal("CONFIRMED", resvStatus(c, id), "预留已确认");
            String id2 = order(c, 43);
            channel.fault(id2, FakeChannel.Fault.none().withDecline());
            Check.equal("FAILED", svc.pay(c, id2, TIMEOUT), "渠道拒付 → FAILED");
            Check.equal("RELEASED", resvStatus(c, id2), "拒付后预留归还");
            Check.equal(4L, Inventory.available(c, SKU), "库存 5 - 已确认 1 = 4");
            int sent = Relay.drain(c, consumer.url());
            Check.equal(2, sent, "outbox 两条终态事件投递");
            Check.equal("ORDER_PAID", Db.queryString(c, "SELECT state FROM fulfillment WHERE order_id = ?", id), "消费者收到 PAID");
            Check.equal(1L, count(c, "SELECT ship_count FROM fulfillment WHERE order_id = ?", id), "发货一次");
            timeline(c, id);
            Reconcile.Report rep = reconcile(c);
            Check.that(rep.clean(), "对账无差异");
            Check.equal((long) AMOUNT, rep.channelNet(), "渠道净额 = PAID 金额");
        }
    }

    static void rejections() throws Exception {
        Check.begin("C29-02", "状态机拒绝路径：重复支付、非法取消、键复用、限购、金额不符、未知订单、售罄不落库");
        reset(3);
        channel.setDefault(FakeChannel.Fault.held());
        try (Connection c = Db.connect()) {
            String o1 = order(c, 42);
            Check.equal("KEY_REUSED", svc.create(c, "req-" + user(42), user(43), SKU, AMOUNT).outcome(), "同键不同用户 → KEY_REUSED");
            Check.equal("USER_LIMIT", svc.create(c, "req-other", user(42), SKU, AMOUNT).outcome(), "同用户第二单 → USER_LIMIT");
            Map<String, Long> outcomes = new ConcurrentHashMap<>();
            concurrently(8, (i, cc) -> outcomes.merge(svc.pay(cc, o1, TIMEOUT), 1L, Long::sum));
            Check.note("8 concurrent pay -> " + new TreeMap<>(outcomes));
            Check.equal(1L, outcomes.getOrDefault("PAID", 0L), "并发支付只有一个进入渠道并成功");
            Check.equal(1, channel.chargeRequests.get(), "渠道只收到一次扣款请求");
            Check.that(svc.pay(c, o1, TIMEOUT).equals("REJECTED PAID"), "PAID 再支付被拒绝");
            Check.equal("REJECTED PAID", svc.cancel(c, o1, "user"), "PAID 不能取消");
            String o2 = order(c, 44);
            Check.equal("CANCELLED", svc.cancel(c, o2, "user"), "CREATED 可取消");
            Check.equal("RELEASED", resvStatus(c, o2), "取消归还预留");
            Check.equal("REJECTED CANCELLED", svc.pay(c, o2, TIMEOUT), "CANCELLED 不能支付");
            Check.equal("REJECTED CANCELLED", svc.cancel(c, o2, "user"), "重复取消被拒绝");
            String o3 = order(c, 45);
            int code = channel.deliver(new FakeChannel.Notice("ntf-x1", o3, "CHARGED", 1, "txn-x", server.baseUrl() + "/callbacks/payment"));
            Check.equal(200, code, "回调已应答");
            Check.equal(List.of("CHARGED:AMOUNT_MISMATCH"), effects(c, o3), "金额不符的成功通知不改变状态");
            Check.equal("CREATED", OrderService.status(c, o3), "订单仍为 CREATED");
            channel.deliver(new FakeChannel.Notice("ntf-x2", "ord-9999", "CHARGED", AMOUNT, "txn-y", server.baseUrl() + "/callbacks/payment"));
            Check.equal(List.of("CHARGED:UNKNOWN_ORDER"), effects(c, "ord-9999"), "未知订单的通知只记录");
            String o4 = order(c, 46);
            Check.equal(0L, Inventory.available(c, SKU), "库存 3 已被 o1 确认、o3/o4 占用");
            Check.equal("SOLD_OUT", svc.create(c, "req-" + user(47), user(47), SKU, AMOUNT).outcome(), "售罄");
            Check.equal(0L, count(c, "SELECT count(*) FROM orders WHERE user_id = ?", user(47)), "售罄不留订单行");
            Check.note("orders " + group(c, "SELECT status, count(*) FROM orders GROUP BY 1") + " o4=" + o4);
            Check.equal(0L, Inventory.drift(c, SKU), "守恒");
        }
    }

    static void payCancelRace() throws Exception {
        Check.begin("C29-03", "边界：同一订单上支付与取消并发（10 单，各一对线程）");
        reset(10);
        channel.setDefault(FakeChannel.Fault.held());
        List<String> ids = new ArrayList<>();
        try (Connection c = Db.connect()) { for (int i = 0; i < 10; i++) ids.add(order(c, 100 + i)); }
        concurrently(20, (i, c) -> {
            String id = ids.get(i / 2);
            if (i % 2 == 0) svc.pay(c, id, TIMEOUT); else svc.cancel(c, id, "user");
        });
        try (Connection c = Db.connect()) {
            Map<String, Long> st = group(c, "SELECT status, count(*) FROM orders GROUP BY 1");
            Check.note("final " + st + " charge_requests=" + channel.chargeRequests.get());
            boolean ok = true;
            for (String id : ids) {
                String s = OrderService.status(c, id), ch = channel.statusOf(id);
                ok &= (s.equals("PAID") && ch.equals("CHARGED")) || (s.equals("CANCELLED") && ch.equals("NOT_FOUND"));
            }
            Check.that(ok, "每单要么 PAID 且渠道已扣款，要么 CANCELLED 且渠道无记录");
            Check.equal(st.getOrDefault("PAID", 0L), (long) channel.chargeRequests.get(), "扣款请求数 = PAID 数");
            Check.that(reconcile(c).clean(), "对账无差异");
        }
    }

    static void timeoutButCharged() throws Exception {
        Check.begin("C29-04", "超时：渠道已扣款但应答丢失 → UNKNOWN，保留预留，查询后收敛为 PAID");
        reset(2);
        try (Connection c = Db.connect()) {
            String id = order(c, 42);
            channel.fault(id, FakeChannel.Fault.held().withResponseDelay(1200));
            String st = svc.pay(c, id, TIMEOUT);
            Check.equal("UNKNOWN", st, "客户端 300ms 超时 → UNKNOWN");
            Check.equal("CHARGED", channel.statusOf(id), "渠道侧已经扣款");
            Check.equal("HELD", resvStatus(c, id), "UNKNOWN 不归还库存");
            Reconcile.Report before = reconcile(c);
            Check.that(before.clean() && before.pending().size() == 1, "收敛前：无差异、1 单待收敛");
            Map<String, Integer> res = recovery.resolveOnce(c, 5_000);
            Check.note("resolve -> " + res);
            Check.equal("PAID", OrderService.status(c, id), "查询 CHARGED → PAID");
            Check.equal("CONFIRMED", resvStatus(c, id), "预留确认");
            for (FakeChannel.Notice n : channel.takeHeld(id)) deliverUntilOk(n);
            Check.equal(List.of("CHARGED:DUPLICATE PAID"), effects(c, id), "迟到的回调判定为重复");
            timeline(c, id);
            Check.that(reconcile(c).clean(), "对账无差异");
        }
    }

    static void lateRequestClosed() throws Exception {
        Check.begin("C29-05", "超时：请求滞留未到渠道 → 查询 NOT_FOUND → 关单 → FAILED；迟到的扣款被渠道拒绝");
        reset(2);
        try (Connection c = Db.connect()) {
            String id = order(c, 42);
            channel.fault(id, FakeChannel.Fault.held().withRequestDelay(1500));
            Check.equal("UNKNOWN", svc.pay(c, id, TIMEOUT), "超时 → UNKNOWN");
            Check.equal("NOT_FOUND", channel.statusOf(id), "此刻渠道没有记录");
            Map<String, Integer> res = recovery.resolveOnce(c, 5_000);
            Check.note("resolve -> " + res);
            Check.equal("FAILED", OrderService.status(c, id), "关单结果 CLOSED → FAILED");
            Check.equal(2L, Inventory.available(c, SKU), "库存归还");
            waitFor("late request processed", 5_000, () -> channel.chargeRequests.get() == 1);
            Thread.sleep(50);
            Check.equal("CLOSED", channel.statusOf(id), "迟到的扣款请求遇到 CLOSED，未扣款");
            Http.Resp again = new ChannelClient(channel.baseUrl()).charge(id, 42, "", java.time.Duration.ofSeconds(5));
            Check.equal("CLOSED", again.get("result"), "关单后同号再扣款，渠道应答 result=CLOSED");
            Check.equal(0, channel.statementLines().size(), "渠道账本无扣款行");
            timeline(c, id);
            Check.that(reconcile(c).clean(), "对账无差异");
        }
    }

    static void duplicateAndReorderedCallbacks() throws Exception {
        Check.begin("C29-06", "回调：16 份重复并发到达；退款通知先于扣款通知到达（乱序）");
        reset(2);
        try (Connection c = Db.connect()) {
            String id = order(c, 42);
            channel.fault(id, FakeChannel.Fault.held().withResponseDelay(800));
            Check.equal("UNKNOWN", svc.pay(c, id, TIMEOUT), "UNKNOWN");
            FakeChannel.Notice n = channel.takeHeld(id).get(0);
            Map<Integer, Long> codes = new ConcurrentHashMap<>();
            concurrently(16, (i, cc) -> codes.merge(deliverUntilOk(n), 1L, Long::sum));
            Map<String, Long> eff = group(c, "SELECT effect, count(*) FROM payment_notification WHERE order_id = '" + id + "' GROUP BY 1");
            Check.note("16 duplicate callbacks -> http " + codes + " effects " + eff);
            Check.equal(1L, eff.getOrDefault("PAID", 0L), "只有一份造成迁移");
            Check.equal(15L, eff.getOrDefault("DUPLICATE PAID", 0L), "其余 15 份为重复");
            Check.equal(1L, count(c, "SELECT count(*) FROM outbox WHERE order_id = ?", id), "outbox 只有一条 ORDER_PAID");
            Check.equal(1L, count(c, "SELECT count(*) FROM order_transition WHERE order_id = ? AND to_status = 'PAID'", id), "只迁移一次");

            String id2 = order(c, 43);
            channel.fault(id2, FakeChannel.Fault.held().withResponseDelay(800));
            Check.equal("UNKNOWN", svc.pay(c, id2, TIMEOUT), "第二单 UNKNOWN");
            Check.equal(1, ageAndExpire(c, List.of(id2)), "第二单预留到期被释放");
            order(c, 44);                                            // 释放出的名额被别人占走
            Map<String, Integer> res = recovery.resolveOnce(c, 5_000);
            Check.note("resolve -> " + res);
            Check.equal("REFUNDED", OrderService.status(c, id2), "钱到了但名额没了 → 退款 → REFUNDED");
            List<FakeChannel.Notice> held = channel.takeHeld(id2);
            Check.note("held notices " + held.stream().map(FakeChannel.Notice::kind).toList() + "，倒序发送");
            Collections.reverse(held);
            for (FakeChannel.Notice h : held) deliverUntilOk(h);
            Check.equal(List.of("REFUNDED:IGNORED REFUNDED", "CHARGED:DUPLICATE REFUNDED"), effects(c, id2), "乱序回调不改变终态");
            Check.equal("REFUNDED", OrderService.status(c, id2), "仍为 REFUNDED");
            timeline(c, id2);
            Check.that(reconcile(c).clean(), "对账无差异");
        }
    }

    static void expiryCompensation() throws Exception {
        Check.begin("C29-07", "预留到期后才得知支付成功：A 重新占用成功；B 占不到 → 退款，首次退款应答超时后同键重试");
        reset(2);
        try (Connection c = Db.connect()) {
            String a = order(c, 61), b = order(c, 62);
            channel.fault(a, FakeChannel.Fault.held().withResponseDelay(800));
            channel.fault(b, FakeChannel.Fault.held().withResponseDelay(800).withRefundDelay(800));
            Check.equal("UNKNOWN", svc.pay(c, a, TIMEOUT), "A UNKNOWN");
            Check.equal("UNKNOWN", svc.pay(c, b, TIMEOUT), "B UNKNOWN");
            Check.equal(2, ageAndExpire(c, List.of(a, b)), "两条预留到期释放");
            String cOrder = order(c, 63);
            Check.equal(1L, Inventory.available(c, SKU), "C 占走 1 件，剩 1 件");
            deliverUntilOk(channel.takeHeld(a).get(0));
            Check.equal(List.of("CHARGED:PAID_REHELD"), effects(c, a), "A：重新占用并确认");
            Check.equal(a + "/r2", Db.queryString(c, "SELECT reservation_key FROM orders WHERE order_id = ?", a), "A 的当前预留换成 /r2");
            deliverUntilOk(channel.takeHeld(b).get(0));
            Check.equal(List.of("CHARGED:REFUNDING"), effects(c, b), "B：占不到，进入 REFUNDING");
            Check.equal("REFUNDING", OrderService.status(c, b), "退款应答超时，B 停在 REFUNDING");
            Check.equal("REFUNDED", channel.statusOf(b), "渠道侧其实已退款");
            Map<String, Integer> res = recovery.resolveOnce(c, 5_000);
            Check.note("resolve -> " + res);
            Check.equal("REFUNDED", OrderService.status(c, b), "同键重试 → REFUNDED");
            long refunds = channel.statementLines().stream().filter(l -> l.startsWith("REFUND " + b)).count();
            Check.equal(1L, refunds, "渠道账本只有一笔退款");
            for (FakeChannel.Notice n : channel.takeHeld(b)) deliverUntilOk(n);
            deliverUntilOk(new FakeChannel.Notice("ntf-late", b, "CHARGED", AMOUNT, "txn-late", server.baseUrl() + "/callbacks/payment"));
            Check.note("B effects " + effects(c, b));
            Check.equal("REFUNDED", OrderService.status(c, b), "迟到的成功通知不让 B 复活");
            Check.equal("CREATED", OrderService.status(c, cOrder), "C 未受影响");
            timeline(c, a);
            timeline(c, b);
            Reconcile.Report r = reconcile(c);
            Check.that(r.clean(), "对账无差异");
            Check.equal(0L, r.drift(), "库存守恒");
        }
    }

    static void expiryRaceConcurrent() throws Exception {
        Check.begin("C29-08", "并发：20 个成功回调、2 个到期释放任务、10 个新用户抢购同时进行");
        reset(20);
        List<String> ids = new ArrayList<>();
        List<FakeChannel.Notice> notices = new ArrayList<>();
        try (Connection c = Db.connect()) {
            for (int i = 0; i < 20; i++) {
                String id = order(c, 200 + i);
                ids.add(id);
                channel.fault(id, FakeChannel.Fault.held().withResponseDelay(400));
            }
        }
        concurrently(20, (i, c) -> svc.pay(c, ids.get(i), TIMEOUT));
        try (Connection c = Db.connect()) {
            Check.equal(20L, count(c, "SELECT count(*) FROM orders WHERE status = 'UNKNOWN'"), "20 单 UNKNOWN");
            Db.update(c, "UPDATE reservation SET expires_at = now() - interval '1 second'");
            for (String id : ids) notices.addAll(channel.takeHeld(id));
        }
        channel.setDefault(FakeChannel.Fault.none());
        Map<String, Long> newcomer = new ConcurrentHashMap<>();
        concurrently(32, (i, c) -> {
            if (i < 20) deliverUntilOk(notices.get(i));
            else if (i < 22) expireRetrying(c);
            else {
                OrderService.Created r = svc.create(c, "req-" + user(300 + i), user(300 + i), SKU, AMOUNT);
                newcomer.merge(r.outcome().equals("CREATED") ? svc.pay(c, r.orderId(), TIMEOUT) : r.outcome(), 1L, Long::sum);
            }
        });
        try (Connection c = Db.connect()) {
            for (int k = 0; k < 10 && Recovery.pending(c) > 0; k++) recovery.resolveOnce(c, 0);
            Map<String, Long> eff = group(c, "SELECT effect, count(*) FROM payment_notification WHERE order_id IN (SELECT order_id FROM orders WHERE user_id < 'user-0300') GROUP BY 1");
            Check.note("original 20 callback effects " + eff + " ; newcomers " + new TreeMap<>(newcomer));
            Check.note("orders " + group(c, "SELECT status, count(*) FROM orders GROUP BY 1"));
            long paid = count(c, "SELECT count(*) FROM orders WHERE status = 'PAID'");
            Check.that(paid <= 20, "PAID 数 " + paid + " 不超过库存 20");
            Check.equal(0L, Recovery.pending(c), "无待收敛订单");
            Reconcile.Report r = reconcile(c);
            Check.that(r.clean(), "对账无差异");
            Check.equal(r.paidSum(), r.channelNet(), "渠道净额 = PAID 金额之和");
        }
    }

    static void outboxRelay() throws Exception {
        Check.begin("C29-09", "Outbox：两个中继并发（SKIP LOCKED）投递 40 条；重复与旧版本直接投给消费者");
        reset(40);
        channel.setDefault(FakeChannel.Fault.held());
        try (Connection c = Db.connect()) {
            for (int i = 0; i < 40; i++) svc.pay(c, order(c, 400 + i), TIMEOUT);
            Check.equal(40L, Relay.unpublished(c), "40 条未发布事件");
        }
        Map<Integer, Integer> perRelay = new ConcurrentHashMap<>();
        concurrently(2, (i, c) -> {
            int n, total = 0;
            while ((n = Relay.relayOnce(c, consumer.url(), 5, Tx.NONE)) > 0) total += n;
            perRelay.put(i, total);
        });
        try (Connection c = Db.connect()) {
            Check.note("per relay sent " + perRelay);
            Check.equal(40, perRelay.values().stream().mapToInt(Integer::intValue).sum(), "两个中继合计发送 40 条");
            Check.equal(40L, count(c, "SELECT count(*) FROM ful_received"), "消费者收到 40 次");
            Check.equal(40L, count(c, "SELECT coalesce(sum(ship_count),0) FROM fulfillment"), "发货 40 次");
            Check.equal(0L, Relay.unpublished(c), "全部已发布");
            long ev = count(c, "SELECT event_id FROM outbox ORDER BY event_id LIMIT 1");
            String oid = Db.queryString(c, "SELECT order_id FROM outbox WHERE event_id = ?", ev);
            int v = (int) count(c, "SELECT order_version FROM outbox WHERE event_id = ?", ev);
            Http.Resp dup = Http.post(consumer.url(), Map.of("event_id", ev, "order_id", oid, "type", "ORDER_PAID", "version", v), Duration.ofSeconds(5));
            Http.Resp old = Http.post(consumer.url(), Map.of("event_id", 999001, "order_id", oid, "type", "ORDER_FAILED", "version", v - 1), Duration.ofSeconds(5));
            Check.note("redeliver -> " + dup.raw() + " ; older version -> " + old.raw());
            Check.equal("DUPLICATE", dup.get("effect"), "同一 event_id 再到达：DUPLICATE");
            Check.equal("STALE", old.get("effect"), "更旧版本的事件：STALE");
            Check.equal("ORDER_PAID", Db.queryString(c, "SELECT state FROM fulfillment WHERE order_id = ?", oid), "状态未被旧事件覆盖");
            Check.equal(1L, count(c, "SELECT ship_count FROM fulfillment WHERE order_id = ?", oid), "发货次数不变");
        }
    }

    static void crashAfterCharge() throws Exception {
        Check.begin("C29-10", "多进程：支付进程在渠道扣款成功、本地记账之前被 kill -9");
        reset(2);
        try (Connection c = Db.connect()) {
            String id = order(c, 42);
            channel.fault(id, FakeChannel.Fault.held());
            Process p = startWorker("pay-stall", id);
            String stage = awaitStage(p);
            Check.that(stage != null && stage.contains("pay-stall"), "子进程停在扣款之后");
            Check.equal(137, kill9(p), "子进程被 SIGKILL 终止");
            awaitWorkerGone(c);
            Check.equal("PAYING", OrderService.status(c, id), "订单停在 PAYING");
            Check.equal("CHARGED", channel.statusOf(id), "渠道已扣款");
            Map<String, Integer> notStale = recovery.resolveOnce(c, 60_000);
            Check.equal(Map.of(), notStale, "未超过陈旧阈值的 PAYING 不处理（可能仍在进行）");
            Map<String, Integer> res = recovery.resolveOnce(c, 0);
            Check.note("resolve(stale=0) -> " + res);
            Check.equal("PAID", OrderService.status(c, id), "查询收敛为 PAID");
            for (FakeChannel.Notice n : channel.takeHeld(id)) deliverUntilOk(n);
            Check.equal(List.of("CHARGED:DUPLICATE PAID"), effects(c, id), "进程崩溃前发出的回调后到，判定为重复");
            timeline(c, id);
            Check.that(reconcile(c).clean(), "对账无差异");
        }
    }

    static void crashBeforeCommit() throws Exception {
        Check.begin("C29-11", "多进程：成功通知的事务（确认预留 + PAID + outbox）提交前被 kill -9");
        reset(2);
        try (Connection c = Db.connect()) {
            String id = order(c, 42);
            channel.fault(id, FakeChannel.Fault.held().withResponseDelay(800));
            Check.equal("UNKNOWN", svc.pay(c, id, TIMEOUT), "UNKNOWN");
            Process p = startWorker("apply-stall", id);
            awaitStage(p);
            Check.equal("UNKNOWN", OrderService.status(c, id), "未提交：其他会话看到的仍是 UNKNOWN");
            Check.equal(137, kill9(p), "子进程被 SIGKILL 终止");
            awaitWorkerGone(c);
            Check.equal("UNKNOWN", OrderService.status(c, id), "回滚后仍是 UNKNOWN");
            Check.equal("HELD", resvStatus(c, id), "预留仍是 HELD");
            Check.equal(0L, count(c, "SELECT count(*) FROM outbox WHERE order_id = ?", id), "没有孤立的 outbox 事件");
            Map<String, Integer> res = recovery.resolveOnce(c, 0);
            Check.note("resolve -> " + res);
            Check.equal("PAID", OrderService.status(c, id), "恢复任务重做 → PAID");
            Check.equal(1L, count(c, "SELECT count(*) FROM outbox WHERE order_id = ?", id), "outbox 恰好一条");
            Check.that(reconcile(c).clean(), "对账无差异");
        }
    }

    static void crashRelay() throws Exception {
        Check.begin("C29-12", "多进程：中继投递完成、标记提交之前被 kill -9，重启后重投，消费者去重");
        reset(3);
        channel.setDefault(FakeChannel.Fault.held());
        try (Connection c = Db.connect()) {
            for (int i = 0; i < 3; i++) svc.pay(c, order(c, 42 + i), TIMEOUT);
            Process p = startWorker("relay-stall", "");
            awaitStage(p);
            Check.equal(3L, count(c, "SELECT count(*) FROM ful_received"), "消费者已收到 3 条");
            Check.equal(137, kill9(p), "子进程被 SIGKILL 终止");
            awaitWorkerGone(c);
            Check.equal(3L, Relay.unpublished(c), "标记随事务回滚，3 条仍未发布");
            Check.equal(3, Relay.drain(c, consumer.url()), "重启后重投 3 条");
            Map<String, Long> eff = group(c, "SELECT effect, count(*) FROM ful_received GROUP BY 1");
            Check.note("consumer effects " + eff);
            Check.equal(3L, eff.getOrDefault("DUPLICATE", 0L), "重投的 3 条被判定为重复");
            Check.equal(3L, count(c, "SELECT sum(ship_count) FROM fulfillment"), "每单只发货一次");
        }
    }

    static void mixedScenario() throws Exception {
        Check.begin("C29-13", "混合场景（种子 29，36 个用户争 24 件）：拒付、应答丢失、请求滞留、不付款、到期竞争、重复与迟到回调、补抢，恢复后对账");
        reset(24);
        Random rnd = new Random(29);
        List<String> ids = new ArrayList<>();
        try (Connection c = Db.connect()) {
            for (int i = 0; i < 36; i++) {
                OrderService.Created r = svc.create(c, "req-" + user(500 + i), user(500 + i), SKU, AMOUNT);
                if (r.outcome().equals("CREATED")) ids.add(r.orderId());
            }
        }
        List<String> shuffled = new ArrayList<>(ids);
        Collections.shuffle(shuffled, rnd);
        Map<String, String> plan = new TreeMap<>();
        List<String> neverPay = new ArrayList<>(), racers = new ArrayList<>();
        for (int i = 0; i < shuffled.size(); i++) {
            String id = shuffled.get(i);
            FakeChannel.Fault f = FakeChannel.Fault.none().withCallbacks(1 + rnd.nextInt(3), rnd.nextInt(300));
            String kind;
            if (i < 3) { f = f.withDecline(); kind = "decline"; }
            else if (i < 7) { f = f.withResponseDelay(700); kind = "response-lost"; }
            else if (i < 10) { f = f.withRequestDelay(900); kind = "request-delayed"; }
            else if (i < 13) { kind = "never-pay"; neverPay.add(id); }
            else if (i < 17) { f = FakeChannel.Fault.held().withResponseDelay(700); kind = "expiry-race"; racers.add(id); }
            else if (i < 19) { f = FakeChannel.Fault.held().withResponseDelay(700).withRefundDelay(500); kind = "expiry-race+refund-timeout"; racers.add(id); }
            else kind = "normal";
            channel.fault(id, f);
            plan.merge(kind, id, (x, y) -> x + "," + y);
        }
        Check.note("created=" + ids.size() + " plan " + plan);
        List<String> toPay = new ArrayList<>(ids);
        toPay.removeAll(neverPay);
        concurrently(toPay.size(), (i, c) -> svc.pay(c, toPay.get(i), TIMEOUT));
        List<String> late = new ArrayList<>();
        try (Connection c = Db.connect()) {
            List<String> aged = new ArrayList<>(neverPay);
            aged.addAll(racers);
            int released = ageAndExpire(c, aged);
            int cancelled = recovery.cancelExpiredCreated(c);
            Check.note("after pay: " + group(c, "SELECT status, count(*) FROM orders GROUP BY 1") + " expired=" + released + " cancelled=" + cancelled);
        }
        // 之前售罄的 12 个用户换新键再来，与恢复任务并发
        concurrently(13, (i, c) -> {
            if (i == 12) {
                for (int k = 0; k < 3; k++) { recovery.resolveOnce(c, 2_000); Thread.sleep(200); }
                return;
            }
            OrderService.Created r = svc.create(c, "req2-" + user(524 + i), user(524 + i), SKU, AMOUNT);
            if (r.outcome().equals("CREATED")) { synchronized (late) { late.add(r.orderId()); } svc.pay(c, r.orderId(), TIMEOUT); }
        });
        Thread.sleep(1_200);                                    // 等滞留请求与延迟回调全部落地
        try (Connection c = Db.connect()) {
            for (String id : racers) for (FakeChannel.Notice n : channel.takeHeld(id)) deliverUntilOk(n);
            for (int k = 0; k < 10 && Recovery.pending(c) > 0; k++) { recovery.resolveOnce(c, 0); Thread.sleep(100); }
            for (String id : racers) for (FakeChannel.Notice n : channel.takeHeld(id)) { deliverUntilOk(n); deliverUntilOk(n); }
            Thread.sleep(600);
            Relay.drain(c, consumer.url());
            Check.note("late buyers " + late.size() + " ; final " + group(c, "SELECT status, count(*) FROM orders GROUP BY 1"));
            Check.note("notification effects " + group(c, "SELECT split_part(effect,' ',1), count(*) FROM payment_notification GROUP BY 1"));
            Check.note("consumer effects " + group(c, "SELECT effect, count(*) FROM ful_received GROUP BY 1"));
            Check.equal(0L, Recovery.pending(c), "无待收敛订单");
            Reconcile.Report r = reconcile(c);
            Check.that(r.clean(), "三方对账无差异");
            Check.equal(r.paidSum(), r.channelNet(), "渠道净额 = PAID 金额之和");
            Check.equal(r.paid(), count(c, "SELECT coalesce(sum(ship_count),0) FROM fulfillment"), "发货次数 = PAID 订单数");
            Check.equal(0L, count(c, "SELECT count(*) FROM fulfillment WHERE ship_count > 1"), "没有订单发货两次");
            Check.equal(0L, Relay.unpublished(c), "outbox 已全部发布");
        }
    }

    // ---------------- 负向对照 ----------------

    static void negTimeoutIsFailure() throws Exception {
        Check.begin("C29-14", "负向对照：扣款超时当作失败，立即归还库存");
        reset(1);
        try (Connection c = Db.connect()) {
            String id = order(c, 42);
            channel.fault(id, FakeChannel.Fault.held().withResponseDelay(800));
            Check.note("naive pay -> " + Negative.payTimeoutIsFailure(c, svc, id, TIMEOUT));
            String other = order(c, 43);
            channel.fault(other, FakeChannel.Fault.held());
            Check.note("另一用户买走归还的名额 -> " + svc.pay(c, other, TIMEOUT));
            Reconcile.Report r = reconcile(c);
            Check.exposes(r.mismatches().stream().anyMatch(m -> m.contains(id + " FAILED CHARGED_BUT_FAILED")),
                "用户已被扣款但订单 FAILED，名额已卖给别人");
        }
    }

    static void negNotFoundIsFailure() throws Exception {
        Check.begin("C29-15", "负向对照：查询 NOT_FOUND 即判定失败，不关单");
        reset(1);
        try (Connection c = Db.connect()) {
            String id = order(c, 42);
            channel.fault(id, FakeChannel.Fault.held().withRequestDelay(1200));
            Check.equal("UNKNOWN", svc.pay(c, id, TIMEOUT), "UNKNOWN");
            Check.note("naive resolve -> " + Negative.notFoundIsFailure(c, svc, id, TIMEOUT));
            waitFor("late request processed", 5_000, () -> channel.chargeRequests.get() == 1);
            Thread.sleep(50);
            Check.note("channel status after late request: " + channel.statusOf(id));
            Reconcile.Report r = reconcile(c);
            Check.exposes(r.mismatches().stream().anyMatch(m -> m.contains(id + " FAILED CHARGED_BUT_FAILED")),
                "迟到的扣款在 FAILED 之后成功");
        }
    }

    static void negBlindCallback() throws Exception {
        Check.begin("C29-16", "负向对照：成功回调不检查当前状态（REFUNDED 之后迟到的 CHARGED）");
        reset(1);
        try (Connection c = Db.connect()) {
            String id = order(c, 42);
            channel.fault(id, FakeChannel.Fault.held().withResponseDelay(800));
            svc.pay(c, id, TIMEOUT);
            ageAndExpire(c, List.of(id));
            order(c, 43);
            recovery.resolveOnce(c, 0);
            Check.equal("REFUNDED", OrderService.status(c, id), "按正确流程已 REFUNDED");
            Negative.blindPaidCallback(c, id);
            Check.note("after blind callback status=" + OrderService.status(c, id));
            Reconcile.Report r = reconcile(c);
            Check.exposes(r.mismatches().stream().anyMatch(m -> m.contains("PAID_BUT_REFUNDED")),
                "已退款的订单被迟到回调改回 PAID");
        }
    }

    static void negConfirmIgnored() throws Exception {
        Check.begin("C29-17", "负向对照：成功回调不看预留确认结果（预留已到期并被别人买走）");
        reset(10);
        List<String> ids = new ArrayList<>();
        try (Connection c = Db.connect()) {
            for (int i = 0; i < 10; i++) {
                String id = order(c, 600 + i);
                ids.add(id);
                channel.fault(id, FakeChannel.Fault.held().withResponseDelay(400));
            }
        }
        concurrently(10, (i, c) -> svc.pay(c, ids.get(i), TIMEOUT));
        try (Connection c = Db.connect()) {
            Check.equal(10, ageAndExpire(c, ids), "10 条预留到期释放");
            channel.setDefault(FakeChannel.Fault.held());
            for (int i = 0; i < 10; i++) svc.pay(c, order(c, 700 + i), TIMEOUT);
            for (String id : ids) Negative.confirmIgnoringResult(c, id);
            long paid = count(c, "SELECT count(*) FROM orders WHERE status = 'PAID'");
            Check.note("PAID orders=" + paid + " total stock=10 confirmed=" + count(c, "SELECT count(*) FROM reservation WHERE status = 'CONFIRMED'"));
            Reconcile.Report r = reconcile(c);
            Check.exposes(paid > 10 && r.mismatches().stream().anyMatch(m -> m.contains("PAID_WITHOUT_CONFIRMED_RESERVATION")),
                "PAID 订单 " + paid + " 超过库存 10（超卖）");
        }
    }

    static void negConsumerNoDedup() throws Exception {
        Check.begin("C29-18", "负向对照（多进程）：消费者不去重，中继崩溃重投后重复发货");
        reset(3);
        channel.setDefault(FakeChannel.Fault.held());
        consumer.dedup = false;
        try (Connection c = Db.connect()) {
            for (int i = 0; i < 3; i++) svc.pay(c, order(c, 42 + i), TIMEOUT);
            Process p = startWorker("relay-stall", "");
            awaitStage(p);
            Check.equal(137, kill9(p), "子进程被 SIGKILL 终止");
            awaitWorkerGone(c);
            Relay.drain(c, consumer.url());
            long ships = count(c, "SELECT sum(ship_count) FROM fulfillment");
            Check.note("3 PAID orders, shipments=" + ships);
            Check.exposes(ships == 6, "3 单发货 6 次");
        } finally {
            consumer.dedup = true;
        }
    }

    static void negDualWrite() throws Exception {
        Check.begin("C29-19", "负向对照（多进程）：先提交 PAID 再直接通知消费者（无 outbox），两步之间 kill -9");
        reset(2);
        try (Connection c = Db.connect()) {
            String id = order(c, 42);
            channel.fault(id, FakeChannel.Fault.held().withResponseDelay(800));
            Check.equal("UNKNOWN", svc.pay(c, id, TIMEOUT), "UNKNOWN（渠道已扣款）");
            Process p = startWorker("dualwrite-stall", id);
            awaitStage(p);
            Check.equal(137, kill9(p), "子进程被 SIGKILL 终止");
            awaitWorkerGone(c);
            Check.equal("PAID", OrderService.status(c, id), "订单已 PAID");
            Reconcile.Report r = reconcile(c);
            Check.that(r.clean(), "三方对账（渠道/订单/预留）看不出问题");
            int resent = Relay.drain(c, consumer.url());
            long ful = count(c, "SELECT count(*) FROM fulfillment WHERE order_id = ?", id);
            Check.note("relay resent=" + resent + " fulfillment rows=" + ful);
            long orphanPaid = count(c, "SELECT count(*) FROM orders o WHERE o.status = 'PAID' AND NOT EXISTS "
                + "(SELECT 1 FROM outbox e WHERE e.order_id = o.order_id AND e.event_type = 'ORDER_PAID')");
            Check.note("PAID orders without ORDER_PAID outbox event: " + orphanPaid);
            Check.exposes(ful == 0 && resent == 0 && orphanPaid == 1, "已支付订单永远不会发货，也没有可重试的记录");
        }
    }
}
