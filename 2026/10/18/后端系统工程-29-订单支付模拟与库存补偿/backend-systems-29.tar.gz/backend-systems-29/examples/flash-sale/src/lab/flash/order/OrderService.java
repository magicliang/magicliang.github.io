package lab.flash.order;

import java.io.IOException;
import java.net.http.HttpTimeoutException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.util.Map;
import lab.common.Db;
import lab.flash.reserve.Inventory;

/**
 * 订单状态机（第 29 章）。库存层复用第 28 章的 lab.flash.reserve.Inventory，不改其公共方法。
 *
 * 状态与前置条件（每条迁移都是 UPDATE ... WHERE status = 前置状态，影响行数为 0 即拒绝；判断前先 SELECT ... FOR UPDATE）：
 *   CREATED  --pay-->      PAYING     先提交 PAYING，再调用渠道
 *   CREATED  --cancel/到期--> CANCELLED  同事务归还 HELD 预留
 *   PAYING   --超时/IO 错误--> UNKNOWN    不归还库存，等待查询收敛
 *   CREATED|PAYING|UNKNOWN --成功-->  PAID       同事务确认预留；预留已被到期释放则重新占用，占不到转 REFUNDING
 *   PAYING|UNKNOWN --拒付/关单--> FAILED   同事务归还 HELD 预留
 *   FAILED|CANCELLED --成功通知--> REFUNDING   异常补偿：钱到了但订单已终止
 *   REFUNDING --退款确认--> REFUNDED
 * 终态 PAID、FAILED、CANCELLED、REFUNDED 写一条 outbox 事件，与状态迁移同事务。
 */
public final class OrderService {

    public static final String SCHEMA = """
        CREATE SEQUENCE order_seq;
        CREATE TABLE orders (
          order_id        text PRIMARY KEY,
          request_key     text NOT NULL UNIQUE,
          user_id         text NOT NULL,
          sku             text NOT NULL,
          amount          int  NOT NULL CHECK (amount > 0),          -- 模拟积分
          status          text NOT NULL CHECK (status IN
                            ('CREATED','PAYING','UNKNOWN','PAID','FAILED','CANCELLED','REFUNDING','REFUNDED')),
          version         int  NOT NULL DEFAULT 1,
          reservation_key text NOT NULL,                              -- 当前占用的预留（reservation.request_key）
          reserve_attempt int  NOT NULL DEFAULT 1,
          channel_txn     text,
          refund_key      text,
          created_at      timestamptz NOT NULL DEFAULT now(),
          updated_at      timestamptz NOT NULL DEFAULT now()
        );
        CREATE TABLE order_transition (
          id         bigserial PRIMARY KEY,
          order_id   text NOT NULL REFERENCES orders,
          from_status text NOT NULL,
          to_status  text NOT NULL,
          version    int  NOT NULL,
          cause      text NOT NULL,
          at         timestamptz NOT NULL DEFAULT clock_timestamp()
        );
        CREATE TABLE payment_notification (
          id          bigserial PRIMARY KEY,
          notify_id   text NOT NULL,
          order_id    text NOT NULL,
          kind        text NOT NULL,
          amount      int  NOT NULL,
          effect      text NOT NULL,
          received_at timestamptz NOT NULL DEFAULT clock_timestamp()
        );
        CREATE TABLE outbox (
          event_id      bigserial PRIMARY KEY,
          order_id      text NOT NULL,
          event_type    text NOT NULL,
          order_version int  NOT NULL,
          payload       text NOT NULL,
          created_at    timestamptz NOT NULL DEFAULT now(),
          published_at  timestamptz
        );
        CREATE INDEX outbox_unpublished ON outbox (event_id) WHERE published_at IS NULL;
        """;

    public record Created(String outcome, String orderId, String status) {}
    public record Order(String id, String user, String sku, int amount, String status, int version,
                        String reservationKey, int attempt, String refundKey) {}

    private final ChannelClient channel;
    private volatile String notifyUrl;
    private final long ttlMillis;

    public OrderService(ChannelClient channel, String notifyUrl, long ttlMillis) {
        this.channel = channel;
        this.notifyUrl = notifyUrl;
        this.ttlMillis = ttlMillis;
    }

    public ChannelClient channel() { return channel; }
    public void notifyUrl(String url) { this.notifyUrl = url; }

    // ---------------- 下单 ----------------

    /** 同一事务：插入订单（按 request_key 幂等）+ 第 28 章的条件预留。预留不成功则整个事务回滚，不留订单。 */
    public Created create(Connection c, String requestKey, String user, String sku, int amount) throws SQLException {
        return Tx.run(c, () -> {
            String id = null;
            try (PreparedStatement ps = c.prepareStatement("""
                    WITH g AS (SELECT 'ord-' || lpad(nextval('order_seq')::text, 4, '0') AS oid)
                    INSERT INTO orders (order_id, request_key, user_id, sku, amount, status, reservation_key)
                    SELECT oid, ?, ?, ?, ?, 'CREATED', oid || '/r1' FROM g
                    ON CONFLICT (request_key) DO NOTHING RETURNING order_id""")) {
                ps.setString(1, requestKey); ps.setString(2, user); ps.setString(3, sku); ps.setInt(4, amount);
                try (ResultSet rs = ps.executeQuery()) { if (rs.next()) id = rs.getString(1); }
            }
            if (id == null) {
                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT order_id, user_id, sku, amount, status FROM orders WHERE request_key = ?")) {
                    ps.setString(1, requestKey);
                    try (ResultSet rs = ps.executeQuery()) {
                        rs.next();
                        boolean same = rs.getString(2).equals(user) && rs.getString(3).equals(sku) && rs.getInt(4) == amount;
                        return same ? new Created("REPLAY", rs.getString(1), rs.getString(5)) : new Created("KEY_REUSED", null, null);
                    }
                }
            }
            Inventory.Hold h = Inventory.reserveInTx(c, id + "/r1", user, sku, ttlMillis);
            if (!h.outcome().equals("HELD")) {
                c.rollback();                       // 订单行一并撤销
                return new Created(h.outcome(), null, null);
            }
            Db.update(c, "INSERT INTO order_transition (order_id, from_status, to_status, version, cause) VALUES (?, '-', 'CREATED', 1, 'create')", id);
            return new Created("CREATED", id, "CREATED");
        });
    }

    // ---------------- 支付 ----------------

    /** CREATED → PAYING。返回订单金额；前置条件不满足返回 -1。单独提交，保证渠道调用之前状态已落库。 */
    public int beginPay(Connection c, String id) throws SQLException {
        return Tx.run(c, () -> transition(c, id, "CREATED", "PAYING", "pay") ? (int) Db.queryLong(c, "SELECT amount FROM orders WHERE order_id = ?", id) : -1);
    }

    /** 完整支付：先提交 PAYING，再按商户订单号扣款；超时只能记为 UNKNOWN，不能当作失败。 */
    public String pay(Connection c, String id, Duration timeout) throws Exception {
        int amount = beginPay(c, id);
        if (amount < 0) return "REJECTED " + status(c, id);
        Http.Resp r;
        try {
            r = channel.charge(id, amount, notifyUrl, timeout);
        } catch (HttpTimeoutException e) {
            markUnknown(c, id, "charge timeout");
            return status(c, id);
        } catch (IOException e) {
            markUnknown(c, id, "charge io error");
            return status(c, id);
        }
        applyChannelResult(c, id, r.get("result"), amount, r.get("txn"), "charge reply", timeout);
        return status(c, id);
    }

    /** 把渠道给出的确定结果（来自同步应答、查询或关单）落到状态机上。 */
    void applyChannelResult(Connection c, String id, String result, int amount, String txn, String cause, Duration timeout) throws Exception {
        switch (result == null ? "" : result) {
            case "CHARGED" -> {
                if (onCharged(c, id, amount, txn, cause, Tx.NONE).startsWith("REFUNDING")) refund(c, id, timeout);
            }
            case "DECLINED", "CLOSED" -> onClosed(c, id, cause + " " + result);
            case "REFUNDED" -> onRefunded(c, id, cause + " REFUNDED");   // 订单应处在 REFUNDING
            default -> markUnknown(c, id, cause + " " + result);
        }
    }

    public boolean markUnknown(Connection c, String id, String cause) throws SQLException {
        return Tx.run(c, () -> transition(c, id, "PAYING", "UNKNOWN", cause));
    }

    /** 成功通知（回调、同步应答或查询结果）。effect 记录这次通知造成的变化。 */
    public String onCharged(Connection c, String id, int amount, String txn, String cause, Tx.Hook beforeCommit) throws Exception {
        return Tx.run(c, () -> {
            String e = onChargedInTx(c, id, amount, txn, cause);
            beforeCommit.run();
            return e;
        });
    }

    String onChargedInTx(Connection c, String id, int amount, String txn, String cause) throws SQLException {
        Order o = lock(c, id);
        if (o == null) return "UNKNOWN_ORDER";
        if (o.amount() != amount) return "AMOUNT_MISMATCH";
        switch (o.status()) {
            case "PAID", "REFUNDING", "REFUNDED" -> { return "DUPLICATE " + o.status(); }
            case "FAILED", "CANCELLED" -> {
                // 钱到了但订单已终止：只能退款补偿
                startRefund(c, o, txn, cause + " after " + o.status());
                return "REFUNDING_ANOMALY";
            }
            default -> { }                                  // CREATED / PAYING / UNKNOWN
        }
        Db.update(c, "UPDATE orders SET channel_txn = ? WHERE order_id = ?", txn, id);
        // 1) 原预留仍是 HELD（到期释放任务还没处理它）：直接确认
        if (Inventory.confirmHeldInTx(c, o.reservationKey())) {
            transition(c, id, o.status(), "PAID", cause);
            return "PAID";
        }
        // 2) 原预留已被释放：按规则重新占用一次，占到即确认
        int attempt = o.attempt() + 1;
        String key = id + "/r" + attempt;
        Inventory.Hold h = Inventory.reserveInTx(c, key, o.user(), o.sku(), ttlMillis);
        if (h.outcome().equals("HELD") && Inventory.confirmHeldInTx(c, key)) {
            Db.update(c, "UPDATE orders SET reservation_key = ?, reserve_attempt = ? WHERE order_id = ?", key, attempt, id);
            transition(c, id, o.status(), "PAID", cause + " re-reserved " + key);
            return "PAID_REHELD";
        }
        // 3) 占不到：退款补偿
        startRefund(c, o, txn, cause + " stock lost (" + h.outcome() + ")");
        return "REFUNDING";
    }

    private void startRefund(Connection c, Order o, String txn, String cause) throws SQLException {
        Db.update(c, "UPDATE orders SET refund_key = 'rf-' || order_id, channel_txn = coalesce(channel_txn, ?) WHERE order_id = ?", txn, o.id());
        transition(c, o.id(), o.status(), "REFUNDING", cause);
    }

    /** 拒付或关单：PAYING/UNKNOWN → FAILED，同事务归还 HELD 预留（已被到期释放则归还 0）。 */
    public String onClosed(Connection c, String id, String cause) throws SQLException {
        return Tx.run(c, () -> onClosedInTx(c, id, cause));
    }

    String onClosedInTx(Connection c, String id, String cause) throws SQLException {
        Order o = lock(c, id);
        if (o == null) return "UNKNOWN_ORDER";
        if (!o.status().equals("PAYING") && !o.status().equals("UNKNOWN")) return "IGNORED " + o.status();
        transition(c, id, o.status(), "FAILED", cause);
        Inventory.releaseInTx(c, o.reservationKey());
        return "FAILED";
    }

    public String onRefunded(Connection c, String id, String cause) throws SQLException {
        return Tx.run(c, () -> onRefundedInTx(c, id, cause));
    }

    String onRefundedInTx(Connection c, String id, String cause) throws SQLException {
        Order o = lock(c, id);
        if (o == null) return "UNKNOWN_ORDER";
        if (!o.status().equals("REFUNDING")) return "IGNORED " + o.status();
        transition(c, id, "REFUNDING", "REFUNDED", cause);
        return "REFUNDED";
    }

    /** REFUNDING 订单向渠道发起退款，refund_key 固定为 rf-<order_id>，重试即重放。 */
    public String refund(Connection c, String id, Duration timeout) throws Exception {
        Order o = find(c, id);
        if (o == null || !o.status().equals("REFUNDING")) return o == null ? "UNKNOWN_ORDER" : o.status();
        Http.Resp r;
        try {
            r = channel.refund(id, o.refundKey(), o.amount(), timeout);
        } catch (IOException e) {
            return "REFUNDING";                                  // 结果未知，留给恢复任务按同键重试
        }
        if ("REFUNDED".equals(r.get("result"))) return onRefunded(c, id, "refund reply");
        return "REFUNDING";
    }

    /** 用户取消：只允许 CREATED。 */
    public String cancel(Connection c, String id, String cause) throws SQLException {
        return Tx.run(c, () -> {
            Order o = lock(c, id);
            if (o == null) return "UNKNOWN_ORDER";
            if (!transition(c, id, "CREATED", "CANCELLED", cause)) return "REJECTED " + o.status();
            Inventory.releaseInTx(c, o.reservationKey());
            return "CANCELLED";
        });
    }

    /** 回调入口：记录每一次通知及其效果，与状态迁移同事务。 */
    public String onNotice(Connection c, Map<String, String> f, Duration timeout) throws Exception {
        String id = f.get("merchant_order"), kind = f.get("kind");
        int amount = Integer.parseInt(f.get("amount"));
        String effect = Tx.run(c, () -> {
            String e = switch (kind) {
                case "CHARGED" -> onChargedInTx(c, id, amount, f.get("txn"), "callback " + f.get("notify_id"));
                case "DECLINED" -> onClosedInTx(c, id, "callback " + f.get("notify_id") + " DECLINED");
                case "REFUNDED" -> onRefundedInTx(c, id, "callback " + f.get("notify_id"));
                default -> "UNKNOWN_KIND";
            };
            Db.update(c, "INSERT INTO payment_notification (notify_id, order_id, kind, amount, effect) VALUES (?,?,?,?,?)",
                f.get("notify_id"), id, kind, amount, e);
            return e;
        });
        if (effect.startsWith("REFUNDING")) refund(c, id, timeout);
        return effect;
    }

    // ---------------- 公共辅助 ----------------

    /**
     * 条件迁移：WHERE status = from。成功时版本号加一、写迁移记录；目标为终态时写 outbox 事件。
     * 三者在调用方事务内，要么一起提交，要么一起回滚。
     */
    static boolean transition(Connection c, String id, String from, String to, String cause) throws SQLException {
        Integer v = null;
        try (PreparedStatement ps = c.prepareStatement(
                "UPDATE orders SET status = ?, version = version + 1, updated_at = now() "
              + "WHERE order_id = ? AND status = ? RETURNING version, user_id, sku, amount")) {
            ps.setString(1, to); ps.setString(2, id); ps.setString(3, from);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return false;
                v = rs.getInt(1);
                if (TERMINAL.contains(to)) {
                    String payload = "order_id=" + id + "&status=" + to + "&version=" + v
                        + "&user=" + rs.getString(2) + "&sku=" + rs.getString(3) + "&amount=" + rs.getInt(4);
                    Db.update(c, "INSERT INTO outbox (order_id, event_type, order_version, payload) VALUES (?,?,?,?)",
                        id, "ORDER_" + to, v, payload);
                }
            }
        }
        Db.update(c, "INSERT INTO order_transition (order_id, from_status, to_status, version, cause) VALUES (?,?,?,?,?)",
            id, from, to, v, cause);
        return true;
    }

    static final java.util.Set<String> TERMINAL = java.util.Set.of("PAID", "FAILED", "CANCELLED", "REFUNDED");

    /** SELECT ... FOR UPDATE：同一订单上的回调、查询结果、取消串行执行，每个都基于最新状态判断。 */
    static Order lock(Connection c, String id) throws SQLException {
        return read(c, id, " FOR UPDATE");
    }

    public static Order find(Connection c, String id) throws SQLException {
        return read(c, id, "");
    }

    private static Order read(Connection c, String id, String suffix) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT order_id, user_id, sku, amount, status, version, reservation_key, reserve_attempt, refund_key "
              + "FROM orders WHERE order_id = ?" + suffix)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                return new Order(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5),
                    rs.getInt(6), rs.getString(7), rs.getInt(8), rs.getString(9));
            }
        }
    }

    public static String status(Connection c, String id) throws SQLException {
        return Db.queryString(c, "SELECT status FROM orders WHERE order_id = ?", id);
    }
}
