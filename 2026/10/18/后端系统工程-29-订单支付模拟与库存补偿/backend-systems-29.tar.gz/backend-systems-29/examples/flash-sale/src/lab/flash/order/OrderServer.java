package lab.flash.order;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.sql.Connection;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.Executors;
import lab.common.Db;

/**
 * 订单服务的 HTTP 入口（每请求一个虚拟线程）：
 *   POST /orders               request_key, user, sku, amount
 *        201 outcome=CREATED / 200 REPLAY / 409 SOLD_OUT|USER_LIMIT / 422 KEY_REUSED
 *   POST /orders/{id}/pay      200 status=PAID|FAILED|UNKNOWN|REFUNDING|REFUNDED / 409 outcome=REJECTED status=...
 *   GET  /orders/{id}          200 status=... version=... / 404
 *   POST /callbacks/payment    渠道回调；处理完成返回 200（渠道据此停止重试），数据库异常返回 500
 */
public final class OrderServer implements AutoCloseable {
    private final HttpServer http;
    private final OrderService svc;
    private final Duration timeout;

    public OrderServer(OrderService svc, Duration timeout, int port) throws IOException {
        this.svc = svc;
        this.timeout = timeout;
        http = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 128);
        http.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
        http.createContext("/orders", this::orders);
        http.createContext("/callbacks/payment", this::callback);
        http.start();
    }

    public String baseUrl() { return "http://127.0.0.1:" + http.getAddress().getPort(); }

    private void orders(HttpExchange ex) {
        try (Connection c = Db.connect()) {
            String path = ex.getRequestURI().getPath();
            if (path.equals("/orders") && ex.getRequestMethod().equals("POST")) {
                Map<String, String> f = Http.form(Http.body(ex));
                OrderService.Created r = svc.create(c, f.get("request_key"), f.get("user"), f.get("sku"), Integer.parseInt(f.get("amount")));
                int code = switch (r.outcome()) { case "CREATED" -> 201; case "REPLAY" -> 200; case "KEY_REUSED" -> 422; default -> 409; };
                Http.reply(ex, code, "outcome=" + r.outcome() + " order_id=" + r.orderId() + " status=" + r.status());
            } else if (path.endsWith("/pay") && ex.getRequestMethod().equals("POST")) {
                String id = path.substring("/orders/".length(), path.length() - "/pay".length());
                String st = svc.pay(c, id, timeout);
                if (st.startsWith("REJECTED")) Http.reply(ex, 409, "outcome=REJECTED status=" + st.substring(9));
                else Http.reply(ex, 200, "status=" + st);
            } else {
                String id = path.substring("/orders/".length());
                OrderService.Order o = OrderService.find(c, id);
                if (o == null) Http.reply(ex, 404, "status=NOT_FOUND");
                else Http.reply(ex, 200, "status=" + o.status() + " version=" + o.version() + " reservation=" + o.reservationKey());
            }
        } catch (Exception e) {
            Http.reply(ex, 500, "outcome=ERROR");
        }
    }

    private void callback(HttpExchange ex) {
        try (Connection c = Db.connect()) {
            String effect = svc.onNotice(c, Http.form(Http.body(ex)), timeout);
            Http.reply(ex, 200, "effect=" + effect.replace(' ', '_'));
        } catch (Exception e) {
            Http.reply(ex, 500, "effect=ERROR");
        }
    }

    @Override public void close() { http.stop(0); }
}
