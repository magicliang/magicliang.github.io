package lab.flash.reserve;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 进程内有界准入：最多 limit 个请求同时进入数据库路径；
 * 其余最多 maxWaiting 个排队等待 waitMillis，排队位满则立即拒绝。
 */
public final class Admission {
    public enum Ticket { ADMITTED, ADMITTED_AFTER_WAIT, REJECTED_QUEUE_FULL, REJECTED_WAIT_TIMEOUT }

    private final Semaphore permits;
    private final int maxWaiting;
    private final long waitMillis;
    private final AtomicInteger waiting = new AtomicInteger();
    private final AtomicInteger inFlight = new AtomicInteger();

    public final AtomicInteger admitted = new AtomicInteger();
    public final AtomicInteger admittedAfterWait = new AtomicInteger();
    public final AtomicInteger rejectedQueueFull = new AtomicInteger();
    public final AtomicInteger rejectedWaitTimeout = new AtomicInteger();
    public final AtomicInteger maxInFlightSeen = new AtomicInteger();
    public final AtomicInteger maxWaitingSeen = new AtomicInteger();

    public Admission(int limit, int maxWaiting, long waitMillis) {
        this.permits = new Semaphore(limit, true);
        this.maxWaiting = maxWaiting;
        this.waitMillis = waitMillis;
    }

    public Ticket enter() throws InterruptedException {
        if (permits.tryAcquire()) return admit(Ticket.ADMITTED, admitted);
        int w = waiting.incrementAndGet();
        if (w > maxWaiting) {
            waiting.decrementAndGet();
            rejectedQueueFull.incrementAndGet();
            return Ticket.REJECTED_QUEUE_FULL;
        }
        maxWaitingSeen.accumulateAndGet(w, Math::max);
        boolean ok;
        try {
            ok = permits.tryAcquire(waitMillis, TimeUnit.MILLISECONDS);
        } finally {
            waiting.decrementAndGet();
        }
        if (!ok) {
            rejectedWaitTimeout.incrementAndGet();
            return Ticket.REJECTED_WAIT_TIMEOUT;
        }
        return admit(Ticket.ADMITTED_AFTER_WAIT, admittedAfterWait);
    }

    private Ticket admit(Ticket t, AtomicInteger counter) {
        counter.incrementAndGet();
        maxInFlightSeen.accumulateAndGet(inFlight.incrementAndGet(), Math::max);
        return t;
    }

    public void exit() {
        inFlight.decrementAndGet();
        permits.release();
    }

    public int waitingNow() { return waiting.get(); }

    public String counters() {
        return "admitted=" + admitted + " admitted_after_wait=" + admittedAfterWait
            + " rejected_queue_full=" + rejectedQueueFull + " rejected_wait_timeout=" + rejectedWaitTimeout
            + " max_in_flight=" + maxInFlightSeen + " max_waiting=" + maxWaitingSeen;
    }
}
