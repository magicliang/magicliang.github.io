package lab.flash.reserve;

import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import lab.common.Db;

/**
 * 全局库存与预留（第 28 章；第 29 章复用）。
 * 不变量：sku_stock.available = total - count(reservation 中 HELD 与 CONFIRMED)。
 * 每个方法都有两种用法：xxx(c, ...) 自己开启并提交事务；xxxInTx(c, ...) 由调用方事务承载。
 */
public final class Inventory {
    private Inventory() {}

    public static final String SCHEMA = """
        CREATE TABLE sku_stock (
          sku       text PRIMARY KEY,
          total     int  NOT NULL CHECK (total >= 0),
          available int  NOT NULL,
          CONSTRAINT available_range CHECK (available >= 0 AND available <= total)
        );
        CREATE TABLE reservation (
          reservation_id bigserial PRIMARY KEY,
          request_key    text NOT NULL UNIQUE,
          user_id        text NOT NULL,
          sku            text NOT NULL REFERENCES sku_stock,
          status         text NOT NULL CHECK (status IN ('HELD','CONFIRMED','RELEASED','EXPIRED')),
          expires_at     timestamptz NOT NULL,
          created_at     timestamptz NOT NULL DEFAULT now(),
          updated_at     timestamptz NOT NULL DEFAULT now()
        );
        -- 每个用户在一个 SKU 上最多一个有效预留（HELD 或 CONFIRMED）
        CREATE UNIQUE INDEX reservation_one_active ON reservation (sku, user_id)
          WHERE status IN ('HELD','CONFIRMED');
        CREATE INDEX reservation_due ON reservation (expires_at) WHERE status = 'HELD';
        """;

    /** outcome: HELD（新建）/ REPLAY（同键已存在）/ SOLD_OUT / USER_LIMIT / KEY_REUSED */
    public record Hold(String outcome, long reservationId, String status) {}

    public static void addSku(Connection c, String sku, int total) throws SQLException {
        Db.update(c, "INSERT INTO sku_stock (sku, total, available) VALUES (?,?,?)", sku, total, total);
    }

    public static Hold reserve(Connection c, String key, String user, String sku, long ttlMillis) throws SQLException {
        return inTx(c, () -> reserveInTx(c, key, user, sku, ttlMillis));
    }

    public static Hold reserveInTx(Connection c, String key, String user, String sku, long ttlMillis) throws SQLException {
        Savepoint sp = c.setSavepoint();
        Long id = null;
        try (PreparedStatement ps = c.prepareStatement(
                "INSERT INTO reservation (request_key, user_id, sku, status, expires_at) "
              + "VALUES (?,?,?,'HELD', now() + make_interval(secs => ? / 1000.0)) "
              + "ON CONFLICT (request_key) DO NOTHING RETURNING reservation_id")) {
            ps.setString(1, key); ps.setString(2, user); ps.setString(3, sku); ps.setLong(4, ttlMillis);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) id = rs.getLong(1); }
        } catch (SQLException e) {
            if (!"23505".equals(e.getSQLState())) throw e;
            c.rollback(sp);
            // 撞上 reservation_one_active。并发的同键请求也可能先撞上这个索引而不是 request_key 冲突：
            // 插入在用户索引上等待对方提交后报错。因此先按 request_key 查一次，查到就是重放。
            Hold existing = lookupByKey(c, key, user, sku);
            return existing != null ? existing : new Hold("USER_LIMIT", 0, null);
        }
        if (id == null) {                          // 同一个 request_key 已登记：返回它现在的状态
            c.releaseSavepoint(sp);
            return lookupByKey(c, key, user, sku);
        }
        // 条件扣减热点行：available > 0 在拿到行锁后对最新版本重新求值
        int n = Db.update(c, "UPDATE sku_stock SET available = available - 1 WHERE sku = ? AND available > 0", sku);
        if (n == 0) {
            c.rollback(sp);                        // 撤销刚插入的预留行
            return new Hold("SOLD_OUT", 0, null);
        }
        c.releaseSavepoint(sp);
        return new Hold("HELD", id, "HELD");
    }

    /** 按 request_key 读取已登记的预留；Read Committed 下新语句能看到刚提交的对方事务。 */
    private static Hold lookupByKey(Connection c, String key, String user, String sku) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT reservation_id, status, user_id, sku FROM reservation WHERE request_key = ?")) {
            ps.setString(1, key);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                if (!rs.getString(3).equals(user) || !rs.getString(4).equals(sku)) return new Hold("KEY_REUSED", 0, null);
                return new Hold("REPLAY", rs.getLong(1), rs.getString(2));
            }
        }
    }

    /** HELD → CONFIRMED，要求尚未到期。返回是否迁移成功。 */
    public static boolean confirm(Connection c, String key) throws SQLException {
        return Db.update(c, "UPDATE reservation SET status = 'CONFIRMED', updated_at = now() "
            + "WHERE request_key = ? AND status = 'HELD' AND expires_at >= now()", key) == 1;
    }

    /** HELD → CONFIRMED，不看到期时间：只要库存仍被这条预留占着（释放任务尚未处理）即可确认。第 29 章使用。 */
    public static boolean confirmHeldInTx(Connection c, String key) throws SQLException {
        return Db.update(c, "UPDATE reservation SET status = 'CONFIRMED', updated_at = now() "
            + "WHERE request_key = ? AND status = 'HELD'", key) == 1;
    }

    /** 主动取消：HELD → RELEASED，并在同一语句中归还库存。 */
    public static int release(Connection c, String key) throws SQLException {
        return inTx(c, () -> releaseInTx(c, key));
    }

    public static int releaseInTx(Connection c, String key) throws SQLException {
        return (int) Db.queryLong(c, """
            WITH moved AS (
              UPDATE reservation SET status = 'RELEASED', updated_at = now()
              WHERE request_key = ? AND status = 'HELD'
              RETURNING sku)
            , per AS (SELECT sku, count(*) AS n FROM moved GROUP BY sku)
            , upd AS (UPDATE sku_stock s SET available = s.available + per.n FROM per WHERE s.sku = per.sku RETURNING per.n)
            SELECT coalesce(sum(n), 0) FROM upd
            """, key);
    }

    /**
     * 到期释放：只有状态从 HELD 迁到 EXPIRED 的行才归还库存，迁移与归还在同一条语句、同一事务中。
     * ids 为 null 时处理全部到期行；非 null 时只处理这一批（模拟任务框架按批投递）。返回归还件数。
     */
    public static final String EXPIRE_SQL = """
        WITH moved AS (
          UPDATE reservation SET status = 'EXPIRED', updated_at = now()
          WHERE status = 'HELD' AND expires_at < now()
            AND (?::bigint[] IS NULL OR reservation_id = ANY (?::bigint[]))
          RETURNING sku)
        , per AS (SELECT sku, count(*) AS n FROM moved GROUP BY sku)
        , upd AS (UPDATE sku_stock s SET available = s.available + per.n FROM per WHERE s.sku = per.sku RETURNING per.n)
        SELECT coalesce(sum(n), 0) FROM upd
        """;

    public static int expire(Connection c, Long[] ids) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(EXPIRE_SQL)) {
            Array arr = ids == null ? null : c.createArrayOf("bigint", ids);
            ps.setArray(1, arr); ps.setArray(2, arr);
            try (ResultSet rs = ps.executeQuery()) { rs.next(); return rs.getInt(1); }
        }
    }

    public static String status(Connection c, String key) throws SQLException {
        return Db.queryString(c, "SELECT status FROM reservation WHERE request_key = ?", key);
    }

    public static long available(Connection c, String sku) throws SQLException {
        return Db.queryLong(c, "SELECT available FROM sku_stock WHERE sku = ?", sku);
    }

    public static long active(Connection c, String sku) throws SQLException {
        return Db.queryLong(c, "SELECT count(*) FROM reservation WHERE sku = ? AND status IN ('HELD','CONFIRMED')", sku);
    }

    /** 库存守恒检查：返回 total - available - active，应为 0。 */
    public static long drift(Connection c, String sku) throws SQLException {
        return Db.queryLong(c, "SELECT total - available FROM sku_stock WHERE sku = ?", sku) - active(c, sku);
    }

    interface Tx<T> { T run() throws SQLException; }

    static <T> T inTx(Connection c, Tx<T> body) throws SQLException {
        c.setAutoCommit(false);
        try {
            T r = body.run();
            c.commit();
            return r;
        } catch (SQLException | RuntimeException e) {
            try { c.rollback(); } catch (SQLException ignore) { }
            throw e;
        } finally {
            try { c.setAutoCommit(true); } catch (SQLException ignore) { }
        }
    }
}
