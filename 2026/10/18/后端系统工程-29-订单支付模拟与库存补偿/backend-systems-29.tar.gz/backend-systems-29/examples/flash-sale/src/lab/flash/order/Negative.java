package lab.flash.order;

import java.net.http.HttpTimeoutException;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.Duration;
import java.util.Map;
import lab.common.Db;
import lab.flash.reserve.Inventory;

/** 负向对照：每个方法去掉正确实现中的一项检查，用来证明那项检查确实必要。 */
final class Negative {
    private Negative() {}

    /** 错误 1：把扣款超时当作失败，立即 FAILED 并归还库存。 */
    static String payTimeoutIsFailure(Connection c, OrderService svc, String id, Duration timeout) throws Exception {
        int amount = svc.beginPay(c, id);
        try {
            Http.Resp r = svc.channel().charge(id, amount, "", timeout);
            svc.applyChannelResult(c, id, r.get("result"), amount, r.get("txn"), "charge reply", timeout);
        } catch (HttpTimeoutException e) {
            Tx.run(c, () -> {
                OrderService.Order o = OrderService.lock(c, id);
                OrderService.transition(c, id, "PAYING", "FAILED", "timeout treated as failure");
                return Inventory.releaseInTx(c, o.reservationKey());
            });
        }
        return OrderService.status(c, id);
    }

    /** 错误 2：查询得到 NOT_FOUND 就判定未扣款，不关单。 */
    static String notFoundIsFailure(Connection c, OrderService svc, String id, Duration timeout) throws Exception {
        String st = svc.channel().query(id, timeout).get("status");
        if (st.equals("NOT_FOUND")) {
            Tx.run(c, () -> {
                OrderService.Order o = OrderService.lock(c, id);
                OrderService.transition(c, id, o.status(), "FAILED", "NOT_FOUND treated as failure");
                return Inventory.releaseInTx(c, o.reservationKey());
            });
        }
        return OrderService.status(c, id);
    }

    /** 错误 3：成功回调不看当前状态，直接写 PAID。 */
    static int blindPaidCallback(Connection c, String id) throws SQLException {
        return Db.update(c, "UPDATE orders SET status = 'PAID', version = version + 1, updated_at = now() WHERE order_id = ?", id);
    }

    /** 错误 4：成功回调确认预留但不看确认结果（预留可能已被到期释放并卖给别人）。 */
    static String confirmIgnoringResult(Connection c, String id) throws SQLException {
        return Tx.run(c, () -> {
            OrderService.Order o = OrderService.lock(c, id);
            Inventory.confirmHeldInTx(c, o.reservationKey());
            OrderService.transition(c, id, o.status(), "PAID", "callback, confirm result ignored");
            return OrderService.status(c, id);
        });
    }

    /** 错误 5（双写）：先提交 PAID（不写 outbox），再直接通知消费者。两步之间崩溃则通知永久丢失。 */
    static void dualWritePaid(Connection c, String id, String consumerUrl, Runnable between) throws Exception {
        int v = Tx.run(c, () -> {
            OrderService.Order o = OrderService.lock(c, id);
            Inventory.confirmHeldInTx(c, o.reservationKey());
            return (int) Db.queryLong(c, "UPDATE orders SET status = 'PAID', version = version + 1 WHERE order_id = ? RETURNING version", id);
        });
        between.run();
        Http.post(consumerUrl, Map.of("event_id", 900000 + v, "order_id", id, "type", "ORDER_PAID", "version", v), Duration.ofSeconds(5));
    }
}
