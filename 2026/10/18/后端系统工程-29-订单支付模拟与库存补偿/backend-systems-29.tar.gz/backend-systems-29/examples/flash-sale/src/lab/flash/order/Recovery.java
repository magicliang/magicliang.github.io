package lab.flash.order;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import lab.common.Db;
import lab.flash.reserve.Inventory;

/**
 * 恢复任务：让“结果未知”的订单收敛，并清理到期未支付的订单。可重复执行、可与回调并发。
 *   UNKNOWN，或 PAYING 超过 staleMillis 未变化（发起支付的进程可能已经崩溃）：
 *       查询渠道 → CHARGED/DECLINED 直接落状态机；NOT_FOUND → 先关单，以关单结果为准。
 *   REFUNDING：按固定 refund_key 重发退款。
 *   CREATED 且预留已到期或已被释放：取消订单，同事务归还仍为 HELD 的预留。
 */
public final class Recovery {
    private final OrderService svc;
    private final Duration timeout;

    public Recovery(OrderService svc, Duration timeout) { this.svc = svc; this.timeout = timeout; }

    public Map<String, Integer> resolveOnce(Connection c, long staleMillis) throws Exception {
        Map<String, Integer> out = new TreeMap<>();
        List<String[]> rows = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement("""
                SELECT order_id, status, amount FROM orders
                WHERE status IN ('UNKNOWN','REFUNDING')
                   OR (status = 'PAYING' AND updated_at < now() - make_interval(secs => ? / 1000.0))
                ORDER BY order_id""")) {
            ps.setLong(1, staleMillis);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) rows.add(new String[] {rs.getString(1), rs.getString(2), rs.getString(3)});
            }
        }
        for (String[] r : rows) {
            String id = r[0];
            String action;
            try {
                if (r[1].equals("REFUNDING")) {
                    action = "refund-retry:" + svc.refund(c, id, timeout);
                } else {
                    action = converge(c, id, Integer.parseInt(r[2]));
                }
            } catch (IOException e) {
                action = "still-unknown";
            }
            out.merge(action, 1, Integer::sum);
        }
        return out;
    }

    /** 查询 → 必要时关单。关单之后渠道不再接受同号扣款，因此 CLOSED 是确定的“未扣款”。 */
    private String converge(Connection c, String id, int amount) throws Exception {
        ChannelClient ch = svc.channel();
        Http.Resp q = ch.query(id, timeout);
        String st = q.get("status");
        if (st.equals("NOT_FOUND")) {
            Http.Resp cl = ch.close(id, timeout);
            st = cl.get("status");              // CLOSED，或在查询与关单之间刚刚到达的 CHARGED/DECLINED
            svc.applyChannelResult(c, id, st, amount, cl.get("txn"), "close", timeout);
            return "close:" + st + "->" + OrderService.status(c, id);
        }
        svc.applyChannelResult(c, id, st, amount, q.get("txn"), "query", timeout);
        return "query:" + st + "->" + OrderService.status(c, id);
    }

    /** CREATED 订单的预留已到期或已被释放：取消。与 pay() 竞争同一行，条件迁移保证只有一方成功。 */
    public int cancelExpiredCreated(Connection c) throws SQLException {
        List<String> ids = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement("""
                SELECT o.order_id FROM orders o JOIN reservation r ON r.request_key = o.reservation_key
                WHERE o.status = 'CREATED' AND (r.status <> 'HELD' OR r.expires_at < now()) ORDER BY 1""");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) ids.add(rs.getString(1));
        }
        int n = 0;
        for (String id : ids) {
            n += Tx.run(c, () -> {
                OrderService.Order o = OrderService.lock(c, id);
                if (!OrderService.transition(c, id, "CREATED", "CANCELLED", "reservation expired")) return 0;
                Inventory.releaseInTx(c, o.reservationKey());
                return 1;
            });
        }
        return n;
    }

    public static long pending(Connection c) throws SQLException {
        return Db.queryLong(c, "SELECT count(*) FROM orders WHERE status IN ('PAYING','UNKNOWN','REFUNDING')");
    }
}
