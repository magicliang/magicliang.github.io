package lab.flash.reserve;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.concurrent.atomic.AtomicInteger;
import lab.common.Db;

/** 方案比较中的另外两种实现：预拆分名额行 + SKIP LOCKED；进程内存计数 + 事后对账。 */
public final class Schemes {
    private Schemes() {}

    public static final String SCHEMA = """
        CREATE TABLE stock_slot (
          sku        text NOT NULL,
          slot_no    int  NOT NULL,
          holder_key text UNIQUE,
          PRIMARY KEY (sku, slot_no)
        );
        CREATE TABLE mem_sale (
          request_key text PRIMARY KEY,
          sku         text NOT NULL,
          node        text NOT NULL
        );
        """;

    public static void addSlots(Connection c, String sku, int n) throws SQLException {
        Db.update(c, "INSERT INTO stock_slot (sku, slot_no) SELECT ?, g FROM generate_series(1, ?) g", sku, n);
    }

    /** 方案 B：领取一个空闲名额行；被别的事务锁住的行直接跳过。调用方控制事务。 */
    public static boolean claimSlotInTx(Connection c, String sku, String key) throws SQLException {
        return Db.update(c, """
            UPDATE stock_slot SET holder_key = ?
            WHERE (sku, slot_no) = (
              SELECT sku, slot_no FROM stock_slot
              WHERE sku = ? AND holder_key IS NULL
              ORDER BY slot_no LIMIT 1
              FOR UPDATE SKIP LOCKED)
            """, key, sku) == 1;
    }

    public static long freeSlots(Connection c, String sku) throws SQLException {
        return Db.queryLong(c, "SELECT count(*) FROM stock_slot WHERE sku = ? AND holder_key IS NULL", sku);
    }

    /** 方案 C：每个应用节点持有一个内存计数器，先在内存扣减，再写销售记录；数据库不检查库存。 */
    public static final class MemoryNode {
        final String name;
        final int configuredShare;
        final AtomicInteger remaining;
        public MemoryNode(String name, int initial) {
            this.name = name; this.configuredShare = initial; this.remaining = new AtomicInteger(initial);
        }

        /** 进程重启：内存计数丢失，按配置份额重新初始化，而不是按已写入的销售记录重算。 */
        public void restartFromConfig() { remaining.set(configuredShare); }

        /** 修正做法：重启时按本节点已落库的销售记录重算剩余份额。 */
        public void restartFromLedger(Connection c, String sku) throws SQLException {
            long sold = Db.queryLong(c, "SELECT count(*) FROM mem_sale WHERE sku = ? AND node = ?", sku, name);
            remaining.set((int) Math.max(0, configuredShare - sold));
        }

        public boolean sell(Connection c, String sku, String key) throws SQLException {
            if (remaining.getAndUpdate(v -> v > 0 ? v - 1 : v) <= 0) return false;
            Db.update(c, "INSERT INTO mem_sale (request_key, sku, node) VALUES (?,?,?)", key, sku, name);
            return true;
        }
        public int remaining() { return remaining.get(); }
    }

    public static long memSold(Connection c, String sku) throws SQLException {
        return Db.queryLong(c, "SELECT count(*) FROM mem_sale WHERE sku = ?", sku);
    }
}
