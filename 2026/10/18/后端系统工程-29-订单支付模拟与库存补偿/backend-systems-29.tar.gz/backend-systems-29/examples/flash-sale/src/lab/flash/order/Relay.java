package lab.flash.order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lab.common.Db;

/**
 * Outbox 中继：至少一次投递。
 * 一个事务内：领取一批未发布事件（FOR UPDATE SKIP LOCKED，多个中继互不阻塞）→ 逐条 POST 给消费者 →
 * 收到 200 的标记 published_at → 提交。投递之后、提交之前崩溃，标记随事务回滚，下次重投。
 */
public final class Relay {
    private Relay() {}

    public static int relayOnce(Connection c, String consumerUrl, int limit, Tx.Hook beforeCommit) throws SQLException {
        return Tx.run(c, () -> {
            List<Object[]> batch = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement("""
                    SELECT event_id, order_id, event_type, order_version FROM outbox
                    WHERE published_at IS NULL ORDER BY event_id LIMIT ? FOR UPDATE SKIP LOCKED""")) {
                ps.setInt(1, limit);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) batch.add(new Object[] {rs.getLong(1), rs.getString(2), rs.getString(3), rs.getInt(4)});
                }
            }
            int sent = 0;
            for (Object[] e : batch) {
                int code;
                try {
                    code = Http.post(consumerUrl, Map.of("event_id", e[0], "order_id", e[1], "type", e[2], "version", e[3]),
                        Duration.ofSeconds(5)).code();
                } catch (Exception ex) {
                    code = -1;
                }
                if (code != 200) break;                // 保持顺序：后面的事件下一轮再发
                Db.update(c, "UPDATE outbox SET published_at = now() WHERE event_id = ?", e[0]);
                sent++;
            }
            beforeCommit.run();
            return sent;
        });
    }

    /** 循环直到没有未发布事件或一轮没有进展。 */
    public static int drain(Connection c, String consumerUrl) throws SQLException {
        int total = 0;
        while (true) {
            int n = relayOnce(c, consumerUrl, 50, Tx.NONE);
            total += n;
            if (n == 0) return total;
        }
    }

    public static long unpublished(Connection c) throws SQLException {
        return Db.queryLong(c, "SELECT count(*) FROM outbox WHERE published_at IS NULL");
    }
}
