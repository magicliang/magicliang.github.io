package lab.flash.order;

import com.sun.net.httpserver.HttpExchange;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

/** 本章三个本地服务共用的极简 HTTP 工具：表单正文、"k=v k=v" 文本应答。 */
final class Http {
    private Http() {}

    record Resp(int code, Map<String, String> kv, String raw) {
        String get(String k) { return kv.get(k); }
    }

    static final HttpClient CLIENT = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1)
        .connectTimeout(Duration.ofSeconds(2)).build();

    static Map<String, String> form(String body) {
        Map<String, String> m = new LinkedHashMap<>();
        if (body == null || body.isEmpty()) return m;
        for (String kv : body.split("&")) {
            int i = kv.indexOf('=');
            if (i > 0) m.put(kv.substring(0, i), URLDecoder.decode(kv.substring(i + 1), StandardCharsets.UTF_8));
        }
        return m;
    }

    static String encode(Map<String, ?> m) {
        StringBuilder b = new StringBuilder();
        for (var e : m.entrySet()) {
            if (b.length() > 0) b.append('&');
            b.append(e.getKey()).append('=').append(URLEncoder.encode(String.valueOf(e.getValue()), StandardCharsets.UTF_8));
        }
        return b.toString();
    }

    static Map<String, String> kv(String text) {
        Map<String, String> m = new LinkedHashMap<>();
        for (String tok : text.trim().split("\\s+")) {
            int i = tok.indexOf('=');
            if (i > 0) m.put(tok.substring(0, i), tok.substring(i + 1));
        }
        return m;
    }

    static String body(HttpExchange ex) throws IOException {
        return new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
    }

    /** 写应答；对端已经放弃等待时写入会失败，这里吞掉异常（服务端的处理结果不受影响）。 */
    static void reply(HttpExchange ex, int status, String text) {
        byte[] b = text.getBytes(StandardCharsets.UTF_8);
        try {
            ex.sendResponseHeaders(status, b.length);
            try (OutputStream os = ex.getResponseBody()) { os.write(b); }
        } catch (IOException ignore) {
            // 客户端已超时断开
        } finally {
            ex.close();
        }
    }

    static Resp post(String url, Map<String, ?> form, Duration timeout) throws IOException, InterruptedException {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url)).timeout(timeout)
            .header("Content-Type", "application/x-www-form-urlencoded")
            .POST(HttpRequest.BodyPublishers.ofString(encode(form))).build();
        HttpResponse<String> r = CLIENT.send(req, HttpResponse.BodyHandlers.ofString());
        return new Resp(r.statusCode(), kv(r.body()), r.body());
    }

    static Resp get(String url, Duration timeout) throws IOException, InterruptedException {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url)).timeout(timeout).GET().build();
        HttpResponse<String> r = CLIENT.send(req, HttpResponse.BodyHandlers.ofString());
        return new Resp(r.statusCode(), kv(r.body()), r.body());
    }
}
