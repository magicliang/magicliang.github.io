package lab.flash.order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import lab.common.Db;
import lab.flash.reserve.Inventory;

/**
 * 三方对账：渠道账本（CHARGE/REFUND 行）× 订单 × 预留。每张订单按状态归入一类，规则如下：
 *   PAID      渠道扣款 = 订单金额、无退款；当前预留为 CONFIRMED
 *   REFUNDED  渠道扣款 = 退款 = 订单金额；当前预留不是有效状态（HELD/CONFIRMED）
 *   FAILED / CANCELLED  渠道无扣款；当前预留不是有效状态
 *   CREATED   渠道无扣款；当前预留为 HELD（未完成，单独计数）
 *   PAYING / UNKNOWN / REFUNDING  待收敛（单独列出，不算不一致）
 * 另查：同一商户订单号多于一条扣款；渠道有记录但订单不存在；CONFIRMED 预留数 = PAID 订单数；库存守恒；
 *   渠道净额 = PAID 订单金额之和。
 */
public final class Reconcile {
    private Reconcile() {}

    public record Report(Map<String, Integer> classes, List<String> mismatches, List<String> pending,
                         long channelNet, long paidSum, long confirmed, long paid, long drift) {
        public boolean clean() { return mismatches.isEmpty(); }
        public String summary() {
            return "classes=" + classes + " mismatches=" + mismatches.size() + " pending=" + pending.size()
                + " channel_net=" + channelNet + " paid_sum=" + paidSum + " confirmed=" + confirmed + " paid=" + paid + " drift=" + drift;
        }
    }

    public static Report run(Connection c, String statement, String sku) throws SQLException {
        Map<String, int[]> led = new HashMap<>();                  // mo -> {charges, chargedAmount, refundedAmount}
        for (String line : statement.split("\n")) {
            if (line.isBlank()) continue;
            String[] p = line.trim().split(" ");
            int[] a = led.computeIfAbsent(p[1], k -> new int[3]);
            if (p[0].equals("CHARGE")) { a[0]++; a[1] += Integer.parseInt(p[2]); }
            else a[2] += Integer.parseInt(p[2]);
        }
        Map<String, Integer> classes = new TreeMap<>();
        List<String> mism = new ArrayList<>(), pending = new ArrayList<>();
        long paidSum = 0, paid = 0;
        try (PreparedStatement ps = c.prepareStatement("""
                SELECT o.order_id, o.status, o.amount, coalesce(r.status, 'NONE')
                FROM orders o LEFT JOIN reservation r ON r.request_key = o.reservation_key ORDER BY o.order_id""");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String id = rs.getString(1), st = rs.getString(2), rst = rs.getString(4);
                int amount = rs.getInt(3);
                int[] a = led.remove(id);
                int n = a == null ? 0 : a[0], charged = a == null ? 0 : a[1], refunded = a == null ? 0 : a[2];
                boolean active = rst.equals("HELD") || rst.equals("CONFIRMED");
                String problem = null;
                if (n > 1) problem = "DOUBLE_CHARGE";
                else switch (st) {
                    case "PAID" -> {
                        paid++; paidSum += amount;
                        if (charged != amount) problem = "PAID_WITHOUT_CHARGE";
                        else if (refunded != 0) problem = "PAID_BUT_REFUNDED";
                        else if (!rst.equals("CONFIRMED")) problem = "PAID_WITHOUT_CONFIRMED_RESERVATION(" + rst + ")";
                    }
                    case "REFUNDED" -> {
                        if (charged != amount || refunded != amount) problem = "REFUNDED_LEDGER_MISMATCH";
                        else if (active) problem = "REFUNDED_BUT_RESERVATION_" + rst;
                    }
                    case "FAILED", "CANCELLED" -> {
                        if (charged - refunded != 0) problem = "CHARGED_BUT_" + st;
                        else if (active) problem = st + "_BUT_RESERVATION_" + rst;
                    }
                    case "CREATED" -> {
                        if (charged != 0) problem = "CHARGED_BUT_CREATED";
                        else if (!rst.equals("HELD")) problem = "CREATED_WITHOUT_HELD(" + rst + ")";
                    }
                    default -> pending.add(id + ":" + st);
                }
                classes.merge(st, 1, Integer::sum);
                if (problem != null) mism.add(id + " " + st + " " + problem + " charged=" + charged + " refunded=" + refunded + " reservation=" + rst);
            }
        }
        long net = 0;
        for (var e : led.entrySet()) mism.add(e.getKey() + " ORPHAN_CHANNEL_RECORD charged=" + e.getValue()[1]);
        for (String line : statement.split("\n")) {
            if (line.isBlank()) continue;
            String[] p = line.trim().split(" ");
            net += (p[0].equals("CHARGE") ? 1 : -1) * Long.parseLong(p[2]);
        }
        long confirmed = Db.queryLong(c, "SELECT count(*) FROM reservation WHERE sku = ? AND status = 'CONFIRMED'", sku);
        long drift = Inventory.drift(c, sku);
        if (confirmed != paid) mism.add("GLOBAL confirmed=" + confirmed + " != paid=" + paid);
        if (drift != 0) mism.add("GLOBAL inventory drift=" + drift);
        if (pending.isEmpty() && net != paidSum) mism.add("GLOBAL channel_net=" + net + " != paid_sum=" + paidSum);
        return new Report(classes, mism, pending, net, paidSum, confirmed, paid, drift);
    }
}
