package lab.flash.order;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 假支付渠道（本地 HTTP 替身），只处理模拟积分。契约：
 *   POST /charge   merchant_order, amount, notify_url
 *        按商户订单号幂等：首次请求决定结果（CHARGED 或 DECLINED），之后同号同额请求返回同一结果；
 *        同号不同额返回 422 AMOUNT_MISMATCH；已关单返回 CLOSED。
 *   GET  /charges/{merchant_order}  status=CHARGED|DECLINED|CLOSED|REFUNDED|NOT_FOUND
 *   POST /close    merchant_order  没有扣款记录时登记 CLOSED，此后同号扣款一律拒绝；已有记录则返回其状态。
 *   POST /refund   merchant_order, refund_key, amount  按 refund_key 幂等；只支持全额退款。
 *   GET  /statement  渠道账本（CHARGE / REFUND 行），供对账使用。
 * 回调：状态变化后向 notify_url 发送 notify_id, merchant_order, kind, amount, txn；
 *   非 200 时重试（至少一次），可配置份数（重复）、延迟（迟到）和扣住（由测试决定发送顺序，即乱序）。
 * 故障：responseDelayMs = 先记账、再拖延应答（已扣款但调用方超时）；refundResponseDelayMs 同理作用于首次退款；
 *       requestDelayMs  = 请求在“网络中”滞留，渠道尚未看见（调用方超时、查询得到 NOT_FOUND）。
 */
public final class FakeChannel implements AutoCloseable {

    public record Fault(boolean decline, long responseDelayMs, long requestDelayMs, long refundResponseDelayMs,
                        boolean holdCallbacks, int callbackCopies, long callbackDelayMs) {
        public static Fault none() { return new Fault(false, 0, 0, 0, false, 1, 20); }
        public static Fault held() { return new Fault(false, 0, 0, 0, true, 1, 0); }
        public Fault withDecline() { return new Fault(true, responseDelayMs, requestDelayMs, refundResponseDelayMs, holdCallbacks, callbackCopies, callbackDelayMs); }
        public Fault withResponseDelay(long ms) { return new Fault(decline, ms, requestDelayMs, refundResponseDelayMs, holdCallbacks, callbackCopies, callbackDelayMs); }
        public Fault withRequestDelay(long ms) { return new Fault(decline, responseDelayMs, ms, refundResponseDelayMs, holdCallbacks, callbackCopies, callbackDelayMs); }
        public Fault withRefundDelay(long ms) { return new Fault(decline, responseDelayMs, requestDelayMs, ms, holdCallbacks, callbackCopies, callbackDelayMs); }
        public Fault withCallbacks(int copies, long delayMs) { return new Fault(decline, responseDelayMs, requestDelayMs, refundResponseDelayMs, false, copies, delayMs); }
    }

    public record Notice(String notifyId, String merchantOrder, String kind, int amount, String txn, String url) {
        Map<String, Object> form() {
            return Map.of("notify_id", notifyId, "merchant_order", merchantOrder, "kind", kind, "amount", amount, "txn", txn);
        }
    }

    private static final class Charge {
        final String mo; final int amount; String status; String txn; String notifyUrl; String refundKey;
        Charge(String mo, int amount) { this.mo = mo; this.amount = amount; }
    }

    private final HttpServer http;
    private final ScheduledExecutorService sched = Executors.newScheduledThreadPool(4);
    private final Map<String, Charge> charges = new HashMap<>();
    private final List<String> statement = new ArrayList<>();
    private final List<Notice> held = new ArrayList<>();
    private final Map<String, Fault> faults = new ConcurrentHashMap<>();
    private volatile Fault defaultFault = Fault.none();
    private int txnSeq, notifySeq;
    public final AtomicInteger chargeRequests = new AtomicInteger();
    public final AtomicInteger callbacksSent = new AtomicInteger();

    public FakeChannel() throws IOException {
        http = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 128);
        http.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
        http.createContext("/charge", this::charge);
        http.createContext("/charges/", this::query);
        http.createContext("/close", this::closeOrder);
        http.createContext("/refund", this::refund);
        http.createContext("/statement", this::statement);
        http.start();
    }

    public String baseUrl() { return "http://127.0.0.1:" + http.getAddress().getPort(); }
    public void setDefault(Fault f) { defaultFault = f; }
    public void fault(String mo, Fault f) { faults.put(mo, f); }
    private Fault faultOf(String mo) { return faults.getOrDefault(mo, defaultFault); }

    /** 清空账本与配置，供每个用例从空状态开始。 */
    public synchronized void reset() {
        charges.clear(); statement.clear(); held.clear(); faults.clear();
        defaultFault = Fault.none(); chargeRequests.set(0); callbacksSent.set(0);
        txnSeq = 0; notifySeq = 0;
    }

    private void charge(HttpExchange ex) {
        try {
            Map<String, String> f = Http.form(Http.body(ex));
            String mo = f.get("merchant_order");
            int amount = Integer.parseInt(f.get("amount"));
            Fault fault = faultOf(mo);
            if (fault.requestDelayMs() > 0) sleep(fault.requestDelayMs());   // 请求滞留在途中，渠道尚未看见
            chargeRequests.incrementAndGet();
            String out;
            int code = 200;
            synchronized (this) {
                Charge ch = charges.get(mo);
                if (ch == null) {
                    ch = new Charge(mo, amount);
                    ch.notifyUrl = f.get("notify_url");
                    ch.txn = String.format("txn-%04d", ++txnSeq);
                    ch.status = fault.decline() ? "DECLINED" : "CHARGED";
                    charges.put(mo, ch);
                    if (ch.status.equals("CHARGED")) statement.add("CHARGE " + mo + " " + amount + " " + ch.txn);
                    emit(ch, ch.status);
                }
                if ("CLOSED".equals(ch.status)) { code = 409; out = "result=CLOSED"; }   // 已关单：同号扣款一律拒绝
                else if (ch.amount != amount) { code = 422; out = "result=AMOUNT_MISMATCH"; }
                else out = "result=" + ch.status + " txn=" + ch.txn;
            }
            if (fault.responseDelayMs() > 0) sleep(fault.responseDelayMs());  // 已记账，应答迟迟不回
            Http.reply(ex, code, out);
        } catch (Exception e) {
            Http.reply(ex, 500, "result=ERROR");
        }
    }

    private void query(HttpExchange ex) {
        String mo = ex.getRequestURI().getPath().substring("/charges/".length());
        String out;
        synchronized (this) {
            Charge ch = charges.get(mo);
            out = ch == null ? "status=NOT_FOUND" : "status=" + ch.status + " amount=" + ch.amount + " txn=" + ch.txn;
        }
        Http.reply(ex, 200, out);
    }

    private void closeOrder(HttpExchange ex) {
        try {
            String mo = Http.form(Http.body(ex)).get("merchant_order");
            String out;
            synchronized (this) {
                Charge ch = charges.get(mo);
                if (ch == null) {
                    ch = new Charge(mo, 0);
                    ch.status = "CLOSED";
                    ch.txn = "-";
                    charges.put(mo, ch);
                }
                out = "status=" + ch.status + " txn=" + ch.txn;
            }
            Http.reply(ex, 200, out);
        } catch (Exception e) {
            Http.reply(ex, 500, "status=ERROR");
        }
    }

    private void refund(HttpExchange ex) {
        try {
            Map<String, String> f = Http.form(Http.body(ex));
            String mo = f.get("merchant_order"), key = f.get("refund_key");
            int amount = Integer.parseInt(f.get("amount"));
            String out;
            int code = 200;
            boolean fresh = false;
            synchronized (this) {
                Charge ch = charges.get(mo);
                if (ch == null || !(ch.status.equals("CHARGED") || ch.status.equals("REFUNDED"))) {
                    code = 409; out = "result=NOT_CHARGED";
                } else if (ch.status.equals("REFUNDED")) {
                    if (key.equals(ch.refundKey)) out = "result=REFUNDED refund_key=" + key;   // 同键重放
                    else { code = 409; out = "result=ALREADY_REFUNDED"; }
                } else if (ch.amount != amount) {
                    code = 422; out = "result=AMOUNT_MISMATCH";
                } else {
                    ch.status = "REFUNDED";
                    ch.refundKey = key;
                    statement.add("REFUND " + mo + " " + amount + " " + key);
                    emit(ch, "REFUNDED");
                    fresh = true;
                    out = "result=REFUNDED refund_key=" + key;
                }
            }
            long d = faultOf(mo).refundResponseDelayMs();
            if (fresh && d > 0) sleep(d);                // 只有首次退款的应答被拖延；同键重放立即应答
            Http.reply(ex, code, out);
        } catch (Exception e) {
            Http.reply(ex, 500, "result=ERROR");
        }
    }

    private void statement(HttpExchange ex) {
        String out;
        synchronized (this) { out = String.join("\n", statement); }
        Http.reply(ex, 200, out);
    }

    /** 调用方持有 this 的锁。 */
    private void emit(Charge ch, String kind) {
        Notice n = new Notice(String.format("ntf-%04d", ++notifySeq), ch.mo, kind, ch.amount, ch.txn, ch.notifyUrl);
        Fault f = faultOf(ch.mo);
        if (ch.notifyUrl == null || ch.notifyUrl.isEmpty()) return;
        if (f.holdCallbacks()) { held.add(n); return; }
        for (int i = 0; i < Math.max(1, f.callbackCopies()); i++) {
            long delay = f.callbackDelayMs() + i * 15L;
            sched.schedule(() -> deliverWithRetry(n, 0), delay, TimeUnit.MILLISECONDS);
        }
    }

    private void deliverWithRetry(Notice n, int attempt) {
        int code = deliver(n);
        if (code != 200 && attempt < 30) sched.schedule(() -> deliverWithRetry(n, attempt + 1), 100, TimeUnit.MILLISECONDS);
    }

    /** 发送一次回调，返回 HTTP 状态码（连接失败为 -1）。测试可直接调用以控制重复与顺序。 */
    public int deliver(Notice n) {
        callbacksSent.incrementAndGet();
        try {
            return Http.post(n.url(), n.form(), Duration.ofSeconds(5)).code();
        } catch (Exception e) {
            return -1;
        }
    }

    /** 取出被扣住的回调（按产生顺序），由测试决定何时、以什么顺序、发几次。 */
    public synchronized List<Notice> takeHeld(String mo) {
        List<Notice> out = new ArrayList<>();
        held.removeIf(n -> { if (n.merchantOrder().equals(mo)) { out.add(n); return true; } return false; });
        return out;
    }

    public synchronized List<String> statementLines() { return new ArrayList<>(statement); }

    public synchronized String statusOf(String mo) {
        Charge ch = charges.get(mo);
        return ch == null ? "NOT_FOUND" : ch.status;
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    @Override public void close() {
        http.stop(0);
        sched.shutdownNow();
    }
}
