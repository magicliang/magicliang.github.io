#!/usr/bin/env bash
# 第 28 章：稀缺名额的准入与库存预留。一条命令完成集群启动、建库、编译、全部用例与证据落盘。
# 只编译 lab.common 与 lab.flash.reserve，构建目录与第 29 章隔离（两章共用本项目目录）。
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
B3=$(cd "$HERE/../.." && pwd)
COMMON="$B3/examples/common"
EV="$B3/evidence/28"
PORT=55428; NAME=b3-28; DB=flash28
JDBC=${JDBC_JAR:-$HOME/.m2/repository/org/postgresql/postgresql/42.7.7/postgresql-42.7.7.jar}
OUT=/tmp/batch3-build/flash-sale-28
mkdir -p "$EV" "$OUT"
export LAB_PGPORT=$PORT LAB_DB=$DB

cat > "$EV/commands.txt" <<CMD
cd $HERE && ./run-28.sh
  PGBIN=/tmp/batch3-pgbin-28 $COMMON/pg.sh start $NAME $PORT   (initdb 包装追加 -c dynamic_shared_memory_type=mmap，原因见 run-28.sh 注释)
  createdb via lab.common.Db.recreate($DB)
  javac -d $OUT/classes -cp postgresql-42.7.7.jar  (examples/common/src + src/lab/flash/reserve)
  java -cp $OUT/classes:postgresql-42.7.7.jar lab.flash.reserve.Ch28Main > evidence/28/output.txt
  (C28-09 / C28-11 由 Ch28Main 启动子 JVM lab.flash.reserve.ReleaseWorker，并用 kill -9 <pid> 终止)
  $COMMON/pg.sh stop $NAME
CMD

{
  echo "date: $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
  echo "uname: $(uname -a)"
  echo "java:"; java -version 2>&1 | sed 's/^/  /'
  echo "postgres: $(/usr/lib/postgresql/16/bin/postgres --version)"
  echo "pgjdbc: $(basename "$JDBC")"
  echo "cluster: $NAME port=$PORT db=$DB (initdb -A trust, fsync=on, max_connections=200, dynamic_shared_memory_type=mmap)"
  echo "dev_shm: $(df -h /dev/shm | tail -1)"
} > "$EV/env.txt"

# 本机 /dev/shm 只有 64MB 且被占满时，initdb 的动态共享内存段无法创建。
# pg.sh 允许用 PGBIN 指定二进制目录；这里放一层只给 initdb 追加 dynamic_shared_memory_type=mmap 的包装，
# 其余命令原样转发。mmap 类型把动态共享内存放在数据目录的 pg_dynshmem 下，不改变事务、锁与 WAL 语义。
REALBIN=/usr/lib/postgresql/16/bin
WRAP=/tmp/batch3-pgbin-28
mkdir -p "$WRAP"
printf '#!/bin/sh\nexec %s/initdb -c dynamic_shared_memory_type=mmap "$@"\n' "$REALBIN" > "$WRAP/initdb"
printf '#!/bin/sh\nexec %s/pg_ctl "$@"\n' "$REALBIN" > "$WRAP/pg_ctl"
chmod +x "$WRAP/initdb" "$WRAP/pg_ctl"
export PGBIN=$WRAP

trap '"$COMMON/pg.sh" stop $NAME' EXIT
"$COMMON/pg.sh" start $NAME $PORT

{ find "$COMMON/src" -name '*.java'; find "$HERE/src/lab/flash/reserve" -name '*.java'; } > "$OUT/sources.txt"
rm -rf "$OUT/classes"
javac -encoding UTF-8 -Xlint:none -d "$OUT/classes" -cp "$JDBC" @"$OUT/sources.txt"
set +e
java -cp "$OUT/classes:$JDBC" lab.flash.reserve.Ch28Main > "$EV/output.txt" 2>&1
rc=$?
set -e
tail -n 3 "$EV/output.txt"
echo "exit=$rc"
exit $rc
