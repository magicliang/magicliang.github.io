package lab.flash.order;

import java.sql.Connection;
import java.time.Duration;
import lab.common.Db;

/**
 * 独立 JVM 中执行一步订单操作并在关键位置停住，供 kill -9 实验使用。
 * 参数：mode channelBase consumerUrl orderId [notifyUrl]
 *   pay-stall      CREATED→PAYING 已提交，渠道已扣款并应答 CHARGED；打印 STAGE 后停住（尚未记账）
 *   apply-stall    在成功通知的事务里完成确认预留、PAID 迁移与 outbox 插入，提交前打印 STAGE 后停住
 *   relay-stall    中继把一批事件投递给消费者并在事务内标记，提交前打印 STAGE 后停住
 *   dualwrite-stall 错误写法：PAID 已提交（无 outbox），通知消费者之前打印 STAGE 后停住
 */
public final class OrderWorker {
    public static void main(String[] args) throws Exception {
        String mode = args[0], channelBase = args[1], consumerUrl = args[2], id = args.length > 3 ? args[3] : "";
        String notify = args.length > 4 ? args[4] : "";
        OrderService svc = new OrderService(new ChannelClient(channelBase), notify, 60_000);
        Tx.Hook stall = () -> {
            System.out.println("STAGE " + mode + " reached");
            System.out.flush();
            try { Thread.sleep(60_000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        };
        try (Connection c = Db.connect()) {
            Db.exec(c, "SET application_name = 'b3-29-worker'");
            switch (mode) {
                case "pay-stall" -> {
                    int amount = svc.beginPay(c, id);
                    Http.Resp r = svc.channel().charge(id, amount, notify, Duration.ofSeconds(5));
                    System.out.println("channel replied " + r.raw());
                    stall.run();
                    svc.applyChannelResult(c, id, r.get("result"), amount, r.get("txn"), "charge reply", Duration.ofSeconds(5));
                }
                case "apply-stall" -> {
                    Http.Resp q = svc.channel().query(id, Duration.ofSeconds(5));
                    int amount = Integer.parseInt(q.get("amount"));
                    System.out.println("effect " + svc.onCharged(c, id, amount, q.get("txn"), "worker", stall));
                }
                case "relay-stall" -> System.out.println("sent " + Relay.relayOnce(c, consumerUrl, 50, stall));
                case "dualwrite-stall" -> Negative.dualWritePaid(c, id, consumerUrl, () -> {
                    try { stall.run(); } catch (Exception e) { throw new RuntimeException(e); }
                });
                default -> throw new IllegalArgumentException(mode);
            }
            System.out.println("STAGE done");
        }
    }
}
