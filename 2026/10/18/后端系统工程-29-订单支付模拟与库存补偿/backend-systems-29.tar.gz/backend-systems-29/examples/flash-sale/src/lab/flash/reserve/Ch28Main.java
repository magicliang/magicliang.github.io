package lab.flash.reserve;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import lab.common.Check;
import lab.common.Db;

/** 第 28 章全部用例。每个用例从空 schema 开始，库存 SKU 固定为 sku-lab-01。 */
public final class Ch28Main {
    static final String SKU = "sku-lab-01";

    interface Body { void run(int i, Connection c) throws Exception; }

    public static void main(String[] args) throws Exception {
        Db.recreate(System.getenv().getOrDefault("LAB_DB", "flash28"));
        normalPath();
        admissionBoundary();
        hotRowOverload();
        duplicateAndUserLimit();
        httpOverload();
        clientDisconnect();
        expiryReplay();
        confirmVersusExpire();
        crashAtomicWorker();
        negativeUnconditionalRelease();
        negativeTwoStepCrash();
        negativeCheckThenInsert();
        schemeComparison();
        skipLockedFalseSoldOut();
        memoryRestart();
        System.exit(Check.finish());
    }

    // ---------- helpers ----------

    static void reset(int total) throws SQLException {
        try (Connection c = Db.connect()) {
            Db.exec(c, "DROP SCHEMA IF EXISTS public CASCADE; CREATE SCHEMA public;");
            Db.exec(c, Inventory.SCHEMA);
            Db.exec(c, Schemes.SCHEMA);
            Db.exec(c, Negative.NOUNIQ_SCHEMA);
            if (total >= 0) Inventory.addSku(c, SKU, total);
        }
    }

    /** n 个真实线程，各自持有一条连接，在同一个闸门后同时开始。 */
    static void concurrently(int n, Body body) throws Exception {
        CountDownLatch ready = new CountDownLatch(n), go = new CountDownLatch(1), done = new CountDownLatch(n);
        AtomicReference<Throwable> err = new AtomicReference<>();
        for (int i = 0; i < n; i++) {
            final int id = i;
            Thread t = new Thread(() -> {
                try (Connection c = Db.connect()) {
                    ready.countDown();
                    go.await();
                    body.run(id, c);
                } catch (Throwable e) {
                    err.compareAndSet(null, e);
                } finally {
                    done.countDown();
                }
            });
            t.start();
        }
        ready.await();
        go.countDown();
        if (!done.await(120, TimeUnit.SECONDS)) throw new IllegalStateException("threads did not finish");
        if (err.get() != null) throw new RuntimeException("worker failed", err.get());
    }

    static void ageAll(Connection c, String where) throws SQLException {
        // 可控时钟：把指定预留的 expires_at 移到过去，等价于“时间流逝到期”，不依赖 sleep。
        Db.update(c, "UPDATE reservation SET expires_at = now() - interval '1 second' WHERE " + where);
    }

    static Long[] ids(Connection c, String where) throws SQLException {
        List<Long> out = new ArrayList<>();
        try (var ps = c.prepareStatement("SELECT reservation_id FROM reservation WHERE " + where + " ORDER BY 1");
             var rs = ps.executeQuery()) {
            while (rs.next()) out.add(rs.getLong(1));
        }
        return out.toArray(new Long[0]);
    }

    static Map<String, Long> statusCounts(Connection c) throws SQLException {
        Map<String, Long> m = new TreeMap<>();
        try (var ps = c.prepareStatement("SELECT status, count(*) FROM reservation GROUP BY status");
             var rs = ps.executeQuery()) {
            while (rs.next()) m.put(rs.getString(1), rs.getLong(2));
        }
        return m;
    }

    static String user(int i) { return String.format("user-%04d", i); }

    // ---------- 正常路径 ----------

    static void normalPath() throws Exception {
        Check.begin("C28-01", "正常路径：预留、同键重放、确认、按 request_key 查询");
        reset(3);
        try (Connection c = Db.connect()) {
            Inventory.Hold h = Inventory.reserve(c, "req-0001", user(1), SKU, 60_000);
            Check.equal("HELD", h.outcome(), "首次预留");
            Inventory.Hold r = Inventory.reserve(c, "req-0001", user(1), SKU, 60_000);
            Check.equal("REPLAY", r.outcome(), "同一 request_key 重放");
            Check.equal(h.reservationId(), r.reservationId(), "重放返回同一预留");
            Check.equal(2L, Inventory.available(c, SKU), "库存只扣一次");
            Inventory.Hold k = Inventory.reserve(c, "req-0001", user(2), SKU, 60_000);
            Check.equal("KEY_REUSED", k.outcome(), "同键不同用户被拒绝");
            Check.that(Inventory.confirm(c, "req-0001"), "未到期的 HELD 可以确认");
            Check.that(!Inventory.confirm(c, "req-0001"), "重复确认不再迁移");
            Check.equal("CONFIRMED", Inventory.status(c, "req-0001"), "查询状态");
            Check.equal(0, Inventory.release(c, "req-0001"), "已确认的预留不能被取消归还");
            Check.equal(0L, Inventory.drift(c, SKU), "守恒 total-available-active");
        }
    }

    // ---------- 准入边界（确定性调度） ----------

    static void admissionBoundary() throws Exception {
        Check.begin("C28-02", "准入边界：上限 2、排队位 1；排满即拒、等待超时、等待后进入");
        Admission a = new Admission(2, 1, 300);
        Check.equal(Admission.Ticket.ADMITTED, a.enter(), "第 1 个直接进入");
        Check.equal(Admission.Ticket.ADMITTED, a.enter(), "第 2 个直接进入");
        CompletableFuture<Admission.Ticket> waiter = CompletableFuture.supplyAsync(() -> {
            try { return a.enter(); } catch (InterruptedException e) { throw new RuntimeException(e); }
        });
        while (a.waitingNow() < 1) Thread.sleep(5);
        Check.equal(Admission.Ticket.REJECTED_QUEUE_FULL, a.enter(), "排队位已满时第 4 个立即拒绝");
        Check.equal(Admission.Ticket.REJECTED_WAIT_TIMEOUT, waiter.get(), "无人退出时等待者超时被拒");
        CompletableFuture<Admission.Ticket> waiter2 = CompletableFuture.supplyAsync(() -> {
            try { return a.enter(); } catch (InterruptedException e) { throw new RuntimeException(e); }
        });
        while (a.waitingNow() < 1) Thread.sleep(5);
        a.exit();
        Check.equal(Admission.Ticket.ADMITTED_AFTER_WAIT, waiter2.get(), "有人退出后等待者进入");
        a.exit(); a.exit();
        Check.equal(Admission.Ticket.ADMITTED, a.enter(), "全部退出后重新可进入");
        a.exit();
        Check.note("counters " + a.counters());
        Check.equal(2, a.maxInFlightSeen.get(), "同时在内的请求从未超过上限");
    }

    // ---------- 超额并发：单热点行 ----------

    static void hotRowOverload() throws Exception {
        Check.begin("C28-03", "超额并发：150 个线程争 40 件，单热点行条件扣减");
        reset(40);
        Map<String, AtomicInteger> out = new ConcurrentHashMap<>();
        concurrently(150, (i, c) -> {
            Inventory.Hold h = Inventory.reserve(c, "req-" + i, user(i), SKU, 60_000);
            out.computeIfAbsent(h.outcome(), k -> new AtomicInteger()).incrementAndGet();
        });
        try (Connection c = Db.connect()) {
            Check.note("outcomes " + new TreeMap<>(out));
            Check.equal(40, out.get("HELD").get(), "成功数等于库存");
            Check.equal(110, out.get("SOLD_OUT").get(), "其余全部售罄");
            Check.equal(0L, Inventory.available(c, SKU), "最终库存 0");
            Check.equal(40L, Inventory.active(c, SKU), "有效预留 40 行");
            Check.equal(0L, Inventory.drift(c, SKU), "守恒");
            Check.note("COUNT C28-03 success=40 sold_out=" + out.get("SOLD_OUT") + " final_available=" + Inventory.available(c, SKU));
        }
    }

    // ---------- 重复请求与每用户一个有效预留 ----------

    static void duplicateAndUserLimit() throws Exception {
        Check.begin("C28-04", "重复：16 线程同一 request_key；8 线程同一用户不同 key");
        reset(10);
        Map<String, AtomicInteger> same = new ConcurrentHashMap<>();
        concurrently(16, (i, c) -> {
            Inventory.Hold h = Inventory.reserve(c, "req-dup", user(7), SKU, 60_000);
            same.computeIfAbsent(h.outcome(), k -> new AtomicInteger()).incrementAndGet();
        });
        Map<String, AtomicInteger> perUser = new ConcurrentHashMap<>();
        concurrently(8, (i, c) -> {
            Inventory.Hold h = Inventory.reserve(c, "req-u8-" + i, user(8), SKU, 60_000);
            perUser.computeIfAbsent(h.outcome(), k -> new AtomicInteger()).incrementAndGet();
        });
        try (Connection c = Db.connect()) {
            Check.note("same key " + new TreeMap<>(same) + " ; same user " + new TreeMap<>(perUser));
            Check.equal(1, same.get("HELD").get(), "同键只有一个 HELD");
            Check.equal(15, same.get("REPLAY").get(), "其余 15 个是 REPLAY");
            Check.equal(1, perUser.get("HELD").get(), "同用户只有一个 HELD");
            Check.equal(7, perUser.get("USER_LIMIT").get(), "其余 7 个撞上部分唯一索引");
            Check.equal(8L, Inventory.available(c, SKU), "库存只扣 2 件");
            Inventory.release(c, Db.queryString(c, "SELECT request_key FROM reservation WHERE user_id = ? AND status='HELD'", user(8)));
            Inventory.Hold again = Inventory.reserve(c, "req-u8-new", user(8), SKU, 60_000);
            Check.equal("HELD", again.outcome(), "释放后同一用户可以再次预留");
            Check.equal(0L, Inventory.drift(c, SKU), "守恒");
        }
    }

    // ---------- HTTP 入口过载：准入计数 ----------

    static HttpResponse<String> post(HttpClient cl, int port, String key, String user) throws Exception {
        return cl.send(postReq(port, key, user), HttpResponse.BodyHandlers.ofString());
    }

    static HttpRequest postReq(int port, String key, String user) {
        String body = "request_key=" + key + "&user=" + user + "&sku=" + SKU + "&ttl_ms=60000";
        return HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + "/reserve"))
            .header("Content-Type", "application/x-www-form-urlencoded")
            .timeout(Duration.ofSeconds(30))
            .POST(HttpRequest.BodyPublishers.ofString(body)).build();
    }

    static void httpOverload() throws Exception {
        Check.begin("C28-05", "HTTP 过载：120 个客户端同时到达，准入上限 4、排队位 8、等待 400ms、处理 30ms，库存 30；"
            + "收到 503 的客户端用同一 request_key 退避重试，直到得到 201 或 409");
        reset(30);
        try (Connection warm = Db.connect()) { Inventory.available(warm, SKU); }   // 预加载驱动，避免首个连接的类加载占用等待窗口
        Admission adm = new Admission(4, 8, 400);
        try (ReserveServer srv = new ReserveServer(adm)) {
            srv.processDelayMs = 30;
            HttpClient cl = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1).build();
            Map<Integer, AtomicInteger> finalCodes = new ConcurrentHashMap<>();
            AtomicInteger got503 = new AtomicInteger(), firstTry503 = new AtomicInteger(), unresolved = new AtomicInteger();
            concurrentlyNoDb(120, i -> {
                for (int attempt = 1; attempt <= 60; attempt++) {
                    int code = post(cl, srv.port(), "req-h" + i, user(100 + i)).statusCode();
                    if (code != 503) { finalCodes.computeIfAbsent(code, k -> new AtomicInteger()).incrementAndGet(); return; }
                    got503.incrementAndGet();
                    if (attempt == 1) firstTry503.incrementAndGet();
                    Thread.sleep(20L * Math.min(attempt, 10));
                }
                unresolved.incrementAndGet();
            });
            try (Connection c = Db.connect()) {
                int c201 = finalCodes.getOrDefault(201, new AtomicInteger()).get();
                int c409 = finalCodes.getOrDefault(409, new AtomicInteger()).get();
                int admittedTotal = adm.admitted.get() + adm.admittedAfterWait.get();
                int rejectedTotal = adm.rejectedQueueFull.get() + adm.rejectedWaitTimeout.get();
                Check.note("final http codes " + new TreeMap<>(finalCodes) + " first_try_503=" + firstTry503 + " all_503=" + got503);
                Check.note("admission " + adm.counters());
                Check.equal(0, unresolved.get(), "每个客户端最终得到 201 或 409");
                Check.equal(30, c201, "最终成功数等于库存 30");
                Check.equal(90, c409, "其余 90 个得到售罄");
                Check.equal(got503.get(), rejectedTotal, "503 次数等于准入拒绝计数");
                Check.equal(120, admittedTotal, "被准入的请求恰好 120 次（每个客户端一次）");
                Check.that(adm.maxInFlightSeen.get() <= 4, "同时处理数不超过 4（实际 " + adm.maxInFlightSeen + "）");
                Check.that(adm.maxWaitingSeen.get() <= 8, "同时等待数不超过 8（实际 " + adm.maxWaitingSeen + "）");
                Check.that(firstTry503.get() > 0, "首轮过载时确有快速拒绝");
                Check.that(adm.admittedAfterWait.get() > 0, "确有请求在等待后进入");
                Check.equal(30L, Inventory.active(c, SKU), "库中有效预留 30 行");
                Check.equal(0L, Inventory.available(c, SKU), "最终库存 0");
                Check.equal(0L, Inventory.drift(c, SKU), "守恒");
                Check.note("COUNT C28-05 success=" + c201 + " sold_out=" + c409 + " rejected_503=" + got503
                    + " admitted_after_wait=" + adm.admittedAfterWait + " final_available=" + Inventory.available(c, SKU)
                    + " (rejected/wait counts depend on scheduling)");
            }
        }
    }

    interface ClientBody { void run(int i) throws Exception; }

    static void concurrentlyNoDb(int n, ClientBody body) throws Exception {
        CountDownLatch go = new CountDownLatch(1), done = new CountDownLatch(n);
        AtomicReference<Throwable> err = new AtomicReference<>();
        for (int i = 0; i < n; i++) {
            final int id = i;
            Thread.ofPlatform().start(() -> {
                try { go.await(); body.run(id); }
                catch (Throwable e) { err.compareAndSet(null, e); }
                finally { done.countDown(); }
            });
        }
        go.countDown();
        if (!done.await(120, TimeUnit.SECONDS)) throw new IllegalStateException("clients did not finish");
        if (err.get() != null) throw new RuntimeException("client failed", err.get());
    }

    // ---------- 客户端断开 ----------

    static void clientDisconnect() throws Exception {
        Check.begin("C28-06", "客户端断开：请求发出 100ms 后关闭连接，服务端处理需 600ms");
        reset(5);
        Admission adm = new Admission(4, 8, 1000);
        try (ReserveServer srv = new ReserveServer(adm)) {
            srv.processDelayMs = 600;
            String body = "request_key=req-gone&user=" + user(42) + "&sku=" + SKU + "&ttl_ms=60000";
            try (Socket s = new Socket("127.0.0.1", srv.port())) {
                OutputStream os = s.getOutputStream();
                os.write(("POST /reserve HTTP/1.1\r\nHost: shop.example.test\r\n"
                    + "Content-Type: application/x-www-form-urlencoded\r\nContent-Length: " + body.length()
                    + "\r\nConnection: close\r\n\r\n" + body).getBytes(StandardCharsets.UTF_8));
                os.flush();
                Thread.sleep(100);
            } // 关闭连接，未读取任何响应
            HttpClient cl = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1).build();
            HttpRequest q = HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + srv.port() + "/reservations/req-gone")).build();
            String first = cl.send(q, HttpResponse.BodyHandlers.ofString()).body();
            Check.note("query right after disconnect: " + first);
            String st = first;
            for (int i = 0; i < 100 && !st.equals("status=HELD"); i++) {
                Thread.sleep(50);
                st = cl.send(q, HttpResponse.BodyHandlers.ofString()).body();
            }
            Check.equal("status=HELD", st, "断开后服务端照常完成，凭 request_key 查到 HELD");
            Check.equal(1, srv.processed.get(), "服务端完整处理了 1 次");
            HttpResponse<String> retry = post(cl, srv.port(), "req-gone", user(42));
            Check.equal(200, retry.statusCode(), "客户端用同一 request_key 重试得到 200");
            Check.that(retry.body().startsWith("outcome=REPLAY"), "重试结果是 REPLAY：" + retry.body());
            try (Connection c = Db.connect()) {
                Check.equal(4L, Inventory.available(c, SKU), "库存只扣 1 件");
                Check.equal(0L, Inventory.drift(c, SKU), "守恒");
            }
            HttpResponse<String> bad = cl.send(HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + srv.port() + "/reserve"))
                .POST(HttpRequest.BodyPublishers.ofString("user=x")).build(), HttpResponse.BodyHandlers.ofString());
            Check.equal(400, bad.statusCode(), "缺少 request_key 的请求被拒绝");
        }
    }

    // ---------- 到期释放与重放 ----------

    static void expiryReplay() throws Exception {
        Check.begin("C28-07", "到期释放：20 个 HELD 中 8 个到期；释放执行一次、重放一次、4 线程并发重放");
        reset(20);
        try (Connection c = Db.connect()) {
            for (int i = 0; i < 20; i++) Inventory.reserve(c, "req-e" + i, user(200 + i), SKU, 60_000);
            ageAll(c, "request_key IN (" + String.join(",", java.util.stream.IntStream.range(0, 8)
                .mapToObj(i -> "'req-e" + i + "'").toList()) + ")");
            Check.equal(8, Inventory.expire(c, null), "第一次释放归还 8 件");
            Check.equal(0, Inventory.expire(c, null), "立即重放归还 0 件");
            AtomicInteger sum = new AtomicInteger();
            concurrently(4, (i, cc) -> sum.addAndGet(Inventory.expire(cc, null)));
            Check.equal(0, sum.get(), "4 线程并发重放合计归还 0 件");
            ageAll(c, "status = 'HELD'");
            AtomicInteger sum2 = new AtomicInteger();
            concurrently(4, (i, cc) -> sum2.addAndGet(Inventory.expire(cc, null)));
            Check.equal(12, sum2.get(), "剩余 12 个到期后由 4 线程并发释放，合计恰好归还 12 件");
            Check.equal(20L, Inventory.available(c, SKU), "库存全部回到 20");
            Check.note("status " + statusCounts(c));
            Check.equal(0L, Inventory.drift(c, SKU), "守恒");
        }
    }

    // ---------- 确认与到期竞争 ----------

    static void confirmVersusExpire() throws Exception {
        Check.begin("C28-08", "确认与到期释放竞争：40 个已到期 HELD，确认线程与释放线程同时处理");
        reset(40);
        try (Connection c = Db.connect()) {
            for (int i = 0; i < 40; i++) Inventory.reserve(c, "req-r" + i, user(300 + i), SKU, 60_000);
            ageAll(c, "true");
        }
        AtomicInteger confirmed = new AtomicInteger(), returned = new AtomicInteger();
        concurrently(2, (i, c) -> {
            if (i == 0) {
                for (int k = 0; k < 40; k++) if (Inventory.confirmHeldInTx(c, "req-r" + k)) confirmed.incrementAndGet();
            } else {
                for (int k = 39; k >= 0; k--) returned.addAndGet(Inventory.expire(c, new Long[] {(long) (k + 1)}));
            }
        });
        try (Connection c = Db.connect()) {
            Map<String, Long> st = statusCounts(c);
            Check.note("confirmed=" + confirmed + " returned=" + returned + " status " + st);
            Check.equal(40, confirmed.get() + returned.get(), "每个预留恰好被一方处理");
            Check.equal((long) returned.get(), st.getOrDefault("EXPIRED", 0L), "归还件数等于 EXPIRED 行数");
            Check.equal((long) returned.get(), Inventory.available(c, SKU), "库存只为 EXPIRED 行归还");
            Check.equal(0L, Inventory.drift(c, SKU), "守恒");
        }
    }

    // ---------- 多进程：释放任务被 kill -9 ----------

    static Process startWorker(String mode) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(
            System.getProperty("java.home") + "/bin/java", "-cp", System.getProperty("java.class.path"),
            "lab.flash.reserve.ReleaseWorker", mode);
        pb.redirectErrorStream(true);
        return pb.start();
    }

    static String awaitStage(Process p) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
        String line;
        while ((line = r.readLine()) != null) {
            Check.note("worker pid=" + p.pid() + " says: " + line);
            if (line.startsWith("STAGE")) return line;
        }
        return null;
    }

    static int kill9(Process p) throws Exception {
        new ProcessBuilder("kill", "-9", Long.toString(p.pid())).inheritIO().start().waitFor();
        return p.waitFor();
    }

    static void awaitWorkerBackendsGone(Connection c) throws Exception {
        for (int i = 0; i < 200; i++) {
            if (Db.queryLong(c, "SELECT count(*) FROM pg_stat_activity WHERE application_name = 'b3-28-release-worker'") == 0) return;
            Thread.sleep(50);
        }
        throw new IllegalStateException("worker backend still present");
    }

    static void seedExpired(Connection c, int total, int expired) throws SQLException {
        for (int i = 0; i < total; i++) Inventory.reserve(c, "req-k" + i, user(400 + i), SKU, 60_000);
        ageAll(c, "reservation_id <= " + expired);
    }

    static void crashAtomicWorker() throws Exception {
        Check.begin("C28-09", "多进程：原子释放任务在提交前被 kill -9，再重放两次");
        reset(10);
        try (Connection c = Db.connect()) {
            seedExpired(c, 10, 5);
            Process p = startWorker("atomic");
            String stage = awaitStage(p);
            Check.equal("STAGE uncommitted returned=5", stage, "子进程已执行释放语句但未提交");
            Check.equal(0L, Inventory.available(c, SKU), "未提交时外部看不到归还");
            int code = kill9(p);
            Check.equal(137, code, "子进程被 SIGKILL 终止（退出码 128+9）");
            awaitWorkerBackendsGone(c);
            Check.equal(5L, Db.queryLong(c, "SELECT count(*) FROM reservation WHERE status='HELD' AND expires_at < now()"),
                "数据库回滚未提交事务，5 个到期预留仍是 HELD");
            Check.equal(0L, Inventory.available(c, SKU), "库存没有被归还");
            Check.equal(5, Inventory.expire(c, null), "重放：归还 5 件");
            Check.equal(0, Inventory.expire(c, null), "再次重放：归还 0 件");
            int won = 0;
            for (int i = 0; i < 10; i++)
                if (Inventory.reserve(c, "req-k2-" + i, user(500 + i), SKU, 60_000).outcome().equals("HELD")) won++;
            Check.note("COUNT C28-09 extra_success=" + won + " active=" + Inventory.active(c, SKU) + " total=10");
            Check.equal(5, won, "10 个补抢请求只有 5 个成功");
            Check.equal(10L, Inventory.active(c, SKU), "有效预留 10，不超过库存");
            Check.equal(0L, Inventory.drift(c, SKU), "守恒");
        }
    }

    // ---------- 负向对照 ----------

    static void negativeUnconditionalRelease() throws Exception {
        Check.begin("C28-10", "负向对照：释放不检查状态、无条件归还，重放后补抢");
        reset(10);
        try (Connection c = Db.connect()) {
            seedExpired(c, 10, 5);
            Long[] due = ids(c, "status='HELD' AND expires_at < now()");
            Negative.unconditionalExpire(c, SKU, due);
            Negative.unconditionalExpire(c, SKU, due);   // 释放任务被重放
            Check.note("after replay available=" + Inventory.available(c, SKU) + " active=" + Inventory.active(c, SKU));
            int won = 0;
            for (int i = 0; i < 10; i++)
                if (Inventory.reserve(c, "req-n" + i, user(600 + i), SKU, 60_000).outcome().equals("HELD")) won++;
            long active = Inventory.active(c, SKU);
            Check.note("COUNT C28-10 extra_success=" + won + " active=" + active + " total=10");
            Check.exposes(active > 10, "有效预留 " + active + " 超过库存 10（超卖）");
            Check.exposes(Inventory.drift(c, SKU) != 0, "守恒检查发现偏差 " + Inventory.drift(c, SKU));
        }
    }

    static void negativeTwoStepCrash() throws Exception {
        Check.begin("C28-11", "负向对照（多进程）：先归还库存并提交、再改状态；两步之间 kill -9，重放后补抢");
        reset(10);
        try (Connection c = Db.connect()) {
            seedExpired(c, 10, 5);
            Process p = startWorker("twostep");
            String stage = awaitStage(p);
            Check.equal("STAGE stock-returned returned=5", stage, "子进程已提交归还、尚未改状态");
            Check.equal(137, kill9(p), "子进程被 SIGKILL 终止");
            awaitWorkerBackendsGone(c);
            Process replay = startWorker("twostep-run");
            new BufferedReader(new InputStreamReader(replay.getInputStream(), StandardCharsets.UTF_8))
                .lines().forEach(l -> Check.note("replay worker says: " + l));
            Check.equal(0, replay.waitFor(), "重放进程正常结束");
            int won = 0;
            for (int i = 0; i < 10; i++)
                if (Inventory.reserve(c, "req-t" + i, user(700 + i), SKU, 60_000).outcome().equals("HELD")) won++;
            long active = Inventory.active(c, SKU);
            Check.note("COUNT C28-11 extra_success=" + won + " active=" + active + " total=10");
            Check.exposes(active > 10, "有效预留 " + active + " 超过库存 10（超卖）");
        }
    }

    static void negativeCheckThenInsert() throws Exception {
        Check.begin("C28-12", "负向对照：先查该用户有无有效预留再插入，无部分唯一索引");
        reset(10);
        CyclicBarrier bothChecked = new CyclicBarrier(2);
        AtomicInteger inserted = new AtomicInteger();
        concurrently(2, (i, c) -> {
            c.setAutoCommit(false);
            boolean has = Negative.userHasActive(c, user(9), SKU);
            bothChecked.await(10, TimeUnit.SECONDS);       // 两个事务都完成检查后再插入
            if (!has) { Negative.insertNoUniq(c, "req-c" + i, user(9), SKU); inserted.incrementAndGet(); }
            c.commit();
        });
        try (Connection c = Db.connect()) {
            long n = Db.queryLong(c, "SELECT count(*) FROM reservation_nouniq WHERE user_id = ? AND status = 'HELD'", user(9));
            Check.exposes(n == 2, "同一用户出现 " + n + " 个有效预留");
        }
        reset(10);
        AtomicInteger held = new AtomicInteger(), limited = new AtomicInteger();
        CyclicBarrier b2 = new CyclicBarrier(2);
        concurrently(2, (i, c) -> {
            b2.await(10, TimeUnit.SECONDS);
            String o = Inventory.reserve(c, "req-c" + i, user(9), SKU, 60_000).outcome();
            (o.equals("HELD") ? held : limited).incrementAndGet();
        });
        Check.equal(1, held.get(), "对照组：有部分唯一索引时只有 1 个 HELD");
        Check.equal(1, limited.get(), "对照组：另一个得到 USER_LIMIT");
    }

    // ---------- 方案比较 ----------

    static void schemeComparison() throws Exception {
        Check.begin("C28-13", "方案比较：同一输入（120 线程、40 件、每人一次）下 A 热点行 / B 名额行 SKIP LOCKED / C 内存先扣");
        // A
        reset(40);
        AtomicInteger aOk = new AtomicInteger();
        concurrently(120, (i, c) -> {
            if (Inventory.reserve(c, "req-a" + i, user(i), SKU, 60_000).outcome().equals("HELD")) aOk.incrementAndGet();
        });
        long aLeft;
        try (Connection c = Db.connect()) { aLeft = Inventory.available(c, SKU); Check.equal(0L, Inventory.drift(c, SKU), "A 守恒"); }
        // B
        reset(-1);
        try (Connection c = Db.connect()) { Schemes.addSlots(c, SKU, 40); }
        AtomicInteger bOk = new AtomicInteger(), bNone = new AtomicInteger();
        concurrently(120, (i, c) -> {
            c.setAutoCommit(false);
            if (Schemes.claimSlotInTx(c, SKU, "req-b" + i)) bOk.incrementAndGet(); else bNone.incrementAndGet();
            c.commit();
        });
        long bLeft, bDistinct;
        try (Connection c = Db.connect()) {
            bLeft = Schemes.freeSlots(c, SKU);
            bDistinct = Db.queryLong(c, "SELECT count(DISTINCT holder_key) FROM stock_slot WHERE holder_key IS NOT NULL");
        }
        // C
        reset(-1);
        Schemes.MemoryNode n1 = new Schemes.MemoryNode("node-1", 20), n2 = new Schemes.MemoryNode("node-2", 20);
        AtomicInteger cOk = new AtomicInteger();
        concurrently(120, (i, c) -> {
            if ((i % 2 == 0 ? n1 : n2).sell(c, SKU, "req-c" + i)) cOk.incrementAndGet();
        });
        long cSold;
        try (Connection c = Db.connect()) { cSold = Schemes.memSold(c, SKU); }
        Check.note("COUNT C28-13 A success=" + aOk + " left=" + aLeft);
        Check.note("COUNT C28-13 B success=" + bOk + " no_slot=" + bNone + " left=" + bLeft + " distinct_holders=" + bDistinct);
        Check.note("COUNT C28-13 C success=" + cOk + " ledger_rows=" + cSold + " mem_left=" + (n1.remaining() + n2.remaining()));
        Check.equal(40, aOk.get(), "A 成功 40");
        Check.equal(40, bOk.get(), "B 成功 40");
        Check.equal(40L, bDistinct, "B 每个名额行最多一个持有者");
        Check.equal(40, cOk.get(), "C 正常运行时成功 40");
        Check.equal(40L, cSold, "C 销售记录 40 行");
    }

    static void skipLockedFalseSoldOut() throws Exception {
        Check.begin("C28-14", "边界：未提交的占用使 B 跳过名额行而报“无名额”，A 则等待后成功");
        reset(-1);
        try (Connection c = Db.connect()) { Schemes.addSlots(c, SKU, 2); }
        try (Connection t1 = Db.connect(); Connection t2 = Db.connect(); Connection t3 = Db.connect()) {
            t1.setAutoCommit(false);
            Check.that(Schemes.claimSlotInTx(t1, SKU, "req-s1"), "t1 占用 1 号名额（未提交）");
            t2.setAutoCommit(false);
            Check.that(Schemes.claimSlotInTx(t2, SKU, "req-s2"), "t2 跳过被锁的 1 号，占用 2 号");
            t2.commit();
            t3.setAutoCommit(false);
            boolean got = Schemes.claimSlotInTx(t3, SKU, "req-s3");
            t3.commit();
            Check.that(!got, "t3 看不到可锁的空名额，返回无名额");
            t1.rollback();
            Check.equal(1L, Schemes.freeSlots(t2, SKU), "t1 回滚后实际还剩 1 个名额");
        }
        reset(1);
        try (Connection t1 = Db.connect()) {
            t1.setAutoCommit(false);
            Check.equal("HELD", Inventory.reserveInTx(t1, "req-h1", user(1), SKU, 60_000).outcome(),
                "A：t1 预留最后 1 件（未提交，持有热点行锁）");
            CompletableFuture<String> t3 = CompletableFuture.supplyAsync(() -> {
                try (Connection c = Db.connect()) {
                    return Inventory.reserve(c, "req-h3", user(3), SKU, 60_000).outcome();
                } catch (SQLException e) { throw new RuntimeException(e); }
            });
            Thread.sleep(300);
            Check.that(!t3.isDone(), "A：t3 在等待 t1 的行锁，没有提前返回售罄");
            t1.rollback();
            Check.equal("HELD", t3.get(10, TimeUnit.SECONDS), "A：t1 回滚后 t3 按最新行版本重新判断并成功");
            t1.setAutoCommit(true);
            Check.equal(0L, Inventory.drift(t1, SKU), "A 守恒");
        }
    }

    static void memoryRestart() throws Exception {
        Check.begin("C28-15", "负向对照：方案 C 节点重启按配置份额重置计数，对账发现超卖；按落库记录重算则不超卖");
        reset(-1);
        Schemes.MemoryNode n1 = new Schemes.MemoryNode("node-1", 20), n2 = new Schemes.MemoryNode("node-2", 20);
        try (Connection c = Db.connect()) {
            for (int i = 0; i < 25; i++) n1.sell(c, SKU, "req-m1-" + i);
            for (int i = 0; i < 25; i++) n2.sell(c, SKU, "req-m2-" + i);
            Check.equal(40L, Schemes.memSold(c, SKU), "重启前售出 40");
            n1.restartFromConfig();
            int extra = 0;
            for (int i = 0; i < 25; i++) if (n1.sell(c, SKU, "req-m3-" + i)) extra++;
            long sold = Schemes.memSold(c, SKU);
            Check.note("COUNT C28-15 extra_after_restart=" + extra + " ledger_rows=" + sold + " total=40");
            Check.exposes(sold > 40, "对账：销售记录 " + sold + " 行超过库存 40");
        }
        reset(-1);
        n1 = new Schemes.MemoryNode("node-1", 20);
        try (Connection c = Db.connect()) {
            for (int i = 0; i < 25; i++) n1.sell(c, SKU, "req-m1-" + i);
            n1.restartFromLedger(c, SKU);
            int extra = 0;
            for (int i = 0; i < 25; i++) if (n1.sell(c, SKU, "req-m3-" + i)) extra++;
            Check.equal(0, extra, "按落库记录重算后重启不再多卖");
            Check.equal(20L, Schemes.memSold(c, SKU), "node-1 销售记录仍为份额 20");
        }
    }
}
