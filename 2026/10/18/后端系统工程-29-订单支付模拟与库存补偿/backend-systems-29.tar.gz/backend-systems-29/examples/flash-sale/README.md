# flash-sale：第 28–29 章共用项目

## 第 28 章 稀缺名额的准入与库存预留（包 `lab.flash.reserve`）

- 入口：`./run-28.sh`（端口 55428，集群 b3-28，库 flash28），证据写入 `../../evidence/28/`。
- 只编译 `examples/common/src` 与 `src/lab/flash/reserve`，构建目录 `/tmp/batch3-build/flash-sale-28`，与第 29 章隔离。
- 关键文件：
  - `Admission.java`：进程内并发上限 + 有界排队位 + 等待超时。
  - `Inventory.java`：库存表、预留表、部分唯一索引；条件预留、确认、取消、到期释放（第 29 章复用）。
  - `ReserveServer.java`：`POST /reserve`、`GET /reservations/{request_key}`，每请求一个虚拟线程。
  - `Schemes.java`：方案 B（预拆分名额行 + SKIP LOCKED）、方案 C（进程内存计数 + 销售记录）。
  - `Negative.java`：负向对照（无条件归还、先查后插）。
  - `ReleaseWorker.java`：独立 JVM 释放任务，供 kill -9 实验使用。
  - `Ch28Main.java`：C28-01 至 C28-15 全部用例。
- 本机 `/dev/shm` 已满时，run-28.sh 给 initdb 追加 `dynamic_shared_memory_type=mmap`，见脚本注释与 `evidence/28/LIMITS.md`。

## 第 29 章 订单、支付模拟与库存补偿（包 `lab.flash.order`）

- 入口：`./run-29.sh`（端口 55429，集群 b3-29，库 flash29），证据写入 `../../evidence/29/`。
- 编译 `examples/common/src`、`src/lab/flash/reserve`（只读复用，未修改）与 `src/lab/flash/order`，构建目录 `${LAB_BUILD:-/tmp/batch3-build}/flash-sale-29`，与第 28 章隔离。
- 关键文件：
  - `OrderService.java`：订单表、迁移记录、回调记录、outbox；状态机（条件迁移 + `SELECT ... FOR UPDATE`），成功通知时确认预留 / 重新占用 / 转退款。
  - `FakeChannel.java`：假支付渠道（本地 HTTP 替身）：按商户订单号幂等扣款、查询、关单、按 refund_key 幂等退款、账本；故障注入（应答丢失、请求滞留、退款应答超时、回调重复/迟到/扣住）。
  - `ChannelClient.java`、`OrderServer.java`（下单、支付、查询、回调入口）、`Http.java`、`Tx.java`。
  - `Recovery.java`：UNKNOWN / 陈旧 PAYING 的查询与关单收敛、REFUNDING 同键重试、到期未支付订单取消。
  - `Relay.java`：outbox 中继（SKIP LOCKED，至少一次）；`Fulfillment.java`：下游消费者（event_id 去重 + 版本比较）。
  - `Reconcile.java`：渠道账本 × 订单 × 预留三方对账。
  - `Negative.java`：负向对照；`OrderWorker.java`：独立 JVM，供 kill -9 实验。
  - `Ch29Main.java`：C29-01 至 C29-19 全部用例。
