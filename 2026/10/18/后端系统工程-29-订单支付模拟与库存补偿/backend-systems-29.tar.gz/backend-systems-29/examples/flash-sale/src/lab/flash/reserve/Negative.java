package lab.flash.reserve;

import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import lab.common.Db;

/** 负向对照：故意去掉某一步检查的错误实现，只在测试中调用。 */
public final class Negative {
    private Negative() {}

    /** 错误：释放时不检查当前状态，按给定 id 无条件改成 EXPIRED 并按 id 个数归还库存。重放会重复归还。 */
    public static int unconditionalExpire(Connection c, String sku, Long[] ids) throws SQLException {
        return Inventory.inTx(c, () -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE reservation SET status = 'EXPIRED', updated_at = now() WHERE reservation_id = ANY (?)")) {
                Array arr = c.createArrayOf("bigint", ids);
                ps.setArray(1, arr);
                ps.executeUpdate();
            }
            Db.update(c, "UPDATE sku_stock SET available = available + ? WHERE sku = ?", ids.length, sku);
            return ids.length;
        });
    }

    /** 错误：先查“该用户是否已有有效预留”，再插入；没有部分唯一索引兜底。表 reservation_nouniq 不带该索引。 */
    public static final String NOUNIQ_SCHEMA = """
        CREATE TABLE reservation_nouniq (
          request_key text PRIMARY KEY,
          user_id     text NOT NULL,
          sku         text NOT NULL,
          status      text NOT NULL
        );
        """;

    public static boolean userHasActive(Connection c, String user, String sku) throws SQLException {
        return Db.queryLong(c, "SELECT count(*) FROM reservation_nouniq WHERE user_id = ? AND sku = ? "
            + "AND status IN ('HELD','CONFIRMED')", user, sku) > 0;
    }

    public static void insertNoUniq(Connection c, String key, String user, String sku) throws SQLException {
        Db.update(c, "INSERT INTO reservation_nouniq VALUES (?,?,?,'HELD')", key, user, sku);
    }
}
