package lab.flash.reserve;

import java.sql.Connection;
import java.util.List;
import lab.common.Db;

/**
 * 独立 JVM 中运行的释放任务，用于 kill -9 实验。
 *   atomic  : 在一个事务里执行 Inventory.EXPIRE_SQL，打印 STAGE uncommitted 后停住等待被杀。
 *   twostep : 错误写法。先查出到期 id，第一个事务只归还库存并提交，打印 STAGE stock-returned 后停住；
 *             第二个事务才把状态改为 EXPIRED。被杀在两步之间时，重放会再次归还。
 *   twostep-run : 同 twostep，但不停顿，完整执行两步（用于“重放”）。
 */
public final class ReleaseWorker {
    public static void main(String[] args) throws Exception {
        String mode = args[0];
        try (Connection c = Db.connect()) {
            Db.exec(c, "SET application_name = 'b3-28-release-worker'");
            c.setAutoCommit(false);
            if (mode.equals("atomic")) {
                int n = Inventory.expire(c, null);
                System.out.println("STAGE uncommitted returned=" + n);
                System.out.flush();
                Thread.sleep(60_000);
                c.commit();
                System.out.println("STAGE committed");
                return;
            }
            List<Long> ids = new java.util.ArrayList<>();
            try (var ps = c.prepareStatement(
                    "SELECT reservation_id FROM reservation WHERE status = 'HELD' AND expires_at < now() ORDER BY 1");
                 var rs = ps.executeQuery()) {
                while (rs.next()) ids.add(rs.getLong(1));
            }
            Db.update(c, "UPDATE sku_stock SET available = available + ? WHERE sku = 'sku-lab-01'", ids.size());
            c.commit();
            System.out.println("STAGE stock-returned returned=" + ids.size());
            System.out.flush();
            if (mode.equals("twostep")) Thread.sleep(60_000);
            try (var ps = c.prepareStatement(
                    "UPDATE reservation SET status = 'EXPIRED', updated_at = now() WHERE reservation_id = ANY (?)")) {
                ps.setArray(1, c.createArrayOf("bigint", ids.toArray(new Long[0])));
                ps.executeUpdate();
            }
            c.commit();
            System.out.println("STAGE status-updated");
        }
    }
}
