#!/usr/bin/env bash
# 第 29 章：订单、支付模拟与库存补偿。一条命令完成集群启动、建库、编译、全部用例与证据落盘。
# 编译 lab.common、lab.flash.reserve（第 28 章库存层，只读复用）与 lab.flash.order；构建目录与第 28 章隔离。
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
B3=$(cd "$HERE/../.." && pwd)
COMMON="$B3/examples/common"
EV="$B3/evidence/29"
PORT=55429; NAME=b3-29; DB=flash29
JDBC=${JDBC_JAR:-$HOME/.m2/repository/org/postgresql/postgresql/42.7.7/postgresql-42.7.7.jar}
OUT=${LAB_BUILD:-/tmp/batch3-build}/flash-sale-29
mkdir -p "$EV" "$OUT"
export LAB_PGPORT=$PORT LAB_DB=$DB

cat > "$EV/commands.txt" <<CMD
cd $HERE && ./run-29.sh
  $COMMON/pg.sh start $NAME $PORT        (pg.sh 的 initdb 已带 -c dynamic_shared_memory_type=mmap)
  createdb via lab.common.Db.recreate($DB)
  javac -d $OUT/classes -cp postgresql-42.7.7.jar  (examples/common/src + src/lab/flash/reserve + src/lab/flash/order)
  java -cp $OUT/classes:postgresql-42.7.7.jar lab.flash.order.Ch29Main > evidence/29/output.txt
  (C29-10/11/12/18/19 由 Ch29Main 启动子 JVM lab.flash.order.OrderWorker，并用 kill -9 <pid> 终止)
  $COMMON/pg.sh stop $NAME
CMD

{
  echo "date: $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
  echo "uname: $(uname -a)"
  echo "java:"; java -version 2>&1 | sed 's/^/  /'
  echo "postgres: $(/usr/lib/postgresql/16/bin/postgres --version)"
  echo "pgjdbc: $(basename "$JDBC")"
  echo "cluster: $NAME port=$PORT db=$DB (initdb -A trust, fsync=on, max_connections=200, dynamic_shared_memory_type=mmap)"
  echo "client timeout to fake channel: 300ms; reservation ttl: 60s (expiry simulated by moving expires_at into the past)"
} > "$EV/env.txt"

trap '"$COMMON/pg.sh" stop $NAME' EXIT
"$COMMON/pg.sh" start $NAME $PORT

{ find "$COMMON/src" -name '*.java'; find "$HERE/src/lab/flash/reserve" "$HERE/src/lab/flash/order" -name '*.java'; } > "$OUT/sources.txt"
rm -rf "$OUT/classes"
javac -encoding UTF-8 -Xlint:none -d "$OUT/classes" -cp "$JDBC" @"$OUT/sources.txt"
set +e
java -cp "$OUT/classes:$JDBC" lab.flash.order.Ch29Main > "$EV/output.txt" 2>&1
rc=$?
set -e
tail -n 3 "$EV/output.txt"
echo "exit=$rc"
exit $rc
