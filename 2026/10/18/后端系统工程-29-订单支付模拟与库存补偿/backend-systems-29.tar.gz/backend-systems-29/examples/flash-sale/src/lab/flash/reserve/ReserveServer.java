package lab.flash.reserve;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * POST /reserve  正文 request_key=..&user=..&sku=..&ttl_ms=..
 *   201 HELD / 200 REPLAY / 409 SOLD_OUT 或 USER_LIMIT / 422 KEY_REUSED / 503 准入拒绝
 * GET  /reservations/{request_key}  200 status=... / 404 NOT_FOUND
 * 服务端不监听客户端是否断开：请求一旦被准入，就完整执行事务；客户端之后凭 request_key 查询或重放。
 * 每个请求一个虚拟线程，排队只发生在 Admission 内部，避免固定线程池背后的无界队列绕过准入上限。
 */
public final class ReserveServer implements AutoCloseable {
    private final HttpServer http;
    private final Admission admission;
    public volatile long processDelayMs = 0;
    public final AtomicInteger processed = new AtomicInteger();

    public ReserveServer(Admission admission) throws IOException {
        this.admission = admission;
        http = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 128);
        http.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
        http.createContext("/reserve", this::reserve);
        http.createContext("/reservations/", this::query);
        http.start();
    }

    public int port() { return http.getAddress().getPort(); }

    private void reserve(HttpExchange ex) throws IOException {
        try (ex) {
            Map<String, String> f = form(new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            if (f.get("request_key") == null || f.get("user") == null || f.get("sku") == null) {
                reply(ex, 400, "outcome=BAD_REQUEST");
                return;
            }
            Admission.Ticket t = admission.enter();
            if (t == Admission.Ticket.REJECTED_QUEUE_FULL || t == Admission.Ticket.REJECTED_WAIT_TIMEOUT) {
                ex.getResponseHeaders().add("Retry-After", "1");
                reply(ex, 503, "outcome=" + t);
                return;
            }
            Inventory.Hold h;
            try {
                if (processDelayMs > 0) Thread.sleep(processDelayMs);
                try (Connection c = lab.common.Db.connect()) {
                    h = Inventory.reserve(c, f.get("request_key"), f.get("user"), f.get("sku"),
                        Long.parseLong(f.getOrDefault("ttl_ms", "60000")));
                }
            } finally {
                admission.exit();
            }
            processed.incrementAndGet();
            int status = switch (h.outcome()) {
                case "HELD" -> 201;
                case "REPLAY" -> 200;
                case "KEY_REUSED" -> 422;
                default -> 409;
            };
            reply(ex, status, "outcome=" + h.outcome() + " reservation=" + h.reservationId() + " status=" + h.status());
        } catch (Exception e) {
            try { reply(ex, 500, "outcome=ERROR " + e); } catch (IOException ignore) { }
        }
    }

    private void query(HttpExchange ex) throws IOException {
        try (ex) {
            String key = ex.getRequestURI().getPath().substring("/reservations/".length());
            String st;
            try (Connection c = lab.common.Db.connect()) { st = Inventory.status(c, key); }
            if (st == null) reply(ex, 404, "status=NOT_FOUND");
            else reply(ex, 200, "status=" + st);
        } catch (Exception e) {
            reply(ex, 500, "outcome=ERROR " + e);
        }
    }

    static Map<String, String> form(String body) {
        Map<String, String> m = new HashMap<>();
        for (String kv : body.split("&")) {
            int i = kv.indexOf('=');
            if (i > 0) m.put(kv.substring(0, i), URLDecoder.decode(kv.substring(i + 1), StandardCharsets.UTF_8));
        }
        return m;
    }

    static void reply(HttpExchange ex, int status, String text) throws IOException {
        byte[] b = text.getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders(status, b.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(b); }
    }

    @Override public void close() { http.stop(0); }
}
