package lab.flash.order;

import java.sql.Connection;
import java.sql.SQLException;

/** 事务模板：body 在一个事务内执行，异常则回滚。Hook 用于在提交前注入停顿（多进程崩溃实验）。 */
public final class Tx {
    private Tx() {}

    public interface Body<T> { T run() throws SQLException; }
    public interface Hook { void run() throws SQLException; }
    public static final Hook NONE = () -> { };

    public static <T> T run(Connection c, Body<T> body) throws SQLException {
        c.setAutoCommit(false);
        try {
            T r = body.run();
            c.commit();
            return r;
        } catch (SQLException | RuntimeException e) {
            try { c.rollback(); } catch (SQLException ignore) { }
            throw e;
        } finally {
            try { c.setAutoCommit(true); } catch (SQLException ignore) { }
        }
    }
}
