package lab.flash.order;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.sql.Connection;
import java.util.Map;
import java.util.concurrent.Executors;
import lab.common.Db;

/**
 * 下游消费者（发货替身），接收 outbox 中继投递的订单事件 POST /events。
 * 幂等：ful_inbox 以 event_id 为主键，同一事件第二次到达记为 DUPLICATE，不再产生效果；
 * 有序：fulfillment.last_version 只接受更大的订单版本，迟到的旧版本记为 STALE。
 * 每次到达都先写 ful_received（自动提交），用于统计投递次数。
 * dedup=false 是负向对照：既不查 inbox 也不比版本，每次到达都执行效果。
 */
public final class Fulfillment implements AutoCloseable {
    public static final String SCHEMA = """
        CREATE TABLE ful_received (id bigserial PRIMARY KEY, event_id bigint NOT NULL, order_id text NOT NULL,
                                   type text NOT NULL, version int NOT NULL, effect text,
                                   at timestamptz NOT NULL DEFAULT clock_timestamp());
        CREATE TABLE ful_inbox (event_id bigint PRIMARY KEY);
        CREATE TABLE fulfillment (order_id text PRIMARY KEY, last_version int NOT NULL, state text NOT NULL,
                                  ship_count int NOT NULL);
        """;

    private final HttpServer http;
    public volatile boolean dedup = true;

    public Fulfillment() throws IOException {
        http = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 128);
        http.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
        http.createContext("/events", this::event);
        http.start();
    }

    public String url() { return "http://127.0.0.1:" + http.getAddress().getPort() + "/events"; }

    private void event(HttpExchange ex) {
        try (Connection c = Db.connect()) {
            Map<String, String> f = Http.form(Http.body(ex));
            long eventId = Long.parseLong(f.get("event_id"));
            String order = f.get("order_id"), type = f.get("type");
            int version = Integer.parseInt(f.get("version"));
            long rid = Db.queryLong(c, "INSERT INTO ful_received (event_id, order_id, type, version) VALUES (?,?,?,?) RETURNING id",
                eventId, order, type, version);
            String effect = dedup ? apply(c, eventId, order, type, version) : applyBlind(c, order, type, version);
            Db.update(c, "UPDATE ful_received SET effect = ? WHERE id = ?", effect, rid);
            Http.reply(ex, 200, "effect=" + effect);
        } catch (Exception e) {
            Http.reply(ex, 500, "effect=ERROR");
        }
    }

    static String apply(Connection c, long eventId, String order, String type, int version) throws Exception {
        return Tx.run(c, () -> {
            if (Db.update(c, "INSERT INTO ful_inbox (event_id) VALUES (?) ON CONFLICT DO NOTHING", eventId) == 0) return "DUPLICATE";
            int n = Db.update(c, """
                INSERT INTO fulfillment (order_id, last_version, state, ship_count)
                VALUES (?, ?, ?, CASE WHEN ? = 'ORDER_PAID' THEN 1 ELSE 0 END)
                ON CONFLICT (order_id) DO UPDATE
                  SET last_version = EXCLUDED.last_version, state = EXCLUDED.state,
                      ship_count = fulfillment.ship_count + EXCLUDED.ship_count
                  WHERE fulfillment.last_version < EXCLUDED.last_version""", order, version, type, type);
            return n == 1 ? "APPLIED" : "STALE";
        });
    }

    /** 负向对照：不去重、不比版本。 */
    static String applyBlind(Connection c, String order, String type, int version) throws Exception {
        Db.update(c, """
            INSERT INTO fulfillment (order_id, last_version, state, ship_count)
            VALUES (?, ?, ?, CASE WHEN ? = 'ORDER_PAID' THEN 1 ELSE 0 END)
            ON CONFLICT (order_id) DO UPDATE
              SET last_version = EXCLUDED.last_version, state = EXCLUDED.state,
                  ship_count = fulfillment.ship_count + EXCLUDED.ship_count""", order, version, type, type);
        return "APPLIED_BLIND";
    }

    @Override public void close() { http.stop(0); }
}
