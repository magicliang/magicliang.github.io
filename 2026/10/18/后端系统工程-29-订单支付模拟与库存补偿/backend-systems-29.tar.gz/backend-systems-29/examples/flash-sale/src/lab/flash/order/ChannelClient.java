package lab.flash.order;

import java.io.IOException;
import java.time.Duration;
import java.util.Map;

/** 订单服务调用假支付渠道的客户端。每个调用都带超时；HttpTimeoutException 表示“结果未知”，不是失败。 */
public final class ChannelClient {
    private final String base;

    public ChannelClient(String base) { this.base = base; }

    public Http.Resp charge(String mo, int amount, String notifyUrl, Duration timeout) throws IOException, InterruptedException {
        return Http.post(base + "/charge", Map.of("merchant_order", mo, "amount", amount, "notify_url", notifyUrl == null ? "" : notifyUrl), timeout);
    }

    public Http.Resp query(String mo, Duration timeout) throws IOException, InterruptedException {
        return Http.get(base + "/charges/" + mo, timeout);
    }

    public Http.Resp close(String mo, Duration timeout) throws IOException, InterruptedException {
        return Http.post(base + "/close", Map.of("merchant_order", mo), timeout);
    }

    public Http.Resp refund(String mo, String refundKey, int amount, Duration timeout) throws IOException, InterruptedException {
        return Http.post(base + "/refund", Map.of("merchant_order", mo, "refund_key", refundKey, "amount", amount), timeout);
    }

    /** 渠道账本，每行 "CHARGE mo amount txn" 或 "REFUND mo amount refund_key"。 */
    public String statement() throws IOException, InterruptedException {
        return Http.get(base + "/statement", Duration.ofSeconds(5)).raw();
    }
}
