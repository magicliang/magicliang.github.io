package lab.lease;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.util.concurrent.atomic.AtomicReference;

import lab.common.Db;

/**
 * 独立 JVM 中的租约持有者。获取租约 → 后台续租 → 检查本地截止时间 → （可选）等待父进程放行 → 写报表。
 * 参数：holder mode ttlMs renewMs marginMs part content waitGo
 * 标准输出每行一个事件，供父进程解析。
 */
public final class Holder {
    static final String LEASE = "report-job";
    static final String SCOPE = "daily-report";

    public static void main(String[] a) throws Exception {
        String holder = a[0];
        ReportStore.Mode mode = ReportStore.Mode.valueOf(a[1]);
        long ttl = Long.parseLong(a[2]), renewEvery = Long.parseLong(a[3]), margin = Long.parseLong(a[4]);
        String part = a[5], content = a[6];
        boolean waitGo = Boolean.parseBoolean(a[7]);

        LeaseStore.Grant g = null;
        try (Connection lc = Db.connect(LeaseLab.LEASE_DB)) {
            long giveUp = System.nanoTime() + 15_000_000_000L;
            while (g == null && System.nanoTime() < giveUp) {
                g = LeaseStore.acquire(lc, LEASE, holder, ttl, margin);
                if (g == null) Thread.sleep(50);
            }
        }
        if (g == null) { emit("ACQUIRE_TIMEOUT"); System.exit(4); }
        emit("ACQUIRED token=" + g.token());

        AtomicReference<LeaseStore.Grant> current = new AtomicReference<>(g);
        Thread renewer = new Thread(() -> renewLoop(current, renewEvery, margin), "renewer");
        renewer.setDaemon(true);
        renewer.start();

        // 写之前检查本地截止时间。这一步只能发现“检查时已过期”，挡不住检查之后的暂停。
        LeaseStore.Grant beforeWrite = current.get();
        if (beforeWrite == null || beforeWrite.localRemainingMillis() <= 0) { emit("LOCAL_EXPIRED"); System.exit(3); }
        emit("LOCAL_CHECK_OK");
        if (waitGo) {
            String go = new BufferedReader(new InputStreamReader(System.in)).readLine();
            if (!"go".equals(go)) { emit("NO_GO"); System.exit(5); }
        }
        boolean accepted;
        try (Connection rc = Db.connect(LeaseLab.RES_DB)) {
            accepted = new ReportStore(mode).write(rc, SCOPE, part, content, holder, g.token());
        }
        emit("WRITE accepted=" + accepted + " token=" + g.token());

        renewer.interrupt();
        renewer.join();
        try (Connection lc = Db.connect(LeaseLab.LEASE_DB)) {
            LeaseStore.Grant r = LeaseStore.renew(lc, g, margin);
            emit("RENEW_AFTER_WRITE ok=" + (r != null));
            if (r != null) emit("RELEASED " + LeaseStore.release(lc, r));
        }
    }

    private static void renewLoop(AtomicReference<LeaseStore.Grant> current, long every, long margin) {
        try (Connection lc = Db.connect(LeaseLab.LEASE_DB)) {
            while (!Thread.currentThread().isInterrupted()) {
                Thread.sleep(every);
                LeaseStore.Grant g = current.get();
                if (g == null) return;
                current.set(LeaseStore.renew(lc, g, margin));
            }
        } catch (InterruptedException ignore) {
            // 正常停止
        } catch (Exception e) {
            emit("RENEW_ERROR " + e.getMessage());
        }
    }

    private static synchronized void emit(String line) {
        System.out.println(line);
        System.out.flush();
    }
}
