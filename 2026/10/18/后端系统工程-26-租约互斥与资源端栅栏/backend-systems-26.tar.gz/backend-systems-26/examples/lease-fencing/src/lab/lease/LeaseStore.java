package lab.lease;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 租约表上的三个操作。过期判断只用数据库一侧的 now()，客户端时钟不参与比较。
 * 每个操作是单条语句；调用方应在自动提交模式下执行，使 now() 接近语句执行时刻
 * （now() 是事务开始时间，见 PostgreSQL 16 文档 9.9.5）。
 */
public final class LeaseStore {
    private LeaseStore() {}

    public static final String SCHEMA = """
        CREATE TABLE lease (
          name        text PRIMARY KEY,
          holder      text NOT NULL,
          token       bigint NOT NULL CHECK (token > 0),
          expires_at  timestamptz NOT NULL
        );
        """;

    /** 获取成功的结果。localDeadlineNanos 基于请求发出前读取的 System.nanoTime()。 */
    public record Grant(String name, String holder, long token, long ttlMillis, long localDeadlineNanos) {
        public long localRemainingMillis() {
            return (localDeadlineNanos - System.nanoTime()) / 1_000_000;
        }
    }

    /**
     * 租约不存在、已过期或已释放时获取成功，并在同一条语句里把 token 加一。
     * 租约仍有效时返回 null。
     */
    public static Grant acquire(Connection c, String name, String holder, long ttlMillis, long safetyMarginMillis)
            throws SQLException {
        long sentAt = System.nanoTime();
        String sql = """
            INSERT INTO lease AS l (name, holder, token, expires_at)
            VALUES (?, ?, 1, now() + make_interval(secs => ?::float8 / 1000))
            ON CONFLICT (name) DO UPDATE
               SET holder = EXCLUDED.holder,
                   token = l.token + 1,
                   expires_at = EXCLUDED.expires_at
             WHERE l.expires_at <= now()
            RETURNING l.token
            """;
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, holder);
            ps.setLong(3, ttlMillis);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                long deadline = sentAt + (ttlMillis - safetyMarginMillis) * 1_000_000L;
                return new Grant(name, holder, rs.getLong(1), ttlMillis, deadline);
            }
        }
    }

    /** 只有当前持有者、当前 token、且尚未过期时续租成功。过期后必须重新获取（得到新 token）。 */
    public static Grant renew(Connection c, Grant g, long safetyMarginMillis) throws SQLException {
        long sentAt = System.nanoTime();
        int n = lab.common.Db.update(c, """
            UPDATE lease SET expires_at = now() + make_interval(secs => ?::float8 / 1000)
             WHERE name = ? AND holder = ? AND token = ? AND expires_at > now()
            """, g.ttlMillis(), g.name(), g.holder(), g.token());
        if (n == 0) return null;
        return new Grant(g.name(), g.holder(), g.token(), g.ttlMillis(),
            sentAt + (g.ttlMillis() - safetyMarginMillis) * 1_000_000L);
    }

    /** 主动释放：把过期时间设为 -infinity，下一次获取立即成功；token 不回退。 */
    public static boolean release(Connection c, Grant g) throws SQLException {
        return lab.common.Db.update(c, """
            UPDATE lease SET expires_at = '-infinity'
             WHERE name = ? AND holder = ? AND token = ?
            """, g.name(), g.holder(), g.token()) == 1;
    }

    public static boolean expiredNow(Connection c, String name) throws SQLException {
        return "t".equals(lab.common.Db.queryString(c,
            "SELECT CASE WHEN expires_at <= now() THEN 't' ELSE 'f' END FROM lease WHERE name = ?", name));
    }
}
