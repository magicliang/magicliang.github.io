# lease-fencing（第 26 章）

租约表 + 单调 fencing token + 资源端栅栏检查。

- `src/lab/lease/LeaseStore.java`：租约获取（原子递增 token）、续租、释放；过期只按数据库 `now()` 判断。
- `src/lab/lease/ReportStore.java`：受保护资源（报表输出库 `res26`），四种写入模式：`FENCED_SCOPE`（作用域级栅栏，正确方案）、`FENCED_ROW`（行级比较，有缺口）、`UNFENCED`（不检查）、`CHECK_THEN_WRITE`（检查与写入分离）。
- `src/lab/lease/Holder.java`：独立 JVM 中的持有者，供 SIGSTOP/SIGCONT 实验使用。
- `src/lab/lease/LeaseLab.java`：用例 F1–F9。

运行：`./run.sh`（端口 55426，集群 b3-26）。输出写入 `../../evidence/26/`。
