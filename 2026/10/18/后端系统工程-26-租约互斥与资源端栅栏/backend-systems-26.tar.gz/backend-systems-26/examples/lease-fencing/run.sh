#!/usr/bin/env bash
# 第 26 章：启动集群 → 重建实验库 → 编译 → 运行全部用例 → 写证据 → 停集群。
set -uo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
COMMON="$HERE/../common"
EVID="$HERE/../../evidence/26"
NAME=b3-26; PORT=55426
mkdir -p "$EVID"
export LAB_PGPORT=$PORT LAB_DB=lease26 LAB_PG_SH="$COMMON/pg.sh" LAB_PG_NAME=$NAME LAB_BUILD=/tmp/batch3-build/ch26
{
  echo "date: $(date -Is)"
  echo "uname: $(uname -a)"
  java -version 2>&1 | sed 's/^/java: /'
  echo "postgres: $(/usr/lib/postgresql/16/bin/postgres --version)"
  echo "pgjdbc: postgresql-42.7.7.jar"
  echo "python: not used"
} > "$EVID/env.txt"
cat > "$EVID/commands.txt" <<CMD
cd examples/lease-fencing && ./run.sh
  initdb -D /tmp/batch3-pg/$NAME -U postgres -A trust -E UTF8 --locale=C.UTF-8 -c dynamic_shared_memory_type=mmap（仅首次）
  ../common/pg.sh start $NAME $PORT
  LAB_PGPORT=$PORT LAB_DB=lease26 LAB_PG_SH=../common/pg.sh LAB_PG_NAME=$NAME LAB_BUILD=/tmp/batch3-build/ch26 ../common/lab.sh . lab.lease.LeaseLab
  （F4/F5 用例内部启动两个子 JVM lab.lease.Holder，并对持有者 A 执行 kill -STOP <pid> / kill -CONT <pid>）
  （F8 用例内部调用 ../common/pg.sh restart-immediate $NAME $PORT）
  ../common/pg.sh stop $NAME
CMD
# 本机 /dev/shm 容量小，预先用 mmap 动态共享内存 initdb；pg.sh 检测到 PG_VERSION 后不再 initdb。
PGDIR=${BATCH3_PG_ROOT:-/tmp/batch3-pg}/$NAME
if [ ! -f "$PGDIR/PG_VERSION" ]; then
  mkdir -p "$(dirname "$PGDIR")"
  /usr/lib/postgresql/16/bin/initdb -D "$PGDIR" -U postgres -A trust -E UTF8 --locale=C.UTF-8 \
    -c dynamic_shared_memory_type=mmap >/dev/null
fi
# 55426 落在本机临时端口范围（32768–61001）内，偶发被其他连接的本地端口占用；启动失败时重试。
for i in 1 2 3 4 5; do
  "$COMMON/pg.sh" start $NAME $PORT && break
  echo "pg start attempt $i failed, retrying" >&2; sleep 3
done
"$COMMON/lab.sh" "$HERE" lab.lease.LeaseLab > "$EVID/output.txt" 2>&1
rc=$?
"$COMMON/pg.sh" stop $NAME
echo "exit=$rc" >> "$EVID/commands.txt"
tail -n 3 "$EVID/output.txt"
exit $rc
