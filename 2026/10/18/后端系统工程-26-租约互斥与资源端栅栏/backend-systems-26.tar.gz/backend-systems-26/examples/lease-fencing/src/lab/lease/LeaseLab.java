package lab.lease;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import lab.common.Check;
import lab.common.Db;

/** 第 26 章全部用例。租约库 lease26 与资源库 res26 位于同一临时集群的两个数据库。 */
public final class LeaseLab {
    static final String LEASE_DB = "lease26";
    static final String RES_DB = "res26";
    static final String SCOPE = Holder.SCOPE;

    public static void main(String[] args) throws Exception {
        setup();
        normalPath();
        boundaries();
        concurrentAcquire();
        pausedHolder(ReportStore.Mode.FENCED_SCOPE);
        pausedHolder(ReportStore.Mode.UNFENCED);
        checkThenWriteRace();
        rowFenceGap();
        restartImmediate();
        externalSideEffect();
        System.exit(Check.finish());
    }

    // ---------------------------------------------------------------- 基础设施

    static void setup() throws SQLException {
        Db.recreate(LEASE_DB);
        Db.recreate(RES_DB);
        try (Connection c = Db.connect(LEASE_DB)) { Db.exec(c, LeaseStore.SCHEMA); }
        try (Connection c = Db.connect(RES_DB)) {
            Db.exec(c, ReportStore.SCHEMA);
            Db.exec(c, """
                CREATE TABLE external_publish (
                  business_key text PRIMARY KEY,
                  content      text NOT NULL,
                  writer       text NOT NULL
                );
                """);
        }
    }

    static void reset() throws SQLException {
        try (Connection c = Db.connect(LEASE_DB)) { Db.exec(c, "TRUNCATE lease"); }
        try (Connection c = Db.connect(RES_DB)) {
            Db.exec(c, "TRUNCATE fence_floor, report_part, write_attempt, external_publish");
            ReportStore.initScope(c, SCOPE);
        }
    }

    static Connection lease() throws SQLException { return Db.connect(LEASE_DB); }
    static Connection res() throws SQLException { return Db.connect(RES_DB); }

    static void waitExpired(Connection lc, String name, long maxMillis) throws Exception {
        long until = System.nanoTime() + maxMillis * 1_000_000L;
        while (!LeaseStore.expiredNow(lc, name)) {
            if (System.nanoTime() > until) throw new IllegalStateException("lease did not expire: " + name);
            Thread.sleep(20);
        }
    }

    static String partContent(Connection rc, String part) throws SQLException {
        return Db.queryString(rc, "SELECT content || ' by ' || writer || ' token=' || token FROM report_part WHERE scope = ? AND part = ?",
            SCOPE, part);
    }

    static long floor(Connection rc) throws SQLException {
        return Db.queryLong(rc, "SELECT max_token FROM fence_floor WHERE scope = ?", SCOPE);
    }

    // ---------------------------------------------------------------- F1 正常路径

    static void normalPath() throws Exception {
        Check.begin("F1", "正常路径：获取 → 写入 → 续租 → 释放 → 下一持有者获取更大 token 并写入");
        reset();
        ReportStore store = new ReportStore(ReportStore.Mode.FENCED_SCOPE);
        try (Connection lc = lease(); Connection rc = res()) {
            LeaseStore.Grant a = LeaseStore.acquire(lc, "report-job", "holder-a", 2000, 300);
            Check.that(a != null && a.token() == 1, "holder-a 获取租约，token=1");
            Check.that(store.write(rc, SCOPE, "summary", "rows=120", "holder-a", a.token()), "holder-a 以 token=1 写入被接受");
            LeaseStore.Grant a2 = LeaseStore.renew(lc, a, 300);
            Check.that(a2 != null && a2.token() == 1, "续租成功，token 不变");
            Check.that(LeaseStore.release(lc, a2), "holder-a 主动释放");
            LeaseStore.Grant b = LeaseStore.acquire(lc, "report-job", "holder-b", 2000, 300);
            Check.that(b != null && b.token() == 2, "释放后 holder-b 立即获取，token=2");
            Check.that(store.write(rc, SCOPE, "summary", "rows=121", "holder-b", b.token()), "holder-b 以 token=2 写入被接受");
            Check.equal("rows=121 by holder-b token=2", partContent(rc, "summary"), "报表内容来自 holder-b");
            Check.equal(2L, floor(rc), "资源端 fence_floor=2");
        }
    }

    // ---------------------------------------------------------------- F2 边界

    static void boundaries() throws Exception {
        Check.begin("F2", "边界：有效期内抢占、错 token 续租、过期后续租、相等/更小 token、事务内 now() 冻结");
        reset();
        ReportStore store = new ReportStore(ReportStore.Mode.FENCED_SCOPE);
        try (Connection lc = lease(); Connection rc = res()) {
            LeaseStore.Grant a = LeaseStore.acquire(lc, "report-job", "holder-a", 800, 100);
            Check.that(LeaseStore.acquire(lc, "report-job", "holder-b", 800, 100) == null, "有效期内 holder-b 获取被拒绝");
            Check.equal(1L, Db.queryLong(lc, "SELECT token FROM lease WHERE name = 'report-job'"), "被拒绝的获取不推进 token");
            Check.that(LeaseStore.renew(lc, new LeaseStore.Grant("report-job", "holder-a", 99, 800, 0), 100) == null,
                "持有者名正确但 token 错误：续租被拒绝");
            Check.that(LeaseStore.renew(lc, new LeaseStore.Grant("report-job", "holder-b", 1, 800, 0), 100) == null,
                "token 正确但持有者错误：续租被拒绝");
            waitExpired(lc, "report-job", 5000);
            Check.that(LeaseStore.renew(lc, a, 100) == null, "过期后原持有者续租被拒绝，必须重新获取");
            LeaseStore.Grant a2 = LeaseStore.acquire(lc, "report-job", "holder-a", 800, 100);
            Check.that(a2 != null && a2.token() == 2, "原持有者重新获取，得到新 token=2");

            Check.that(store.write(rc, SCOPE, "summary", "v1", "holder-a", 2), "token=2 首次写入接受");
            Check.that(store.write(rc, SCOPE, "summary", "v2", "holder-a", 2), "相等 token=2 再次写入接受（同一持有期内多次写）");
            Check.that(!store.write(rc, SCOPE, "summary", "stale", "holder-a", 1), "更小 token=1 写入被拒绝");
            Check.equal("v2 by holder-a token=2", partContent(rc, "summary"), "被拒绝的写入未改动内容");

            // now() 是事务开始时间：长事务中的获取按旧时间判断过期
            LeaseStore.release(lc, a2);
            LeaseStore.Grant c = LeaseStore.acquire(lc, "report-job", "holder-c", 300, 50);
            Check.that(c != null && c.token() == 3, "holder-c 获取 ttl=300ms 的租约，token=3");
            try (Connection tx = lease()) {
                tx.setAutoCommit(false);
                String t0 = Db.queryString(tx, "SELECT now()::text");
                waitExpired(lc, "report-job", 5000);
                Thread.sleep(100);
                Check.equal(t0, Db.queryString(tx, "SELECT now()::text"), "同一事务内 now() 不随时间前进");
                Check.that("t".equals(Db.queryString(tx, "SELECT CASE WHEN clock_timestamp() > now() THEN 't' END")),
                    "clock_timestamp() 已越过 now()");
                Check.that(LeaseStore.acquire(tx, "report-job", "holder-d", 300, 50) == null,
                    "自动提交连接已判定过期，但长事务内的获取仍按事务开始时间判为未过期而拒绝");
                tx.rollback();
            }
            LeaseStore.Grant d = LeaseStore.acquire(lc, "report-job", "holder-d", 300, 50);
            Check.that(d != null && d.token() == 4, "自动提交模式下获取成功，token=4");
        }
    }

    // ---------------------------------------------------------------- F3 并发获取

    static void concurrentAcquire() throws Exception {
        Check.begin("F3", "16 个线程（各自连接）同时获取同一租约：新建、过期后、有效期内三轮");
        reset();
        int n = 16;
        String[] rounds = {"新建", "过期后", "有效期内"};
        try (Connection lc = lease()) {
            for (int r = 0; r < rounds.length; r++) {
                if (r == 1) waitExpired(lc, "race", 5000);
                long ttl = r == 0 ? 300 : 5000;
                List<Long> tokens = raceAcquire(n, "race", ttl);
                long expectWinners = r == 2 ? 0 : 1;
                Check.equal(expectWinners, (long) tokens.size(), "第 " + (r + 1) + " 轮（" + rounds[r] + "）获取成功的线程数");
                if (expectWinners == 1) Check.equal((long) (r + 1), tokens.get(0), "第 " + (r + 1) + " 轮获胜者的 token");
            }
            Check.equal(2L, Db.queryLong(lc, "SELECT token FROM lease WHERE name = 'race'"), "三轮共 48 次尝试后 token=2");
        }
    }

    static List<Long> raceAcquire(int n, String name, long ttl) throws Exception {
        CyclicBarrier barrier = new CyclicBarrier(n);
        ExecutorService pool = Executors.newFixedThreadPool(n);
        List<Future<Long>> fs = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String holder = String.format("worker-%02d", i);
            fs.add(pool.submit(() -> {
                try (Connection c = lease()) {
                    c.isValid(1);
                    barrier.await(10, TimeUnit.SECONDS);
                    LeaseStore.Grant g = LeaseStore.acquire(c, name, holder, ttl, 50);
                    return g == null ? null : g.token();
                }
            }));
        }
        List<Long> won = new ArrayList<>();
        for (Future<Long> f : fs) {
            Long t = f.get(30, TimeUnit.SECONDS);
            if (t != null) won.add(t);
        }
        pool.shutdown();
        return won;
    }

    // ---------------------------------------------------------------- F4 / F5 多进程：暂停的旧持有者

    static final class Child {
        final Process p;
        final BlockingQueue<String> lines = new LinkedBlockingQueue<>();
        final Writer in;

        Child(String holder, ReportStore.Mode mode, String part, String content, boolean waitGo) throws Exception {
            String java = Path.of(System.getProperty("java.home"), "bin", "java").toString();
            p = new ProcessBuilder(java, "-cp", System.getProperty("java.class.path"), "lab.lease.Holder",
                holder, mode.name(), "1500", "400", "300", part, content, Boolean.toString(waitGo))
                .redirectErrorStream(true).start();
            in = new OutputStreamWriter(p.getOutputStream(), StandardCharsets.UTF_8);
            Thread t = new Thread(() -> {
                try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                    for (String l; (l = r.readLine()) != null; ) lines.add(l);
                } catch (Exception ignore) { }
            });
            t.setDaemon(true);
            t.start();
        }

        String next() throws InterruptedException {
            String l = lines.poll(20, TimeUnit.SECONDS);
            return l == null ? "(timeout)" : l;
        }

        String state() throws Exception {
            String stat = Files.readString(Path.of("/proc/" + p.pid() + "/stat"));
            return stat.substring(stat.lastIndexOf(')') + 2, stat.lastIndexOf(')') + 3);
        }

        void signal(String sig) throws Exception {
            new ProcessBuilder("kill", "-" + sig, Long.toString(p.pid())).inheritIO().start().waitFor();
        }
    }

    static void pausedHolder(ReportStore.Mode mode) throws Exception {
        boolean fenced = mode == ReportStore.Mode.FENCED_SCOPE;
        Check.begin(fenced ? "F4" : "F5", (fenced ? "" : "负向对照：")
            + "持有者 A（独立 JVM）拿到 token 后被 SIGSTOP；租约过期后 B（独立 JVM）写入；A 被 SIGCONT 后写入；资源端模式="
            + mode);
        reset();
        Child a = new Child("holder-a", mode, "summary", "rows=200(A)", true);
        Check.equal("ACQUIRED token=1", a.next(), "A 获取租约");
        Check.equal("LOCAL_CHECK_OK", a.next(), "A 写前检查本地截止时间通过，随后停在写入之前");
        try (Connection lc = lease(); Connection rc = res()) {
            Thread.sleep(3000); // 两倍 TTL：A 未暂停时后台续租维持租约
            Check.that(!LeaseStore.expiredNow(lc, "report-job"), "A 未暂停期间（等待 3000ms，TTL=1500ms）续租维持租约");
            a.signal("STOP");
            Thread.sleep(100);
            Check.equal("T", a.state(), "SIGSTOP 后 /proc 中 A 的状态为 T（续租线程同样停止）");
            waitExpired(lc, "report-job", 10_000);
            Check.that(true, "租约按数据库 now() 判定过期");

            Child b = new Child("holder-b", mode, "summary", "rows=201(B)", false);
            Check.equal("ACQUIRED token=2", b.next(), "B 获取租约，token=2");
            Check.equal("LOCAL_CHECK_OK", b.next(), "B 本地检查通过");
            Check.equal("WRITE accepted=true token=2", b.next(), "B 写入被接受");
            Check.equal("RENEW_AFTER_WRITE ok=true", b.next(), "B 写后续租成功");
            Check.equal("RELEASED true", b.next(), "B 释放租约");
            Check.equal(0, b.p.waitFor(), "B 进程退出码");

            a.in.write("go\n");
            a.in.flush();
            a.signal("CONT");
            String aWrite = a.next();
            String aRenew = a.next();
            Check.equal(0, a.p.waitFor(), "A 进程退出码");
            String content = partContent(rc, "summary");
            Check.note("A 恢复后：" + aWrite + "；" + aRenew);
            Check.note("最终 summary = " + content + "；fence_floor=" + floor(rc));
            Check.equal("RENEW_AFTER_WRITE ok=false", aRenew, "A 恢复后续租失败（token 已被取代）");
            if (fenced) {
                Check.equal("WRITE accepted=false token=1", aWrite, "A 的旧 token 写入被资源端拒绝");
                Check.equal("rows=201(B) by holder-b token=2", content, "报表保持 B 的结果");
                Check.equal(2L, floor(rc), "fence_floor 保持 2");
                Check.equal(1L, Db.queryLong(rc, "SELECT count(*) FROM write_attempt WHERE writer = 'holder-a' AND NOT accepted"),
                    "write_attempt 记录一次 A 的被拒尝试");
            } else {
                Check.exposes("WRITE accepted=true token=1".equals(aWrite) && "rows=200(A) by holder-a token=1".equals(content),
                    "资源端不检查 token 时，A 的旧结果覆盖了 B 的结果");
            }
        }
    }

    // ---------------------------------------------------------------- F6 先检查后写入

    static void checkThenWriteRace() throws Exception {
        Check.begin("F6", "同一交错下比较：检查与写入分离（负向对照） vs 条件 UPDATE 持行锁");
        // (a) 非原子：A 读到 floor=0 后停住，B 完成写入，A 继续写
        reset();
        CountDownLatch aChecked = new CountDownLatch(1), bDone = new CountDownLatch(1);
        ReportStore racyA = new ReportStore(ReportStore.Mode.CHECK_THEN_WRITE, () -> {
            aChecked.countDown();
            await(bDone);
        });
        ExecutorService ex = Executors.newFixedThreadPool(2);
        Future<Boolean> fa = ex.submit(() -> { try (Connection c = res()) { return racyA.write(c, SCOPE, "summary", "old(A)", "holder-a", 1); } });
        Check.that(aChecked.await(10, TimeUnit.SECONDS), "A 已读到 fence_floor 并通过检查");
        boolean bOk;
        try (Connection c = res()) { bOk = new ReportStore(ReportStore.Mode.CHECK_THEN_WRITE).write(c, SCOPE, "summary", "new(B)", "holder-b", 2); }
        bDone.countDown();
        boolean aOk = fa.get(10, TimeUnit.SECONDS);
        try (Connection rc = res()) {
            String content = partContent(rc, "summary");
            Check.note("check-then-write：B accepted=" + bOk + "，A accepted=" + aOk + "，最终 " + content + "，fence_floor=" + floor(rc));
            Check.exposes(aOk && "old(A) by holder-a token=1".equals(content) && floor(rc) == 1,
                "A 的检查结果在写入时已过时：旧 token 覆盖新结果，fence_floor 从 2 回退到 1");
        }

        // (b) 原子：A 的条件 UPDATE 持有 fence_floor 行锁，在写数据前停住；B 只能等待
        reset();
        CountDownLatch aLocked = new CountDownLatch(1), releaseA = new CountDownLatch(1);
        ReportStore atomicA = new ReportStore(ReportStore.Mode.FENCED_SCOPE, () -> {
            aLocked.countDown();
            await(releaseA);
        });
        Future<Boolean> fa2 = ex.submit(() -> { try (Connection c = res()) { return atomicA.write(c, SCOPE, "summary", "old(A)", "holder-a", 1); } });
        Check.that(aLocked.await(10, TimeUnit.SECONDS), "A 已推进 fence_floor 并停在写数据之前（事务未提交）");
        Future<Boolean> fb2 = ex.submit(() -> { try (Connection c = res()) { return new ReportStore(ReportStore.Mode.FENCED_SCOPE).write(c, SCOPE, "summary", "new(B)", "holder-b", 2); } });
        try (Connection rc = res()) {
            long waiting = 0;
            for (int i = 0; i < 100 && waiting == 0; i++) {
                Thread.sleep(50);
                waiting = Db.queryLong(rc, "SELECT count(*) FROM pg_stat_activity WHERE datname = ? AND wait_event_type = 'Lock'", RES_DB);
            }
            Check.equal(1L, waiting, "pg_stat_activity 中 B 的会话在行锁上等待");
            Check.that(!fb2.isDone(), "B 尚未返回");
            releaseA.countDown();
            boolean a2 = fa2.get(10, TimeUnit.SECONDS), b2 = fb2.get(10, TimeUnit.SECONDS);
            Check.that(a2 && b2, "A 先提交（token=1 合法），B 随后对新版本行重新求值 1<=2，接受");
            Check.equal("new(B) by holder-b token=2", partContent(rc, "summary"), "最终内容来自更大 token");
            Check.equal(2L, floor(rc), "fence_floor=2");
            // (c) 反向顺序：B 先完成，A 后到
            boolean late = new ReportStore(ReportStore.Mode.FENCED_SCOPE).write(rc, SCOPE, "summary", "old(A)", "holder-a", 1);
            Check.that(!late, "B 已推进到 2 后，A 的 token=1 写入被拒绝");
        }
        ex.shutdown();
    }

    static void await(CountDownLatch l) {
        try {
            if (!l.await(10, TimeUnit.SECONDS)) throw new IllegalStateException("latch timeout");
        } catch (InterruptedException e) {
            throw new IllegalStateException(e);
        }
    }

    // ---------------------------------------------------------------- F7 行级栅栏的缺口

    static void rowFenceGap() throws Exception {
        Check.begin("F7", "栅栏粒度：B 只写了 summary，旧持有者 A 写尚未被 B 触及的 detail");
        for (ReportStore.Mode mode : new ReportStore.Mode[]{ReportStore.Mode.FENCED_ROW, ReportStore.Mode.FENCED_SCOPE}) {
            reset();
            ReportStore store = new ReportStore(mode);
            try (Connection lc = lease(); Connection rc = res()) {
                LeaseStore.Grant a = LeaseStore.acquire(lc, "report-job", "holder-a", 300, 50);
                store.write(rc, SCOPE, "summary", "A-summary", "holder-a", a.token());
                waitExpired(lc, "report-job", 5000);
                LeaseStore.Grant b = LeaseStore.acquire(lc, "report-job", "holder-b", 5000, 300);
                boolean bOk = store.write(rc, SCOPE, "summary", "B-summary", "holder-b", b.token());
                boolean aDetail = store.write(rc, SCOPE, "detail", "A-detail", "holder-a", a.token());
                Check.note(mode + "：B summary accepted=" + bOk + "，A(token=" + a.token() + ") detail accepted=" + aDetail);
                if (mode == ReportStore.Mode.FENCED_ROW) {
                    Check.exposes(bOk && aDetail, "行级比较只看被写的那一行；新行没有旧 token 可比，旧持有者写入成功");
                } else {
                    Check.that(bOk && !aDetail, "作用域级 fence_floor 拒绝旧 token 写入任何分片");
                    Check.equal(0L, Db.queryLong(rc, "SELECT count(*) FROM report_part WHERE part = 'detail'"), "detail 分片不存在");
                }
            }
        }
    }

    // ---------------------------------------------------------------- F8 数据库崩溃重启

    static void restartImmediate() throws Exception {
        Check.begin("F8", "pg.sh restart-immediate 后：租约行、token 与 fence_floor 均由 WAL 恢复，token 不复用");
        reset();
        ReportStore store = new ReportStore(ReportStore.Mode.FENCED_SCOPE);
        LeaseStore.Grant a;
        try (Connection lc = lease(); Connection rc = res()) {
            LeaseStore.Grant first = LeaseStore.acquire(lc, "report-job", "holder-a", 60_000, 1000);
            LeaseStore.release(lc, first);
            a = LeaseStore.acquire(lc, "report-job", "holder-a", 60_000, 1000);
            Check.equal(2L, a.token(), "重启前 holder-a 持有 token=2");
            Check.that(store.write(rc, SCOPE, "summary", "before-crash", "holder-a", a.token()), "重启前写入接受");
        }
        String sh = System.getenv("LAB_PG_SH"), name = System.getenv("LAB_PG_NAME"), port = System.getenv("LAB_PGPORT");
        Process p = new ProcessBuilder("bash", sh, "restart-immediate", name, port).redirectErrorStream(true).start();
        String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
        Check.equal(0, p.waitFor(), "restart-immediate 退出码（" + out + "）");
        try (Connection lc = lease(); Connection rc = res()) {
            Check.equal("holder-a/2", Db.queryString(lc, "SELECT holder || '/' || token FROM lease WHERE name = 'report-job'"),
                "租约行恢复：holder-a 仍持有 token=2（租约不随数据库连接断开而失效）");
            Check.equal(2L, floor(rc), "fence_floor 恢复为 2");
            Check.equal("before-crash by holder-a token=2", partContent(rc, "summary"), "已提交写入仍在");
            Check.that(LeaseStore.release(lc, a), "holder-a 释放");
            LeaseStore.Grant b = LeaseStore.acquire(lc, "report-job", "holder-b", 5000, 300);
            Check.equal(3L, b.token(), "重启后的下一次获取得到 token=3，不复用");
            Check.that(store.write(rc, SCOPE, "summary", "after-crash", "holder-b", b.token()), "holder-b 写入接受");
            Check.that(!store.write(rc, SCOPE, "summary", "stale", "holder-a", a.token()), "holder-a 的 token=2 写入被拒绝");
        }
    }

    // ---------------------------------------------------------------- F9 不支持栅栏的外部副作用

    static boolean publish(Connection rc, String key, String content, String writer) throws SQLException {
        return Db.update(rc, "INSERT INTO external_publish (business_key, content, writer) VALUES (?,?,?) ON CONFLICT DO NOTHING",
            key, content, writer) == 1;
    }

    static void externalSideEffect() throws Exception {
        Check.begin("F9", "外部发布替身不认识 token，只按业务键幂等：去重有效，但不能阻止旧持有者抢先");
        reset();
        try (Connection rc = res()) {
            boolean b1 = publish(rc, "report:2026-10-17", "B-final", "holder-b");
            boolean a1 = publish(rc, "report:2026-10-17", "A-stale", "holder-a");
            Check.that(b1 && !a1, "顺序 B→A：A 的重复发布被业务键去重");
            Check.equal("B-final", Db.queryString(rc, "SELECT content FROM external_publish WHERE business_key = 'report:2026-10-17'"),
                "保留 B 的内容");
            boolean a2 = publish(rc, "report:2026-10-18", "A-stale", "holder-a");
            boolean b2 = publish(rc, "report:2026-10-18", "B-final", "holder-b");
            String kept = Db.queryString(rc, "SELECT content FROM external_publish WHERE business_key = 'report:2026-10-18'");
            Check.note("顺序 A→B：A accepted=" + a2 + "，B accepted=" + b2 + "，保留 " + kept);
            Check.exposes(a2 && !b2 && "A-stale".equals(kept), "幂等只保证一次，旧持有者先到时保留的是旧内容");
            Check.equal(2L, Db.queryLong(rc, "SELECT count(*) FROM external_publish"), "每个业务键恰好一条发布记录");
        }
    }
}
