package lab.lease;

import java.sql.Connection;
import java.sql.SQLException;

import lab.common.Db;

/**
 * 受保护资源：报表输出库（与租约库是两个数据库，资源端不读租约表）。
 * 资源端只记住自己见过的最大 token（fence_floor），据此拒绝更小的 token。
 */
public final class ReportStore {
    public enum Mode {
        /** 作用域级栅栏：在同一事务里条件更新 fence_floor，再写数据。 */
        FENCED_SCOPE,
        /** 行级栅栏：只比较被写那一行上记录的 token；新行不受约束。 */
        FENCED_ROW,
        /** 不检查 token：负向对照。 */
        UNFENCED,
        /** 先读 fence_floor 判断，再分别更新：检查与写入不是原子的。 */
        CHECK_THEN_WRITE
    }

    public static final String SCHEMA = """
        CREATE TABLE fence_floor (
          scope      text PRIMARY KEY,
          max_token  bigint NOT NULL
        );
        CREATE TABLE report_part (
          scope      text NOT NULL,
          part       text NOT NULL,
          content    text NOT NULL,
          writer     text NOT NULL,
          token      bigint NOT NULL,
          written_at timestamptz NOT NULL DEFAULT clock_timestamp(),
          PRIMARY KEY (scope, part)
        );
        CREATE TABLE write_attempt (
          id        bigserial PRIMARY KEY,
          scope     text NOT NULL,
          part      text NOT NULL,
          writer    text NOT NULL,
          token     bigint NOT NULL,
          mode      text NOT NULL,
          accepted  boolean NOT NULL,
          at        timestamptz NOT NULL DEFAULT clock_timestamp()
        );
        """;

    private static final String UPSERT = """
        INSERT INTO report_part AS r (scope, part, content, writer, token) VALUES (?, ?, ?, ?, ?)
        ON CONFLICT (scope, part) DO UPDATE
           SET content = EXCLUDED.content, writer = EXCLUDED.writer,
               token = EXCLUDED.token, written_at = clock_timestamp()
        """;

    private final Mode mode;
    /** 测试钩子：在“检查之后、写入之前”调用，用来构造确定的交错。 */
    private final Runnable gap;

    public ReportStore(Mode mode) { this(mode, () -> {}); }

    public ReportStore(Mode mode, Runnable gap) {
        this.mode = mode;
        this.gap = gap;
    }

    public static void initScope(Connection c, String scope) throws SQLException {
        Db.update(c, "INSERT INTO fence_floor (scope, max_token) VALUES (?, 0) ON CONFLICT DO NOTHING", scope);
    }

    /** 写入一个报表分片；返回资源端是否接受。 */
    public boolean write(Connection c, String scope, String part, String content, String writer, long token)
            throws SQLException {
        boolean accepted = switch (mode) {
            case FENCED_SCOPE -> fencedScope(c, scope, part, content, writer, token);
            case FENCED_ROW -> Db.update(c, UPSERT + " WHERE r.token <= EXCLUDED.token",
                scope, part, content, writer, token) == 1;
            case UNFENCED -> Db.update(c, UPSERT, scope, part, content, writer, token) == 1;
            case CHECK_THEN_WRITE -> checkThenWrite(c, scope, part, content, writer, token);
        };
        Db.update(c, "INSERT INTO write_attempt (scope, part, writer, token, mode, accepted) VALUES (?,?,?,?,?,?)",
            scope, part, writer, token, mode.name(), accepted);
        return accepted;
    }

    private boolean fencedScope(Connection c, String scope, String part, String content, String writer, long token)
            throws SQLException {
        c.setAutoCommit(false);
        try {
            // 比较与推进栅栏是同一条 UPDATE；它持有 fence_floor 行锁直到提交，
            // 同作用域的其他写入者在这里排队，并在锁释放后对新版本行重新求值 WHERE。
            int n = Db.update(c, "UPDATE fence_floor SET max_token = ? WHERE scope = ? AND max_token <= ?",
                token, scope, token);
            if (n == 0) {
                c.rollback();
                return false;
            }
            gap.run();
            Db.update(c, UPSERT, scope, part, content, writer, token);
            c.commit();
            return true;
        } catch (SQLException | RuntimeException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
    }

    private boolean checkThenWrite(Connection c, String scope, String part, String content, String writer, long token)
            throws SQLException {
        long seen = Db.queryLong(c, "SELECT max_token FROM fence_floor WHERE scope = ?", scope);
        if (token < seen) return false;
        gap.run();
        Db.update(c, "UPDATE fence_floor SET max_token = ? WHERE scope = ?", token, scope);
        Db.update(c, UPSERT, scope, part, content, writer, token);
        return true;
    }
}
