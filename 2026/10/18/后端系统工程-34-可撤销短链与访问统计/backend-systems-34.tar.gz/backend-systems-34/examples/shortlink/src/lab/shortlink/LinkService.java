package lab.shortlink;

import java.net.URI;
import java.net.URISyntaxException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Locale;
import java.util.function.Supplier;

import lab.common.Db;

/** 短链的写入路径：创建、别名、撤销。唯一性只由 link.code 主键保证。 */
public final class LinkService {
    public static final String DDL = """
        CREATE TABLE link (
            code       text        PRIMARY KEY CHECK (code ~ '^[A-Za-z0-9_-]{3,32}$'),
            target     text        NOT NULL,
            owner      text        NOT NULL,
            kind       text        NOT NULL CHECK (kind IN ('RANDOM', 'ALIAS')),
            state      text        NOT NULL CHECK (state IN ('ACTIVE', 'REVOKED')),
            version    bigint      NOT NULL DEFAULT 1,
            expires_at timestamptz,
            created_at timestamptz NOT NULL DEFAULT now(),
            revoked_at timestamptz
        );
        CREATE TABLE link_change (
            seq        bigserial   PRIMARY KEY,
            code       text        NOT NULL REFERENCES link(code),
            version    bigint      NOT NULL,
            changed_at timestamptz NOT NULL DEFAULT clock_timestamp()
        );
        """;

    public static final String STATS_DDL = """
        CREATE TABLE click (
            click_id    uuid        PRIMARY KEY,
            code        text        NOT NULL,
            clicked_at  timestamptz NOT NULL,
            ingested_at timestamptz NOT NULL DEFAULT clock_timestamp()
        );
        """;

    public record Created(String code, int collisions) {}

    public static final class AliasTaken extends Exception {
        AliasTaken(String alias) { super("alias taken: " + alias); }
    }

    public static final class InvalidTarget extends Exception {
        InvalidTarget(String why) { super(why); }
    }

    private static final String ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
    private static final SecureRandom RNG = new SecureRandom();
    public static final int MAX_TRIES = 5;

    /** 8 位随机码，字母表去掉了易混淆字符；约 57^8 ≈ 1.1e14 个取值。 */
    public static String randomCode() {
        StringBuilder sb = new StringBuilder(8);
        for (int i = 0; i < 8; i++) sb.append(ALPHABET.charAt(RNG.nextInt(ALPHABET.length())));
        return sb.toString();
    }

    /** 只接受带主机名的绝对 http/https 地址；拒绝 userinfo、控制字符和协议相对地址。 */
    public static String validateTarget(String raw) throws InvalidTarget {
        if (raw == null || raw.isEmpty() || raw.length() > 2048) throw new InvalidTarget("length");
        for (char ch : raw.toCharArray()) {
            if (ch <= 0x20 || ch == 0x7f) throw new InvalidTarget("control-or-space");
        }
        URI u;
        try {
            u = new URI(raw);
        } catch (URISyntaxException e) {
            throw new InvalidTarget("syntax");
        }
        String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
        if (!scheme.equals("http") && !scheme.equals("https")) throw new InvalidTarget("scheme:" + scheme);
        if (u.getRawUserInfo() != null) throw new InvalidTarget("userinfo");
        if (u.getHost() == null || u.getHost().isEmpty()) throw new InvalidTarget("host");
        return u.toASCIIString();
    }

    public static Created createRandom(Connection c, String owner, String target, Integer ttlSeconds,
                                       Supplier<String> gen) throws SQLException, InvalidTarget {
        String t = validateTarget(target);
        int collisions = 0;
        for (int i = 0; i < MAX_TRIES; i++) {
            String code = gen.get();
            int n = Db.update(c, """
                INSERT INTO link(code, target, owner, kind, state, expires_at)
                VALUES (?, ?, ?, 'RANDOM', 'ACTIVE',
                        CASE WHEN ?::int IS NULL THEN NULL ELSE now() + make_interval(secs => ?::int) END)
                ON CONFLICT (code) DO NOTHING""", code, t, owner, ttlSeconds, ttlSeconds);
            if (n == 1) return new Created(code, collisions);
            collisions++;
        }
        throw new SQLException("code space exhausted after " + MAX_TRIES + " collisions", "P0001");
    }

    /** 别名冲突直接拒绝：插入失败时不更新已有行。 */
    public static Created createAlias(Connection c, String owner, String alias, String target)
            throws SQLException, AliasTaken, InvalidTarget {
        String t = validateTarget(target);
        try {
            Db.update(c, "INSERT INTO link(code, target, owner, kind, state) VALUES (?, ?, ?, 'ALIAS', 'ACTIVE')",
                    alias, t, owner);
            return new Created(alias, 0);
        } catch (SQLException e) {
            if ("23505".equals(e.getSQLState())) throw new AliasTaken(alias);
            throw e;
        }
    }

    /** 撤销：版本加一并追加一条变更记录，二者同一事务提交。返回新版本，未撤销任何行时返回 -1。 */
    public static long revoke(Connection c, String code) throws SQLException {
        return revoke(c, code, true, null);
    }

    /** 变更日志的写入锁键。持有到提交，使 link_change.seq 的分配顺序与提交顺序一致。 */
    static final long CHANGE_LOG_LOCK = 34_0001L;

    /**
     * serialize=false 仅用于负向对照：不取写入锁，两个撤销可以先拿序号后提交，
     * 轮询者按 seq 推进游标时可能越过一个尚未提交的较小序号。
     * beforeCommit 是测试钩子，在变更记录写入之后、提交之前调用。
     */
    public static long revoke(Connection c, String code, boolean serialize, Runnable beforeCommit) throws SQLException {
        c.setAutoCommit(false);
        try {
            if (serialize) {
                try (PreparedStatement ps = c.prepareStatement("SELECT pg_advisory_xact_lock(?)")) {
                    ps.setLong(1, CHANGE_LOG_LOCK);
                    ps.execute();
                }
            }
            long v = -1;
            try (PreparedStatement ps = c.prepareStatement("""
                    UPDATE link SET state = 'REVOKED', version = version + 1, revoked_at = now()
                     WHERE code = ? AND state = 'ACTIVE' RETURNING version""")) {
                ps.setString(1, code);
                try (ResultSet rs = ps.executeQuery()) { if (rs.next()) v = rs.getLong(1); }
            }
            if (v > 0) Db.update(c, "INSERT INTO link_change(code, version) VALUES (?, ?)", code, v);
            if (beforeCommit != null) beforeCommit.run();
            c.commit();
            return v;
        } catch (SQLException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
    }
}
