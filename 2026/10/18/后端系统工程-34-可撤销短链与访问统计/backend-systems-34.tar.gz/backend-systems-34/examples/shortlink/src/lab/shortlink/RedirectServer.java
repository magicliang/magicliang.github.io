package lab.shortlink;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;

import lab.common.Db;

/**
 * 重定向服务。主路径只依赖 link 表（经本地缓存）；统计写入走有界队列，队列满时丢弃并计数。
 * 撤销通过两条途径进入缓存：link_change 轮询（按版本淘汰）与条目 TTL（轮询失效时的上界）。
 */
public final class RedirectServer implements AutoCloseable {
    public enum StatsMode { ASYNC, SYNC }

    /** versionGuard=false 仅用于负向对照：回源结果不与轮询已见版本比较。 */
    public record Config(long cacheTtlMs, long pollMs, StatsMode statsMode, int queueCapacity, String statsUrl,
                         boolean versionGuard) {}

    record Entry(String target, String state, long version, long expiresAtMs, long loadedAtNanos) {}

    public record Click(UUID id, String code, Instant at) {}

    private final Config cfg;
    private final HttpServer server;
    private final ExecutorService pool = Executors.newFixedThreadPool(16);
    private final BlockingQueue<Connection> mainConns = new ArrayBlockingQueue<>(4);
    private final Map<String, Entry> cache = new ConcurrentHashMap<>();
    /** 轮询已见到的每个码的最新版本；回源结果版本更旧时不进缓存。 */
    private final Map<String, Long> seenVersion = new ConcurrentHashMap<>();
    /** 测试钩子：回源读到行之后、写入缓存之前调用，用来构造“读在撤销之前、填充在撤销之后”的交错。 */
    public volatile java.util.function.Consumer<String> afterLoadHook;
    private final BlockingQueue<Click> queue;
    private final StatsWriter writer;
    private final Thread poller;
    private volatile boolean running = true;
    private volatile long lastSeq;

    public final AtomicLong redirects = new AtomicLong();
    public final AtomicLong enqueued = new AtomicLong();
    public final AtomicLong dropped = new AtomicLong();
    public final AtomicLong dbLoads = new AtomicLong();
    public final AtomicLong pollEvictions = new AtomicLong();

    public RedirectServer(Config cfg) throws IOException, SQLException {
        this.cfg = cfg;
        for (int i = 0; i < 4; i++) mainConns.add(Db.connect());
        try (Connection c = Db.connect()) {
            lastSeq = Db.queryLong(c, "SELECT coalesce(max(seq), 0) FROM link_change");
        }
        queue = new ArrayBlockingQueue<>(cfg.queueCapacity());
        writer = new StatsWriter(queue, cfg.statsUrl());
        if (cfg.statsMode() == StatsMode.ASYNC) writer.start();
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 128);
        server.createContext("/", this::handle);
        server.setExecutor(pool);
        server.start();
        poller = new Thread(this::pollLoop, "revocation-poller");
        poller.setDaemon(true);
        if (cfg.pollMs() > 0) poller.start();
    }

    public String baseUrl() { return "http://127.0.0.1:" + server.getAddress().getPort(); }
    public StatsWriter writer() { return writer; }
    public int queued() { return queue.size(); }
    public long seenVersion(String code) { return seenVersion.getOrDefault(code, 0L); }

    private void handle(HttpExchange ex) throws IOException {
        try {
            if (!ex.getRequestMethod().equals("GET") && !ex.getRequestMethod().equals("HEAD")) {
                send(ex, 405, null);
                return;
            }
            String code = ex.getRequestURI().getPath().substring(1);
            Entry e = lookup(code);
            if (e == null) { send(ex, 404, null); return; }
            if (!e.state().equals("ACTIVE") || System.currentTimeMillis() >= e.expiresAtMs()) {
                send(ex, 410, null);
                return;
            }
            Click click = new Click(UUID.randomUUID(), code, Instant.now());
            if (cfg.statsMode() == StatsMode.SYNC) {
                writer.insertNow(click);  // 负向对照：统计写入阻塞在重定向路径上
            } else if (queue.offer(click)) {
                enqueued.incrementAndGet();
            } else {
                dropped.incrementAndGet();
            }
            redirects.incrementAndGet();
            // 观测用：本次 302 所依据的缓存条目年龄
            ex.getResponseHeaders().set("X-Entry-Age-Ms", Long.toString((System.nanoTime() - e.loadedAtNanos()) / 1_000_000));
            send(ex, 302, e.target());
        } catch (Exception err) {
            send(ex, 503, null);
        }
    }

    private Entry lookup(String code) throws SQLException, InterruptedException {
        Entry e = cache.get(code);
        long now = System.nanoTime();
        if (e != null && (now - e.loadedAtNanos()) / 1_000_000 < cfg.cacheTtlMs()) return e;
        Connection c = mainConns.take();
        try (PreparedStatement ps = c.prepareStatement("""
                SELECT target, state, version,
                       coalesce((extract(epoch FROM expires_at) * 1000)::bigint, 9223372036854775807)
                  FROM link WHERE code = ?""")) {
            ps.setString(1, code);
            dbLoads.incrementAndGet();
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) { cache.remove(code); return null; }
                Entry fresh = new Entry(rs.getString(1), rs.getString(2), rs.getLong(3), rs.getLong(4), System.nanoTime());
                java.util.function.Consumer<String> hook = afterLoadHook;
                if (hook != null) hook.accept(code);
                // 与轮询线程的 computeIfPresent 在同一个键上串行：轮询先登记版本再淘汰，
                // 因此旧读要么在这里被拒绝，要么先进缓存再被随后的淘汰删掉。
                cache.compute(code, (k, old) ->
                        cfg.versionGuard() && fresh.version() < seenVersion.getOrDefault(k, 0L) ? null : fresh);
                return fresh;
            }
        } finally {
            mainConns.add(c);
        }
    }

    private void pollLoop() {
        while (running) {
            try (Connection c = Db.connect();
                 PreparedStatement ps = c.prepareStatement(
                     "SELECT seq, code, version FROM link_change WHERE seq > ? ORDER BY seq")) {
                while (running) {
                    ps.setLong(1, lastSeq);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            long seq = rs.getLong(1);
                            String code = rs.getString(2);
                            long v = rs.getLong(3);
                            seenVersion.merge(code, v, Math::max);
                            // 只淘汰版本更旧的条目，迟到的旧变更不会删掉更新的缓存。
                            boolean[] evicted = { false };
                            cache.computeIfPresent(code, (k, old) -> {
                                if (old.version() < v) { evicted[0] = true; return null; }
                                return old;
                            });
                            if (evicted[0]) pollEvictions.incrementAndGet();
                            lastSeq = seq;
                        }
                    }
                    Thread.sleep(cfg.pollMs());
                }
            } catch (InterruptedException ie) {
                return;
            } catch (SQLException e) {
                try { Thread.sleep(cfg.pollMs()); } catch (InterruptedException ie) { return; }
            }
        }
    }

    private static void send(HttpExchange ex, int status, String location) throws IOException {
        // 所有响应都不允许缓存：302 本身不可启发式缓存，但 404/410 可以，显式指令让撤销只取决于服务端。
        ex.getResponseHeaders().set("Cache-Control", "no-store");
        if (location != null) ex.getResponseHeaders().set("Location", location);
        // RFC 9110 §15.5.6：405 响应必须带 Allow，列出目标资源支持的方法。
        if (status == 405) ex.getResponseHeaders().set("Allow", "GET, HEAD");
        byte[] body = (status + "\n").getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders(status, ex.getRequestMethod().equals("HEAD") ? -1 : body.length);
        try (OutputStream os = ex.getResponseBody()) {
            if (!ex.getRequestMethod().equals("HEAD")) os.write(body);
        }
    }

    @Override public void close() {
        running = false;
        poller.interrupt();
        writer.stop();
        server.stop(0);
        pool.shutdownNow();
        for (Connection c : mainConns) { try { c.close(); } catch (SQLException ignored) { } }
    }

    /** 统计写入器：批量插入，click_id 主键去重；失败时保留批次重试，形成至少一次入库。 */
    public static final class StatsWriter {
        private final BlockingQueue<Click> queue;
        private volatile String url;
        private final Thread thread;
        private volatile boolean running = true;
        private java.util.List<Click> pending = new java.util.ArrayList<>();
        private Connection conn;
        public volatile boolean loseAckOnce;
        private volatile boolean reconnect;
        public final AtomicLong batchAttempts = new AtomicLong();
        public final AtomicLong batchFailures = new AtomicLong();
        public final AtomicLong rowsInserted = new AtomicLong();
        public final AtomicLong rowsDeduplicated = new AtomicLong();
        public volatile String lastError = "";

        StatsWriter(BlockingQueue<Click> queue, String url) {
            this.queue = queue;
            this.url = url;
            this.thread = new Thread(this::loop, "stats-writer");
            this.thread.setDaemon(true);
        }

        void start() { thread.start(); }
        void stop() { running = false; thread.interrupt(); }
        public void url(String u) { url = u; reconnect = true; }
        public synchronized int pendingSize() { return pending.size(); }

        private void loop() {
            while (running) {
                try {
                    if (pendingSize() == 0) {
                        Click first = queue.poll(20, java.util.concurrent.TimeUnit.MILLISECONDS);
                        if (first == null) continue;
                        synchronized (this) { pending.add(first); queue.drainTo(pending, 99); }
                    }
                    if (!flush()) Thread.sleep(100);
                } catch (InterruptedException ie) {
                    return;
                }
            }
        }

        private boolean flush() {
            java.util.List<Click> batch;
            synchronized (this) { batch = new java.util.ArrayList<>(pending); }
            batchAttempts.incrementAndGet();
            try {
                Connection c = conn();
                c.setAutoCommit(false);
                int inserted = 0;
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO click(click_id, code, clicked_at) VALUES (?, ?, ?) ON CONFLICT (click_id) DO NOTHING")) {
                    for (Click k : batch) {
                        ps.setObject(1, k.id());
                        ps.setString(2, k.code());
                        ps.setTimestamp(3, Timestamp.from(k.at()));
                        inserted += ps.executeUpdate();
                    }
                }
                c.commit();
                rowsInserted.addAndGet(inserted);
                rowsDeduplicated.addAndGet(batch.size() - inserted);
                if (loseAckOnce) {
                    // 模拟“提交成功但确认丢失”：写入器认为失败，保留批次重试。
                    loseAckOnce = false;
                    batchFailures.incrementAndGet();
                    lastError = "ack lost after commit (simulated)";
                    closeConn();
                    return false;
                }
                synchronized (this) { pending = new java.util.ArrayList<>(); }
                return true;
            } catch (SQLException e) {
                batchFailures.incrementAndGet();
                lastError = e.getSQLState() + " " + e.getMessage().split("\n")[0];
                closeConn();
                return false;
            }
        }

        void insertNow(Click k) throws SQLException {
            try (Connection c = java.sql.DriverManager.getConnection(url, "postgres", "");
                 PreparedStatement ps = c.prepareStatement(
                     "INSERT INTO click(click_id, code, clicked_at) VALUES (?, ?, ?) ON CONFLICT (click_id) DO NOTHING")) {
                ps.setObject(1, k.id());
                ps.setString(2, k.code());
                ps.setTimestamp(3, Timestamp.from(k.at()));
                ps.executeUpdate();
            }
        }

        private Connection conn() throws SQLException {
            if (reconnect) { reconnect = false; closeConn(); }
            if (conn == null) {
                conn = java.sql.DriverManager.getConnection(url, "postgres", "");
                Db.exec(conn, "SET lock_timeout = '200ms'");
            }
            return conn;
        }

        private void closeConn() {
            Connection c = conn;
            conn = null;
            if (c != null) { try { c.close(); } catch (SQLException ignored) { } }
        }
    }
}
