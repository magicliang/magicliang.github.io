package lab.shortlink;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.Connection;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import lab.common.Check;
import lab.common.Db;

public final class Main {
    static final String DB = System.getenv().getOrDefault("LAB_DB", "shortlink34");
    static final String STATS_DB = DB + "_stats";
    static final HttpClient HTTP = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1)
            .followRedirects(HttpClient.Redirect.NEVER).build();

    public static void main(String[] args) throws Exception {
        Db.recreate(DB);
        Db.recreate(STATS_DB);
        try (Connection c = Db.connect(DB)) {
            Db.exec(c, LinkService.DDL);
            Db.exec(c, "CREATE TABLE link_naive (code text PRIMARY KEY, target text NOT NULL)");
        }
        try (Connection s = Db.connect(STATS_DB)) { Db.exec(s, LinkService.STATS_DDL); }
        try (Connection c = Db.connect(DB)) {
            v1Targets();
            a1AliasRace(c);
            nc1NaiveAlias(c);
            a2RandomCollision(c);
            a3ConcurrentRandom();
            r1RedirectAndStatus(c);
            r2RevocationWindow(c, 100, 2000, "R2", "轮询开启（poll=100ms, TTL=2000ms）");
            r2RevocationWindow(c, 0, 1500, "R3", "轮询关闭（只剩 TTL=1500ms 上界）");
            r4StaleFill(c, true, "R4", "回源读在撤销提交前、缓存填充在轮询淘汰后：版本守卫拒绝旧读");
            r4StaleFill(c, false, "NC3", "负向对照：去掉版本守卫，同一交错让旧条目留在缓存直到 TTL");
            r5ChangeOrder(c, true, "R5", "两个撤销交错提交：变更日志写入锁使序号顺序等于提交顺序");
            r5ChangeOrder(c, false, "NC4", "负向对照：不取写入锁，小序号晚提交，轮询游标越过它");
            s1StatsNormal(c);
            s2StatsDown(c);
            s3StatsLocked(c);
            nc2SyncStats(c);
            s4Replay(c);
        }
        System.exit(Check.finish());
    }

    static String statsUrl() { return Db.url(STATS_DB); }

    record Resp(int status, String location, String cacheControl, long entryAgeMs) {}

    static Resp get(RedirectServer srv, String code, long timeoutMs) throws Exception {
        HttpRequest r = HttpRequest.newBuilder(URI.create(srv.baseUrl() + "/" + code))
                .timeout(Duration.ofMillis(timeoutMs)).GET().build();
        HttpResponse<String> resp = HTTP.send(r, HttpResponse.BodyHandlers.ofString());
        return new Resp(resp.statusCode(), resp.headers().firstValue("Location").orElse(null),
                resp.headers().firstValue("Cache-Control").orElse(null),
                Long.parseLong(resp.headers().firstValue("X-Entry-Age-Ms").orElse("-1")));
    }

    static RedirectServer server(long ttl, long poll, RedirectServer.StatsMode mode, int cap, String statsUrl)
            throws Exception {
        return new RedirectServer(new RedirectServer.Config(ttl, poll, mode, cap, statsUrl, true));
    }

    static long clicks(String code) throws Exception {
        try (Connection s = Db.connect(STATS_DB)) {
            return Db.queryLong(s, "SELECT count(*) FROM click WHERE code = ?", code);
        }
    }

    static void waitDrained(RedirectServer srv, long ms) throws Exception {
        long end = System.currentTimeMillis() + ms;
        while ((srv.queued() > 0 || srv.writer().pendingSize() > 0) && System.currentTimeMillis() < end) Thread.sleep(20);
    }

    static void v1Targets() {
        Check.begin("V1", "目标地址校验：只允许带主机名的 http/https");
        String[] ok = { "https://docs.example.test/guide?id=7", "http://example.test/a" };
        String[] bad = { "javascript:alert(1)", "data:text/html,hi", "//evil.example.test/x", "/relative/path",
                "ftp://files.example.test/a", "https://user-0042@login.example.test/", "https://example.test/a\r\nSet-Cookie:x=1",
                "https:///nohost" };
        for (String s : ok) {
            try { LinkService.validateTarget(s); Check.that(true, "接受 " + s); }
            catch (LinkService.InvalidTarget e) { Check.that(false, "接受 " + s + " -> " + e.getMessage()); }
        }
        for (String s : bad) {
            String shown = s.replace("\r", "\\r").replace("\n", "\\n");
            try { LinkService.validateTarget(s); Check.that(false, "拒绝 " + shown); }
            catch (LinkService.InvalidTarget e) { Check.that(true, "拒绝 " + shown + " (" + e.getMessage() + ")"); }
        }
    }

    static void a1AliasRace(Connection c) throws Exception {
        Check.begin("A1", "16 个线程并发创建同一别名 promo-q4，目标各不相同");
        int n = 16;
        CyclicBarrier gate = new CyclicBarrier(n);
        ExecutorService ex = Executors.newFixedThreadPool(n);
        List<Future<String>> fs = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            final int k = i;
            fs.add(ex.submit(() -> {
                try (Connection own = Db.connect(DB)) {
                    gate.await();
                    LinkService.createAlias(own, "user-" + String.format("%04d", k), "promo-q4",
                            "https://shop.example.test/q4?variant=" + k);
                    return "https://shop.example.test/q4?variant=" + k;
                } catch (LinkService.AliasTaken t) {
                    return null;
                }
            }));
        }
        List<String> winners = new ArrayList<>();
        int conflicts = 0;
        for (Future<String> f : fs) { String w = f.get(); if (w == null) conflicts++; else winners.add(w); }
        ex.shutdown();
        Check.equal(1, winners.size(), "成功创建数");
        Check.equal(15, conflicts, "收到 AliasTaken 的调用数");
        Check.equal(winners.get(0), Db.queryString(c, "SELECT target FROM link WHERE code = 'promo-q4'"),
                "库中目标等于唯一成功者提交的目标");
    }

    static void nc1NaiveAlias(Connection c) throws Exception {
        Check.begin("NC1", "负向对照：先查后写 + ON CONFLICT DO UPDATE（覆盖式 upsert）");
        int n = 16;
        CyclicBarrier afterCheck = new CyclicBarrier(n);
        ExecutorService ex = Executors.newFixedThreadPool(n);
        List<Future<String>> fs = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            final int k = i;
            fs.add(ex.submit(() -> {
                try (Connection own = Db.connect(DB)) {
                    boolean exists = Db.queryLong(own, "SELECT count(*) FROM link_naive WHERE code = 'promo-q4'") > 0;
                    afterCheck.await();
                    if (exists) return null;
                    String t = "https://shop.example.test/q4?variant=" + k;
                    Db.update(own, "INSERT INTO link_naive VALUES ('promo-q4', ?) ON CONFLICT (code) DO UPDATE SET target = EXCLUDED.target", t);
                    return t;
                }
            }));
        }
        List<String> told = new ArrayList<>();
        for (Future<String> f : fs) { String w = f.get(); if (w != null) told.add(w); }
        ex.shutdown();
        String finalTarget = Db.queryString(c, "SELECT target FROM link_naive WHERE code = 'promo-q4'");
        long overwritten = told.stream().filter(t -> !t.equals(finalTarget)).count();
        Check.note("报告成功的调用数 " + told.size() + "，其目标已被覆盖的调用数 " + overwritten);
        Check.exposes(overwritten > 0, "多个创建者都被告知成功，其中至少一个的目标已被他人覆盖");
    }

    static void a2RandomCollision(Connection c) throws Exception {
        Check.begin("A2", "随机码冲突：插入失败后换码重试；连续冲突达到上限则报错");
        LinkService.createAlias(c, "user-0001", "Abc23456", "https://example.test/existing");
        Deque<String> script = new ArrayDeque<>(List.of("Abc23456", "promo-q4", "Zxy98765"));
        LinkService.Created r = LinkService.createRandom(c, "user-0002", "https://example.test/new", null, script::poll);
        Check.equal("Zxy98765", r.code(), "最终使用的码");
        Check.equal(2, r.collisions(), "冲突重试次数");
        Check.equal("https://example.test/existing", Db.queryString(c, "SELECT target FROM link WHERE code = 'Abc23456'"),
                "已有行未被覆盖");
        try {
            LinkService.createRandom(c, "user-0003", "https://example.test/x", null, () -> "Abc23456");
            Check.that(false, "连续冲突应报错");
        } catch (java.sql.SQLException e) {
            Check.that(e.getMessage().contains("exhausted"), "连续 " + LinkService.MAX_TRIES + " 次冲突后报错: " + e.getMessage());
        }
    }

    static void a3ConcurrentRandom() throws Exception {
        Check.begin("A3", "16 线程 × 50 次随机码创建");
        ExecutorService ex = Executors.newFixedThreadPool(16);
        List<Future<List<String>>> fs = new ArrayList<>();
        for (int i = 0; i < 16; i++) {
            final int k = i;
            fs.add(ex.submit(() -> {
                List<String> codes = new ArrayList<>();
                try (Connection own = Db.connect(DB)) {
                    for (int j = 0; j < 50; j++)
                        codes.add(LinkService.createRandom(own, "user-0" + (100 + k), "https://example.test/p/" + k + "/" + j,
                                null, LinkService::randomCode).code());
                }
                return codes;
            }));
        }
        Set<String> all = new HashSet<>();
        int returned = 0;
        for (Future<List<String>> f : fs) { List<String> l = f.get(); returned += l.size(); all.addAll(l); }
        ex.shutdown();
        Check.equal(800, returned, "返回码数");
        Check.equal(800, all.size(), "不同码数");
        try (Connection c = Db.connect(DB)) {
            Check.equal(800L, Db.queryLong(c, "SELECT count(*) FROM link WHERE kind = 'RANDOM' AND owner LIKE 'user-01%'"), "库中行数");
        }
    }

    static void r1RedirectAndStatus(Connection c) throws Exception {
        Check.begin("R1", "重定向、未知码、过期、方法限制与响应头");
        String code = LinkService.createRandom(c, "user-0042", "https://docs.example.test/guide?id=7", null, LinkService::randomCode).code();
        String exp = LinkService.createRandom(c, "user-0042", "https://docs.example.test/flash", 1, LinkService::randomCode).code();
        try (RedirectServer srv = server(5000, 100, RedirectServer.StatsMode.ASYNC, 64, statsUrl())) {
            Resp r = get(srv, code, 2000);
            Check.equal(302, r.status(), "活跃短链状态码");
            Check.equal("https://docs.example.test/guide?id=7", r.location(), "Location");
            Check.equal("no-store", r.cacheControl(), "302 的 Cache-Control");
            Resp nf = get(srv, "nope-000", 2000);
            Check.equal(404, nf.status(), "未知码状态码");
            Check.equal("no-store", nf.cacheControl(), "404 的 Cache-Control");
            Check.equal(302, get(srv, exp, 2000).status(), "过期前访问");
            Thread.sleep(1200);
            Check.equal(410, get(srv, exp, 2000).status(), "过期后访问（条目仍在缓存 TTL 内）");
            HttpResponse<String> post = HTTP.send(HttpRequest.newBuilder(URI.create(srv.baseUrl() + "/" + code))
                    .POST(HttpRequest.BodyPublishers.noBody()).build(), HttpResponse.BodyHandlers.ofString());
            Check.equal(405, post.statusCode(), "POST 状态码");
            Check.equal("GET, HEAD", post.headers().firstValue("Allow").orElse(null), "405 带 Allow 头（RFC 9110 §15.5.6）");
        }
    }

    static void r2RevocationWindow(Connection c, long poll, long ttl, String id, String label) throws Exception {
        Check.begin(id, "撤销生效窗口，真实 HTTP 测量：" + label);
        String code = LinkService.createRandom(c, "user-0042", "https://docs.example.test/rev/" + id, null, LinkService::randomCode).code();
        try (RedirectServer srv = server(ttl, poll, RedirectServer.StatsMode.ASYNC, 1024, statsUrl())) {
            Check.equal(302, get(srv, code, 2000).status(), "撤销前访问（同时装入缓存）");
            long v = LinkService.revoke(c, code);
            long t0 = System.nanoTime();
            Check.equal(2L, v, "撤销后版本");
            int stale = 0;
            long t1 = -1, maxAge = -1, maxGapMs = 0, prevStart = t0;
            long deadline = t0 + (ttl + 3000) * 1_000_000L;
            while (System.nanoTime() < deadline) {
                long start = System.nanoTime();
                maxGapMs = Math.max(maxGapMs, (start - prevStart) / 1_000_000);
                prevStart = start;
                Resp rr = get(srv, code, 2000);
                if (rr.status() == 410) { t1 = System.nanoTime(); break; }
                if (rr.status() == 302) { stale++; maxAge = Math.max(maxAge, rr.entryAgeMs()); }
                Thread.sleep(5);
            }
            long windowMs = (t1 - t0) / 1_000_000;
            Check.that(t1 > 0, "撤销最终生效（返回 410）");
            Check.note("撤销提交后仍返回 302 的请求数 " + stale + "，首次 410 响应距提交 " + windowMs
                    + " ms，相邻两次请求发起间隔最大 " + maxGapMs + " ms（本机观察值）");
            Check.that(maxAge < ttl, "撤销后每个 302 依据的缓存条目年龄都小于 TTL（最大 " + maxAge + " ms）");
            Check.that(windowMs <= ttl + maxGapMs + 100, "观察窗口不超过 TTL + 采样间隔 + 100ms 余量");
            Check.note("轮询淘汰次数 " + srv.pollEvictions.get() + "，回源加载次数 " + srv.dbLoads.get());
            Check.equal(410, get(srv, code, 2000).status(), "之后的访问保持 410");
        }
        long v2 = LinkService.revoke(c, code);
        Check.equal(-1L, v2, "重复撤销不再产生新版本");
    }

    static void r4StaleFill(Connection c, boolean guard, String id, String label) throws Exception {
        Check.begin(id, label);
        String code = LinkService.createRandom(c, "user-0042", "https://docs.example.test/fill/" + id, null,
                LinkService::randomCode).code();
        long ttl = 5000;
        try (RedirectServer srv = new RedirectServer(new RedirectServer.Config(ttl, 50,
                RedirectServer.StatsMode.ASYNC, 64, statsUrl(), guard))) {
            java.util.concurrent.CountDownLatch loaded = new java.util.concurrent.CountDownLatch(1);
            java.util.concurrent.CountDownLatch release = new java.util.concurrent.CountDownLatch(1);
            srv.afterLoadHook = k -> {
                if (!k.equals(code)) return;
                loaded.countDown();
                try { release.await(); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
            };
            ExecutorService ex = Executors.newSingleThreadExecutor();
            Future<Resp> first = ex.submit(() -> get(srv, code, 10000));
            Check.that(loaded.await(5, java.util.concurrent.TimeUnit.SECONDS), "请求 A 已读到 ACTIVE 行并停在填充缓存之前");
            long v = LinkService.revoke(c, code);
            long end = System.currentTimeMillis() + 5000;
            while (srv.seenVersion(code) < v && System.currentTimeMillis() < end) Thread.sleep(10);
            Check.equal(v, srv.seenVersion(code), "轮询线程已处理撤销变更（已见版本）");
            srv.afterLoadHook = null;
            release.countDown();
            Resp a = first.get(10, java.util.concurrent.TimeUnit.SECONDS);
            ex.shutdown();
            Check.equal(302, a.status(), "请求 A 依据撤销前读到的行返回 302");
            Resp b = get(srv, code, 2000);
            Check.note("请求 A 完成后的下一次访问状态 " + b.status() + "，回源加载次数 " + srv.dbLoads.get()
                    + "，轮询淘汰次数 " + srv.pollEvictions.get());
            if (guard) {
                Check.equal(410, b.status(), "下一次访问回源并返回 410");
                Check.equal(2L, srv.dbLoads.get(), "旧读没有进入缓存，第二次访问重新回源");
            } else {
                Check.exposes(b.status() == 302, "轮询已处理撤销，旧条目仍被写入缓存并继续返回 302");
            }
        }
    }

    static void r5ChangeOrder(Connection c, boolean serialize, String id, String label) throws Exception {
        Check.begin(id, label);
        String x = LinkService.createRandom(c, "user-0042", "https://docs.example.test/ord/x/" + id, null,
                LinkService::randomCode).code();
        String y = LinkService.createRandom(c, "user-0042", "https://docs.example.test/ord/y/" + id, null,
                LinkService::randomCode).code();
        try (RedirectServer srv = server(5000, 50, RedirectServer.StatsMode.ASYNC, 64, statsUrl());
             Connection ca = Db.connect(DB); Connection cb = Db.connect(DB)) {
            Check.equal(302, get(srv, x, 2000).status(), "X 撤销前访问（装入缓存）");
            Check.equal(302, get(srv, y, 2000).status(), "Y 撤销前访问（装入缓存）");
            java.util.concurrent.CountDownLatch aWritten = new java.util.concurrent.CountDownLatch(1);
            java.util.concurrent.CountDownLatch releaseA = new java.util.concurrent.CountDownLatch(1);
            ExecutorService ex = Executors.newFixedThreadPool(2);
            Future<Long> fa = ex.submit(() -> LinkService.revoke(ca, x, serialize, () -> {
                aWritten.countDown();
                try { releaseA.await(); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
            }));
            Check.that(aWritten.await(5, java.util.concurrent.TimeUnit.SECONDS), "撤销 A（X）已写入变更记录、尚未提交");
            Future<Long> fb = ex.submit(() -> LinkService.revoke(cb, y, serialize, null));
            boolean bDoneEarly;
            try { fb.get(400, java.util.concurrent.TimeUnit.MILLISECONDS); bDoneEarly = true; }
            catch (java.util.concurrent.TimeoutException te) { bDoneEarly = false; }
            if (bDoneEarly) {
                long end = System.currentTimeMillis() + 3000;
                while (srv.seenVersion(y) < 2 && System.currentTimeMillis() < end) Thread.sleep(10);
            }
            Check.note("A 未提交时 B 是否已提交: " + bDoneEarly + "，此时轮询已见 Y 版本 " + srv.seenVersion(y));
            releaseA.countDown();
            Check.equal(2L, fa.get(5, java.util.concurrent.TimeUnit.SECONDS), "撤销 A 提交后的版本");
            Check.equal(2L, fb.get(5, java.util.concurrent.TimeUnit.SECONDS), "撤销 B 提交后的版本");
            ex.shutdown();
            Thread.sleep(500);  // 约 10 个轮询周期
            long seqX = Db.queryLong(c, "SELECT seq FROM link_change WHERE code = ?", x);
            long seqY = Db.queryLong(c, "SELECT seq FROM link_change WHERE code = ?", y);
            int sx = get(srv, x, 2000).status(), sy = get(srv, y, 2000).status();
            Check.note("seq(X)=" + seqX + " seq(Y)=" + seqY + "，提交 500ms 后轮询已见版本 X=" + srv.seenVersion(x)
                    + " Y=" + srv.seenVersion(y) + "，访问状态 X=" + sx + " Y=" + sy);
            if (serialize) {
                Check.that(!bDoneEarly, "A 提交前 B 在写入锁上等待");
                Check.that(seqX < seqY, "序号顺序与提交顺序一致（A 先）");
                Check.equal(2L, srv.seenVersion(x), "轮询见到 X 的撤销");
                Check.equal(410, sx, "X 返回 410");
                Check.equal(410, sy, "Y 返回 410");
            } else {
                Check.that(bDoneEarly && seqX < seqY, "前提成立：小序号的 A 晚于 B 提交");
                Check.exposes(srv.seenVersion(x) < 2 && sx == 302,
                        "轮询游标越过晚提交的小序号，X 的撤销被漏掉，缓存继续返回 302");
            }
        }
    }

    static void s1StatsNormal(Connection c) throws Exception {
        Check.begin("S1", "统计正常：20 次点击全部入库");
        String code = LinkService.createAlias(c, "user-0042", "stats-ok", "https://example.test/s1").code();
        try (RedirectServer srv = server(5000, 0, RedirectServer.StatsMode.ASYNC, 64, statsUrl())) {
            int ok = 0;
            for (int i = 0; i < 20; i++) if (get(srv, code, 2000).status() == 302) ok++;
            waitDrained(srv, 5000);
            Check.equal(20, ok, "302 次数");
            Check.equal(0L, srv.dropped.get(), "丢弃数");
            Check.equal(20L, clicks(code), "统计库点击数");
        }
    }

    static void s2StatsDown(Connection c) throws Exception {
        Check.begin("S2", "统计库连接失败：重定向不受影响，队列满后丢弃并计数，恢复后补写");
        String code = LinkService.createAlias(c, "user-0042", "stats-down", "https://example.test/s2").code();
        String badUrl = "jdbc:postgresql://localhost:1/" + STATS_DB + "?connectTimeout=1";
        try (RedirectServer srv = server(5000, 0, RedirectServer.StatsMode.ASYNC, 8, badUrl)) {
            int ok = 0;
            for (int i = 0; i < 30; i++) { if (get(srv, code, 1000).status() == 302) ok++; Thread.sleep(5); }
            Check.equal(30, ok, "统计库不可达期间 302 次数");
            Check.that(srv.writer().batchFailures.get() >= 1, "写入器记录失败批次 " + srv.writer().batchFailures.get()
                    + "，最后错误: " + srv.writer().lastError);
            long dropped = srv.dropped.get();
            Check.that(dropped > 0, "有界队列满后丢弃 " + dropped + " 次");
            Check.equal(30L, srv.enqueued.get() + dropped, "入队数 + 丢弃数 = 302 次数");
            srv.writer().url(statsUrl());
            waitDrained(srv, 5000);
            Check.equal(30L - dropped, clicks(code), "恢复后统计库点击数 = 入队数");
        }
    }

    static void s3StatsLocked(Connection c) throws Exception {
        Check.begin("S3", "统计表被 ACCESS EXCLUSIVE 锁住：重定向仍返回 302");
        String code = LinkService.createAlias(c, "user-0042", "stats-lock", "https://example.test/s3").code();
        try (RedirectServer srv = server(5000, 0, RedirectServer.StatsMode.ASYNC, 64, statsUrl());
             Connection locker = Db.connect(STATS_DB)) {
            locker.setAutoCommit(false);
            Db.exec(locker, "LOCK TABLE click IN ACCESS EXCLUSIVE MODE");
            int ok = 0;
            for (int i = 0; i < 20; i++) { if (get(srv, code, 1000).status() == 302) ok++; Thread.sleep(20); }
            Check.equal(20, ok, "锁持有期间 302 次数（客户端超时 1000ms）");
            Check.that(srv.writer().batchFailures.get() >= 1, "写入器因锁等待失败 " + srv.writer().batchFailures.get()
                    + " 次，最后错误: " + srv.writer().lastError);
            locker.rollback();
            waitDrained(srv, 5000);
            Check.equal(20L - srv.dropped.get(), clicks(code), "释放锁后点击数 = 入队数");
        }
    }

    static void nc2SyncStats(Connection c) throws Exception {
        Check.begin("NC2", "负向对照：统计同步写在重定向路径上，统计表被锁时重定向超时");
        String code = LinkService.createAlias(c, "user-0042", "stats-sync", "https://example.test/nc2").code();
        try (RedirectServer srv = server(5000, 0, RedirectServer.StatsMode.SYNC, 8, statsUrl());
             Connection locker = Db.connect(STATS_DB)) {
            locker.setAutoCommit(false);
            Db.exec(locker, "LOCK TABLE click IN ACCESS EXCLUSIVE MODE");
            int timeouts = 0, ok = 0;
            for (int i = 0; i < 3; i++) {
                try { if (get(srv, code, 1000).status() == 302) ok++; }
                catch (java.net.http.HttpTimeoutException e) { timeouts++; }
            }
            locker.rollback();
            Check.note("3 次请求中 302=" + ok + "，客户端超时=" + timeouts);
            Check.exposes(timeouts == 3, "统计表锁直接阻塞重定向");
        }
    }

    static void s4Replay(Connection c) throws Exception {
        Check.begin("S4", "统计重放：提交成功但确认丢失，批次重写不重复计数");
        String code = LinkService.createAlias(c, "user-0042", "stats-replay", "https://example.test/s4").code();
        try (RedirectServer srv = server(5000, 0, RedirectServer.StatsMode.ASYNC, 64, statsUrl())) {
            srv.writer().loseAckOnce = true;
            for (int i = 0; i < 10; i++) get(srv, code, 2000);
            waitDrained(srv, 5000);
            RedirectServer.StatsWriter w = srv.writer();
            Check.note("批次尝试 " + w.batchAttempts.get() + "，失败 " + w.batchFailures.get() + "，插入行 "
                    + w.rowsInserted.get() + "，主键去重行 " + w.rowsDeduplicated.get());
            Check.that(w.batchFailures.get() == 1 && w.batchAttempts.get() >= 2, "确认丢失的批次被重试");
            Check.that(w.rowsDeduplicated.get() > 0, "重试批次中有行被 click_id 去重");
            Check.equal(10L, w.rowsInserted.get(), "实际插入行数");
            Check.equal(10L, clicks(code), "统计库点击数");
        }
    }
}
