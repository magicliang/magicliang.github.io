# shortlink（第 34 篇）

可撤销短链与访问统计的最小实现：PostgreSQL 主键保证码唯一，重定向服务带本地缓存、变更日志轮询与条目 TTL，统计写入经有界队列异步入库并按 click_id 去重。

- 运行：`bash run.sh`（端口 55434，集群 b3-34；输出写入 `../../evidence/34/`）
- 代码：`src/lab/shortlink/LinkService.java`（建表、创建、别名、撤销）、`RedirectServer.java`（HTTP 重定向、缓存、轮询、统计写入器）、`Main.java`（全部用例）
- 用例与限制见 `../../evidence/34/output.txt` 与 `../../evidence/34/LIMITS.md`
