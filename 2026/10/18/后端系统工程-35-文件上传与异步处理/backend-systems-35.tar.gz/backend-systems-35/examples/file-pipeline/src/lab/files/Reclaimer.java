package lab.files;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;
import lab.common.Db;

/** 孤儿回收：过期会话 → 关闭会话的暂存分块 → 无引用且超过宽限期的 blob → 过旧的临时文件。 */
public final class Reclaimer {
    private final Store store;
    private final Duration grace;

    public Reclaimer(Store store, Duration grace) {
        this.store = store;
        this.grace = grace;
    }

    public record Report(int expired, int stagingRemoved, int blobsRemoved, int blobsKept, int tmpRemoved) {
        @Override public String toString() {
            return "expired=" + expired + " stagingRemoved=" + stagingRemoved + " blobsRemoved=" + blobsRemoved
                + " blobsKept=" + blobsKept + " tmpRemoved=" + tmpRemoved;
        }
    }

    /** 引用来源：任何 file_object；COMPLETED 会话的 blob；未结束会话声明的整体摘要。 */
    static final String REFERENCED = """
        SELECT (EXISTS (SELECT 1 FROM file_object WHERE blob_sha256 = ?)
             OR EXISTS (SELECT 1 FROM upload_session WHERE state = 'COMPLETED' AND blob_sha256 = ?)
             OR EXISTS (SELECT 1 FROM upload_session WHERE state IN ('INIT','UPLOADING') AND declared_sha256 = ?))::int""";

    public Report run(Instant now) throws SQLException, IOException {
        return run(now, true);
    }

    /** checkReferences=false 是负向对照：只看宽限期。 */
    public Report run(Instant now, boolean checkReferences) throws SQLException, IOException {
        int expired, staging = 0, removed = 0, kept = 0, tmpRemoved = 0;
        try (Connection c = Db.connect()) {
            expired = Db.update(c, """
                UPDATE upload_session SET state='EXPIRED', closed_reason='TTL'
                WHERE state IN ('INIT','UPLOADING','COMPLETED') AND expires_at <= ?""", Timestamp.from(now));
            List<String> closed = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT session_id FROM upload_session WHERE state IN ('COMMITTED','ABORTED','EXPIRED')");
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) closed.add(rs.getString(1));
            }
            for (String id : closed) {
                Path dir = store.sessionDir(id);
                if (Files.exists(dir)) {
                    deleteTree(dir);
                    staging++;
                }
            }
            Instant cutoff = now.minus(grace);
            List<Path> blobs;
            try (Stream<Path> s = Files.list(store.blobs)) {
                blobs = s.sorted().toList();
            }
            for (Path b : blobs) {
                String sha = b.getFileName().toString();
                c.setAutoCommit(false);
                try {
                    UploadService.lockBlob(c, sha);
                    boolean ref = checkReferences && Db.queryLong(c, REFERENCED, sha, sha, sha) == 1;
                    boolean old = Files.exists(b) && Files.getLastModifiedTime(b).toInstant().isBefore(cutoff);
                    if (!ref && old) {
                        Files.delete(b);
                        Store.fsyncDir(store.blobs);
                        removed++;
                    } else {
                        kept++;
                    }
                    c.commit();
                } finally {
                    c.setAutoCommit(true);
                }
            }
            try (Stream<Path> s = Files.list(store.tmp)) {
                for (Path t : s.toList()) {
                    if (Files.getLastModifiedTime(t).toInstant().isBefore(cutoff)) {
                        Files.delete(t);
                        tmpRemoved++;
                    }
                }
            }
        }
        return new Report(expired, staging, removed, kept, tmpRemoved);
    }

    static void deleteTree(Path dir) throws IOException {
        try (Stream<Path> s = Files.walk(dir)) {
            for (Path p : s.sorted(Comparator.reverseOrder()).toList()) Files.delete(p);
        }
    }
}
