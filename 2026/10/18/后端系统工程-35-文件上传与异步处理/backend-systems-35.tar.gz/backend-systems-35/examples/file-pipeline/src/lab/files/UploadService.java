package lab.files;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Supplier;
import lab.common.Db;

/** 上传会话、分块、完成、元数据提交、中止与读取。数据库是状态的唯一权威，文件系统只存字节。 */
public final class UploadService {
    private final Store store;
    private final Supplier<Instant> clock;
    private final Duration ttl;
    /** 崩溃注入点：after-fsync（临时文件已落盘、未改名）、after-rename（已改名进 blob 目录、未提交）。 */
    public Consumer<String> hook = p -> {};
    /** 元数据提交时的故障注入：插入 file_object 之后、提交之前抛出异常。 */
    public boolean failCommitAfterInsert = false;

    public UploadService(Store store, Supplier<Instant> clock, Duration ttl) {
        this.store = store;
        this.clock = clock;
        this.ttl = ttl;
    }

    public record Session(String sessionId, String state, Instant expiresAt) {}

    public Session init(String owner, int partCount, long size, String sha256) throws SQLException {
        Instant exp = clock.get().plus(ttl);
        try (Connection c = Db.connect()) {
            String id = String.format("up-%04d", Db.queryLong(c, "SELECT nextval('session_seq')"));
            Db.update(c, """
                INSERT INTO upload_session(session_id, owner, state, part_count, declared_size, declared_sha256, expires_at)
                VALUES (?, ?, 'INIT', ?, ?, ?, ?)""", id, owner, partCount, size, sha256, Timestamp.from(exp));
            return new Session(id, "INIT", exp);
        }
    }

    /** 返回 STORED 或 DUPLICATE；内容摘要不符抛 CHECKSUM_MISMATCH，同序号不同内容抛 PART_CONFLICT。 */
    public String putPart(String sessionId, int partNo, byte[] body, String claimedSha) throws SQLException, IOException {
        String actual = Store.sha256(body);
        if (!actual.equals(claimedSha)) throw new FileError("CHECKSUM_MISMATCH", "part " + partNo);
        Path tmp = store.tmp.resolve(sessionId + "-p" + partNo + "-" + UUID.randomUUID());
        Store.writeDurable(tmp, body);
        try (Connection c = Db.connect()) {
            c.setAutoCommit(false);
            try {
                SessionRow s = lockSession(c, sessionId);
                if (!s.state.equals("INIT") && !s.state.equals("UPLOADING"))
                    throw new FileError("SESSION_CLOSED", s.state);
                if (!clock.get().isBefore(s.expiresAt)) throw new FileError("SESSION_EXPIRED", sessionId);
                if (partNo < 1 || partNo > s.partCount) throw new FileError("PART_OUT_OF_RANGE", "" + partNo);
                int ins = Db.update(c, """
                    INSERT INTO upload_part(session_id, part_no, size, sha256) VALUES (?, ?, ?, ?)
                    ON CONFLICT (session_id, part_no) DO NOTHING""", sessionId, partNo, body.length, actual);
                String result;
                if (ins == 0) {
                    String existing = Db.queryString(c,
                        "SELECT sha256 FROM upload_part WHERE session_id=? AND part_no=?", sessionId, partNo);
                    if (!actual.equals(existing)) throw new FileError("PART_CONFLICT", "part " + partNo);
                    result = "DUPLICATE";
                } else {
                    Path dir = Files.createDirectories(store.sessionDir(sessionId));
                    Files.move(tmp, store.partPath(sessionId, partNo), StandardCopyOption.ATOMIC_MOVE);
                    Store.fsyncDir(dir);
                    Db.update(c, "UPDATE upload_session SET state='UPLOADING' WHERE session_id=? AND state='INIT'", sessionId);
                    result = "STORED";
                }
                c.commit();
                return result;
            } catch (SQLException | IOException | RuntimeException e) {
                c.rollback();
                throw e;
            } finally {
                Files.deleteIfExists(tmp);
            }
        }
    }

    /**
     * 校验分块集合 → 按序组装到临时文件并逐块复核摘要 → fsync → 比对整体摘要 →
     * 在 blob 级咨询锁内原子改名到内容地址 → fsync 目录 → 会话置 COMPLETED。
     */
    public String complete(String sessionId) throws SQLException, IOException {
        try (Connection c = Db.connect()) {
            c.setAutoCommit(false);
            Path tmp = store.tmp.resolve(sessionId + ".assembling");
            try {
                SessionRow s = lockSession(c, sessionId);
                if (s.state.equals("COMPLETED") || s.state.equals("COMMITTED")) {
                    c.rollback();
                    return s.blobSha;           // 重复调用 complete：返回已有结果
                }
                if (!s.state.equals("UPLOADING")) throw new FileError("SESSION_CLOSED", s.state);
                if (!clock.get().isBefore(s.expiresAt)) throw new FileError("SESSION_EXPIRED", sessionId);
                List<int[]> parts = new ArrayList<>();   // {part_no, size}
                List<String> shas = new ArrayList<>();
                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT part_no, size, sha256 FROM upload_part WHERE session_id=? ORDER BY part_no")) {
                    ps.setString(1, sessionId);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            parts.add(new int[]{rs.getInt(1), rs.getInt(2)});
                            shas.add(rs.getString(3));
                        }
                    }
                }
                long total = 0;
                for (int i = 0; i < parts.size(); i++) {
                    if (parts.get(i)[0] != i + 1) throw new FileError("MISSING_PARTS", "expected part " + (i + 1));
                    total += parts.get(i)[1];
                }
                if (parts.size() != s.partCount) throw new FileError("MISSING_PARTS", parts.size() + "/" + s.partCount);
                if (total != s.declaredSize) throw new FileError("SIZE_MISMATCH", total + "!=" + s.declaredSize);

                Files.deleteIfExists(tmp);
                MessageDigest whole = Store.sha256();
                try (FileChannel ch = FileChannel.open(tmp, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
                     OutputStream out = Channels.newOutputStream(ch)) {
                    for (int i = 0; i < parts.size(); i++) {
                        byte[] b = Files.readAllBytes(store.partPath(sessionId, i + 1));
                        if (!Store.sha256(b).equals(shas.get(i)))
                            throw new FileError("PART_CORRUPT", "part " + (i + 1));
                        out.write(b);
                        whole.update(b);
                    }
                    out.flush();
                    ch.force(true);
                }
                String sha = Store.hex(whole.digest());
                if (!sha.equals(s.declaredSha)) {
                    Files.deleteIfExists(tmp);
                    Db.update(c, "UPDATE upload_session SET state='ABORTED', closed_reason='DIGEST_MISMATCH' WHERE session_id=?", sessionId);
                    c.commit();
                    throw new FileError("DIGEST_MISMATCH", sha);
                }
                hook.accept("after-fsync");
                lockBlob(c, sha);
                Path target = store.blobPath(sha);
                if (Files.exists(target) && Store.sha256(target).equals(sha)) {
                    Files.delete(tmp);                       // 相同内容已存在：去重
                } else {
                    Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE);
                }
                Store.fsyncDir(store.blobs);
                hook.accept("after-rename");
                Db.update(c, "UPDATE upload_session SET state='COMPLETED', blob_sha256=? WHERE session_id=?", sha, sessionId);
                c.commit();
                return sha;
            } catch (SQLException | IOException | RuntimeException e) {
                if (!c.getAutoCommit()) c.rollback();
                Files.deleteIfExists(tmp);
                throw e;
            }
        }
    }

    /** 提交元数据：只接受 COMPLETED 且未过期的会话；同一会话重复提交返回同一 file_id。 */
    public String commitMetadata(String sessionId, String name, String contentType) throws SQLException {
        if (name == null || name.isEmpty() || name.length() > 255 || name.contains("/") || name.contains("\u0000"))
            throw new FileError("METADATA_INVALID", "name");
        try (Connection c = Db.connect()) {
            c.setAutoCommit(false);
            try {
                SessionRow s = lockSession(c, sessionId);
                String fileId = "file-" + sessionId.substring(3);
                if (s.state.equals("COMMITTED")) {
                    c.rollback();
                    return fileId;
                }
                if (!s.state.equals("COMPLETED")) throw new FileError("SESSION_NOT_COMPLETED", s.state);
                if (!clock.get().isBefore(s.expiresAt)) throw new FileError("SESSION_EXPIRED", sessionId);
                Db.update(c, """
                    INSERT INTO file_object(file_id, session_id, owner, name, content_type, blob_sha256, size, state)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'PROCESSING')""",
                    fileId, sessionId, s.owner, name, contentType, s.blobSha, s.declaredSize);
                if (failCommitAfterInsert) throw new IllegalStateException("injected failure before commit");
                Db.update(c, "INSERT INTO process_job(file_id, state) VALUES (?, 'READY')", fileId);
                Db.update(c, "UPDATE upload_session SET state='COMMITTED' WHERE session_id=?", sessionId);
                c.commit();
                return fileId;
            } catch (SQLException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        }
    }

    public void abort(String sessionId) throws SQLException {
        try (Connection c = Db.connect()) {
            c.setAutoCommit(false);
            SessionRow s = lockSession(c, sessionId);
            if (!List.of("INIT", "UPLOADING", "COMPLETED").contains(s.state)) {
                c.rollback();
                throw new FileError("SESSION_CLOSED", s.state);
            }
            Db.update(c, "UPDATE upload_session SET state='ABORTED', closed_reason='CLIENT_ABORT' WHERE session_id=?", sessionId);
            c.commit();
        }
    }

    /** 读取接口：只返回 PUBLISHED 文件，并在返回前复核内容摘要。 */
    public byte[] read(String fileId) throws SQLException, IOException {
        String state, sha;
        try (Connection c = Db.connect();
             PreparedStatement ps = c.prepareStatement("SELECT state, blob_sha256 FROM file_object WHERE file_id=?")) {
            ps.setString(1, fileId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) throw new FileError("NOT_FOUND", fileId);
                state = rs.getString(1);
                sha = rs.getString(2);
            }
        }
        if (!state.equals("PUBLISHED")) throw new FileError("NOT_READY", state);
        byte[] data = Files.readAllBytes(store.blobPath(sha));
        if (!Store.sha256(data).equals(sha)) throw new FileError("BLOB_CORRUPT", sha);
        return data;
    }

    /** 负向对照：按内容地址直接取文件，不看元数据状态。 */
    public byte[] readNaive(String fileId) throws SQLException, IOException {
        try (Connection c = Db.connect()) {
            String sha = Db.queryString(c, "SELECT blob_sha256 FROM file_object WHERE file_id=?", fileId);
            if (sha == null) throw new FileError("NOT_FOUND", fileId);
            return Files.readAllBytes(store.blobPath(sha));
        }
    }

    /** blob 级咨询锁：complete 的改名与回收的“复核引用 + 删除”在同一把锁下串行。 */
    static void lockBlob(Connection c, String sha) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT pg_advisory_xact_lock(hashtextextended(?, 35))")) {
            ps.setString(1, sha);
            ps.execute();
        }
    }

    record SessionRow(String owner, String state, int partCount, long declaredSize, String declaredSha,
                      String blobSha, Instant expiresAt) {}

    private static SessionRow lockSession(Connection c, String id) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("""
                SELECT owner, state, part_count, declared_size, declared_sha256, blob_sha256, expires_at
                FROM upload_session WHERE session_id=? FOR UPDATE""")) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) throw new FileError("NO_SUCH_SESSION", id);
                return new SessionRow(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getLong(4),
                    rs.getString(5), rs.getString(6), rs.getTimestamp(7).toInstant());
            }
        }
    }
}
