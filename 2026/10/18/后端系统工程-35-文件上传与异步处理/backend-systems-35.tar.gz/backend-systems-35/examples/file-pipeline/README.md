# file-pipeline（第 35 篇）

分块上传、整体校验、内容寻址存储、元数据提交、异步处理与发布、孤儿回收的最小实现。

- 运行：`bash run.sh`（集群 b3-35，端口 55435；证据写入 `../../evidence/35/`）
- 代码：`src/lab/files/`
  - `UploadService`：init / putPart / complete / commitMetadata / abort / read
  - `Worker`：claim（租约 + 尝试号）/ transform（确定性 gzip）/ publish（状态 + 令牌检查）
  - `Reclaimer`：过期会话、暂存分块、无引用 blob、过旧临时文件
  - `Store`：本地目录替身与 fsync 辅助
  - `Child`：多进程实验的子进程入口
  - `Main`：全部用例
- 限制见 `../../evidence/35/LIMITS.md`。本地目录不是对象存储，实验不证明对象存储持久性。
