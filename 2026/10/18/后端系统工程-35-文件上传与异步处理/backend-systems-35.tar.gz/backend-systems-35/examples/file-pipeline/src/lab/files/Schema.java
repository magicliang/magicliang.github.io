package lab.files;

import java.sql.Connection;
import java.sql.SQLException;
import lab.common.Db;

public final class Schema {
    private Schema() {}

    public static final String DDL = """
        CREATE SEQUENCE session_seq;
        CREATE TABLE upload_session (
            session_id      text        PRIMARY KEY,
            owner           text        NOT NULL,
            state           text        NOT NULL CHECK (state IN
                                ('INIT','UPLOADING','COMPLETED','COMMITTED','ABORTED','EXPIRED')),
            part_count      int         NOT NULL CHECK (part_count BETWEEN 1 AND 10000),
            declared_size   bigint      NOT NULL CHECK (declared_size >= 0),
            declared_sha256 text        NOT NULL CHECK (declared_sha256 ~ '^[0-9a-f]{64}$'),
            blob_sha256     text,
            expires_at      timestamptz NOT NULL,
            closed_reason   text,
            CHECK (state NOT IN ('COMPLETED','COMMITTED') OR blob_sha256 IS NOT NULL)
        );
        CREATE TABLE upload_part (
            session_id text NOT NULL REFERENCES upload_session(session_id),
            part_no    int  NOT NULL CHECK (part_no >= 1),
            size       int  NOT NULL CHECK (size >= 0),
            sha256     text NOT NULL,
            PRIMARY KEY (session_id, part_no)
        );
        CREATE TABLE file_object (
            file_id           text PRIMARY KEY,
            session_id        text NOT NULL UNIQUE REFERENCES upload_session(session_id),
            owner             text NOT NULL,
            name              text NOT NULL,
            content_type      text NOT NULL,
            blob_sha256       text NOT NULL,
            size              bigint NOT NULL,
            state             text NOT NULL CHECK (state IN ('PROCESSING','PUBLISHED')),
            derived_path      text,
            derived_sha256    text,
            published_attempt int,
            CHECK (state <> 'PUBLISHED' OR (derived_path IS NOT NULL AND published_attempt IS NOT NULL))
        );
        CREATE TABLE process_job (
            file_id     text PRIMARY KEY REFERENCES file_object(file_id),
            state       text NOT NULL CHECK (state IN ('READY','RUNNING','DONE')),
            attempt     int  NOT NULL DEFAULT 0,
            lease_owner text,
            lease_until timestamptz
        );
        CREATE TABLE publish_event (
            event_id bigserial PRIMARY KEY,
            file_id  text NOT NULL UNIQUE,
            attempt  int  NOT NULL,
            worker   text NOT NULL
        );
        -- 负向对照专用：没有唯一约束，用来观察不带检查的发布会写出几条事件
        CREATE TABLE publish_event_naive (
            event_id bigserial PRIMARY KEY,
            file_id  text NOT NULL,
            attempt  int  NOT NULL,
            worker   text NOT NULL
        );
        """;

    public static void create(Connection c) throws SQLException {
        Db.exec(c, DDL);
    }
}
