package lab.files;

/** 业务拒绝。code 是稳定的错误码，测试按 code 断言。 */
public final class FileError extends RuntimeException {
    public final String code;

    public FileError(String code, String detail) {
        super(code + ": " + detail);
        this.code = code;
    }
}
