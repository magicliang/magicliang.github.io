#!/usr/bin/env bash
# 第 35 篇：文件上传与异步处理。一条命令完成建集群、建库、编译、运行全部用例与停集群。
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
B3=$(cd "$HERE/../.." && pwd)
COMMON=$B3/examples/common
EV=$B3/evidence/35
NAME=b3-35 PORT=55435
mkdir -p "$EV"
export LAB_PGPORT=$PORT LAB_DB=files35 FP_ROOT=/tmp/b3-35-files
trap '"$COMMON/pg.sh" stop $NAME' EXIT
# 本机 /dev/shm 只有 64M 且已被占满，initdb 的 posix 动态共享内存会失败；
# 因此在 pg.sh 之前自行 initdb，并把 dynamic_shared_memory_type 设为 mmap（数据目录仍在 pg.sh 约定的位置）。
PGROOT=${BATCH3_PG_ROOT:-/tmp/batch3-pg}
if [ ! -f "$PGROOT/$NAME/PG_VERSION" ]; then
  mkdir -p "$PGROOT"
  /usr/lib/postgresql/16/bin/initdb -D "$PGROOT/$NAME" -U postgres -A trust -E UTF8 --locale=C.UTF-8 \
    -c dynamic_shared_memory_type=mmap >/dev/null
fi
"$COMMON/pg.sh" start $NAME $PORT
{
  echo "date: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "uname: $(uname -a)"
  java -version 2>&1
  /usr/lib/postgresql/16/bin/postgres --version
  echo "pgjdbc: postgresql-42.7.7.jar"
  echo "dynamic_shared_memory_type=mmap (/dev/shm 已满的规避措施)"
  echo "file store: $FP_ROOT on $(df -T /tmp | awk 'NR==2{print $2" ("$1")"}')"
} > "$EV/env.txt"
cat > "$EV/commands.txt" <<CMD
bash examples/file-pipeline/run.sh
  initdb -c dynamic_shared_memory_type=mmap（仅首次）; ../common/pg.sh start $NAME $PORT
  LAB_PGPORT=$PORT LAB_DB=files35 FP_ROOT=/tmp/b3-35-files ../common/lab.sh examples/file-pipeline lab.files.Main > evidence/35/output.txt
  （P 系列由 Main 启动独立 JVM：java -cp <同一 classpath> lab.files.Child ...，信号经 /bin/kill -9 / -STOP / -CONT 发送）
  ../common/pg.sh stop $NAME
CMD
set +e
"$COMMON/lab.sh" "$HERE" lab.files.Main > "$EV/output.txt" 2>&1
rc=$?
set -e
echo "exit_code: $rc" >> "$EV/commands.txt"
exit $rc
