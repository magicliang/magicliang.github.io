package lab.files;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;
import java.util.zip.GZIPOutputStream;
import lab.common.Db;

/** 处理任务：领取（租约 + 尝试号）→ 确定性变换（gzip）→ 带状态与尝试令牌检查的发布。 */
public final class Worker {
    private final Store store;
    public final String name;

    public Worker(Store store, String name) {
        this.store = store;
        this.name = name;
    }

    public record Claim(String fileId, int attempt, String blobSha) {}

    public record Artifact(Path path, String sha256) {}

    /** 领取一个 READY 或租约已过期的 RUNNING 任务；尝试号加一作为本次执行的令牌。 */
    public Claim claim(int leaseSeconds) throws SQLException {
        try (Connection c = Db.connect();
             PreparedStatement ps = c.prepareStatement("""
                 UPDATE process_job j SET state='RUNNING', attempt=attempt+1, lease_owner=?,
                        lease_until=now() + make_interval(secs => ?)
                 WHERE file_id = (SELECT file_id FROM process_job
                                  WHERE state='READY' OR (state='RUNNING' AND lease_until < now())
                                  ORDER BY file_id LIMIT 1 FOR UPDATE SKIP LOCKED)
                 RETURNING j.file_id, j.attempt,
                           (SELECT blob_sha256 FROM file_object f WHERE f.file_id=j.file_id)""")) {
            ps.setString(1, name);
            ps.setInt(2, leaseSeconds);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? new Claim(rs.getString(1), rs.getInt(2), rs.getString(3)) : null;
            }
        }
    }

    /** 确定性变换：同一输入产生同一路径、同一字节。先写临时文件并 fsync，再原子改名。 */
    public Artifact transform(Claim cl) throws IOException {
        byte[] src = Files.readAllBytes(store.blobPath(cl.blobSha()));
        if (!Store.sha256(src).equals(cl.blobSha())) throw new FileError("BLOB_CORRUPT", cl.blobSha());
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (GZIPOutputStream gz = new GZIPOutputStream(bos)) {
            gz.write(src);
        }
        byte[] out = bos.toByteArray();
        String sha = Store.sha256(out);
        Path target = store.derivedPath(cl.blobSha());
        if (!(Files.exists(target) && Store.sha256(target).equals(sha))) {
            Path tmp = store.tmp.resolve("derived-" + UUID.randomUUID());
            Store.writeDurable(tmp, out);
            Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE);
            Store.fsyncDir(store.derived);
        }
        return new Artifact(target, sha);
    }

    /**
     * 发布：任务行必须仍是 RUNNING、尝试号与领取时一致、领取者是自己；文件必须仍是 PROCESSING。
     * 两个条件在同一事务里检查，任一不满足即回滚并返回 false。
     */
    public boolean publish(Claim cl, Artifact a) throws SQLException {
        try (Connection c = Db.connect()) {
            c.setAutoCommit(false);
            try {
                int job = Db.update(c, """
                    UPDATE process_job SET state='DONE', lease_until=NULL
                    WHERE file_id=? AND state='RUNNING' AND attempt=? AND lease_owner=?""",
                    cl.fileId(), cl.attempt(), name);
                int file = job == 0 ? 0 : Db.update(c, """
                    UPDATE file_object SET state='PUBLISHED', derived_path=?, derived_sha256=?, published_attempt=?
                    WHERE file_id=? AND state='PROCESSING'""",
                    store.root.relativize(a.path()).toString(), a.sha256(), cl.attempt(), cl.fileId());
                if (file != 1) {
                    c.rollback();
                    return false;
                }
                Db.update(c, "INSERT INTO publish_event(file_id, attempt, worker) VALUES (?, ?, ?)",
                    cl.fileId(), cl.attempt(), name);
                c.commit();
                return true;
            } catch (SQLException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        }
    }

    /** 负向对照：只按 file_id 置 PUBLISHED 并写事件，不检查状态和尝试号。 */
    public boolean publishNaive(Claim cl, Artifact a) throws SQLException {
        try (Connection c = Db.connect()) {
            Db.update(c, """
                UPDATE file_object SET state='PUBLISHED', derived_path=?, derived_sha256=?, published_attempt=?
                WHERE file_id=?""", store.root.relativize(a.path()).toString(), a.sha256(), cl.attempt(), cl.fileId());
            Db.update(c, "INSERT INTO publish_event_naive(file_id, attempt, worker) VALUES (?, ?, ?)",
                cl.fileId(), cl.attempt(), name);
            return true;
        }
    }
}
