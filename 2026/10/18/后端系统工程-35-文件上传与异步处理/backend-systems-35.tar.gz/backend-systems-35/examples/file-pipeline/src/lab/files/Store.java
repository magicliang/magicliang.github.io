package lab.files;

import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

/**
 * 本地文件系统上的对象存储替身。目录布局：
 * staging/<session>/part-NNNNN  已被数据库登记的分块
 * tmp/                          组装与写入中的临时文件
 * blobs/sha256/<hex>            按内容寻址的完整文件
 * derived/<hex>.gz              确定性派生文件
 */
public final class Store {
    public final Path root, staging, tmp, blobs, derived;

    public Store(Path root) throws IOException {
        this.root = root;
        this.staging = Files.createDirectories(root.resolve("staging"));
        this.tmp = Files.createDirectories(root.resolve("tmp"));
        this.blobs = Files.createDirectories(root.resolve("blobs").resolve("sha256"));
        this.derived = Files.createDirectories(root.resolve("derived"));
    }

    public Path sessionDir(String sessionId) { return staging.resolve(sessionId); }
    public Path partPath(String sessionId, int partNo) { return sessionDir(sessionId).resolve(String.format("part-%05d", partNo)); }
    public Path blobPath(String sha) { return blobs.resolve(sha); }
    public Path derivedPath(String blobSha) { return derived.resolve(blobSha + ".gz"); }

    /** 写入并 fsync 文件内容（FileChannel.force(true)，在 Linux 上对应 fsync(2)）。 */
    public static void writeDurable(Path p, byte[] data) throws IOException {
        try (FileChannel ch = FileChannel.open(p, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE)) {
            java.nio.ByteBuffer buf = java.nio.ByteBuffer.wrap(data);
            while (buf.hasRemaining()) ch.write(buf);
            ch.force(true);
        }
    }

    /** fsync 目录，使其中新建或改名的目录项落盘。fsync(2) 手册指出对文件 fsync 不保证目录项落盘。 */
    public static void fsyncDir(Path dir) throws IOException {
        try (FileChannel ch = FileChannel.open(dir, StandardOpenOption.READ)) {
            ch.force(true);
        }
    }

    public static MessageDigest sha256() {
        try {
            return MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    public static String hex(byte[] d) { return HexFormat.of().formatHex(d); }

    public static String sha256(byte[] data) { return hex(sha256().digest(data)); }

    public static String sha256(Path p) throws IOException {
        MessageDigest md = sha256();
        try (InputStream in = Files.newInputStream(p)) {
            byte[] buf = new byte[8192];
            for (int n; (n = in.read(buf)) > 0; ) md.update(buf, 0, n);
        }
        return hex(md.digest());
    }
}
