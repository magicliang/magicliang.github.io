package lab.files;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Stream;
import java.util.zip.GZIPInputStream;
import lab.common.Check;
import lab.common.Db;

/** 第 35 篇全部用例。真实 PostgreSQL 16 + 本地文件系统；P 系列用独立 JVM 进程与信号。 */
public final class Main {
    static final Duration TTL = Duration.ofHours(1);
    static final Duration GRACE = Duration.ofMinutes(10);
    static final int PART = 65_536;
    static Path root;
    static Store store;
    static final AtomicLong offsetMs = new AtomicLong();
    static UploadService svc;
    static Reclaimer reclaimer;

    static Instant now() { return Instant.now().plusMillis(offsetMs.get()); }

    public static void main(String[] args) throws Exception {
        String db = System.getenv().getOrDefault("LAB_DB", "files35");
        root = Path.of(System.getenv().getOrDefault("FP_ROOT", "/tmp/b3-35-files"));
        Db.recreate(db);
        try (Connection c = Db.connect()) {
            Schema.create(c);
        }
        System.out.println("db=" + db + " store=" + root + " ttl=" + TTL + " grace=" + GRACE + " part=" + PART);

        u1NormalPath();
        u2PartBoundaries();
        u3DigestMismatch();
        u4ConcurrentDuplicateParts();
        u5Dedup();
        u6Abort();
        m1MetadataRejectedThenRetry();
        m2MetadataFailureReclaimed();
        nc3ReclaimWithoutReferences();
        p1aKillAfterRenameThenReclaim();
        p1bKillAfterRenameThenRetry();
        p1cKillBeforeRename();
        p1dAbortedOrphanRespectsGrace();
        nc4NaiveAssembleIntoAddress();
        p2DuplicateWorkersSinglePublish();
        p2bConcurrentWorkersOneClaim();
        nc1NaivePublish();
        p3ReaderProcessDuringProcessing();
        nc2NaiveReader();

        System.exit(Check.finish());
    }

    // ---------- fixtures ----------

    static void reset() throws Exception {
        try (Connection c = Db.connect()) {
            Db.exec(c, "TRUNCATE publish_event, publish_event_naive, process_job, file_object, upload_part, upload_session RESTART IDENTITY");
            Db.exec(c, "ALTER SEQUENCE session_seq RESTART");
        }
        if (Files.exists(root)) Reclaimer.deleteTree(root);
        store = new Store(root);
        offsetMs.set(0);
        svc = new UploadService(store, Main::now, TTL);
        reclaimer = new Reclaimer(store, GRACE);
    }

    static byte[] data(long seed, int size) {
        byte[] b = new byte[size];
        new Random(seed).nextBytes(b);
        return b;
    }

    static List<byte[]> split(byte[] d) {
        List<byte[]> parts = new ArrayList<>();
        for (int off = 0; off < d.length; off += PART) parts.add(Arrays.copyOfRange(d, off, Math.min(d.length, off + PART)));
        return parts;
    }

    static String initAndUpload(byte[] d, boolean uploadAll) throws Exception {
        List<byte[]> parts = split(d);
        String id = svc.init("user-0042", parts.size(), d.length, Store.sha256(d)).sessionId();
        if (uploadAll) for (int i = 0; i < parts.size(); i++) svc.putPart(id, i + 1, parts.get(i), Store.sha256(parts.get(i)));
        return id;
    }

    static String committedFile(long seed) throws Exception {
        byte[] d = data(seed, 150_000);
        String id = initAndUpload(d, true);
        svc.complete(id);
        return svc.commitMetadata(id, "report-" + seed + ".bin", "application/octet-stream");
    }

    static String code(ThrowingRunnable r) {
        try {
            r.run();
            return "OK";
        } catch (FileError e) {
            return e.code;
        } catch (Exception e) {
            return e.getClass().getSimpleName();
        }
    }

    interface ThrowingRunnable { void run() throws Exception; }

    static String q(String sql, Object... a) throws SQLException {
        try (Connection c = Db.connect()) {
            return Db.queryString(c, sql, a);
        }
    }

    static long n(String sql, Object... a) throws SQLException {
        try (Connection c = Db.connect()) {
            return Db.queryLong(c, sql, a);
        }
    }

    static long count(Path dir) throws IOException {
        if (!Files.exists(dir)) return 0;
        try (Stream<Path> s = Files.list(dir)) {
            return s.count();
        }
    }

    static Instant afterExpiry() { return now().plus(TTL).plus(GRACE).plusSeconds(60); }

    // ---------- child processes ----------

    static final class Proc {
        final Process p;
        final BlockingQueue<String> lines = new LinkedBlockingQueue<>();
        final List<String> all = Collections.synchronizedList(new ArrayList<>());

        Proc(String... args) throws IOException {
            String java = ProcessHandle.current().info().command().orElse("java");
            List<String> cmd = new ArrayList<>(List.of(java, "-cp", System.getProperty("java.class.path"), "lab.files.Child"));
            cmd.addAll(List.of(args));
            p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
            Thread t = new Thread(() -> {
                try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                    for (String l; (l = r.readLine()) != null; ) {
                        all.add(l);
                        lines.add(l);
                    }
                } catch (IOException ignored) {
                }
            });
            t.setDaemon(true);
            t.start();
        }

        long pid() { return p.pid(); }

        String await(String prefix, int seconds) throws InterruptedException {
            long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(seconds);
            while (System.nanoTime() < deadline) {
                String l = lines.poll(200, TimeUnit.MILLISECONDS);
                if (l != null && l.startsWith(prefix)) return l;
            }
            return null;
        }

        int waitExit() throws InterruptedException {
            if (!p.waitFor(30, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                return -1;
            }
            return p.exitValue();
        }

        void send(String line) throws IOException {
            OutputStream o = p.getOutputStream();
            o.write((line + "\n").getBytes(StandardCharsets.UTF_8));
            o.flush();
        }
    }

    static void signal(String sig, long pid) throws Exception {
        int rc = new ProcessBuilder("kill", "-" + sig, Long.toString(pid)).inheritIO().start().waitFor();
        Check.note("kill -" + sig + " " + pid + " rc=" + rc);
    }

    static String procState(long pid) throws IOException {
        String stat = Files.readString(Path.of("/proc/" + pid + "/stat"));
        return stat.substring(stat.lastIndexOf(')') + 2, stat.lastIndexOf(')') + 3);
    }

    // ---------- U: upload path ----------

    static void u1NormalPath() throws Exception {
        reset();
        Check.begin("U1", "正常路径：乱序上传 3 块 → 完成 → 提交元数据 → 处理 → 发布 → 读取");
        byte[] d = data(35, 150_000);
        List<byte[]> parts = split(d);
        String sha = Store.sha256(d);
        String id = svc.init("user-0042", parts.size(), d.length, sha).sessionId();
        Check.equal("INIT", q("SELECT state FROM upload_session WHERE session_id=?", id), "新会话状态");
        for (int i : new int[]{3, 1, 2})
            Check.equal("STORED", svc.putPart(id, i, parts.get(i - 1), Store.sha256(parts.get(i - 1))), "上传分块 " + i);
        Check.equal("UPLOADING", q("SELECT state FROM upload_session WHERE session_id=?", id), "收到分块后状态");
        String blob = svc.complete(id);
        Check.equal(sha, blob, "整体摘要等于声明值");
        Check.that(Files.exists(store.blobPath(sha)), "blob 位于内容地址 blobs/sha256/" + sha.substring(0, 12) + "…");
        Check.equal(0L, count(store.tmp), "tmp 目录无残留");
        Check.equal("COMPLETED", q("SELECT state FROM upload_session WHERE session_id=?", id), "完成后会话状态");
        String fileId = svc.commitMetadata(id, "report-0042.csv", "text/csv");
        Check.equal("PROCESSING", q("SELECT state FROM file_object WHERE file_id=?", fileId), "提交后文件状态");
        Check.equal("COMMITTED", q("SELECT state FROM upload_session WHERE session_id=?", id), "提交后会话状态");
        Check.equal("NOT_READY", code(() -> svc.read(fileId)), "PROCESSING 时读取被拒绝");
        Worker w = new Worker(store, "worker-a");
        Worker.Claim cl = w.claim(30);
        Check.equal(1, cl.attempt(), "首次领取尝试号");
        Worker.Artifact art = w.transform(cl);
        Check.that(w.publish(cl, art), "发布成功");
        Check.equal("PUBLISHED", q("SELECT state FROM file_object WHERE file_id=?", fileId), "发布后文件状态");
        byte[] got = svc.read(fileId);
        Check.equal(sha, Store.sha256(got), "读取内容摘要");
        byte[] unz = new GZIPInputStream(new ByteArrayInputStream(Files.readAllBytes(art.path()))).readAllBytes();
        Check.that(Arrays.equals(d, unz), "派生文件解压后与原文件一致");
        Check.equal(1L, n("SELECT count(*) FROM publish_event WHERE file_id=?", fileId), "发布事件条数");
        Check.note("file=" + fileId + " blob=" + sha.substring(0, 16) + " derived=" + store.root.relativize(art.path()));
    }

    static void u2PartBoundaries() throws Exception {
        reset();
        Check.begin("U2", "分块边界：重复同内容、同序号异内容、摘要不符、越界、缺块完成、重复完成与提交");
        byte[] d = data(36, 150_000);
        List<byte[]> p = split(d);
        String id = svc.init("user-0042", p.size(), d.length, Store.sha256(d)).sessionId();
        Check.equal("STORED", svc.putPart(id, 1, p.get(0), Store.sha256(p.get(0))), "分块 1 首次上传");
        Check.equal("DUPLICATE", svc.putPart(id, 1, p.get(0), Store.sha256(p.get(0))), "分块 1 同内容重传");
        byte[] other = data(99, PART);
        Check.equal("PART_CONFLICT", code(() -> svc.putPart(id, 1, other, Store.sha256(other))), "分块 1 不同内容");
        Check.equal(Store.sha256(p.get(0)), Store.sha256(store.partPath(id, 1)), "冲突后暂存分块未被覆盖");
        Check.equal("CHECKSUM_MISMATCH", code(() -> svc.putPart(id, 2, p.get(1), Store.sha256(p.get(0)))), "分块 2 摘要与内容不符");
        Check.equal(0L, n("SELECT count(*) FROM upload_part WHERE session_id=? AND part_no=2", id), "摘要不符的分块未登记");
        Check.equal("PART_OUT_OF_RANGE", code(() -> svc.putPart(id, 4, p.get(0), Store.sha256(p.get(0)))), "分块序号 4 越界");
        Check.equal("PART_OUT_OF_RANGE", code(() -> svc.putPart(id, 0, p.get(0), Store.sha256(p.get(0)))), "分块序号 0 越界");
        svc.putPart(id, 3, p.get(2), Store.sha256(p.get(2)));
        Check.equal("MISSING_PARTS", code(() -> svc.complete(id)), "缺分块 2 时完成被拒绝");
        Check.equal("UPLOADING", q("SELECT state FROM upload_session WHERE session_id=?", id), "拒绝后仍可继续上传");
        Check.equal(0L, count(store.blobs) + count(store.tmp), "拒绝后无 blob、无临时文件");
        svc.putPart(id, 2, p.get(1), Store.sha256(p.get(1)));
        String s1 = svc.complete(id);
        String s2 = svc.complete(id);
        Check.equal(s1, s2, "重复调用 complete 返回同一摘要");
        Check.equal("SESSION_CLOSED", code(() -> svc.putPart(id, 2, p.get(1), Store.sha256(p.get(1)))), "完成后不再接受分块");
        String f1 = svc.commitMetadata(id, "a.bin", "application/octet-stream");
        String f2 = svc.commitMetadata(id, "a.bin", "application/octet-stream");
        Check.equal(f1, f2, "重复提交元数据返回同一 file_id");
        Check.equal(1L, n("SELECT count(*) FROM file_object WHERE session_id=?", id), "file_object 只有一行");
        Check.equal(1L, n("SELECT count(*) FROM process_job WHERE file_id=?", f1), "处理任务只有一行");
    }

    static void u3DigestMismatch() throws Exception {
        reset();
        Check.begin("U3", "整体摘要与声明不符：完成被拒绝，会话中止，不产生 blob");
        byte[] d = data(37, 150_000);
        List<byte[]> p = split(d);
        String wrong = Store.sha256("not-the-content".getBytes(StandardCharsets.UTF_8));
        String id = svc.init("user-0042", p.size(), d.length, wrong).sessionId();
        for (int i = 0; i < p.size(); i++) svc.putPart(id, i + 1, p.get(i), Store.sha256(p.get(i)));
        Check.equal("DIGEST_MISMATCH", code(() -> svc.complete(id)), "complete 返回摘要不符");
        Check.equal("ABORTED", q("SELECT state FROM upload_session WHERE session_id=?", id), "会话被中止");
        Check.equal("DIGEST_MISMATCH", q("SELECT closed_reason FROM upload_session WHERE session_id=?", id), "关闭原因");
        Check.equal(0L, count(store.blobs) + count(store.tmp), "无 blob、无临时文件");
    }

    static void u4ConcurrentDuplicateParts() throws Exception {
        reset();
        Check.begin("U4", "8 个线程并发上传同一序号：同内容只登记一次；两种内容只有一种胜出");
        byte[] d = data(38, 150_000);
        List<byte[]> p = split(d);
        String id = svc.init("user-0042", p.size(), d.length, Store.sha256(d)).sessionId();
        List<String> r1 = race(8, i -> svc.putPart(id, 1, p.get(0), Store.sha256(p.get(0))));
        Check.equal(1L, r1.stream().filter("STORED"::equals).count(), "同内容：STORED 恰好 1 次");
        Check.equal(7L, r1.stream().filter("DUPLICATE"::equals).count(), "同内容：其余 7 次 DUPLICATE");
        Check.equal(1L, n("SELECT count(*) FROM upload_part WHERE session_id=? AND part_no=1", id), "同内容：登记行数");
        byte[] a = data(201, PART), b = data(202, PART);
        List<String> r2 = race(8, i -> {
            byte[] x = i % 2 == 0 ? a : b;
            return svc.putPart(id, 2, x, Store.sha256(x));
        });
        String winner = q("SELECT sha256 FROM upload_part WHERE session_id=? AND part_no=2", id);
        long stored = r2.stream().filter("STORED"::equals).count();
        long dup = r2.stream().filter("DUPLICATE"::equals).count();
        long conflict = r2.stream().filter("PART_CONFLICT"::equals).count();
        Check.note("两种内容并发结果 " + r2);
        Check.equal(1L, stored, "异内容：STORED 恰好 1 次");
        Check.equal(3L, dup, "异内容：与胜者相同的另外 3 次为 DUPLICATE");
        Check.equal(4L, conflict, "异内容：另一种内容的 4 次为 PART_CONFLICT");
        Check.equal(winner, Store.sha256(store.partPath(id, 2)), "暂存文件内容与登记摘要一致");
        Check.equal(0L, count(store.tmp), "无临时文件残留");
    }

    interface PutFn { String put(int i) throws Exception; }

    static List<String> race(int threads, PutFn fn) throws Exception {
        CountDownLatch go = new CountDownLatch(1);
        List<String> out = Collections.synchronizedList(new ArrayList<>());
        List<Thread> ts = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            int k = i;
            Thread t = new Thread(() -> {
                try {
                    go.await();
                    out.add(k + ":" + fn.put(k));
                } catch (FileError e) {
                    out.add(k + ":" + e.code);
                } catch (Exception e) {
                    out.add(k + ":" + e);
                }
            });
            ts.add(t);
            t.start();
        }
        go.countDown();
        for (Thread t : ts) t.join();
        List<String> sorted = new ArrayList<>(out);
        Collections.sort(sorted);
        return sorted.stream().map(s -> s.substring(s.indexOf(':') + 1)).toList();
    }

    static void u5Dedup() throws Exception {
        reset();
        Check.begin("U5", "两个会话上传相同内容：共用一个 blob，回收不删除被引用的 blob");
        byte[] d = data(39, 150_000);
        String a = initAndUpload(d, true), b = initAndUpload(d, true);
        Check.equal(svc.complete(a), svc.complete(b), "两次完成得到同一摘要");
        Check.equal(1L, count(store.blobs), "blob 目录只有一个文件");
        svc.commitMetadata(a, "a.bin", "application/octet-stream");
        svc.commitMetadata(b, "b.bin", "application/octet-stream");
        Reclaimer.Report r = reclaimer.run(afterExpiry());
        Check.note("reclaim " + r);
        Check.equal(0, r.blobsRemoved(), "被两条 file_object 引用的 blob 未删除");
        Check.equal(2, r.stagingRemoved(), "两个已提交会话的暂存分块被清理");
    }

    static void u6Abort() throws Exception {
        reset();
        Check.begin("U6", "中止：之后的分块被拒绝，暂存分块由回收清理");
        byte[] d = data(40, 150_000);
        List<byte[]> p = split(d);
        String id = svc.init("user-0042", p.size(), d.length, Store.sha256(d)).sessionId();
        svc.putPart(id, 1, p.get(0), Store.sha256(p.get(0)));
        svc.abort(id);
        Check.equal("SESSION_CLOSED", code(() -> svc.putPart(id, 2, p.get(1), Store.sha256(p.get(1)))), "中止后上传被拒绝");
        Check.equal("SESSION_CLOSED", code(() -> svc.complete(id)), "中止后完成被拒绝");
        Check.equal(0L, count(store.tmp), "被拒绝的分块没有留下临时文件");
        Reclaimer.Report r = reclaimer.run(now());
        Check.note("reclaim " + r);
        Check.equal(1, r.stagingRemoved(), "暂存目录被删除");
        Check.that(!Files.exists(store.sessionDir(id)), "staging/" + id + " 不存在");
    }

    // ---------- M: metadata commit failure ----------

    static void m1MetadataRejectedThenRetry() throws Exception {
        reset();
        Check.begin("M1", "元数据被拒绝：会话保持 COMPLETED，blob 受保护，重试提交成功");
        byte[] d = data(41, 150_000);
        String id = initAndUpload(d, true);
        String sha = svc.complete(id);
        Check.equal("METADATA_INVALID", code(() -> svc.commitMetadata(id, "../etc/passwd", "text/plain")), "非法文件名被拒绝");
        Check.equal("COMPLETED", q("SELECT state FROM upload_session WHERE session_id=?", id), "会话仍为 COMPLETED");
        Reclaimer.Report r = reclaimer.run(now().plus(GRACE).plusSeconds(60));
        Check.note("reclaim(宽限期后、TTL 内) " + r);
        Check.that(Files.exists(store.blobPath(sha)), "COMPLETED 会话引用的 blob 未被删除");
        String f = svc.commitMetadata(id, "report-0041.csv", "text/csv");
        Check.equal("PROCESSING", q("SELECT state FROM file_object WHERE file_id=?", f), "重试提交成功");
    }

    static void m2MetadataFailureReclaimed() throws Exception {
        reset();
        Check.begin("M2", "元数据事务在提交前失败且客户端不再重试：TTL 后会话过期，blob 被回收");
        byte[] d = data(42, 150_000);
        String id = initAndUpload(d, true);
        String sha = svc.complete(id);
        svc.failCommitAfterInsert = true;
        Check.equal("IllegalStateException", code(() -> svc.commitMetadata(id, "x.bin", "application/octet-stream")), "注入故障");
        svc.failCommitAfterInsert = false;
        Check.equal(0L, n("SELECT count(*) FROM file_object WHERE session_id=?", id), "file_object 已回滚");
        Check.equal("COMPLETED", q("SELECT state FROM upload_session WHERE session_id=?", id), "会话仍为 COMPLETED");
        Reclaimer.Report r0 = reclaimer.run(now());
        Check.note("reclaim(TTL 内) " + r0);
        Check.equal(0, r0.blobsRemoved(), "TTL 内不删除");
        Reclaimer.Report r1 = reclaimer.run(afterExpiry());
        Check.note("reclaim(TTL + 宽限期后) " + r1);
        Check.equal(1, r1.expired(), "会话被标记过期");
        Check.equal("EXPIRED", q("SELECT state FROM upload_session WHERE session_id=?", id), "会话状态");
        Check.equal(1, r1.blobsRemoved(), "孤儿 blob 被删除");
        Check.that(!Files.exists(store.blobPath(sha)), "blob 文件不存在");
        Check.that(!Files.exists(store.sessionDir(id)), "暂存分块已删除");
        Check.equal("SESSION_NOT_COMPLETED", code(() -> svc.commitMetadata(id, "x.bin", "application/octet-stream")), "过期后不能再提交");
    }

    static void nc3ReclaimWithoutReferences() throws Exception {
        reset();
        Check.begin("NC3", "负向对照：回收只看宽限期、不查引用");
        String fileId = committedFile(43);
        byte[] d = data(44, 150_000);
        String pending = initAndUpload(d, true);
        String pendingSha = svc.complete(pending);
        Instant t = now().plus(GRACE).plusSeconds(60);   // 宽限期已过，但 TTL 未到
        Reclaimer.Report safe = reclaimer.run(t, true);
        Check.equal(0, safe.blobsRemoved(), "对照组（查引用）：0 个 blob 被删");
        Reclaimer.Report bad = reclaimer.run(t, false);
        Check.note("reclaim(不查引用) " + bad);
        String procSha = q("SELECT blob_sha256 FROM file_object WHERE file_id=?", fileId);
        Check.exposes(!Files.exists(store.blobPath(procSha)), "PROCESSING 文件的 blob 被删除");
        Check.exposes(!Files.exists(store.blobPath(pendingSha)), "TTL 内 COMPLETED 会话的 blob 被删除");
        String f2 = svc.commitMetadata(pending, "late.bin", "application/octet-stream");
        Worker w = new Worker(store, "worker-a");
        Worker.Claim cl = w.claim(30);
        Check.exposes(code(() -> w.transform(cl)).equals("NoSuchFileException"), "元数据提交成功但处理任务找不到 blob（file " + f2 + "）");
    }

    // ---------- P1: crash between assembly and commit ----------

    static String crashComplete(String id, String point) throws Exception {
        Proc ch = new Proc("complete-crash", root.toString(), id, point);
        String at = ch.await("AT " + point, 30);
        Check.that(at != null, "子进程到达注入点：" + at);
        signal("9", ch.pid());
        int rc = ch.waitExit();
        Check.equal(137, rc, "子进程被 SIGKILL 终止（退出码 128+9）");
        return at;
    }

    static void p1aKillAfterRenameThenReclaim() throws Exception {
        reset();
        Check.begin("P1a", "多进程：改名进 blob 目录之后、提交之前 kill -9，再执行回收");
        byte[] d = data(45, 150_000);
        String sha = Store.sha256(d);
        String id = initAndUpload(d, true);
        crashComplete(id, "after-rename");
        Check.that(Files.exists(store.blobPath(sha)), "blob 已在内容地址");
        Check.equal(sha, Store.sha256(store.blobPath(sha)), "blob 内容完整");
        Check.equal("UPLOADING", q("SELECT state FROM upload_session WHERE session_id=?", id), "数据库事务随连接断开回滚，会话仍为 UPLOADING");
        Check.equal(0L, n("SELECT count(*) FROM file_object"), "无 file_object");
        Reclaimer.Report r0 = reclaimer.run(now().plus(GRACE).plusSeconds(60));
        Check.note("reclaim(宽限期后、TTL 内) " + r0);
        Check.equal(0, r0.blobsRemoved(), "未结束会话声明了该摘要，blob 受保护");
        Reclaimer.Report r1 = reclaimer.run(afterExpiry());
        Check.note("reclaim(TTL + 宽限期后) " + r1);
        Check.equal("EXPIRED", q("SELECT state FROM upload_session WHERE session_id=?", id), "会话过期");
        Check.equal(1, r1.blobsRemoved(), "孤儿 blob 被删除");
        Check.that(!Files.exists(store.sessionDir(id)), "暂存分块已删除");
        Check.equal(0L, count(store.blobs) + count(store.tmp), "blob 与 tmp 目录为空");
    }

    static void p1bKillAfterRenameThenRetry() throws Exception {
        reset();
        Check.begin("P1b", "多进程：同一崩溃点后客户端重试 complete，走去重分支完成");
        byte[] d = data(46, 150_000);
        String sha = Store.sha256(d);
        String id = initAndUpload(d, true);
        crashComplete(id, "after-rename");
        Check.equal(sha, svc.complete(id), "重试 complete 成功");
        Check.equal("COMPLETED", q("SELECT state FROM upload_session WHERE session_id=?", id), "会话 COMPLETED");
        Check.equal(1L, count(store.blobs), "blob 仍只有一个");
        Check.equal(0L, count(store.tmp), "重试删除了自己的临时文件");
        String f = svc.commitMetadata(id, "retry.bin", "application/octet-stream");
        Reclaimer.Report r = reclaimer.run(afterExpiry());
        Check.note("reclaim " + r);
        Check.equal(0, r.blobsRemoved(), "已提交文件的 blob 保留");
        Check.equal("PROCESSING", q("SELECT state FROM file_object WHERE file_id=?", f), "文件进入处理");
    }

    static void p1cKillBeforeRename() throws Exception {
        reset();
        Check.begin("P1c", "多进程：临时文件 fsync 之后、改名之前 kill -9；临时文件在宽限期后回收");
        byte[] d = data(47, 150_000);
        String id = initAndUpload(d, true);
        crashComplete(id, "after-fsync");
        Check.equal(0L, count(store.blobs), "内容地址上没有任何文件");
        Check.equal(1L, count(store.tmp), "留下一个组装中的临时文件");
        Reclaimer.Report r0 = reclaimer.run(now());
        Check.equal(0, r0.tmpRemoved(), "宽限期内不删临时文件");
        Reclaimer.Report r1 = reclaimer.run(now().plus(GRACE).plusSeconds(60));
        Check.note("reclaim(宽限期后) " + r1);
        Check.equal(1, r1.tmpRemoved(), "临时文件被删除");
        Check.equal("UPLOADING", q("SELECT state FROM upload_session WHERE session_id=?", id), "会话在 TTL 内仍可重试");
        Check.equal(Store.sha256(d), svc.complete(id), "重试 complete 成功");
    }

    static void p1dAbortedOrphanRespectsGrace() throws Exception {
        reset();
        Check.begin("P1d", "多进程：崩溃后客户端中止会话；无引用的 blob 在宽限期内保留，期满删除");
        byte[] d = data(48, 150_000);
        String sha = Store.sha256(d);
        String id = initAndUpload(d, true);
        crashComplete(id, "after-rename");
        svc.abort(id);
        Reclaimer.Report r0 = reclaimer.run(now());
        Check.note("reclaim(立即) " + r0);
        Check.equal(0, r0.blobsRemoved(), "宽限期内无引用 blob 仍保留");
        Reclaimer.Report r1 = reclaimer.run(now().plus(GRACE).plusSeconds(60));
        Check.note("reclaim(宽限期后) " + r1);
        Check.equal(1, r1.blobsRemoved(), "期满后删除");
        Check.that(!Files.exists(store.blobPath(sha)), "blob 不存在");
    }

    static void nc4NaiveAssembleIntoAddress() throws Exception {
        reset();
        Check.begin("NC4", "负向对照（多进程）：直接写到内容地址，写到一半 kill -9");
        byte[] d = data(49, 150_000);
        String sha = Store.sha256(d);
        String id = initAndUpload(d, true);
        Proc ch = new Proc("naive-assemble", root.toString(), id);
        Check.that(ch.await("AT partial-write", 30) != null, "子进程写完第一块");
        signal("9", ch.pid());
        Check.equal(137, ch.waitExit(), "子进程被 SIGKILL 终止");
        Path p = store.blobPath(sha);
        long size = Files.size(p);
        Check.note("内容地址文件大小 " + size + "，声明大小 " + d.length);
        Check.exposes(Files.exists(p) && !Store.sha256(p).equals(sha), "内容地址上的文件与地址摘要不符");
        Check.equal(sha, svc.complete(id), "正确实现的 complete 复核摘要后用完整文件替换");
        Check.equal(sha, Store.sha256(p), "替换后内容与地址一致");
    }

    // ---------- P2: duplicate workers ----------

    static void p2DuplicateWorkersSinglePublish() throws Exception {
        reset();
        Check.begin("P2", "多进程：worker-a 领取后被 SIGSTOP，租约过期 worker-b 重复执行；只有一次发布");
        String fileId = committedFile(50);
        Proc a = new Proc("worker", root.toString(), "worker-a", "2", "true");
        String artA = a.await("ARTIFACT", 30);
        Check.that(a.await("PAUSE", 30) != null, "worker-a 停在发布之前：" + artA);
        signal("STOP", a.pid());
        Check.equal("T", procState(a.pid()), "/proc 显示 worker-a 处于停止状态");
        Thread.sleep(2_500);
        Check.that(n("SELECT count(*) FROM process_job WHERE lease_until < now()") == 1, "worker-a 的租约已过期");
        Proc b = new Proc("worker", root.toString(), "worker-b", "30", "false");
        Check.equal(0, b.waitExit(), "worker-b 正常退出");
        Check.note("worker-b 输出 " + b.all);
        Check.that(b.all.stream().anyMatch(l -> l.startsWith("PUBLISHED worker=worker-b attempt=2")), "worker-b 以尝试号 2 发布");
        signal("CONT", a.pid());
        a.send("go");
        String resA = a.await("", 30);
        Check.equal(0, a.waitExit(), "worker-a 正常退出");
        Check.equal("REJECTED worker=worker-a attempt=1", resA, "worker-a 的迟到发布被拒绝");
        Check.equal(1L, n("SELECT count(*) FROM publish_event WHERE file_id=?", fileId), "发布事件恰好 1 条");
        Check.equal("worker-b", q("SELECT worker FROM publish_event WHERE file_id=?", fileId), "事件来自 worker-b");
        Check.equal(2L, n("SELECT published_attempt FROM file_object WHERE file_id=?", fileId), "published_attempt");
        Check.equal("DONE", q("SELECT state FROM process_job WHERE file_id=?", fileId), "任务状态");
        String shaA = artA.substring(artA.indexOf("sha=") + 4);
        String artB = b.all.stream().filter(l -> l.startsWith("ARTIFACT")).findFirst().orElse("");
        String shaB = artB.substring(artB.indexOf("sha=") + 4);
        String rec = q("SELECT derived_sha256 FROM file_object WHERE file_id=?", fileId);
        Check.equal(shaA, shaB, "两个 worker 的派生文件摘要相同（确定性变换）");
        Check.equal(rec, Store.sha256(store.root.resolve(q("SELECT derived_path FROM file_object WHERE file_id=?", fileId))), "磁盘上派生文件与登记摘要一致");
    }

    static void p2bConcurrentWorkersOneClaim() throws Exception {
        reset();
        Check.begin("P2b", "多进程：两个 worker 同时启动抢同一任务");
        String fileId = committedFile(51);
        Proc a = new Proc("worker", root.toString(), "worker-a", "30", "false");
        Proc b = new Proc("worker", root.toString(), "worker-b", "30", "false");
        Check.equal(0, a.waitExit(), "worker-a 退出");
        Check.equal(0, b.waitExit(), "worker-b 退出");
        List<String> out = new ArrayList<>(a.all);
        out.addAll(b.all);
        Check.note("输出 " + out);
        Check.equal(1L, out.stream().filter(l -> l.startsWith("PUBLISHED")).count(), "恰好一个 PUBLISHED");
        Check.equal(1L, out.stream().filter(l -> l.startsWith("NO_JOB")).count(), "另一个没有领到任务");
        Check.equal(1L, n("SELECT count(*) FROM publish_event WHERE file_id=?", fileId), "发布事件 1 条");
    }

    static void nc1NaivePublish() throws Exception {
        reset();
        Check.begin("NC1", "负向对照：发布只按 file_id 更新，不检查状态与尝试号");
        String fileId = committedFile(52);
        Worker a = new Worker(store, "worker-a"), b = new Worker(store, "worker-b");
        Worker.Claim ca = a.claim(1);
        Worker.Artifact aa = a.transform(ca);
        Thread.sleep(1_500);
        Worker.Claim cb = b.claim(30);
        Check.equal(2, cb.attempt(), "租约过期后 worker-b 领到尝试号 2");
        b.publishNaive(cb, b.transform(cb));
        a.publishNaive(ca, aa);
        long events = n("SELECT count(*) FROM publish_event_naive WHERE file_id=?", fileId);
        long att = n("SELECT published_attempt FROM file_object WHERE file_id=?", fileId);
        Check.note("naive 事件数=" + events + " 最终 published_attempt=" + att);
        Check.exposes(events == 2, "同一文件发布事件 2 条");
        Check.exposes(att == 1, "过期尝试覆盖了较新的发布记录");
    }

    // ---------- P3: read visibility ----------

    static void p3ReaderProcessDuringProcessing() throws Exception {
        reset();
        Check.begin("P3", "多进程：独立读取进程在 PROCESSING 时被拒绝，发布后可读");
        String fileId = committedFile(53);
        String sha = q("SELECT blob_sha256 FROM file_object WHERE file_id=?", fileId);
        Check.that(Files.exists(store.blobPath(sha)), "blob 已在磁盘上（拒绝来自状态检查）");
        Proc r1 = new Proc("reader", root.toString(), fileId);
        r1.waitExit();
        Check.note("reader 输出 " + r1.all);
        Check.that(r1.all.contains("READ REJECTED code=NOT_READY detail=NOT_READY: PROCESSING"), "PROCESSING 时读取被拒绝");
        String pending = initAndUpload(data(54, 150_000), false);
        Proc r0 = new Proc("reader", root.toString(), "file-" + pending.substring(3));
        r0.waitExit();
        Check.that(r0.all.stream().anyMatch(l -> l.startsWith("READ REJECTED code=NOT_FOUND")), "上传中的会话没有可读文件：" + r0.all);
        Worker w = new Worker(store, "worker-a");
        Worker.Claim cl = w.claim(30);
        w.publish(cl, w.transform(cl));
        Proc r2 = new Proc("reader", root.toString(), fileId);
        r2.waitExit();
        Check.note("reader 输出 " + r2.all);
        Check.that(r2.all.contains("READ OK bytes=150000 sha=" + sha), "发布后读取成功且摘要一致");
    }

    static void nc2NaiveReader() throws Exception {
        reset();
        Check.begin("NC2", "负向对照：按内容地址直接读取，不检查文件状态");
        String fileId = committedFile(55);
        Check.equal("NOT_READY", code(() -> svc.read(fileId)), "对照组：正式读取接口拒绝");
        byte[] leaked = svc.readNaive(fileId);
        Check.exposes(leaked.length == 150_000, "PROCESSING 文件被读出 " + leaked.length + " 字节");
    }
}
