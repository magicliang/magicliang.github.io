package lab.files;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.sql.Connection;
import java.time.Duration;
import java.time.Instant;
import lab.common.Db;

/**
 * 独立 JVM 进程入口，由 Main 启动并发送信号。
 *   complete-crash <root> <session> <point>   执行 complete，到达注入点后打印 AT 并停住，等待 kill -9
 *   worker <root> <name> <leaseSec> <gate>     领取并处理一个任务；gate=true 时发布前打印 PAUSE 并等待标准输入
 *   reader <root> <fileId>                     调用读取接口
 *   naive-assemble <root> <session>            负向对照：直接写到内容地址，写完第一块后停住
 */
public final class Child {
    public static void main(String[] a) throws Exception {
        Store store = new Store(Path.of(a[1]));
        switch (a[0]) {
            case "complete-crash" -> {
                UploadService svc = new UploadService(store, Instant::now, Duration.ofHours(1));
                String point = a[3];
                svc.hook = p -> {
                    if (p.equals(point)) {
                        System.out.println("AT " + p + " pid=" + ProcessHandle.current().pid());
                        System.out.flush();
                        parkForever();
                    }
                };
                svc.complete(a[2]);
                System.out.println("COMPLETED without reaching " + point);
            }
            case "worker" -> {
                Worker w = new Worker(store, a[2]);
                Worker.Claim cl = w.claim(Integer.parseInt(a[3]));
                if (cl == null) {
                    System.out.println("NO_JOB worker=" + w.name);
                    return;
                }
                Worker.Artifact art = w.transform(cl);
                System.out.println("ARTIFACT worker=" + w.name + " file=" + cl.fileId() + " attempt=" + cl.attempt()
                    + " sha=" + art.sha256());
                if (Boolean.parseBoolean(a[4])) {
                    System.out.println("PAUSE before-publish pid=" + ProcessHandle.current().pid());
                    System.out.flush();
                    new BufferedReader(new InputStreamReader(System.in)).readLine();
                }
                boolean ok = w.publish(cl, art);
                System.out.println((ok ? "PUBLISHED" : "REJECTED") + " worker=" + w.name + " attempt=" + cl.attempt());
            }
            case "reader" -> {
                UploadService svc = new UploadService(store, Instant::now, Duration.ofHours(1));
                try {
                    byte[] d = svc.read(a[2]);
                    System.out.println("READ OK bytes=" + d.length + " sha=" + Store.sha256(d));
                } catch (FileError e) {
                    System.out.println("READ REJECTED code=" + e.code + " detail=" + e.getMessage());
                }
            }
            case "naive-assemble" -> {
                String sha;
                try (Connection c = Db.connect()) {
                    sha = Db.queryString(c, "SELECT declared_sha256 FROM upload_session WHERE session_id=?", a[2]);
                }
                try (FileChannel ch = FileChannel.open(store.blobPath(sha), StandardOpenOption.CREATE, StandardOpenOption.WRITE)) {
                    ch.write(java.nio.ByteBuffer.wrap(Files.readAllBytes(store.partPath(a[2], 1))));
                    ch.force(true);
                    System.out.println("AT partial-write pid=" + ProcessHandle.current().pid());
                    System.out.flush();
                    parkForever();
                }
            }
            default -> throw new IllegalArgumentException(a[0]);
        }
    }

    static void parkForever() {
        while (true) {
            try {
                Thread.sleep(60_000);
            } catch (InterruptedException ignored) {
            }
        }
    }
}
