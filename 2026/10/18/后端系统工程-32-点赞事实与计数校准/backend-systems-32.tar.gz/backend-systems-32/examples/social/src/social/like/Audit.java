package social.like;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import lab.common.Db;

/** 对账查询。每个方法只用一条 SQL，保证在同一快照内读出所有量。 */
public final class Audit {
    private Audit() {}

    /**
     * 写侧不变量：序号无空洞；每对 (user, item) 的版本等于其事件条数；每个条目的事件增量之和等于事实数。
     */
    public record WriteSide(long last, long events, long versionMismatch, long sumMismatch) {
        public boolean ok() { return last == events && versionMismatch == 0 && sumMismatch == 0; }
        public String toString() {
            return "last_seq=" + last + " outbox_rows=" + events + " version_mismatch_pairs=" + versionMismatch +
                   " delta_sum_mismatch_items=" + sumMismatch;
        }
    }

    public static WriteSide writeSide(Connection c) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("""
                SELECT (SELECT last FROM like_seq),
                       (SELECT count(*) FROM like_outbox),
                       (SELECT count(*) FROM like_fact f
                         WHERE f.version <> (SELECT count(*) FROM like_outbox o WHERE o.user_id = f.user_id AND o.item_id = f.item_id)),
                       (SELECT count(*) FROM item i
                         WHERE (SELECT count(*) FROM like_fact f WHERE f.item_id = i.item_id AND f.liked)
                            <> (SELECT coalesce(sum(delta), 0) FROM like_outbox o WHERE o.item_id = i.item_id))
                """); ResultSet rs = ps.executeQuery()) {
            rs.next();
            return new WriteSide(rs.getLong(1), rs.getLong(2), rs.getLong(3), rs.getLong(4));
        }
    }

    /**
     * 读侧快照：lag、未处理事件数、计数与事实不符的条目数、最大绝对误差，以及两条恒等式的违反条目数：
     * exact:  n + Σ(未处理且序号 > base_seq 的增量) = 事实数
     * bound:  |n − 事实数| ≤ 该条目未处理事件数
     */
    public record ReadSide(long last, long watermark, long unprocessed, long mismatchItems, long maxErr,
                           long exactViolations, long boundViolations) {
        public long lag() { return last - watermark; }
        public String toString() {
            return "last_seq=" + last + " watermark=" + watermark + " lag=" + lag() + " unprocessed=" + unprocessed +
                   " count_mismatch_items=" + mismatchItems + " max_abs_err=" + maxErr +
                   " exact_violations=" + exactViolations + " bound_violations=" + boundViolations;
        }
    }

    public static ReadSide readSide(Connection c) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("""
                WITH truth AS (
                  SELECT i.item_id, count(*) FILTER (WHERE f.liked) AS t
                  FROM item i LEFT JOIN like_fact f USING (item_id) GROUP BY i.item_id),
                cnt AS (
                  SELECT i.item_id, coalesce(lc.n, 0) AS n, coalesce(lc.base_seq, 0) AS b
                  FROM item i LEFT JOIN like_count lc USING (item_id)),
                pend AS (
                  SELECT o.item_id, count(*) AS pc,
                         coalesce(sum(o.delta) FILTER (WHERE o.seq > cnt.b), 0) AS psum
                  FROM like_outbox o JOIN cnt USING (item_id)
                  WHERE NOT EXISTS (SELECT 1 FROM processed_event p WHERE p.seq = o.seq)
                  GROUP BY o.item_id)
                SELECT (SELECT last FROM like_seq),
                       (SELECT applied_upto FROM counter_watermark),
                       coalesce(sum(pend.pc), 0),
                       count(*) FILTER (WHERE cnt.n <> truth.t),
                       coalesce(max(abs(cnt.n - truth.t)), 0),
                       count(*) FILTER (WHERE cnt.n + coalesce(pend.psum, 0) <> truth.t),
                       count(*) FILTER (WHERE abs(cnt.n - truth.t) > coalesce(pend.pc, 0))
                FROM truth JOIN cnt USING (item_id) LEFT JOIN pend USING (item_id)
                """); ResultSet rs = ps.executeQuery()) {
            rs.next();
            return new ReadSide(rs.getLong(1), rs.getLong(2), rs.getLong(3), rs.getLong(4), rs.getLong(5), rs.getLong(6), rs.getLong(7));
        }
    }

    /** 负向对照 1 的偏差：直接加减的计数与事实数不一致的条目数及偏差绝对值之和。 */
    public static long[] naiveDrift(Connection c) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("""
                SELECT count(*) FILTER (WHERE coalesce(nv.n, 0) <> t.t), coalesce(sum(abs(coalesce(nv.n, 0) - t.t)), 0)
                FROM (SELECT i.item_id, count(*) FILTER (WHERE f.liked) AS t
                      FROM item i LEFT JOIN like_fact f USING (item_id) GROUP BY i.item_id) t
                LEFT JOIN like_count_naive nv USING (item_id)
                """); ResultSet rs = ps.executeQuery()) {
            rs.next();
            return new long[]{rs.getLong(1), rs.getLong(2)};
        }
    }

    /** 读计数时一并返回误差上界：本条目未处理事件数，以及全局滞后。 */
    public record CountView(long n, long baseSeq, long last, long watermark, long pendingForItem, boolean stale) {
        public long lag() { return last - watermark; }
        public String toString() {
            return "n=" + n + " lag=" + lag() + " pendingForItem=" + pendingForItem + " stale=" + stale;
        }
    }

    /** allowedLag 为教学设定的允许滞后（事件条数）；lag 超过它时把读结果标为 stale。 */
    public static CountView readCount(Connection c, String item, long allowedLag) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("""
                SELECT coalesce((SELECT n FROM like_count WHERE item_id = ?), 0),
                       coalesce((SELECT base_seq FROM like_count WHERE item_id = ?), 0),
                       (SELECT last FROM like_seq), (SELECT applied_upto FROM counter_watermark),
                       (SELECT count(*) FROM like_outbox o WHERE o.item_id = ?
                          AND NOT EXISTS (SELECT 1 FROM processed_event p WHERE p.seq = o.seq))
                """)) {
            ps.setString(1, item); ps.setString(2, item); ps.setString(3, item);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                long last = rs.getLong(3), w = rs.getLong(4);
                return new CountView(rs.getLong(1), rs.getLong(2), last, w, rs.getLong(5), last - w > allowedLag);
            }
        }
    }

    public static long q(Connection c, String sql, Object... a) throws SQLException { return Db.queryLong(c, sql, a); }
}
