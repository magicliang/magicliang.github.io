package social.feed;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CyclicBarrier;
import java.util.stream.Collectors;
import lab.common.Check;
import lab.common.Db;
import social.feed.Feed.Cursor;
import social.feed.Feed.Item;
import social.feed.Feed.Kind;
import social.feed.Feed.Paging;
import social.rel.AccessCheck;
import social.rel.RelSchema;
import social.rel.RelationService;

/** 第 31 篇：Feed 的扇出成本与热点。全部用例使用真实 PostgreSQL 16 事务。 */
public final class Ch31Main {
    static final long SEED = 31_2026L;
    // 教学假设：1200 个用户，每人关注 5..40 个账号，被关注者按 Zipf(s=1.0) 抽取；3000 条帖子，每页 20 条，读 3 页
    static final int USERS = 1200, MIN_DEG = 5, MAX_DEG = 40, POSTS = 3000, READERS = 100, PAGE = 20, PAGES = 3;
    static final double ZIPF_S = 1.0;
    static final long HOT_COUNT = 10_000; // 人为设定的计数快照，让专用测试作者落入拉取档

    static String db;
    static final List<Feed> feeds = new ArrayList<>();
    static final Map<Feed, Connection> conns = new LinkedHashMap<>();

    public static void main(String[] args) throws Exception {
        db = System.getenv().getOrDefault("LAB_DB", "social31");
        Db.recreate(db);
        try (Connection c = Db.connect(db)) {
            RelSchema.create(c);
            Feed.createShared(c);
            feeds.add(new Feed("push", Kind.PUSH, Long.MAX_VALUE));
            feeds.add(new Feed("pull", Kind.PULL, 0));
            feeds.add(new Feed("h50", Kind.HYBRID, 50));
            feeds.add(new Feed("h200", Kind.HYBRID, 200));
            for (Feed f : feeds) { f.createTables(c); conns.put(f, f.open(db)); }
            System.out.println("chapter 31 feed lab, seed=" + SEED + ", db=" + db);
            Graph g = Graph.generate(SEED, USERS, MIN_DEG, MAX_DEG, ZIPF_S, POSTS);
            g.load(c);
            compareSchemes(c, g);
            hotBurst(c, g);
            duplicateTimestamps(c);
            insertDuringPaging(c);
            revocation(c);
            cleanupRace(c);
            concurrentBlockPublish(c);
            thresholdCrossing(c);
            followAfterPublish(c);
            interruptedPublish(c, g);
        } finally {
            for (Connection x : conns.values()) x.close();
        }
        System.exit(Check.finish());
    }

    static Feed feed(String name) { return feeds.stream().filter(f -> f.name.equals(name)).findFirst().orElseThrow(); }
    static Connection conn(String name) { return conns.get(feed(name)); }

    static List<Long> ids(List<Item> items) { return items.stream().map(Item::postId).collect(Collectors.toList()); }

    static boolean strictlyNewestFirst(List<Item> items) {
        for (int i = 1; i < items.size(); i++) if (Feed.NEWEST_FIRST.compare(items.get(i - 1), items.get(i)) >= 0) return false;
        return true;
    }

    /** 从 TOP 开始按键集游标走完整个 Feed（或最多 maxPages 页）。 */
    static List<Item> walk(Feed f, Connection c, String reader, int limit, int maxPages, Paging paging) throws SQLException {
        List<Item> all = new ArrayList<>();
        Cursor cur = Cursor.TOP;
        for (int p = 0; p < maxPages; p++) {
            List<Item> page = f.page(c, reader, cur, all.size(), limit, paging);
            all.addAll(page);
            if (page.size() < limit) break;
            cur = Feed.next(page);
        }
        return all;
    }

    static void setCount(Connection c, String author, long n) throws SQLException {
        Db.update(c, "INSERT INTO follower_count (author, followers) VALUES (?, ?) " +
                     "ON CONFLICT (author) DO UPDATE SET followers = EXCLUDED.followers", author, n);
    }

    static boolean allowed(Connection c, String reader, long postId) throws SQLException {
        return AccessCheck.canRead(c, reader, postId, AccessCheck.Mode.TRUTH).allowed();
    }

    // ---------------------------------------------------------------- 31-A 相同输入下的读写放大
    static void compareSchemes(Connection c, Graph g) throws SQLException {
        Check.begin("31-A", "相同合成关注图：推、拉、混合(50/200) 的写入行数、读取语句与行数；四种方案结果与内存模型一致");
        List<Integer> fc = new ArrayList<>(g.followers.values());
        Collections.sort(fc);
        long over50 = fc.stream().filter(x -> x >= 50).count(), over200 = fc.stream().filter(x -> x >= 200).count();
        Map<String, Long> vis = g.posts.stream().collect(Collectors.groupingBy(Graph.PostSpec::visibility, java.util.TreeMap::new, Collectors.counting()));
        Check.note("graph users=" + USERS + " edges=" + g.edges() + " outDegree=" + MIN_DEG + ".." + MAX_DEG + " zipf_s=" + ZIPF_S);
        Check.note("followers p50=" + fc.get(fc.size() / 2) + " p90=" + fc.get(fc.size() * 9 / 10) + " p99=" + fc.get(fc.size() * 99 / 100) +
                   " max=" + fc.get(fc.size() - 1) + " zeroFollowers=" + fc.stream().filter(x -> x == 0).count() +
                   " authors>=50: " + over50 + " authors>=200: " + over200);
        Check.note("posts=" + POSTS + " visibility=" + vis + " readers=" + READERS + " pages=" + PAGES + "x" + PAGE);
        Check.equal(g.edges(), Db.queryLong(c, "SELECT count(*) FROM relation WHERE state = 'ACTIVE'"), "关系行数等于生成的边数");

        Map<Feed, long[]> writes = new LinkedHashMap<>();
        for (Feed f : feeds) {
            f.cost.reset();
            for (Graph.PostSpec p : g.posts) f.publish(conns.get(f), p.postId(), p.author(), p.createdAt(), p.visibility());
            long model = g.expectedWriteRows(f.threshold);
            long inbox = Db.queryLong(c, "SELECT count(*) FROM " + f.schema + ".inbox");
            long pulled = Db.queryLong(c, "SELECT count(*) FROM " + f.schema + ".post WHERE delivery = 'PULL'");
            writes.put(f, new long[]{f.cost.writeQueries, f.cost.writeRows, f.cost.maxFanoutRows, inbox, pulled});
            Check.equal(model, f.cost.writeRows, f.name + " 写入行数等于内存模型（帖子 + 推送帖子的粉丝数之和）");
        }

        Random rnd = new Random(SEED + 1);
        List<String> readers = new ArrayList<>(g.users);
        Collections.shuffle(readers, rnd);
        readers = readers.subList(0, READERS);
        Map<Feed, long[]> reads = new LinkedHashMap<>();
        Map<String, List<Long>> first = new LinkedHashMap<>();
        for (Feed f : feeds) {
            f.cost.reset();
            int mismatches = 0, dupPages = 0;
            Map<String, List<Item>> result = new LinkedHashMap<>();
            for (String r : readers) {
                List<Item> got = walk(f, conns.get(f), r, PAGE, PAGES, Paging.KEYSET);
                result.put(r, got);
                if (!ids(got).equals(ids(g.expectedFeed(r, PAGE * PAGES)))) mismatches++;
                if (new HashSet<>(ids(got)).size() != got.size()) dupPages++;
            }
            long[] cost = {f.cost.readQueries, f.cost.readRows, f.cost.pages, f.cost.maxPageQueries};
            reads.put(f, cost);
            int denied = 0, items = 0;
            for (var e : result.entrySet())
                for (Item it : e.getValue()) { items++; if (!allowed(conns.get(f), e.getKey(), it.postId())) denied++; }
            Check.equal(0, mismatches, f.name + " 100 个读者的前 3 页与内存模型逐条一致");
            Check.equal(0, dupPages, f.name + " 无重复条目");
            Check.equal(0, denied, f.name + " 返回的 " + items + " 条全部通过 AccessCheck(TRUTH)");
            for (var e : result.entrySet()) first.merge(e.getKey(), ids(e.getValue()), (a, b) -> a.equals(b) ? a : List.of(-1L));
            if (f.kind == Kind.PULL || f.name.equals("h200")) {
                String hot = Collections.max(g.followers.entrySet(), Map.Entry.comparingByValue()).getKey();
                long total = f.cost.streamQueriesByAuthor.values().stream().mapToLong(Long::longValue).sum();
                Check.note(f.name + " author-stream queries=" + total + ", of which hot author " + hot +
                           " (followers=" + g.followers.get(hot) + ")=" + f.cost.streamQueriesByAuthor.getOrDefault(hot, 0L));
            }
        }
        Check.that(first.values().stream().noneMatch(l -> l.equals(List.of(-1L))), "四种方案对每个读者返回相同的帖子序列");
        System.out.println("  table scheme | writeQueries writeRows maxFanoutRows inboxRows pullPosts | readQueries readRows pages maxQueriesPerPage");
        for (Feed f : feeds) {
            long[] w = writes.get(f), r = reads.get(f);
            System.out.printf("  table %-5s | %d %d %d %d %d | %d %d %d %d%n", f.name, w[0], w[1], w[2], w[3], w[4], r[0], r[1], r[2], r[3]);
        }
    }

    // ---------------------------------------------------------------- 31-B 热点作者连续发帖
    static void hotBurst(Connection c, Graph g) throws SQLException {
        Check.begin("31-B", "热点作者连续发 10 帖：每种方案的写入行数与单帖最大扇出；其粉丝首页顶部是这 10 帖");
        var hot = Collections.max(g.followers.entrySet(), Map.Entry.comparingByValue());
        String fan = g.users.stream().filter(x -> g.followees.get(x).contains(hot.getKey())).findFirst().orElseThrow();
        Check.note("hot author=" + hot.getKey() + " followers=" + hot.getValue() + " sample follower=" + fan);
        for (Feed f : feeds) {
            f.cost.reset();
            for (int k = 0; k < 10; k++) f.publish(conns.get(f), 500_000 + k, hot.getKey(), 2_000_000L + k, "PUBLIC");
            long w = f.cost.writeRows, q = f.cost.writeQueries, mx = f.cost.maxFanoutRows;
            f.cost.reset();
            List<Item> top = f.page(conns.get(f), fan, Cursor.TOP, 10);
            Check.note(f.name + " burst writeQueries=" + q + " writeRows=" + w + " maxFanoutRows=" + mx +
                       " | follower first page readQueries=" + f.cost.readQueries + " readRows=" + f.cost.readRows);
            long expected = f.kind == Kind.PUSH || hot.getValue() < f.threshold ? 10L * (1 + hot.getValue()) : 10L;
            Check.equal(expected, w, f.name + " 写入行数");
            Check.that(top.stream().allMatch(i -> i.author().equals(hot.getKey())) && top.size() == 10, f.name + " 粉丝首页前 10 条是热点作者的 10 帖");
        }
    }

    // ---------------------------------------------------------------- 31-C 重复时间戳
    static void duplicateTimestamps(Connection c) throws SQLException {
        Check.begin("31-C", "边界：30 帖中 20 帖共用同一 created_at，每页 7 条跨越同值区间；键集游标不漏不重，仅时间戳游标漏帖");
        String reader = "user-8001", a = "user-8011", h = "user-8012";
        RelationService rs = new RelationService(c);
        rs.follow(reader, a); rs.follow(reader, h);
        setCount(c, a, 1); setCount(c, h, HOT_COUNT);
        List<Long> pids = new ArrayList<>();
        for (long i = 0; i < 30; i++) pids.add(700_000 + i);
        Collections.shuffle(pids, new Random(SEED + 3));
        for (Feed f : feeds)
            for (int i = 0; i < 30; i++) f.publish(conns.get(f), pids.get(i), i % 2 == 0 ? a : h, i < 20 ? 3_000_000L : 2_999_999L, "PUBLIC");
        List<Long> expected = new ArrayList<>(pids);
        // 期望顺序：created_at 降序，再 post_id 降序
        expected.sort((x, y) -> {
            long cx = pids.indexOf(x) < 20 ? 3_000_000L : 2_999_999L, cy = pids.indexOf(y) < 20 ? 3_000_000L : 2_999_999L;
            return cx != cy ? Long.compare(cy, cx) : Long.compare(y, x);
        });
        for (Feed f : feeds) {
            List<Item> ks = walk(f, conns.get(f), reader, 7, 100, Paging.KEYSET);
            Check.that(ids(ks).equals(expected) && strictlyNewestFirst(ks), f.name + " 键集游标：30 条按 (created_at, post_id) 严格降序且不漏不重");
            List<Item> ts = walk(f, conns.get(f), reader, 7, 100, Paging.TS_ONLY);
            Set<Long> got = new HashSet<>(ids(ts));
            long missing = expected.stream().filter(x -> !got.contains(x)).count();
            Check.note(f.name + " TS_ONLY cursor returned=" + ts.size() + " missing=" + missing);
            Check.exposes(missing > 0, f.name + " 只比较 created_at 的游标在同值边界漏掉 " + missing + " 帖");
        }
    }

    // ---------------------------------------------------------------- 31-D 翻页期间插入
    static void insertDuringPaging(Connection c) throws SQLException {
        Check.begin("31-D", "翻页期间发布：较新帖与游标之下的帖按规则出现；落入已读区间的帖本轮不可见、刷新后可见；OFFSET 分页出现重复");
        RelationService rs = new RelationService(c);
        String reader = "user-8101", a = "user-8111", h = "user-8112";
        String r2 = "user-8201", a2 = "user-8211", h2 = "user-8212";
        rs.follow(reader, a); rs.follow(reader, h); rs.follow(r2, a2); rs.follow(r2, h2);
        setCount(c, a, 1); setCount(c, h, HOT_COUNT); setCount(c, a2, 1); setCount(c, h2, HOT_COUNT);
        for (Feed f : feeds) {
            Connection fc = conns.get(f);
            for (int k = 0; k < 24; k++) {
                f.publish(fc, 710_000 + k, k % 2 == 0 ? a : h, 4_000_000L + k / 2, "PUBLIC");
                f.publish(fc, 720_000 + k, k % 2 == 0 ? a2 : h2, 4_000_000L + k / 2, "PUBLIC");
            }
            // 键集游标
            List<Item> p1 = f.page(fc, reader, Cursor.TOP, 8);
            Cursor cur = Feed.next(p1);
            for (int k = 0; k < 3; k++) f.publish(fc, 711_000 + k, k % 2 == 0 ? a : h, 4_100_000L + k, "PUBLIC");
            f.publish(fc, 711_100, h, 4_000_010L, "PUBLIC");  // 落在第 1 页已读区间之内（模拟时钟落后的写入者）
            f.publish(fc, 711_200, a, 4_000_003L, "PUBLIC");  // 在游标之下
            List<Item> rest = new ArrayList<>(p1);
            while (true) {
                List<Item> p = f.page(fc, reader, cur, 8);
                rest.addAll(p);
                if (p.size() < 8) break;
                cur = Feed.next(p);
            }
            Set<Long> seen = new HashSet<>(ids(rest));
            boolean allOriginal = java.util.stream.IntStream.range(0, 24).allMatch(k -> seen.contains(710_000L + k));
            Check.note(f.name + " cursor after page1=" + Feed.next(p1) + " traversal size=" + rest.size() +
                       " sawBelowCursor=" + seen.contains(711_200L) + " sawInsideReadRange=" + seen.contains(711_100L) +
                       " sawNewer=" + seen.contains(711_000L));
            Check.that(allOriginal && seen.size() == rest.size() && strictlyNewestFirst(rest),
                    f.name + " 键集：原有 24 帖全部出现、无重复、严格降序");
            Check.that(seen.contains(711_200L) && !seen.contains(711_100L) && !seen.contains(711_000L),
                    f.name + " 键集：游标之下的新帖可见；已读区间内与更新的帖本轮不可见（声明的边界）");
            List<Item> refresh = walk(f, fc, reader, 8, 100, Paging.KEYSET);
            Check.equal(29, refresh.size(), f.name + " 从顶部刷新后看到 24+5 帖");
            Check.equal(29, new HashSet<>(ids(refresh)).size(), f.name + " 刷新结果无重复");
            // OFFSET 负向对照
            List<Item> o1 = f.page(fc, r2, Cursor.TOP, 0, 8, Paging.OFFSET);
            for (int k = 0; k < 3; k++) f.publish(fc, 721_000 + k, k % 2 == 0 ? a2 : h2, 4_100_000L + k, "PUBLIC");
            List<Item> o2 = f.page(fc, r2, Cursor.TOP, 8, 8, Paging.OFFSET);
            Set<Long> s1 = new HashSet<>(ids(o1));
            long dup = o2.stream().filter(i -> s1.contains(i.postId())).count();
            Check.note(f.name + " OFFSET page2 repeated " + dup + " items of page1");
            Check.exposes(dup > 0, f.name + " OFFSET 分页在顶部插入后第 2 页重复第 1 页的帖");
        }
    }

    // ---------------------------------------------------------------- 31-E 撤销
    static void revocation(Connection c) throws SQLException {
        Check.begin("31-E", "撤销：取消关注、拉黑、帖子改为 SELF 后，过滤读取不再返回；直接返回收件箱行会泄露；恢复操作的结果");
        RelationService rs = new RelationService(c);
        String r = "user-8301", a = "user-8311", h = "user-8312", s = "user-8313";
        rs.follow(r, a); rs.follow(r, h); rs.follow(r, s);
        setCount(c, a, 1); setCount(c, h, HOT_COUNT); setCount(c, s, 1);
        long a1 = 730_001, a2 = 730_002, h1 = 730_003, s1 = 730_004;
        for (Feed f : feeds) {
            Connection fc = conns.get(f);
            f.publish(fc, a1, a, 5_000_001L, "FOLLOWERS");
            f.publish(fc, a2, a, 5_000_002L, "PUBLIC");
            f.publish(fc, h1, h, 5_000_003L, "FOLLOWERS");
            f.publish(fc, s1, s, 5_000_004L, "PUBLIC");
        }
        for (Feed f : feeds) Check.equal(4, f.page(conns.get(f), r, Cursor.TOP, 20).size(), f.name + " 撤销前 4 帖可见");
        rs.unfollow(r, a);
        rs.block(h, r);
        for (Feed f : feeds) Db.update(conns.get(f), "UPDATE post SET visibility = 'SELF' WHERE post_id = ?", s1);
        Check.note("ops: unfollow(" + r + "->" + a + "), block(" + h + " blocks " + r + "), post " + s1 + " -> SELF");
        for (Feed f : feeds) {
            Connection fc = conns.get(f);
            List<Item> page = f.page(fc, r, Cursor.TOP, 20);
            Check.equal(0, page.size(), f.name + " 过滤读取返回 0 帖");
            if (f.kind == Kind.PULL) continue;
            List<Item> raw = f.rawInboxPage(fc, r, 20);
            StringBuilder sb = new StringBuilder();
            int deniedLeak = 0;
            for (Item it : raw) {
                AccessCheck.Decision d = AccessCheck.canRead(fc, r, it.postId(), AccessCheck.Mode.TRUTH);
                sb.append(it.postId()).append('=').append(d).append(' ');
                if (!d.allowed()) deniedLeak++;
            }
            Check.note(f.name + " raw inbox rows=" + raw.size() + " : " + sb.toString().trim());
            Check.exposes(deniedLeak > 0, f.name + " 直接返回收件箱行时，" + deniedLeak + " 帖是 AccessCheck 拒绝的内容");
        }
        rs.unblock(h, r);
        rs.follow(r, a);
        for (Feed f : feeds) Db.update(conns.get(f), "UPDATE post SET visibility = 'PUBLIC' WHERE post_id = ?", s1);
        for (Feed f : feeds) {
            List<Long> got = ids(f.page(conns.get(f), r, Cursor.TOP, 20));
            Check.note(f.name + " after unblock + refollow + PUBLIC: " + got);
            Check.equal(List.of(s1, a2, a1), got, f.name + " 恢复后：重新关注的作者与改回公开的帖可见，解除拉黑不恢复旧关注");
        }
    }

    // ---------------------------------------------------------------- 31-F 清理不是保证
    static void cleanupRace(Connection c) throws SQLException {
        Check.begin("31-F", "负向对照：取消关注时删除收件箱行，与未提交的扇出事务交错，删除漏掉在途行");
        Feed f = feed("push");
        Connection fc = conns.get(f);
        String r = "user-8401", a = "user-8411";
        new RelationService(c).follow(r, a);
        f.publish(fc, 740_001, a, 6_000_001L, "FOLLOWERS");
        long[] deleted = new long[1];
        f.publish(fc, 740_002, a, 6_000_002L, "FOLLOWERS", cx -> {
            // 扇出语句已执行、尚未提交；另一个连接取消关注并清理收件箱
            try (Connection other = f.open(db)) {
                new RelationService(other).unfollow(r, a);
                deleted[0] = Db.update(other, "DELETE FROM inbox WHERE reader = ? AND author = ?", r, a);
            }
        });
        List<Item> raw = f.rawInboxPage(fc, r, 20);
        Check.note("cleanup deleted=" + deleted[0] + " raw inbox after publish commit=" + ids(raw));
        Check.equal(1L, deleted[0], "清理删除了已提交的 740001");
        Check.exposes(ids(raw).contains(740_002L), "在途扇出的 740002 在清理之后仍留在收件箱");
        Check.that(!allowed(fc, r, 740_002), "AccessCheck 拒绝 740002（FOLLOWERS，已取消关注）");
        Check.equal(0, f.page(fc, r, Cursor.TOP, 20).size(), "读取时过滤仍返回 0 帖");
    }

    // ---------------------------------------------------------------- 31-G 并发拉黑与发布
    static void concurrentBlockPublish(Connection c) throws Exception {
        Check.begin("31-G", "真实线程：作者连发 5 帖的同时拉黑读者，20 轮；收件箱可能残留行，过滤读取一条都不返回");
        int rounds = 20;
        long leftover = 0;
        int violations = 0;
        ConcurrentLinkedQueue<Throwable> errors = new ConcurrentLinkedQueue<>();
        for (String name : List.of("push", "h50")) {
            Feed f = feed(name);
            for (int k = 0; k < rounds; k++) {
                int base = name.equals("push") ? 0 : 50;
                String r = String.format("user-85%02d", base + k), a = String.format("user-86%02d", base + k);
                new RelationService(c).follow(r, a);
                setCount(c, a, 1);
                CyclicBarrier barrier = new CyclicBarrier(2);
                final int round = k;
                Thread pub = Thread.ofPlatform().start(() -> {
                    try (Connection x = f.open(db)) {
                        barrier.await();
                        for (int i = 0; i < 5; i++) f.publish(x, 750_000 + round * 10 + i, a, 7_000_000L + round * 10 + i, "PUBLIC");
                    } catch (Throwable t) { errors.add(t); }
                });
                Thread blk = Thread.ofPlatform().start(() -> {
                    try (Connection x = Db.connect(db)) {
                        barrier.await();
                        new RelationService(x).block(a, r);
                    } catch (Throwable t) { errors.add(t); }
                });
                pub.join(); blk.join();
                Connection fc = conns.get(f);
                leftover += f.rawInboxPage(fc, r, 20).size();
                for (Item it : f.page(fc, r, Cursor.TOP, 20)) if (it.author().equals(a)) violations++;
                for (int i = 0; i < 5; i++) if (allowed(fc, r, 750_000 + k * 10 + i)) violations++;
            }
            Check.note(name + " rounds=" + rounds + " leftover inbox rows (scheduling-dependent)=" + leftover);
            leftover = 0;
        }
        Check.equal(0, errors.size(), "无异常");
        Check.equal(0, violations, "拉黑提交后，过滤读取与 AccessCheck 都不放行被拉黑作者的帖");
    }

    // ---------------------------------------------------------------- 31-H 阈值跨越
    static void thresholdCrossing(Connection c) throws SQLException {
        Check.begin("31-H", "混合方案：作者粉丝数跨越阈值上下，按帖记录的投递方式读取不重不漏；读时按当前计数分类会重复或遗漏");
        Feed f = feed("h50");
        Connection fc = conns.get(f);
        String x = "user-8701", r = "user-8711";
        RelationService rs = new RelationService(c);
        for (int i = 8711; i <= 8713; i++) rs.follow("user-" + i, x);
        setCount(c, x, 3);
        f.publish(fc, 760_001, x, 8_000_001L, "PUBLIC");
        f.publish(fc, 760_002, x, 8_000_002L, "PUBLIC");
        setCount(c, x, 60);
        f.publish(fc, 760_003, x, 8_000_003L, "PUBLIC");
        f.publish(fc, 760_004, x, 8_000_004L, "PUBLIC");
        setCount(c, x, 3);
        f.publish(fc, 760_005, x, 8_000_005L, "PUBLIC");
        Check.note("delivery: " + Db.queryString(fc, "SELECT string_agg(post_id || '=' || delivery, ' ' ORDER BY post_id) FROM post WHERE author = ?", x));
        List<Long> expect = List.of(760_005L, 760_004L, 760_003L, 760_002L, 760_001L);
        for (long cnt : new long[]{3, 60}) {
            setCount(c, x, cnt);
            f.classifyAtRead = false;
            List<Long> ok = ids(f.page(fc, r, Cursor.TOP, 20));
            f.classifyAtRead = true;
            List<Long> naive = ids(f.page(fc, r, Cursor.TOP, 20));
            f.classifyAtRead = false;
            long dups = naive.size() - new HashSet<>(naive).size();
            long missing = expect.stream().filter(p -> !naive.contains(p)).count();
            Check.note("count now=" + cnt + " per-post delivery=" + ok + " classify-at-read=" + naive + " dup=" + dups + " missing=" + missing);
            Check.equal(expect, ok, "count=" + cnt + " 按帖投递方式读取：5 帖各一次");
            Check.exposes(dups > 0 || missing > 0, "count=" + cnt + " 读时分类" + (dups > 0 ? "重复 " + dups : "遗漏 " + missing) + " 帖");
        }
    }

    // ---------------------------------------------------------------- 31-I 关注晚于发布
    static void followAfterPublish(Connection c) throws SQLException {
        Check.begin("31-I", "边界：先发帖后关注；推送方案不回填旧帖，拉取方案能看到旧帖；之后的新帖三种方案一致");
        String r = "user-8801", y = "user-8811", z = "user-8812";
        setCount(c, y, 1); setCount(c, z, HOT_COUNT);
        for (Feed f : feeds) { f.publish(conns.get(f), 770_001, y, 9_000_001L, "PUBLIC"); f.publish(conns.get(f), 770_002, z, 9_000_002L, "PUBLIC"); }
        RelationService rs = new RelationService(c);
        rs.follow(r, y); rs.follow(r, z);
        Map<String, List<Long>> before = new LinkedHashMap<>();
        for (Feed f : feeds) before.put(f.name, ids(f.page(conns.get(f), r, Cursor.TOP, 20)));
        Check.note("old posts visible after follow: " + before);
        Check.equal(List.of(), before.get("push"), "push 不回填：关注前的两帖都不在 Feed");
        Check.equal(List.of(770_002L, 770_001L), before.get("pull"), "pull 读时取作者时间线：两帖都在");
        Check.equal(List.of(770_002L), before.get("h50"), "h50 只看到拉取档作者 " + z + " 的旧帖");
        Check.that(allowed(conns.get(feed("push")), r, 770_001), "缺失不是权限问题：AccessCheck 允许 770001");
        for (Feed f : feeds) { f.publish(conns.get(f), 770_003, y, 9_000_003L, "PUBLIC"); f.publish(conns.get(f), 770_004, z, 9_000_004L, "PUBLIC"); }
        for (Feed f : feeds) {
            List<Long> got = ids(f.page(conns.get(f), r, Cursor.TOP, 2));
            Check.equal(List.of(770_004L, 770_003L), got, f.name + " 关注之后的新帖都在首页顶部");
        }
    }

    // ---------------------------------------------------------------- 31-J 发布事务中断与重试
    static void interruptedPublish(Connection c, Graph g) throws SQLException {
        Check.begin("31-J", "恢复：推送方案中，热点作者的发布事务在扇出后、提交前被 pg_terminate_backend 终止；帖与收件箱行都不存在，重试一次扇出、再重试为 NOOP");
        Feed f = feed("push");
        var hot = Collections.max(g.followers.entrySet(), Map.Entry.comparingByValue());
        long pid = 780_001;
        String err = null;
        try (Connection victim = f.open(db)) {
            long backend = Db.queryLong(victim, "SELECT pg_backend_pid()");
            try {
                f.publish(victim, pid, hot.getKey(), 9_500_000L, "PUBLIC", cx -> {
                    long pending = Db.queryLong(cx, "SELECT count(*) FROM inbox WHERE post_id = ?", pid);
                    Check.note("inside tx: inbox rows written but uncommitted=" + pending);
                    try (Connection killer = Db.connect(db)) {
                        String sent = Db.queryString(killer, "SELECT pg_terminate_backend(?, 5000)::text", (int) backend);
                        long alive = Db.queryLong(killer, "SELECT count(*) FROM pg_stat_activity WHERE pid = ?", (int) backend);
                        Check.note("pg_terminate_backend(" + backend + ", 5000ms)=" + sent + " backendStillListed=" + alive);
                    }
                });
            } catch (SQLException e) {
                err = e.getSQLState() + " " + e.getMessage().split("\n")[0];
            }
        }
        // Tx 在回滚和恢复 autocommit 时还会再碰到已关闭的连接，抛出的最后一个异常会盖住提交时的原始错误
        Check.note("publish failed (last exception seen by caller): " + err);
        Check.that(err != null, "提交前被终止的发布返回错误");
        Connection fc = conns.get(f);
        Check.equal(0L, Db.queryLong(fc, "SELECT count(*) FROM post WHERE post_id = ?", pid), "帖子行不存在");
        Check.equal(0L, Db.queryLong(fc, "SELECT count(*) FROM inbox WHERE post_id = ?", pid), "收件箱行不存在");
        String first = f.publish(fc, pid, hot.getKey(), 9_500_000L, "PUBLIC");
        long rows = Db.queryLong(fc, "SELECT count(*) FROM inbox WHERE post_id = ?", pid);
        String second = f.publish(fc, pid, hot.getKey(), 9_500_000L, "PUBLIC");
        long rows2 = Db.queryLong(fc, "SELECT count(*) FROM inbox WHERE post_id = ?", pid);
        Check.note("retry=" + first + " inboxRows=" + rows + " second retry=" + second + " inboxRows=" + rows2);
        Check.equal((long) hot.getValue(), rows, "重试后收件箱行数等于粉丝数");
        Check.equal("NOOP", second, "再次重试为 NOOP");
        Check.equal(rows, rows2, "再次重试不新增收件箱行");
    }
}
