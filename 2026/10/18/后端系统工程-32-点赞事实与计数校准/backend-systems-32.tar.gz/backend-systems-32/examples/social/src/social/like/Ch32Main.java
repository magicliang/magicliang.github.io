package social.like;

import static social.like.LikeSchema.item;
import static social.like.LikeSchema.user;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import lab.common.Check;
import lab.common.Db;
import social.common.Tx;
import social.like.CounterConsumer.Ev;
import social.like.CounterConsumer.Stats;
import social.like.LikeService.Outcome;
import social.like.LikeService.Result;

/** 第 32 篇：点赞事实与计数校准。真实 PostgreSQL 事务、真实线程；32-J 为独立 JVM 进程，32-K 为数据库 immediate 停机。 */
public final class Ch32Main {
    static final long SEED = 32_2026L;
    static String db;

    public static void main(String[] args) throws Exception {
        db = System.getenv().getOrDefault("LAB_DB", "social32");
        Db.recreate(db);
        try (Connection c = Db.connect(db)) {
            LikeSchema.create(c);
            System.out.println("chapter 32 like/count lab, seed=" + SEED + ", db=" + db);
            normal(c);
            boundaries(c);
            concurrentSamePair(c);
            lagDefinition(c);
            shuffledDuplicates(c);
            naiveIncrement(c);
            noDedupConsumer(c);
            rebuildVsOnline(c);
            rebuildLockWait(c);
            concurrentMix(c);
            consumerKill(c);
        }
        dbCrash();
        System.out.println();
        System.out.println("tx retries observed (40001/40P01): " + Tx.retries);
        System.exit(Check.finish());
    }

    // ---------------------------------------------------------------- 工具
    record Req(int user, int item, boolean want) {}

    static List<Req> workload(Random r, int n, int users, int items, double hotShare) {
        List<Req> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            int it = items == 1 || r.nextDouble() < hotShare ? 1 : 2 + r.nextInt(items - 1);
            out.add(new Req(1 + r.nextInt(users), it, r.nextBoolean()));
        }
        return out;
    }

    static Stats drain(Connection c) throws SQLException { return new CounterConsumer(c).drain(50); }

    static void fresh(Connection c, int items) throws SQLException {
        LikeSchema.reset(c);
        LikeSchema.addItems(c, items);
    }

    interface Job { void run() throws Exception; }

    static Thread start(String name, ConcurrentLinkedQueue<Throwable> errs, Job j) {
        Thread t = new Thread(() -> {
            try { j.run(); } catch (Throwable e) { errs.add(e); }
        }, name);
        t.start();
        return t;
    }

    static void joinAll(List<Thread> ts) throws InterruptedException { for (Thread t : ts) t.join(); }

    static void noErrors(ConcurrentLinkedQueue<Throwable> errs, String what) {
        for (Throwable e : errs) Check.note("thread error: " + e);
        Check.that(errs.isEmpty(), what + "：线程无异常");
    }

    static long q(Connection c, String sql, Object... a) throws SQLException { return Db.queryLong(c, sql, a); }

    static void auditOk(Connection c, String when) throws SQLException {
        Audit.WriteSide w = Audit.writeSide(c);
        Audit.ReadSide rd = Audit.readSide(c);
        Check.note(when + " write-side: " + w);
        Check.note(when + " read-side:  " + rd);
        Check.that(w.ok(), when + "：序号无空洞、版本数等于事件数、事件增量和等于事实数");
        Check.equal(0L, rd.lag(), when + "：滞后为 0");
        Check.equal(0L, rd.mismatchItems(), when + "：计数与事实数不一致的条目数");
    }

    // ---------------------------------------------------------------- 32-A 正常路径
    static void normal(Connection c) throws SQLException {
        Check.begin("32-A", "正常路径：点赞写事实与 Outbox，消费者应用后计数等于事实数，滞后归零");
        fresh(c, 3);
        LikeService s = new LikeService(c);
        Result r = s.like(user(1), item(1));
        Check.note("like(user-0001, item-lab-01) = " + r);
        Check.equal(Outcome.CHANGED, r.outcome(), "首次点赞 CHANGED");
        Check.equal(1L, r.version(), "事实版本为 1");
        Check.equal(1L, r.seq(), "分配全局序号 1");
        Check.equal(1L, q(c, "SELECT count(*) FROM like_outbox WHERE user_id = ? AND item_id = ? AND delta = 1", user(1), item(1)),
                "同事务写入 1 条 delta=+1 的 Outbox 事件");
        Audit.CountView before = Audit.readCount(c, item(1), 16);
        Check.note("before consume: " + before);
        Check.equal(1L, before.lag(), "消费前滞后 = 1");
        Check.equal(0L, before.n(), "消费前计数仍为 0");
        Stats st = drain(c);
        Check.note("consumer: " + st);
        Audit.CountView after = Audit.readCount(c, item(1), 16);
        Check.note("after consume: " + after);
        Check.equal(1L, after.n(), "消费后计数 = 1");
        auditOk(c, "32-A");
    }

    // ---------------------------------------------------------------- 32-B 边界
    static void boundaries(Connection c) throws SQLException {
        Check.begin("32-B", "边界：重复点赞与未赞取消为 NOOP；赞/取消/赞产生三条事件；不存在的条目被外键拒绝；写 Outbox 后中止则事实与事件都不存在");
        fresh(c, 3);
        LikeService s = new LikeService(c);
        s.like(user(1), item(1));
        Result dup = s.like(user(1), item(1));
        Check.note("repeat like = " + dup);
        Check.equal(Outcome.NOOP, dup.outcome(), "重复点赞 NOOP");
        Check.equal(1L, q(c, "SELECT count(*) FROM like_outbox"), "重复点赞不写新事件");
        Result un = s.unlike(user(2), item(1));
        Check.note("unlike never-liked = " + un);
        Check.equal(Outcome.NOOP, un.outcome(), "未赞过的取消 NOOP");
        Result t1 = s.like(user(3), item(2)), t2 = s.unlike(user(3), item(2)), t3 = s.like(user(3), item(2));
        Check.note("toggle: " + t1 + " " + t2 + " " + t3);
        Check.equal(3L, t3.version(), "赞/取消/赞后版本 = 3");
        List<Long> deltas = new ArrayList<>();
        for (Ev e : CounterConsumer.all(c)) if (e.user().equals(user(3))) deltas.add((long) e.delta());
        Check.equal(List.of(1L, -1L, 1L), deltas, "三条事件的增量依次为 +1,-1,+1");
        Result bad = s.like(user(1), "item-lab-99");
        Check.note("like nonexistent item = " + bad);
        Check.equal(Outcome.REJECTED, bad.outcome(), "不存在的条目 REJECTED");
        long lastBefore = q(c, "SELECT last FROM like_seq");
        String err = null;
        try {
            s.set(user(4), item(3), true, (p, cx) -> {
                if (p.equals("afterOutbox")) {
                    Check.note("inside tx: outbox rows visible to own tx = " + q(cx, "SELECT count(*) FROM like_outbox WHERE user_id = ?", user(4)));
                    throw new IllegalStateException("injected abort after outbox insert");
                }
            });
        } catch (IllegalStateException e) { err = e.getMessage(); }
        Check.note("aborted like: " + err);
        Check.that(err != null, "注入的中止传到调用方");
        Check.equal(0L, q(c, "SELECT count(*) FROM like_fact WHERE user_id = ? AND item_id = ?", user(4), item(3)), "中止后事实行不存在");
        Check.equal(0L, q(c, "SELECT count(*) FROM like_outbox WHERE user_id = ?", user(4)), "中止后 Outbox 事件不存在");
        Check.equal(lastBefore, q(c, "SELECT last FROM like_seq"), "中止后序号未前进");
        Result retry = s.like(user(4), item(3));
        Check.note("retry after abort = " + retry);
        Check.equal(lastBefore + 1, retry.seq(), "重试拿到紧接着的序号（无空洞）");
        drain(c);
        Check.equal(1L, q(c, "SELECT n FROM like_count WHERE item_id = ?", item(1)), "item-lab-01 计数 = 1");
        Check.equal(1L, q(c, "SELECT n FROM like_count WHERE item_id = ?", item(2)), "item-lab-02 计数 = 1");
        auditOk(c, "32-B");
    }

    // ---------------------------------------------------------------- 32-C 同一对并发
    static void concurrentSamePair(Connection c) throws Exception {
        Check.begin("32-C", "并发：16 线程同时点赞同一 (user, item) 只产生一条事件；8 线程交错赞/取消 320 次后，版本 = 事件数，增量和 = 当前状态");
        fresh(c, 2);
        int n = 16;
        CyclicBarrier bar = new CyclicBarrier(n);
        ConcurrentLinkedQueue<Throwable> errs = new ConcurrentLinkedQueue<>();
        ConcurrentLinkedQueue<Result> results = new ConcurrentLinkedQueue<>();
        List<Thread> ts = new ArrayList<>();
        for (int i = 0; i < n; i++) ts.add(start("dup-" + i, errs, () -> {
            try (Connection cx = Db.connect(db)) {
                LikeService s = new LikeService(cx);
                bar.await();
                results.add(s.like(user(42), item(2)));
            }
        }));
        joinAll(ts);
        noErrors(errs, "并发重复点赞");
        long changed = results.stream().filter(r -> r.outcome() == Outcome.CHANGED).count();
        long noop = results.stream().filter(r -> r.outcome() == Outcome.NOOP).count();
        Check.note("16 concurrent likes: CHANGED=" + changed + " NOOP=" + noop);
        Check.equal(1L, changed, "恰好 1 个 CHANGED");
        Check.equal(15L, noop, "其余 15 个 NOOP");
        Check.equal(1L, q(c, "SELECT count(*) FROM like_outbox WHERE user_id = ?", user(42)), "只有 1 条事件");

        int threads = 8, per = 40;
        CyclicBarrier bar2 = new CyclicBarrier(threads);
        AtomicInteger changedToggles = new AtomicInteger();
        ts.clear();
        for (int i = 0; i < threads; i++) {
            final long seed = SEED + i;
            ts.add(start("toggle-" + i, errs, () -> {
                Random r = new Random(seed);
                try (Connection cx = Db.connect(db)) {
                    LikeService s = new LikeService(cx);
                    bar2.await();
                    for (int k = 0; k < per; k++)
                        if (s.set(user(43), item(2), r.nextBoolean(), LikeService.NO_HOOK).outcome() == Outcome.CHANGED)
                            changedToggles.incrementAndGet();
                }
            }));
        }
        joinAll(ts);
        noErrors(errs, "交错赞/取消");
        long events = q(c, "SELECT count(*) FROM like_outbox WHERE user_id = ?", user(43));
        long version = q(c, "SELECT version FROM like_fact WHERE user_id = ? AND item_id = ?", user(43), item(2));
        long sum = q(c, "SELECT sum(delta) FROM like_outbox WHERE user_id = ?", user(43));
        long liked = q(c, "SELECT CASE WHEN liked THEN 1 ELSE 0 END FROM like_fact WHERE user_id = ? AND item_id = ?", user(43), item(2));
        Check.note("toggles: requests=" + threads * per + " CHANGED=" + changedToggles.get() + " events=" + events +
                   " version=" + version + " sum(delta)=" + sum + " liked=" + liked);
        Check.equal((long) changedToggles.get(), events, "CHANGED 次数 = 事件数");
        Check.equal(events, version, "事实版本 = 事件数");
        Check.equal(liked, sum, "事件增量和 = 当前是否已赞");
        drain(c);
        auditOk(c, "32-C");
    }

    // ---------------------------------------------------------------- 32-D 滞后的定义
    static void lagDefinition(Connection c) throws SQLException {
        Check.begin("32-D", "滞后：lag = like_seq.last − counter_watermark.applied_upto；允许滞后 16 条（教学设定），超出时读结果标 stale；误差不超过本条目未处理事件数");
        fresh(c, 2);
        LikeService s = new LikeService(c);
        for (int u = 1; u <= 30; u++) s.like(user(u), u % 3 == 0 ? item(2) : item(1));
        long allowed = 16;
        Audit.CountView v0 = Audit.readCount(c, item(1), allowed);
        Check.note("no consumer yet: item-lab-01 " + v0 + " truth=20");
        Check.equal(30L, v0.lag(), "未消费时 lag = 30");
        Check.that(v0.stale(), "lag 30 > 16，读结果标 stale");
        Check.that(Math.abs(v0.n() - 20) <= v0.pendingForItem(), "|n − 事实数| ≤ 本条目未处理事件数");
        Stats st = new CounterConsumer(c).apply(CounterConsumer.fetchAfter(c, 0, 20));
        Audit.CountView v1 = Audit.readCount(c, item(1), allowed);
        Audit.ReadSide rd = Audit.readSide(c);
        Check.note("after 20 events: " + st + " | item-lab-01 " + v1 + " | " + rd);
        Check.equal(10L, v1.lag(), "应用 20 条后 lag = 10");
        Check.that(!v1.stale(), "lag 10 ≤ 16，读结果不标 stale");
        Check.that(Math.abs(v1.n() - 20) <= v1.pendingForItem(), "|n − 事实数| ≤ 本条目未处理事件数");
        Check.equal(0L, rd.exactViolations(), "恒等式 n + 未处理增量 = 事实数 无违反");
        Check.that(rd.unprocessed() <= rd.lag(), "未处理事件数 ≤ lag");
        drain(c);
        Audit.CountView v2 = Audit.readCount(c, item(1), allowed);
        Check.note("drained: item-lab-01 " + v2);
        Check.equal(20L, v2.n(), "排空后 item-lab-01 = 20");
        auditOk(c, "32-D");
    }

    // ---------------------------------------------------------------- 32-E 重复与乱序投递
    static void shuffledDuplicates(Connection c) throws SQLException {
        Check.begin("32-E", "重复与乱序：每条事件投递 1–3 次并整体打乱，按 13 条一批应用；去重后计数等于事实数，重复投递全部被识别");
        fresh(c, 5);
        Random r = new Random(SEED);
        LikeService s = new LikeService(c);
        int changed = 0;
        for (Req q : workload(r, 600, 40, 5, 0.4)) if (s.set(user(q.user()), item(q.item()), q.want(), LikeService.NO_HOOK).outcome() == Outcome.CHANGED) changed++;
        List<Ev> evs = CounterConsumer.all(c);
        List<Ev> deliveries = new ArrayList<>();
        for (Ev e : evs) for (int k = 0, m = 1 + r.nextInt(3); k < m; k++) deliveries.add(e);
        Collections.shuffle(deliveries, r);
        Check.note("requests=600 changed=" + changed + " events=" + evs.size() + " deliveries=" + deliveries.size());
        CounterConsumer cc = new CounterConsumer(c);
        Stats total = new Stats();
        long maxExact = 0, maxBound = 0, badUnprocessed = 0, samples = 0;
        for (int i = 0, b = 0; i < deliveries.size(); i += 13, b++) {
            total.add(cc.apply(deliveries.subList(i, Math.min(i + 13, deliveries.size()))));
            if (b % 10 == 9) {
                Audit.ReadSide rd = Audit.readSide(c);
                samples++;
                maxExact = Math.max(maxExact, rd.exactViolations());
                maxBound = Math.max(maxBound, rd.boundViolations());
                if (rd.unprocessed() > rd.lag()) badUnprocessed++;
                if (b == 9) Check.note("after 10 batches: processed=" + q(c, "SELECT count(*) FROM processed_event") + " " + rd);
            }
        }
        Check.note("consumer total: " + total + " samples=" + samples);
        Check.equal(evs.size(), total.applied, "applied = 事件数");
        Check.equal(deliveries.size() - evs.size(), total.dup, "dup = 投递数 − 事件数");
        Check.equal(0L, maxExact, "中途采样：恒等式无违反");
        Check.equal(0L, maxBound, "中途采样：误差上界无违反");
        Check.equal(0L, badUnprocessed, "中途采样：未处理事件数 ≤ lag");
        auditOk(c, "32-E");
    }

    // ---------------------------------------------------------------- 32-F 负向对照 1：直接加一
    static void naiveIncrement(Connection c) throws Exception {
        Check.begin("32-F", "负向对照 1：8 线程发送 400 个赞/取消请求，35% 的请求被客户端重发；事实入口计数一致，请求路径直接加减的计数偏离事实");
        Random r = new Random(SEED + 6);
        List<Req> reqs = workload(r, 400, 30, 4, 0.5);
        boolean[] resend = new boolean[reqs.size()];
        int resends = 0;
        for (int i = 0; i < resend.length; i++) if (resend[i] = r.nextDouble() < 0.35) resends++;
        Check.note("requests=" + reqs.size() + " resent=" + resends + " sends=" + (reqs.size() + resends));
        for (boolean naive : new boolean[]{false, true}) {
            fresh(c, 4);
            ConcurrentLinkedQueue<Throwable> errs = new ConcurrentLinkedQueue<>();
            AtomicInteger noops = new AtomicInteger();
            List<Thread> ts = new ArrayList<>();
            CyclicBarrier bar = new CyclicBarrier(8);
            for (int t = 0; t < 8; t++) {
                final int tt = t;
                ts.add(start("client-" + t, errs, () -> {
                    try (Connection cx = Db.connect(db)) {
                        LikeService s = new LikeService(cx);
                        bar.await();
                        for (int i = tt; i < reqs.size(); i += 8) {
                            Req q = reqs.get(i);
                            for (int k = 0; k < (resend[i] ? 2 : 1); k++) {
                                if (naive) LikeService.setNaive(cx, user(q.user()), item(q.item()), q.want());
                                else if (s.set(user(q.user()), item(q.item()), q.want(), LikeService.NO_HOOK).outcome() == Outcome.NOOP)
                                    noops.incrementAndGet();
                            }
                        }
                    }
                }));
            }
            joinAll(ts);
            noErrors(errs, naive ? "直接加减" : "事实入口");
            if (!naive) {
                drain(c);
                Check.note("fact-based: NOOP=" + noops.get() + " events=" + q(c, "SELECT count(*) FROM like_outbox"));
                auditOk(c, "32-F fact-based");
            } else {
                long[] d = Audit.naiveDrift(c);
                Check.note("naive: items with drift=" + d[0] + " of 4, sum |naive − facts|=" + d[1]);
                for (int i = 1; i <= 4; i++)
                    Check.note("  " + item(i) + " naive=" + q(c, "SELECT coalesce((SELECT n FROM like_count_naive WHERE item_id = ?), 0)", item(i)) +
                               " facts=" + q(c, "SELECT count(*) FROM like_fact WHERE item_id = ? AND liked", item(i)));
                Check.exposes(d[0] > 0, "请求路径直接加减的计数与事实数不一致");
            }
        }
    }

    // ---------------------------------------------------------------- 32-G 负向对照 2：消费者不去重
    static Stats competingConsume(Connection c, boolean dedup, List<Long> redeliver) throws Exception {
        ConcurrentLinkedQueue<Throwable> errs = new ConcurrentLinkedQueue<>();
        ConcurrentLinkedQueue<Stats> parts = new ConcurrentLinkedQueue<>();
        List<Thread> ts = new ArrayList<>();
        CyclicBarrier bar = new CyclicBarrier(3);
        for (int t = 0; t < 3; t++) ts.add(start("consumer-" + t, errs, () -> {
            try (Connection cx = Db.connect(db)) {
                CounterConsumer cc = new CounterConsumer(cx).dedup(dedup);
                bar.await();
                while (true) {
                    // 三个消费者都从当前水位拉取，拉取发生在加锁之前，批次会互相重叠
                    List<Ev> b = CounterConsumer.fetchAfter(cx, CounterConsumer.watermark(cx), 25);
                    if (b.isEmpty()) break;
                    parts.add(cc.apply(b));
                }
            }
        }));
        joinAll(ts);
        noErrors(errs, dedup ? "去重消费者" : "不去重消费者");
        Stats total = new Stats();
        for (Stats s : parts) total.add(s);
        // 传输层重投：位点确认丢失后重发的一部分旧事件
        Stats re = new CounterConsumer(c).dedup(dedup).apply(CounterConsumer.fetchSeqs(c, redeliver));
        total.add(re);
        total.watermark = CounterConsumer.watermark(c);
        return total;
    }

    static void noDedupConsumer(Connection c) throws Exception {
        Check.begin("32-G", "负向对照 2：同一批 Outbox 事件由 3 个竞争消费者从水位拉取，再重投 10% 旧事件；去重消费者计数一致，不去重消费者计数偏离；随后批量重算把计数校准回事实");
        fresh(c, 4);
        Random r = new Random(SEED + 7);
        LikeService s = new LikeService(c);
        for (Req q : workload(r, 500, 30, 4, 0.5)) s.set(user(q.user()), item(q.item()), q.want(), LikeService.NO_HOOK);
        long events = q(c, "SELECT count(*) FROM like_outbox");
        List<Long> redeliver = new ArrayList<>();
        for (long seq = 1; seq <= events; seq++) if (r.nextDouble() < 0.10) redeliver.add(seq);
        Check.note("events=" + events + " redelivered=" + redeliver.size());
        Stats good = competingConsume(c, true, redeliver);
        Check.note("dedup consumers: " + good);
        Check.equal((int) events, good.applied, "去重：applied = 事件数");
        Check.that(good.dup >= redeliver.size(), "去重：重投的旧事件全部记为 dup（dup=" + good.dup + "）");
        auditOk(c, "32-G dedup");

        LikeSchema.resetDerived(c);
        Stats bad = competingConsume(c, false, redeliver);
        Audit.ReadSide rd = Audit.readSide(c);
        Check.note("no-dedup consumers: " + bad + " (applications=" + bad.applied + " for " + events + " events)");
        Check.note("no-dedup read-side: " + rd);
        for (int i = 1; i <= 4; i++)
            Check.note("  " + item(i) + " count=" + q(c, "SELECT n FROM like_count WHERE item_id = ?", item(i)) +
                       " facts=" + q(c, "SELECT count(*) FROM like_fact WHERE item_id = ? AND liked", item(i)));
        Check.exposes(rd.mismatchItems() > 0, "不去重的消费者在重投下使计数偏离事实");

        List<Rebuild.ItemResult> rb = Rebuild.rebuildAll(c, p -> {});
        Check.note("rebuild: " + rb);
        Audit.ReadSide after = Audit.readSide(c);
        Check.note("after rebuild: " + after);
        Check.equal(0L, after.mismatchItems(), "重算后计数与事实数一致");
        for (Req q : workload(r, 50, 30, 4, 0.5)) s.set(user(q.user()), item(q.item()), q.want(), LikeService.NO_HOOK);
        Stats tail = drain(c);
        Check.note("50 more requests, dedup drain: " + tail);
        auditOk(c, "32-G after rebuild");
    }

    // ---------------------------------------------------------------- 32-H 重算与在线增量（确定交错）
    static long n(Connection c, String item) throws SQLException {
        return q(c, "SELECT coalesce((SELECT n FROM like_count WHERE item_id = ?), 0)", item);
    }

    static void rebuildVsOnline(Connection c) throws SQLException {
        Check.begin("32-H", "重算与在线增量交错：快照 S=6 后又有事件 7、8，消费者先应用 1..3 与 7；按基线安装后 4..6 记为 COVERED，结果等于事实数；直接覆盖的重算重复计入 4..6 并丢失 7");
        for (boolean naive : new boolean[]{false, true}) {
            fresh(c, 1);
            LikeService s = new LikeService(c);
            CounterConsumer cc = new CounterConsumer(c);
            String it = item(1);
            for (int u = 1; u <= 6; u++) s.like(user(u), it);
            cc.apply(CounterConsumer.fetchSeqs(c, List.of(1L, 2L, 3L)));
            long n1 = n(c, it);
            Rebuild.Snapshot snap = Rebuild.snapshot(c);
            s.like(user(7), it);
            s.like(user(8), it);
            cc.apply(CounterConsumer.fetchSeqs(c, List.of(7L)));
            long n2 = n(c, it);
            Rebuild.ItemResult ir = naive ? Rebuild.installNaive(c, snap, it) : Rebuild.install(c, snap, it);
            Stats rest = cc.apply(CounterConsumer.fetchSeqs(c, List.of(4L, 5L, 6L, 8L)));
            long n3 = n(c, it);
            long truth = q(c, "SELECT count(*) FROM like_fact WHERE item_id = ? AND liked", it);
            String tag = naive ? "naive overwrite" : "base_seq install";
            Check.note(tag + ": applied{1,2,3} n=" + n1 + "; snapshot S=" + snap.seq() + " C(S)=" + snap.counts().get(it) +
                       "; +events 7,8, applied{7} n=" + n2 + "; " + ir + "; applied{4,5,6,8} " + rest + " n=" + n3 + " truth=" + truth);
            if (!naive) {
                Check.equal(7L, ir.newN(), "安装值 = C(S) + 已应用的序号 > S 的增量 = 6 + 1");
                Check.equal(3, rest.covered, "4..6 记为 COVERED");
                Check.equal(1, rest.applied, "8 正常应用");
                Check.equal(truth, n3, "最终计数 = 事实数");
                Stats again = cc.apply(CounterConsumer.fetchSeqs(c, List.of(1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L)));
                Check.note("redeliver 1..8: " + again + " n=" + n(c, it));
                Check.equal(8, again.dup, "全部重投记为 dup");
                auditOk(c, "32-H");
            } else {
                Check.note("naive: double-counted {4,5,6}=+3, lost {7}=-1, error=" + (n3 - truth));
                Check.exposes(n3 != truth, "直接覆盖的重算与在线增量交错后计数偏离事实");
            }
        }
    }

    // ---------------------------------------------------------------- 32-I 重算等待消费者的行锁
    static void rebuildLockWait(Connection c) throws Exception {
        Check.begin("32-I", "重算与消费者争同一计数行：消费者事务持有 item-lab-01 计数行锁时，重算安装在 pg_locks 中等待；放行后安装读到已提交的事件 5");
        fresh(c, 1);
        LikeService s = new LikeService(c);
        String it = item(1);
        for (int u = 1; u <= 4; u++) s.like(user(u), it);
        Rebuild.Snapshot snap = Rebuild.snapshot(c);
        s.like(user(5), it);
        CountDownLatch paused = new CountDownLatch(1), release = new CountDownLatch(1);
        ConcurrentLinkedQueue<Throwable> errs = new ConcurrentLinkedQueue<>();
        AtomicLong rebuildPid = new AtomicLong();
        Rebuild.ItemResult[] res = new Rebuild.ItemResult[1];
        Thread consumer = start("consumer", errs, () -> {
            try (Connection cx = Db.connect(db)) {
                new CounterConsumer(cx).hook((p, x) -> {
                    paused.countDown();
                    try { release.await(); } catch (InterruptedException e) { throw new SQLException(e); }
                }).apply(CounterConsumer.fetchSeqs(cx, List.of(5L)));
            }
        });
        Check.that(paused.await(10, TimeUnit.SECONDS), "消费者停在提交前");
        Thread rebuild = start("rebuild", errs, () -> {
            try (Connection cx = Db.connect(db)) {
                rebuildPid.set(q(cx, "SELECT pg_backend_pid()"));
                res[0] = Rebuild.install(cx, snap, it);
            }
        });
        long waiting = 0;
        for (int i = 0; i < 200 && waiting == 0; i++) {
            Thread.sleep(20);
            if (rebuildPid.get() != 0)
                waiting = q(c, "SELECT count(*) FROM pg_locks WHERE pid = ? AND NOT granted", (int) rebuildPid.get());
        }
        Check.note("snapshot S=" + snap.seq() + " C(S)=" + snap.counts().get(it) + "; consumer paused before commit holding row lock; rebuild waiting locks=" + waiting);
        Check.that(waiting > 0, "重算安装在计数行锁上等待（pg_locks granted=false）");
        release.countDown();
        consumer.join();
        rebuild.join();
        noErrors(errs, "消费者与重算");
        Check.note("install: " + res[0]);
        Check.equal(1L, res[0].appliedAfter(), "安装读到了锁释放后已提交的事件 5");
        Check.equal(5L, res[0].newN(), "安装值 = 4 + 1");
        Stats st = drain(c);
        Check.note("drain events 1..4: " + st);
        Check.equal(4, st.covered, "1..4 记为 COVERED");
        auditOk(c, "32-I");
    }

    // ---------------------------------------------------------------- 32-J 主验收：全部并发
    static void concurrentMix(Connection c) throws Exception {
        Check.begin("32-J", "并发混合：8 个写线程各 300 个请求（热点条目占 50%），3 个竞争消费者、1 个重投线程、1 个周期重算线程同时运行；采样恒等式始终成立，排空后计数等于事实数");
        fresh(c, 6);
        ConcurrentLinkedQueue<Throwable> errs = new ConcurrentLinkedQueue<>();
        AtomicBoolean writersDone = new AtomicBoolean();
        AtomicInteger changed = new AtomicInteger(), rebuilds = new AtomicInteger(), samples = new AtomicInteger();
        AtomicLong maxLag = new AtomicLong(), maxErr = new AtomicLong(), exactBad = new AtomicLong(), boundBad = new AtomicLong(),
                unprocBad = new AtomicLong(), redelivered = new AtomicLong();
        ConcurrentLinkedQueue<Stats> parts = new ConcurrentLinkedQueue<>();
        List<Thread> writers = new ArrayList<>(), others = new ArrayList<>();
        for (int t = 0; t < 8; t++) {
            final long seed = SEED + 100 + t;
            writers.add(start("writer-" + t, errs, () -> {
                Random r = new Random(seed);
                try (Connection cx = Db.connect(db)) {
                    LikeService s = new LikeService(cx);
                    for (Req q : workload(r, 300, 60, 6, 0.5))
                        if (s.set(user(q.user()), item(q.item()), q.want(), LikeService.NO_HOOK).outcome() == Outcome.CHANGED) changed.incrementAndGet();
                }
            }));
        }
        for (int t = 0; t < 3; t++) others.add(start("consumer-" + t, errs, () -> {
            try (Connection cx = Db.connect(db)) {
                CounterConsumer cc = new CounterConsumer(cx);
                while (true) {
                    List<Ev> b = CounterConsumer.fetchAfter(cx, CounterConsumer.watermark(cx), 20);
                    if (b.isEmpty()) {
                        if (writersDone.get() && CounterConsumer.lag(cx) == 0) break;
                        Thread.sleep(5);
                        continue;
                    }
                    parts.add(cc.apply(b));
                }
            }
        }));
        others.add(start("redeliver", errs, () -> {
            Random r = new Random(SEED + 200);
            try (Connection cx = Db.connect(db)) {
                CounterConsumer cc = new CounterConsumer(cx);
                while (!writersDone.get()) {
                    long last = q(cx, "SELECT last FROM like_seq");
                    if (last > 0) {
                        Set<Long> pick = new TreeSet<>();
                        for (int k = 0; k < 10; k++) pick.add(1 + (long) r.nextInt((int) last));
                        parts.add(cc.apply(CounterConsumer.fetchSeqs(cx, pick)));
                        redelivered.addAndGet(pick.size());
                    }
                    Thread.sleep(5);
                }
            }
        }));
        others.add(start("rebuild", errs, () -> {
            try (Connection cx = Db.connect(db)) {
                while (!writersDone.get()) {
                    Rebuild.rebuildAll(cx, p -> {});
                    rebuilds.incrementAndGet();
                    Thread.sleep(100);
                }
            }
        }));
        others.add(start("sampler", errs, () -> {
            try (Connection cx = Db.connect(db)) {
                while (!writersDone.get()) {
                    Audit.ReadSide rd = Audit.readSide(cx);
                    samples.incrementAndGet();
                    maxLag.accumulateAndGet(rd.lag(), Math::max);
                    maxErr.accumulateAndGet(rd.maxErr(), Math::max);
                    exactBad.addAndGet(rd.exactViolations());
                    boundBad.addAndGet(rd.boundViolations());
                    if (rd.unprocessed() > rd.lag()) unprocBad.incrementAndGet();
                    Thread.sleep(10);
                }
            }
        }));
        joinAll(writers);
        writersDone.set(true);
        joinAll(others);
        noErrors(errs, "并发混合");
        Stats total = new Stats();
        for (Stats s : parts) total.add(s);
        long events = q(c, "SELECT count(*) FROM like_outbox");
        long coveredRows = q(c, "SELECT count(*) FROM processed_event WHERE how = 'COVERED'");
        Check.note("requests=2400 CHANGED=" + changed.get() + " events=" + events + " rebuild rounds=" + rebuilds.get() +
                   " redelivered=" + redelivered.get());
        Check.note("consumers+redeliver: " + total + " covered rows=" + coveredRows);
        Check.note("sampler (values vary by run): samples=" + samples.get() + " max lag=" + maxLag.get() + " max |n-truth|=" + maxErr.get());
        Check.equal((long) changed.get(), events, "CHANGED 次数 = 事件数");
        Check.equal(events, (long) (total.applied + total.covered), "每条事件恰好一次 APPLIED 或 COVERED");
        Check.that(samples.get() > 0 && rebuilds.get() > 0, "采样与重算都实际运行过");
        Check.equal(0L, exactBad.get(), "采样：恒等式 n + 未处理增量 = 事实数 无违反");
        Check.equal(0L, boundBad.get(), "采样：|n − 事实数| ≤ 本条目未处理事件数 无违反");
        Check.equal(0L, unprocBad.get(), "采样：未处理事件数 ≤ lag 无违反");
        auditOk(c, "32-J");
    }

    // ---------------------------------------------------------------- 32-K 消费者进程 kill -9
    static Process spawn(String mode, Path offset, BlockingQueue<String> lines, String tag) throws Exception {
        String java = ProcessHandle.current().info().command().orElse("java");
        ProcessBuilder pb = new ProcessBuilder(java, "-cp", System.getProperty("java.class.path"),
                "social.like.ConsumerProc", db, mode, offset.toString(), "25");
        pb.redirectErrorStream(true);
        Process p = pb.start();
        Thread rd = new Thread(() -> {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                String l;
                while ((l = br.readLine()) != null) lines.add(tag + "| " + l);
            } catch (Exception ignored) { }
        });
        rd.setDaemon(true);
        rd.start();
        return p;
    }

    static String await(BlockingQueue<String> lines, String marker) throws InterruptedException {
        long end = System.currentTimeMillis() + 60_000;
        while (System.currentTimeMillis() < end) {
            String l = lines.poll(1, TimeUnit.SECONDS);
            if (l == null) continue;
            Check.note(l.replaceAll("pid=\\d+", "pid=<child>"));
            if (l.contains(marker)) return l;
        }
        return null;
    }

    static int kill9(Process p) throws Exception {
        new ProcessBuilder("kill", "-9", Long.toString(p.pid())).inheritIO().start().waitFor();
        return p.waitFor();
    }

    static long waitBackendGone(Connection c) throws Exception {
        long n = -1;
        for (int i = 0; i < 200; i++) {
            n = q(c, "SELECT count(*) FROM pg_stat_activity WHERE application_name = 'like-consumer'");
            if (n == 0) return 0;
            Thread.sleep(50);
        }
        return n;
    }

    static void consumerKill(Connection c) throws Exception {
        Check.begin("32-K", "恢复（多进程）：独立 JVM 消费者在事务内被 kill -9，未提交的批次全部回滚；再在提交后、保存位点前被 kill -9，重启后重投整批并被去重");
        fresh(c, 3);
        LikeService s = new LikeService(c);
        for (int u = 1; u <= 40; u++) for (int i = 1; i <= 3; i++) s.like(user(u), item(i));
        long events = q(c, "SELECT count(*) FROM like_outbox");
        Path offset = Files.createTempDirectory("ch32-").resolve("offset");
        Check.note("events=" + events + " batch=25 offsetFile=<tmp>/offset");
        BlockingQueue<String> lines = new LinkedBlockingQueue<>();

        Process p1 = spawn("die-in-tx", offset, lines, "child1");
        Check.that(await(lines, "PAUSED_IN_TX") != null, "子进程 1 停在第 2 批事务内");
        long locked = q(c, "SELECT count(*) FROM pg_stat_activity WHERE application_name = 'like-consumer' AND state = 'idle in transaction'");
        Check.note("child1 backend state idle in transaction = " + locked);
        int ec1 = kill9(p1);
        long left1 = waitBackendGone(c);
        Check.note("kill -9 child1 exit=" + ec1 + " backendStillListed=" + left1 + " watermark=" + CounterConsumer.watermark(c) +
                   " processed=" + q(c, "SELECT count(*) FROM processed_event") + " offsetFile=" + Files.readString(offset).trim());
        Check.equal(137, ec1, "子进程 1 被 SIGKILL（退出码 137）");
        Check.equal(0L, left1, "服务端会话随客户端消失而结束");
        Check.equal(25L, CounterConsumer.watermark(c), "第 2 批未提交：水位停在 25");
        Check.equal(25L, q(c, "SELECT count(*) FROM processed_event"), "第 2 批的 processed_event 全部回滚");
        Check.equal(0L, Audit.readSide(c).exactViolations(), "kill 后恒等式成立");

        Process p2 = spawn("die-after-commit", offset, lines, "child2");
        Check.that(await(lines, "COMMITTED_OFFSET_NOT_SAVED") != null, "子进程 2 提交第 2 批后停在保存位点之前");
        int ec2 = kill9(p2);
        waitBackendGone(c);
        long wm2 = CounterConsumer.watermark(c);
        String off2 = Files.readString(offset).trim();
        Check.note("kill -9 child2 exit=" + ec2 + " watermark=" + wm2 + " offsetFile=" + off2);
        Check.equal(75L, wm2, "数据库已提交到 75");
        Check.equal("50", off2, "本地位点仍是 50（提交与保存位点之间被杀）");

        Process p3 = spawn("run", offset, lines, "child3");
        String done = await(lines, "DONE");
        int ec3 = p3.waitFor();
        Check.note("child3 exit=" + ec3);
        Check.equal(0, ec3, "子进程 3 正常结束");
        Check.that(done != null && done.contains("dup=25"), "重启后重投的 51..75 共 25 条全部记为 dup");
        auditOk(c, "32-K");
    }

    // ---------------------------------------------------------------- 32-L 数据库 immediate 停机
    static void dbCrash() throws Exception {
        Check.begin("32-L", "恢复（数据库崩溃）：写线程与消费者运行中执行 pg.sh restart-immediate；重启后事实与 Outbox 同进同退，已确认的事件都在，计数可排空到与事实一致");
        String common = System.getenv("LAB_COMMON"), name = System.getenv("PG_NAME"), port = System.getenv("LAB_PGPORT");
        if (common == null || name == null || port == null) {
            Check.note("NOT_RUN: LAB_COMMON/PG_NAME/LAB_PGPORT not set");
            Check.that(false, "32-L 需要 run.sh 提供 LAB_COMMON 与 PG_NAME");
            return;
        }
        try (Connection c = Db.connect(db)) { fresh(c, 4); }
        ConcurrentLinkedQueue<Throwable> errs = new ConcurrentLinkedQueue<>();
        ConcurrentLinkedQueue<Result> acked = new ConcurrentLinkedQueue<>();
        ConcurrentLinkedQueue<String> failStates = new ConcurrentLinkedQueue<>();
        AtomicBoolean stop = new AtomicBoolean();
        List<Thread> ts = new ArrayList<>();
        for (int t = 0; t < 6; t++) {
            final long seed = SEED + 300 + t;
            ts.add(start("writer-" + t, errs, () -> {
                Random r = new Random(seed);
                try (Connection cx = Db.connect(db)) {
                    LikeService s = new LikeService(cx);
                    while (!stop.get()) {
                        Req q = workload(r, 1, 40, 4, 0.5).get(0);
                        Result res = s.set(user(q.user()), item(q.item()), q.want(), LikeService.NO_HOOK);
                        if (res.outcome() == Outcome.CHANGED) acked.add(res);
                    }
                } catch (SQLException e) {
                    failStates.add(e.getSQLState());
                }
            }));
        }
        ts.add(start("consumer", errs, () -> {
            try (Connection cx = Db.connect(db)) {
                CounterConsumer cc = new CounterConsumer(cx);
                while (!stop.get()) {
                    List<Ev> b = CounterConsumer.fetchAfter(cx, CounterConsumer.watermark(cx), 20);
                    if (b.isEmpty()) { Thread.sleep(5); continue; }
                    cc.apply(b);
                }
            } catch (SQLException e) {
                failStates.add("consumer:" + e.getSQLState());
            }
        }));
        long deadline = System.currentTimeMillis() + 60_000;
        while (acked.size() < 300 && System.currentTimeMillis() < deadline) Thread.sleep(10);
        Check.that(acked.size() >= 300, "崩溃前已确认至少 300 个 CHANGED");
        Process pr = new ProcessBuilder(Path.of(common, "pg.sh").toString(), "restart-immediate", name, port).redirectErrorStream(true).start();
        String out = new String(pr.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
        int rc = pr.waitFor();
        stop.set(true);
        joinAll(ts);
        noErrors(errs, "崩溃期间的线程（SQLException 已单独记录）");
        Check.note("pg.sh restart-immediate rc=" + rc + " output=" + out);
        Check.equal(0, rc, "restart-immediate 成功");
        Set<String> states = new TreeSet<>(failStates);
        Check.note("acked CHANGED before crash=" + acked.size() + "; threads ended by SQLException=" + failStates.size() + " states=" + states);
        Check.equal(7, failStates.size(), "6 个写线程和 1 个消费者都因连接中断结束");
        try (Connection c = Db.connect(db)) {
            Audit.WriteSide w = Audit.writeSide(c);
            Audit.ReadSide rd = Audit.readSide(c);
            Check.note("after recovery write-side: " + w);
            Check.note("after recovery read-side:  " + rd);
            Check.that(w.ok(), "恢复后：序号无空洞、版本数等于事件数、事件增量和等于事实数");
            long missing = 0;
            for (Result r : acked)
                if (q(c, "SELECT count(*) FROM like_outbox WHERE seq = ? AND version = ?", r.seq(), r.version()) != 1) missing++;
            Check.equal(0L, missing, "已向调用方确认的事件在恢复后全部存在");
            Check.that(w.events() >= acked.size(), "恢复后事件数 ≥ 已确认数（差值是提交成功但确认未送达的请求）");
            Check.equal(0L, rd.exactViolations(), "恢复后恒等式 n + 未处理增量 = 事实数 成立");
            Stats st = drain(c);
            Check.note("drain after recovery: " + st);
            auditOk(c, "32-L");
        }
    }
}
