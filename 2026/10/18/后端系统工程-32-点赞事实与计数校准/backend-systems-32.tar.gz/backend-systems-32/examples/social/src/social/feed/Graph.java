package social.feed;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import lab.common.Db;

/**
 * 固定种子的合成关注图与帖子序列（教学假设，不对应任何真实产品）。
 * 每个用户关注 [minDeg, maxDeg] 个账号；被关注者按“人气名次”的 Zipf 权重 1/(rank+1)^s 无放回抽取，
 * 因此粉丝数呈重尾分布。帖子作者均匀抽取，created_at 每 3 条共用一个值，post_id 与时间顺序无关。
 */
public final class Graph {
    public record PostSpec(long postId, String author, long createdAt, String visibility) {}

    public final List<String> users = new ArrayList<>();
    public final Map<String, Set<String>> followees = new HashMap<>();
    public final Map<String, Integer> followers = new HashMap<>();
    public final List<PostSpec> posts = new ArrayList<>();

    public static String u(int i) { return String.format("user-%04d", i); }

    public static Graph generate(long seed, int n, int minDeg, int maxDeg, double s, int nPosts) {
        Random rnd = new Random(seed);
        Graph g = new Graph();
        for (int i = 1; i <= n; i++) { g.users.add(u(i)); g.followers.put(u(i), 0); }
        List<String> byRank = new ArrayList<>(g.users);
        Collections.shuffle(byRank, rnd);
        double[] cum = new double[n];
        double acc = 0;
        for (int r = 0; r < n; r++) { acc += 1.0 / Math.pow(r + 1, s); cum[r] = acc; }
        for (String f : g.users) {
            int d = minDeg + rnd.nextInt(maxDeg - minDeg + 1);
            Set<String> out = new LinkedHashSet<>();
            while (out.size() < d) {
                double x = rnd.nextDouble() * acc;
                int lo = 0, hi = n - 1;
                while (lo < hi) { int mid = (lo + hi) >>> 1; if (cum[mid] < x) lo = mid + 1; else hi = mid; }
                String t = byRank.get(lo);
                if (!t.equals(f)) out.add(t);
            }
            g.followees.put(f, out);
            for (String t : out) g.followers.merge(t, 1, Integer::sum);
        }
        List<Long> ids = new ArrayList<>();
        for (long i = 0; i < nPosts; i++) ids.add(100_000 + i);
        Collections.shuffle(ids, rnd);
        for (int i = 0; i < nPosts; i++) {
            String author = g.users.get(rnd.nextInt(n));
            int v = rnd.nextInt(100);
            String vis = v < 85 ? "PUBLIC" : v < 97 ? "FOLLOWERS" : "SELF";
            g.posts.add(new PostSpec(ids.get(i), author, 1_000_000L + i / 3, vis));
        }
        return g;
    }

    /** 批量写入 relation（ACTIVE, version 1）与 follower_count 快照。不经过 RelationService，不写事件。 */
    public void load(Connection c) throws SQLException {
        c.setAutoCommit(false);
        try (PreparedStatement ps = c.prepareStatement(
                "INSERT INTO relation (follower, followee, state, version) VALUES (?, ?, 'ACTIVE', 1)")) {
            for (var e : followees.entrySet()) {
                for (String t : e.getValue()) { ps.setString(1, e.getKey()); ps.setString(2, t); ps.addBatch(); }
            }
            ps.executeBatch();
        }
        c.commit();
        c.setAutoCommit(true);
        Db.exec(c, "INSERT INTO follower_count (author, followers) " +
                "SELECT a.u, count(r.follower) FROM (SELECT DISTINCT followee AS u FROM relation UNION SELECT DISTINCT follower FROM relation) a " +
                "LEFT JOIN relation r ON r.followee = a.u AND r.state = 'ACTIVE' GROUP BY a.u");
    }

    public long edges() { return followees.values().stream().mapToLong(Set::size).sum(); }

    /** 不依赖数据库的期望 Feed：当前关注者的非 SELF 帖子，按 (created_at, post_id) 降序。 */
    public List<Feed.Item> expectedFeed(String reader, int limit) {
        Set<String> fs = followees.get(reader);
        List<Feed.Item> all = new ArrayList<>();
        for (PostSpec p : posts)
            if (fs.contains(p.author()) && !p.visibility().equals("SELF"))
                all.add(new Feed.Item(p.createdAt(), p.postId(), p.author()));
        all.sort(Feed.NEWEST_FIRST);
        return all.subList(0, Math.min(limit, all.size()));
    }

    /** 不依赖数据库的期望写入行数：每帖 1 行帖子，走推送的帖子再加该作者的粉丝数。 */
    public long expectedWriteRows(long threshold) {
        long rows = 0;
        for (PostSpec p : posts) {
            rows++;
            int f = followers.get(p.author());
            if (f < threshold) rows += f;
        }
        return rows;
    }
}
