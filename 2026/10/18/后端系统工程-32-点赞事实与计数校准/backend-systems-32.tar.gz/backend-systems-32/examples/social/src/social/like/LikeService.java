package social.like;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import lab.common.Db;
import social.common.Tx;

/**
 * 点赞写入口。一个事务内：确保事实行存在并加行锁 → 比较旧状态 → 改状态、版本加一 →
 * 分配全局序号 → 写 Outbox。锁顺序固定为 事实行 → like_seq。
 */
public final class LikeService {
    public enum Outcome { CHANGED, NOOP, REJECTED }

    public record Result(Outcome outcome, boolean liked, long version, long seq, String reason) {
        public String toString() {
            return outcome + "(" + (liked ? "liked" : "unliked") + ",v" + version + (seq > 0 ? ",seq" + seq : "") +
                   (reason == null ? "" : "," + reason) + ")";
        }
    }

    /** 测试插桩点。 */
    public interface Hook { void at(String point, Connection c) throws SQLException; }
    public static final Hook NO_HOOK = (p, c) -> {};

    private final Connection c;
    public LikeService(Connection c) { this.c = c; }

    public Result like(String user, String item) throws SQLException { return set(user, item, true, NO_HOOK); }
    public Result unlike(String user, String item) throws SQLException { return set(user, item, false, NO_HOOK); }

    public Result set(String user, String item, boolean want, Hook hook) throws SQLException {
        try {
            return Tx.rc(c, cx -> {
                Db.update(cx, "INSERT INTO like_fact(user_id, item_id, liked, version) VALUES (?, ?, false, 0) " +
                              "ON CONFLICT DO NOTHING", user, item);
                boolean liked; long ver;
                try (PreparedStatement ps = cx.prepareStatement(
                        "SELECT liked, version FROM like_fact WHERE user_id = ? AND item_id = ? FOR UPDATE")) {
                    ps.setString(1, user); ps.setString(2, item);
                    try (ResultSet rs = ps.executeQuery()) { rs.next(); liked = rs.getBoolean(1); ver = rs.getLong(2); }
                }
                hook.at("afterLock", cx);
                if (liked == want) return new Result(Outcome.NOOP, liked, ver, 0, want ? "already liked" : "not liked");
                long v = ver + 1;
                Db.update(cx, "UPDATE like_fact SET liked = ?, version = ? WHERE user_id = ? AND item_id = ?", want, v, user, item);
                long seq = Db.queryLong(cx, "UPDATE like_seq SET last = last + 1 WHERE id = 1 RETURNING last");
                Db.update(cx, "INSERT INTO like_outbox(seq, user_id, item_id, delta, version) VALUES (?, ?, ?, ?, ?)",
                        seq, user, item, want ? 1 : -1, v);
                hook.at("afterOutbox", cx);
                return new Result(Outcome.CHANGED, want, v, seq, null);
            });
        } catch (SQLException e) {
            if ("23503".equals(e.getSQLState())) return new Result(Outcome.REJECTED, false, 0, 0, "no such item (23503)");
            throw e;
        }
    }

    /** 负向对照：每次请求直接按请求方向加减计数，不读旧状态，也不写 Outbox。 */
    public static void setNaive(Connection c, String user, String item, boolean want) throws SQLException {
        Tx.rc(c, cx -> {
            Db.update(cx, "INSERT INTO like_fact(user_id, item_id, liked, version) VALUES (?, ?, ?, 1) " +
                          "ON CONFLICT (user_id, item_id) DO UPDATE SET liked = EXCLUDED.liked, version = like_fact.version + 1",
                    user, item, want);
            Db.update(cx, "INSERT INTO like_count_naive(item_id, n) VALUES (?, ?) " +
                          "ON CONFLICT (item_id) DO UPDATE SET n = like_count_naive.n + EXCLUDED.n", item, want ? 1 : -1);
            return null;
        });
    }
}
