# social：第 30–32 章共用项目

三章共用一个源码树和一个 `run.sh`。`lab.sh` 每次编译 `examples/common/src` 与本目录 `src` 下的全部 Java 文件，所以任何一章的编译错误都会让三章一起失败；改动后三章都要回归。

## 运行入口

```bash
cd batch-3/examples/social
LAB_BUILD=/tmp/batch3-build-30 ./run.sh 30   # 第 30 章
LAB_BUILD=/tmp/batch3-build-31 ./run.sh 31   # 第 31 章
LAB_BUILD=/tmp/batch3-build-32 ./run.sh 32   # 第 32 章
./run.sh all                                  # 依次运行三章
```

| 章 | 主类 | 端口 | 集群 | 库 | 证据 |
|---|---|---|---|---|---|
| 30 关注关系与可撤销订阅 | `social.rel.Ch30Main` | 55430 | b3-30 | social30 | `../../evidence/30/` |
| 31 Feed 的扇出成本与热点 | `social.feed.Ch31Main` | 55431 | b3-31 | social31 | `../../evidence/31/` |
| 32 点赞事实与计数校准 | `social.like.Ch32Main` | 55432 | b3-32 | social32 | `../../evidence/32/` |

每章流程：必要时 initdb（`dynamic_shared_memory_type=mmap`）→ `pg.sh start` → 主类重建本章库并运行全部用例 → 标准输出写入 `evidence/NN/output.txt`，环境写入 `env.txt`，命令与退出码写入 `commands.txt` → `pg.sh stop`。退出码非零即 FAIL。

- `LAB_BUILD` 决定编译目录（`$LAB_BUILD/social`）。多个代理或多次复跑同时进行时，每次用不同目录，避免互相覆盖 class 文件。
- 约定端口如果已被本机其他集群占用（`pg_ctl status` 显示本章集群未运行，但端口可连接），`run.sh` 改用 `555NN`，并在 `env.txt` 的 `cluster:` 行写明原因。
- 主类从环境变量读取 `LAB_PGPORT`、`LAB_DB`、`EVIDENCE_DIR`；第 32 章的 32-L 还读取 `LAB_COMMON`（`examples/common` 路径）与 `PG_NAME`（集群名），用来调用 `pg.sh restart-immediate`。30、31 不读这两个变量。
- 运行会重写对应章节的 `evidence/NN/output.txt`、`env.txt`、`commands.txt`。只想回归、不想替换已引用的证据时，先备份 `evidence/NN`，跑完再恢复，并用 `diff -r` 确认。

## 包结构

```text
src/social/
  common/Tx.java            事务执行器：隔离级别、40001/40P01 整体重试；回滚与恢复 autocommit 的
                            次生异常只作为 suppressed 附在原始异常上，调用方看到的是第一个异常
  rel/                      第 30 章
    RelSchema.java          关系真相源 relation/block、事件表、粉丝投影表、post
    RelationService.java    关注、取消、审批、拉黑、解除拉黑、发帖（acl_token）
    Projector.java          关系事件消费者：版本比较、proj_seen 去重、连续水位
    AccessCheck.java        内容访问检查（真相源 / 投影 / 令牌三种口径）
    Ch30Main.java           30-A 起全部用例
  feed/                     第 31 章（复用 rel 的真相源与 RelationService）
    Graph.java              固定种子的合成关注图
    Feed.java               推、拉、混合三种方案与键集分页
    Ch31Main.java           31-A 至 31-J
  like/                     第 32 章（不依赖 rel、feed）
    LikeSchema.java         item、like_fact、like_seq、like_outbox、like_count、processed_event、counter_watermark
    LikeService.java        点赞/取消：事实行加锁、状态比较、版本加一、同事务写 Outbox；负向对照 setNaive
    CounterConsumer.java    计数消费者：processed_event 去重、base_seq 判断 COVERED、连续水位、lag
    Rebuild.java            批量重算：快照读 S 与事实数，按 base_seq 安装；负向对照 installNaive
    Audit.java              对账与读侧恒等式（单条 SQL，同一快照）
    ConsumerProc.java       独立 JVM 消费者，供 32-K kill -9
    Ch32Main.java           32-A 至 32-L
```

`Tx` 的异常处理在第 32 章时修改过：之前 `finally` 里恢复 autocommit 失败会抛出 08003，盖住提交阶段的原始错误。修改后 31-J 在回归运行中看到的是 `57P01 FATAL: terminating connection due to administrator command`；`evidence/31/` 已在修改后重跑，记录的也是 57P01。
