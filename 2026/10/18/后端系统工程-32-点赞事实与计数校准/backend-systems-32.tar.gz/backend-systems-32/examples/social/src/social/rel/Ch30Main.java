package social.rel;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.TimeUnit;
import lab.common.Check;
import lab.common.Db;
import social.common.Tx;
import social.rel.RelationService.Outcome;
import social.rel.RelationService.Result;

/** 第 30 篇：关注关系与可撤销订阅。全部用例使用真实 PostgreSQL 事务。 */
public final class Ch30Main {
    static final long SEED = 30_2026L;

    public static void main(String[] args) throws Exception {
        String db = System.getenv().getOrDefault("LAB_DB", "social30");
        Db.recreate(db);
        try (Connection c = Db.connect(db)) {
            RelSchema.create(c);
            System.out.println("chapter 30 relation lab, seed=" + SEED + ", db=" + db);
            normalPublic(c);
            privateApproval(c);
            boundaries(c);
            concurrentDuplicateFollow(db);
            concurrentInterleave(db, c);
            singlePairReorder(c);
            shuffledDelivery(db, c);
            blockFollowInterleave(db, c, false);
            blockFollowInterleave(db, c, true);
            blockFollowStress(db, c);
            newEnemy(c);
            replayRecovery(db, c);
            visibilityBoundaries(c);
        }
        System.out.println("tx retries observed (40001/40P01): " + Tx.retries);
        System.exit(Check.finish());
    }

    static String u(int i) { return String.format("user-%04d", i); }

    static long count(Connection c, String sql, Object... a) throws SQLException { return Db.queryLong(c, sql, a); }

    static void drain(Connection c) throws SQLException {
        Projector p = new Projector(c);
        long wm = Projector.watermark(c);
        for (Projector.Event e : Projector.loadEvents(c)) if (e.seq() > wm) p.apply(e);
    }

    // ---------------------------------------------------------------- 正常路径
    static void normalPublic(Connection c) throws SQLException {
        Check.begin("30-A", "公开账号：关注生效、写事件、投影消费后粉丝列表与计数一致");
        RelationService rs = new RelationService(c);
        Result r = rs.follow(u(1), u(2));
        Check.note("follow(user-0001 -> user-0002) = " + r);
        Check.equal("ACTIVE", r.state(), "公开账号直接 ACTIVE");
        Check.equal(1L, r.version(), "首个有效版本为 1");
        Check.equal(1L, count(c, "SELECT count(*) FROM relation_event WHERE follower=? AND followee=?", u(1), u(2)), "写入 1 条事件");
        drain(c);
        Check.equal(1L, count(c, "SELECT followers FROM proj_count WHERE followee=?", u(2)), "投影计数 = 1");
        long[] d = Projector.diff(c);
        Check.that(d[0] == 0 && d[1] == 0 && d[2] == 0, "投影与真相源无差异");
    }

    static void privateApproval(Connection c) throws SQLException {
        Check.begin("30-B", "私密账号：关注进入 PENDING，重复请求不产生新事件，审批后 ACTIVE，非 PENDING 不能审批");
        RelationService.createAccount(c, u(10), true);
        RelationService rs = new RelationService(c);
        Result r1 = rs.follow(u(11), u(10));
        Result r2 = rs.follow(u(11), u(10));
        Check.note("request=" + r1 + " repeat=" + r2);
        Check.equal("PENDING", r1.state(), "私密账号进入 PENDING");
        Check.equal(Outcome.NOOP, r2.outcome(), "重复请求为 NOOP");
        Result a = rs.decide(u(10), u(11), true);
        Check.note("approve=" + a);
        Check.equal("ACTIVE", a.state(), "审批后 ACTIVE");
        Check.equal(2L, a.version(), "审批使版本变为 2");
        Result again = rs.decide(u(10), u(11), true);
        Check.equal(Outcome.REJECTED, again.outcome(), "对 ACTIVE 再次审批被拒绝: " + again.reason());
        Result r3 = rs.follow(u(12), u(10));
        Result rej = rs.decide(u(10), u(12), false);
        Check.note("request=" + r3 + " reject=" + rej);
        Check.equal("REMOVED", rej.state(), "拒绝后 REMOVED");
        drain(c);
        Check.equal(1L, count(c, "SELECT followers FROM proj_count WHERE followee=?", u(10)), "PENDING 与被拒请求不计入粉丝数");
    }

    static void boundaries(Connection c) throws SQLException {
        Check.begin("30-C", "边界：自关注、未关注时取消、取消后再关注版本继续递增、拉黑后关注被拒、解除拉黑不恢复旧关系");
        RelationService rs = new RelationService(c);
        Check.equal(Outcome.REJECTED, rs.follow(u(20), u(20)).outcome(), "自关注被拒");
        long before = count(c, "SELECT count(*) FROM relation_event");
        Result un = rs.unfollow(u(20), u(21));
        Check.equal(Outcome.NOOP, un.outcome(), "未关注时取消为 NOOP");
        Check.equal(before, count(c, "SELECT count(*) FROM relation_event"), "NOOP 不写事件");
        rs.follow(u(20), u(21));
        rs.unfollow(u(20), u(21));
        Result re = rs.follow(u(20), u(21));
        Check.note("follow/unfollow/follow -> " + re);
        Check.equal(3L, re.version(), "再关注得到版本 3，旧版本不会被重用");
        rs.block(u(21), u(20));
        Check.equal("REMOVED", Db.queryString(c, "SELECT state FROM relation WHERE follower=? AND followee=?", u(20), u(21)),
                "拉黑在同一事务内移除关系");
        Result fb = rs.follow(u(20), u(21));
        Result fb2 = rs.follow(u(21), u(20));
        Check.note("blocked follow both ways -> " + fb + " / " + fb2);
        Check.that(fb.outcome() == Outcome.REJECTED && fb2.outcome() == Outcome.REJECTED, "双向关注都被拒");
        rs.unblock(u(21), u(20));
        Check.equal("REMOVED", Db.queryString(c, "SELECT state FROM relation WHERE follower=? AND followee=?", u(20), u(21)),
                "解除拉黑后旧关系仍为 REMOVED");
        drain(c);
    }

    // ---------------------------------------------------------------- 并发
    static void concurrentDuplicateFollow(String db) throws Exception {
        Check.begin("30-D", "16 个线程同时关注同一对：一行关系、版本 1、恰好 1 条事件");
        int n = 16;
        CyclicBarrier barrier = new CyclicBarrier(n);
        ConcurrentLinkedQueue<Result> results = new ConcurrentLinkedQueue<>();
        ConcurrentLinkedQueue<Throwable> errors = new ConcurrentLinkedQueue<>();
        List<Thread> ts = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            ts.add(Thread.ofPlatform().start(() -> {
                try (Connection cx = Db.connect(db)) {
                    barrier.await();
                    results.add(new RelationService(cx).follow(u(31), u(30)));
                } catch (Throwable t) { errors.add(t); }
            }));
        }
        for (Thread t : ts) t.join();
        try (Connection c = Db.connect(db)) {
            long changed = results.stream().filter(r -> r.outcome() == Outcome.CHANGED).count();
            long noop = results.stream().filter(r -> r.outcome() == Outcome.NOOP).count();
            Check.note("CHANGED=" + changed + " NOOP=" + noop + " errors=" + errors.size());
            Check.equal(0, errors.size(), "无异常");
            Check.equal(1L, changed, "只有一个请求改变状态");
            Check.equal(1L, count(c, "SELECT version FROM relation WHERE follower=? AND followee=?", u(31), u(30)), "版本 = 1");
            Check.equal(1L, count(c, "SELECT count(*) FROM relation_event WHERE follower=? AND followee=?", u(31), u(30)), "事件 = 1");
        }
    }

    static void concurrentInterleave(String db, Connection c) throws Exception {
        Check.begin("30-E", "8 线程 × 150 次随机关注/取消交错于 6 个关系对：版本连续、末事件与真相源一致");
        int threads = 8, ops = 150;
        String[][] pairs = new String[6][];
        for (int i = 0; i < 6; i++) pairs[i] = new String[]{u(40 + i), u(50 + i % 3)};
        ConcurrentLinkedQueue<Throwable> errors = new ConcurrentLinkedQueue<>();
        java.util.concurrent.atomic.AtomicLong changed = new java.util.concurrent.atomic.AtomicLong();
        CyclicBarrier barrier = new CyclicBarrier(threads);
        List<Thread> ts = new ArrayList<>();
        for (int t = 0; t < threads; t++) {
            final long s = SEED + t;
            ts.add(Thread.ofPlatform().start(() -> {
                Random rnd = new Random(s);
                try (Connection cx = Db.connect(db)) {
                    RelationService rs = new RelationService(cx);
                    barrier.await();
                    for (int i = 0; i < ops; i++) {
                        String[] p = pairs[rnd.nextInt(pairs.length)];
                        Result r = rnd.nextBoolean() ? rs.follow(p[0], p[1]) : rs.unfollow(p[0], p[1]);
                        if (r.outcome() == Outcome.CHANGED) changed.incrementAndGet();
                    }
                } catch (Throwable e) { errors.add(e); }
            }));
        }
        for (Thread t : ts) t.join();
        Check.equal(0, errors.size(), "无异常");
        boolean contiguous = true, lastMatches = true;
        long events = 0;
        for (String[] p : pairs) {
            long n = count(c, "SELECT count(*) FROM relation_event WHERE follower=? AND followee=?", p[0], p[1]);
            long max = count(c, "SELECT coalesce(max(version),0) FROM relation_event WHERE follower=? AND followee=?", p[0], p[1]);
            long ver = count(c, "SELECT version FROM relation WHERE follower=? AND followee=?", p[0], p[1]);
            String lastState = Db.queryString(c, "SELECT state FROM relation_event WHERE follower=? AND followee=? ORDER BY version DESC LIMIT 1", p[0], p[1]);
            String truth = Db.queryString(c, "SELECT state FROM relation WHERE follower=? AND followee=?", p[0], p[1]);
            contiguous &= (n == max && max == ver);
            lastMatches &= truth.equals(lastState);
            events += n;
        }
        Check.note("state-changing ops=" + changed.get() + " events=" + events);
        Check.that(contiguous, "每对事件版本为 1..v 且 v 等于真相源版本");
        Check.that(lastMatches, "每对最高版本事件的状态等于真相源状态");
        Check.equal(changed.get(), events, "改变状态的操作数 = 事件数");
    }

    // ---------------------------------------------------------------- 乱序与重复
    static void singlePairReorder(Connection c) throws SQLException {
        Check.begin("30-F", "单对乱序：ACTIVE v1 / REMOVED v2 按 v2、v1、v1 到达");
        RelationService rs = new RelationService(c);
        Result f = rs.follow(u(60), u(61));
        Result uf = rs.unfollow(u(60), u(61));
        List<Projector.Event> ev = new ArrayList<>();
        for (Projector.Event e : Projector.loadEvents(c)) if (e.seq() == f.token() || e.seq() == uf.token()) ev.add(e);
        Projector.Event v1 = ev.get(0), v2 = ev.get(1);
        drainExcept(c, f.token(), uf.token());
        Projector p = new Projector(c);
        List<String> verdicts = List.of(p.apply(v2), p.apply(v1), p.apply(v1));
        Check.note("arrivals v2,v1,v1 -> " + verdicts);
        Check.equal(List.of("applied", "stale", "dup"), verdicts, "旧版本被判 stale，重复被判 dup");
        Check.equal("REMOVED", Db.queryString(c, "SELECT state FROM proj_follower WHERE followee=? AND follower=?", u(61), u(60)),
                "投影保持 REMOVED");
        long[] d = Projector.diff(c);
        Check.that(d[0] == 0 && d[1] == 0 && d[2] == 0, "投影与真相源无差异");
    }

    static void drainExcept(Connection c, long... skip) throws SQLException {
        Projector p = new Projector(c);
        long wm = Projector.watermark(c);
        outer:
        for (Projector.Event e : Projector.loadEvents(c)) {
            if (e.seq() <= wm) continue;
            for (long s : skip) if (s == e.seq()) continue outer;
            p.apply(e);
        }
    }

    static List<Projector.Event> shuffledWithDups(List<Projector.Event> events, long seed, double dupRate) {
        Random rnd = new Random(seed);
        List<Projector.Event> out = new ArrayList<>(events);
        for (Projector.Event e : events) if (rnd.nextDouble() < dupRate) out.add(e);
        Collections.shuffle(out, rnd);
        return out;
    }

    static void shuffledDelivery(String db, Connection c) throws Exception {
        Check.begin("30-G", "追加 300 对、每对 2–4 次关注/取消；全量事件 30% 重复后随机乱序，4 个消费者线程并发应用；对照组按到达顺序直接覆盖");
        Random gen = new Random(SEED);
        RelationService rs = new RelationService(c);
        for (int i = 0; i < 300; i++) {
            String a = u(1000 + i), b = u(2000 + i % 50);
            int k = 2 + gen.nextInt(3);
            for (int j = 0; j < k; j++) { if (j % 2 == 0) rs.follow(a, b); else rs.unfollow(a, b); }
        }
        Check.note("truth after workload: ACTIVE=" + count(c, "SELECT count(*) FROM relation WHERE state='ACTIVE'") +
                   " REMOVED=" + count(c, "SELECT count(*) FROM relation WHERE state='REMOVED'"));
        List<Projector.Event> all = Projector.loadEvents(c);
        List<Projector.Event> delivery = shuffledWithDups(all, SEED, 0.30);
        Check.note("events=" + all.size() + " deliveries=" + delivery.size() + " seed=" + SEED);
        // 负向对照：同一投递序列，单线程按到达顺序覆盖
        RelSchema.resetProjection(c);
        Projector naive = new Projector(c);
        for (Projector.Event e : delivery) naive.applyNaive(e);
        long[] nd = Projector.diff(c);
        Check.note("naive: resurrected=" + nd[0] + " missing=" + nd[1] + " wrongCounts=" + nd[2]);
        Check.exposes(nd[0] > 0, "按到达顺序应用时已取消的关系复活 (" + nd[0] + " 对)");
        // 正确实现
        RelSchema.resetProjection(c);
        int workers = 4;
        ConcurrentLinkedQueue<Projector.Event> q = new ConcurrentLinkedQueue<>(delivery);
        ConcurrentLinkedQueue<Throwable> errors = new ConcurrentLinkedQueue<>();
        Map<String, Integer> verdicts = Collections.synchronizedMap(new TreeMap<>());
        List<Thread> ts = new ArrayList<>();
        for (int w = 0; w < workers; w++) {
            ts.add(Thread.ofPlatform().start(() -> {
                try (Connection cx = Db.connect(db)) {
                    Projector p = new Projector(cx);
                    Projector.Event e;
                    while ((e = q.poll()) != null) verdicts.merge(p.apply(e), 1, Integer::sum);
                } catch (Throwable t) { errors.add(t); }
            }));
        }
        for (Thread t : ts) t.join();
        long[] d = Projector.diff(c);
        Check.note("versioned: verdicts=" + verdicts + " resurrected=" + d[0] + " missing=" + d[1] + " wrongCounts=" + d[2]);
        Check.equal(0, errors.size(), "无异常");
        Check.that(d[0] == 0 && d[1] == 0 && d[2] == 0, "版本化消费后投影与真相源无差异");
        Check.equal((long) all.size(), Projector.watermark(c), "连续水位 = 事件总数");
    }

    // ---------------------------------------------------------------- 拉黑与关注
    static long backendPid(Connection c) throws SQLException { return Db.queryLong(c, "SELECT pg_backend_pid()"); }

    static boolean waitingOnLock(Connection probe, long pid) throws SQLException {
        return Db.queryLong(probe, "SELECT count(*) FROM pg_locks WHERE pid = ? AND NOT granted", pid) > 0;
    }

    static void blockFollowInterleave(String db, Connection c, boolean negative) throws Exception {
        String id = negative ? "30-I" : "30-H";
        Check.begin(id, negative
                ? "负向对照：关注先检查拉黑再加锁，检查与加锁之间拉黑事务完整提交"
                : "关注先锁关系行再检查拉黑；拉黑事务在关注事务持锁期间到达并等待行锁");
        String a = negative ? u(72) : u(70), b = negative ? u(73) : u(71); // a 关注 b，b 拉黑 a
        CountDownLatch inWindow = new CountDownLatch(1), blockDone = new CountDownLatch(1);
        ConcurrentLinkedQueue<Throwable> errors = new ConcurrentLinkedQueue<>();
        Result[] fr = new Result[1];
        long[] blockPid = new long[1];
        boolean[] sawLockWait = new boolean[1];
        Connection blockConn = Db.connect(db);
        blockPid[0] = backendPid(blockConn);
        Thread follower = Thread.ofPlatform().start(() -> {
            try (Connection cx = Db.connect(db); Connection probe = Db.connect(db)) {
                RelationService rs = new RelationService(cx).checkBeforeLock(negative).hook(point -> {
                    inWindow.countDown();
                    try {
                        if (negative) {
                            blockDone.await(10, TimeUnit.SECONDS); // 让拉黑完整提交
                        } else {
                            long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(10);
                            while (System.nanoTime() < deadline && !(sawLockWait[0] = waitingOnLock(probe, blockPid[0])))
                                Thread.sleep(5);
                        }
                    } catch (InterruptedException ie) { throw new SQLException(ie); }
                });
                fr[0] = rs.follow(a, b);
            } catch (Throwable t) { errors.add(t); }
        });
        Thread blocker = Thread.ofPlatform().start(() -> {
            try {
                inWindow.await(10, TimeUnit.SECONDS);
                new RelationService(blockConn).block(b, a);
                blockDone.countDown();
            } catch (Throwable t) { errors.add(t); }
        });
        follower.join(); blocker.join();
        blockConn.close();
        String state = Db.queryString(c, "SELECT state FROM relation WHERE follower=? AND followee=?", a, b);
        long blocks = count(c, "SELECT count(*) FROM block WHERE blocker=? AND blocked=?", b, a);
        Check.note("follow result=" + fr[0] + " final relation=" + state + " block rows=" + blocks +
                   (negative ? "" : " blockTxWaitedOnRowLock=" + sawLockWait[0]));
        Check.equal(0, errors.size(), "无异常");
        if (negative) {
            Check.exposes("ACTIVE".equals(state) && blocks == 1, "拉黑已提交，关系仍为 ACTIVE");
        } else {
            Check.that(sawLockWait[0], "观察到拉黑事务在 pg_locks 中等待行锁");
            Check.equal("REMOVED", state, "拉黑后关系为 REMOVED");
            Check.equal(1L, blocks, "block 行存在");
        }
        drain(c);
    }

    static void blockFollowStress(String db, Connection c) throws Exception {
        Check.begin("30-J", "拉黑与双向关注并发 40 轮（真实线程，无插桩）：不存在被拉黑仍有效的关系");
        ConcurrentLinkedQueue<Throwable> errors = new ConcurrentLinkedQueue<>();
        for (int round = 0; round < 40; round++) {
            String a = u(100 + round), b = u(200 + round);
            if (round % 2 == 0) RelationService.createAccount(c, b, true);
            CyclicBarrier barrier = new CyclicBarrier(3);
            List<Thread> ts = new ArrayList<>();
            ts.add(Thread.ofPlatform().start(() -> runQuiet(db, barrier, errors, rs -> rs.follow(a, b))));
            ts.add(Thread.ofPlatform().start(() -> runQuiet(db, barrier, errors, rs -> rs.follow(b, a))));
            ts.add(Thread.ofPlatform().start(() -> runQuiet(db, barrier, errors, rs -> rs.block(b, a))));
            for (Thread t : ts) t.join();
        }
        long violations = count(c,
                "SELECT count(*) FROM relation r JOIN block k ON (k.blocker = r.follower AND k.blocked = r.followee) " +
                "OR (k.blocker = r.followee AND k.blocked = r.follower) WHERE r.state <> 'REMOVED' " +
                "AND r.follower BETWEEN 'user-0100' AND 'user-0299' AND r.followee BETWEEN 'user-0100' AND 'user-0299'");
        long blocks = count(c, "SELECT count(*) FROM block WHERE blocker BETWEEN 'user-0200' AND 'user-0239'");
        Check.note("rounds=40 blockRows=" + blocks);
        Check.equal(40L, blocks, "40 轮拉黑全部提交");
        Check.note("errors=" + errors.size() + " violations=" + violations);
        Check.equal(0, errors.size(), "无异常（死锁会以 40P01 重试）");
        Check.equal(0L, violations, "拉黑存在时双向关系均为 REMOVED");
        drain(c);
    }

    interface Op { Result run(RelationService rs) throws SQLException; }

    static void runQuiet(String db, CyclicBarrier barrier, ConcurrentLinkedQueue<Throwable> errors, Op op) {
        try (Connection cx = Db.connect(db)) {
            RelationService rs = new RelationService(cx);
            barrier.await();
            op.run(rs);
        } catch (Throwable t) { errors.add(t); }
    }

    // ---------------------------------------------------------------- 新敌人问题
    static void newEnemy(Connection c) throws SQLException {
        Check.begin("30-K", "撤销后发布新内容：投影滞后时，只读投影泄露；内容令牌与新鲜令牌回退真相源");
        String owner = u(300), viewer = u(342);
        RelationService.createAccount(c, owner, true);
        RelationService rs = new RelationService(c);
        rs.follow(viewer, owner);
        rs.decide(owner, viewer, true);
        long t1 = RelationService.createPost(c, 3001, owner, 1_000, "FOLLOWERS", "p1 before revoke");
        drain(c);
        Check.note("P1 acl_token=" + t1 + " watermark=" + Projector.watermark(c));
        Check.equal(true, AccessCheck.canRead(c, viewer, 3001, AccessCheck.Mode.CONTENT_TOKEN).allowed(), "撤销前 P1 可读");
        Result blk = rs.block(owner, viewer);
        long t2 = RelationService.createPost(c, 3002, owner, 2_000, "FOLLOWERS", "p2 after revoke");
        Check.note("block seq=" + blk.token() + " P2 acl_token=" + t2 + " watermark=" + Projector.watermark(c) + " (projection not drained)");
        for (AccessCheck.Mode m : AccessCheck.Mode.values()) {
            Check.note(String.format("%-15s P1=%s P2=%s", m,
                    AccessCheck.canRead(c, viewer, 3001, m), AccessCheck.canRead(c, viewer, 3002, m)));
        }
        Check.exposes(AccessCheck.canRead(c, viewer, 3002, AccessCheck.Mode.PROJECTION_ONLY).allowed(),
                "只读投影时，被拉黑者读到拉黑之后发布的 P2");
        Check.equal(false, AccessCheck.canRead(c, viewer, 3002, AccessCheck.Mode.TRUTH).allowed(), "真相源拒绝 P2");
        Check.equal(false, AccessCheck.canRead(c, viewer, 3002, AccessCheck.Mode.CONTENT_TOKEN).allowed(), "内容令牌拒绝 P2（回退真相源）");
        Check.equal(false, AccessCheck.canRead(c, viewer, 3001, AccessCheck.Mode.FRESH_TOKEN).allowed(), "新鲜令牌拒绝 P1");
        Check.that(AccessCheck.canRead(c, viewer, 3001, AccessCheck.Mode.CONTENT_TOKEN).allowed(),
                "内容令牌对旧内容 P1 仍允许：这是该模式声明的滞后窗口");
        drain(c);
        AccessCheck.Decision after = AccessCheck.canRead(c, viewer, 3001, AccessCheck.Mode.CONTENT_TOKEN);
        Check.note("after drain watermark=" + Projector.watermark(c) + " P1 CONTENT_TOKEN=" + after);
        Check.equal(false, after.allowed(), "投影追上后，内容令牌模式也拒绝 P1");
    }

    // ---------------------------------------------------------------- 重放恢复
    static void replayRecovery(String db, Connection c) throws Exception {
        Check.begin("30-L", "恢复：清空投影，先投递 60% 后消费者丢失进度重启，从头再次乱序投递全量");
        RelSchema.resetProjection(c);
        List<Projector.Event> all = Projector.loadEvents(c);
        List<Projector.Event> first = shuffledWithDups(all, SEED + 1, 0.0).subList(0, all.size() * 6 / 10);
        try (Connection c1 = Db.connect(db)) {
            Projector p = new Projector(c1);
            for (Projector.Event e : first) p.apply(e);
        }
        long midWm = Projector.watermark(c);
        long[] mid = Projector.diff(c);
        Check.note("after partial: watermark=" + midWm + "/" + all.size() + " diff=" + mid[0] + "," + mid[1] + "," + mid[2]);
        try (Connection c2 = Db.connect(db)) {
            Projector p = new Projector(c2);
            for (Projector.Event e : shuffledWithDups(all, SEED + 2, 0.3)) p.apply(e);
        }
        long[] d = Projector.diff(c);
        Check.note("after restart replay: watermark=" + Projector.watermark(c) + " diff=" + d[0] + "," + d[1] + "," + d[2]);
        Check.that(midWm < all.size(), "中途水位低于事件总数（确有未完成部分）");
        Check.that(d[0] == 0 && d[1] == 0 && d[2] == 0, "重放后投影与真相源无差异");
        Check.equal((long) all.size(), Projector.watermark(c), "水位追平");
    }
    // ---------------------------------------------------------------- 可见性边界
    static void visibilityBoundaries(Connection c) throws SQLException {
        Check.begin("30-M", "可见性边界：PUBLIC 对非粉丝可读、拉黑后各模式均拒绝；SELF 只对作者可读");
        String author = u(400), stranger = u(401), fan = u(402);
        RelationService rs = new RelationService(c);
        rs.follow(fan, author);
        RelationService.createPost(c, 4001, author, 3_000, "PUBLIC", "public post");
        RelationService.createPost(c, 4002, author, 3_001, "SELF", "self-only post");
        drain(c);
        boolean allPublic = true;
        for (AccessCheck.Mode m : AccessCheck.Mode.values()) allPublic &= AccessCheck.canRead(c, stranger, 4001, m).allowed();
        Check.note("stranger PUBLIC CONTENT_TOKEN=" + AccessCheck.canRead(c, stranger, 4001, AccessCheck.Mode.CONTENT_TOKEN));
        Check.that(allPublic, "非粉丝在四种模式下都能读 PUBLIC");
        rs.block(author, stranger);
        boolean anyAllowed = false;
        for (AccessCheck.Mode m : AccessCheck.Mode.values()) anyAllowed |= AccessCheck.canRead(c, stranger, 4001, m).allowed();
        Check.note("after block stranger PUBLIC PROJECTION_ONLY=" + AccessCheck.canRead(c, stranger, 4001, AccessCheck.Mode.PROJECTION_ONLY));
        Check.that(!anyAllowed, "拉黑后四种模式都拒绝 PUBLIC（拉黑直接读 block 表）");
        Check.note("fan SELF=" + AccessCheck.canRead(c, fan, 4002, AccessCheck.Mode.TRUTH) +
                   " owner SELF=" + AccessCheck.canRead(c, author, 4002, AccessCheck.Mode.TRUTH));
        Check.equal(false, AccessCheck.canRead(c, fan, 4002, AccessCheck.Mode.TRUTH).allowed(), "有效粉丝读 SELF 被拒");
        Check.equal(true, AccessCheck.canRead(c, author, 4002, AccessCheck.Mode.TRUTH).allowed(), "作者读 SELF 允许");
        rs.unblock(author, stranger);
        Check.equal(true, AccessCheck.canRead(c, stranger, 4001, AccessCheck.Mode.TRUTH).allowed(), "解除拉黑后 PUBLIC 恢复可读");
    }
}
