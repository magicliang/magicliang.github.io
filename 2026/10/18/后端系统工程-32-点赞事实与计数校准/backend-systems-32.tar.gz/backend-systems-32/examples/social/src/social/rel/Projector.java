package social.rel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import lab.common.Db;
import social.common.Tx;

/** 关系事件消费者：把事件应用到粉丝列表与计数投影。 */
public final class Projector {
    public record Event(long seq, String follower, String followee, String state, long version) {}

    public static List<Event> loadEvents(Connection c) throws SQLException {
        List<Event> out = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT seq, follower, followee, state, version FROM relation_event ORDER BY seq");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) out.add(new Event(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getLong(5)));
        }
        return out;
    }

    private final Connection c;
    public Projector(Connection c) { this.c = c; }

    /**
     * 正确消费：只接受版本更大的事件；计数增量由旧状态与新状态的差决定；
     * 已见事件集合与连续水位在同一事务内更新。返回 "applied"/"stale"/"dup"。
     */
    public String apply(Event e) throws SQLException {
        return Tx.rc(c, cx -> {
            int fresh = Db.update(cx, "INSERT INTO proj_seen(seq) VALUES (?) ON CONFLICT DO NOTHING", e.seq());
            String verdict;
            if (fresh == 0) {
                verdict = "dup";
            } else {
                Db.update(cx, "INSERT INTO proj_follower(followee, follower, state, version) VALUES (?, ?, 'REMOVED', 0) " +
                              "ON CONFLICT DO NOTHING", e.followee(), e.follower());
                String oldState; long oldVer;
                try (PreparedStatement ps = cx.prepareStatement(
                        "SELECT state, version FROM proj_follower WHERE followee = ? AND follower = ? FOR UPDATE")) {
                    ps.setString(1, e.followee()); ps.setString(2, e.follower());
                    try (ResultSet rs = ps.executeQuery()) { rs.next(); oldState = rs.getString(1); oldVer = rs.getLong(2); }
                }
                if (e.version() <= oldVer) {
                    verdict = "stale";
                } else {
                    Db.update(cx, "UPDATE proj_follower SET state = ?, version = ? WHERE followee = ? AND follower = ?",
                            e.state(), e.version(), e.followee(), e.follower());
                    int delta = (e.state().equals("ACTIVE") ? 1 : 0) - (oldState.equals("ACTIVE") ? 1 : 0);
                    if (delta != 0)
                        Db.update(cx, "INSERT INTO proj_count(followee, followers) VALUES (?, ?) " +
                                      "ON CONFLICT (followee) DO UPDATE SET followers = proj_count.followers + EXCLUDED.followers",
                                e.followee(), delta);
                    verdict = "applied";
                }
            }
            advanceWatermark(cx);
            return verdict;
        });
    }

    /** 连续水位：最大的 s，使 1..s 都已在 proj_seen 中。 */
    static void advanceWatermark(Connection cx) throws SQLException {
        long upto = Db.queryLong(cx, "SELECT applied_upto FROM proj_watermark WHERE id = 1 FOR UPDATE");
        long next = upto;
        try (PreparedStatement ps = cx.prepareStatement(
                "SELECT seq FROM proj_seen WHERE seq > ? ORDER BY seq LIMIT 10000")) {
            ps.setLong(1, upto);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next() && rs.getLong(1) == next + 1) next++;
            }
        }
        if (next != upto) Db.update(cx, "UPDATE proj_watermark SET applied_upto = ? WHERE id = 1", next);
    }

    /** 负向对照：按到达顺序直接覆盖，不比较版本、不去重。 */
    public void applyNaive(Event e) throws SQLException {
        Tx.rc(c, cx -> {
            String old = Db.queryString(cx, "SELECT state FROM proj_follower WHERE followee = ? AND follower = ?",
                    e.followee(), e.follower());
            Db.update(cx, "INSERT INTO proj_follower(followee, follower, state, version) VALUES (?, ?, ?, ?) " +
                          "ON CONFLICT (followee, follower) DO UPDATE SET state = EXCLUDED.state, version = EXCLUDED.version",
                    e.followee(), e.follower(), e.state(), e.version());
            int delta = (e.state().equals("ACTIVE") ? 1 : 0) - ("ACTIVE".equals(old) ? 1 : 0);
            if (delta != 0)
                Db.update(cx, "INSERT INTO proj_count(followee, followers) VALUES (?, ?) " +
                              "ON CONFLICT (followee) DO UPDATE SET followers = proj_count.followers + EXCLUDED.followers",
                        e.followee(), delta);
            return null;
        });
    }

    public static long watermark(Connection c) throws SQLException {
        return Db.queryLong(c, "SELECT applied_upto FROM proj_watermark WHERE id = 1");
    }

    /** 投影与真相源的差异行数：有效关系集合的对称差 + 计数不一致的被关注者数。 */
    public static long[] diff(Connection c) throws SQLException {
        long resurrected = Db.queryLong(c,
                "SELECT count(*) FROM proj_follower p JOIN relation r ON r.follower = p.follower AND r.followee = p.followee " +
                "WHERE p.state = 'ACTIVE' AND r.state <> 'ACTIVE'");
        long missing = Db.queryLong(c,
                "SELECT count(*) FROM relation r LEFT JOIN proj_follower p ON r.follower = p.follower AND r.followee = p.followee " +
                "WHERE r.state = 'ACTIVE' AND (p.state IS NULL OR p.state <> 'ACTIVE')");
        long badCount = Db.queryLong(c,
                "WITH t AS (SELECT followee, count(*) n FROM relation WHERE state = 'ACTIVE' GROUP BY followee) " +
                "SELECT count(*) FROM (SELECT followee FROM t FULL JOIN proj_count pc USING (followee) " +
                "WHERE coalesce(t.n, 0) <> coalesce(pc.followers, 0)) x");
        return new long[]{resurrected, missing, badCount};
    }
}
