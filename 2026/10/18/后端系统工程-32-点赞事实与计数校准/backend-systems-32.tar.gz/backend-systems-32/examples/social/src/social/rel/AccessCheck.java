package social.rel;

import java.sql.Connection;
import java.sql.SQLException;
import lab.common.Db;

/**
 * 内容访问检查。PUBLIC 只检查拉黑；FOLLOWERS 按四种模式检查关注关系：
 * TRUTH 读真相源；PROJECTION_ONLY 直接读派生视图（负向对照）；
 * CONTENT_TOKEN 要求投影水位不低于内容的 acl_token，否则回退真相源；
 * FRESH_TOKEN 要求投影水位不低于检查时刻已提交的最高事件序号，否则回退真相源。
 */
public final class AccessCheck {
    public enum Mode { TRUTH, PROJECTION_ONLY, CONTENT_TOKEN, FRESH_TOKEN }
    public record Decision(boolean allowed, String source) {
        public String toString() { return (allowed ? "ALLOW" : "DENY") + "/" + source; }
    }

    private AccessCheck() {}

    public static Decision canRead(Connection c, String viewer, long postId, Mode mode) throws SQLException {
        String author = Db.queryString(c, "SELECT author FROM post WHERE post_id = ?", postId);
        String vis = Db.queryString(c, "SELECT visibility FROM post WHERE post_id = ?", postId);
        if (author == null) return new Decision(false, "no-post");
        if (author.equals(viewer)) return new Decision(true, "owner");
        if (vis.equals("SELF")) return new Decision(false, "self-only");
        if (vis.equals("PUBLIC")) {
            // 公开内容不看关注关系，只看拉黑；拉黑不进投影，所以任何模式都读真相源 block 表
            boolean blocked = Db.queryLong(c, "SELECT count(*) FROM block WHERE (blocker = ? AND blocked = ?) OR (blocker = ? AND blocked = ?)",
                    author, viewer, viewer, author) > 0;
            return new Decision(!blocked, "public-block-check");
        }
        long token = switch (mode) {
            case CONTENT_TOKEN -> Db.queryLong(c, "SELECT acl_token FROM post WHERE post_id = ?", postId);
            case FRESH_TOKEN -> Db.queryLong(c, "SELECT last FROM event_seq WHERE id = 1");
            default -> 0;
        };
        boolean useProjection = switch (mode) {
            case TRUTH -> false;
            case PROJECTION_ONLY -> true;
            case CONTENT_TOKEN, FRESH_TOKEN -> Projector.watermark(c) >= token;
        };
        if (useProjection) {
            boolean ok = Db.queryLong(c, "SELECT count(*) FROM proj_follower WHERE followee = ? AND follower = ? AND state = 'ACTIVE'",
                    author, viewer) > 0;
            return new Decision(ok, "projection");
        }
        boolean ok = Db.queryLong(c,
                "SELECT count(*) FROM relation r WHERE r.follower = ? AND r.followee = ? AND r.state = 'ACTIVE' " +
                "AND NOT EXISTS (SELECT 1 FROM block b WHERE (b.blocker = r.follower AND b.blocked = r.followee) " +
                "OR (b.blocker = r.followee AND b.blocked = r.follower))", viewer, author) > 0;
        return new Decision(ok, mode == Mode.TRUTH ? "truth" : "fallback-truth");
    }
}
