package social.like;

import java.sql.Connection;
import java.sql.SQLException;
import lab.common.Db;

/** 第 32 篇：互动事实表、Outbox 事件、派生计数、去重记录与水位。 */
public final class LikeSchema {
    private LikeSchema() {}

    public static void create(Connection c) throws SQLException {
        Db.exec(c, """
            CREATE TABLE item (item_id text PRIMARY KEY, owner text NOT NULL);
            -- 唯一互动事实：每个 (user, item) 一行，liked 为当前状态，version 每次状态变化加一
            CREATE TABLE like_fact (
              user_id text   NOT NULL,
              item_id text   NOT NULL REFERENCES item (item_id),
              liked   boolean NOT NULL,
              version bigint NOT NULL CHECK (version >= 0),
              PRIMARY KEY (user_id, item_id)
            );
            CREATE INDEX like_fact_by_item ON like_fact (item_id) WHERE liked;
            -- 全局无空洞序号：计数行的行锁持有到提交，序号顺序等于提交顺序
            CREATE TABLE like_seq (id int PRIMARY KEY CHECK (id = 1), last bigint NOT NULL);
            INSERT INTO like_seq VALUES (1, 0);
            -- Outbox：与事实变化同事务写入；delta 由事务内读到的旧状态决定
            CREATE TABLE like_outbox (
              seq     bigint PRIMARY KEY,
              user_id text   NOT NULL,
              item_id text   NOT NULL,
              delta   smallint NOT NULL CHECK (delta IN (-1, 1)),
              version bigint NOT NULL,
              UNIQUE (user_id, item_id, version)
            );
            CREATE INDEX like_outbox_by_item ON like_outbox (item_id, seq);
            -- 派生计数：n = 重算基线 base_seq 时的事实数 + 序号大于 base_seq 且已应用的事件增量
            CREATE TABLE like_count (
              item_id  text PRIMARY KEY,
              n        bigint NOT NULL,
              base_seq bigint NOT NULL DEFAULT 0
            );
            -- 已处理事件：APPLIED 计入了增量；COVERED 表示该事件已被重算基线覆盖，只登记不加
            CREATE TABLE processed_event (
              seq bigint PRIMARY KEY,
              how text NOT NULL CHECK (how IN ('APPLIED', 'COVERED'))
            );
            -- 连续水位：1..applied_upto 全部已处理
            CREATE TABLE counter_watermark (id int PRIMARY KEY CHECK (id = 1), applied_upto bigint NOT NULL);
            INSERT INTO counter_watermark VALUES (1, 0);
            -- 负向对照用：请求路径直接加减的计数
            CREATE TABLE like_count_naive (item_id text PRIMARY KEY, n bigint NOT NULL);
            """);
    }

    /** 清空全部数据，序号与水位归零。 */
    public static void reset(Connection c) throws SQLException {
        Db.exec(c, "TRUNCATE like_fact, like_outbox, like_count, processed_event, like_count_naive, item; " +
                   "UPDATE like_seq SET last = 0; UPDATE counter_watermark SET applied_upto = 0");
    }

    /** 只清空派生侧（计数、去重记录、水位），保留事实与 Outbox，用于让另一种消费者重放同一批事件。 */
    public static void resetDerived(Connection c) throws SQLException {
        Db.exec(c, "TRUNCATE like_count, processed_event; UPDATE counter_watermark SET applied_upto = 0");
    }

    public static void addItems(Connection c, int n) throws SQLException {
        for (int i = 1; i <= n; i++) Db.update(c, "INSERT INTO item VALUES (?, ?)", item(i), "user-9" + String.format("%03d", i));
    }

    public static String item(int i) { return String.format("item-lab-%02d", i); }
    public static String user(int i) { return String.format("user-%04d", i); }
}
