package social.like;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import lab.common.Db;
import social.common.Tx;

/**
 * 计数消费者。一批事件在一个事务内处理：锁水位行（消费者之间串行）→ 逐条锁计数行 →
 * 登记 processed_event（主键去重）→ 加增量 → 推进连续水位。
 */
public final class CounterConsumer {
    public record Ev(long seq, String user, String item, int delta, long version) {}

    public static final class Stats {
        public int applied, covered, dup;
        public long watermark;
        public void add(Stats o) { applied += o.applied; covered += o.covered; dup += o.dup; watermark = o.watermark; }
        public String toString() { return "applied=" + applied + " covered=" + covered + " dup=" + dup + " watermark=" + watermark; }
    }

    public interface Hook { void at(String point, Connection c) throws SQLException; }

    private final Connection c;
    private boolean dedup = true;
    private Hook hook = (p, cx) -> {};

    public CounterConsumer(Connection c) { this.c = c; }
    /** false 为负向对照：不查 processed_event，也不看 base_seq，每次投递都加增量。 */
    public CounterConsumer dedup(boolean v) { this.dedup = v; return this; }
    public CounterConsumer hook(Hook h) { this.hook = h; return this; }

    public static List<Ev> fetchAfter(Connection c, long after, int limit) throws SQLException {
        return query(c, "SELECT seq, user_id, item_id, delta, version FROM like_outbox WHERE seq > ? ORDER BY seq LIMIT ?", after, limit);
    }

    public static List<Ev> fetchSeqs(Connection c, Collection<Long> seqs) throws SQLException {
        return query(c, "SELECT seq, user_id, item_id, delta, version FROM like_outbox WHERE seq = ANY (?) ORDER BY seq",
                c.createArrayOf("bigint", seqs.toArray()));
    }

    public static List<Ev> all(Connection c) throws SQLException {
        return query(c, "SELECT seq, user_id, item_id, delta, version FROM like_outbox ORDER BY seq");
    }

    private static List<Ev> query(Connection c, String sql, Object... args) throws SQLException {
        List<Ev> out = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(new Ev(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getLong(5)));
            }
        }
        return out;
    }

    public Stats apply(List<Ev> batch) throws SQLException {
        List<Ev> sorted = new ArrayList<>(batch);
        sorted.sort(Comparator.comparing(Ev::item).thenComparingLong(Ev::seq));
        return Tx.rc(c, cx -> {
            Stats s = new Stats();
            Db.queryLong(cx, "SELECT applied_upto FROM counter_watermark WHERE id = 1 FOR UPDATE");
            for (Ev e : sorted) {
                Db.update(cx, "INSERT INTO like_count(item_id, n, base_seq) VALUES (?, 0, 0) ON CONFLICT DO NOTHING", e.item());
                long base = Db.queryLong(cx, "SELECT base_seq FROM like_count WHERE item_id = ? FOR UPDATE", e.item());
                if (!dedup) {
                    Db.update(cx, "INSERT INTO processed_event(seq, how) VALUES (?, 'APPLIED') ON CONFLICT DO NOTHING", e.seq());
                    Db.update(cx, "UPDATE like_count SET n = n + ? WHERE item_id = ?", e.delta(), e.item());
                    s.applied++;
                } else if (e.seq() <= base) {
                    // 重算基线已经包含这条事件的效果：只登记，不加
                    int fresh = Db.update(cx, "INSERT INTO processed_event(seq, how) VALUES (?, 'COVERED') ON CONFLICT DO NOTHING", e.seq());
                    if (fresh == 1) s.covered++; else s.dup++;
                } else {
                    int fresh = Db.update(cx, "INSERT INTO processed_event(seq, how) VALUES (?, 'APPLIED') ON CONFLICT DO NOTHING", e.seq());
                    if (fresh == 1) {
                        Db.update(cx, "UPDATE like_count SET n = n + ? WHERE item_id = ?", e.delta(), e.item());
                        s.applied++;
                    } else {
                        s.dup++;
                    }
                }
            }
            s.watermark = advanceWatermark(cx);
            hook.at("beforeCommit", cx);
            return s;
        });
    }

    /** 连续水位：最大的 w，使 1..w 全部在 processed_event 中。调用方已持有水位行锁。 */
    static long advanceWatermark(Connection cx) throws SQLException {
        long upto = Db.queryLong(cx, "SELECT applied_upto FROM counter_watermark WHERE id = 1");
        long next = upto;
        try (PreparedStatement ps = cx.prepareStatement("SELECT seq FROM processed_event WHERE seq > ? ORDER BY seq LIMIT 100000")) {
            ps.setLong(1, upto);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next() && rs.getLong(1) == next + 1) next++;
            }
        }
        if (next != upto) Db.update(cx, "UPDATE counter_watermark SET applied_upto = ? WHERE id = 1", next);
        return next;
    }

    /** 从水位之后按序号拉取并应用，直到没有新事件。 */
    public Stats drain(int batchSize) throws SQLException {
        Stats total = new Stats();
        while (true) {
            List<Ev> b = fetchAfter(c, watermark(c), batchSize);
            if (b.isEmpty()) { total.watermark = watermark(c); return total; }
            total.add(apply(b));
        }
    }

    public static long watermark(Connection c) throws SQLException {
        return Db.queryLong(c, "SELECT applied_upto FROM counter_watermark WHERE id = 1");
    }

    /** 滞后 = 已提交的最大事件序号 − 连续水位；两者在同一条语句（同一快照）里读出。 */
    public static long lag(Connection c) throws SQLException {
        return Db.queryLong(c, "SELECT (SELECT last FROM like_seq) - (SELECT applied_upto FROM counter_watermark)");
    }
}
