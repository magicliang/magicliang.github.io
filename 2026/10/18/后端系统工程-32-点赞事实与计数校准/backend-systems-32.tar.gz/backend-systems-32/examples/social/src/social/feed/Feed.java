package social.feed;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.TreeMap;
import lab.common.Db;
import social.common.Tx;

/**
 * 推、拉、混合三种 Feed 共用一段代码，差别只在发布时怎样决定每条帖子的投递方式：
 * PUSH 一律写时扇出到收件箱；PULL 一律留在作者时间线等读时拉取；
 * HYBRID 按发布时刻作者粉丝数（follower_count）与阈值比较。
 * 投递方式记在帖子行的 delivery 列上，读路径据此找候选，不依赖读取时刻的粉丝数。
 * 每种方案使用自己的 schema（post、inbox），关系真相源 relation/block 在 public 中共享。
 * 所有候选都在读取时按当前权限过滤。
 */
public final class Feed {
    public enum Kind { PUSH, PULL, HYBRID }
    /** 分页方式：KEYSET 为正确实现；TS_ONLY、OFFSET 只用于负向对照。 */
    public enum Paging { KEYSET, TS_ONLY, OFFSET }

    /** 本次输入下确定的计数：语句数、写入行数、返回给应用的行数。不含耗时。 */
    public static final class Cost {
        public long writeQueries, writeRows, readQueries, readRows, pages, maxFanoutRows, maxPageQueries;
        public final Map<String, Long> streamQueriesByAuthor = new TreeMap<>();
        public void reset() {
            writeQueries = writeRows = readQueries = readRows = pages = maxFanoutRows = maxPageQueries = 0;
            streamQueriesByAuthor.clear();
        }
        public String toString() {
            return "writeQueries=" + writeQueries + " writeRows=" + writeRows +
                   " readQueries=" + readQueries + " readRows=" + readRows + " pages=" + pages;
        }
    }

    public record Item(long createdAt, long postId, String author) {}
    public record Cursor(long createdAt, long postId) {
        public static final Cursor TOP = new Cursor(Long.MAX_VALUE, Long.MAX_VALUE);
    }

    public static final Comparator<Item> NEWEST_FIRST =
            Comparator.comparingLong(Item::createdAt).thenComparingLong(Item::postId).reversed();

    /** 读取时的当前权限与成员资格：仍是 ACTIVE 关注、双方无拉黑、帖子不是仅自己可见。参数依次为 reader×3。 */
    static final String VISIBLE = """
             p.visibility <> 'SELF'
             AND EXISTS (SELECT 1 FROM relation r WHERE r.follower = ? AND r.followee = p.author AND r.state = 'ACTIVE')
             AND NOT EXISTS (SELECT 1 FROM block b WHERE (b.blocker = ? AND b.blocked = p.author)
                                                      OR (b.blocker = p.author AND b.blocked = ?))
            """;

    public final String name;
    public final Kind kind;
    public final long threshold;
    public final String schema;
    public final Cost cost = new Cost();
    /** 负向对照：读取时按“当前”粉丝数决定拉谁，并且不区分帖子的投递方式。 */
    public boolean classifyAtRead;

    public Feed(String name, Kind kind, long threshold) {
        this.name = name;
        this.kind = kind;
        this.threshold = threshold;
        this.schema = "feed_" + name.toLowerCase().replaceAll("[^a-z0-9]", "_");
    }

    /** public 中的粉丝计数快照：混合方案在发布时读它做分类。 */
    public static void createShared(Connection c) throws SQLException {
        Db.exec(c, "CREATE TABLE follower_count (author text PRIMARY KEY, followers bigint NOT NULL)");
    }

    public void createTables(Connection c) throws SQLException {
        Db.exec(c, "CREATE SCHEMA " + schema);
        Db.exec(c, "CREATE TABLE " + schema + ".post (" +
                "post_id bigint PRIMARY KEY, author text NOT NULL, created_at bigint NOT NULL, " +
                "visibility text NOT NULL CHECK (visibility IN ('PUBLIC','FOLLOWERS','SELF')), " +
                "acl_token bigint NOT NULL DEFAULT 0, body text NOT NULL, " +
                "delivery text NOT NULL CHECK (delivery IN ('PUSH','PULL')))");
        Db.exec(c, "CREATE INDEX ON " + schema + ".post (author, created_at DESC, post_id DESC) WHERE delivery = 'PULL'");
        Db.exec(c, "CREATE TABLE " + schema + ".inbox (reader text NOT NULL, created_at bigint NOT NULL, " +
                "post_id bigint NOT NULL, author text NOT NULL, PRIMARY KEY (reader, post_id))");
        Db.exec(c, "CREATE INDEX ON " + schema + ".inbox (reader, created_at DESC, post_id DESC)");
    }

    /** 打开一条连接，search_path 指向本方案的 schema，再回落到 public 的关系表。 */
    public Connection open(String db) throws SQLException {
        Connection c = Db.connect(db);
        Db.exec(c, "SET search_path TO " + schema + ", public");
        return c;
    }

    // ------------------------------------------------------------------ 写路径

    /** 测试插桩：扇出语句执行后、提交前调用。 */
    public interface Hook { void beforeCommit(Connection c) throws SQLException; }

    public String publish(Connection c, long postId, String author, long createdAt, String visibility) throws SQLException {
        return publish(c, postId, author, createdAt, visibility, null);
    }

    /**
     * 帖子行与收件箱行在同一事务内写入。重复发布同一 post_id 为 NOOP，不会二次扇出。
     * 返回 "PUSH"/"PULL"/"NOOP"。
     */
    public String publish(Connection c, long postId, String author, long createdAt, String visibility, Hook hook)
            throws SQLException {
        return Tx.rc(c, cx -> {
            String delivery;
            if (kind == Kind.PUSH) delivery = "PUSH";
            else if (kind == Kind.PULL) delivery = "PULL";
            else {
                cost.writeQueries++;
                long n = Db.queryLong(cx, "SELECT coalesce((SELECT followers FROM follower_count WHERE author = ?), 0)", author);
                delivery = n >= threshold ? "PULL" : "PUSH";
            }
            cost.writeQueries++;
            int ins = Db.update(cx, "INSERT INTO post (post_id, author, created_at, visibility, body, delivery) " +
                    "VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT (post_id) DO NOTHING",
                    postId, author, createdAt, visibility, "body of " + postId, delivery);
            cost.writeRows += ins;
            if (ins == 0) return "NOOP";
            if (delivery.equals("PUSH")) {
                cost.writeQueries++;
                int n = Db.update(cx, "INSERT INTO inbox (reader, created_at, post_id, author) " +
                        "SELECT r.follower, ?, ?, ? FROM relation r WHERE r.followee = ? AND r.state = 'ACTIVE' " +
                        "ON CONFLICT DO NOTHING", createdAt, postId, author, author);
                cost.writeRows += n;
                cost.maxFanoutRows = Math.max(cost.maxFanoutRows, n);
            }
            if (hook != null) hook.beforeCommit(cx);
            return delivery;
        });
    }

    // ------------------------------------------------------------------ 读路径

    public List<Item> page(Connection c, String reader, Cursor cur, int limit) throws SQLException {
        return page(c, reader, cur, 0, limit, Paging.KEYSET);
    }

    /** 一页在一个 REPEATABLE READ 事务内读取，所有子查询看到同一快照。 */
    public List<Item> page(Connection c, String reader, Cursor cur, int offset, int limit, Paging paging) throws SQLException {
        long q0 = cost.readQueries;
        List<Item> out = Tx.rr(c, cx -> {
            int fetch = paging == Paging.OFFSET ? offset + limit : limit;
            List<List<Item>> streams = new ArrayList<>();
            if (kind != Kind.PULL) streams.add(inboxStream(cx, reader, cur, fetch, paging));
            if (kind != Kind.PUSH) {
                for (String author : pulledFollowees(cx, reader))
                    streams.add(authorStream(cx, reader, author, cur, fetch, paging));
            }
            List<Item> merged = merge(streams, fetch);
            return paging == Paging.OFFSET ? merged.subList(Math.min(offset, merged.size()), merged.size()) : merged;
        });
        cost.pages++;
        cost.maxPageQueries = Math.max(cost.maxPageQueries, cost.readQueries - q0);
        return out;
    }

    private static String cursorPredicate(String alias, Paging paging) {
        return switch (paging) {
            case KEYSET -> "(" + alias + ".created_at, " + alias + ".post_id) < (?, ?)";
            case TS_ONLY -> alias + ".created_at < ? AND ? = ?";   // 负向对照：只比较时间戳
            case OFFSET -> "? = ? AND ? = ?";                       // 负向对照：不用游标，靠跳过行数
        };
    }

    private static Object[] cursorArgs(Cursor cur, Paging paging) {
        return switch (paging) {
            case KEYSET -> new Object[]{cur.createdAt(), cur.postId()};
            case TS_ONLY -> new Object[]{cur.createdAt(), 0, 0};
            case OFFSET -> new Object[]{0, 0, 0, 0};
        };
    }

    private List<Item> inboxStream(Connection c, String reader, Cursor cur, int limit, Paging paging) throws SQLException {
        String sql = "SELECT i.created_at, i.post_id, i.author FROM inbox i JOIN post p ON p.post_id = i.post_id " +
                "WHERE i.reader = ? AND " + cursorPredicate("i", paging) + " AND " + VISIBLE +
                "ORDER BY i.created_at DESC, i.post_id DESC LIMIT ?";
        return items(c, sql, concat(new Object[]{reader}, cursorArgs(cur, paging), new Object[]{reader, reader, reader, limit}));
    }

    private List<String> pulledFollowees(Connection c, String reader) throws SQLException {
        String sql = classifyAtRead
                ? "SELECT r.followee FROM relation r JOIN follower_count fc ON fc.author = r.followee " +
                  "WHERE r.follower = ? AND r.state = 'ACTIVE' AND fc.followers >= " + threshold + " ORDER BY r.followee"
                : "SELECT r.followee FROM relation r WHERE r.follower = ? AND r.state = 'ACTIVE' " +
                  "AND EXISTS (SELECT 1 FROM post p WHERE p.author = r.followee AND p.delivery = 'PULL') ORDER BY r.followee";
        cost.readQueries++;
        List<String> out = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, reader);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) { out.add(rs.getString(1)); cost.readRows++; } }
        }
        return out;
    }

    private List<Item> authorStream(Connection c, String reader, String author, Cursor cur, int limit, Paging paging)
            throws SQLException {
        cost.streamQueriesByAuthor.merge(author, 1L, Long::sum);
        String deliveryFilter = classifyAtRead ? "" : "p.delivery = 'PULL' AND ";
        String sql = "SELECT p.created_at, p.post_id, p.author FROM post p " +
                "WHERE p.author = ? AND " + deliveryFilter + cursorPredicate("p", paging) + " AND " + VISIBLE +
                "ORDER BY p.created_at DESC, p.post_id DESC LIMIT ?";
        return items(c, sql, concat(new Object[]{author}, cursorArgs(cur, paging), new Object[]{reader, reader, reader, limit}));
    }

    private List<Item> items(Connection c, String sql, Object... args) throws SQLException {
        cost.readQueries++;
        List<Item> out = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) { out.add(new Item(rs.getLong(1), rs.getLong(2), rs.getString(3))); cost.readRows++; }
            }
        }
        return out;
    }

    private static Object[] concat(Object[]... parts) {
        List<Object> all = new ArrayList<>();
        for (Object[] p : parts) all.addAll(List.of(p));
        return all.toArray();
    }

    /** 多路归并：每路已按 (created_at, post_id) 降序，取全局前 limit 条。不去重，重复由调用方断言暴露。 */
    static List<Item> merge(List<List<Item>> streams, int limit) {
        record Head(Item item, int stream, int idx) {}
        PriorityQueue<Head> pq = new PriorityQueue<>((x, y) -> NEWEST_FIRST.compare(x.item(), y.item()));
        for (int s = 0; s < streams.size(); s++) if (!streams.get(s).isEmpty()) pq.add(new Head(streams.get(s).get(0), s, 0));
        List<Item> out = new ArrayList<>();
        while (!pq.isEmpty() && out.size() < limit) {
            Head h = pq.poll();
            out.add(h.item());
            List<Item> st = streams.get(h.stream());
            if (h.idx() + 1 < st.size()) pq.add(new Head(st.get(h.idx() + 1), h.stream(), h.idx() + 1));
        }
        return out;
    }

    public static Cursor next(List<Item> page) {
        Item last = page.get(page.size() - 1);
        return new Cursor(last.createdAt(), last.postId());
    }

    /** 负向对照：直接返回已物化的收件箱行，不做读取时的权限过滤。 */
    public List<Item> rawInboxPage(Connection c, String reader, int limit) throws SQLException {
        return items(c, "SELECT created_at, post_id, author FROM inbox WHERE reader = ? " +
                "ORDER BY created_at DESC, post_id DESC LIMIT ?", reader, limit);
    }
}
