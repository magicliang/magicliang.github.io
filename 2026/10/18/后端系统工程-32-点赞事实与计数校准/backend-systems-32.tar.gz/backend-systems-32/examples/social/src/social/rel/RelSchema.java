package social.rel;

import java.sql.Connection;
import java.sql.SQLException;
import lab.common.Db;

/** 第 30 篇的真相源表、事件表与派生视图表。第 31 篇复用真相源部分。 */
public final class RelSchema {
    private RelSchema() {}

    public static void create(Connection c) throws SQLException {
        Db.exec(c, """
            CREATE TABLE account (
              user_id    text PRIMARY KEY,
              is_private boolean NOT NULL DEFAULT false
            );
            -- 关系真相源：每个有序对一行，状态与单调版本
            CREATE TABLE relation (
              follower text NOT NULL,
              followee text NOT NULL,
              state    text NOT NULL CHECK (state IN ('ACTIVE','PENDING','REMOVED')),
              version  bigint NOT NULL CHECK (version >= 0),
              PRIMARY KEY (follower, followee),
              CHECK (follower <> followee)
            );
            -- 反向查询索引：按被关注者列出有效粉丝
            CREATE INDEX relation_by_followee ON relation (followee, follower) WHERE state = 'ACTIVE';
            CREATE TABLE block (
              blocker text NOT NULL,
              blocked text NOT NULL,
              PRIMARY KEY (blocker, blocked),
              CHECK (blocker <> blocked)
            );
            -- 无空洞事件序号：计数行的行锁持有到提交，序号顺序等于提交顺序
            CREATE TABLE event_seq (id int PRIMARY KEY CHECK (id = 1), last bigint NOT NULL);
            INSERT INTO event_seq VALUES (1, 0);
            CREATE TABLE relation_event (
              seq      bigint PRIMARY KEY,
              follower text NOT NULL,
              followee text NOT NULL,
              state    text NOT NULL,
              version  bigint NOT NULL,
              cause    text NOT NULL,
              UNIQUE (follower, followee, version)
            );
            -- 派生视图：粉丝列表、粉丝计数、已见事件与连续水位
            CREATE TABLE proj_follower (
              followee text NOT NULL,
              follower text NOT NULL,
              state    text NOT NULL,
              version  bigint NOT NULL,
              PRIMARY KEY (followee, follower)
            );
            CREATE TABLE proj_count (followee text PRIMARY KEY, followers bigint NOT NULL);
            CREATE TABLE proj_seen (seq bigint PRIMARY KEY);
            CREATE TABLE proj_watermark (id int PRIMARY KEY CHECK (id = 1), applied_upto bigint NOT NULL);
            INSERT INTO proj_watermark VALUES (1, 0);
            -- 受保护内容：acl_token 是创建时已提交的关系事件最高序号
            CREATE TABLE post (
              post_id    bigint PRIMARY KEY,
              author     text NOT NULL,
              created_at bigint NOT NULL,
              visibility text NOT NULL CHECK (visibility IN ('PUBLIC','FOLLOWERS','SELF')),
              acl_token  bigint NOT NULL,
              body       text NOT NULL
            );
            CREATE INDEX post_by_author ON post (author, created_at DESC, post_id DESC);
            """);
    }

    public static void resetProjection(Connection c) throws SQLException {
        Db.exec(c, "TRUNCATE proj_follower, proj_count, proj_seen; UPDATE proj_watermark SET applied_upto = 0");
    }
}
