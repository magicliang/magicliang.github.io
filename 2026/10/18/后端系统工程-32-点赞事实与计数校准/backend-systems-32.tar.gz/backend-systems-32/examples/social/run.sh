#!/usr/bin/env bash
# 第 30–32 篇共用入口。用法: ./run.sh 30|31|32|all
# 每章：启动本章集群 -> 重建实验库 -> 编译运行 -> 写 evidence/NN -> 停集群。
set -uo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
COMMON=$(cd "$HERE/../common" && pwd)
EVROOT=$(cd "$HERE/../../evidence" && pwd)
export LAB_BUILD=${LAB_BUILD:-/tmp/batch3-build}

run_chapter() {
  local nn=$1 main=$2
  local port=554$nn name=b3-$nn ev=$EVROOT/$nn
  local dir=${BATCH3_PG_ROOT:-/tmp/batch3-pg}/$name
  # 约定端口被本机其他集群占用（且不是本章集群）时改用 555NN，并写入 env.txt
  local note="port $port (convention)"
  if ! /usr/lib/postgresql/16/bin/pg_ctl -D "$dir" status >/dev/null 2>&1 && (exec 3<>/dev/tcp/127.0.0.1/$port) 2>/dev/null; then
    note="port $port busy (held by a cluster that is not $name), fallback to 555$nn"
    port=555$nn
  fi
  mkdir -p "$ev"
  rm -f "$ev"/output.txt "$ev"/children.log
  {
    echo "date: $(date -Iseconds)"
    echo "uname: $(uname -a)"
    echo "java: $(java -version 2>&1 | tr '\n' ' ')"
    echo "postgres: $(/usr/lib/postgresql/16/bin/postgres --version)"
    echo "pgjdbc: postgresql-42.7.7.jar"
    echo "cluster: $name port $port (fsync=on, max_connections=200); $note"
  } > "$ev/env.txt"
  {
    echo "cd $HERE && ./run.sh $nn"
    echo "  initdb -D /tmp/batch3-pg/$name -U postgres -A trust -E UTF8 --locale=C.UTF-8 -c dynamic_shared_memory_type=mmap  (only if absent)"
    echo "  $COMMON/pg.sh start $name $port"
    echo "  LAB_PGPORT=$port LAB_DB=social$nn EVIDENCE_DIR=$ev LAB_COMMON=$COMMON PG_NAME=$name LAB_BUILD=$LAB_BUILD $COMMON/lab.sh $HERE $main"
    echo "  $COMMON/pg.sh stop $name"
  } > "$ev/commands.txt"
  # 本机 /dev/shm 只有 64MB 且被其他进程占满，POSIX 动态共享内存会让 initdb 失败。
  # 因此先由本脚本以 dynamic_shared_memory_type=mmap 初始化数据目录，pg.sh 发现目录已存在便直接启动。
  if [ ! -f "$dir/PG_VERSION" ]; then
    mkdir -p "$(dirname "$dir")"
    /usr/lib/postgresql/16/bin/initdb -D "$dir" -U postgres -A trust -E UTF8 --locale=C.UTF-8 \
      -c dynamic_shared_memory_type=mmap >/dev/null || return 1
  fi
  echo "initdb: dynamic_shared_memory_type=mmap (see LIMITS.md)" >> "$ev/env.txt"
  "$COMMON/pg.sh" start "$name" "$port" || return 1
  # LAB_COMMON 与 PG_NAME 供第 32 篇的 32-L 调用 pg.sh restart-immediate；30、31 不读取
  LAB_PGPORT=$port LAB_DB=social$nn EVIDENCE_DIR=$ev LAB_COMMON=$COMMON PG_NAME=$name \
    "$COMMON/lab.sh" "$HERE" "$main" > "$ev/output.txt" 2>&1
  local rc=$?
  "$COMMON/pg.sh" stop "$name"
  echo "exit code: $rc" >> "$ev/commands.txt"
  echo "chapter $nn exit=$rc ($(grep '^SUMMARY' "$ev/output.txt" || echo 'no summary'))"
  return $rc
}

target=${1:-all}
rc=0
case "$target" in
  30) run_chapter 30 social.rel.Ch30Main || rc=1 ;;
  31) run_chapter 31 social.feed.Ch31Main || rc=1 ;;
  32) run_chapter 32 social.like.Ch32Main || rc=1 ;;
  all)
    run_chapter 30 social.rel.Ch30Main || rc=1
    run_chapter 31 social.feed.Ch31Main || rc=1
    run_chapter 32 social.like.Ch32Main || rc=1 ;;
  *) echo "usage: $0 30|31|32|all" >&2; exit 2 ;;
esac
exit $rc
