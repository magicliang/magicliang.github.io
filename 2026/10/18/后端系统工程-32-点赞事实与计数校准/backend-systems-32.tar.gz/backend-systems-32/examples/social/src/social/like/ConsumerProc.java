package social.like;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;
import lab.common.Db;

/**
 * 独立 JVM 中运行的计数消费者，供 32-K 用 kill -9 终止。投递位置保存在本地文件（模拟外部传输的消费位点），
 * 只在数据库事务提交之后才写入，因此“已提交但位点未保存”时重启会重投整批。
 * 用法: ConsumerProc <db> <mode: run|die-in-tx|die-after-commit> <offsetFile> <batch>
 */
public final class ConsumerProc {
    public static void main(String[] args) throws Exception {
        String db = args[0], mode = args[1];
        Path offsetFile = Path.of(args[2]);
        int batch = Integer.parseInt(args[3]);
        try (Connection c = DriverManager.getConnection(Db.url(db) + "?ApplicationName=like-consumer", "postgres", "")) {
            long offset = Files.exists(offsetFile) ? Long.parseLong(Files.readString(offsetFile).trim()) : 0;
            System.out.println("START mode=" + mode + " offset=" + offset + " pid=" + ProcessHandle.current().pid());
            CounterConsumer.Stats total = new CounterConsumer.Stats();
            int batchNo = 0;
            while (true) {
                List<CounterConsumer.Ev> evs = CounterConsumer.fetchAfter(c, offset, batch);
                if (evs.isEmpty()) break;
                batchNo++;
                final int bn = batchNo;
                final long first = evs.get(0).seq(), lastSeq = evs.get(evs.size() - 1).seq();
                CounterConsumer cc = new CounterConsumer(c).hook((p, cx) -> {
                    if (mode.equals("die-in-tx") && bn == 2) {
                        System.out.println("PAUSED_IN_TX batch=" + bn + " seq=" + first + ".." + lastSeq);
                        System.out.flush();
                        sleepLong();
                    }
                });
                CounterConsumer.Stats s = cc.apply(evs);
                total.add(s);
                if (mode.equals("die-after-commit") && bn == 2) {
                    System.out.println("COMMITTED_OFFSET_NOT_SAVED batch=" + bn + " seq=" + first + ".." + lastSeq + " " + s);
                    System.out.flush();
                    sleepLong();
                }
                Path tmp = offsetFile.resolveSibling(offsetFile.getFileName() + ".tmp");
                Files.writeString(tmp, Long.toString(lastSeq));
                Files.move(tmp, offsetFile, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
                offset = lastSeq;
            }
            System.out.println("DONE batches=" + batchNo + " " + total);
        }
    }

    /** 停在这里等父进程 kill -9；正常情况下不会返回。 */
    static void sleepLong() {
        try { Thread.sleep(600_000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
