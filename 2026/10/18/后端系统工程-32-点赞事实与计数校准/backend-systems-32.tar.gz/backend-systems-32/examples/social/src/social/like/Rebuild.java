package social.like;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import lab.common.Db;
import social.common.Tx;

/**
 * 批量重算。第一步在一个 REPEATABLE READ 快照里同时读出 S = like_seq.last 与各条目的事实数 C(S)；
 * 由于序号顺序等于提交顺序，这个快照恰好包含序号 1..S 的全部事件效果。
 * 第二步逐条目在短事务里锁计数行，写入 n = C(S) + Σ(已应用且序号 > S 的增量)，base_seq = S。
 * 之后到达的、序号 ≤ S 的事件被消费者识别为 COVERED，不再加增量。
 */
public final class Rebuild {
    private Rebuild() {}

    public record Snapshot(long seq, Map<String, Long> counts) {}

    public record ItemResult(String item, String verdict, long oldN, long newN, long base, long appliedAfter) {
        public String toString() {
            return item + ":" + verdict + "(n " + oldN + "->" + newN + ", base_seq=" + base + ", appliedAfterBase=" + appliedAfter + ")";
        }
    }

    public interface Hook { void at(String point) throws SQLException; }

    public static Snapshot snapshot(Connection c) throws SQLException {
        return Tx.rr(c, cx -> {
            long s = Db.queryLong(cx, "SELECT last FROM like_seq WHERE id = 1");
            Map<String, Long> m = new TreeMap<>();
            try (PreparedStatement ps = cx.prepareStatement(
                    "SELECT i.item_id, count(*) FILTER (WHERE f.liked) FROM item i LEFT JOIN like_fact f USING (item_id) GROUP BY i.item_id");
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) m.put(rs.getString(1), rs.getLong(2));
            }
            return new Snapshot(s, m);
        });
    }

    /** 正确的安装步骤。base_seq 已不小于 S 时说明有更新的重算，跳过。 */
    public static ItemResult install(Connection c, Snapshot snap, String item) throws SQLException {
        return Tx.rc(c, cx -> {
            Db.update(cx, "INSERT INTO like_count(item_id, n, base_seq) VALUES (?, 0, 0) ON CONFLICT DO NOTHING", item);
            long oldN, base;
            try (PreparedStatement ps = cx.prepareStatement("SELECT n, base_seq FROM like_count WHERE item_id = ? FOR UPDATE")) {
                ps.setString(1, item);
                try (ResultSet rs = ps.executeQuery()) { rs.next(); oldN = rs.getLong(1); base = rs.getLong(2); }
            }
            if (base >= snap.seq()) return new ItemResult(item, "stale", oldN, oldN, base, 0);
            long after = Db.queryLong(cx,
                    "SELECT coalesce(sum(o.delta), 0) FROM processed_event p JOIN like_outbox o USING (seq) " +
                    "WHERE o.item_id = ? AND p.seq > ? AND p.how = 'APPLIED'", item, snap.seq());
            long n = snap.counts().getOrDefault(item, 0L) + after;
            Db.update(cx, "UPDATE like_count SET n = ?, base_seq = ? WHERE item_id = ?", n, snap.seq(), item);
            return new ItemResult(item, "installed", oldN, n, snap.seq(), after);
        });
    }

    /** 负向对照：直接用快照里的事实数覆盖计数，不记基线、不补快照之后已应用的增量。 */
    public static ItemResult installNaive(Connection c, Snapshot snap, String item) throws SQLException {
        return Tx.rc(c, cx -> {
            Db.update(cx, "INSERT INTO like_count(item_id, n, base_seq) VALUES (?, 0, 0) ON CONFLICT DO NOTHING", item);
            long oldN = Db.queryLong(cx, "SELECT n FROM like_count WHERE item_id = ? FOR UPDATE", item);
            long n = snap.counts().getOrDefault(item, 0L);
            Db.update(cx, "UPDATE like_count SET n = ? WHERE item_id = ?", n, item);
            return new ItemResult(item, "overwritten", oldN, n, 0, 0);
        });
    }

    public static List<ItemResult> rebuildAll(Connection c, Hook afterSnapshot) throws SQLException {
        Snapshot s = snapshot(c);
        afterSnapshot.at("afterSnapshot");
        List<ItemResult> out = new ArrayList<>();
        for (String item : s.counts().keySet()) out.add(install(c, s, item));
        return out;
    }
}
