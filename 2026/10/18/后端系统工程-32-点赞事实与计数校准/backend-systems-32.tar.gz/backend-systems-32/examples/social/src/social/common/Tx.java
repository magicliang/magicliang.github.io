package social.common;

import java.sql.Connection;
import java.sql.SQLException;
import lab.common.Db;

/**
 * 事务执行器：在给定隔离级别下运行一段代码，遇到 40001/40P01 时整体重试。
 * 回滚和恢复 autocommit 时产生的次生异常只作为 suppressed 附在原始异常上，
 * 调用方拿到的始终是事务体或提交阶段的第一个异常（例如会话被终止时的 57P01/08006，
 * 而不是之后在已关闭连接上操作得到的 08003）。
 */
public final class Tx {
    private Tx() {}

    public interface Body<T> { T run(Connection c) throws SQLException; }

    public static int retries; // 只用于输出观察，不参与判定

    public static <T> T run(Connection c, int isolation, Body<T> body) throws SQLException {
        for (int attempt = 0; ; attempt++) {
            c.setAutoCommit(false);
            c.setTransactionIsolation(isolation);
            Throwable primary = null;
            try {
                T r = body.run(c);
                c.commit();
                return r;
            } catch (SQLException e) {
                primary = e;
                boolean rolledBack = rollback(c, e);
                if (rolledBack && Db.retryable(e) && attempt < 50) {
                    synchronized (Tx.class) { retries++; }
                    primary = null;
                    continue;
                }
                throw e;
            } catch (RuntimeException | Error e) {
                primary = e;
                rollback(c, e);
                throw e;
            } finally {
                restoreAutoCommit(c, primary);
            }
        }
    }

    /** 回滚；失败时把回滚异常挂到原始异常上，返回 false。 */
    private static boolean rollback(Connection c, Throwable primary) {
        try {
            c.rollback();
            return true;
        } catch (SQLException x) {
            primary.addSuppressed(x);
            return false;
        }
    }

    /** 有原始异常时，恢复 autocommit 的失败不得覆盖它；连接已关闭时不再操作。 */
    private static void restoreAutoCommit(Connection c, Throwable primary) throws SQLException {
        try {
            if (!c.isClosed()) c.setAutoCommit(true);
        } catch (SQLException x) {
            if (primary == null) throw x;
            primary.addSuppressed(x);
        }
    }

    public static <T> T rc(Connection c, Body<T> body) throws SQLException {
        return run(c, Connection.TRANSACTION_READ_COMMITTED, body);
    }

    public static <T> T rr(Connection c, Body<T> body) throws SQLException {
        return run(c, Connection.TRANSACTION_REPEATABLE_READ, body);
    }
}
