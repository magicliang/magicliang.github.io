package social.rel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import lab.common.Db;
import social.common.Tx;

/**
 * 关系写入口。所有状态变化在同一事务内：锁住关系行、检查拉黑、改状态并递增版本、写事件。
 * 锁顺序固定为：关系行（按 (follower, followee) 字典序）→ block → event_seq，避免锁环。
 */
public final class RelationService {
    /** 测试用插桩点：在事务内的指定位置暂停，用来构造确定的交错。 */
    public interface Hook { void at(String point) throws SQLException; }
    public static final Hook NO_HOOK = p -> {};

    public enum Outcome { CHANGED, NOOP, REJECTED }

    public record Result(Outcome outcome, String state, long version, long token, String reason) {
        public String toString() {
            return outcome + "(" + state + ",v" + version + (token > 0 ? ",seq" + token : "") +
                   (reason == null ? "" : "," + reason) + ")";
        }
    }

    private final Connection c;
    private Hook hook = NO_HOOK;
    /** 负向对照开关：先检查拉黑再锁关系行（check-then-lock）。 */
    private boolean checkBeforeLock;

    public RelationService(Connection c) { this.c = c; }
    public RelationService hook(Hook h) { this.hook = h; return this; }
    public RelationService checkBeforeLock(boolean v) { this.checkBeforeLock = v; return this; }

    public static void createAccount(Connection c, String user, boolean isPrivate) throws SQLException {
        Db.update(c, "INSERT INTO account(user_id, is_private) VALUES (?, ?)", user, isPrivate);
    }

    // ---------- 内部步骤 ----------

    /** 保证关系行存在并加行锁，返回 {state, version}。占位行为 REMOVED/0，不产生事件。 */
    private String[] lockPair(String follower, String followee) throws SQLException {
        Db.update(c, "INSERT INTO relation(follower, followee, state, version) VALUES (?, ?, 'REMOVED', 0) " +
                     "ON CONFLICT DO NOTHING", follower, followee);
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT state, version FROM relation WHERE follower = ? AND followee = ? FOR UPDATE")) {
            ps.setString(1, follower); ps.setString(2, followee);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return new String[]{rs.getString(1), Long.toString(rs.getLong(2))};
            }
        }
    }

    private boolean blockedEitherWay(String a, String b) throws SQLException {
        return Db.queryLong(c, "SELECT count(*) FROM block WHERE (blocker = ? AND blocked = ?) OR (blocker = ? AND blocked = ?)",
                a, b, b, a) > 0;
    }

    /** 改状态、版本 +1、分配无空洞序号并写事件。返回事件序号。 */
    private long transition(String follower, String followee, String newState, long oldVersion, String cause)
            throws SQLException {
        long v = oldVersion + 1;
        Db.update(c, "UPDATE relation SET state = ?, version = ? WHERE follower = ? AND followee = ?",
                newState, v, follower, followee);
        long seq = nextSeq(c);
        Db.update(c, "INSERT INTO relation_event(seq, follower, followee, state, version, cause) VALUES (?,?,?,?,?,?)",
                seq, follower, followee, newState, v, cause);
        return seq;
    }

    static long nextSeq(Connection c) throws SQLException {
        return Db.queryLong(c, "UPDATE event_seq SET last = last + 1 WHERE id = 1 RETURNING last");
    }

    // ---------- 对外操作 ----------

    public Result follow(String follower, String followee) throws SQLException {
        if (follower.equals(followee)) return new Result(Outcome.REJECTED, null, 0, 0, "self");
        return Tx.rc(c, cx -> {
            String[] cur;
            if (checkBeforeLock) {
                // 错误顺序：检查结果在加锁前就已经过期
                boolean blocked = blockedEitherWay(follower, followee);
                hook.at("follow.afterCheck");
                cur = lockPair(follower, followee);
                if (blocked) return new Result(Outcome.REJECTED, cur[0], Long.parseLong(cur[1]), 0, "blocked");
            } else {
                cur = lockPair(follower, followee);
                hook.at("follow.afterLock");
                // 拉黑事务也必须先锁这一行，所以此处读到的 block 不会在提交前失效
                if (blockedEitherWay(follower, followee))
                    return new Result(Outcome.REJECTED, cur[0], Long.parseLong(cur[1]), 0, "blocked");
            }
            String state = cur[0];
            long ver = Long.parseLong(cur[1]);
            if (!state.equals("REMOVED")) return new Result(Outcome.NOOP, state, ver, 0, "already " + state);
            boolean priv = Db.queryLong(cx, "SELECT count(*) FROM account WHERE user_id = ? AND is_private", followee) > 0;
            String target = priv ? "PENDING" : "ACTIVE";
            long seq = transition(follower, followee, target, ver, priv ? "request" : "follow");
            return new Result(Outcome.CHANGED, target, ver + 1, seq, null);
        });
    }

    public Result unfollow(String follower, String followee) throws SQLException {
        return Tx.rc(c, cx -> {
            String[] cur = lockPair(follower, followee);
            long ver = Long.parseLong(cur[1]);
            if (cur[0].equals("REMOVED")) return new Result(Outcome.NOOP, "REMOVED", ver, 0, "not following");
            long seq = transition(follower, followee, "REMOVED", ver, "unfollow");
            return new Result(Outcome.CHANGED, "REMOVED", ver + 1, seq, null);
        });
    }

    /** 私密账号 owner 审批 requester 的关注请求。只接受 PENDING。 */
    public Result decide(String owner, String requester, boolean approve) throws SQLException {
        return Tx.rc(c, cx -> {
            String[] cur = lockPair(requester, owner);
            long ver = Long.parseLong(cur[1]);
            if (!cur[0].equals("PENDING")) return new Result(Outcome.REJECTED, cur[0], ver, 0, "not pending");
            String target = approve ? "ACTIVE" : "REMOVED";
            long seq = transition(requester, owner, target, ver, approve ? "approve" : "reject");
            return new Result(Outcome.CHANGED, target, ver + 1, seq, null);
        });
    }

    /** 拉黑：同一事务内写 block，并把双向关系都置为 REMOVED（版本递增）。返回最后一个事件序号。 */
    public Result block(String blocker, String blocked) throws SQLException {
        if (blocker.equals(blocked)) return new Result(Outcome.REJECTED, null, 0, 0, "self");
        return Tx.rc(c, cx -> {
            // 按字典序锁两行，和任何单行关注事务都不会形成锁环
            String[][] pairs = blocker.compareTo(blocked) < 0
                    ? new String[][]{{blocker, blocked}, {blocked, blocker}}
                    : new String[][]{{blocked, blocker}, {blocker, blocked}};
            String[][] cur = new String[2][];
            for (int i = 0; i < 2; i++) cur[i] = lockPair(pairs[i][0], pairs[i][1]);
            hook.at("block.afterLock");
            int ins = Db.update(cx, "INSERT INTO block(blocker, blocked) VALUES (?, ?) ON CONFLICT DO NOTHING", blocker, blocked);
            long last = 0;
            for (int i = 0; i < 2; i++) {
                if (!cur[i][0].equals("REMOVED"))
                    last = transition(pairs[i][0], pairs[i][1], "REMOVED", Long.parseLong(cur[i][1]), "block");
            }
            return new Result(ins == 1 || last > 0 ? Outcome.CHANGED : Outcome.NOOP, "BLOCKED", 0, last, null);
        });
    }

    /** 解除拉黑只删除 block 行，不恢复任何旧关系。 */
    public Result unblock(String blocker, String blocked) throws SQLException {
        int n = Db.update(c, "DELETE FROM block WHERE blocker = ? AND blocked = ?", blocker, blocked);
        return new Result(n == 1 ? Outcome.CHANGED : Outcome.NOOP, "UNBLOCKED", 0, 0, null);
    }

    /** 发布受保护内容：acl_token 取同一事务里可见的最高关系事件序号。 */
    public static long createPost(Connection c, long postId, String author, long createdAt, String visibility, String body)
            throws SQLException {
        return Tx.rc(c, cx -> {
            long token = Db.queryLong(cx, "SELECT last FROM event_seq WHERE id = 1");
            Db.update(cx, "INSERT INTO post(post_id, author, created_at, visibility, acl_token, body) VALUES (?,?,?,?,?,?)",
                    postId, author, createdAt, visibility, token, body);
            return token;
        });
    }
}
