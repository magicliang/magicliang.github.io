#!/usr/bin/env bash
# 编译并运行一个示例项目的 Java 主类。
# 用法: lab.sh <project-dir> <main-class> [args...]
# 环境: LAB_PGPORT, LAB_DB 由调用方设置。
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
PROJ=$(cd "$1" && pwd); shift
MAIN=$1; shift
JDBC=${JDBC_JAR:-$HOME/.m2/repository/org/postgresql/postgresql/42.7.7/postgresql-42.7.7.jar}
OUT=${LAB_BUILD:-/tmp/batch3-build}/$(basename "$PROJ")
mkdir -p "$OUT"
find "$HERE/src" "$PROJ/src" -name '*.java' > "$OUT/sources.txt"
javac -encoding UTF-8 -Xlint:none -d "$OUT/classes" -cp "$JDBC" @"$OUT/sources.txt"
exec java -cp "$OUT/classes:$JDBC" "$MAIN" "$@"
