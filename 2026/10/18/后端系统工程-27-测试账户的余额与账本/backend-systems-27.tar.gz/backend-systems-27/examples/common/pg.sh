#!/usr/bin/env bash
# 本批实验用的临时 PostgreSQL 16 集群。数据目录位于 /tmp，不进入交付包。
# 用法: pg.sh start <name> <port> | pg.sh stop <name> | pg.sh psql <port> [args]
set -euo pipefail
PGBIN=${PGBIN:-/usr/lib/postgresql/16/bin}
ROOT=${BATCH3_PG_ROOT:-/tmp/batch3-pg}
cmd=${1:?command}; name=${2:-}; port=${3:-}
case "$cmd" in
  start)
    dir="$ROOT/$name"
    if [ ! -f "$dir/PG_VERSION" ]; then
      mkdir -p "$ROOT"
      # 本机 /dev/shm 仅 64MB 且常被其他进程占满，动态共享内存改用 mmap；不影响事务、锁与 WAL 语义
      "$PGBIN/initdb" -D "$dir" -U postgres -A trust -E UTF8 --locale=C.UTF-8 -c dynamic_shared_memory_type=mmap >/dev/null
    fi
    if ! "$PGBIN/pg_ctl" -D "$dir" status >/dev/null 2>&1; then
      "$PGBIN/pg_ctl" -D "$dir" -w -l "$ROOT/$name.log" \
        -o "-p $port -k /tmp -c listen_addresses=localhost -c max_connections=200 -c fsync=on" start >/dev/null
    fi
    echo "pg $name ready on port $port";;
  stop)
    "$PGBIN/pg_ctl" -D "$ROOT/$name" -m fast stop >/dev/null 2>&1 || true;;
  restart-immediate)
    # 以 immediate 模式停止（不做检查点，等价于崩溃后由 WAL 恢复），再启动
    "$PGBIN/pg_ctl" -D "$ROOT/$name" -m immediate stop >/dev/null 2>&1 || true
    "$PGBIN/pg_ctl" -D "$ROOT/$name" -w -l "$ROOT/$name.log" \
        -o "-p $port -k /tmp -c listen_addresses=localhost -c max_connections=200" start >/dev/null
    echo "pg $name restarted after immediate stop";;
  *) echo "unknown command $cmd" >&2; exit 2;;
esac
