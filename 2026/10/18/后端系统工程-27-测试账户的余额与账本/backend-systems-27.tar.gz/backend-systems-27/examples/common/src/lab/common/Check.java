package lab.common;

import java.util.ArrayList;
import java.util.List;

/**
 * 极简断言与用例记录。每个用例输出一行 CASE，结束时输出汇总；
 * 任一断言失败则进程以非零码退出，证据脚本据此标记 FAIL。
 */
public final class Check {
    private static final List<String> failures = new ArrayList<>();
    private static int passed;
    private static String current = "(none)";

    private Check() {}

    public static void begin(String caseId, String description) {
        current = caseId;
        System.out.println();
        System.out.println("CASE " + caseId + " :: " + description);
    }

    public static void that(boolean cond, String what) {
        if (cond) {
            passed++;
            System.out.println("  ok   " + what);
        } else {
            failures.add(current + ": " + what);
            System.out.println("  FAIL " + what);
        }
    }

    public static void equal(Object expected, Object actual, String what) {
        boolean ok = expected == null ? actual == null : expected.equals(actual);
        that(ok, what + " (expected=" + expected + ", actual=" + actual + ")");
    }

    /** 负向对照：期望错误方案确实暴露问题。断言的是“问题出现”，失败表示对照无效。 */
    public static void exposes(boolean problemObserved, String what) {
        that(problemObserved, "negative control exposes: " + what);
    }

    public static void note(String line) {
        System.out.println("  note " + line);
    }

    public static int finish() {
        System.out.println();
        System.out.println("SUMMARY passed=" + passed + " failed=" + failures.size());
        for (String f : failures) System.out.println("  failed: " + f);
        return failures.isEmpty() ? 0 : 1;
    }
}
