package lab.common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/** 连接本批临时 PostgreSQL 实例。端口与库名来自环境变量 LAB_PGPORT、LAB_DB。 */
public final class Db {
    private Db() {}

    public static String url(String db) {
        String port = System.getenv().getOrDefault("LAB_PGPORT", "55432");
        return "jdbc:postgresql://localhost:" + port + "/" + db;
    }

    public static Connection connect() throws SQLException {
        return connect(System.getenv().getOrDefault("LAB_DB", "postgres"));
    }

    public static Connection connect(String db) throws SQLException {
        return DriverManager.getConnection(url(db), "postgres", "");
    }

    /** 删除并重建实验库，保证每次运行从空状态开始。 */
    public static void recreate(String db) throws SQLException {
        try (Connection c = connect("postgres"); Statement s = c.createStatement()) {
            s.execute("DROP DATABASE IF EXISTS " + db + " WITH (FORCE)");
            s.execute("CREATE DATABASE " + db);
        }
    }

    public static void exec(Connection c, String sql) throws SQLException {
        try (Statement s = c.createStatement()) {
            s.execute(sql);
        }
    }

    public static long queryLong(Connection c, String sql, Object... args) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) throw new SQLException("no row: " + sql);
                return rs.getLong(1);
            }
        }
    }

    public static String queryString(Connection c, String sql, Object... args) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : null;
            }
        }
    }

    public static int update(Connection c, String sql, Object... args) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            return ps.executeUpdate();
        }
    }

    /** SQLSTATE 40001（序列化失败）与 40P01（死锁）属于可重试的事务冲突。 */
    public static boolean retryable(SQLException e) {
        String st = e.getSQLState();
        return "40001".equals(st) || "40P01".equals(st);
    }
}
