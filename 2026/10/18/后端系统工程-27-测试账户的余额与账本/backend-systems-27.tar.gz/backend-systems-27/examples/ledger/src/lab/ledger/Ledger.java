package lab.ledger;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HexFormat;

/**
 * 测试账户账本：余额行 + 复式分录 + 幂等请求表。
 * 一次转移（扣减或发放）在同一个 READ COMMITTED 事务里完成四步：
 * 登记请求、条件扣减、写分录、记录结果。金额单位为“模拟积分”。
 */
public final class Ledger {
    private Ledger() {}

    public static final String SINK = "sys-redeem";   // 积分兑换去向（系统账户）
    public static final String ISSUER = "sys-issuer"; // 积分发放来源（允许为负的系统账户）

    /** outcome: OK / INSUFFICIENT / KEY_REUSED / NO_ACCOUNT。replay 表示结果来自已登记的请求。 */
    public record Result(String outcome, long txnId, long balanceAfter, boolean replay) {
        public String wire() {
            return "outcome=" + outcome + " txn=" + txnId + " balance_after=" + balanceAfter + " replay=" + replay;
        }
    }

    /** 测试注入点：在事务内部、提交之前调用，用于让子进程停在事务中途。 */
    public interface Hook { void at(String point) throws SQLException; }
    public static final Hook NO_HOOK = p -> {};

    public static final String SCHEMA = """
        CREATE TABLE account (
          account_id     text PRIMARY KEY,
          allow_negative boolean NOT NULL DEFAULT false,
          balance        bigint  NOT NULL DEFAULT 0,
          CONSTRAINT balance_non_negative CHECK (allow_negative OR balance >= 0)
        );
        CREATE TABLE idem_request (
          client_id     text NOT NULL,
          idem_key      text NOT NULL,
          request_hash  text NOT NULL,
          outcome       text NOT NULL CHECK (outcome IN ('PENDING','OK','INSUFFICIENT','NO_ACCOUNT')),
          txn_id        bigint,
          balance_after bigint,
          created_at    timestamptz NOT NULL DEFAULT now(),
          PRIMARY KEY (client_id, idem_key)
        );
        CREATE TABLE ledger_txn (
          txn_id     bigserial PRIMARY KEY,
          client_id  text NOT NULL,
          idem_key   text NOT NULL,
          kind       text NOT NULL,
          created_at timestamptz NOT NULL DEFAULT now(),
          UNIQUE (client_id, idem_key)
        );
        CREATE TABLE ledger_entry (
          entry_id   bigserial PRIMARY KEY,
          txn_id     bigint NOT NULL REFERENCES ledger_txn,
          account_id text   NOT NULL REFERENCES account,
          amount     bigint NOT NULL CHECK (amount <> 0)
        );
        CREATE INDEX ledger_entry_account ON ledger_entry (account_id);
        """;

    public static String requestHash(String kind, String from, String to, long amount) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256")
                .digest((kind + "|" + from + "|" + to + "|" + amount).getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(d, 0, 16);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    public static Result debit(Connection c, String client, String key, String account, long amount) throws SQLException {
        return transfer(c, client, key, "DEBIT", account, SINK, amount, NO_HOOK);
    }

    public static Result grant(Connection c, String client, String key, String account, long amount) throws SQLException {
        return transfer(c, client, key, "GRANT", ISSUER, account, amount, NO_HOOK);
    }

    /**
     * 把 amount 从 from 转到 to。调用方传入的连接处于自动提交模式；本方法自行开启并结束事务。
     * 加锁顺序固定为 from 行再 to 行：扣减是 user→sink，发放是 issuer→user，不形成环。
     */
    public static Result transfer(Connection c, String client, String key, String kind,
                                  String from, String to, long amount, Hook hook) throws SQLException {
        if (amount <= 0) throw new IllegalArgumentException("amount must be positive");
        String hash = requestHash(kind, from, to, amount);
        c.setAutoCommit(false);
        try {
            // 第 1 步：登记请求。同键的并发请求在唯一索引上等待先到者结束。
            boolean fresh;
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO idem_request (client_id, idem_key, request_hash, outcome) VALUES (?,?,?,'PENDING') "
                  + "ON CONFLICT (client_id, idem_key) DO NOTHING RETURNING 1")) {
                ps.setString(1, client); ps.setString(2, key); ps.setString(3, hash);
                try (ResultSet rs = ps.executeQuery()) { fresh = rs.next(); }
            }
            if (!fresh) {
                Result r = stored(c, client, key, hash);
                c.rollback();
                return r;
            }
            hook.at("registered");
            // 第 2 步：条件扣减。WHERE 在拿到行锁后对最新版本重新求值。
            Long fromAfter = null;
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE account SET balance = balance - ? "
                  + "WHERE account_id = ? AND (allow_negative OR balance >= ?) RETURNING balance")) {
                ps.setLong(1, amount); ps.setString(2, from); ps.setLong(3, amount);
                try (ResultSet rs = ps.executeQuery()) { if (rs.next()) fromAfter = rs.getLong(1); }
            }
            if (fromAfter == null) {
                boolean exists = lab.common.Db.queryLong(c, "SELECT count(*) FROM account WHERE account_id = ?", from) == 1;
                String outcome = exists ? "INSUFFICIENT" : "NO_ACCOUNT";
                long bal = exists ? lab.common.Db.queryLong(c, "SELECT balance FROM account WHERE account_id = ?", from) : 0;
                finish(c, client, key, outcome, null, bal);
                c.commit();
                return new Result(outcome, 0, bal, false);
            }
            if (lab.common.Db.update(c, "UPDATE account SET balance = balance + ? WHERE account_id = ?", amount, to) != 1)
                throw new SQLException("target account missing: " + to);
            // 第 3 步：写分录，每笔交易的分录之和为 0。
            long txn = lab.common.Db.queryLong(c,
                "INSERT INTO ledger_txn (client_id, idem_key, kind) VALUES (?,?,?) RETURNING txn_id", client, key, kind);
            lab.common.Db.update(c, "INSERT INTO ledger_entry (txn_id, account_id, amount) VALUES (?,?,?), (?,?,?)",
                txn, from, -amount, txn, to, amount);
            hook.at("entries-written");
            // 第 4 步：记录结果，供重试原样返回。
            long reported = kind.equals("GRANT")
                ? lab.common.Db.queryLong(c, "SELECT balance FROM account WHERE account_id = ?", to) : fromAfter;
            finish(c, client, key, "OK", txn, reported);
            hook.at("before-commit");
            c.commit();
            return new Result("OK", txn, reported, false);
        } catch (SQLException | RuntimeException e) {
            try { c.rollback(); } catch (SQLException ignore) { }
            throw e;
        } finally {
            try { c.setAutoCommit(true); } catch (SQLException ignore) { }
        }
    }

    private static void finish(Connection c, String client, String key, String outcome, Long txn, long bal) throws SQLException {
        lab.common.Db.update(c, "UPDATE idem_request SET outcome = ?, txn_id = ?, balance_after = ? WHERE client_id = ? AND idem_key = ?",
            outcome, txn, bal, client, key);
    }

    private static Result stored(Connection c, String client, String key, String hash) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT request_hash, outcome, coalesce(txn_id,0), coalesce(balance_after,0) FROM idem_request WHERE client_id = ? AND idem_key = ?")) {
            ps.setString(1, client); ps.setString(2, key);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) throw new SQLException("idem row vanished: " + key);
                if (!rs.getString(1).equals(hash)) return new Result("KEY_REUSED", 0, 0, true);
                return new Result(rs.getString(2), rs.getLong(3), rs.getLong(4), true);
            }
        }
    }

    public static long balance(Connection c, String account) throws SQLException {
        return lab.common.Db.queryLong(c, "SELECT balance FROM account WHERE account_id = ?", account);
    }

    public static void openAccount(Connection c, String account) throws SQLException {
        lab.common.Db.update(c, "INSERT INTO account (account_id) VALUES (?)", account);
    }
}
