package lab.ledger;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import lab.common.Check;
import lab.common.Db;

/** 第 27 章全部用例。真实 PostgreSQL 16 事务、真实线程、独立 JVM 子进程与 immediate 停机。 */
public final class LedgerLab {
    static final String DB = System.getenv().getOrDefault("LAB_DB", "ledger27");
    static final String NEG_DB = DB + "_neg";
    static final HttpClient HTTP = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1).build();

    public static void main(String[] args) throws Exception {
        Db.recreate(DB);
        Db.recreate(NEG_DB);
        try (Connection c = Db.connect(DB)) { setup(c); }
        try (Connection c = Db.connect(NEG_DB)) { setup(c); }
        try (LedgerServer server = new LedgerServer()) {
            normal();
            boundary(server);
            concurrentDebits();
            lostUpdateControl();
            overdraftWithoutCheckControl();
            checkIsLastLineOnly();
            timeoutRetry(server);
            sameKeyConcurrent(server);
            killMidTransaction();
            restartImmediate();
            reconciliation();
        }
        System.exit(Check.finish());
    }

    static void setup(Connection c) throws SQLException {
        Db.exec(c, Ledger.SCHEMA);
        Db.update(c, "INSERT INTO account (account_id, allow_negative) VALUES (?, true), (?, false)", Ledger.ISSUER, Ledger.SINK);
    }

    static Connection conn() throws SQLException { return Db.connect(DB); }

    static void fund(Connection c, String acct, long amt) throws SQLException {
        Ledger.openAccount(c, acct);
        Ledger.grant(c, "lab", "grant-" + acct, acct, amt);
    }

    static void normal() throws Exception {
        Check.begin("L1", "正常路径：发放 1000，扣减 300，分录平衡");
        try (Connection c = conn()) {
            fund(c, "acct-0001", 1000);
            Ledger.Result r = Ledger.debit(c, "app-a", "k-0001", "acct-0001", 300);
            Check.equal("OK", r.outcome(), "扣减结果");
            Check.equal(700L, Ledger.balance(c, "acct-0001"), "余额");
            Check.equal(0L, Db.queryLong(c, "SELECT sum(amount) FROM ledger_entry WHERE txn_id = ?", r.txnId()), "该笔交易分录和");
            Check.equal(2L, Db.queryLong(c, "SELECT count(*) FROM ledger_entry WHERE txn_id = ?", r.txnId()), "该笔交易分录条数");
        }
    }

    static void boundary(LedgerServer s) throws Exception {
        Check.begin("L2", "边界：恰好扣到 0、再扣 1 被拒、拒绝结果可重放、非法输入");
        try (Connection c = conn()) {
            fund(c, "acct-0002", 50);
            Check.equal("OK", Ledger.debit(c, "app-a", "k-0201", "acct-0002", 50).outcome(), "扣减等于余额");
            Check.equal(0L, Ledger.balance(c, "acct-0002"), "余额为 0");
            Ledger.Result r = Ledger.debit(c, "app-a", "k-0202", "acct-0002", 1);
            Check.equal("INSUFFICIENT", r.outcome(), "余额 0 时扣 1");
            Ledger.grant(c, "lab", "grant-acct-0002-b", "acct-0002", 10);
            Ledger.Result again = Ledger.debit(c, "app-a", "k-0202", "acct-0002", 1);
            Check.that(again.replay() && again.outcome().equals("INSUFFICIENT"), "补足余额后用同键重试，返回已登记的 INSUFFICIENT（replay=" + again.replay() + "）");
            Check.equal("OK", Ledger.debit(c, "app-a", "k-0203", "acct-0002", 1).outcome(), "换新键后扣 1 成功");
            Check.equal(9L, Ledger.balance(c, "acct-0002"), "余额");
        }
        Check.equal(400, post(s, "app-a", "k-0204", "acct-0002", "amount=0", 2000).statusCode(), "amount=0 返回 400");
        Check.equal(400, post(s, "app-a", null, "acct-0002", "amount=5", 2000).statusCode(), "缺 Idempotency-Key 返回 400");
        Check.equal(404, post(s, "app-a", "k-0205", "acct-9999", "amount=5", 2000).statusCode(), "未知账户返回 404");
        Check.equal(409, post(s, "app-a", "k-0206", "acct-0002", "amount=10", 2000).statusCode(), "余额 9 扣 10 返回 409");
    }

    static void concurrentDebits() throws Exception {
        Check.begin("L3", "真实并发：32 线程各扣 7，初始余额 100，条件更新");
        try (Connection c = conn()) { fund(c, "acct-0003", 100); }
        AtomicInteger ok = new AtomicInteger(), insufficient = new AtomicInteger();
        runThreads(32, i -> {
            try (Connection c = conn()) {
                String out = Ledger.debit(c, "app-a", "k-03-" + i, "acct-0003", 7).outcome();
                (out.equals("OK") ? ok : insufficient).incrementAndGet();
            }
        });
        try (Connection c = conn()) {
            Check.note("ok=" + ok + " insufficient=" + insufficient + " balance=" + Ledger.balance(c, "acct-0003"));
            Check.equal(14, ok.get(), "成功次数 = floor(100/7)");
            Check.equal(18, insufficient.get(), "余额不足次数");
            Check.equal(2L, Ledger.balance(c, "acct-0003"), "最终余额");
            Check.equal(14L, Db.queryLong(c, "SELECT count(*) FROM ledger_entry WHERE account_id = 'acct-0003' AND amount < 0"), "扣减分录条数");
        }
    }

    /** 负向对照 1：READ COMMITTED 下先读余额、应用内判断、再写回绝对值。 */
    static void lostUpdateControl() throws Exception {
        Check.begin("L4", "负向对照：先读后写（绝对值写回），32 线程在读后汇合");
        try (Connection c = Db.connect(NEG_DB)) {
            Ledger.openAccount(c, "acct-0004");
            Ledger.grant(c, "lab", "grant-0004", "acct-0004", 100);
        }
        CyclicBarrier afterRead = new CyclicBarrier(32);
        AtomicInteger ok = new AtomicInteger();
        runThreads(32, i -> {
            try (Connection c = Db.connect(NEG_DB)) {
                c.setAutoCommit(false);
                long bal = Db.queryLong(c, "SELECT balance FROM account WHERE account_id = 'acct-0004'");
                afterRead.await(10, TimeUnit.SECONDS);
                if (bal >= 7) {
                    Db.update(c, "UPDATE account SET balance = ? WHERE account_id = 'acct-0004'", bal - 7);
                    Db.update(c, "UPDATE account SET balance = balance + 7 WHERE account_id = ?", Ledger.SINK);
                    long txn = Db.queryLong(c, "INSERT INTO ledger_txn (client_id, idem_key, kind) VALUES ('naive', ?, 'DEBIT') RETURNING txn_id", "n-04-" + i);
                    Db.update(c, "INSERT INTO ledger_entry (txn_id, account_id, amount) VALUES (?, 'acct-0004', -7), (?, ?, 7)", txn, txn, Ledger.SINK);
                    ok.incrementAndGet();
                }
                c.commit();
            }
        });
        try (Connection c = Db.connect(NEG_DB)) {
            long bal = Ledger.balance(c, "acct-0004");
            long entries = Db.queryLong(c, "SELECT coalesce(-sum(amount),0) FROM ledger_entry WHERE account_id = 'acct-0004' AND amount < 0");
            Check.note("naive ok=" + ok + " stored balance=" + bal + " debited by entries=" + entries);
            Check.exposes(ok.get() > 14, "成功次数 " + ok + " 超过余额允许的 14 次");
            Check.exposes(bal != 100 - entries, "丢失更新：余额 " + bal + " ≠ 100 - 分录扣减 " + entries);
        }
    }

    /** 负向对照 2：无 CHECK 的表上先读判断再相对扣减，真实透支。 */
    static void overdraftWithoutCheckControl() throws Exception {
        Check.begin("L5", "负向对照：无 CHECK 表上先读判断、再相对扣减");
        try (Connection c = Db.connect(NEG_DB)) {
            Db.exec(c, "CREATE TABLE naive_account (account_id text PRIMARY KEY, balance bigint NOT NULL)");
            Db.exec(c, "INSERT INTO naive_account VALUES ('acct-0005', 100)");
        }
        CyclicBarrier afterRead = new CyclicBarrier(32);
        runThreads(32, i -> {
            try (Connection c = Db.connect(NEG_DB)) {
                c.setAutoCommit(false);
                long bal = Db.queryLong(c, "SELECT balance FROM naive_account WHERE account_id = 'acct-0005'");
                afterRead.await(10, TimeUnit.SECONDS);
                if (bal >= 7) Db.update(c, "UPDATE naive_account SET balance = balance - 7 WHERE account_id = 'acct-0005'");
                c.commit();
            }
        });
        try (Connection c = Db.connect(NEG_DB)) {
            long bal = Db.queryLong(c, "SELECT balance FROM naive_account WHERE account_id = 'acct-0005'");
            Check.note("naive balance=" + bal);
            Check.exposes(bal < 0, "余额被扣成负数 " + bal);
        }
    }

    /** CHECK 拦住透支，但拦不住重复扣款。 */
    static void checkIsLastLineOnly() throws Exception {
        Check.begin("L6", "CHECK 只防透支：先读判断+相对扣减被 23514 拦下；换键重发两次照样扣两次");
        try (Connection c = Db.connect(NEG_DB)) {
            Ledger.openAccount(c, "acct-0006");
            Ledger.grant(c, "lab", "grant-0006", "acct-0006", 100);
        }
        CyclicBarrier afterRead = new CyclicBarrier(32);
        AtomicInteger ok = new AtomicInteger(), checkViolation = new AtomicInteger();
        runThreads(32, i -> {
            try (Connection c = Db.connect(NEG_DB)) {
                c.setAutoCommit(false);
                long bal = Db.queryLong(c, "SELECT balance FROM account WHERE account_id = 'acct-0006'");
                afterRead.await(10, TimeUnit.SECONDS);
                try {
                    if (bal >= 7) Db.update(c, "UPDATE account SET balance = balance - 7 WHERE account_id = 'acct-0006'");
                    c.commit();
                    ok.incrementAndGet();
                } catch (SQLException e) {
                    c.rollback();
                    if ("23514".equals(e.getSQLState())) checkViolation.incrementAndGet(); else throw e;
                }
            }
        });
        try (Connection c = Db.connect(NEG_DB)) {
            long bal = Ledger.balance(c, "acct-0006");
            Check.note("ok=" + ok + " check_violation(23514)=" + checkViolation + " balance=" + bal);
            Check.that(bal >= 0, "CHECK 保住余额非负");
            Check.equal(18, checkViolation.get(), "被 CHECK 拒绝的扣减数");
            // 同一个业务请求，客户端超时后换了新键重发：两次都满足 CHECK
            Ledger.openAccount(c, "acct-0016");
            Ledger.grant(c, "lab", "grant-0016", "acct-0016", 100);
            Ledger.debit(c, "app-a", "order-77-try1", "acct-0016", 30);
            Ledger.debit(c, "app-a", "order-77-try2", "acct-0016", 30);
            Check.exposes(Ledger.balance(c, "acct-0016") == 40, "同一业务请求换键重发被扣两次，余额 " + Ledger.balance(c, "acct-0016") + "，CHECK 未触发");
        }
    }

    static void timeoutRetry(LedgerServer s) throws Exception {
        Check.begin("L7", "提交后响应丢失：客户端超时，用同一个键重试，只扣一次");
        try (Connection c = conn()) { fund(c, "acct-0007", 100); fund(c, "acct-0017", 100); }
        s.dropResponseAfterCommit.add("k-0701");
        boolean timedOut = false;
        try { post(s, "app-a", "k-0701", "acct-0007", "amount=30", 400); }
        catch (HttpTimeoutException e) { timedOut = true; }
        Check.that(timedOut, "第一次请求在客户端超时（400ms）");
        try (Connection c = conn()) {
            Check.equal(70L, Ledger.balance(c, "acct-0007"), "超时时服务端已提交，余额已是 70");
        }
        HttpResponse<String> retry = post(s, "app-a", "k-0701", "acct-0007", "amount=30", 3000);
        Check.note("retry status=" + retry.statusCode() + " replayed=" + retry.headers().firstValue("Idempotent-Replayed").orElse("-") + " body=" + retry.body());
        Check.equal(201, retry.statusCode(), "重试返回原状态码");
        Check.equal("true", retry.headers().firstValue("Idempotent-Replayed").orElse("-"), "重试带 Idempotent-Replayed");
        try (Connection c = conn()) {
            Check.equal(70L, Ledger.balance(c, "acct-0007"), "重试后余额仍为 70");
            Check.equal(1L, Db.queryLong(c, "SELECT count(*) FROM ledger_txn WHERE idem_key = 'k-0701'"), "该键只有一笔交易");
        }
        // 对照：同样超时，但客户端换新键重发
        s.dropResponseAfterCommit.add("k-1701");
        try { post(s, "app-a", "k-1701", "acct-0017", "amount=30", 400); } catch (HttpTimeoutException ignore) { }
        post(s, "app-a", "k-1702", "acct-0017", "amount=30", 3000);
        try (Connection c = conn()) {
            long b = Ledger.balance(c, "acct-0017");
            Check.exposes(b == 40, "超时后换新键重发，余额 " + b + "（扣了两次）");
            Check.equal(0, Recon.run(c).size(), "这种重复扣款在账本内部仍然平衡，对账查不出");
        }
        Check.equal(2, s.droppedResponses.get(), "服务端丢弃响应次数");
    }

    static void sameKeyConcurrent(LedgerServer s) throws Exception {
        Check.begin("L8", "同键 16 个请求同时到达，结果一致；同键不同金额返回 422");
        try (Connection c = conn()) { fund(c, "acct-0008", 100); }
        Set<String> bodies = ConcurrentHashMap.newKeySet();
        AtomicInteger fresh = new AtomicInteger(), replayed = new AtomicInteger();
        runThreads(16, i -> {
            HttpResponse<String> r = post(s, "app-a", "k-0801", "acct-0008", "amount=25", 5000);
            bodies.add(r.statusCode() + " " + r.body().replace(" replay=true", "").replace(" replay=false", ""));
            (r.headers().firstValue("Idempotent-Replayed").isPresent() ? replayed : fresh).incrementAndGet();
        });
        Check.note("distinct responses=" + bodies + " fresh=" + fresh + " replayed=" + replayed);
        Check.equal(1, bodies.size(), "16 个响应的状态码、txn、余额完全相同");
        Check.equal(1, fresh.get(), "只有一个请求真正执行");
        try (Connection c = conn()) {
            Check.equal(75L, Ledger.balance(c, "acct-0008"), "只扣一次");
        }
        HttpResponse<String> mismatch = post(s, "app-a", "k-0801", "acct-0008", "amount=26", 3000);
        Check.equal(422, mismatch.statusCode(), "同键不同载荷返回 422（" + mismatch.body() + "）");
        HttpResponse<String> otherClient = post(s, "app-b", "k-0801", "acct-0008", "amount=25", 3000);
        Check.equal(201, otherClient.statusCode(), "另一客户端使用相同键字符串，作为独立请求执行");
    }

    static void killMidTransaction() throws Exception {
        Check.begin("L9", "子 JVM 在事务中途被 kill -9：回滚；等待中的同键请求随后执行");
        try (Connection c = conn()) { fund(c, "acct-0009", 100); }
        Process p = new ProcessBuilder(javaBin(), "-cp", System.getProperty("java.class.path"),
            "lab.ledger.CrashWorker", "app-a", "k-0901", "acct-0009", "40").redirectErrorStream(true).start();
        BufferedReader out = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line = out.readLine();
        Check.that(line != null && line.startsWith("PAUSED_IN_TX"), "子进程停在提交前：" + line);
        try (Connection c = conn()) {
            String st = Db.queryString(c, "SELECT state FROM pg_stat_activity WHERE application_name = 'ledger-crash-worker'");
            Check.equal("idle in transaction", st, "数据库看到子进程会话处于事务中");
            Check.equal(100L, Ledger.balance(c, "acct-0009"), "其他会话读不到未提交扣减");
        }
        CompletableFuture<Ledger.Result> waiter = CompletableFuture.supplyAsync(() -> {
            try (Connection c = conn()) { return Ledger.debit(c, "app-a", "k-0901", "acct-0009", 40); }
            catch (SQLException e) { throw new RuntimeException(e); }
        });
        Thread.sleep(500);
        Check.that(!waiter.isDone(), "同键请求在唯一索引上等待子进程事务结束");
        new ProcessBuilder("kill", "-9", Long.toString(p.pid())).inheritIO().start().waitFor();
        Check.note("child exit=" + p.waitFor());
        Ledger.Result r = waiter.get(30, TimeUnit.SECONDS);
        Check.that(r.outcome().equals("OK") && !r.replay(), "子进程回滚后，等待者作为首个请求执行（" + r.wire() + "）");
        try (Connection c = conn()) {
            Check.equal(60L, Ledger.balance(c, "acct-0009"), "最终只扣一次 40");
            Check.equal(1L, Db.queryLong(c, "SELECT count(*) FROM ledger_txn WHERE idem_key = 'k-0901'"), "该键一笔交易");
            Check.equal(0L, Db.queryLong(c, "SELECT count(*) FROM pg_stat_activity WHERE application_name = 'ledger-crash-worker'"), "子进程会话已被服务端清理");
        }
    }

    static void restartImmediate() throws Exception {
        Check.begin("L10", "已提交扣减在 pg.sh restart-immediate 后仍在；未提交的消失");
        try (Connection c = conn()) {
            fund(c, "acct-0010", 100);
            Check.equal("OK", Ledger.debit(c, "app-a", "k-1001", "acct-0010", 10).outcome(), "提交扣减 10");
        }
        Connection open = conn();
        open.setAutoCommit(false);
        Db.update(open, "UPDATE account SET balance = balance - 20 WHERE account_id = 'acct-0010'");
        String sh = System.getenv("LAB_PG_SH"), name = System.getenv("LAB_PG_NAME"), port = System.getenv("LAB_PGPORT");
        Process p = new ProcessBuilder("bash", sh, "restart-immediate", name, port).redirectErrorStream(true).start();
        String msg = new String(p.getInputStream().readAllBytes()).trim();
        Check.equal(0, p.waitFor(), "restart-immediate 退出码（" + msg + "）");
        boolean broken = false;
        try { open.commit(); } catch (SQLException e) { broken = true; }
        Check.that(broken, "停机前打开的事务连接已失效");
        try (Connection c = conn()) {
            Check.note("after restart: fsync=" + Db.queryString(c, "SHOW fsync") + " synchronous_commit=" + Db.queryString(c, "SHOW synchronous_commit"));
            Check.equal(90L, Ledger.balance(c, "acct-0010"), "已提交的 10 仍在，未提交的 20 不在");
            Check.equal("OK", Db.queryString(c, "SELECT outcome FROM idem_request WHERE idem_key = 'k-1001'"), "幂等记录仍在");
            Ledger.Result r = Ledger.debit(c, "app-a", "k-1001", "acct-0010", 10);
            Check.that(r.replay() && r.balanceAfter() == 90, "重启后同键重试返回原结果（" + r.wire() + "）");
        }
    }

    static void reconciliation() throws Exception {
        Check.begin("L11", "对账：从分录重算余额，每笔交易和为 0，请求与交易一一对应");
        try (Connection c = conn()) {
            List<String> p = Recon.run(c);
            Check.note("accounts=" + Db.queryLong(c, "SELECT count(*) FROM account") + " txns=" + Db.queryLong(c, "SELECT count(*) FROM ledger_txn")
                + " entries=" + Db.queryLong(c, "SELECT count(*) FROM ledger_entry") + " requests=" + Db.queryLong(c, "SELECT count(*) FROM idem_request"));
            Check.equal(List.of(), p, "主库对账无差异");
            Db.update(c, "UPDATE account SET balance = balance + 5 WHERE account_id = 'acct-0001'");
            List<String> tampered = Recon.run(c);
            Check.note("tampered: " + tampered);
            Check.exposes(tampered.stream().anyMatch(x -> x.startsWith("balance acct-0001")), "绕过账本改余额被重算发现");
            Db.update(c, "UPDATE account SET balance = balance - 5 WHERE account_id = 'acct-0001'");
            Check.equal(List.of(), Recon.run(c), "改回后对账恢复无差异");
        }
        try (Connection c = Db.connect(NEG_DB)) {
            List<String> p = Recon.run(c);
            Check.note("negative db: " + p.stream().filter(x -> !x.startsWith("request")).toList()
                + " + " + p.stream().filter(x -> x.startsWith("request")).count() + " 笔交易没有对应的幂等登记（naive 路径不登记）");
            Check.exposes(p.stream().anyMatch(x -> x.startsWith("balance acct-0004")), "L4 的丢失更新被对账发现");
        }
    }

    // ---------- helpers ----------
    interface Body { void run(int i) throws Exception; }

    static void runThreads(int n, Body body) throws Exception {
        CountDownLatch start = new CountDownLatch(1);
        List<Thread> ts = new ArrayList<>();
        List<Throwable> errors = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            final int id = i;
            Thread t = new Thread(() -> {
                try { start.await(); body.run(id); }
                catch (Throwable e) { synchronized (errors) { errors.add(e); } }
            });
            t.start(); ts.add(t);
        }
        start.countDown();
        for (Thread t : ts) t.join(60_000);
        if (!errors.isEmpty()) throw new IllegalStateException("thread error", errors.get(0));
    }

    static HttpResponse<String> post(LedgerServer s, String client, String key, String acct, String body, int timeoutMs) throws Exception {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + s.port() + "/accounts/" + acct + "/debits"))
            .timeout(Duration.ofMillis(timeoutMs)).header("X-Client-Id", client)
            .POST(HttpRequest.BodyPublishers.ofString(body));
        if (key != null) b.header("Idempotency-Key", key);
        return HTTP.send(b.build(), HttpResponse.BodyHandlers.ofString());
    }

    static String javaBin() {
        return ProcessHandle.current().info().command().orElse("java");
    }
}
