package lab.ledger;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 扣减接口：POST /accounts/{id}/debits，头 Idempotency-Key 与 X-Client-Id，正文 amount=N。
 * 状态码：201 新扣减成功；同键重放返回原状态码并带 Idempotent-Replayed: true；
 * 409 余额不足（结果已登记，重放返回同样结果）；422 同键不同载荷；400 缺键或金额非法；404 账户不存在。
 */
public final class LedgerServer implements AutoCloseable {
    private final HttpServer http;
    /** 故障注入：这些键第一次处理时，事务提交后不写响应，延迟后直接断开。 */
    public final Set<String> dropResponseAfterCommit = ConcurrentHashMap.newKeySet();
    public final AtomicInteger droppedResponses = new AtomicInteger();

    public LedgerServer() throws IOException {
        http = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 64);
        http.setExecutor(Executors.newFixedThreadPool(16));
        http.createContext("/accounts/", this::handle);
        http.start();
    }

    public int port() { return http.getAddress().getPort(); }

    private void handle(HttpExchange ex) throws IOException {
        try (ex) {
            String[] parts = ex.getRequestURI().getPath().split("/");
            String key = ex.getRequestHeaders().getFirst("Idempotency-Key");
            String client = ex.getRequestHeaders().getFirst("X-Client-Id");
            String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8).trim();
            if (!"POST".equals(ex.getRequestMethod()) || parts.length != 4 || !"debits".equals(parts[3])) {
                reply(ex, 404, "outcome=NOT_FOUND", false); return;
            }
            if (key == null || key.isBlank() || client == null || !body.startsWith("amount=")) {
                reply(ex, 400, "outcome=BAD_REQUEST", false); return;
            }
            long amount;
            try { amount = Long.parseLong(body.substring(7)); } catch (NumberFormatException e) { amount = -1; }
            if (amount <= 0) { reply(ex, 400, "outcome=BAD_AMOUNT", false); return; }
            Ledger.Result r;
            try (Connection c = lab.common.Db.connect()) {
                c.setClientInfo("ApplicationName", "ledger-server");
                r = Ledger.debit(c, client, key, parts[2], amount);
            }
            if (!r.replay() && dropResponseAfterCommit.remove(key)) {
                droppedResponses.incrementAndGet();
                Thread.sleep(1500);   // 已提交；客户端在此期间超时，随后连接被关闭且没有响应
                return;
            }
            int status = switch (r.outcome()) {
                case "OK" -> 201;
                case "INSUFFICIENT" -> 409;
                case "KEY_REUSED" -> 422;
                default -> 404;
            };
            reply(ex, status, r.wire(), r.replay() && !"KEY_REUSED".equals(r.outcome()));
        } catch (Exception e) {
            try { reply(ex, 500, "outcome=ERROR " + e.getMessage(), false); } catch (IOException ignore) { }
        }
    }

    private static void reply(HttpExchange ex, int status, String text, boolean replay) throws IOException {
        byte[] b = text.getBytes(StandardCharsets.UTF_8);
        if (replay) ex.getResponseHeaders().add("Idempotent-Replayed", "true");
        ex.sendResponseHeaders(status, b.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(b); }
    }

    @Override public void close() { http.stop(0); }
}
