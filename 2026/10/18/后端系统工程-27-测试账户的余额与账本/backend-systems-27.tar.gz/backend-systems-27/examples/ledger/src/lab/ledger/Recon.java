package lab.ledger;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * 对账：只读查询，从分录重算余额并检查交易平衡与请求-交易对应。返回问题列表，空表示通过。
 * 四条查询放在同一个 REPEATABLE READ 只读事务里，共用一个快照，避免对账期间新提交的交易造成假差异。
 */
public final class Recon {
    private Recon() {}

    public static final String BALANCE_VS_ENTRIES = """
        SELECT a.account_id, a.balance, coalesce(sum(e.amount), 0) AS recomputed
        FROM account a LEFT JOIN ledger_entry e ON e.account_id = a.account_id
        GROUP BY a.account_id, a.balance
        HAVING a.balance <> coalesce(sum(e.amount), 0)
        """;
    public static final String UNBALANCED_TXN = """
        SELECT t.txn_id, coalesce(sum(e.amount), 0) AS total, count(e.entry_id) AS n
        FROM ledger_txn t LEFT JOIN ledger_entry e ON e.txn_id = t.txn_id
        GROUP BY t.txn_id
        HAVING coalesce(sum(e.amount), 0) <> 0 OR count(e.entry_id) < 2
        """;
    public static final String REQUEST_TXN_MISMATCH = """
        SELECT r.client_id, r.idem_key, r.outcome, r.txn_id, t.txn_id
        FROM idem_request r FULL JOIN ledger_txn t
          ON t.client_id = r.client_id AND t.idem_key = r.idem_key
        WHERE (r.outcome = 'OK' AND (t.txn_id IS NULL OR t.txn_id <> r.txn_id))
           OR (r.outcome IS DISTINCT FROM 'OK' AND t.txn_id IS NOT NULL)
           OR r.outcome = 'PENDING'
        """;
    public static final String GLOBAL_SUM = "SELECT coalesce(sum(balance), 0) FROM account";

    public static List<String> run(Connection c) throws SQLException {
        List<String> problems = new ArrayList<>();
        boolean auto = c.getAutoCommit();
        int iso = c.getTransactionIsolation();
        c.setAutoCommit(false);
        c.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
        c.setReadOnly(true);
        try (Statement s = c.createStatement()) {
            try (ResultSet rs = s.executeQuery(BALANCE_VS_ENTRIES)) {
                while (rs.next()) problems.add("balance " + rs.getString(1) + " stored=" + rs.getLong(2) + " recomputed=" + rs.getLong(3));
            }
            try (ResultSet rs = s.executeQuery(UNBALANCED_TXN)) {
                while (rs.next()) problems.add("txn " + rs.getLong(1) + " sum=" + rs.getLong(2) + " entries=" + rs.getLong(3));
            }
            try (ResultSet rs = s.executeQuery(REQUEST_TXN_MISMATCH)) {
                while (rs.next()) problems.add("request " + rs.getString(2) + " outcome=" + rs.getString(3) + " txn=" + rs.getObject(4) + "/" + rs.getObject(5));
            }
            try (ResultSet rs = s.executeQuery(GLOBAL_SUM)) {
                rs.next();
                if (rs.getLong(1) != 0) problems.add("global balance sum=" + rs.getLong(1));
            }
            c.commit();
        } catch (SQLException e) {
            c.rollback();
            throw e;
        } finally {
            c.setReadOnly(false);
            c.setTransactionIsolation(iso);
            c.setAutoCommit(auto);
        }
        return problems;
    }
}
