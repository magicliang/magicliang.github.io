package lab.ledger;

import java.sql.Connection;

/**
 * 独立 JVM：执行一次扣减，在分录写完、提交之前停住，等待父进程 kill -9。
 * 参数：client key account amount
 */
public final class CrashWorker {
    public static void main(String[] a) throws Exception {
        try (Connection c = lab.common.Db.connect()) {
            c.setClientInfo("ApplicationName", "ledger-crash-worker");
            Ledger.transfer(c, a[0], a[1], "DEBIT", a[2], Ledger.SINK, Long.parseLong(a[3]), point -> {
                if (point.equals("before-commit")) {
                    System.out.println("PAUSED_IN_TX pid=" + ProcessHandle.current().pid());
                    System.out.flush();
                    try { Thread.sleep(120_000); } catch (InterruptedException ignore) { }
                }
            });
            System.out.println("UNEXPECTED_COMMIT");
        }
    }
}
