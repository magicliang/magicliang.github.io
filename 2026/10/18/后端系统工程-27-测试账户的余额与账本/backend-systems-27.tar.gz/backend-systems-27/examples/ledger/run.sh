#!/usr/bin/env bash
# 第 27 章：一条命令完成 启动集群 → 建库 → 编译 → 运行全部用例 → 写证据 → 停集群。
set -uo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
COMMON="$HERE/../common"
EVID="$HERE/../../evidence/27"
NAME=b3-27; PORT=55427
mkdir -p "$EVID"
export LAB_PGPORT=$PORT LAB_DB=ledger27 LAB_PG_SH="$COMMON/pg.sh" LAB_PG_NAME=$NAME LAB_BUILD=/tmp/batch3-build/ch27
{
  echo "date: $(date -Is)"
  echo "uname: $(uname -a)"
  java -version 2>&1 | sed 's/^/java: /'
  echo "postgres: $(/usr/lib/postgresql/16/bin/postgres --version)"
  echo "pgjdbc: postgresql-42.7.7.jar"
} > "$EVID/env.txt"
cat > "$EVID/commands.txt" <<CMD
cd examples/ledger && ./run.sh
  initdb -D /tmp/batch3-pg/$NAME -U postgres -A trust -E UTF8 --locale=C.UTF-8 -c dynamic_shared_memory_type=mmap（仅首次）
  ../common/pg.sh start $NAME $PORT
  LAB_PGPORT=$PORT LAB_DB=ledger27 LAB_PG_SH=../common/pg.sh LAB_PG_NAME=$NAME ../common/lab.sh . lab.ledger.LedgerLab
  （L10 用例内部调用 ../common/pg.sh restart-immediate $NAME $PORT；L9 用例内部对子 JVM 执行 kill -9 <pid>）
  ../common/pg.sh stop $NAME
CMD
# 本机 /dev/shm 仅 64MB 且被其他进程占满，PostgreSQL 默认的 posix 动态共享内存会失败；
# 预先用相同参数 initdb 并改用 mmap（文件位于数据目录内），pg.sh 检测到 PG_VERSION 后不再 initdb。
PGDIR=${BATCH3_PG_ROOT:-/tmp/batch3-pg}/$NAME
if [ ! -f "$PGDIR/PG_VERSION" ]; then
  mkdir -p "$(dirname "$PGDIR")"
  /usr/lib/postgresql/16/bin/initdb -D "$PGDIR" -U postgres -A trust -E UTF8 --locale=C.UTF-8 \
    -c dynamic_shared_memory_type=mmap >/dev/null
fi
"$COMMON/pg.sh" start $NAME $PORT
"$COMMON/lab.sh" "$HERE" lab.ledger.LedgerLab > "$EVID/output.txt" 2>&1
rc=$?
"$COMMON/pg.sh" stop $NAME
echo "exit=$rc" >> "$EVID/commands.txt"
tail -n 3 "$EVID/output.txt"
exit $rc
