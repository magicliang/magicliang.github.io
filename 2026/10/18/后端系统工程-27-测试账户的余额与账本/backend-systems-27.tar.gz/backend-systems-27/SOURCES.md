# SOURCES：第 24–35 篇技术依据

按章节汇总来源卡。核对方式取值：已读原文（URL 可访问）、本地 man 页、仅书目信息（本环境无法取得全文）。仅有书目信息的论文只用于说明概念出处，不支撑细节论断。公共运行环境版本见 `CONVENTIONS.md` 第 2 节。

## 来源卡：第 24 篇 在线变更的数据兼容

适用版本：PostgreSQL 16.15（本地服务端）；文档一律核对 16 版。核对日期均为 2026-10-19。

| 论断 | 来源（标准/论文/官方文档/源码，含章节） | 版本 | 核对日期 | 核对方式 | 对应实验 |
|---|---|---|---|---|---|
| ALTER TABLE 默认取 ACCESS EXCLUSIVE，多子命令取最严格者 | ALTER TABLE，Description 首段（https://www.postgresql.org/docs/16/sql-altertable.html） | 16 | 2026-10-19 | 已读原文（URL 可访问）；本地 man 页 ALTER_TABLE.7 一致 | S2、S4 |
| ADD COLUMN 不带 DEFAULT 或带非易变 DEFAULT 不重写表；易变 DEFAULT 需要重写表和索引 | ALTER TABLE，Notes 第 2、3 段 | 16 | 2026-10-19 | 已读原文（URL 可访问）；本地 man 页 | S4 |
| 非易变默认值存于 pg_attribute.atthasmissing / attmissingval | 53.7 pg_attribute（https://www.postgresql.org/docs/16/catalog-pg-attribute.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | S4 |
| PG11 起常量默认值的加列不重写表 | PostgreSQL 11.0 发行说明 E.x “Allow ALTER TABLE to add a column with a non-null default without doing a table rewrite”（https://www.postgresql.org/docs/release/11.0/） | 11.0 | 2026-10-19 | 已读原文（URL 可访问） | S4（仅说明出处） |
| ADD CONSTRAINT ... NOT VALID 跳过既有行扫描，但约束后续 INSERT/UPDATE；VALIDATE CONSTRAINT 取 SHARE UPDATE EXCLUSIVE，不阻塞并发更新 | ALTER TABLE，ADD table_constraint、VALIDATE CONSTRAINT 两节及 Notes 中 NOT VALID 段 | 16 | 2026-10-19 | 已读原文（URL 可访问）；本地 man 页 | S5 |
| pg_constraint.convalidated 表示是否已验证，仅外键与 CHECK 可为 false | 53.13 pg_constraint（https://www.postgresql.org/docs/16/catalog-pg-constraint.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | S5 |
| SET NOT NULL 通常扫描全表；若存在有效 CHECK 能证明无 NULL 则跳过扫描 | ALTER TABLE，SET/DROP NOT NULL 一节 | 16 | 2026-10-19 | 已读原文（URL 可访问）；本地 man 页 | S6 |
| PG12 引入“SET NOT NULL 避免不必要扫描” | PostgreSQL 12.0 发行说明“Allow ALTER TABLE ... SET NOT NULL to avoid unnecessary table scans”（https://www.postgresql.org/docs/release/12.0/） | 12.0 | 2026-10-19 | 已读原文（URL 可访问） | S6（仅说明出处） |
| 服务端 DEBUG1 消息文本“existing constraints on column ... are sufficient to prove that it does not contain nulls”“verifying table”“rewriting table” | PostgreSQL 16.15 服务端二进制中的消息字符串（/usr/lib/postgresql/16/bin/postgres，grep -a 取得）；源码 tablecmds.c 在本环境不可达（GitHub 403、git.postgresql.org 502），未读源码上下文 | 16.15 | 2026-10-19 | 本地二进制字符串 + 实验观察；源码未读 | S4、S6 |
| 表级锁冲突矩阵；SHARE ROW EXCLUSIVE 由 CREATE TRIGGER 获取；无死锁时等锁会无限等待 | 13.3.1 Table-Level Locks、13.3.4 Deadlocks 末段（https://www.postgresql.org/docs/16/explicit-locking.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | S2 |
| pg_locks.granted=false 表示等待中；pg_locks 不暴露等待队列先后，应使用 pg_blocking_pids | 54.12 pg_locks（https://www.postgresql.org/docs/16/view-pg-locks.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | S2、S8 |
| pg_blocking_pids 同时报告 hard block（持有冲突锁）与 soft block（排在前面等待冲突锁） | 9.26 System Information Functions，Table 9.67 pg_blocking_pids（https://www.postgresql.org/docs/16/functions-info.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | S2 |
| lock_timeout：等锁超过设定时间则中止语句，单位毫秒，0 为关闭；不建议写入 postgresql.conf | 20.11.1 Statement Behavior，lock_timeout（https://www.postgresql.org/docs/16/runtime-config-client.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | S3 |
| 55P03 lock_not_available、23514 check_violation、23505 unique_violation、23502 not_null_violation、42703 undefined_column、25001 active_sql_transaction | Appendix A PostgreSQL Error Codes（https://www.postgresql.org/docs/16/errcodes-appendix.html）；本地 /usr/share/postgresql/16/errcodes.txt | 16 | 2026-10-19 | 已读原文（URL 可访问） | S3、S5、S6、S7、S10、S1 |
| CREATE INDEX CONCURRENTLY 分三个事务、两次扫描；失败留下 INVALID 索引，查询忽略但仍承担更新开销；推荐 DROP 后重建或 REINDEX CONCURRENTLY；不能在事务块内执行 | CREATE INDEX，Building Indexes Concurrently 一节（https://www.postgresql.org/docs/16/sql-createindex.html） | 16 | 2026-10-19 | 已读原文（URL 可访问）；本地 man 页 CREATE_INDEX.7 | S7 |
| 唯一索引并发构建时，若第二次扫描失败，INVALID 索引继续约束唯一性 | 同上一节倒数第二段 | 16 | 2026-10-19 | 已读原文（URL 可访问）；未构造实验 | 无（正文只引用文档） |
| IF NOT EXISTS 不保证已存在的索引与将要创建的一致，只发 NOTICE | CREATE INDEX，Parameters 中 IF NOT EXISTS | 16 | 2026-10-19 | 本地 man 页 | S7 |
| pg_index.indisvalid=false 表示索引可能不完整，不可用于查询；唯一索引此时唯一性也不保证 | 53.26 pg_index（https://www.postgresql.org/docs/16/catalog-pg-index.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | S7 |
| DROP INDEX CONCURRENTLY 不阻塞表上的读写，等待冲突事务结束 | DROP INDEX，CONCURRENTLY 参数（本地 man 页 DROP_INDEX.7） | 16 | 2026-10-19 | 本地 man 页 | S7 |
| READ COMMITTED 下 UPDATE 遇到被并发更新的行，等待对方结束；对方提交后在新版本上重新求值 WHERE | 13.2.1 Read Committed Isolation Level（https://www.postgresql.org/docs/16/transaction-iso.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | S8 |
| REPEATABLE READ 下更新被并发修改的行会报 could not serialize access due to concurrent update，需要重试整个事务 | 13.2.2 Repeatable Read Isolation Level（https://www.postgresql.org/docs/16/transaction-iso.html） | 16 | 2026-10-19 | 已读原文（URL 可访问）；未构造实验 | 无（正文只引用文档） |
| BEFORE 行级触发器返回修改后的 NEW 会改变写入的行 | 43.10.1 Triggers on Data Changes（https://www.postgresql.org/docs/16/plpgsql-trigger.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | S9、S1 |
| DROP COLUMN 不物理删除数据，只让列对 SQL 不可见 | ALTER TABLE，Notes 中 DROP COLUMN 段 | 16 | 2026-10-19 | 已读原文（URL 可访问） | S1（P7，仅说明） |
| 概念：absent → delete-only → write-only →（数据重组/回填）→ public 的中间状态；任意时刻最多两个相邻 schema 版本在用；schema lease 与写栅栏；回填任务须可恢复、幂等，跳过回填开始后被用户事务更新过的行（Thomas write rule） | Ian Rae, Eric Rollins, Jeff Shute, Sukhdeep Sodhi, Radek Vingralek. Online, Asynchronous Schema Change in F1. PVLDB 6(11), 2013, pp.1045–1056；§3.2 定义 1–3、§3.3.1、§3.3.2、§4.3 Schema leases、§4.4 Data reorganization（http://www.vldb.org/pvldb/vol6/p1045-rae.pdf） | VLDB 2013 | 2026-10-19 | 已读原文（PDF 可下载，本地以 zlib 解出文本流阅读，排版符号有缺失） | 概念出处，对应 S1、S8、S11 的设计；论文中的分布式租约机制本文未实现 |

## 第 25 章来源卡：缓存旧值回填与失效修复

| 论断 | 来源（标准/论文/官方文档/源码，含章节） | 版本 | 核对日期 | 核对方式 | 对应实验 |
|---|---|---|---|---|---|
| memcached `add` 仅当服务端没有该键时存储；`cas` 表示“自上次取回以来无人更新才存储”；`cas` 对不存在的键返回 `NOT_FOUND`，对已被修改的返回 `EXISTS`；`add` 条件不满足返回 `NOT_STORED` | memcached `doc/protocol.txt`，“Storage commands”节 | master 分支，经 jsDelivr 镜像 `cdn.jsdelivr.net/gh/memcached/memcached@master/doc/protocol.txt` 取得，文件 sha256 fbd6f3ac…5063（raw.githubusercontent 本环境 502） | 2026-10-19 | 已读原文（URL 可访问） | C1 |
| `<cas unique>` 是已有条目的 64 位唯一值，客户端应使用 `gets` 返回的值 | 同上，“Storage commands”与“Retrieval command”节 | 同上 | 2026-10-19 | 已读原文（URL 可访问） | C1 |
| `delete` 返回 `DELETED` 或 `NOT_FOUND` | 同上，“Deletion”节 | 同上 | 2026-10-19 | 已读原文（URL 可访问） | C3、C4、C8 |
| meta get 的 `E(token)` 可用外部系统版本（如行版本）作为 CAS 值；`N(token)` 未命中时创建空占位并返回 `W` 标志（赢得回填权），其他客户端看到 `Z`；`X` 表示条目已被标记为 stale | 同上，“Meta Get”节 | 同上 | 2026-10-19 | 已读原文（URL 可访问） | C8（对应关系说明，未运行 memcached） |
| meta set `C(token)` 比较 CAS 相等才存储；与 `I` 合用时，比当前值更低的 CAS 可能被接受但条目被标记为 stale | 同上，“Meta Set”节 | 同上 | 2026-10-19 | 已读原文（URL 可访问） | 正文对应关系说明 |
| meta delete `I` 不移除条目，而是标记 stale 并递增 CAS；`T` 与 `I` 合用可更新 stale 条目 TTL | 同上，“Meta Delete”节 | 同上 | 2026-10-19 | 已读原文（URL 可访问） | 正文对应关系说明（与带版本墓碑对照） |
| Redis 保证脚本原子执行，执行期间其他服务端活动被阻塞，脚本效果要么全部未发生要么全部已发生 | Redis 文档 “Scripting with Lua”（develop/programmability/eval-intro） | redis.io/docs/latest，页面无固定版本号 | 2026-10-19 | 已读原文（URL 可访问） | 正文对应关系说明（替身 putIfNewer/invalidate 在锁内执行） |
| 脚本访问的键名必须作为输入键参数显式传入；脚本缓存是易失的，可能在重启、故障切换或 SCRIPT FLUSH 后丢失 | 同上，键参数说明段与脚本缓存易失性说明段 | 同上 | 2026-10-19 | 已读原文（URL 可访问） | 正文差异说明 |
| Redis `SET` 的 `NX` 仅当键不存在时设置；`IFEQ` 仅当当前值等于给定值时设置（8.4.0 起），比较的是值相等 | Redis 文档 `SET` 命令页（commands/set） | redis.io/docs/latest；IFEQ 标注 since 8.4.0 | 2026-10-19 | 已读原文（URL 可访问） | 正文差异说明 |
| Redis 默认异步复制；WAIT 不能把实例集合变成强一致系统，已确认写在故障切换中仍可能丢失 | Redis 文档 “Redis replication” | redis.io/docs/latest | 2026-10-19 | 已读原文（URL 可访问） | LIMITS（未实验） |
| Read Committed 下 SELECT 只看到查询开始前已提交的数据；并发更新同一行时后者等待前者提交或回滚 | PostgreSQL 16 文档 13.2.1 Read Committed Isolation Level（transaction-iso.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | C2–C10（读者读到 v1 的前提；版本在行锁下递增） |
| `SKIP LOCKED` 跳过不能立即加锁的行，适用于多个消费者访问队列式表 | PostgreSQL 16 文档 SELECT，“The Locking Clause”（sql-select.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | C14 |
| 数据页修改先写 WAL，崩溃后用 WAL 重做（REDO）恢复已提交的修改 | PostgreSQL 16 文档 30.3 Write-Ahead Logging（wal-intro.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | C11（immediate 重启后 outbox 行仍在） |
| 租约令牌作为限制回填的机制，其概念出处 | R. Nishtala et al., “Scaling Memcache at Facebook”, NSDI 2013 | 论文 | 2026-10-19 | 仅书目信息，本环境无法取得全文（usenix.org 超时、WebFetch 403） | C8（只作概念出处，令牌语义为本章自定契约） |

## 第 26 篇来源卡：租约互斥与资源端栅栏

| 论断 | 来源（标准/论文/官方文档/源码，含章节） | 版本 | 核对日期 | 核对方式 | 对应实验 |
|---|---|---|---|---|---|
| 租约（lease）作为有时限的授权这一概念出处 | C. G. Gray, D. R. Cheriton, "Leases: An Efficient Fault-Tolerant Mechanism for Distributed File Cache Consistency", 12th SOSP, 1989, pp. 202–210（书目信息另见 Chubby 论文参考文献） | 1989 | 2026-10-19 | 仅书目信息，本环境无法取得全文（ACM DL 返回 403） | 仅概念出处，不支撑细节论断 |
| Chubby 的锁是建议性的；持有者发出的请求 R 可能在锁转手后才到达目标；sequencer 含锁名、模式、lock generation number，由资源服务器检查，可与“见过的最新 sequencer”比较，不合格则拒绝 | M. Burrows, "The Chubby lock service for loosely-coupled distributed systems", OSDI 2006, §2.4 Locks and sequencers；https://www.usenix.org/legacy/events/osdi06/tech/full_papers/burrows/burrows_html/index.html | OSDI '06 | 2026-10-19 | 已读原文（URL 可访问） | F4、F5、F7 |
| 对不支持 sequencer 的服务，Chubby 提供 lock-delay（持有者失效后一段时间内不让他人获取），论文称其 imperfect | 同上，§2.4 | OSDI '06 | 2026-10-19 | 已读原文（URL 可访问） | 正文讨论；F9 对应“无栅栏”的情形 |
| Chubby 会话租约：主服务器只能前推不能后退；客户端维护保守的本地租约超时，需假设 KeepAlive 回复在途时间并要求服务器时钟比客户端快不超过已知常数因子 | 同上，§2.8 Sessions and KeepAlives | OSDI '06 | 2026-10-19 | 已读原文（URL 可访问） | 正文“本地截止时间与安全余量”；LeaseStore 以请求发出前的单调时钟为起点 |
| etcd lease：带 TTL 授予，TTL 内未收到 keepAlive 即过期；过期或撤销时删除附着的键 | etcd v3.6 文档 Learning › etcd API › Lease API；https://etcd.io/docs/v3.6/learning/api/ | v3.6（页面 Last modified 2026-01-20, 7047ac4） | 2026-10-19 | 已读原文（URL 可访问） | 正文方案比较 |
| etcd revision 是集群级 64 位计数器，每次修改递增，可作逻辑时钟；一次事务只分配一个 revision | etcd v3.6 Learning › etcd API › Revisions；Learning › API guarantees › Revision；https://etcd.io/docs/v3.6/learning/api_guarantees/ | v3.6（API guarantees 页面 Last modified 2025-09-26, 5e64060） | 2026-10-19 | 已读原文（URL 可访问） | 正文方案比较 |
| etcd 文档：TTL 是物理时间，服务器与客户端各自计时，可能出现服务器已撤销而客户端仍认为持有；lease 本身不保证互斥；锁 API 不能单独作为互斥机制；保护 etcd 之外的资源时，资源本身必须提供版本号校验；文档把 Chubby sequencer 解释为近似 revision + lease ID | etcd v3.6 Learning › Why etcd › Notes on the usage of lock and lease；https://etcd.io/docs/v3.6/learning/why/ | v3.6（页面 Last modified 2026-07-10, f199afb） | 2026-10-19 | 已读原文（URL 可访问） | F4、F5 |
| `now()` 等价于 `transaction_timestamp()`，返回当前事务开始时间，事务内不变；`clock_timestamp()` 返回实际当前时间 | PostgreSQL 16 文档 §9.9.5 Current Date/Time；https://www.postgresql.org/docs/16/functions-datetime.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | F2（事务内 now() 冻结、长事务内获取被拒） |
| Read Committed 下 UPDATE 遇到被并发事务更新的目标行会等待；对方提交后对更新后的行版本重新求值 WHERE | PostgreSQL 16 文档 §13.2.1 Read Committed Isolation Level；https://www.postgresql.org/docs/16/transaction-iso.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | F6(b)：B 在行锁上等待，A 提交后 B 以新版本重新判断 |
| `INSERT ... ON CONFLICT DO UPDATE` 保证原子的 INSERT 或 UPDATE 结果（无独立错误时） | PostgreSQL 16 SQL 命令参考 INSERT，ON CONFLICT 子句 | 16（本地 /usr/share/postgresql/16/man/man7/INSERT.7.gz） | 2026-10-19 | 本地 man 页 | F3（16 线程同时获取，恰好一个获胜） |
| `UPDATE ... RETURNING` 只为实际更新的行返回值 | PostgreSQL 16 SQL 命令参考 UPDATE，RETURNING | 16（本地 man7/UPDATE.7.gz） | 2026-10-19 | 本地 man 页 | LeaseStore.renew / acquire 以返回行判定成功 |
| `pg_ctl -m immediate` 立即中止所有服务器进程、不做干净关闭，下次启动进入崩溃恢复 | PostgreSQL 16 pg_ctl 参考页，`-m` 选项说明 | 16（本地 /usr/share/postgresql/16/man/man1/pg_ctl.1.gz） | 2026-10-19 | 本地 man 页 | F8（经 `pg.sh restart-immediate` 调用） |

说明：etcd “Why etcd” 页面同时引用了一篇个人博客中的 fencing token 说法；本篇未检索、未引用该博客，相关论断只以 etcd 官方文档和 Chubby 论文原文为依据。
| Chubby 主节点切换（fail-over）期间停止会话租约计时 | 同上，§2.9 Fail-overs | OSDI '06 | 2026-10-21 | 已读原文（独立审稿时核对，URL 可访问） | 正文“恢复流程”中与本实现的对比 |

## 第 27 篇来源卡：测试账户的余额与账本

| 论断 | 来源（标准/论文/官方文档/源码，含章节） | 版本 | 核对日期 | 核对方式 | 对应实验 |
|---|---|---|---|---|---|
| READ COMMITTED 下 UPDATE 遇到被并发更新的目标行会等待对方结束；对方提交后在新版本上重新求值 WHERE，满足才更新 | PostgreSQL 文档 13.2.1 Read Committed Isolation Level，https://www.postgresql.org/docs/16/transaction-iso.html | PostgreSQL 16（运行 16.15） | 2026-10-19 | 已读原文（URL 可访问） | L3、L4 |
| 该模式适用于每条命令只影响一个预先确定的行（文档以账户余额转账为例） | 同上，13.2.1 节转账示例 | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | L3 |
| READ COMMITTED 下 INSERT ON CONFLICT DO NOTHING 可能因另一事务的结果而不插入，即使该行对当前快照不可见 | 同上，13.2.1 节 | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | L8、L9 |
| 每条 SELECT 在 READ COMMITTED 下取语句开始时的快照，同一事务内相继两条 SELECT 可见不同数据 | 同上，13.2.1 节 | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | L7、L8（`stored()` 读到先到者终态） |
| REPEATABLE READ 事务内的语句看到第一条非事务控制语句开始时的同一快照 | 同上，13.2.2 Repeatable Read Isolation Level | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | L11（对账事务） |
| 序列推进不随事务回滚撤销，serial 列可能有空洞 | 同上，13.2 节开头 Important 提示 | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | 正文论述，无专门断言 |
| 唯一性检查遇到未提交事务插入的冲突行时，插入者等待该事务结束后重新检查；对方回滚则无冲突 | PostgreSQL 文档 64.5 Index Uniqueness Checks，https://www.postgresql.org/docs/16/index-unique-checks.html | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | L8、L9（L9 只断言等待者 500ms 未返回，未查询 pg_locks） |
| ON CONFLICT DO NOTHING 的语义；RETURNING 只返回实际插入的行 | PostgreSQL 文档 SQL 命令 INSERT，ON CONFLICT Clause 与 Outputs，https://www.postgresql.org/docs/16/sql-insert.html | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | L1、L7、L8 |
| CHECK 约束不支持引用当前行以外的数据；跨行限制应改用其他手段 | PostgreSQL 文档 5.4.1 Check Constraints，https://www.postgresql.org/docs/16/ddl-constraints.html | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | 正文设计依据（I4 放到对账查询） |
| 唯一约束定义；默认两个 NULL 不相等 | 同上，5.4.3 Unique Constraints | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | schema 中键列均为 NOT NULL |
| SQLSTATE 23514 check_violation、23505 unique_violation、40001 serialization_failure、40P01 deadlock_detected | PostgreSQL 文档 Appendix A. PostgreSQL Error Codes，https://www.postgresql.org/docs/16/errcodes-appendix.html | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | L6（观察到 18 次 23514） |
| 行级锁导致死锁的条件；按一致顺序加锁是首要预防手段；无死锁时锁等待无限期持续 | PostgreSQL 文档 13.3.4 Deadlocks，https://www.postgresql.org/docs/16/explicit-locking.html | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | 正文加锁顺序论述；L9 等待者 |
| UPDATE 修改可被外键引用的唯一索引列时取 FOR UPDATE 行锁，否则 FOR NO KEY UPDATE | 同上，13.3.2 Row-Level Locks | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | 背景，未单独断言 |
| synchronous_commit=on 时提交等待本地 WAL 刷盘；off 时崩溃可能丢失最近已报告成功的事务 | PostgreSQL 文档 20.5 Write Ahead Log，synchronous_commit，https://www.postgresql.org/docs/16/runtime-config-wal.html | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | L10（记录 fsync=on、synchronous_commit=on；off 情形未实验） |
| pg_stat_activity.state 的 `idle in transaction` 表示后端在事务中但未执行查询 | PostgreSQL 文档 28.2 The Cumulative Statistics System，pg_stat_activity 视图，https://www.postgresql.org/docs/16/monitoring-stats.html | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | L9 |
| 幂等键不得在不同载荷间复用（2.2）；资源可定义过期策略（2.3）；可用指纹判定同一请求（2.4）；重试返回先前结果，成功或错误（2.6）；并发重试应返回冲突（2.6、2.7 的 409）；缺键 400、复用 422（2.7）；键为 RFC 8941 String（2.1）；建议复合键（5） | IETF draft-ietf-httpapi-idempotency-key-header-07，https://www.ietf.org/archive/id/draft-ietf-httpapi-idempotency-key-header-07.txt | -07（2025-10-15 发布，标注过期日 2026-04-18；-08 不存在，datatracker 状态为 Expired） | 2026-10-19 | 已读原文（URL 可访问） | L2、L7、L8；409 并发语义与 RFC 8941 语法未实现，正文列为差异 |
| POST 不是幂等方法；幂等方法定义 | RFC 9110 9.2.2 Idempotent Methods，https://www.rfc-editor.org/rfc/rfc9110.txt | RFC 9110 | 2026-10-19 | 已读原文（URL 可访问） | 接口背景 |
| 409 Conflict 与 422 Unprocessable Content 的定义 | RFC 9110 15.5.10、15.5.21 | RFC 9110 | 2026-10-19 | 已读原文（URL 可访问） | L2（409）、L8（422） |

说明：未检索或引用任何博客、教程。正文中的需求、算例、表结构、代码与图均为本章独立设计；实验结果全部来自 `evidence/27/output.txt`。

## 第 28 篇来源卡：稀缺名额的准入与库存预留

核对日期均为 2026-10-19。实际运行版本：PostgreSQL 16.15、OpenJDK 21.0.12.1、pgJDBC 42.7.7。

| 论断 | 来源（标准/论文/官方文档/源码，含章节） | 版本 | 核对日期 | 核对方式 | 对应实验 |
|---|---|---|---|---|---|
| READ COMMITTED 下 UPDATE 找到已被并发事务修改的行时，等待对方结束；对方提交后对行的最新版本重新求值 WHERE，满足才更新；对方回滚则按原行继续 | PostgreSQL 文档 13.2.1 Read Committed Isolation Level（https://www.postgresql.org/docs/16/transaction-iso.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | C28-03、C28-07、C28-08、C28-14（A 部分） |
| 同一节同时说明这种更新可能看到“不一致快照”，只适合简单搜索条件 | 同上，13.2.1 | 16 | 2026-10-19 | 已读原文（URL 可访问） | 用于说明条件写在单行 WHERE 上的理由 |
| INSERT ... ON CONFLICT DO NOTHING 在 READ COMMITTED 下可能因另一个尚不可见事务的结果而不插入 | 同上，13.2.1 | 16 | 2026-10-19 | 已读原文（URL 可访问） | C28-04（同键并发） |
| ON CONFLICT 只对 conflict_target 推断出的仲裁索引采取替代动作；其他唯一索引冲突照常报错 | INSERT 参考页 “ON CONFLICT Clause”（/usr/share/postgresql/16/man/man7/INSERT.7.gz） | 16 | 2026-10-19 | 本地 man 页 | C28-04（同用户不同键得到 23505 → USER_LIMIT） |
| 部分唯一索引只约束满足谓词的行，可用于“每组最多一个成功记录” | PostgreSQL 文档 11.8 Partial Indexes，Example 11.3（https://www.postgresql.org/docs/16/indexes-partial.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | C28-04、C28-12 |
| SQLSTATE 23505 为 unique_violation | 附录 A PostgreSQL Error Codes（https://www.postgresql.org/docs/16/errcodes-appendix.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | C28-04 |
| WITH 中的数据修改子语句与主查询使用同一快照、彼此看不到对目标表的修改，只能通过 RETURNING 传递；数据修改子语句总会执行完毕 | PostgreSQL 文档 7.8.4 Data-Modifying Statements in WITH（https://www.postgresql.org/docs/16/queries-with.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | EXPIRE_SQL：C28-07、C28-09 |
| now() 等函数返回当前事务开始时间，事务内不变 | PostgreSQL 文档 9.9.5 Current Date/Time（https://www.postgresql.org/docs/16/functions-datetime.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | expires_at 计算与到期判断 |
| SKIP LOCKED 跳过不能立即加锁的行，给出不一致的数据视图，只适合队列式多消费者 | SELECT 参考页 “The Locking Clause”（/usr/share/postgresql/16/man/man7/SELECT.7.gz） | 16 | 2026-10-19 | 本地 man 页 | C28-13、C28-14（B 部分） |
| FOR UPDATE 锁住的行在事务结束前阻止其他 UPDATE / FOR UPDATE | PostgreSQL 文档 13.3.2 Row-Level Locks（https://www.postgresql.org/docs/16/explicit-locking.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | C28-14 |
| 连接正常或异常终止时，未结束的事务一律回滚；非事务块中的语句可能在服务端发现断连前已提交 | PostgreSQL 文档 55.2.9 Termination（https://www.postgresql.org/docs/16/protocol-flow.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | C28-09、C28-11 |
| 未开启 client_connection_check_interval（默认 0）时，服务端只在下一次读写套接字时发现连接丢失 | PostgreSQL 文档 20.3.1 client_connection_check_interval（https://www.postgresql.org/docs/16/runtime-config-connection.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | C28-09（等待 pg_stat_activity 中的后端消失） |
| 事务是全有或全无的；中间状态对并发事务不可见 | PostgreSQL 文档 3.4 Transactions（https://www.postgresql.org/docs/16/tutorial-transactions.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | C28-09（未提交时外部看不到归还） |
| dynamic_shared_memory_type=mmap 用数据目录中的内存映射文件模拟共享内存，适用于其他共享内存设施不可用的情况 | PostgreSQL 文档 20.4.1 Memory（https://www.postgresql.org/docs/16/runtime-config-resource.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | 环境偏差（/dev/shm 已满） |
| 公平 Semaphore 按 FIFO 分配许可；不带超时的 tryAcquire() 不遵守公平设置 | Java SE 21 API：java.util.concurrent.Semaphore 类说明（https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/Semaphore.html） | 21 | 2026-10-19 | 已读原文（URL 可访问） | Admission、C28-02 |
| newFixedThreadPool 的工作线程从共享的无界队列取任务 | Java SE 21 API：java.util.concurrent.Executors（https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/Executors.html） | 21 | 2026-10-19 | 已读原文（URL 可访问） | ReserveServer 改用每请求一个虚拟线程的理由 |
| HttpServer 的所有请求都在交给 Executor 的任务中处理 | Java SE 21 API：com.sun.net.httpserver.HttpServer#setExecutor（https://docs.oracle.com/en/java/javase/21/docs/api/jdk.httpserver/com/sun/net/httpserver/HttpServer.html） | 21 | 2026-10-19 | 已读原文（URL 可访问） | C28-05 |
| 503 表示服务端暂时无法处理；可携带 Retry-After 指示客户端等待多久再试 | RFC 9110 §15.6.4 503 Service Unavailable、§10.2.3 Retry-After（https://www.rfc-editor.org/rfc/rfc9110.txt） | RFC 9110 | 2026-10-19 | 已读原文（URL 可访问） | ReserveServer 的拒绝响应、C28-05 |
| 子进程被 SIGKILL 终止时 Java 报告的退出码为 137 | 本地观察（evidence/28/output.txt C28-09、C28-11），未找到规范性文档条款 | OpenJDK 21.0.12.1 | 2026-10-19 | 本地运行观察 | C28-09、C28-11 |

未使用论文。未检索、未参考任何博客、公众号或教程文章。

## 第 29 篇来源卡：订单、支付模拟与库存补偿

核对日期均为 2026-10-19。实际运行版本：PostgreSQL 16.15、OpenJDK 21.0.12.1、pgJDBC 42.7.7。库存层（条件预留、确认、到期释放）的来源见第 28 篇来源卡，本篇只补充新增论断。

| 论断 | 来源（标准/论文/官方文档/源码，含章节） | 版本 | 核对日期 | 核对方式 | 对应实验 |
|---|---|---|---|---|---|
| saga 是可以写成一串事务、并与其他事务交错执行的长事务；系统保证要么全部事务完成，要么运行补偿事务修正部分执行，即执行序列为 T1…Tn 或 T1…Tj, Cj…C1 | H. Garcia-Molina, K. Salem, “Sagas”, Proc. ACM SIGMOD 1987, pp. 249–259，Abstract 与第 1 节 Introduction（https://www.cs.cornell.edu/andru/cs711/2002fa/reading/sagas.pdf） | 1987 原文扫描版 | 2026-10-19 | 已读原文（URL 可访问；扫描版 PDF，经其 OCR 文本层核对。ACM DL 页面 403） | 概念出处：C29-07、C29-08 的退款补偿 |
| 补偿事务在语义上撤销 Ti 的动作，但不一定把数据库恢复到 Ti 开始前的状态；其他事务可能看到部分执行的效果，运行补偿时不通知也不中止这些事务 | 同上，第 1 节 Introduction（航班座位例子之后的段落） | 1987 | 2026-10-19 | 已读原文（OCR 文本层） | 正文“预留到期与补偿”：释放出的名额可能已被他人买走 |
| 失败后有两种选择：补偿已执行的事务（backward recovery）或执行剩余事务（forward recovery，需要保存点） | 同上，第 4 节 Backward Recovery 开头 | 1987 | 2026-10-19 | 已读原文（OCR 文本层） | 正文：重新占用（向前）与退款（向后）两种处理 |
| 幂等方法的定义；非幂等方法（如 POST）的请求，客户端不应自动重试，除非能知道语义上幂等或能检测原请求未被执行 | RFC 9110 §9.2.2 Idempotent Methods（https://www.rfc-editor.org/rfc/rfc9110.txt） | RFC 9110 | 2026-10-19 | 已读原文（URL 可访问） | 渠道契约：按商户订单号幂等扣款；超时后先查询而非重发 |
| Idempotency-Key：键不得用于不同请求体；重复请求返回先前结果；同键不同请求体 SHOULD 返回 422；原请求仍在处理时的重复请求 SHOULD 返回 409 | draft-ietf-httpapi-idempotency-key-header-07 §2.2、§2.6、§2.7（https://www.ietf.org/archive/id/draft-ietf-httpapi-idempotency-key-header-07.txt） | Internet-Draft -07（2025-10-15，未成为 RFC） | 2026-10-19 | 已读原文（URL 可访问） | FakeChannel：同号不同额 422；替身对并发重复请求串行处理而非返回 409（正文写明差异） |
| READ COMMITTED 下 UPDATE / SELECT FOR UPDATE 遇到被并发事务修改的行会等待；对方提交后对新版本重新求值 WHERE，SELECT FOR UPDATE 锁住并返回新版本 | PostgreSQL 文档 13.2.1 Read Committed Isolation Level（https://www.postgresql.org/docs/16/transaction-iso.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | OrderService.lock 与条件迁移：C29-02、C29-03、C29-06、C29-08 |
| FOR UPDATE 锁住的行在事务结束前阻止其他 UPDATE、DELETE、SELECT FOR UPDATE 等；SELECT FOR UPDATE 会等待并返回更新后的行 | PostgreSQL 文档 13.3.2 Row-Level Locks（https://www.postgresql.org/docs/16/explicit-locking.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | 同一订单上的回调、查询结果、取消串行化 |
| SKIP LOCKED 跳过不能立即加锁的行，给出不一致的数据视图，不适合一般用途，但可用于多个消费者访问队列式表 | SELECT 参考页 The Locking Clause（/usr/share/postgresql/16/man/man7/SELECT.7.gz） | 16 | 2026-10-19 | 本地 man 页 | Relay：C29-09 两个中继并发 |
| ON CONFLICT DO UPDATE 的 WHERE condition：只有条件为真的行被更新，但所有冲突行都会被锁住；条件在确认冲突之后最后求值 | INSERT 参考页 ON CONFLICT Clause（/usr/share/postgresql/16/man/man7/INSERT.7.gz） | 16 | 2026-10-19 | 本地 man 页 | Fulfillment 的版本比较：C29-09 STALE |
| 事务把多个步骤合成一个全有或全无的操作，中间状态对并发事务不可见，失败时所有步骤都不生效 | PostgreSQL 文档 3.4 Transactions（https://www.postgresql.org/docs/16/tutorial-transactions.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | 状态迁移 + outbox 同事务：C29-11 |
| 连接正常或异常终止时，未结束的事务一律回滚 | PostgreSQL 文档 55.2.9 Termination（https://www.postgresql.org/docs/16/protocol-flow.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | C29-11、C29-12、C29-18（kill -9 后未提交的修改不存在） |
| now() / CURRENT_TIMESTAMP 返回当前事务开始时间，事务内不变 | PostgreSQL 文档 9.9.5 Current Date/Time（https://www.postgresql.org/docs/16/functions-datetime.html） | 16 | 2026-10-19 | 已读原文（URL 可访问） | Recovery 的 PAYING 陈旧阈值、到期判断 |
| HttpRequest.Builder.timeout：在指定时间内收不到响应，send 抛出 HttpTimeoutException；不设超时等于无限等待 | Java SE 21 API java.net.http.HttpRequest.Builder#timeout、HttpTimeoutException（https://docs.oracle.com/en/java/javase/21/docs/api/java.net.http/java/net/http/HttpRequest.Builder.html） | 21 | 2026-10-19 | 已读原文（URL 可访问） | OrderService.pay 把超时记为 UNKNOWN：C29-04、C29-05 |
| 子进程被 SIGKILL 终止时 Process.waitFor 返回 137 | 本地观察（evidence/29/output.txt C29-10/11/12/18/19），未找到规范性条款 | OpenJDK 21.0.12.1 | 2026-10-19 | 本地运行观察 | 多进程用例 |

说明：
- “Outbox”“收件箱（inbox）”在本篇只作为表名与做法的描述，没有引用任何博客或厂商文章作为出处；其正确性只由上表中的事务原子性、行锁与本章实验支撑。
- 假支付渠道的“关单”接口是本章自定的替身契约，不对应任何真实渠道的接口文档；正文明确写为假设。
- 未检索、未参考任何博客、公众号或教程文章。

## 第 30 篇来源卡：关注关系与可撤销订阅

| 论断 | 来源（标准/论文/官方文档/源码，含章节） | 版本 | 核对日期 | 核对方式 | 对应实验 |
|---|---|---|---|---|---|
| Read Committed 下 `SELECT FOR UPDATE` 遇到被并发更新/锁定的行时等待对方结束，对方提交后锁住并返回更新后的版本；每条语句取新快照 | PostgreSQL 文档 13.2.1 Read Committed Isolation Level，https://www.postgresql.org/docs/16/transaction-iso.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 30-D、30-H |
| Read Committed 下 `INSERT ... ON CONFLICT DO NOTHING` 可能因对本快照不可见的其他事务而不插入 | 同上 13.2.1 | 16 | 2026-10-19 | 已读原文（URL 可访问） | 30-D（lockPair 后续 FOR UPDATE 为新语句） |
| `ON CONFLICT DO NOTHING` 在冲突时不插入；省略 conflict_target 时处理所有可用唯一约束 | SQL Commands: INSERT，ON CONFLICT Clause，https://www.postgresql.org/docs/16/sql-insert.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 30-D、30-F（proj_seen 去重） |
| `FOR UPDATE` 行锁阻止其他事务对该行加锁、修改，直到当前事务结束 | 13.3.2 Row-Level Locks，https://www.postgresql.org/docs/16/explicit-locking.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 30-H、event_seq 序号 |
| 按一致顺序获取多个对象上的锁是避免死锁的首要办法；死锁被检测后中止一个事务 | 13.3.4 Deadlocks，同上 | 16 | 2026-10-19 | 已读原文（URL 可访问） | 30-J（重试计数 0，仅本次） |
| pg_locks 中 `granted = false` 表示该进程正在等待该锁 | 54.12 pg_locks，https://www.postgresql.org/docs/16/view-pg-locks.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 30-H |
| 部分索引只包含满足谓词的行 | 11.8 Partial Indexes，https://www.postgresql.org/docs/16/indexes-partial.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | relation_by_followee（未单独做实验） |
| 唯一约束、主键、CHECK 约束语义 | 5.4.1 / 5.4.3 / 5.4.4，https://www.postgresql.org/docs/16/ddl-constraints.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 30-C（自关注）、relation_event UNIQUE |
| “new enemy problem”“zookie”两个术语的出处 | Ruoming Pang 等，Zanzibar: Google's Consistent, Global Authorization System，USENIX ATC 2019 | 2019 | 2026-10-19 | 仅书目信息，本环境无法取得全文（usenix.org 与 research.google 均返回 403） | 30-K（只借用问题名称；令牌规则为本章自行设计） |
| 序号顺序等于提交顺序、水位 ≥ 令牌即视图已含令牌前全部事件 | 本章设计：event_seq 单行计数在行锁下递增（依据 13.3.2），proj_watermark 连续水位 | 本仓代码 | 2026-10-19 | 本地实验 | 30-G、30-K、30-L |

未使用任何博客、教程或公众号材料。

## 第 31 篇来源卡：Feed 的扇出成本与热点

| 论断 | 来源（标准/论文/官方文档/源码，含章节） | 版本 | 核对日期 | 核对方式 | 对应实验 |
|---|---|---|---|---|---|
| 按作者选择性物化 Feed（写时推送与读时拉取的混合）这一问题的出处 | Adam Silberstein, Jeff Terrace, Brian F. Cooper, Raghu Ramakrishnan, Feeding Frenzy: Selectively Materializing Users' Event Feeds, SIGMOD 2010, pp. 831–842, DOI 10.1145/1807167.1807257（书目由 Crossref API 核对） | 2010 | 2026-10-19 | 仅书目信息，本环境无法取得全文（dl.acm.org 返回 403，未找到可访问的作者副本） | 只说明概念出处；本章的阈值规则、按帖记录投递方式均为自行设计，不代表论文的策略或代价模型 |
| 行构造器比较 `<`：从左到右逐对比较，遇到第一对不相等（或含 NULL）的元素即由它决定结果 | 9.24.5 Row Constructor Comparison，https://www.postgresql.org/docs/16/functions-comparisons.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 31-C、31-D 的键集游标 `(created_at, post_id) < (?, ?)` |
| 使用 LIMIT 时必须用 ORDER BY 约束出唯一顺序，否则得到不可预测的子集；OFFSET 跳过的行仍需在服务端计算 | 7.6 LIMIT and OFFSET，https://www.postgresql.org/docs/16/queries-limit.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 排序键带 post_id 作为决胜列；31-D 的 OFFSET 负向对照 |
| ORDER BY 与 LIMIT n 组合时，若有与排序匹配的索引，可以直接取前 n 行而不扫描其余部分；B-tree 可反向扫描满足 DESC | 11.4 Indexes and ORDER BY，https://www.postgresql.org/docs/16/indexes-ordering.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | inbox (reader, created_at DESC, post_id DESC) 与 post 部分索引的设计理由（未用 EXPLAIN 验证计划） |
| 部分索引只包含满足谓词的行 | 11.8 Partial Indexes，https://www.postgresql.org/docs/16/indexes-partial.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | `post (author, created_at DESC, post_id DESC) WHERE delivery = 'PULL'`（未单独实验） |
| Read Committed 下每条 SELECT 看到语句开始时的快照，同一事务内相继两条 SELECT 可能看到不同数据；UPDATE/DELETE 只找到语句开始时已提交的目标行 | 13.2.1 Read Committed Isolation Level，https://www.postgresql.org/docs/16/transaction-iso.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 31-F（DELETE 看不到未提交的扇出行）、31-G |
| Repeatable Read 下事务内所有语句看到同一快照（取自第一条非事务控制语句开始时） | 13.2.2 Repeatable Read Isolation Level，同上 | 16 | 2026-10-19 | 已读原文（URL 可访问） | Feed.page 在 RR 事务内执行收件箱、关注列表与各作者时间线的查询 |
| 事务是全有或全无的操作；未完成事务的中间状态对其他事务不可见，失败时所有步骤都不生效 | 3.4 Transactions，https://www.postgresql.org/docs/16/tutorial-transactions.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 31-J（发布与扇出同事务，会话终止后两者都不存在） |
| pg_terminate_backend(pid, timeout)：timeout 大于 0 时等待进程真正终止或超时，终止则返回 true | 9.27.2 Server Signaling Functions，https://www.postgresql.org/docs/16/functions-admin.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 31-J |
| ON CONFLICT DO NOTHING 在冲突时放弃插入 | SQL Commands: INSERT，ON CONFLICT Clause，https://www.postgresql.org/docs/16/sql-insert.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 扇出 INSERT 的幂等；31-J 再次重试为 NOOP |
| 未限定 schema 的表名按 search_path 依次查找，取第一个匹配 | 5.9.3 The Schema Search Path，https://www.postgresql.org/docs/16/ddl-schemas.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 四个方案各自的 post/inbox 与共享的 public.relation、block；AccessCheck 中的 `post` 解析到当前方案 |
| PUBLIC 内容只检查双向拉黑，FOLLOWERS 需要 ACTIVE 关注且无拉黑，SELF 只对作者可读 | 本仓第 30 篇代码 social.rel.AccessCheck（已修正版本） | 本仓代码 | 2026-10-19 | 本地实验 | 31-A、31-E、31-F、31-G 的判定依据 |
| 写入行数 = 帖子数 + 推送帖子作者粉丝数之和 | 本章内存模型 Graph.expectedWriteRows | 本仓代码 | 2026-10-19 | 本地实验 | 31-A、31-B |

未检索、未使用任何博客、教程或公众号材料。

## 第 32 篇来源卡：点赞事实与计数校准

| 论断 | 来源（标准/论文/官方文档/源码，含章节） | 版本 | 核对日期 | 核对方式 | 对应实验 |
|---|---|---|---|---|---|
| Read Committed 下每条语句看到语句开始时已提交的数据；`SELECT FOR UPDATE` 遇到被并发更新或锁定的行时等待对方结束，对方提交后锁住并返回更新后的行版本 | PostgreSQL 文档 13.2.1 Read Committed Isolation Level，https://www.postgresql.org/docs/16/transaction-iso.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 32-I（安装等锁后读到事件 5）、LikeService 事实行加锁 |
| Repeatable Read 事务内所有语句看到同一快照（取自第一条非事务控制语句开始时） | 13.2.2 Repeatable Read Isolation Level，同上 | 16 | 2026-10-19 | 已读原文（URL 可访问） | Rebuild.snapshot（S 与事实数同一快照）、32-H、32-J |
| `FOR UPDATE` 行锁阻止其他事务修改或加锁该行直到当前事务结束；RR/SERIALIZABLE 中被锁行在事务开始后变化会报错 | 13.3.2 Row-Level Locks，https://www.postgresql.org/docs/16/explicit-locking.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | like_seq 计数行、counter_watermark 行、32-I |
| 按一致顺序获取锁是避免死锁的主要办法；检测到死锁时中止其中一个事务 | 13.3.4 Deadlocks，同上 | 16 | 2026-10-19 | 已读原文（URL 可访问） | 锁顺序设计；本次运行 40001/40P01 重试计数为 0（仅本次） |
| `nextval` 取得的值在事务中止后不回收，事务中止或崩溃会留下空洞，序列不能用于无空洞编号 | 9.17 Sequence Manipulation Functions，https://www.postgresql.org/docs/16/functions-sequence.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 选用单行计数而非序列的理由；32-B（中止后序号不前进） |
| `ON CONFLICT DO NOTHING` 在冲突时不插入；省略 conflict_target 时处理全部可用唯一约束 | SQL Commands: INSERT，ON CONFLICT Clause，https://www.postgresql.org/docs/16/sql-insert.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | processed_event 去重、事实占位行、32-E、32-G |
| 主键、唯一、外键、CHECK 约束语义 | 5.4 Constraints（5.4.1、5.4.3、5.4.4、5.4.5），https://www.postgresql.org/docs/16/ddl-constraints.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 32-B（外键拒绝）、like_outbox UNIQUE |
| SQLSTATE 23503 foreign_key_violation、08003 connection_does_not_exist、08006 connection_failure、57P01 admin_shutdown | Appendix A. PostgreSQL Error Codes，https://www.postgresql.org/docs/16/errcodes-appendix.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 32-B、32-L、31-J 回归 |
| 正常或异常终止时，打开的事务都回滚而不提交 | 55.2.9 Termination，https://www.postgresql.org/docs/16/protocol-flow.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 32-K（客户端 kill -9 后第 2 批回滚） |
| `client_connection_check_interval` 默认 0；不开检查时服务端在下次读写 socket 时才发现连接丢失 | 20.3.1 Connection Settings，https://www.postgresql.org/docs/16/runtime-config-connection.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 32-K（会话停在 idle in transaction，等待读取时发现 EOF） |
| `pg_stat_activity.state = 'idle in transaction'` 表示后端在事务中但没有执行查询 | 28.2.3 pg_stat_activity，https://www.postgresql.org/docs/16/monitoring-stats.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 32-K |
| `pg_locks.granted = false` 表示该进程正在等待这个锁 | 54.12 pg_locks，https://www.postgresql.org/docs/16/view-pg-locks.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 32-I |
| `pg_ctl stop -m immediate` 直接中止全部服务进程，不做干净关闭，下次启动进入崩溃恢复 | pg_ctl 参考页，https://www.postgresql.org/docs/16/app-pg-ctl.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 32-L |
| WAL：数据文件的修改在描述它的 WAL 记录刷到持久存储之后才写入，崩溃后用 WAL 重做 | 30.3 Write-Ahead Logging (WAL)，https://www.postgresql.org/docs/16/wal-intro.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | 32-L（fsync=on，已确认事件恢复后全部存在） |
| 部分索引只包含满足谓词的行 | 11.8 Partial Indexes，https://www.postgresql.org/docs/16/indexes-partial.html | 16 | 2026-10-19 | 已读原文（URL 可访问） | like_fact_by_item（未单独做实验） |
| finally 块异常完成时，try/catch 块原来的异常被丢弃 | JLS SE 21 §14.20.2 Execution of try-finally and try-catch-finally，https://docs.oracle.com/javase/specs/jls/se21/html/jls-14.html | Java SE 21 | 2026-10-19 | 已读原文（URL 可访问） | Tx 修复（31-J 回归由 08003 变为 57P01） |
| `Throwable.addSuppressed` 把异常附加到“为了传递本异常而被抑制”的异常列表 | Java SE 21 API，java.lang.Throwable，https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/lang/Throwable.html | 21 | 2026-10-19 | 已读原文（URL 可访问） | Tx 修复 |
| TAO 是为社交图设计的数据模型与 API 及其实现（摘要级信息） | Nathan Bronson 等，TAO: Facebook's Distributed Data Store for the Social Graph，USENIX ATC 2013，https://www.usenix.org/conference/atc13/technical-sessions/presentation/bronson | 2013 | 2026-10-19 | 仅书目信息，本环境无法取得全文（会议页面与摘要可访问，PDF 下载失败） | 无；正文只作为相关工作出处提及，不引用任何细节 |
| 序号顺序等于提交顺序；RR 快照读到 last=S 时恰好包含序号 1..S 的全部事件效果；n + Σ(未处理且序号 > base_seq 的增量) = 事实数 | 本章设计推导（依据上面 13.2.2、13.3.2 两条），本仓 social.like 代码 | 本仓代码 | 2026-10-19 | 本地实验 | 32-D、32-E、32-H、32-J、32-L（恒等式违反数均为 0） |

未使用任何博客、教程或公众号材料。Outbox、水位、分片计数行等术语按通用工程用法使用，未引用特定出处。

## 第 33 篇来源卡：通知渠道的结果未知

| 论断 | 来源（标准/论文/官方文档/源码，含章节） | 版本 | 核对日期 | 核对方式 | 对应实验 |
|---|---|---|---|---|---|
| 推送服务返回 201 Created 表示消息被接受，且“does not indicate that the message was delivered to the user agent” | RFC 8030 Section 5（Requesting Push Message Delivery） | RFC 8030（2016-12） | 2026-10-19 | 已读原文（https://www.rfc-editor.org/rfc/rfc8030.txt 可访问） | N2、T1（替身把“接受”记为 SENT，正文说明 SENT 只表示渠道接受） |
| 应用服务器可用 `Prefer: respond-async` 请求投递回执，服务以 202 Accepted 响应并给出 receipt 订阅；用户代理确认后回执为 204，提前放弃重试时为 410 | RFC 8030 Section 5.1、6.2、6.3 | RFC 8030 | 2026-10-19 | 已读原文（URL 可访问） | 无（替身未实现回执；正文列为排除项） |
| 请求必须带 TTL 头；服务可缩短 TTL 并在响应中返回实际值；TTL 到期后服务 MUST NOT 再尝试投递；服务不负责计入应用服务器发送耗时 | RFC 8030 Section 5.2；Section 7.2（接受后服务可提前过期） | RFC 8030 | 2026-10-19 | 已读原文（URL 可访问） | B1、B2（本地 expires_at 检查；替身未实现 TTL 头） |
| Topic 只替换同一订阅上“outstanding”（已存储未投递）的消息；替换请求创建新消息资源并删除同 Topic 旧资源 | RFC 8030 Section 5.4 | RFC 8030 | 2026-10-19 | 已读原文（URL 可访问） | 无（正文用于说明 Topic 不能消除已投递副本） |
| 用户代理用 DELETE 确认，以保证消息“at least once”送达；未在合理时间内确认则视为未送达并继续重试至过期 | RFC 8030 Section 6.2 | RFC 8030 | 2026-10-19 | 已读原文（URL 可访问） | 无（概念依据：外部链路本身是至少一次） |
| 服务器对 DATA 结束返回 2yz 即承担投递责任；4yz/5yz 后服务器 MUST NOT 再投递，客户端保留责任 | RFC 5321 Section 4.2.5 | RFC 5321（2008-10） | 2026-10-19 | 已读原文（https://www.rfc-editor.org/rfc/rfc5321.txt 可访问） | F1（类比：接受前拒绝可安全重试） |
| 等待“250 OK”时的伪超时“would typically result in delivery of multiple copies of the message” | RFC 5321 Section 4.5.3.2.6（DATA Termination: 10 Minutes） | RFC 5321 | 2026-10-19 | 已读原文（URL 可访问） | T1、T2、NC2 |
| 接受后服务器承担投递责任；“To avoid receiving duplicate messages as the result of timeouts”，服务器 MUST 尽量缩短对结束符的响应时间，并指向 RFC 1047 | RFC 5321 Section 6.1（Reliable Delivery and Replies by Email） | RFC 5321 | 2026-10-19 | 已读原文（URL 可访问） | NC2 |
| RFC 1047《Duplicate messages and SMTP》讨论确认丢失导致的重复 | RFC 1047（由 RFC 5321 [40] 引用） | RFC 1047 | 2026-10-19 | 仅书目信息，本环境未读取全文 | 无（只用于说明出处，不支撑细节） |
| 发送方失败后必须延迟重试，参数必须可配置 | RFC 5321 Section 4.5.4.1（Sending Strategy） | RFC 5321 | 2026-10-19 | 已读原文（URL 可访问） | T3（retryDelay、max_attempts 为配置项） |
| 客户端 SHOULD NOT 自动重试非幂等方法，除非能知道语义实际幂等或能检测原请求未生效 | RFC 9110 Section 9.2.2（Idempotent Methods） | RFC 9110（2022-06） | 2026-10-19 | 已读原文（https://www.rfc-editor.org/rfc/rfc9110.txt 可访问） | T1（幂等键）、T2（查询）、NC2（反例） |
| `Idempotency-Key` 请求头用于让 POST/PATCH 容错，处于 Internet-Draft 阶段 | draft-ietf-httpapi-idempotency-key-header-07，Abstract | -07（2025-10-15，标注 2026-04-18 过期） | 2026-10-19 | 已读原文（https://www.ietf.org/archive/id/draft-ietf-httpapi-idempotency-key-header-07.txt 可访问），只引用摘要与草案状态 | T1、P1（替身自定契约，不声称符合草案细节） |
| `SKIP LOCKED` 跳过不能立即加锁的行，提供不一致视图，适合多个消费者访问队列式表 | PostgreSQL 16 SELECT 参考页，The Locking Clause | 16（本机 16.15） | 2026-10-19 | 本地 man 页（/usr/share/postgresql/16/man/man7/SELECT.7.gz） | C1、NC1 |
| 带唯一索引的 INSERT 可能被并发会话阻塞（见 64.5）；`ON CONFLICT DO NOTHING` 以不插入作为替代动作 | PostgreSQL 16 INSERT 参考页（Description、ON CONFLICT Clause） | 16 | 2026-10-19 | 已读原文（https://www.postgresql.org/docs/16/sql-insert.html 可访问）+ 本地 man 页 | N1 |
| Read Committed 下 `ON CONFLICT DO NOTHING` 可能因另一事务的结果而不插入，即使其效果对本 INSERT 快照不可见 | PostgreSQL 16 文档 13.2.1 Read Committed Isolation Level | 16 | 2026-10-19 | 已读原文（https://www.postgresql.org/docs/16/transaction-iso.html 可访问） | N1（之后用新语句读取已提交行） |
| `HttpRequest.Builder.timeout`：未在时限内收到响应则 `HttpClient::send` 抛出 `HttpTimeoutException` | Java SE 21 API，java.net.http.HttpRequest.Builder#timeout | Java SE 21 | 2026-10-19 | 已读原文（https://docs.oracle.com/en/java/javase/21/docs/api/java.net.http/java/net/http/HttpRequest.Builder.html 可访问） | T1、T2、T3、P2 |

## 第 34 篇来源卡：可撤销短链与访问统计

| 论断 | 来源（标准/论文/官方文档/源码，含章节） | 版本 | 核对日期 | 核对方式 | 对应实验 |
|---|---|---|---|---|---|
| 301、308 表示资源已分配新的永久 URI；302、307 表示暂时位于另一 URI，客户端应继续使用原 URI；307/308 禁止改写方法，301/302 允许 POST 改为 GET | RFC 9110 §15.4、§15.4.2、§15.4.3、§15.4.8、§15.4.9（https://www.rfc-editor.org/rfc/rfc9110.txt） | RFC 9110（2022-06） | 2026-10-19 | 已读原文（URL 可访问） | R1（选 302、只允许 GET/HEAD） |
| 可启发式缓存的状态码包括 200、203、204、206、300、301、308、404、405、410、414、501；302、307 不在其中 | RFC 9110 §15.1，以及 §15.4.2、§15.4.9、§15.5.5、§15.5.11 各节末尾的说明 | RFC 9110 | 2026-10-19 | 已读原文（URL 可访问） | R1 |
| 缓存可在无显式过期时间时自行估算新鲜期，规范不规定算法；存在显式过期时间时不得使用启发式；Last-Modified 场景下“典型取值可能为 10%” | RFC 9111 §4.2.2（https://www.rfc-editor.org/rfc/rfc9111.txt） | RFC 9111（2022-06） | 2026-10-19 | 已读原文（URL 可访问） | R1（正文推理，未在真实缓存上实验） |
| 无 public/private/Expires/max-age/s-maxage/缓存扩展的响应，只有状态码可启发式缓存时才可存储 | RFC 9111 §3 | RFC 9111 | 2026-10-19 | 已读原文（URL 可访问） | R1 |
| `no-store` 对私有与共享缓存都适用，缓存不得存储；该指令对恶意或被攻破的缓存不是可靠保证 | RFC 9111 §5.2.2.5 | RFC 9111 | 2026-10-19 | 已读原文（URL 可访问） | R1 |
| Location 不带片段时，用户代理继承原请求 URI 的片段；可能造成跨站片段泄露 | RFC 9110 §10.2.2、§17.11 | RFC 9110 | 2026-10-19 | 已读原文（URL 可访问） | 无（列为限制） |
| 接收方应把来自不可信来源的 http(s) URI 中的 userinfo 视为错误，它常被用来掩盖真实主机 | RFC 9110 §4.2.4 | RFC 9110 | 2026-10-19 | 已读原文（URL 可访问） | V1 |
| userinfo 位于主机之前，可构造误导用户的 URI（语义攻击） | RFC 3986 §7.6（https://www.rfc-editor.org/rfc/rfc3986.txt） | RFC 3986（2005-01） | 2026-10-19 | 已读原文（URL 可访问） | V1 |
| 开放重定向器的定义：用参数指定位置、不经校验即重定向用户代理的端点；可用于钓鱼 | RFC 6749 §10.15（https://www.rfc-editor.org/rfc/rfc6749.txt） | RFC 6749（2012-10） | 2026-10-19 | 已读原文（URL 可访问） | V1（只证明语法校验） |
| `ON CONFLICT DO NOTHING` 冲突时不插入；`ON CONFLICT DO UPDATE` 保证原子的插入或更新结果，冲突时更新已有行 | PostgreSQL 16 INSERT 参考页（本地 /usr/share/postgresql/16/man/man7/INSERT.7.gz；https://www.postgresql.org/docs/16/sql-insert.html） | PostgreSQL 16.15 | 2026-10-19 | 本地 man 页 | A1、A2、A3、NC1 |
| 唯一冲突的 SQLSTATE 为 23505，锁等待超时为 55P03，连接失败为 08001 | PostgreSQL 16 附录 A 错误码（https://www.postgresql.org/docs/16/errcodes-appendix.html） | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | A1、S2、S3 |
| ACCESS EXCLUSIVE 与所有锁模式冲突；INSERT 获取 ROW EXCLUSIVE | PostgreSQL 16 §13.3.1 表级锁（https://www.postgresql.org/docs/16/explicit-locking.html） | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问）；本地 man 页 LOCK.7.gz | S3、NC2 |
| `lock_timeout`：语句等待锁超过设定时长即中止，每次加锁尝试分别计时，0 为不限 | PostgreSQL 16 §20.11.1（https://www.postgresql.org/docs/16/runtime-config-client.html） | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | S3、NC2 |
| 事务级咨询锁 `pg_advisory_xact_lock` 获取排他锁、必要时等待，事务结束时自动释放 | PostgreSQL 16 §13.3.5 咨询锁、§9.27.10 咨询锁函数（https://www.postgresql.org/docs/16/explicit-locking.html） | PostgreSQL 16 | 2026-10-19 | 已读原文（URL 可访问） | R5、NC4 |
| 序列值在调用 nextval 时分配，不随事务回滚回收，序列不能提供无间隙序号；分配顺序与提交顺序无关（小序号可能晚于大序号提交） | PostgreSQL 16 §9.17 序列操作函数（https://www.postgresql.org/docs/16/functions-sequence.html）说明不回收与间隙；“分配顺序≠提交顺序”由 NC4 实测（seq(X) 小于 seq(Y) 但晚提交） | PostgreSQL 16.15 | 2026-10-19 | 已读原文（URL 可访问）+ 实验观察 | NC4 |
| `ConcurrentHashMap.compute` / `computeIfPresent` 整个调用原子执行 | Java SE 21 API：java.util.concurrent.ConcurrentHashMap（https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/ConcurrentHashMap.html） | JDK 21 | 2026-10-19 | 已读原文（URL 可访问） | R4、NC3 |

说明：未检索或引用任何博客、教程文章。码空间、冲突概率与读写比是教学假设，不来自任何来源。

## 第 35 篇来源卡：文件上传与异步处理

| 论断 | 来源（标准/论文/官方文档/源码，含章节） | 版本 | 核对日期 | 核对方式 | 对应实验 |
|---|---|---|---|---|---|
| 分块号 1–10000，可不连续；用同一分块号再次上传会覆盖之前的分块 | Amazon S3 User Guide《Uploading and copying objects using multipart upload》, Multipart upload process | 在线文档（2026-10-19 取得） | 2026-10-19 | 已读原文（https://docs.aws.amazon.com/AmazonS3/latest/userguide/mpuoverview.html 可访问） | U2（本实现选择相反语义：同号异内容报 PART_CONFLICT） |
| 完成时按分块号升序拼接；完成后分块不再存在；启动后上传了分块就必须 complete 或 abort，否则持续计费 | 同上，Multipart upload completion 与 Important 提示 | 同上 | 2026-10-19 | 已读原文（URL 可访问） | U1、U6 |
| 未开版本控制时，上传开始到完成之间的其他请求可能优先；complete 响应可能显示成功却从未看到对象 | 同上，Concurrent multipart upload operations | 同上 | 2026-10-19 | 已读原文（URL 可访问） | 无（正文用于说明内容寻址 + 元数据提交的动机） |
| CompleteMultipartUpload 处理可能持续数分钟，先返回 200 OK 再用空白字符保活，错误可嵌在 200 响应体中；失败时应用需准备重试 | Amazon S3 API Reference, CompleteMultipartUpload 描述段 | 在线文档 | 2026-10-19 | 已读原文（https://docs.aws.amazon.com/AmazonS3/latest/API/API_CompleteMultipartUpload.html 可访问） | P1b（complete 需可重试、幂等） |
| abort 后不能再用该 upload ID 上传；进行中的分块上传可能仍成功，可能需多次 abort，并用 ListParts 确认为空 | Amazon S3 API Reference, AbortMultipartUpload 描述段 | 在线文档 | 2026-10-19 | 已读原文（https://docs.aws.amazon.com/AmazonS3/latest/API/API_AbortMultipartUpload.html 可访问） | U6（本实现用会话行锁串行化 abort 与分块登记） |
| 生命周期规则 AbortIncompleteMultipartUpload/DaysAfterInitiation 让启动后指定天数内未完成的上传成为中止对象；对已完成上传和对象无效 | Amazon S3 User Guide《Configuring a bucket lifecycle configuration to delete incomplete multipart uploads》 | 在线文档 | 2026-10-19 | 已读原文（https://docs.aws.amazon.com/AmazonS3/latest/userguide/mpu-abort-incomplete-mpu-lifecycle-config.html 可访问） | M2、P1a（会话 TTL 对应同一思路） |
| PATCH 的 Upload-Offset 必须等于当前偏移，否则 409 Conflict 且不修改资源 | tus Resumable Upload Protocol 1.0.x, Core Protocol / PATCH | 1.0.0（2016-03-25） | 2026-10-19 | 已读原文（https://tus.io/protocols/resumable-upload 可访问） | U2（PART_CONFLICT 的对照语义） |
| Checksum 扩展：Upload-Checksum 不符时返回 460 Checksum Mismatch，该块必须丢弃、偏移不得更新 | tus 1.0.x, Checksum extension | 1.0.0 | 2026-10-19 | 已读原文（URL 可访问） | U2（CHECKSUM_MISMATCH，未登记） |
| Expiration 扩展：服务端可删除过期的未完成上传，Upload-Expires 指出时间；已删除的上传应返回 404 或 410 | tus 1.0.x, Expiration extension | 1.0.0 | 2026-10-19 | 已读原文（URL 可访问） | M2、P1a |
| Termination 扩展：DELETE 后返回 204，之后该 URL 返回 404/410 | tus 1.0.x, Termination extension | 1.0.0 | 2026-10-19 | 已读原文（URL 可访问） | U6 |
| Concatenation 扩展：partial 上传在拼成 final 之前服务端不应处理；对 final 的 PATCH 返回 403 | tus 1.0.x, Concatenation extension | 1.0.0 | 2026-10-19 | 已读原文（URL 可访问） | 无（正文方案比较） |
| Content-Digest 作用于消息内容，Repr-Digest 作用于完整选定表示；sha-256、sha-512 状态 Active，md5、crc32c 等 Deprecated | RFC 9530 Section 2、3、5、7.2 | RFC 9530（2024-02） | 2026-10-19 | 已读原文（https://www.rfc-editor.org/rfc/rfc9530.txt 可访问） | U2（分块摘要）、U3（整体摘要） |
| 摘要字段单独使用不提供跨多跳的端到端完整性，元数据可被篡改 | RFC 9530 Section 6.2 | RFC 9530 | 2026-10-19 | 已读原文（URL 可访问） | 无（正文限制：摘要只防损坏不防篡改） |
| newpath 已存在时被原子替换，其他进程访问 newpath 不会发现它缺失；可能存在两路径都指向该文件的窗口；跨挂载点返回 EXDEV | Linux man-pages rename(2) DESCRIPTION、ERRORS | man-pages 6.19（2026-02-08） | 2026-10-19 | 已读原文（https://man7.org/linux/man-pages/man2/rename.2.html 可访问；本机 man 页已被精简移除） | NC4 后 complete、P1b |
| rename 期间名为 new 的目录项对其他线程始终可见，指向操作前 new 或 old 所指文件 | POSIX.1-2024 (IEEE Std 1003.1-2024, Issue 8) rename() DESCRIPTION | Issue 8 | 2026-10-19 | 已读原文（https://pubs.opengroup.org/onlinepubs/9799919799/functions/rename.html 可访问） | 同上 |
| fsync 刷文件数据与元数据，但不保证包含该文件的目录项落盘，需要对目录 fd 再 fsync | Linux man-pages fsync(2) DESCRIPTION | man-pages 6.19 | 2026-10-19 | 已读原文（https://man7.org/linux/man-pages/man2/fsync.2.html 可访问） | Store.fsyncDir（代码遵循；崩溃效果未观察到） |
| POSIX fsync 的传输方式由实现定义；未定义 _POSIX_SYNCHRONIZED_IO 时允许空实现 | POSIX.1-2024 fsync() DESCRIPTION、RATIONALE | Issue 8 | 2026-10-19 | 已读原文（https://pubs.opengroup.org/onlinepubs/9799919799/functions/fsync.html 可访问） | 无（LIMITS：持久性未验证） |
| ATOMIC_MOVE：作为原子文件系统操作执行，其他选项被忽略；目标已存在时替换还是抛 IOException 由实现决定；无法原子移动时抛 AtomicMoveNotSupportedException（如跨 FileStore） | Java SE 21 API, java.nio.file.Files.move | Java SE 21 | 2026-10-19 | 已读原文（https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/nio/file/Files.html 可访问） | U1、NC4、P1b |
| FileChannel.force：本地存储设备上返回时保证此前改动已写入设备；非本地设备不保证；metaData 参数效果依赖操作系统 | Java SE 21 API, java.nio.channels.FileChannel.force(boolean) | Java SE 21 | 2026-10-19 | 已读原文（https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/nio/channels/FileChannel.html 可访问） | Store.writeDurable |
| Read Committed 下 UPDATE 遇到被并发更新的目标行时等待，提交后对新版本重新求值 WHERE | PostgreSQL 16 文档 13.2.1 Read Committed Isolation Level | 16 | 2026-10-19 | 已读原文（https://www.postgresql.org/docs/16/transaction-iso.html 可访问） | P2（迟到 publish 的条件更新返回 0 行）、NC1 |
