# 容器系列的共用探针

此处只运行自己编写、可审计的教学程序；不是生产容器启动器，不接受不可信代码。实验前读取 `writing-plans/containers/VERSIONS.md`，按文章素材目录中的 `RUN.md` 核对条件。不要在共享节点上直接执行提权、挂载、网络故障或资源压力实验。

```sh
gcc -std=c11 -Wall -Wextra -Werror -O2 process_probe.c -o /tmp/containers-process-probe
/tmp/containers-process-probe inherit
/tmp/containers-process-probe cloexec
/tmp/containers-process-probe zombie
python3 probe_app.py --port 18080 --state-dir /tmp/containers-my-own-state
```

`process_probe.c` 只在本进程的临时文件上做描述符实验；僵尸案例睡眠不超过 1 秒并总是调用 `waitpid` 回收。`probe_app.py` 默认监听 loopback，单次写入最多 4096 字节。不要把 `/tmp/containers-my-own-state` 指向现有数据目录。`env_probe.sh` 只读，不会尝试切换默认网络或向 cgroup 写入。

`root_probe.py` 与 `uid_probe.py` 只操作调用者新建的空目录。`teaching_launcher.c` 固定执行同目录内自编译的 `process_probe`，只展示 user/UTS/IPC namespace 与退出回收；没有根文件系统切换、资源限制、seccomp、LSM、网络或强安全隔离，不能运行外来程序。

`bounded_load.py` 用于对照计算负载，每次最多占用自申请的 32 MiB 字节数组、运行 2 秒；只有在专用 VM 已委派的 cgroup 子目录内才能把它用作资源限制实验，绝不可对共享宿主 cgroup 开始故障注入。

`oci_layout.py` 用相同的 `probe_app.py` 源文件建立供解析的 OCI image layout 示范；层内只有脚本，不含 Python 解释器，故不是可直接启动的镜像。`verify` 从真实 blob 字节重新计算压缩层摘要、解压后 DiffID、配置与 manifest 摘要。不可将其输出当成容器运行成功证据。

`Dockerfile.single`、`Dockerfile.multi` 与 `Dockerfile.secret` 只描述在专用 VM 构建相同探针的不同路径；基础镜像的实际 digest 需在实验机器上解析并记录，不能把 `python:3.12-slim` 标签当成冻结版本。合成测试密钥仅由该实验 VM 生成并用 BuildKit secret mount 传入，不写入仓库。

`compose.yaml` 只有在专用 VM 为 `PROBE_IMAGE` 提供实际 `repo@sha256:...` 值时才可用于单机交付；本仓库没有 runtime，也没有伪造的远端 digest。
