import argparse
import json
import os
import pathlib
import time
from http.server import BaseHTTPRequestHandler, HTTPServer


def identity():
    return {
        "pid": os.getpid(),
        "ppid": os.getppid(),
        "uid": os.getuid(),
        "namespace": {name: os.readlink(f"/proc/self/ns/{name}") for name in ("pid", "mnt", "net", "user")},
        "cgroup": pathlib.Path("/proc/self/cgroup").read_text(),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=18080)
    parser.add_argument("--state-dir", type=pathlib.Path, required=True)
    parser.add_argument("--ready-delay", type=float, default=0)
    args = parser.parse_args()
    if not 0 <= args.ready_delay <= 30:
        parser.error("ready-delay must be between 0 and 30 seconds")
    args.state_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    started = time.monotonic()

    class Handler(BaseHTTPRequestHandler):
        def reply(self, status, data):
            payload = json.dumps(data, ensure_ascii=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

        def do_GET(self):
            if self.path == "/health":
                self.reply(200, {"alive": True})
            elif self.path == "/ready":
                ready = time.monotonic() - started >= args.ready_delay
                self.reply(200 if ready else 503, {"ready": ready})
            elif self.path == "/identity":
                self.reply(200, identity())
            elif self.path == "/state":
                state_file = args.state_dir / "state.txt"
                self.reply(200, {"value": state_file.read_text() if state_file.exists() else None})
            else:
                self.reply(404, {"error": "unknown path"})

        def do_POST(self):
            if self.path != "/state":
                self.reply(404, {"error": "unknown path"})
                return
            try:
                length = int(self.headers.get("Content-Length", ""))
            except ValueError:
                length = -1
            if not 0 <= length <= 4096:
                self.reply(413, {"error": "invalid content length"})
                return
            payload = self.rfile.read(length)
            (args.state_dir / "state.txt").write_bytes(payload)
            self.reply(200, {"bytes": length})

    server = HTTPServer((args.host, args.port), Handler)
    print(json.dumps({"listen": server.server_address, "pid": os.getpid()}), flush=True)
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
