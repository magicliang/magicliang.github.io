#!/bin/sh
set -u

run() {
    printf '\nCOMMAND: %s\n' "$*"
    "$@" 2>&1
    result=$?
    printf 'EXIT_CODE: %s\n' "$result"
}

printf 'UTC_BEGIN: '; date -u -Iseconds
run uname -a
run cat /etc/os-release
run id
run cat /proc/self/cgroup
run cat /proc/self/uid_map
run cat /proc/self/gid_map
run sh -c 'for entry in /proc/self/ns/*; do printf "%s %s\n" "$entry" "$(readlink "$entry")"; done'
run sh -c 'for entry in /sys/fs/cgroup/cgroup.controllers /sys/fs/cgroup/cpu.max; do if test -f "$entry"; then cat "$entry"; else printf "%s NOT_AVAILABLE\n" "$entry"; fi; done'
run sh -c 'for name in docker podman nerdctl ctr runc kind kubectl ip gcc python3; do if command -v "$name" >/dev/null 2>&1; then command -v "$name"; else printf "%s NOT_AVAILABLE\n" "$name"; fi; done'
run sh -c 'grep -E "^(CapEff|CapBnd|Seccomp|NoNewPrivs):" /proc/self/status'
run sh -c 'test -w /sys/fs/cgroup'
printf 'UTC_END: '; date -u -Iseconds
