import argparse
import hashlib
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seconds", type=float, default=0.5)
    parser.add_argument("--memory-mib", type=int, default=0)
    args = parser.parse_args()
    if not 0 <= args.seconds <= 2 or not 0 <= args.memory_mib <= 32:
        parser.error("seconds: 0..2; memory-mib: 0..32")
    buffer = bytearray(args.memory_mib * 1024 * 1024)
    for offset in range(0, len(buffer), 4096):
        buffer[offset] = 1
    start = time.monotonic()
    iterations = 0
    data = b"containers teaching workload"
    while time.monotonic() - start < args.seconds:
        data = hashlib.sha256(data).digest()
        iterations += 1
    print(f"iterations={iterations} seconds={time.monotonic() - start:.3f} memory_mib={args.memory_mib}")


if __name__ == "__main__":
    main()
