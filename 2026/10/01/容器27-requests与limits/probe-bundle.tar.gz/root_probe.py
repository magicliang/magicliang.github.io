import os
import sys


root_directory = sys.argv[1]
original_root = os.open("/", os.O_RDONLY | os.O_DIRECTORY)
print("before_root=" + os.readlink("/proc/self/root"), flush=True)
os.chroot(root_directory)
os.chdir("/")
print("inside_root=" + os.getcwd(), flush=True)
os.fchdir(original_root)
with open("etc/os-release") as source:
    print("retained_fd_old_root=" + source.readline().strip(), flush=True)
os.close(original_root)
