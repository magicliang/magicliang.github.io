#!/bin/sh
set -eu
image=${1:?usage: sh verify_volume.sh built-image}
engine=${CONTAINER_ENGINE:-docker}
directory=$(mktemp -d)
volume="containers-volume-check-$(basename "$directory" | tr '[:upper:]' '[:lower:]')"
created=false
cleanup() {
    if [ "$created" = true ]; then "$engine" volume rm "$volume"; fi
    rmdir "$directory"
}
trap cleanup EXIT
trap 'exit 1' HUP INT TERM
"$engine" volume create "$volume"
created=true
"$engine" run --rm -v "$volume:/tmp/containers-state" --entrypoint python3 "$image" -c 'import os,pathlib; p=pathlib.Path("/tmp/containers-state/state.txt"); assert os.getuid()==65532; p.write_text("volume-check"); assert p.read_text()=="volume-check"'
"$engine" run --rm -v "$volume:/tmp/containers-state" --entrypoint python3 "$image" -c 'import pathlib; assert pathlib.Path("/tmp/containers-state/state.txt").read_text()=="volume-check"'
"$engine" run --rm -v "$volume:/tmp/containers-state:ro" --entrypoint python3 "$image" -c 'import errno,pathlib
try:
    pathlib.Path("/tmp/containers-state/state.txt").write_text("unexpected")
except OSError as error:
    assert error.errno == errno.EROFS, error
else:
    raise AssertionError("read-only write succeeded")'
"$engine" run --rm -v "$volume:/tmp/containers-state" --entrypoint python3 "$image" -c 'import pathlib; assert pathlib.Path("/tmp/containers-state/state.txt").read_text()=="volume-check"'
printf 'PASS: UID 65532 write, recreation readback, read-only rejection\n'
