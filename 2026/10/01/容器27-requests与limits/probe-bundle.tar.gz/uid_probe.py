import os
import pathlib
import sys


directory = pathlib.Path(sys.argv[1])
print("inside_uid=" + str(os.getuid()) + " inside_gid=" + str(os.getgid()))
print("uid_map=" + pathlib.Path("/proc/self/uid_map").read_text().strip())
print("gid_map=" + pathlib.Path("/proc/self/gid_map").read_text().strip())
print("directory_owner_inside=" + str(directory.stat().st_uid))
(directory / "owned.txt").write_text("only my file\n")
print("write=ok")
