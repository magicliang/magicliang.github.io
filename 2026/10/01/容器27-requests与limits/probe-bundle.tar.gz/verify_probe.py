import argparse
import hashlib
import json
import pathlib
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request


def wait_text(path, needle, process):
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        text = path.read_text()
        if needle in text:
            return text
        if process.poll() is not None:
            break
        time.sleep(0.02)
    raise AssertionError(f'{needle!r} absent from {path}: {path.read_text()}')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--evidence-dir', type=pathlib.Path, required=True)
    args = parser.parse_args()
    evidence = args.evidence_dir.resolve()
    evidence.mkdir(parents=True, exist_ok=True)
    app = pathlib.Path(__file__).with_name('probe_app.py')
    print('Source SHA256:', hashlib.sha256(app.read_bytes()).hexdigest(), flush=True)
    print('Scope: ordinary local HTTP process; Docker and volume behavior NOT_RUN.', flush=True)
    for scenario in ('idle', 'inflight_complete', 'inflight_idle', 'inflight_deadline', 'incomplete_body', 'accept_boundary'):
        log = evidence / f'{scenario}.stdout.txt'
        err = evidence / f'{scenario}.stderr.txt'
        with tempfile.TemporaryDirectory(prefix='probe-check-') as temporary, log.open('w') as stdout, err.open('w') as stderr:
            state = pathlib.Path(temporary) / 'state'
            invocation = [sys.executable, str(app), '--port', '0', '--state-dir', str(state)]
            gate = pathlib.Path(temporary) / 'accept-gate'
            if scenario == 'accept_boundary':
                wrapper = """
import pathlib, runpy, sys, time
from http.server import HTTPServer
original = HTTPServer.get_request
accepted = 0
gate = pathlib.Path(sys.argv.pop(1))
def paused_accept(server):
    global accepted
    connection, address = original(server)
    accepted += 1
    if accepted == 3:
        print('{"event": "accept_boundary"}', flush=True)
        deadline = time.monotonic() + 5
        while not gate.exists() and time.monotonic() < deadline:
            time.sleep(.01)
    return connection, address
HTTPServer.get_request = paused_accept
sys.argv = sys.argv[1:]
runpy.run_path(sys.argv[0], run_name='__main__')
"""
                invocation = [sys.executable, '-c', wrapper, str(gate), *invocation[1:]]
            proc = subprocess.Popen(invocation, stdout=stdout, stderr=stderr)
            client = None
            sender = None
            try:
                startup = wait_text(log, '"listen"', proc)
                port = json.loads(startup.splitlines()[0])['listen'][1]
                url = f'http://127.0.0.1:{port}/state'
                with urllib.request.urlopen(urllib.request.Request(url, data=b'baseline', method='POST'), timeout=3) as response:
                    assert response.status == 200 and json.load(response) == {'bytes': 8}
                with urllib.request.urlopen(url, timeout=3) as response:
                    assert response.status == 200 and json.load(response) == {'value': 'baseline'}
                if scenario != 'idle':
                    client = socket.create_connection(('127.0.0.1', port), timeout=5)
                    client.sendall(b'POST /state HTTP/1.0\r\nContent-Length: 100\r\n\r\nx')
                    wait_text(log, '"accept_boundary"' if scenario == 'accept_boundary' else '"bytes": 100', proc)
                if scenario == 'incomplete_body':
                    client.shutdown(socket.SHUT_WR)
                    reply = client.recv(4096)
                    assert b'400' in reply.split(b'\r\n', 1)[0], reply
                started = time.monotonic()
                proc.terminate()
                wait_text(log, '"signal": "SIGTERM"', proc)
                if scenario == 'accept_boundary':
                    gate.write_text('release')
                if scenario == 'inflight_complete':
                    client.sendall(b'x' * 99)
                    reply = client.recv(4096)
                    assert b'200' in reply.split(b'\r\n', 1)[0], reply
                if scenario == 'inflight_deadline':
                    def trickle():
                        try:
                            while proc.poll() is None:
                                client.sendall(b'x')
                                time.sleep(0.1)
                        except OSError:
                            pass
                    sender = threading.Thread(target=trickle)
                    sender.start()
                assert proc.wait(timeout=5) == 0
                elapsed = time.monotonic() - started
                if scenario == 'inflight_deadline':
                    assert '"event": "grace_expired"' in log.read_text()
                assert '"event": "stopped"' in log.read_text()
                assert 'Traceback' not in err.read_text(), err.read_text()
                expected = 'x' * 100 if scenario == 'inflight_complete' else 'baseline'
                assert (state / 'state.txt').read_text() == expected
                print(json.dumps({'scenario': scenario, 'result': 'PASS', 'invocation': invocation,
                                  'post_status': 200, 'get_status': 200, 'exit_code': proc.returncode,
                                  'seconds': round(elapsed, 3), 'state': expected,
                                  'stdout': str(log), 'stderr': str(err)}), flush=True)
            finally:
                if proc.poll() is None:
                    proc.kill()
                    proc.wait()
                if sender is not None:
                    sender.join(timeout=2)
                    assert not sender.is_alive()
                if client:
                    client.close()
    print('PASS: 6 local scenarios; writes/readback, signal/stopped logs, bounded exit 0, no partial state writes.', flush=True)


if __name__ == '__main__':
    main()
