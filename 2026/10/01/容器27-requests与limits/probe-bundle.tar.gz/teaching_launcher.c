#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

static void fail(const char *operation) {
    perror(operation);
    exit(EXIT_FAILURE);
}

static void write_file(const char *path, const char *contents) {
    int descriptor = open(path, O_WRONLY | O_CLOEXEC);
    if (descriptor < 0) fail(path);
    size_t length = strlen(contents);
    if (write(descriptor, contents, length) != (ssize_t)length) fail(path);
    if (close(descriptor) < 0) fail(path);
}

int main(void) {
    uid_t outside_uid = getuid();
    gid_t outside_gid = getgid();
    if (unshare(CLONE_NEWUSER) < 0) fail("unshare user");
    write_file("/proc/self/setgroups", "deny\n");
    char mapping[64];
    snprintf(mapping, sizeof(mapping), "0 %lu 1\n", (unsigned long)outside_uid);
    write_file("/proc/self/uid_map", mapping);
    snprintf(mapping, sizeof(mapping), "0 %lu 1\n", (unsigned long)outside_gid);
    write_file("/proc/self/gid_map", mapping);
    if (unshare(CLONE_NEWUTS | CLONE_NEWIPC) < 0) fail("unshare uts ipc");
    if (sethostname("containers-teaching", strlen("containers-teaching")) < 0) fail("sethostname");
    char namespace[128];
    ssize_t bytes = readlink("/proc/self/ns/uts", namespace, sizeof(namespace) - 1);
    if (bytes < 0) fail("readlink uts");
    namespace[bytes] = '\0';
    printf("launcher_pid=%ld uts=%s\n", (long)getpid(), namespace);
    fflush(stdout);
    pid_t child = fork();
    if (child < 0) fail("fork");
    if (child == 0) {
        execl("./process_probe", "./process_probe", "inherit", (char *)NULL);
        fail("exec trusted probe");
    }
    int status;
    if (waitpid(child, &status, 0) != child) fail("waitpid");
    printf("launcher_child=%ld status=%d\n", (long)child,
           WIFEXITED(status) ? WEXITSTATUS(status) : -1);
    return WIFEXITED(status) ? WEXITSTATUS(status) : EXIT_FAILURE;
}
