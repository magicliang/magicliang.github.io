#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

static void fail(const char *operation) {
    perror(operation);
    exit(EXIT_FAILURE);
}

int main(int argc, char **argv) {
    if (argc == 3 && strcmp(argv[1], "child") == 0) {
        int descriptor = atoi(argv[2]);
        printf("event=exec_child pid=%ld ppid=%ld descriptor=%d open=%s\n",
               (long)getpid(), (long)getppid(), descriptor,
               fcntl(descriptor, F_GETFD) == -1 ? "no" : "yes");
        return 7;
    }
    if (argc != 2 || (strcmp(argv[1], "inherit") != 0 &&
                      strcmp(argv[1], "cloexec") != 0 &&
                      strcmp(argv[1], "zombie") != 0)) {
        fprintf(stderr, "usage: %s inherit|cloexec|zombie\n", argv[0]);
        return 2;
    }
    char path[] = "/tmp/containers-process-probe-XXXXXX";
    int descriptor = mkstemp(path);
    if (descriptor < 0) fail("mkstemp");
    if (unlink(path) < 0) fail("unlink");
    if (strcmp(argv[1], "cloexec") == 0 &&
        fcntl(descriptor, F_SETFD, FD_CLOEXEC) < 0) fail("fcntl");
    fflush(stdout);
    pid_t child = fork();
    if (child < 0) fail("fork");
    if (child == 0) {
        if (strcmp(argv[1], "zombie") == 0) _exit(7);
        char number[32];
        snprintf(number, sizeof(number), "%d", descriptor);
        execl(argv[0], argv[0], "child", number, (char *)NULL);
        fail("execl");
    }
    if (strcmp(argv[1], "zombie") == 0) {
        sleep(1);
        char status_path[64];
        snprintf(status_path, sizeof(status_path), "/proc/%ld/status", (long)child);
        FILE *status_file = fopen(status_path, "r");
        if (!status_file) fail("fopen child status");
        char line[256];
        while (fgets(line, sizeof(line), status_file)) {
            if (strncmp(line, "State:", 6) == 0) {
                printf("event=before_wait %s", line);
                break;
            }
        }
        fclose(status_file);
    }
    int status;
    if (waitpid(child, &status, 0) != child) fail("waitpid");
    printf("event=wait parent=%ld child=%ld exited=%d code=%d signaled=%d\n",
           (long)getpid(), (long)child, WIFEXITED(status),
           WIFEXITED(status) ? WEXITSTATUS(status) : -1, WIFSIGNALED(status));
    if (close(descriptor) < 0) fail("close");
    return WIFEXITED(status) && WEXITSTATUS(status) == 7 ? 0 : 1;
}
