import argparse
import gzip
import hashlib
import io
import json
import pathlib
import platform
import tarfile


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def digest(data):
    return "sha256:" + hashlib.sha256(data).hexdigest()


def store(root, data, media_type):
    identifier = digest(data)
    location = root / "blobs" / "sha256" / identifier[7:]
    location.parent.mkdir(parents=True, exist_ok=True)
    location.write_bytes(data)
    return {"mediaType": media_type, "digest": identifier, "size": len(data)}


def create(root, source):
    root.mkdir(parents=True, exist_ok=False)
    layer_buffer = io.BytesIO()
    with tarfile.open(fileobj=layer_buffer, mode="w") as archive:
        content = source.read_bytes()
        entry = tarfile.TarInfo("probe_app.py")
        entry.size = len(content)
        entry.mode = 0o644
        entry.mtime = 0
        archive.addfile(entry, io.BytesIO(content))
    raw_layer = layer_buffer.getvalue()
    compressed = io.BytesIO()
    with gzip.GzipFile(fileobj=compressed, mode="wb", mtime=0) as archive:
        archive.write(raw_layer)
    layer = store(root, compressed.getvalue(), "application/vnd.oci.image.layer.v1.tar+gzip")
    machine = {"x86_64": "amd64", "aarch64": "arm64"}.get(platform.machine())
    if machine is None:
        raise ValueError("unsupported example architecture")
    config = {
        "architecture": machine,
        "os": "linux",
        "rootfs": {"type": "layers", "diff_ids": [digest(raw_layer)]},
        "config": {"Env": [], "Cmd": ["/probe_app.py"]},
    }
    config_descriptor = store(root, encoded(config), "application/vnd.oci.image.config.v1+json")
    manifest = {"schemaVersion": 2, "config": config_descriptor, "layers": [layer]}
    manifest_descriptor = store(root, encoded(manifest), "application/vnd.oci.image.manifest.v1+json")
    index = {"schemaVersion": 2, "manifests": [dict(manifest_descriptor, platform={"architecture": machine, "os": "linux"})]}
    (root / "index.json").write_bytes(encoded(index))
    (root / "oci-layout").write_bytes(encoded({"imageLayoutVersion": "1.0.0"}))
    return manifest_descriptor["digest"]


def verify(root):
    def load(descriptor):
        name = descriptor["digest"]
        if not name.startswith("sha256:") or len(name) != 71:
            raise ValueError("invalid digest")
        content = (root / "blobs" / "sha256" / name[7:]).read_bytes()
        if len(content) != descriptor["size"] or digest(content) != name:
            raise ValueError("digest or size mismatch for " + name)
        return content

    index = json.loads((root / "index.json").read_bytes())
    manifest_descriptor = index["manifests"][0]
    manifest = json.loads(load(manifest_descriptor))
    config = json.loads(load(manifest["config"]))
    for layer, expected in zip(manifest["layers"], config["rootfs"]["diff_ids"], strict=True):
        if digest(gzip.decompress(load(layer))) != expected:
            raise ValueError("uncompressed DiffID mismatch")
    return manifest_descriptor["digest"], config["rootfs"]["diff_ids"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("create", "verify"))
    parser.add_argument("directory", type=pathlib.Path)
    parser.add_argument("--source", type=pathlib.Path, default=pathlib.Path(__file__).with_name("probe_app.py"))
    args = parser.parse_args()
    if args.command == "create":
        print("manifest=" + create(args.directory, args.source))
    else:
        manifest, diff_ids = verify(args.directory)
        print("verified_manifest=" + manifest)
        print("diff_ids=" + ",".join(diff_ids))


if __name__ == "__main__":
    main()
