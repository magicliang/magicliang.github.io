import argparse
import json
import os
import pathlib
import signal
import socket
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer


def identity():
    return {
        "pid": os.getpid(),
        "ppid": os.getppid(),
        "uid": os.getuid(),
        "namespace": {name: os.readlink(f"/proc/self/ns/{name}") for name in ("pid", "mnt", "net", "user")},
        "cgroup": pathlib.Path("/proc/self/cgroup").read_text(),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=18080)
    parser.add_argument("--state-dir", type=pathlib.Path, required=True)
    parser.add_argument("--ready-delay", type=float, default=0)
    args = parser.parse_args()
    if not 0 <= args.ready_delay <= 30:
        parser.error("ready-delay must be between 0 and 30 seconds")
    args.state_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    started = time.monotonic()

    class Server(HTTPServer):
        connection = None

        def get_request(self):
            connection, address = super().get_request()
            if stopped.is_set():
                connection.close()
                raise OSError("server is stopping")
            connection.settimeout(3)
            self.connection = connection
            return connection, address

        def close_request(self, request):
            self.connection = None
            super().close_request(request)

    class Handler(BaseHTTPRequestHandler):
        def reply(self, status, data):
            payload = json.dumps(data, ensure_ascii=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

        def do_GET(self):
            if self.path == "/health":
                self.reply(200, {"alive": True})
            elif self.path == "/ready":
                ready = time.monotonic() - started >= args.ready_delay
                self.reply(200 if ready else 503, {"ready": ready})
            elif self.path == "/identity":
                self.reply(200, identity())
            elif self.path == "/state":
                state_file = args.state_dir / "state.txt"
                self.reply(200, {"value": state_file.read_text() if state_file.exists() else None})
            else:
                self.reply(404, {"error": "unknown path"})

        def do_POST(self):
            if self.path != "/state":
                self.reply(404, {"error": "unknown path"})
                return
            try:
                length = int(self.headers.get("Content-Length", ""))
            except ValueError:
                length = -1
            if not 0 <= length <= 4096:
                self.reply(413, {"error": "invalid content length"})
                return
            print(json.dumps({"event": "state_read", "bytes": length}), flush=True)
            payload = self.rfile.read(length)
            if len(payload) != length:
                if not stopped.is_set():
                    self.reply(400, {"error": "incomplete body"})
                return
            (args.state_dir / "state.txt").write_bytes(payload)
            self.reply(200, {"bytes": length})

    server = Server((args.host, args.port), Handler)
    stopped = threading.Event()
    received_signal = None

    def stop(signum, frame):
        nonlocal received_signal
        if received_signal is None:
            received_signal = signum
            stopped.set()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    worker = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.2})
    worker.start()
    print(json.dumps({"listen": server.server_address, "pid": os.getpid()}), flush=True)
    try:
        stopped.wait()
        print(json.dumps({"event": "signal", "signal": signal.Signals(received_signal).name}), flush=True)
        def expire_request():
            connection = server.connection
            if connection is not None:
                print(json.dumps({"event": "grace_expired"}), flush=True)
                try:
                    connection.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass  # The request may have finished just before the deadline.

        deadline = threading.Timer(3, expire_request)
        deadline.start()
        try:
            # serve_forever runs on the worker, so shutdown cannot self-deadlock.
            server.shutdown()
        finally:
            deadline.cancel()
            deadline.join()
    finally:
        server.server_close()
        worker.join()
        print(json.dumps({"event": "stopped"}), flush=True)
        sys.stdout.flush()
        sys.stderr.flush()


if __name__ == "__main__":
    main()
