package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

type oneByteReader struct {
	reader io.Reader
}

func (input oneByteReader) Read(payload []byte) (int, error) {
	if len(payload) == 0 {
		return 0, nil
	}
	return input.reader.Read(payload[:1])
}

type partialWriter struct {
	bytes.Buffer
	closeCalls int
}

func (output *partialWriter) Write(payload []byte) (int, error) {
	if len(payload) == 0 {
		return 0, nil
	}
	return output.Buffer.Write(payload[:1])
}

func (output *partialWriter) Close() error {
	output.closeCalls++
	return nil
}

func TestBoundedInputAndOwnership(t *testing.T) {
	text, err := readBounded(oneByteReader{reader: strings.NewReader("Go 写 Go")})
	if err != nil || text != "Go 写 Go" {
		t.Fatalf("short reads = %q, %v", text, err)
	}
	t.Logf("one-byte reads: %q, err=%v", text, err)
	if text, err = readBounded(strings.NewReader(strings.Repeat("x", maxInputBytes))); err != nil || len(text) != maxInputBytes {
		t.Fatalf("exact byte limit = %d, %v", len(text), err)
	}
	closeError := errors.New("close failure")
	input := &trackedReader{Reader: strings.NewReader(strings.Repeat("x", maxInputBytes+1)), closeErr: closeError}
	text, err = readAndClose(input)
	if text != "" || !errors.Is(err, ErrInvalidInput) || input.closeCalls != 1 {
		t.Fatalf("over limit and close error: text=%q err=%v closeCalls=%d", text, err, input.closeCalls)
	}
	if errors.Is(err, closeError) {
		t.Fatalf("close error replaced read error: %v", err)
	}
	t.Logf("over limit: err=%v closeCalls=%d", err, input.closeCalls)
	var stdout, stderr bytes.Buffer
	if code := runWithInput([]string{"--stdin"}, strings.NewReader(strings.Repeat("x", maxInputBytes+1)), &stdout, &stderr); code != 2 || stdout.Len() != 0 || !strings.Contains(stderr.String(), "input exceeds") {
		t.Fatalf("stdin limit: stdout=%q stderr=%q code=%d", stdout.String(), stderr.String(), code)
	}
}

func TestJSONAndPartialWriter(t *testing.T) {
	text, err := decodeJSONText("{")
	var syntaxError *json.SyntaxError
	if text != "" || !errors.Is(err, ErrInvalidInput) || !errors.As(err, &syntaxError) {
		t.Fatalf("malformed JSON = %q, %v", text, err)
	}
	t.Logf("bad JSON: %v", err)
	for _, testCase := range []struct {
		name   string
		args   []string
		input  string
		output string
		code   int
	}{
		{name: "short JSON stdin", args: []string{"--stdin", "--input-json", "--json"}, input: `{"text":"Go 写 Go"}`, output: "[{\"id\":\"task[0]\",\"status\":\"SUCCEEDED\",\"words\":3,\"bytes\":9,\"runes\":7}]\n"},
		{name: "plain stdin", args: []string{"--stdin"}, input: "Go 写 Go", output: "words=3 bytes=9 runes=7\n"},
		{name: "malformed JSON", args: []string{"--stdin", "--input-json"}, input: `{"text":`, code: 2},
		{name: "trailing JSON", args: []string{"--stdin", "--input-json"}, input: `{"text":"Go"} garbage`, code: 2},
		{name: "wrong JSON type", args: []string{"--stdin", "--input-json"}, input: `{"text":12}`, code: 2},
		{name: "JSON on text not permitted", args: []string{"--text", "Go", "--input-json"}, code: 2},
		{name: "JSON list", args: []string{"--batch", "Go|one two", "--list-ids", "--json"}, output: "[\"task[0]\",\"task[1]\"]\n"},
		{name: "JSON lookup", args: []string{"--batch", "Go|one two", "--lookup", "task[0]", "--json"}, output: "[{\"id\":\"task[0]\",\"status\":\"SUCCEEDED\",\"words\":1,\"bytes\":2,\"runes\":2}]\n"},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			var stdout, stderr bytes.Buffer
			code := runWithInput(testCase.args, oneByteReader{reader: strings.NewReader(testCase.input)}, &stdout, &stderr)
			if code != testCase.code || stdout.String() != testCase.output {
				t.Fatalf("output=%q stderr=%q code=%d", stdout.String(), stderr.String(), code)
			}
			if (code == 0) != (stderr.Len() == 0) {
				t.Fatalf("stderr=%q code=%d", stderr.String(), code)
			}
		})
	}
	path := filepath.Join(t.TempDir(), "task.json")
	if err := os.WriteFile(path, []byte(`{"text":"Go 写 Go"}`), 0600); err != nil {
		t.Fatal(err)
	}
	var fileOutput, fileErrors bytes.Buffer
	if code := runWithInput([]string{"--file", path, "--input-json", "--json"}, strings.NewReader(""), &fileOutput, &fileErrors); code != 0 || fileErrors.Len() != 0 || !strings.Contains(fileOutput.String(), `"words":3`) {
		t.Fatalf("JSON file: stdout=%q stderr=%q code=%d", fileOutput.String(), fileErrors.String(), code)
	}
	var output partialWriter
	if err := writeResponse(&output, []byte("Go")); !errors.Is(err, io.ErrShortWrite) || output.String() != "G" {
		t.Fatalf("partial write = %q, %v", output.String(), err)
	}
	t.Logf("partial writer: accepted=%q returned=%v", output.String(), io.ErrShortWrite)
	var stderr bytes.Buffer
	if code := runWithInput([]string{"--text", "Go", "--json"}, strings.NewReader(""), &output, &stderr); code != 2 || !strings.Contains(stderr.String(), "output write failed") || output.closeCalls != 0 {
		t.Fatalf("writer ownership: stderr=%q code=%d closeCalls=%d", stderr.String(), code, output.closeCalls)
	}
}
