sha256sum /home/admin/workspace/my-blogs/writing-plans/go-language/evidence/12/http-archive.body
