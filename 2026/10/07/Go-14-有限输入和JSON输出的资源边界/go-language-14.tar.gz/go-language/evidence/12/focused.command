go test -count=1 -v -run 'TestPanicsAndCleanup|TestErrorKinds|TestReadAndClose' .
