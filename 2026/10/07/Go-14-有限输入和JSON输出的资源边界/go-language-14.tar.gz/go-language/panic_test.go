package main

import (
	"errors"
	"testing"

	"example.com/go-language-task/stats"
)

type panicReader struct{}

func (panicReader) Read([]byte) (int, error) {
	panic("injected read panic")
}

func TestPanicsAndCleanup(t *testing.T) {
	cleanupCalls := 0
	var caught any
	func() {
		defer func() { caught = recover() }()
		defer func() { cleanupCalls++ }()
		_, _ = analyzeTaskUsing("Go", 3, func(string) stats.Counts {
			panic("injected statistics panic")
		})
	}()
	if caught != "injected statistics panic" || cleanupCalls != 1 {
		t.Fatalf("statistics panic: recovered=%v cleanupCalls=%d", caught, cleanupCalls)
	}
	t.Logf("statistics: recovered=%v cleanupCalls=%d", caught, cleanupCalls)

	reader := &trackedReader{Reader: panicReader{}}
	caught = nil
	func() {
		defer func() { caught = recover() }()
		_, _ = readAndClose(reader)
	}()
	if caught != "injected read panic" || reader.closeCalls != 1 {
		t.Fatalf("read panic: recovered=%v closeCalls=%d", caught, reader.closeCalls)
	}
	t.Logf("read: recovered=%v closeCalls=%d", caught, reader.closeCalls)

	called := false
	_, err := analyzeTaskUsing(" ", 3, func(string) stats.Counts {
		called = true
		return stats.Counts{}
	})
	if !errors.Is(err, ErrInvalidInput) || called {
		t.Fatalf("invalid text: err=%v analyzerCalled=%t", err, called)
	}
}
