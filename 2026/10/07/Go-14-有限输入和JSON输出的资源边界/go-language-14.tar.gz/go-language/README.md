# 累计任务服务：第 14 章

本快照对应 Go 14《有限输入和JSON输出的资源边界》。当前源码以本目录实际文件和 `CURRENT-SHA256SUMS` 为准；`evidence/` 下的旧输出是写作过程历史证据，不冒充本次解包复跑。

## 历史阶段说明

以下文字由早期累计快照继承，描述当时阶段；其中的能力限制和证据路径不作为本篇当前能力总览。本篇复跑步骤以 RUN.md 为准。

本目录是全系列的**唯一累计工程**。14 将 `--file`/`--stdin` 单份输入限制为 65536 字节（多读第 65537 字节判断超限）；仅这两种入口可搭配 `--input-json` 解码 `{"text":"..."}`，`--json` 把当前结果输出为 JSON 数组。`runWithInput` 允许注入 Reader/Writer，验证一字节短读、部分写入、坏 JSON、超限及文件关闭责任。直接 `--text`/`--batch` 命令行参数暂不经过此字节上限。13 之前的顺序计算和错误契约保持原工程；没有后台队列、持久数据库或 HTTP。00–13 的工程各自冻结在对应博文素材包中。

需要 Linux amd64 的 Go 1.27.1，或在自己的平台安装同一 patch 版本；不得用较早语言版本的观察冒充本章证据。仓库内源码 tag/SHA 和二进制来源见 `VERSIONS.md`。

```sh
cd examples/go-language
GOTOOLCHAIN=local go version
GOTOOLCHAIN=local go test -count=1 ./...
GOTOOLCHAIN=local go list ./...
GOTOOLCHAIN=local go list -m all
GOTOOLCHAIN=local go run . --text 'Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go' --drop-first --append again
GOTOOLCHAIN=local go run . --batch 'Go|one two' --lookup 'task[0]'
GOTOOLCHAIN=local go run . --batch 'Go|one two' --list-ids
printf '%s' '{"text":"Go 写 Go"}' | GOTOOLCHAIN=local go run . --stdin --input-json --json
GOTOOLCHAIN=local go run . --file /tmp/taskstats-input.txt --json
printf 'Go 写 Go' > /tmp/taskstats-input.txt
GOTOOLCHAIN=local go run . --file /tmp/taskstats-input.txt
GOTOOLCHAIN=local go run . --text '  '
GOTOOLCHAIN=local go run ./testdata/shadow.go
GOTOOLCHAIN=local go run ./testdata/assign.go
GOTOOLCHAIN=local go run ./testdata/loop-declare.go
GOTOOLCHAIN=local go run ./testdata/loop-assign.go
GOTOOLCHAIN=local go run ./testdata/defer-order.go
GOTOOLCHAIN=local go run ./testdata/defer-loop.go
GOTOOLCHAIN=local go run ./testdata/slice-append.go
GOTOOLCHAIN=local go test -count=1 -v ./testdata/slice-alias-bug_test.go
GOTOOLCHAIN=local go run ./testdata/nil-map-write.go
GOTOOLCHAIN=local go build ./testdata/nonaddressable-receiver.go
GOTOOLCHAIN=local go build ./testdata/interface-value-error.go
GOTOOLCHAIN=local go run ./testdata/typed-nil.go
GOTOOLCHAIN=local go build -o /tmp/recover-outside-defer ./testdata/recover-outside-defer.go
/tmp/recover-outside-defer
GOTOOLCHAIN=local go build ./testdata/invalid-summarizer.go
GOTOOLCHAIN=local go build ./testdata/invalid-type-operation.go
```

纯空白文本及文件打开失败的**应用进程**预期退出 2；`go run` 外层状态不能代替应用退出码，应改用编译所得二进制检查。14 的输入超限、坏 JSON、stdout 部分写入分别返回应用退出 2；已经接受的输出字节不能由本 CLI 撤销，不能称写出具有事务原子性。文件由 `readAndClose` 关闭；调用方拥有的 stdin/stdout 不由本函数关闭。13 两份故意编译失败例子及更早反例仍隔离在 `testdata/`。最新 14 结果见 `writing-plans/go-language/evidence/14/`，00–13 的冻结快照留在对应正文素材包。
