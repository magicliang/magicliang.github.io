package main

import (
	"encoding/json"
	"io"
)

type jsonTask struct {
	ID     string     `json:"id"`
	Status TaskStatus `json:"status"`
	Words  int        `json:"words"`
	Bytes  int        `json:"bytes"`
	Runes  int        `json:"runes"`
}

func jsonRecords(records []TaskRecord) ([]byte, error) {
	items := make([]jsonTask, 0, len(records))
	for _, record := range records {
		items = append(items, jsonTask{
			ID: record.ID, Status: record.Status,
			Words: record.Words, Bytes: record.Bytes, Runes: record.Runes,
		})
	}
	return json.Marshal(items)
}

func writeResponse(output io.Writer, payload []byte) error {
	written, err := output.Write(payload)
	if err != nil {
		return err
	}
	if written != len(payload) {
		return io.ErrShortWrite
	}
	return nil
}
