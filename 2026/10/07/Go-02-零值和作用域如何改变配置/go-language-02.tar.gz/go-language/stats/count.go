package stats

import "strings"

func CountWords(text string) int {
	return len(strings.Fields(text))
}
