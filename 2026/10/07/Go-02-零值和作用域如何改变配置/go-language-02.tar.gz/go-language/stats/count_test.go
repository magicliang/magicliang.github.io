package stats

import "testing"

func TestCountWords(t *testing.T) {
	for _, testCase := range []struct {
		name string
		text string
		want int
	}{
		{name: "ASCII", text: "one two", want: 2},
		{name: "Chinese", text: "Go 写 Go", want: 3},
		{name: "Whitespace", text: "\t \n", want: 0},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			if got := CountWords(testCase.text); got != testCase.want {
				t.Errorf("CountWords(%q) = %d; want %d", testCase.text, got, testCase.want)
			}
		})
	}
}
