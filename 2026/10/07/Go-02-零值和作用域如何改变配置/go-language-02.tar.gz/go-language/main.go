package main

import (
	"flag"
	"fmt"
	"io"
	"os"
	"strings"

	"example.com/go-language-task/stats"
)

func run(args []string, stdout, stderr io.Writer) int {
	flags := flag.NewFlagSet("taskstats", flag.ContinueOnError)
	flags.SetOutput(stderr)
	text := flags.String("text", "", "text to count")
	maxWords := flags.Int("max-words", 3, "maximum number of words")
	if err := flags.Parse(args); err != nil {
		return 2
	}
	config := Config{MaxWords: *maxWords}
	if err := validateConfig(config); err != nil {
		fmt.Fprintln(stderr, err)
		return 2
	}
	if flags.NArg() != 0 || strings.TrimSpace(*text) == "" {
		fmt.Fprintln(stderr, "usage: taskstats --text 'words separated by whitespace' [--max-words N]")
		return 2
	}
	count := stats.CountWords(*text)
	if count > config.MaxWords {
		fmt.Fprintf(stderr, "word count %d exceeds max-words %d\n", count, config.MaxWords)
		return 2
	}
	fmt.Fprintf(stdout, "words=%d\n", count)
	return 0
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}
