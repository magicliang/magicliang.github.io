package main

import "errors"

type Config struct {
	MaxWords int
}

func validateConfig(config Config) error {
	if config.MaxWords <= 0 {
		return errors.New("max-words must be positive")
	}
	return nil
}
