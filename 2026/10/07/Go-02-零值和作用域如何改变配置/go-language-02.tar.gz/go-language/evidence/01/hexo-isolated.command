PATH=/home/admin/.nvm/versions/node/v22.23.2/bin:$PATH hexo generate --force --bail (temporary site: original config/theme/deps, Go 00–01 posts/assets/navigation only)
