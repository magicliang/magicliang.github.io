curl -fsS -o http-sums.body -w %{http_code} http://127.0.0.1:18972/2026/10/07/Go-01-package-module-与依赖如何分工/SHA256SUMS
