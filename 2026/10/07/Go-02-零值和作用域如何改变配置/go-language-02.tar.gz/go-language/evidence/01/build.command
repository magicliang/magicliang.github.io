go build -trimpath -o /tmp/go-language-01-clean-PplCQR/taskstats .
