# 01 原始证据索引

实际工具链、工作区开关见 `environment.txt`，干净构建目录见 `clean-directory.txt`。每项 `.command`、`.stdout`、`.stderr`、`.exit` 保存命令、原始双流和退出码。`toolchain`、`module-graph`、`package-graph`、`test`、`build`、`metadata`、`valid`、`doc-modules` 退出 0；`invalid` 退出 2。

`missing-import.diff` 只修改隔离副本的 import 路径；`missing-import.*` 的测试退出 1，编译器报告不存在的 package，而 `stats` 包本身测试仍通过。输出中的 `go get` 只是工具提示，**未执行**。00 原始证据在上一章素材包和 `evidence/00/`，原始工程不被 01 覆盖。

01 同名素材包包含完整工程、`RUN.md`/`VERSIONS.md` 和 00–01 实验原始证据。素材目录 `unpack-*` 包含本机解包后的真实构建、两包测试和正反 CLI 结果。`hexo-isolated.*` 的独立站点生成退出 0（仓库原配置与主题，只载入 Go 00–01）；`initial-page-check.*` 保留最初未放回系列导航链接的失败，补链并重新生成后 `page-check.*` 退出 0。`http-post.*`、`http-nav.*`、`http-archive.*`、`http-sums.*` 在本地静态服务器均收到 HTTP 200，curl 退出 0，下载的归档 SHA-256 与素材一致。这些请求不是尚未实现的任务服务 HTTP API。00 的全站页面实测通过（`full-page-00.*`），但本次全站构建启动时 01 尚不存在，`full-page-01.*` 因页面不存在退出 1，01 的全站页面检查仍 `NOT_RUN`，详见 `evidence/00/full-site-status.md`。
