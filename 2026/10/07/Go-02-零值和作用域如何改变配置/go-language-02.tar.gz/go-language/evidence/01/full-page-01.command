python3 writing-plans/go-language/scripts/check_page_00.py public 01
