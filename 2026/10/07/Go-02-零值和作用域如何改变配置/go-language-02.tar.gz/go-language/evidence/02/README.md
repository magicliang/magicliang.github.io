# 02 原始证据索引

环境见 `environment.txt`。每项 `.command`、`.stdout`、`.stderr`、`.exit` 分别保存原始命令、双流与退出码。

- `go-version.*`、`tidy-check.*`、`test.*`、`build.*`：工具链与双包测试、编译，退出均为 0；`test.stdout` 同时含配置零值、显式值、错误输入和原有 CLI、统计断言。
- `default.*`、`explicit.*`：正例输出 `words=3`、`words=1`，退出 0；`zero.*`、`negative.*`、`overflow.*`：错误配置或超限，标准输出空，标准错误记录具体原因，退出 2。
- `shadow.*` 与 `assignment.*`：相同初值 3 和请求值 1，`:=` 错误遮蔽打印 3、`=` 正确赋值打印 1，两者进程均退出 0。前者结果不符合请求值，是语义反例，不是用非零退出码冒充反例。

后续素材包将累计工程与前章已保存的证据一并带上；本章构建和页面验收仍需另核。
