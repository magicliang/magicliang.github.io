package main

type missingTaskError struct {
	id string
}

func (failure *missingTaskError) Error() string {
	return "task not found: " + failure.id
}

func lookupRecord(source TaskLookup, id string) (TaskRecord, error) {
	record, found := source.Lookup(id)
	if !found {
		return TaskRecord{}, &missingTaskError{id: id}
	}
	return record, nil
}
