# 运行与复核

运行环境：JDK 21；Gradle Wrapper 8.14；Kotlin Gradle Plugin、编译器和 stdlib 2.2.21。精确 SHA、文档出处和已执行结果见 `../../writing-plans/kotlin/VERSIONS.md` 与 `../../writing-plans/kotlin/verification/00/`。Gradle Wrapper 固定分发包 SHA-256，即使从镜像下载也必须先通过校验。

```bash
cd examples/kotlin-language
bash verification/00.sh
```

脚本保存环境、clean test、合法/非法 CLI、字节码、依赖解析、测试报告的命令、原始输出、退出码和断言。`invalid` 的退出码预期非零。脚本依赖本仓库相对目录结构；若只拿到打包工程，请进入解包后的 `kotlin-language` 并运行 `./gradlew --no-daemon clean test`，随后分别运行 `./gradlew run --args='submit nightly-index'` 与 `./gradlew run --args=submit`。这是本机 JDK/Gradle 的实际运行，不包括 HTTP、数据库、协程或重启恢复。
