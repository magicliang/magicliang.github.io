package main

import (
	"flag"
	"fmt"
	"io"
	"os"
	"strings"

	"example.com/go-language-task/stats"
)

func run(args []string, stdout, stderr io.Writer) int {
	flags := flag.NewFlagSet("taskstats", flag.ContinueOnError)
	flags.SetOutput(stderr)
	text := flags.String("text", "", "text to count")
	batch := flags.String("batch", "", "texts separated by |")
	inputFile := flags.String("file", "", "path to one text input")
	appendText := flags.String("append", "", "append one batch item")
	dropFirst := flags.Bool("drop-first", false, "omit the first batch item")
	lookup := flags.String("lookup", "", "look up one batch task ID")
	listIDs := flags.Bool("list-ids", false, "list batch task IDs in submission order")
	maxWords := flags.Int("max-words", 3, "maximum number of words")
	if err := flags.Parse(args); err != nil {
		return 2
	}
	config := Config{MaxWords: *maxWords}
	if err := validateConfig(config); err != nil {
		fmt.Fprintln(stderr, err)
		return 2
	}
	textProvided, batchProvided, fileProvided, appendProvided, dropProvided, lookupProvided, listProvided := false, false, false, false, false, false, false
	flags.Visit(func(option *flag.Flag) {
		if option.Name == "text" {
			textProvided = true
		}
		if option.Name == "batch" {
			batchProvided = true
		}
		if option.Name == "file" {
			fileProvided = true
		}
		if option.Name == "append" {
			appendProvided = true
		}
		if option.Name == "drop-first" {
			dropProvided = true
		}
		if option.Name == "lookup" {
			lookupProvided = true
		}
		if option.Name == "list-ids" {
			listProvided = true
		}
	})
	selectedModes := 0
	for _, provided := range []bool{textProvided, batchProvided, fileProvided} {
		if provided {
			selectedModes++
		}
	}
	if flags.NArg() != 0 || selectedModes != 1 || !batchProvided && (appendProvided || dropProvided || lookupProvided || listProvided) || lookupProvided && listProvided {
		fmt.Fprintln(stderr, "usage: taskstats (--text 'text' | --batch 'text|text' [--append text] [--drop-first] [--lookup ID | --list-ids] | --file path) [--max-words N]")
		return 2
	}
	taskText := *text
	if fileProvided {
		var err error
		taskText, err = readInputFile(*inputFile)
		if err != nil {
			fmt.Fprintln(stderr, "read file:", err)
			return 2
		}
	}
	tasks := []string{taskText}
	if batchProvided {
		tasks = prepareBatch(strings.Split(*batch, "|"), *appendText, appendProvided, *dropFirst)
		if len(tasks) == 0 {
			fmt.Fprintln(stderr, "usage: taskstats: batch must contain at least one item")
			return 2
		}
	}
	results := make([]stats.Counts, 0, len(tasks))
	for _, taskText := range tasks {
		if strings.TrimSpace(taskText) == "" {
			fmt.Fprintln(stderr, "usage: taskstats: text must not be empty")
			return 2
		}
		counts := stats.Analyze(taskText)
		if counts.Words > config.MaxWords {
			fmt.Fprintf(stderr, "word count %d exceeds max-words %d\n", counts.Words, config.MaxWords)
			return 2
		}
		results = append(results, counts)
	}
	var output strings.Builder
	if batchProvided && (lookupProvided || *listIDs) {
		positions := indexTasks(len(results))
		if lookupProvided {
			position, found := positions[*lookup]
			if !found {
				fmt.Fprintln(stderr, "task not found:", *lookup)
				return 2
			}
			counts := results[position]
			fmt.Fprintf(&output, "task[%d] words=%d bytes=%d runes=%d\n", position, counts.Words, counts.Bytes, counts.Runes)
		} else {
			for _, id := range orderedTaskIDs(positions) {
				fmt.Fprintln(&output, id)
			}
		}
	} else {
		for index, counts := range results {
			if batchProvided {
				fmt.Fprintf(&output, "task[%d] ", index)
			}
			fmt.Fprintf(&output, "words=%d bytes=%d runes=%d\n", counts.Words, counts.Bytes, counts.Runes)
		}
	}
	fmt.Fprint(stdout, output.String())
	return 0
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}
