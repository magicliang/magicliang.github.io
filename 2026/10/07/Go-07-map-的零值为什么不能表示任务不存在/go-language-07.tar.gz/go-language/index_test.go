package main

import (
	"reflect"
	"testing"
)

func TestIndexTasks(t *testing.T) {
	positions := indexTasks(12)
	first, found := positions["task[0]"]
	if !found || first != 0 {
		t.Fatalf("first task = %d, found = %t", first, found)
	}
	missing, found := positions["task[missing]"]
	if found || missing != 0 {
		t.Fatalf("missing task = %d, found = %t", missing, found)
	}
	ids := orderedTaskIDs(positions)
	if len(ids) != 12 || ids[0] != "task[0]" || ids[2] != "task[2]" || ids[10] != "task[10]" {
		t.Fatalf("unexpected ID order: %v", ids)
	}
	if got := orderedTaskIDs(nil); !reflect.DeepEqual(got, []string{}) {
		t.Fatalf("nil index IDs = %v", got)
	}
}
