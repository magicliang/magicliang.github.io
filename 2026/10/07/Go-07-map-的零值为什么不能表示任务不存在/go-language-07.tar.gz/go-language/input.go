package main

import (
	"io"
	"os"
)

func readInputFile(path string) (string, error) {
	file, err := os.Open(path)
	if err != nil {
		return "", err
	}
	return readAndClose(file)
}

func readAndClose(input io.ReadCloser) (text string, err error) {
	defer func() {
		if closeErr := input.Close(); err == nil && closeErr != nil {
			err = closeErr
		}
	}()
	content, err := io.ReadAll(input)
	return string(content), err
}
