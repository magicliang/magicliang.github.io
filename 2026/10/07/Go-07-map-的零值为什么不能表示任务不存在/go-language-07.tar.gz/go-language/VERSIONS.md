# 00 冻结版本

| 项目 | 本次实测 / 冻结 |
|---|---|
| OS/架构 | Ubuntu 24.04.4 LTS，Linux x86_64 |
| 工具链 | `go version go1.27.1 linux/amd64` |
| 官方二进制 | `https://dl.google.com/go/go1.27.1.linux-amd64.tar.gz`，SHA-256 `63d339f0da5ab53635a56f2490a7984dfe12dfcff22ad749f63edaf590168445` |
| 源码 | tag `go1.27.1`，Git SHA `862c888e612ac346c7c4d99c9392bdfd265f33b0`，由 Gitee 的 Go 镜像 `git ls-remote` 查询；官方 Gitiles 不可达，未完成对官方 Git 远端的交叉验证 |
| module | `example.com/go-language-task`，`go 1.27.1`；未写 `toolchain` 指令（同版指令被 `go mod tidy` 移除）；仅标准库，无 `go.sum` |
| 运行方式 | `GOTOOLCHAIN=local` 禁止静默切换下载的工具链 |

环境变量、资源限制和模块图的原始命令输出见 `writing-plans/go-language/evidence/00/`；压缩副本见本章文章素材。非 Go 依赖在首次引入时另行冻结。

01 延用 Go 1.27.1、`go.mod` 与标准库依赖，未添加第三方模块。`GOWORK=off` 的干净目录验证记录在 `writing-plans/go-language/evidence/01/`；`go list ./...` 显示 `example.com/go-language-task` 和 `example.com/go-language-task/stats` 两个 package，`go list -m all` 仍只显示一个 module。01 的独立压缩快照见同名正文素材目录；00 的冻结快照不随这里的代码变动。

02 沿用相同 Go 1.27.1、`go.mod` 和标准库依赖，没有新增外部版本。`Config{}` 的 `MaxWords` 语言零值为 0，而 CLI 用 `flag.Int` 显式设默认 3：二者不是一回事。`--max-words` 非正数错误在统计前返回，超出正上限要在统计后才判断；实测输出与退出码在 `writing-plans/go-language/evidence/02/`。

03 继续沿用同一工具链和标准库；新计数使用本版 `src/unicode/utf8/utf8.go:447` 的 `RuneCountInString`（同一源码 tag/SHA）。字段数来自 `strings.Fields`，字节数来自 `len(text)`，码点数来自 `utf8.RuneCountInString(text)`；没有引入图素簇分段库。03 的中文、空串、结合符输入与隔离副本错误计数结果见 `writing-plans/go-language/evidence/03/`。

04 沿用 Go 1.27.1、`go.mod` 的 `go 1.27.1` 和标准库，没有额外依赖。在该语言版本下 `for _, value := range ...` 每轮有独立声明变量，而预先声明再用 `for _, value = range ...` 是给同一变量赋值；两种短程序的实际输出在 `writing-plans/go-language/evidence/04/`，并对照本版 `doc/go_spec.html` 的 range clause。不使用旧版本工具链推测跨版本行为。

05 沿用 Go 1.27.1 与标准库，没有额外依赖。`defer` 和 `return` 规则对照本版 `doc/go_spec.html` 的 Defer statements/Return statements；文件输入使用本版 `os.Open`、`io.ReadAll`、`io.ReadCloser.Close`，退出码与原始输出见 `writing-plans/go-language/evidence/05/`。`/proc/self/fd` 计数只在 Linux amd64 的这次进程中观察；不能当作其他系统的文件描述符数量。

06 继续使用同一 Go 1.27.1 工具链和标准库；无新增外部版本。slice 与数组语义按本版 `doc/go_spec.html` 中 Array types、Slice types、Appending and copying slices、Representation of values 核对；`testdata/slice-append.go`、`slice-alias-bug_test.go` 和根包正反测试原始结果见 `writing-plans/go-language/evidence/06/`。

07 继续使用 Go 1.27.1 和标准库，没有新模块。map 类型、索引表达式、range 遍历顺序按本版 `doc/go_spec.html` 的 Map types、Index expressions、For statements with range clause 核对，排序 API 用本版 `go doc sort.Slice` 核对；实际命令、原始双流与退出码见 `writing-plans/go-language/evidence/07/`。
