package main

import (
	"fmt"
	"sort"
)

func indexTasks(count int) map[string]int {
	positions := make(map[string]int, count)
	for position := 0; position < count; position++ {
		positions[fmt.Sprintf("task[%d]", position)] = position
	}
	return positions
}

func orderedTaskIDs(positions map[string]int) []string {
	ids := make([]string, 0, len(positions))
	for id := range positions {
		ids = append(ids, id)
	}
	sort.Slice(ids, func(left, right int) bool {
		return positions[ids[left]] < positions[ids[right]]
	})
	return ids
}
