package example.tasks

fun submitTask(args: Array<String>): String {
    require(args.size == 2 && args[0] == "submit" && args[1].isNotBlank()) {
        "Usage: submit <task text>"
    }
    return args[1]
}

fun main(args: Array<String>) {
    println("TASK input accepted (not persisted): ${submitTask(args)}")
}
