# Kotlin 累计任务系统

从 00 开始逐篇扩展的 Kotlin/JVM 合成任务实验。当前 `submit` 只验证一条命令行输入并打印“输入已接收”提示；**没有排队、执行、持久化或后台任务**，不能把提示当成提交成功的持久证据。

01 增加 `TaskSettings` 的标签与重试上限实验。`val labels` 仍公开一个可变列表，专用于验证别名和对象可变性；这不是线程安全接口，06 再区分只读视图与真正的快照。该设置还没有接入 00 的 CLI，不要从测试通过推断 CLI 已支持重试。

要求 JDK 21 与可访问 Maven Central/Gradle 分发包的网络；版本和校验值见 `../../writing-plans/kotlin/VERSIONS.md`。在本目录运行：

```bash
./gradlew --no-daemon clean test
./gradlew --no-daemon run --args='submit nightly-index'
./gradlew --no-daemon run --args='submit'
```

最后一条应以非零退出并打印 `Usage: submit <task text>`。完整的版本、命令、退出码、原始输出和断言由 `verification/00.sh` 写入 `../../writing-plans/kotlin/verification/00/`。Wrapper 包固定官方 SHA-256，但 `distributionUrl` 使用可从当前环境访问的第三方镜像；验收脚本另行核对下载内容校验和。

01 运行 `bash verification/01.sh`，检验 00 回归、`val`/`var` 别名、数字溢出与隔离的编译拒绝样本；对应记录见 `../../writing-plans/kotlin/verification/01/`。01 快照及下载校验文件放在 01 正文的同名素材目录。
