go doc os.File.Close 
