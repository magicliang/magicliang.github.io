go list -m all 
