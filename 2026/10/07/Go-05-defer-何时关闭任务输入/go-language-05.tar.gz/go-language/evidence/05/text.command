/tmp/go-language-05-bTjFeJ/taskstats --text Go\ 写\ Go 
