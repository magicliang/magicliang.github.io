package main

import (
	"bytes"
	"strings"
	"testing"
)

func TestRun(t *testing.T) {
	for _, testCase := range []struct {
		name          string
		args          []string
		code          int
		output        string
		errorContains string
	}{
		{name: "valid", args: []string{"--text", "Go 写 Go"}, code: 0, output: "words=3 bytes=9 runes=7\n"},
		{name: "explicit limit", args: []string{"--text", "Go", "--max-words", "1"}, code: 0, output: "words=1 bytes=2 runes=2\n"},
		{name: "empty", args: []string{"--text", "  "}, code: 2, errorContains: "usage:"},
		{name: "unknown flag", args: []string{"--invalid"}, code: 2, errorContains: "flag provided"},
		{name: "extra argument", args: []string{"--text", "Go", "extra"}, code: 2, errorContains: "usage:"},
		{name: "zero limit", args: []string{"--text", "Go 写 Go", "--max-words", "0"}, code: 2, errorContains: "max-words must be positive"},
		{name: "invalid config before empty", args: []string{"--text", " ", "--max-words", "0"}, code: 2, errorContains: "max-words must be positive"},
		{name: "negative limit", args: []string{"--text", "Go", "--max-words", "-1"}, code: 2, errorContains: "max-words must be positive"},
		{name: "over limit", args: []string{"--text", "one two three four"}, code: 2, errorContains: "exceeds max-words"},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			var stdout, stderr bytes.Buffer
			if got := run(testCase.args, &stdout, &stderr); got != testCase.code {
				t.Errorf("exit code = %d; want %d", got, testCase.code)
			}
			if got := stdout.String(); got != testCase.output {
				t.Errorf("stdout = %q; want %q", got, testCase.output)
			}
			if !strings.Contains(stderr.String(), testCase.errorContains) || (testCase.code == 0 && stderr.Len() != 0) {
				t.Errorf("unexpected stderr: %q", stderr.String())
			}
		})
	}
}
