# 累计任务服务：第 03 章

本快照对应 Go 03《byte-rune-和字段数怎样区分》。当前源码以本目录实际文件和 `CURRENT-SHA256SUMS` 为准；`evidence/` 下的旧输出是写作过程历史证据，不冒充本次解包复跑。

## 历史阶段说明

以下文字由早期累计快照继承，描述当时阶段；其中的能力限制和证据路径不作为本篇当前能力总览。本篇复跑步骤以 RUN.md 为准。

本目录是全系列的**唯一累计工程**。03 在已有 CLI、`--max-words` 配置和统计包上增加字节数与 Unicode 码点数输出；上限仍约束按空白分隔的字段数。没有 goroutine、队列、数据库或 HTTP。码点数不是用户可见字符数，00–02 的工程各自冻结在对应博文素材包中。

需要 Linux amd64 的 Go 1.27.1，或在自己的平台安装同一 patch 版本；不得用较早语言版本的观察冒充本章证据。仓库内源码 tag/SHA 和二进制来源见 `VERSIONS.md`。

```sh
cd examples/go-language
GOTOOLCHAIN=local go version
GOTOOLCHAIN=local go test -count=1 ./...
GOTOOLCHAIN=local go list ./...
GOTOOLCHAIN=local go list -m all
GOTOOLCHAIN=local go run . --text 'Go 写 Go'
GOTOOLCHAIN=local go run . --text '  '
GOTOOLCHAIN=local go run ./testdata/shadow.go
GOTOOLCHAIN=local go run ./testdata/assign.go
```

纯空白文本的**应用进程**预期退出 2；`go run` 外层状态不能代替应用退出码，应改用编译所得二进制检查。不要把预期输出当作在新环境里已测得。最新 03 结果见 `writing-plans/go-language/evidence/03/`，00–02 的原始快照留在对应正文素材包。
