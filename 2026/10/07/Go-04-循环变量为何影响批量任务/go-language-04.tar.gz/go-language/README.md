# 累计任务服务：第 04 章

本快照对应 Go 04《循环变量为何影响批量任务》。当前源码以本目录实际文件和 `CURRENT-SHA256SUMS` 为准；`evidence/` 下的旧输出是写作过程历史证据，不冒充本次解包复跑。

## 历史阶段说明

以下文字由早期累计快照继承，描述当时阶段；其中的能力限制和证据路径不作为本篇当前能力总览。本篇复跑步骤以 RUN.md 为准。

本目录是全系列的**唯一累计工程**。04 在 03 的 CLI 上新增顺序 `--batch 'text|text'`；各项仍按字段数、字节数、码点数统计，任一项非法则本次调用不写出成功结果。没有 goroutine、队列、数据库或 HTTP；目前的 `|` 只是教学输入分隔符，不支持转义，也没有限制批次数量或承诺持久化原子性。00–03 的工程各自冻结在对应博文素材包中。

需要 Linux amd64 的 Go 1.27.1，或在自己的平台安装同一 patch 版本；不得用较早语言版本的观察冒充本章证据。仓库内源码 tag/SHA 和二进制来源见 `VERSIONS.md`。

```sh
cd examples/go-language
GOTOOLCHAIN=local go version
GOTOOLCHAIN=local go test -count=1 ./...
GOTOOLCHAIN=local go list ./...
GOTOOLCHAIN=local go list -m all
GOTOOLCHAIN=local go run . --text 'Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go'
GOTOOLCHAIN=local go run . --text '  '
GOTOOLCHAIN=local go run ./testdata/shadow.go
GOTOOLCHAIN=local go run ./testdata/assign.go
GOTOOLCHAIN=local go run ./testdata/loop-declare.go
GOTOOLCHAIN=local go run ./testdata/loop-assign.go
```

纯空白文本的**应用进程**预期退出 2；`go run` 外层状态不能代替应用退出码，应改用编译所得二进制检查。不要把预期输出当作在新环境里已测得。最新 04 结果见 `writing-plans/go-language/evidence/04/`，00–03 的原始快照留在对应正文素材包。
