# 04 原始证据索引

`environment.txt` 冻结工具链及 `go.mod` 的语言版本。`.command`、`.stdout`、`.stderr`、`.exit` 保存每项实际命令与退出码。

- `test.*`、`build.*`、`single.*`、`batch.*`：两包测试与编译退出 0，单次 CLI 旧输出保留，批量逐项输出序号与统计数值。
- `batch-empty.*`、`batch-overflow.*`、`both-modes.*`：任一项目非法或两种模式同时使用均退出 2，stdout 为空，即使前一项已经在内存中计算；不表示有数据库事务或任务执行回滚。
- `loop-declare.*`、`loop-assign.*`：同一 Go 1.27.1 下，无 goroutine，`:=` 每轮声明给出 `A B C`，向预声明变量赋值给出 `C C C`；两次程序退出都为 0。后者是“意图捕获每轮值”时的语义反例，不是假装命令发生编译错误。
