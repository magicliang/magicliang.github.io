package main

import (
	"flag"
	"fmt"
	"io"
	"os"
	"strings"

	"example.com/go-language-task/stats"
)

func run(args []string, stdout, stderr io.Writer) int {
	flags := flag.NewFlagSet("taskstats", flag.ContinueOnError)
	flags.SetOutput(stderr)
	text := flags.String("text", "", "text to count")
	batch := flags.String("batch", "", "texts separated by |")
	maxWords := flags.Int("max-words", 3, "maximum number of words")
	if err := flags.Parse(args); err != nil {
		return 2
	}
	config := Config{MaxWords: *maxWords}
	if err := validateConfig(config); err != nil {
		fmt.Fprintln(stderr, err)
		return 2
	}
	textProvided, batchProvided := false, false
	flags.Visit(func(option *flag.Flag) {
		if option.Name == "text" {
			textProvided = true
		}
		if option.Name == "batch" {
			batchProvided = true
		}
	})
	if flags.NArg() != 0 || textProvided == batchProvided {
		fmt.Fprintln(stderr, "usage: taskstats (--text 'text' | --batch 'text|text') [--max-words N]")
		return 2
	}
	tasks := []string{*text}
	if batchProvided {
		tasks = strings.Split(*batch, "|")
	}
	var output strings.Builder
	for index, taskText := range tasks {
		if strings.TrimSpace(taskText) == "" {
			fmt.Fprintln(stderr, "usage: taskstats: text must not be empty")
			return 2
		}
		counts := stats.Analyze(taskText)
		if counts.Words > config.MaxWords {
			fmt.Fprintf(stderr, "word count %d exceeds max-words %d\n", counts.Words, config.MaxWords)
			return 2
		}
		if batchProvided {
			fmt.Fprintf(&output, "task[%d] ", index)
		}
		fmt.Fprintf(&output, "words=%d bytes=%d runes=%d\n", counts.Words, counts.Bytes, counts.Runes)
	}
	fmt.Fprint(stdout, output.String())
	return 0
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}
