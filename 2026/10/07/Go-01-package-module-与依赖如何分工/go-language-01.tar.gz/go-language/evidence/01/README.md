# 01 原始证据索引

实际工具链、工作区开关见 `environment.txt`，干净构建目录见 `clean-directory.txt`。每项 `.command`、`.stdout`、`.stderr`、`.exit` 保存命令、原始双流和退出码。`toolchain`、`module-graph`、`package-graph`、`test`、`build`、`metadata`、`valid`、`doc-modules` 退出 0；`invalid` 退出 2。

`missing-import.diff` 只修改隔离副本的 import 路径；`missing-import.*` 的测试退出 1，编译器报告不存在的 package，而 `stats` 包本身测试仍通过。输出中的 `go get` 只是工具提示，**未执行**。00 原始证据在上一章素材包和 `evidence/00/`，原始工程不被 01 覆盖。
