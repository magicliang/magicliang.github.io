package main

import (
	"reflect"
	"testing"

	"example.com/go-language-task/stats"
)

type lookupStub struct {
	record TaskRecord
	found  bool
}

func (stub lookupStub) Lookup(string) (TaskRecord, bool) {
	return stub.record, stub.found
}

var _ TaskLookup = lookupStub{}
var _ TaskLookup = (*BatchTasks)(nil)

func TestTaskLookup(t *testing.T) {
	record := newTaskRecord("task[0]")
	record.MarkSucceeded(stats.Counts{Words: 1, Bytes: 2, Runes: 2})
	tasks := newBatchTasks([]TaskRecord{record})
	if got, found := describeTask(tasks, "task[0]"); !found || got != "task[0] words=1 bytes=2 runes=2" {
		t.Fatalf("real lookup = %q, found = %t", got, found)
	}
	if _, found := tasks.Lookup("task[missing]"); found {
		t.Fatal("missing ID was found")
	}
	if got := tasks.IDs(); !reflect.DeepEqual(got, []string{"task[0]"}) {
		t.Fatalf("IDs = %v", got)
	}
	if got, found := describeTask(lookupStub{record: record, found: true}, "task[0]"); !found || got != "task[0] words=1 bytes=2 runes=2" {
		t.Fatalf("stub lookup = %q, found = %t", got, found)
	}
	if got, found := describeTask(lookupStub{}, "task[missing]"); found || got != "" {
		t.Fatalf("stub missing lookup = %q, found = %t", got, found)
	}
}
