package main

import "fmt"

type TaskLookup interface {
	Lookup(id string) (TaskRecord, bool)
}

type BatchTasks struct {
	records   []TaskRecord
	positions map[string]int
}

func newBatchTasks(records []TaskRecord) *BatchTasks {
	return &BatchTasks{records: records, positions: indexTasks(records)}
}

func (tasks *BatchTasks) Lookup(id string) (TaskRecord, bool) {
	position, found := tasks.positions[id]
	if !found {
		return TaskRecord{}, false
	}
	return tasks.records[position], true
}

func (tasks *BatchTasks) IDs() []string {
	return orderedTaskIDs(tasks.positions)
}

func describeTask(source TaskLookup, id string) (string, bool) {
	record, found := source.Lookup(id)
	if !found {
		return "", false
	}
	return fmt.Sprintf("%s %s", record.ID, record.Summary()), true
}
