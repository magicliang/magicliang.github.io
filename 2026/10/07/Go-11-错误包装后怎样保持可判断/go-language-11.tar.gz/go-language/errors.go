package main

import (
	"errors"
	"fmt"
	"strings"

	"example.com/go-language-task/stats"
)

var (
	ErrInvalidInput    = errors.New("invalid input")
	ErrTaskNotFound    = errors.New("task not found")
	ErrExecutionFailed = errors.New("task execution failed")
)

func analyzeTask(text string, maxWords int) (stats.Counts, error) {
	if strings.TrimSpace(text) == "" {
		return stats.Counts{}, fmt.Errorf("text must not be empty: %w", ErrInvalidInput)
	}
	counts := stats.Analyze(text)
	if counts.Words > maxWords {
		return counts, fmt.Errorf("word count %d exceeds max-words %d: %w", counts.Words, maxWords, ErrInvalidInput)
	}
	return counts, nil
}

func readTaskFile(path string) (string, error) {
	text, err := readInputFile(path)
	if err != nil {
		return "", fmt.Errorf("read input %q: %w: %w", path, ErrExecutionFailed, err)
	}
	return text, nil
}
