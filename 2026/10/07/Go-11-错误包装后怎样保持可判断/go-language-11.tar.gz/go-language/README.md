# 累计任务服务：第 11 章

本快照对应 Go 11《错误包装后怎样保持可判断》。当前源码以本目录实际文件和 `CURRENT-SHA256SUMS` 为准；`evidence/` 下的旧输出是写作过程历史证据，不冒充本次解包复跑。

## 历史阶段说明

以下文字由早期累计快照继承，描述当时阶段；其中的能力限制和证据路径不作为本篇当前能力总览。本篇复跑步骤以 RUN.md 为准。

本目录是全系列的**唯一累计工程**。11 为当前 CLI 的调用层定义可用 `errors.Is` 识别的非法输入、未找到和执行失败三类错误；缺失任务使用 `Unwrap`，文件读取失败同时包装分类与底层 `PathError`，对外只打印稳定的执行失败描述，不泄露文件路径细节。10 的 typed nil 对照与之前顺序查询入口不变；没有 goroutine、队列、持久数据库或 HTTP。00–10 的工程各自冻结在对应博文素材包中。

需要 Linux amd64 的 Go 1.27.1，或在自己的平台安装同一 patch 版本；不得用较早语言版本的观察冒充本章证据。仓库内源码 tag/SHA 和二进制来源见 `VERSIONS.md`。

```sh
cd examples/go-language
GOTOOLCHAIN=local go version
GOTOOLCHAIN=local go test -count=1 ./...
GOTOOLCHAIN=local go list ./...
GOTOOLCHAIN=local go list -m all
GOTOOLCHAIN=local go run . --text 'Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go' --drop-first --append again
GOTOOLCHAIN=local go run . --batch 'Go|one two' --lookup 'task[0]'
GOTOOLCHAIN=local go run . --batch 'Go|one two' --list-ids
printf 'Go 写 Go' > /tmp/taskstats-input.txt
GOTOOLCHAIN=local go run . --file /tmp/taskstats-input.txt
GOTOOLCHAIN=local go run . --text '  '
GOTOOLCHAIN=local go run ./testdata/shadow.go
GOTOOLCHAIN=local go run ./testdata/assign.go
GOTOOLCHAIN=local go run ./testdata/loop-declare.go
GOTOOLCHAIN=local go run ./testdata/loop-assign.go
GOTOOLCHAIN=local go run ./testdata/defer-order.go
GOTOOLCHAIN=local go run ./testdata/defer-loop.go
GOTOOLCHAIN=local go run ./testdata/slice-append.go
GOTOOLCHAIN=local go test -count=1 -v ./testdata/slice-alias-bug_test.go
GOTOOLCHAIN=local go run ./testdata/nil-map-write.go
GOTOOLCHAIN=local go build ./testdata/nonaddressable-receiver.go
GOTOOLCHAIN=local go build ./testdata/interface-value-error.go
GOTOOLCHAIN=local go run ./testdata/typed-nil.go
```

纯空白文本及文件打开失败的**应用进程**预期退出 2；`go run` 外层状态不能代替应用退出码，应改用编译所得二进制检查。11 的文件错误现在对 CLI 仅显示 `read file: task execution failed`，不要把内部 `PathError` 或 `fmt.Errorf` 拼出的文字当客户端协议。`typed-nil.go` 的 bad 路径是逻辑反例；09/08 的故意编译失败、07 的 nil map panic、06 的失败测试仍各自隔离。`defer-loop.go` 读取 Linux `/proc/self/fd`，非 Linux 平台不能沿用本机计数。最新 11 结果见 `writing-plans/go-language/evidence/11/`，00–10 的原始快照留在对应正文素材包。
