# 累计任务服务：第 08 章

本快照对应 Go 08《任务记录的复制与指针更新》。当前源码以本目录实际文件和 `CURRENT-SHA256SUMS` 为准；`evidence/` 下的旧输出是写作过程历史证据，不冒充本次解包复跑。

## 历史阶段说明

以下文字由早期累计快照继承，描述当时阶段；其中的能力限制和证据路径不作为本篇当前能力总览。本篇复跑步骤以 RUN.md 为准。

本目录是全系列的**唯一累计工程**。08 把当前批次的 ID、计数与 `QUEUED`/`SUCCEEDED` 记录进 `TaskRecord`；`TaskResult` 值接收者的 `Summary` 通过嵌入提升，`MarkSucceeded` 用指针接收者更新同一记录。07 的临时 map 索引改为引用记录 ID，06 的复制后编辑与 05 的文件输入保持不变。没有 goroutine、队列、持久数据库或 HTTP；`|` 仍只是教学输入分隔符，不支持转义。00–07 的工程各自冻结在对应博文素材包中。

需要 Linux amd64 的 Go 1.27.1，或在自己的平台安装同一 patch 版本；不得用较早语言版本的观察冒充本章证据。仓库内源码 tag/SHA 和二进制来源见 `VERSIONS.md`。

```sh
cd examples/go-language
GOTOOLCHAIN=local go version
GOTOOLCHAIN=local go test -count=1 ./...
GOTOOLCHAIN=local go list ./...
GOTOOLCHAIN=local go list -m all
GOTOOLCHAIN=local go run . --text 'Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go'
GOTOOLCHAIN=local go run . --batch 'one two|Go 写 Go' --drop-first --append again
GOTOOLCHAIN=local go run . --batch 'Go|one two' --lookup 'task[0]'
GOTOOLCHAIN=local go run . --batch 'Go|one two' --list-ids
printf 'Go 写 Go' > /tmp/taskstats-input.txt
GOTOOLCHAIN=local go run . --file /tmp/taskstats-input.txt
GOTOOLCHAIN=local go run . --text '  '
GOTOOLCHAIN=local go run ./testdata/shadow.go
GOTOOLCHAIN=local go run ./testdata/assign.go
GOTOOLCHAIN=local go run ./testdata/loop-declare.go
GOTOOLCHAIN=local go run ./testdata/loop-assign.go
GOTOOLCHAIN=local go run ./testdata/defer-order.go
GOTOOLCHAIN=local go run ./testdata/defer-loop.go
GOTOOLCHAIN=local go run ./testdata/slice-append.go
GOTOOLCHAIN=local go test -count=1 -v ./testdata/slice-alias-bug_test.go
GOTOOLCHAIN=local go run ./testdata/nil-map-write.go
GOTOOLCHAIN=local go build ./testdata/nonaddressable-receiver.go
```

纯空白文本及文件打开失败的**应用进程**预期退出 2；`go run` 外层状态不能代替应用退出码，应改用编译所得二进制检查。`nonaddressable-receiver.go` 是独立的故意编译失败的反例；07 的 `nil-map-write.go` 会 panic；06 的 `slice-alias-bug_test.go` 也故意失败。这些独立例子均不属于 `go test ./...` 的正常测试。`defer-loop.go` 读取 Linux `/proc/self/fd`，非 Linux 平台不能沿用本机计数。不要把预期输出当作在新环境里已测得。最新 08 结果见 `writing-plans/go-language/evidence/08/`，00–07 的原始快照留在对应正文素材包。
