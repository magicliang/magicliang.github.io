# 00 冻结版本

| 项目 | 本次实测 / 冻结 |
|---|---|
| OS/架构 | Ubuntu 24.04.4 LTS，Linux x86_64 |
| 工具链 | `go version go1.27.1 linux/amd64` |
| 官方二进制 | `https://dl.google.com/go/go1.27.1.linux-amd64.tar.gz`，SHA-256 `63d339f0da5ab53635a56f2490a7984dfe12dfcff22ad749f63edaf590168445` |
| 源码 | tag `go1.27.1`，Git SHA `862c888e612ac346c7c4d99c9392bdfd265f33b0`，由 Gitee 的 Go 镜像 `git ls-remote` 查询；官方 Gitiles 不可达，未完成对官方 Git 远端的交叉验证 |
| module | `example.com/go-language-task`，`go 1.27.1`；未写 `toolchain` 指令（同版指令被 `go mod tidy` 移除）；仅标准库，无 `go.sum` |
| 运行方式 | `GOTOOLCHAIN=local` 禁止静默切换下载的工具链 |

环境变量、资源限制和模块图的原始命令输出见 `writing-plans/go-language/evidence/00/`；压缩副本见本章文章素材。非 Go 依赖在首次引入时另行冻结。
