# 累计任务服务：第 00 章

本快照对应 Go 00《从一个任务看懂Go工程》。当前源码以本目录实际文件和 `CURRENT-SHA256SUMS` 为准；`evidence/` 下的旧输出是写作过程历史证据，不冒充本次解包复跑。

## 历史阶段说明

以下文字由早期累计快照继承，描述当时阶段；其中的能力限制和证据路径不作为本篇当前能力总览。本篇复跑步骤以 RUN.md 为准。

本目录是全系列的**唯一累计工程**。00 只实现顺序文本统计 CLI：按 Unicode 空白切分输入，返回字段数；没有 goroutine、队列、数据库或 HTTP。`strings.Fields` 的字段数不是字节数、码点数或用户可见字符数。

需要 Linux amd64 的 Go 1.27.1，或在自己的平台安装同一 patch 版本；不得用较早语言版本的观察冒充本章证据。仓库内源码 tag/SHA 和二进制来源见 `VERSIONS.md`。

```sh
cd examples/go-language
GOTOOLCHAIN=local go version
GOTOOLCHAIN=local go test -count=1 ./...
GOTOOLCHAIN=local go run . --text 'Go 写 Go'
GOTOOLCHAIN=local go run . --text '  '
```

最后一条**预期**退出 2；不要把预期输出当作在新环境里已测得。原始运行结果保存在 `writing-plans/go-language/evidence/00/`，正文素材包中也包含对应副本。
