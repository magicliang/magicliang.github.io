# 00 原始证据索引

每项命令的 `.command`、`.stdout`、`.stderr`、`.exit` 分别保存命令、原始标准输出、原始标准错误和退出码；`GOTOOLCHAIN=local GOMAXPROCS=2 CGO_ENABLED=0` 见 `environment.txt`。临时 CLI 二进制位于 `/tmp/go-language-00-taskstats`，不提交。

- `toolchain-sha.*`：官方压缩包 SHA-256 验证，退出 0；`source-sha.*`：Go 镜像 tag Git SHA，退出 0。
- `go-version.*`、`go-env.*`、`platform.*`、`resource-limits.*`：环境；`initial-resource-limits.txt` 保留首次尝试 cgroup v2 文件不存在的原始错误，随后按真实 cgroup v1 修正。
- `initial-test.*`：初次 `go.mod` 冗余指令导致退出 1；修正后的 `tidy-check.*`、`module-list.*`、`test.*`、`build.*`、`binary-metadata.*` 均退出 0。
- `cli-ascii.*`、`cli-chinese.*` 退出 0；`cli-invalid.*`、`cli-unknown.*` 退出 2，错误输出在 stderr。
- `mutation.diff` 和 `mutation.*`：只改**临时副本**的计数实现，`go test` 退出 1 且断言失败；累计工程随后保持通过状态。

原始 Go/CLI 命令只证明当前输入与环境；没运行的 HTTP、SQL、并发、race 和云端发布都不在这里宣称通过。
