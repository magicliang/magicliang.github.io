package main

import (
	"flag"
	"fmt"
	"io"
	"os"
	"strings"
)

func run(args []string, stdout, stderr io.Writer) int {
	flags := flag.NewFlagSet("taskstats", flag.ContinueOnError)
	flags.SetOutput(stderr)
	text := flags.String("text", "", "text to count")
	if err := flags.Parse(args); err != nil {
		return 2
	}
	if flags.NArg() != 0 || strings.TrimSpace(*text) == "" {
		fmt.Fprintln(stderr, "usage: taskstats --text 'words separated by whitespace'")
		return 2
	}
	fmt.Fprintf(stdout, "words=%d\n", countWords(*text))
	return 0
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}
