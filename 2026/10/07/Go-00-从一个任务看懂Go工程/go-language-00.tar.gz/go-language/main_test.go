package main

import (
	"bytes"
	"strings"
	"testing"
)

func TestCountWords(t *testing.T) {
	for _, testCase := range []struct {
		name string
		text string
		want int
	}{
		{name: "ASCII", text: "one two", want: 2},
		{name: "Chinese", text: "Go 写 Go", want: 3},
		{name: "Whitespace", text: "\t \n", want: 0},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			if got := countWords(testCase.text); got != testCase.want {
				t.Errorf("countWords(%q) = %d; want %d", testCase.text, got, testCase.want)
			}
		})
	}
}

func TestRun(t *testing.T) {
	for _, testCase := range []struct {
		name   string
		args   []string
		code   int
		output string
	}{
		{name: "valid", args: []string{"--text", "Go 写 Go"}, code: 0, output: "words=3\n"},
		{name: "empty", args: []string{"--text", "  "}, code: 2},
		{name: "unknown flag", args: []string{"--invalid"}, code: 2},
		{name: "extra argument", args: []string{"--text", "Go", "extra"}, code: 2},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			var stdout, stderr bytes.Buffer
			if got := run(testCase.args, &stdout, &stderr); got != testCase.code {
				t.Errorf("exit code = %d; want %d", got, testCase.code)
			}
			if got := stdout.String(); got != testCase.output {
				t.Errorf("stdout = %q; want %q", got, testCase.output)
			}
			if testCase.code != 0 && !strings.Contains(stderr.String(), "usage:") && !strings.Contains(stderr.String(), "flag provided") {
				t.Errorf("stderr has no error: %q", stderr.String())
			}
		})
	}
}
