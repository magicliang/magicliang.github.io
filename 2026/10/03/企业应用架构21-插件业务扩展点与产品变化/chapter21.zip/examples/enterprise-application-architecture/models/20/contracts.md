# 20 契约与质量情景

- same-id-independent: PASS，两账号各读100/200。
- missing-or-forged-context: PASS，空/伪造上下文拒绝。
- cross-read/cross-write: SQLSTATE=90096，拒绝跨schema。
- reused-connection-schema: SQLSTATE=90096，切schema不提权。
- cache-scoped/unscoped-cache-counterexample/config-scoped: PASS，隔离键正确且坏键污染可见。
- job-message-context/tenant-idempotency-and-no-side-effect: PASS，伪造任务拒绝，重复job-1不重复增加。
- restart-durable: PASS，新进程读101/201。

所有输入为合成教学数据。真实H2 2.1.214 schema权限及应用账号；无真实身份服务、第三方连接池、broker、生产负载。消费函数证明本地Inbox事务，不证明消息运行时。

质量情景：施加上表的具体刺激，通过实际命令重跑，观察该行的精确金额、权限码、退出码或行数；没有性能SLO测量。
