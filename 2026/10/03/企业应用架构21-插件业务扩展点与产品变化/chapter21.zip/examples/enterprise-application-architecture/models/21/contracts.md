# 21 业务契约与质量情景

- default-weekly-plugin:800/700/500
- missing/duplicate/incompatible/tenant-config/class-injection/negative/float/boolean/overflow/invalid-days/exception均拒绝
- direct-branch-equivalence cases=21

输入为合成数据。场景刺激、响应、度量对应上述原始断言；没有性能SLO测量。受信任本地文件Python插件；没有Java ServiceLoader、热卸载、不可信代码沙箱、持久化或生产配置。


Repair regression: reserved-load-daily/weekly and reserved-call-daily/weekly reject; builtins-preserved-after-conflicts=PASS values=800,700. Captured in normal.stdout.txt.
