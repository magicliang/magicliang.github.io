#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
java_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}java
javac_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}javac
jar=$(python3 "$root/sql-support/v1/resolve-h2.py")
build=$(mktemp -d)
trap 'rm -rf "$build"' EXIT
"$java_cmd" -version
"$javac_cmd" --release 21 -d "$build" "$root/labs/20/Lab20.java"
"$java_cmd" -ea -cp "$build:$jar" Lab20 "$build/tenants"
"$java_cmd" -ea -cp "$build:$jar" Lab20 "$build/tenants" restart
