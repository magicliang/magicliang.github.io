#!/usr/bin/env bash
set -euo pipefail
"${PYTHON:-python3}" "$(dirname "$0")/lab.py"
