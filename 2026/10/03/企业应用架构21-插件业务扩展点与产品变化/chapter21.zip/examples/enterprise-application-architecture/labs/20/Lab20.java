import java.sql.*;
import java.util.*;

public final class Lab20 {
    static String url;
    static final Map<String, String> identities = Map.of("alice", "A", "bob", "B");
    static final Map<String, Integer> cache = new HashMap<>();
    static void check(String id, boolean ok) {
        System.out.println(id + "=" + (ok ? "PASS" : "FAIL"));
        if (!ok) throw new AssertionError(id);
    }
    static Connection connection(String actor, String claimed) throws SQLException {
        if (claimed == null || !claimed.equals(identities.get(actor))) throw new SecurityException("tenant context");
        Connection c = DriverManager.getConnection(url, "APP_" + claimed, "lesson");
        c.setSchema(claimed);
        return c;
    }
    static int read(Connection c) throws SQLException {
        System.out.println("SQL user=" + c.getMetaData().getUserName() + " schema=" + c.getSchema() + " SELECT amount FROM contracts WHERE id=1");
        try (var s = c.createStatement(); var r = s.executeQuery("SELECT amount FROM contracts WHERE id=1")) {
            r.next(); return r.getInt(1);
        }
    }
    static void deniedSql(Connection c, String sql, String id) throws SQLException {
        System.out.println("SQL user=" + c.getMetaData().getUserName() + " " + sql);
        try (var s = c.createStatement()) {
            s.execute(sql); throw new AssertionError("unexpected permission: " + id);
        } catch (SQLException e) {
            System.out.println(id + " SQLSTATE=" + e.getSQLState());
            check(id, "90096".equals(e.getSQLState()));
        }
    }
    static void consume(String actor, String tenant, String key) throws SQLException {
        try (var c = connection(actor, tenant)) {
            c.setAutoCommit(false);
            try (var p = c.prepareStatement("INSERT INTO inbox VALUES (?)")) {
                System.out.println("SQL user=" + c.getMetaData().getUserName() + " INSERT INTO inbox VALUES (?) params=" + key);
                p.setString(1, key); p.executeUpdate();
                c.createStatement().executeUpdate("UPDATE contracts SET amount=amount+1 WHERE id=1");
                System.out.println("SQL UPDATE contracts SET amount=amount+1 WHERE id=1; COMMIT");
                c.commit();
            } catch (SQLException e) {
                c.rollback(); if (!"23505".equals(e.getSQLState())) throw e;
            }
        }
    }
    public static void main(String[] args) throws Exception {
        url = "jdbc:h2:" + args[0];
        if (args.length > 1) {
            try (var a = connection("alice", "A"); var b = connection("bob", "B")) {
                check("restart-durable", read(a) == 101 && read(b) == 201);
            }
            return;
        }
        try (var c = DriverManager.getConnection(url, "sa", "" ); var s = c.createStatement()) {
            System.out.println("database=" + c.getMetaData().getDatabaseProductVersion());
            for (String t : List.of("A", "B")) {
                s.execute("CREATE USER APP_" + t + " PASSWORD 'lesson'");
                s.execute("CREATE SCHEMA " + t + " AUTHORIZATION SA");
                s.execute("CREATE TABLE " + t + ".contracts(id INT PRIMARY KEY, amount INT CHECK(amount>=0))");
                s.execute("CREATE TABLE " + t + ".inbox(id VARCHAR PRIMARY KEY)");
                s.execute("GRANT SELECT, INSERT, UPDATE ON SCHEMA " + t + " TO APP_" + t);
                s.execute("INSERT INTO " + t + ".contracts VALUES(1," + (t.equals("A") ? 100 : 200) + ")");
            }
        }
        for (String claimed : Arrays.asList(null, "B")) {
            try (var ignored = connection("alice", claimed)) { throw new AssertionError("spoof accepted"); }
            catch (SecurityException expected) { check("missing-or-forged-context", true); }
        }
        try (var a = connection("alice", "A"); var b = connection("bob", "B")) {
            check("application-identity", a.getMetaData().getUserName().equals("APP_A"));
            check("same-id-independent", read(a) == 100 && read(b) == 200);
            deniedSql(a, "SELECT * FROM B.contracts", "cross-read");
            deniedSql(a, "UPDATE B.contracts SET amount=0", "cross-write");
            a.setSchema("B");
            deniedSql(a, "SELECT * FROM contracts", "reused-connection-schema");
            a.setSchema("A");
            cache.put("A:1", read(a)); cache.put("B:1", read(b));
            check("cache-scoped", cache.get("A:1") == 100 && cache.get("B:1") == 200);
            Map<String, Integer> unsafe = new HashMap<>();
            unsafe.put("1", read(a)); unsafe.put("1", read(b));
            check("unscoped-cache-counterexample", unsafe.get("1") != read(a));
            Map<String, String> config = Map.of("A:currency", "CNY", "B:currency", "USD");
            check("config-scoped", config.get("A:currency").equals("CNY") && config.get("B:currency").equals("USD"));
        }
        consume("alice", "A", "job-1"); consume("bob", "B", "job-1"); consume("alice", "A", "job-1");
        try { consume("alice", "B", "bad"); throw new AssertionError("forged job"); }
        catch (SecurityException expected) { check("job-message-context", true); }
        try (var a = connection("alice", "A"); var b = connection("bob", "B")) {
            check("tenant-idempotency-and-no-side-effect", read(a) == 101 && read(b) == 201);
        }
        System.out.println("PASS chapter20");
    }
}
