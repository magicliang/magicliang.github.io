API = 2
NAME = "cap"
CAPABILITIES = {"CNY", "quote"}
