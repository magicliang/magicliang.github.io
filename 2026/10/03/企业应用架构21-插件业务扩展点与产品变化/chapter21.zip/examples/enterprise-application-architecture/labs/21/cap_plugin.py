API = 1
NAME = "cap"
CAPABILITIES = {"CNY", "quote"}


def quote(days, cents):
    return min(days * cents, 500)
