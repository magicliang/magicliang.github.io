"""Trusted, explicitly registered Python plugin: no tenant-supplied import path."""
import importlib.util
import pathlib
import tempfile


def daily(days, cents):
    return days * cents


def weekly(days, cents):
    weeks, rest = divmod(days, 7)
    return (weeks * 6 + rest) * cents


BUILTINS = {"daily": daily, "weekly": weekly}


def load(paths):
    result = {}
    for path in paths:
        spec = importlib.util.spec_from_file_location("approved_plugin", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if module.API != 1 or module.CAPABILITIES != {"CNY", "quote"}:
            raise ValueError("incompatible contract")
        if module.NAME in BUILTINS or module.NAME in result:
            raise ValueError("duplicate registration")
        result[module.NAME] = module.quote
    return result


def quote(actor, tenant, strategy, days, cents, plugins):
    if {"alice": "A", "bob": "B"}.get(actor) != tenant:
        raise ValueError("tenant authorization")
    allowed = {"A": {"daily", "weekly"}, "B": {"daily", "cap"}}
    if strategy not in allowed[tenant] or days < 1 or cents < 0:
        raise ValueError("configuration")
    if BUILTINS.keys() & plugins.keys():
        raise ValueError("reserved strategy name")
    fn = {**BUILTINS, **plugins}.get(strategy)
    if fn is None:
        raise ValueError("plugin missing")
    amount = fn(days, cents)
    if type(amount) is not int or not 0 <= amount <= 10**9:
        raise ValueError("illegal money")
    return amount


def reject(name, fn):
    try:
        fn()
    except (ValueError, RuntimeError):
        print(name + "=PASS rejected")
    else:
        raise AssertionError(name)


def main():
    plugin = pathlib.Path(__file__).with_name("cap_plugin.py")
    plugins = load([plugin])
    assert quote("alice", "A", "daily", 8, 100, plugins) == 800
    assert quote("alice", "A", "weekly", 8, 100, plugins) == 700
    assert quote("bob", "B", "cap", 8, 100, plugins) == 500
    print("default-weekly-plugin=PASS values=800,700,500")
    reject("missing", lambda: quote("bob", "B", "cap", 8, 100, {}))
    reject("duplicate", lambda: load([plugin, plugin]))
    with tempfile.TemporaryDirectory() as directory:
        reserved = pathlib.Path(directory) / "reserved.py"
        for name in BUILTINS:
            reserved.write_text('API=1\nNAME=' + repr(name) + '\nCAPABILITIES={"CNY","quote"}\ndef quote(days,cents):return 7\n')
            reject("reserved-load-" + name, lambda: load([reserved]))
            reject("reserved-call-" + name, lambda: quote("alice", "A", name, 8, 100, {name: lambda *_: 7}))
    assert quote("alice", "A", "daily", 8, 100, plugins) == 800
    assert quote("alice", "A", "weekly", 8, 100, plugins) == 700
    print("builtins-preserved-after-conflicts=PASS values=800,700")
    reject("incompatible", lambda: load([plugin.with_name("bad_plugin.py")]))
    reject("tenant-config", lambda: quote("alice", "B", "cap", 8, 100, plugins))
    reject("class-injection", lambda: quote("bob", "B", "os.system", 8, 100, plugins))
    reject("negative", lambda: quote("bob", "B", "cap", 8, 100, {"cap": lambda *_: -1}))
    reject("float", lambda: quote("bob", "B", "cap", 8, 100, {"cap": lambda *_: 1.5}))
    reject("boolean", lambda: quote("bob", "B", "cap", 8, 100, {"cap": lambda *_: True}))
    reject("overflow", lambda: quote("bob", "B", "cap", 8, 100, {"cap": lambda *_: 10**9 + 1}))
    reject("invalid-days", lambda: quote("alice", "A", "daily", 0, 100, plugins))
    def broken(*_):
        raise RuntimeError("plugin failure")
    reject("exception", lambda: quote("bob", "B", "cap", 8, 100, {"cap": broken}))
    for days in range(1, 22):
        direct = (days // 7 * 6 + days % 7) * 100
        assert weekly(days, 100) == direct
    print("direct-branch-equivalence=PASS cases=21")
    print("PASS chapter21")


if __name__ == "__main__":
    main()
