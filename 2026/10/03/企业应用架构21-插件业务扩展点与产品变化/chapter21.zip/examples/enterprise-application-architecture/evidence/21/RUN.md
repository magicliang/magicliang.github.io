# 21 RUN

2026-10-03 独立场景 VERIFIED_LOCAL；累计门槛待root集成，不表示所有章验收已完成。

命令：`bash examples/enterprise-application-architecture/labs/21/run.sh`。实际调用与退出码见normal.command.json、normal.exit.txt；环境见environment.txt，源码散列source-sha256.json，输入inputs.json。

| 场景/二值可观察量 | 产物 |
|---|---|
| default-weekly-plugin:800/700/500 | normal.stdout.txt |
| missing/duplicate/incompatible/tenant-config/class-injection/negative/float/boolean/overflow/invalid-days/exception均拒绝 | normal.stdout.txt |
| direct-branch-equivalence cases=21 | normal.stdout.txt |


正常退出0。stderr空仅代表无异常，不作成功证据。受信任本地文件Python插件；没有Java ServiceLoader、热卸载、不可信代码沙箱、持久化或生产配置。



Repair regression: reserved-load-daily/weekly and reserved-call-daily/weekly reject; builtins-preserved-after-conflicts=PASS values=800,700. Captured in normal.stdout.txt.
