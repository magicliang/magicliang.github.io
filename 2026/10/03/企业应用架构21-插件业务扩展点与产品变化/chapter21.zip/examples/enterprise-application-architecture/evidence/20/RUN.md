# Chapter 20 RUN

2026-10-03，独立场景 VERIFIED_LOCAL；累计依赖门槛由root集成验证后更新共享状态。本文件不表示整章全部验收通过。

## 命令

从仓库根目录运行：

```bash
bash examples/enterprise-application-architecture/labs/20/run.sh
```

本次复核编排：`.omo/evidence/enterprise-20-23/verify.py`；它保存每个命令的原始stdout/stderr、exit与command.json。Python环境使用PYTHON覆盖，Java使用JAVA_HOME，20使用H2_JAR且验证固定散列。确切执行环境见environment.txt。

## 场景矩阵

| 场景 | 命令 | 二值判定/实际值 | 本目录原始产物 |
|---|---|---|---|
| same-id-independent | bash examples/enterprise-application-architecture/labs/20/run.sh | PASS，两账号各读100/200 | normal.stdout.txt |
| missing-or-forged-context | bash examples/enterprise-application-architecture/labs/20/run.sh | PASS，空/伪造上下文拒绝 | normal.stdout.txt |
| cross-read/cross-write | bash examples/enterprise-application-architecture/labs/20/run.sh | SQLSTATE=90096，拒绝跨schema | normal.stdout.txt |
| reused-connection-schema | bash examples/enterprise-application-architecture/labs/20/run.sh | SQLSTATE=90096，切schema不提权 | normal.stdout.txt |
| cache-scoped/unscoped-cache-counterexample/config-scoped | bash examples/enterprise-application-architecture/labs/20/run.sh | PASS，隔离键正确且坏键污染可见 | normal.stdout.txt |
| job-message-context/tenant-idempotency-and-no-side-effect | bash examples/enterprise-application-architecture/labs/20/run.sh | PASS，伪造任务拒绝，重复job-1不重复增加 | normal.stdout.txt |
| restart-durable | bash examples/enterprise-application-architecture/labs/20/run.sh | PASS，新进程读101/201 | normal.stdout.txt |

正常退出0，23的幂等突变预期退出1。SQL类场景以原始SQL和最终断言对应；21纯计算没有数据库。stderr为空表示没有错误输出，不作为独立完成证据。

## 范围

真实H2 2.1.214 schema权限及应用账号；无真实身份服务、第三方连接池、broker、生产负载。消费函数证明本地Inbox事务，不证明消息运行时。

输入固定在对应实验源码，输入摘要见inputs.json；源码摘要见source-sha256.json。
