#!/usr/bin/env bash
set -euo pipefail
here=$(cd "$(dirname "$0")" && pwd)
exec "${PYTHON_BINARY:-python3}" "$here/run.py" "$@"
