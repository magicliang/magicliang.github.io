import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.camunda.bpm.dmn.engine.DmnDecisionTableResult;

public final class DecisionCheck {
    private static final DmnEngine ENGINE = DmnEngineConfiguration.createDefaultDmnEngineConfiguration().buildEngine();
    private static int checks;
    private DecisionCheck() { }
    private static DmnDecisionTableResult evaluate(String xml, Map<String, Object> inputs) {
        return ENGINE.evaluateDecisionTable("eligibility", new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)), inputs);
    }
    private static void check(boolean ok, String label) {
        if (!ok) throw new AssertionError(label);
        checks++;
        System.out.println("PASS " + label);
    }
    public static void main(String[] args) throws Exception {
        String original = Files.readString(Path.of(args[0]));
        String changed = original.replace("&lt; 1", "&lt; 2").replace("&gt;= 1", "&gt;= 2");
        String overlap = original.replace("&lt; 1", "&lt;= 1");
        if (args.length > 1) {
            evaluate(overlap, Map.of("released", true, "leadHours", 1));
            throw new AssertionError("UNIQUE overlap unexpectedly accepted");
        }
        check("BLOCKED".equals(evaluate(original, Map.of("released", false, "leadHours", 2)).getSingleEntry()), "blocked-regardless-of-lead");
        check("TOO_SOON".equals(evaluate(original, Map.of("released", true, "leadHours", 0)).getSingleEntry()), "original-zero-refused");
        check("ELIGIBLE".equals(evaluate(original, Map.of("released", true, "leadHours", 1)).getSingleEntry()), "original-one-eligible");
        check("TOO_SOON".equals(evaluate(changed, Map.of("released", true, "leadHours", 1)).getSingleEntry()), "changed-one-refused");
        check("ELIGIBLE".equals(evaluate(changed, Map.of("released", true, "leadHours", 2)).getSingleEntry()), "changed-two-eligible");
        boolean rejected = false;
        try { evaluate(overlap, Map.of("released", true, "leadHours", 1)); }
        catch (org.camunda.bpm.dmn.engine.DmnEngineException e) {
            rejected = true;
            System.out.println("EXPECTED " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
        check(rejected, "UNIQUE-overlap-runtime-rejection");
        check(evaluate(original, Map.of("released", true)).isEmpty(), "missing-lead-no-matching-rule");
        for (boolean released : new boolean[] {false, true}) {
            for (int lead = 0; lead <= 3; lead++) {
                check(evaluate(changed, Map.of("released", released, "leadHours", lead)).size() == 1,
                        "finite-totality-released=" + released + "-lead=" + lead);
            }
        }
        System.out.println("RESULT checks=" + checks + " PASS engine=7.23.0 model=DMN-1.3");
    }
}
