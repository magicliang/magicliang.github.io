import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import urllib.request

here = Path(__file__).resolve().parent
cache = Path(os.environ.get('MODELING_E08_CACHE', Path.home() / '.cache/software-modeling/E08'))
cache.mkdir(parents=True, exist_ok=True)
jars = []
for dependency in json.loads((here / 'dependencies.json').read_text()):
    jar = cache / dependency['url'].rsplit('/', 1)[1]
    if not jar.exists():
        with urllib.request.urlopen(dependency['url'], timeout=60) as response:
            data = response.read()
        if hashlib.sha256(data).hexdigest() != dependency['sha256']:
            raise ValueError('download checksum mismatch: ' + jar.name)
        jar.write_bytes(data)
    if hashlib.sha256(jar.read_bytes()).hexdigest() != dependency['sha256']:
        raise ValueError('cache checksum mismatch: ' + jar.name)
    jars.append(str(jar))
java_home = os.environ.get('JAVA_HOME')
java = str(Path(java_home) / 'bin/java') if java_home else 'java'
javac = str(Path(java_home) / 'bin/javac') if java_home else 'javac'
classpath = os.pathsep.join(jars)
subprocess.run([java, '-version'], check=True)
with tempfile.TemporaryDirectory(prefix='modeling-E08-') as work:
    subprocess.run([javac, '--release', '21', '-Xlint:all', '-Werror', '-cp', classpath,
                    '-d', work, str(here / 'DecisionCheck.java')], check=True)
    result = subprocess.run([java, '-cp', work + os.pathsep + classpath, 'DecisionCheck',
                             str(here.parents[1] / 'models/E08/eligibility.dmn'), *sys.argv[1:]])
    sys.exit(result.returncode)
