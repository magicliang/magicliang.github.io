import java.nio.file.*;
import java.util.*;
import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.*;
import org.eclipse.emf.ecore.resource.*;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.*;
import org.eclipse.emf.ecore.xmi.impl.*;

public class EmfRoundTrip {
    static Object get(EObject object, String name) { return object.eGet(object.eClass().getEStructuralFeature(name)); }
    static void set(EObject object, String name, Object value) { object.eSet(object.eClass().getEStructuralFeature(name), value); }
    @SuppressWarnings("unchecked")
    static List<EObject> list(EObject object, String name) { return (List<EObject>) get(object, name); }
    static void check(String name, Object actual, Object expected) {
        boolean pass = Objects.equals(actual, expected);
        System.out.printf("{\"scenario\":\"%s\",\"actual\":\"%s\",\"expected\":\"%s\",\"pass\":%s}%n", name, actual, expected, pass);
        if (!pass) throw new AssertionError(name);
    }
    static ResourceSet resources() {
        ResourceSet result = new ResourceSetImpl();
        result.getResourceFactoryRegistry().getExtensionToFactoryMap().put("ecore", new EcoreResourceFactoryImpl());
        result.getResourceFactoryRegistry().getExtensionToFactoryMap().put("xmi", new XMIResourceFactoryImpl());
        return result;
    }
    static URI uri(Path path) { return URI.createFileURI(path.toAbsolutePath().toString()); }
    static EPackage loadPackage(ResourceSet rs, Path path) {
        EPackage p = (EPackage) rs.getResource(uri(path), true).getContents().get(0);
        rs.getPackageRegistry().put(p.getNsURI(), p);
        return p;
    }
    static String business(EObject fleet) {
        List<EObject> reservations = list(fleet, "reservations");
        for (EObject r : reservations)
            if ((Integer)get(r,"start") >= (Integer)get(r,"end")) return "INVALID_PERIOD";
        for (int i=0;i<reservations.size();i++) for(int j=i+1;j<reservations.size();j++) {
            EObject a=reservations.get(i), b=reservations.get(j);
            if (get(a,"equipment")==get(b,"equipment") && (Integer)get(a,"start")<(Integer)get(b,"end") && (Integer)get(b,"start")<(Integer)get(a,"end")) return "OVERLAP";
        }
        return "OK";
    }
    static List<String> facts(EObject fleet) {
        List<String> result=new ArrayList<>();
        for(EObject e:list(fleet,"equipment")) result.add("E:"+get(e,"id")+":"+get(e,"state"));
        for(EObject r:list(fleet,"reservations")) result.add("R:"+get(r,"id")+":"+get((EObject)get(r,"equipment"),"id")+":"+get(r,"start")+":"+get(r,"end"));
        Collections.sort(result);return result;
    }
    static void diagnostic(Path output, String name, EObject object) throws Exception {
        Diagnostic d=Diagnostician.INSTANCE.validate(object);
        Files.writeString(output.resolve(name+"-diagnostic.txt"),d.toString()+"\n");
    }
    public static void main(String[] args) throws Exception {
        Path models=Path.of(args[0]), output=Path.of(args[1]);Files.createDirectories(output);
        ResourceSet rs=resources();EPackage pkg=loadPackage(rs,models.resolve("rental.ecore"));
        check("real-emf-metamodel-valid",Diagnostician.INSTANCE.validate(pkg).getSeverity(),Diagnostic.OK);
        EObject fleet=rs.getResource(uri(models.resolve("rental.xmi")),true).getContents().get(0);
        check("loaded-instance-valid",Diagnostician.INSTANCE.validate(fleet).getSeverity(),Diagnostic.OK);
        check("loaded-reference-resolves-to-contained-equipment",get(list(fleet,"reservations").get(0),"equipment")==list(fleet,"equipment").get(0),true);
        check("loaded-business-constraints",business(fleet),"OK");
        EObject missing=EcoreUtil.copy(fleet);set(list(missing,"equipment").get(0),"id",null);
        diagnostic(output,"missing-id",missing);
        check("required-id-diagnosed",Diagnostician.INSTANCE.validate(missing).getSeverity(),Diagnostic.ERROR);
        EObject missingRef=EcoreUtil.copy(fleet);set(list(missingRef,"reservations").get(0),"equipment",null);
        diagnostic(output,"missing-reference",missingRef);
        check("required-reference-diagnosed",Diagnostician.INSTANCE.validate(missingRef).getSeverity(),Diagnostic.ERROR);
        EObject overlap=EcoreUtil.copy(fleet);EObject r2=EcoreUtil.copy(list(overlap,"reservations").get(0));
        set(r2,"id","R2");set(r2,"start",2);set(r2,"end",4);list(overlap,"reservations").add(r2);
        check("overlap-structurally-valid",Diagnostician.INSTANCE.validate(overlap).getSeverity(),Diagnostic.OK);
        check("custom-java-constraint-rejects-overlap",business(overlap),"OVERLAP");
        set(r2,"start",3);set(r2,"end",4);check("adjacent-half-open-periods-allowed",business(overlap),"OK");
        set(r2,"end",3);check("empty-period-rejected",business(overlap),"INVALID_PERIOD");
        Resource meta=rs.createResource(uri(output.resolve("roundtrip.ecore")));meta.getContents().add(EcoreUtil.copy(pkg));meta.save(Map.of());
        Resource serialized=rs.createResource(uri(output.resolve("roundtrip.xmi")));serialized.getContents().add(EcoreUtil.copy(fleet));serialized.save(Map.of());
        ResourceSet fresh=resources();EPackage reloadedPkg=loadPackage(fresh,output.resolve("roundtrip.ecore"));
        EObject restored=fresh.getResource(uri(output.resolve("roundtrip.xmi")),true).getContents().get(0);
        check("fresh-package-instance",reloadedPkg!=pkg,true);
        check("fresh-object-instance",restored!=fleet,true);
        check("roundtrip-metamodel-valid",Diagnostician.INSTANCE.validate(reloadedPkg).getSeverity(),Diagnostic.OK);
        check("roundtrip-instance-valid",Diagnostician.INSTANCE.validate(restored).getSeverity(),Diagnostic.OK);
        check("roundtrip-business-valid",business(restored),"OK");
        check("roundtrip-semantic-facts-equal",facts(restored),facts(fleet));
        check("roundtrip-reference-identity-preserved",get(list(restored,"reservations").get(0),"equipment")==list(restored,"equipment").get(0),true);
        Files.writeString(output.resolve("semantic-facts.txt"),facts(restored)+"\n");
    }
}
