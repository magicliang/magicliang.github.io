import json,os,subprocess,tempfile,zipfile
from pathlib import Path
from fetch_tools import fetch
BASE=Path(__file__).resolve().parents[2]

def main():
    evidence=BASE/'evidence/E04';evidence.mkdir(parents=True,exist_ok=True)
    jars=fetch();cp=os.pathsep.join(map(str,jars))
    binary=lambda name:str(Path(os.environ['JAVA_HOME'])/'bin'/name) if 'JAVA_HOME' in os.environ else name
    version=subprocess.run([binary('java'),'-version'],capture_output=True,text=True)
    (evidence/'java-version.txt').write_text(version.stdout+version.stderr)
    manifests={p.name:zipfile.ZipFile(p).read('META-INF/MANIFEST.MF').decode() for p in jars}
    (evidence/'jar-manifests.json').write_text(json.dumps(manifests,indent=2)+'\n')
    with tempfile.TemporaryDirectory(prefix='modeling-e04-') as temp:
        compile_cmd=[binary('javac'),'-cp',cp,'-d',temp,str(Path(__file__).resolve().with_name('EmfRoundTrip.java'))]
        compiled=subprocess.run(compile_cmd,capture_output=True,text=True)
        (evidence/'compile-output.txt').write_text(compiled.stdout+compiled.stderr or 'javac completed without diagnostics\n')
        (evidence/'compile-exit.txt').write_text(str(compiled.returncode)+'\n')
        if compiled.returncode:raise RuntimeError(compiled.stderr)
        command=[binary('java'),'-cp',temp+os.pathsep+cp,'EmfRoundTrip',str(BASE/'models/E04'),str(evidence)]
        run=subprocess.run(command,capture_output=True,text=True)
        (evidence/'emf-output.txt').write_text(run.stdout+run.stderr);(evidence/'emf-exit.txt').write_text(str(run.returncode)+'\n')
        (evidence/'invocations.json').write_text(json.dumps({'compile':compile_cmd,'run':command,'compile_exit':compiled.returncode,'run_exit':run.returncode},indent=2)+'\n')
        print(run.stdout,end='')
        if run.returncode:raise RuntimeError(run.stderr)
        records=[json.loads(x) for x in run.stdout.splitlines()];assert len(records)==17 and all(x['pass'] for x in records)

if __name__=='__main__':main()
