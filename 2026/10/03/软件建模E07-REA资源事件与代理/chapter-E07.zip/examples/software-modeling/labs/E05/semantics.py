from pathlib import Path
import sys
from importlib.metadata import version
from rdflib import Graph, Namespace, RDF, Literal
from owlrl import DeductiveClosure, OWLRL_Semantics
from pyshacl import validate

EX = Namespace("https://example.invalid/rental/")
SH = Namespace("http://www.w3.org/ns/shacl#")
MODELS = Path(__file__).resolve().parents[2] / "models/E05"

def check(ok, name):
    if not ok:
        raise AssertionError(name)
    print("PASS", name)

def report(graph):
    conforms, results, text = validate(graph, shacl_graph=str(MODELS / "shapes.ttl"), inference="none")
    details = sorted((str(results.value(r, SH.focusNode)), str(results.value(r, SH.resultPath)),
                      str(results.value(r, SH.sourceConstraintComponent)))
                     for r in results.subjects(RDF.type, SH.ValidationResult))
    print("SHACL", conforms, details)
    return conforms, details, text

def main():
    print("VERSIONS", {x: version(x) for x in ("rdflib", "owlrl", "pyshacl")})
    raw = Graph().parse(MODELS / "rental.ttl")
    count = len(raw)
    check((EX.camera1, RDF.type, EX.Equipment) not in raw, "equipment-type-not-explicit")
    inferred = Graph()
    for triple in raw:
        inferred.add(triple)
    DeductiveClosure(OWLRL_Semantics).expand(inferred)
    check((EX.camera1, RDF.type, EX.Equipment) in inferred, "subclass-inference")
    check((EX.alice, RDF.type, EX.Party) in inferred, "domain-infers-party")
    check((EX.camera1, EX.ownedBy, EX.alice) in inferred, "owl-inverse-relation")
    check(not list(inferred.objects(EX.camera2, EX.serial)), "missing-value-not-invented")
    check(len(raw) == count, "source-graph-not-mutated")
    conforms, details, text = report(inferred)
    check(not conforms and len(details) == 1 and details[0][0] == str(EX.camera2), "missing-serial-violates-minCount")
    if sys.argv[1:] == ["missing"]:
        print(text)
        return 1
    if sys.argv[1:]:
        raise ValueError("expected no arguments or missing")
    inferred.add((EX.camera2, EX.serial, Literal("CAM-02")))
    check(report(inferred)[0], "explicit-repair-conforms")
    before = len(inferred)
    inferred.add((EX.camera2, EX.serial, Literal("CAM-02")))
    check(len(inferred) == before and report(inferred)[0], "same-triple-is-not-a-second-value")
    inferred.remove((EX.camera2, EX.serial, None))
    inferred.add((EX.camera2, EX.serial, Literal(42)))
    check(not report(inferred)[0], "integer-serial-violates-datatype")
    inferred.remove((EX.camera2, EX.serial, None))
    inferred.add((EX.camera2, EX.serial, Literal("CAM-02")))
    inferred.add((EX.camera2, EX.serial, Literal("CAM-02-OTHER")))
    check(not report(inferred)[0], "second-serial-violates-maxCount")
    wrong = Graph().parse(MODELS / "rental.ttl")
    wrong.add((EX.alice, EX.owns, EX.someService))
    DeductiveClosure(OWLRL_Semantics).expand(wrong)
    check((EX.someService, RDF.type, EX.Equipment) in wrong, "range-classifies-untyped-object")
    print("RESULT checks=12 PASS; missing is unknown, SHACL completeness is explicit policy")
    return 0

if __name__ == "__main__":
    sys.exit(main())
