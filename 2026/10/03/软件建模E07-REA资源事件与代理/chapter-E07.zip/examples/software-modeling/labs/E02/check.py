"""SQLite dimensional example: daily recognition grain versus reservation invoice grain."""
import json,sqlite3
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]

def check(name,actual,expected):
    passed=actual==expected;print(json.dumps({'scenario':name,'actual':actual,'expected':expected,'pass':passed}))
    if not passed:raise AssertionError(name)

def dimension_key(db,identity,day):
    rows=db.execute('SELECT sk FROM dim_equipment WHERE equipment_id=? AND valid_from<=? AND ?<valid_to',(identity,day,day)).fetchall()
    if len(rows)!=1:raise ValueError('DIMENSION_NOT_EXACTLY_ONE')
    return rows[0][0]

def outcome(action):
    try:action()
    except (ValueError,sqlite3.IntegrityError) as error:return type(error).__name__
    return 'ACCEPT'

def main():
    db=sqlite3.connect(':memory:');db.executescript((BASE/'models/E02/warehouse.sql').read_text())
    query=lambda sql:db.execute(sql).fetchall()
    check('atomic-daily-grain-total',query('SELECT count(*),sum(amount_cents) FROM rental_day'),[(3,40000)])
    check('reservation-invoice-grain-total',query('SELECT count(*),sum(invoice_cents) FROM settlement'),[(2,40000)])
    check('raw-fact-join-multiplies-invoice',query('SELECT sum(invoice_cents) FROM rental_day JOIN settlement USING(reservation_id)'),[(60000,)])
    check('sum-distinct-is-not-repair',query('SELECT sum(DISTINCT invoice_cents) FROM rental_day JOIN settlement USING(reservation_id)'),[(20000,)])
    check('aggregate-to-reservation-before-join',query('SELECT sum(d.amount),sum(s.invoice_cents) FROM (SELECT reservation_id,sum(amount_cents) amount FROM rental_day GROUP BY reservation_id) d JOIN settlement s USING(reservation_id)'),[(40000,40000)])
    historical=query('SELECT d.branch,sum(f.amount_cents) FROM rental_day f JOIN dim_equipment d ON d.sk=f.equipment_sk GROUP BY d.branch ORDER BY d.branch')
    check('historical-branch-at-service-day',historical,[('North',10000),('South',30000)])
    check('join-current-version-rewrites-history',query("SELECT current.branch,sum(f.amount_cents) FROM rental_day f JOIN dim_equipment old ON old.sk=f.equipment_sk JOIN dim_equipment current ON current.equipment_id=old.equipment_id AND current.valid_to='9999-12-31' GROUP BY current.branch"),[('South',40000)])
    check('unqualified-natural-key-join-duplicates-facts',query('SELECT sum(f.amount_cents) FROM rental_day f JOIN dim_equipment old ON old.sk=f.equipment_sk JOIN dim_equipment history ON history.equipment_id=old.equipment_id'),[(80000,)])
    check('asof-before-boundary',dimension_key(db,'E1','2026-10-02'),1)
    check('asof-at-boundary',dimension_key(db,'E1','2026-10-03'),2)
    check('late-arriving-old-fact-uses-historical-version',dimension_key(db,'E1','2026-10-02'),1)
    check('unknown-date-dimension-rejected',outcome(lambda:dimension_key(db,'E1','2026-09-30')),'ValueError')
    check('duplicate-daily-grain-rejected',outcome(lambda:db.execute("INSERT INTO rental_day VALUES('R1','2026-10-02',1,10000)")),'IntegrityError')
    check('unknown-surrogate-reference-rejected',outcome(lambda:db.execute("INSERT INTO rental_day VALUES('R9','2026-10-02',99,10000)")),'IntegrityError')
    db.execute("INSERT INTO dim_equipment VALUES(3,'E1','Overlap','2026-10-02','2026-10-04')")
    check('overlapping-dimension-versions-rejected-by-lookup',outcome(lambda:dimension_key(db,'E1','2026-10-03')),'ValueError')
    ev=BASE/'evidence/E02';ev.mkdir(parents=True,exist_ok=True)
    (ev/'historical-report.json').write_text(json.dumps(historical,indent=2)+'\n')
    (ev/'sqlite-version.txt').write_text(sqlite3.sqlite_version+'\n')
    (ev/'tested-state.sql').write_text('\n'.join(db.iterdump())+'\n')

if __name__=='__main__':main()
