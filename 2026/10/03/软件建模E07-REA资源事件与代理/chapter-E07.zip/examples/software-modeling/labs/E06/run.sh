#!/usr/bin/env bash
set -euo pipefail
here=$(cd "$(dirname "$0")" && pwd)
"${PYTHON_BINARY:-python3}" "$here/features.py" "$@"
