import hashlib,json,os,tempfile,urllib.request
from pathlib import Path

def fetch():
    base=Path(__file__).resolve().parents[2]
    chapter=Path(__file__).resolve().parent.name
    cache=Path(os.environ.get('MODELING_TOOL_CACHE',str(Path(tempfile.gettempdir())/'software-modeling-tools')))
    cache.mkdir(parents=True,exist_ok=True)
    paths=[]
    for item in json.loads((base/'models'/chapter/'tools-lock.json').read_text()):
        path=cache/item['file']
        if not path.exists():
            data=urllib.request.urlopen(item['url'],timeout=60).read()
            if hashlib.sha256(data).hexdigest()!=item['sha256']:raise ValueError('DOWNLOAD_HASH_MISMATCH')
            with tempfile.NamedTemporaryFile(dir=cache,delete=False) as output:
                output.write(data);temporary=Path(output.name)
            temporary.replace(path)
        if hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:raise ValueError('CACHE_HASH_MISMATCH')
        paths.append(path)
    return paths

if __name__=='__main__':
    for path in fetch():print(path)
