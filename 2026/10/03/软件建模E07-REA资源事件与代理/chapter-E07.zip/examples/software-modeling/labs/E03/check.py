import hashlib,json,os,re,shutil,subprocess,tempfile
from pathlib import Path
from fetch_tools import fetch
BASE=Path(__file__).resolve().parents[2]
EVIDENCE=BASE/'evidence/E03'

def check(name,actual,expected):
    passed=actual==expected
    print(json.dumps({'scenario':name,'actual':actual,'expected':expected,'pass':passed}))
    if not passed:raise AssertionError(name)

def main():
    EVIDENCE.mkdir(parents=True,exist_ok=True)
    jar=fetch()[0]
    java=str(Path(os.environ['JAVA_HOME'])/'bin/java') if 'JAVA_HOME' in os.environ else 'java'
    version=subprocess.run([java,'-version'],capture_output=True,text=True)
    (EVIDENCE/'java-version.txt').write_text(version.stdout+version.stderr)
    rows=[]
    with tempfile.TemporaryDirectory(prefix='modeling-e03-') as temp:
        work=Path(temp)
        for p in (BASE/'models/E03').glob('*'):
            if p.suffix in ('.tla','.cfg'):shutil.copyfile(p,work/p.name)
        for name in ('Unguarded','Protected'):
            command=[java,'-XX:+UseParallelGC','-Xmx256m','-cp',str(jar),'tlc2.TLC','-workers','1','-fp','0','-seed','1','-metadir',str(work/name),'-config',name+'.cfg','Commitments']
            run=subprocess.run(command,cwd=work,capture_output=True,text=True)
            text=run.stdout+run.stderr
            (EVIDENCE/f'{name.lower()}-output.txt').write_text(text)
            (EVIDENCE/f'{name.lower()}-exit.txt').write_text(str(run.returncode)+'\n')
            rows.append({'case':name,'command':command,'exit':run.returncode,'jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest()})
            if name=='Unguarded':
                check('unguarded-counterexample-exit',run.returncode,12)
                check('unguarded-named-invariant-violated','Invariant NoDoubleCommitment is violated' in text,True)
                check('trace-contains-two-commitments',bool(re.search(r'committed = \{(?:R1, R2|R2, R1)\}',text)),True)
                check('trace-shows-two-stale-readers','sawFree = (R1 :> TRUE @@ R2 :> TRUE)' in text,True)
            else:
                check('protected-exhaustive-exit',run.returncode,0)
                check('protected-no-error','Model checking completed. No error has been found.' in text,True)
                check('protected-state-space-finished','0 states left on queue' in text,True)
    (EVIDENCE/'invocations.json').write_text(json.dumps(rows,indent=2)+'\n')

if __name__=='__main__':main()
