import itertools
import json
from pathlib import Path
import sys

MODEL = Path(__file__).resolve().parents[2] / "models/E06/product.json"

def load():
    m = json.loads(MODEL.read_text())
    names = m["features"]
    if len(names) != len(set(names)):
        raise ValueError("duplicate features")
    refs = [m["root"], *m["parents"], *m["parents"].values()]
    for key in ("mandatory", "requires", "excludes"):
        refs += [v for pair in m[key] for v in pair]
    for group in m["xor"]:
        refs += [group["parent"], *group["children"]]
    if set(refs) - set(names):
        raise ValueError("unknown reference")
    return m

def violations(m, selected):
    errors = []
    if set(selected) - set(m["features"]): errors.append("unknown-feature")
    if m["root"] not in selected: errors.append("root-required")
    for child, parent in m["parents"].items():
        if child in selected and parent not in selected: errors.append(f"parent:{child}->{parent}")
    for parent, child in m["mandatory"]:
        if parent in selected and child not in selected: errors.append(f"mandatory:{child}")
    for g in m["xor"]:
        if g["parent"] in selected and sum(c in selected for c in g["children"]) != 1:
            errors.append("xor:" + g["parent"])
    for a, b in m["requires"]:
        if a in selected and b not in selected: errors.append(f"requires:{a}->{b}")
    for a, b in m["excludes"]:
        if a in selected and b in selected: errors.append(f"excludes:{a},{b}")
    return errors

def products(m):
    return [frozenset(f for f, enabled in zip(m["features"], bits) if enabled)
            for bits in itertools.product((False, True), repeat=len(m["features"]))
            if not violations(m, {f for f, enabled in zip(m["features"], bits) if enabled})]

def main():
    m = load()
    if sys.argv[1:]:
        errors = violations(m, set(sys.argv[1].split(",")))
        print("CONFIG", sys.argv[1], "errors=", errors)
        return int(bool(errors))
    valid = products(m)
    print("ENUMERATED", 2 ** len(m["features"]), "VALID", len(valid))
    assert len(valid) == 7
    for selected in valid: print("PRODUCT", ",".join(sorted(selected)))
    cases = [({"Rental", "Booking", "Pickup"}, True),
             ({"Rental", "Booking", "Pickup", "Delivery"}, False),
             ({"Rental", "Booking", "Delivery"}, False),
             ({"Rental", "Booking", "Delivery", "Address", "CrossBorder"}, False),
             ({"Rental", "Booking"}, False), ({"Rental", "Pickup"}, False),
             ({"Rental", "Booking", "Pickup", "Mystery"}, False)]
    for selected, expected in cases:
        errors = violations(m, selected)
        assert (not errors) == expected
        print("PASS scenario", sorted(selected), errors)
    changed = dict(m, excludes=m["excludes"] + [["CrossBorder", "Insurance"]])
    after = products(changed)
    dead = sorted(f for f in m["features"] if not any(f in p for p in after))
    assert len(after) == 6 and dead == ["CrossBorder"]
    print("PASS change-card valid=6 dead=", dead)
    assert all(violations(m, p - {"Address"}) for p in valid if "Delivery" in p)
    print("PASS runtime-removal-of-required-address-is-invalid")
    print("RESULT checks=10 PASS")
    return 0

if __name__ == "__main__": sys.exit(main())
