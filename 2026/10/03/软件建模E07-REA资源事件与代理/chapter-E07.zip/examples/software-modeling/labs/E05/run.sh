#!/usr/bin/env bash
set -euo pipefail
here=$(cd "$(dirname "$0")" && pwd)
python_cmd=${PYTHON_BINARY:-python3}
cache=${MODELING_E05_CACHE:-${XDG_CACHE_HOME:-$HOME/.cache}/software-modeling/E05}
mkdir -p "$cache"
if [[ ! -x "$cache/venv/bin/python" ]]; then "$python_cmd" -m venv "$cache/venv"; fi
lock=$(shasum -a 256 "$here/requirements.lock" | cut -d ' ' -f1)
if [[ ! -f "$cache/installed-$lock" ]]; then
  PIP_USER=false "$cache/venv/bin/python" -m pip install --isolated --index-url https://pypi.org/simple --require-hashes --only-binary=:all: -r "$here/requirements.lock"
  touch "$cache/installed-$lock"
fi
"$cache/venv/bin/python" "$here/semantics.py" "$@"
