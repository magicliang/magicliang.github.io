import copy
import json
from pathlib import Path
import sys

MODEL = Path(__file__).resolve().parents[2] / 'models/E07/exchange.json'

def validate(model):
    errors = []
    commitments = {c['id']: c for c in model['commitments']}
    events = {e['id']: e for e in model['events']}
    if len(commitments) != len(model['commitments']): errors.append('duplicate-commitment')
    if len(events) != len(model['events']): errors.append('duplicate-event')
    fulfilled = {key: 0 for key in commitments}
    for item in model['commitments'] + model['events']:
        if item['resource'] not in model['resources']: errors.append('unknown-resource')
        if type(item['quantity']) is not int or item['quantity'] <= 0: errors.append('positive-integer-required')
        if item['provider'] not in model['agents'] or item['receiver'] not in model['agents']: errors.append('unknown-agent')
        if item['provider'] == item['receiver']: errors.append('same-agent')
    for event in model['events']:
        commitment = commitments.get(event['commitment'])
        if commitment is None:
            errors.append('unknown-commitment')
            continue
        if any(event[key] != commitment[key] for key in ('resource', 'provider', 'receiver')):
            errors.append('fulfillment-mismatch')
        fulfilled[commitment['id']] += event['quantity']
    for key, quantity in fulfilled.items():
        if quantity > commitments[key]['quantity']: errors.append('over-fulfillment')
    for left, right in model['duality']:
        if left not in events or right not in events:
            errors.append('unknown-duality-event')
        elif events[left]['provider'] != events[right]['receiver'] or events[left]['receiver'] != events[right]['provider']:
            errors.append('duality-parties-mismatch')
    return sorted(set(errors)), {key: c['quantity'] - fulfilled[key] for key, c in commitments.items()}

def main():
    model = json.loads(MODEL.read_text())
    if sys.argv[1:]:
        if sys.argv[1:] != ['over']: raise ValueError('expected over')
        model['events'][0]['quantity'] = 5
        errors, remaining = validate(model)
        print('NEGATIVE', errors, remaining)
        return int(bool(errors))
    errors, remaining = validate(model)
    assert not errors and remaining == {'supply': 2, 'pay': 200}
    print('PASS partial-fulfillment', remaining)
    complete = copy.deepcopy(model)
    for event in list(complete['events']):
        next_event = dict(event, id=event['id'] + '-2')
        complete['events'].append(next_event)
    complete['duality'].append(['use-1-2', 'cash-1-2'])
    assert validate(complete) == ([], {'supply': 0, 'pay': 0})
    print('PASS complete-fulfillment', validate(complete)[1])
    cases = [('quantity', 5, 'over-fulfillment'), ('quantity', 0, 'positive-integer-required'),
             ('provider', 'missing', 'unknown-agent'), ('resource', 'cash', 'fulfillment-mismatch'),
             ('commitment', 'missing', 'unknown-commitment')]
    for field, value, expected in cases:
        changed = copy.deepcopy(model)
        changed['events'][0][field] = value
        actual = validate(changed)[0]
        assert expected in actual
        print('PASS', expected, actual)
    duplicate = copy.deepcopy(model)
    duplicate['events'].append(dict(duplicate['events'][0]))
    assert 'duplicate-event' in validate(duplicate)[0]
    print('PASS duplicate-event-rejected')
    changed = copy.deepcopy(model)
    changed['duality'] = [['use-1', 'missing']]
    assert 'unknown-duality-event' in validate(changed)[0]
    print('PASS unknown-duality-event')
    changed = copy.deepcopy(model)
    changed['commitments'][1]['quantity'] = 500
    assert validate(changed) == ([], {'supply': 2, 'pay': 300})
    print('PASS change-card-price-obligation-500 remainder=300 history-cash=200')
    assert model['events'][1]['quantity'] == 200
    print('RESULT checks=10 PASS; synthetic REA-inspired exchange, not a certified REA engine')
    return 0

if __name__ == '__main__':
    sys.exit(main())
