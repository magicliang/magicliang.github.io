#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
lab=${1:-00}
if [[ $# -gt 1 || ! "$lab" =~ ^([0-3][0-9]|E0[1-9]|E1[01])$ ]]; then
  echo "Usage: $0 [00-39|E01-E11]" >&2
  exit 2
fi
if [[ "$lab" != 00 ]]; then
  entry="$root/labs/$lab/run.sh"
  if [[ ! -f "$entry" ]]; then
    echo "Lab $lab has not been implemented." >&2
    exit 2
  fi
  exec bash "$entry"
fi
java_cmd=java
javac_cmd=javac
if [[ -n "${JAVA_HOME:-}" ]]; then
  java_cmd="$JAVA_HOME/bin/java"
  javac_cmd="$JAVA_HOME/bin/javac"
fi
java_version=$("$java_cmd" -version 2>&1)
javac_version=$("$javac_cmd" -version 2>&1)
if [[ ! "$java_version" =~ version\ \"21[.\"] || ! "$javac_version" =~ ^javac\ 21[.\ ] ]]; then
  printf 'JDK 21 required; set JAVA_HOME to a JDK 21 installation.\n%s\n%s\n' "$java_version" "$javac_version" >&2
  exit 2
fi
classes=$(mktemp -d "${TMPDIR:-/tmp}/rental-lab.XXXXXX")
trap 'rm -rf "$classes"' EXIT
"$javac_cmd" --release 21 -Xlint:all -Werror -d "$classes" "$root/rental-core/RentalDesk.java" "$root/labs/00/BaselineCheck.java"
"$java_cmd" -ea -cp "$classes" rental.BaselineCheck
