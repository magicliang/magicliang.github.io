package rental;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public final class RentalDesk {
    public record EquipmentId(String value) {
        public EquipmentId { requireId(value); }
    }

    public record RequestId(String value) {
        public RequestId { requireId(value); }
    }

    public record Period(Instant start, Instant end) {
        public Period {
            Objects.requireNonNull(start, "start");
            Objects.requireNonNull(end, "end");
            if (!start.isBefore(end)) throw new IllegalArgumentException("start must precede end");
        }

        public boolean overlaps(Period other) {
            return start.isBefore(other.end) && other.start.isBefore(end);
        }
    }

    public record ReserveRequest(RequestId requestId, EquipmentId equipmentId, Period period) {
        public ReserveRequest {
            Objects.requireNonNull(requestId, "requestId");
            Objects.requireNonNull(equipmentId, "equipmentId");
            Objects.requireNonNull(period, "period");
        }
    }

    public enum Outcome { CONFIRMED, OVERLAP_REJECTED }

    private record Receipt(ReserveRequest request, Outcome outcome) {}

    private final Map<RequestId, Receipt> receipts = new HashMap<>();
    private final Map<RequestId, ReserveRequest> bookings = new HashMap<>();

    public Outcome reserve(ReserveRequest request) {
        Objects.requireNonNull(request, "request");
        Receipt previous = receipts.get(request.requestId());
        if (previous != null) {
            if (!previous.request().equals(request)) {
                throw new IllegalArgumentException("requestId already used with different payload");
            }
            return previous.outcome();
        }
        // ponytail: O(n) booking scan; add an equipment/time index when measured volume requires it.
        boolean conflict = bookings.values().stream().anyMatch(existing ->
                existing.equipmentId().equals(request.equipmentId())
                        && existing.period().overlaps(request.period()));
        Outcome outcome = conflict ? Outcome.OVERLAP_REJECTED : Outcome.CONFIRMED;
        receipts.put(request.requestId(), new Receipt(request, outcome));
        if (outcome == Outcome.CONFIRMED) bookings.put(request.requestId(), request);
        return outcome;
    }

    /** Returns true only when an active booking was released. Retains its original receipt. */
    public boolean cancel(RequestId requestId) {
        return bookings.remove(Objects.requireNonNull(requestId, "requestId")) != null;
    }

    private static void requireId(String value) {
        if (value == null || value.isBlank()) throw new IllegalArgumentException("nonblank id required");
    }
}
