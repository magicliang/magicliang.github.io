PRAGMA foreign_keys = ON;
CREATE TABLE party (
  party_id TEXT PRIMARY KEY NOT NULL,
  display_name TEXT NOT NULL
);
CREATE TABLE equipment (
  equipment_id TEXT PRIMARY KEY NOT NULL
);
CREATE TABLE receipt (
  request_id TEXT PRIMARY KEY NOT NULL,
  equipment_id TEXT NOT NULL REFERENCES equipment(equipment_id),
  party_id TEXT REFERENCES party(party_id),
  start_epoch INTEGER NOT NULL,
  end_epoch INTEGER NOT NULL,
  outcome TEXT NOT NULL CHECK(outcome IN ('CONFIRMED', 'OVERLAP_REJECTED')),
  CHECK(start_epoch < end_epoch)
);
CREATE TABLE booking (
  request_id TEXT PRIMARY KEY NOT NULL REFERENCES receipt(request_id)
);
