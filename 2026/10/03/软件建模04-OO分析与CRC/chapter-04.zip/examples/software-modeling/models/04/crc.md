# 04 CRC 候选分配

合成案例，书面角色走查，非真实访谈或团队工作坊。继承 00/01 的 UTC、[start,end)、实例级请求身份和取消保留回执契约。

| 候选 | 对象 | 主动动词职责 | 协作者及消息 |
|---|---|---|---|
| A，当前 core | RentalDesk | 比较旧载荷、重放原结果、拒绝冲突、登记占用、取消占用 | ReserveRequest 取值，Period.overlaps，两个 Map 读写 |
| A/B | Period | 拒绝无效区间、判断重叠 | Instant.isBefore |
| B，仅 lab | SplitDesk | 按顺序协调重放、预留和记账 | Ledger.lookup/remember，Schedule.reserve/release |
| B，仅 lab | Ledger | 比较旧载荷、保存并返回原结果 | ReserveRequest.equals |
| B，仅 lab | Schedule | 拒绝同设备重叠、登记并释放当前占用 | ReserveRequest 取值，Period.overlaps |

候选 B 的 Schedule 不提供外部应用入口，包围它的 SplitDesk 负责先读回执；单独调用 Schedule 会绕开重试契约。两个辅助对象都是具体类，没有仓储接口或框架。

## 消息走查

A E1 [10,12) 确认；B E1 [11,13) 拒绝；C E1 [12,13) 确认；D E2 [10,12) 确认。旧 A 改负载必须异常且不改原占用。取消 A 仅释放占用，再取消返回 false；重放 A 返回原确认但不重新占位；再取消 C，确保 B 的冲突已全部消失，重放 B 仍拒绝；新 F E1 [10,12) 确认。逐步断言由 labs/04/CrcCheck.java 同时施加于 A/B。

反例：取消同时删除 Ledger 回执。旧 A 重放仍返回 CONFIRMED，看似正常，但新 F 被拒绝，暴露旧预留复活。用外部行为探针识别，不靠读私有计数；私有访问仅用于注入故障。

变化走查（未实现）：清洁占用期可能由 Schedule 接收独立区间；仍需确定如何从租期推导及取消是否释放清洁。不能直接把 Period.overlaps 的 < 改成 <=。性能、并发、持久化未验证。当前 core 保留 A，B 仅展示另一分配同样可满足已测场景。
