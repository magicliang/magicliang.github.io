# 01 验收证据

状态：本地 Java 21 行为实验与文章/模型一致性已验证；完整 Hexo 构建和浏览器观察交给主任务集成，不在本目录声称完成。

## 可复现调用

从仓库根目录执行：

```bash
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn bash examples/software-modeling/labs/01/run.sh
```

便携入口将 JAVA_HOME 替换为本机 JDK 21 路径。版本：Corretto 21.0.11；逐项输出 run.log；进程退出值 exit-code.txt。脚本仅使用 Java 标准库与临时编译目录；20 个显式断言失败会抛出 AssertionError，导致非零退出。

## 成功标准与二元观察

| 标准 | 具体场景/调用 | 二元观察 | 本次工件 |
|---|---|---|---|
| 正常、异常、边界路径 | 上述 run.sh；S01–S05 | CONFIRMED、OVERLAP_REJECTED、IllegalArgumentException 与期望相等 | run.log、exit-code.txt |
| 重试与新意图区分 | run.sh；S06–S09 | 改负载抛出异常；原预留仍有效；取消后旧成功回执不重建占用；旧拒绝回执稳定而新 ID 可成功 | run.log |
| 取消边界 | run.sh；S08、S10 | 第一次 true；重复、未知、已拒绝请求 false | run.log |
| 每条约定有来源、反例、实现映射 | 核对 models/01/scenarios-and-rules.md 的 R1–R4、C1–C2 与 rental-core/RentalDesk.java | 6 行均同时含来源、反例、符号、场景；S01–S10 存在于模型与实际 lab | artifact-check.json；models/01/scenarios-and-rules.md |
| 资料核对 | web.open 两个原始 PDF | v1.1 p1/p4；Manifesto v2.0 §§2–4可定位 | sources.md |

artifact-check.json 是本次只读 Python 断言检查的实际输出，包含正文、模型、实验和基线的 SHA-256。它检查字数范围、正文与已审草稿逐字相等、10个场景编号、6条规则编号、日志20项PASS及退出码0。

局限：没有并发、持久化、身份授权、UI或生产验证。尝试直接 require('hexo-renderer-marked') 返回 MODULE_NOT_FOUND，因此没有将该非配置渲染器当作渲染证据；主任务应使用项目实际 Hexo 配置统一构建。
