# 04 验证记录

场景/二元观察：A 当前 RentalDesk 与 B 候选 SplitDesk 分别执行确认、重叠拒绝、相邻接受、设备隔离、重试、载荷冲突、取消两次、取消后重放、新请求、已拒绝请求在冲突全部释放后重放、取消拒绝请求。每个期望不符立即抛出，进程非零。output.txt 含 central/split 的逐项 PASS，exit-code.txt 为 0。故意删除回执的变体在重放后拒绝新请求，output.txt 含 DETECTED cancelled_request_resurrected；该观察通过外部返回值判定。

完整调用见 command.txt；使用 Java 21.0.11，编译标志 --release 21 -Xlint:all -Werror。模型在 ../../models/04/crc.md；源码在 ../../labs/04/CrcCheck.java。source-sha256.txt 标记本次被验证源文件。

两份 JSON 保存扫描结果及草稿 SHA256；post-model-check.txt 验证落盘正文与已扫描草稿一致。sources.md 为直接读取一手资料的位置与边界。

限制：单线程内存实验；未验证生产规则、持久化、并发或跨进程重放。候选 B 不进入累计 core。共享 Hexo 构建、浏览器与 ZIP 打包由主代理集成。
