# 02 verification receipt

Scope: local static DFD checks; no rental runtime, sequence, concurrency or deployment proof.

Invocation from repository root: `sh examples/software-modeling/labs/02/run.sh`.

| Scenario | Binary observable | Captured artifact |
|---|---|---|
| Context/detail boundary conservation | `PASS balanced_boundary` and exit 0 | `output.txt`, `exit-code.txt` |
| Missing and duplicate external output | Both intentional fixtures rejected with `boundary imbalance` | `output.txt` |
| Missing dictionary definition and store bypass | Both intentional fixtures rejected | `output.txt` |
| Diagram source agrees with JSON | `PASS diagram_source_matches_model` | `output.txt` |
| Standalone downloadable package | Extracted run exits 0 | `archive-output.txt`, `archive-exit-code.txt` |

Freshly read source: https://www.excelsoftware.com/processmodel, headings Data Flow Diagrams, Data Dictionary, Verification and Balance Reports. Supports process decomposition, dictionaries and boundary conservation. It also discusses an extended control-flow notation, which this chapter does not adopt. No claim that Yourdon materials do not exist.

The checker only compares identically named boundary flows. It does not expand composite dictionary entries or validate natural-language field semantics. `source-sha256.txt` freezes the verified model and executable source. The chapter Mermaid blocks are checked against the `.mmd` files in `post-model-check.txt`. Hexo build and browser verification belong to the parent integration run.
