# 03 verification receipt

Scope: local in-memory SQLite mapping probe; not a persistent adapter, concurrency test or full RentalDesk implementation.

Invocation from repository root: `sh examples/software-modeling/labs/03/run.sh`.

| Scenario | Binary observable | Captured artifact |
|---|---|---|
| Party multiplicity and optional reference | Two receipts for P1 and NULL party for C | `output.txt`, `exit-code.txt` |
| Equipment/party/booking referential integrity | Three missing-reference fixtures rejected | `output.txt` |
| Unique request and active booking | Duplicate keys rejected | `output.txt` |
| Empty period and deleting referenced receipt | CHECK and foreign-key errors respectively | `output.txt` |
| Cancel active booking | Original receipt tuple unchanged; active count 0 | `output.txt` |
| Known business-rule gap | Rejected booking and overlapping periods accepted, then rolled back | `output.txt` |
| Standalone downloadable package | Extracted run exits 0 | `archive-output.txt`, `archive-exit-code.txt` |

Observed environment: Python 3.14.4, SQLite 3.51.3, foreign_keys=1, recorded by the actual probe. The schema adds an equipment catalog and optional party relation absent from the Java baseline. It does not enforce receipt immutability, confirmed-only bookings, cross-row interval exclusion, blank IDs or Java Instant precision.

Fresh sources: Chen 1976 original paper https://weichselbraun.net/dbs/pdf/literature/chen.pdf §§2.1–2.3 (four logical view levels, entity/relationship/attribute/key); SQLite author docs https://www.sqlite.org/foreignkeys.html (connection setting, referential checks and nullable reference). The chapter's conceptual/logical/physical organization is explicitly its own teaching division, not attributed as Chen's exact terminology.

`source-sha256.txt` freezes schema and executable source. The chapter Mermaid block is compared to the concept source in `post-model-check.txt`. Hexo build and browser verification belong to the parent integration run.
