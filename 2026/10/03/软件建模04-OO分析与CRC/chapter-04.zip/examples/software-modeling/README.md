# 软件建模：设备租赁累计实验

00 使用 Java 21 标准库，无 Maven、测试框架或外部服务。入口从任意工作目录运行：

```bash
JAVA_HOME=/path/to/jdk-21 ./examples/software-modeling/run-lab.sh 00
```

未设置 `JAVA_HOME` 时读取 PATH。运行器同时检查 java/javac 为 21，临时编译目录在退出时清理；断言失败、编译失败或 JDK 不兼容均返回非零退出码。

`rental-core/RentalDesk.java` 是单线程内存表实现。公开 API：`reserve(ReserveRequest)` 返回 `CONFIRMED` 或 `OVERLAP_REJECTED`；`cancel(RequestId)` 返回是否实际释放预留。`EquipmentId`、`RequestId`、`Period`、`ReserveRequest` 使用不可变 record；ID 非空白，时间使用调用方显式传入的 `Instant`，不依赖系统当前时间。

租期采用 `[start,end)`，必须 `start < end`。同一设备的有效预留不能重叠，相邻租期可共存。请求 ID 为当前 RentalDesk 实例内的全局键：同 ID、同负载重试返回最初结果，改负载抛出 `IllegalArgumentException`。取消仅移除有效预留，保留最初请求结果；因此取消后重放旧请求不会重新预留。已拒绝的请求即使后来资源空闲仍返回原拒绝结果，重新尝试须使用新请求 ID。

`labs/00/BaselineCheck.java` 检查区间边界、不同重叠形态、设备隔离、取消、成功和失败请求的幂等重放、非法输入。逐项输出和退出码保存在 `evidence/00/`。其他已实现章节可使用同一入口，例如 `bash run-lab.sh 01`；对应 `labs/NN/run.sh` 自行选择所需工具。未实现章节返回非零退出码，不会被当作已通过。

这是合成教学案例。没有线程安全、持久化、跨进程幂等、身份认证、付款或真实租赁企业规则的保证。扫描成本为 O(n)，请求回执随实例存活而保留；后续章节按需求加入模型，不提前加入聚合、仓储或领域事件。
