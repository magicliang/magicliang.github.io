package examples;

import jakarta.inject.Inject;
import org.apache.pekko.actor.ActorSystem;
import org.apache.pekko.stream.javadsl.Source;
import org.apache.pekko.util.ByteString;
import java.util.Arrays;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import play.http.HttpEntity;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;

public final class MigrationExample extends Controller {
    private final ActorSystem system;

    @Inject
    public MigrationExample(ActorSystem system) {
        this.system = system;
    }

    public CompletionStage<Result> async() {
        return CompletableFuture.supplyAsync(
                () -> ok(Json.newObject().put("value", "async-ok"))
                        .withHeader("X-Async-Thread", Thread.currentThread().getName()),
                system.dispatcher());
    }

    public Result known() {
        Source<ByteString, ?> bytes = Source.from(Arrays.asList(
                ByteString.fromString("part"), ByteString.fromString("-two")));
        return ok().sendEntity(new HttpEntity.Streamed(
                bytes, Optional.of(8L), Optional.of("text/plain")));
    }
}
