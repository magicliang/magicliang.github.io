# Play 32 isolated migration acceptance

Source owner: `/private/tmp/play-migration-work-20261003`. No shared lab, posts or Git were changed for this experiment. Public intended path: `examples/play-electives/migration/`.

| Scenario | Actual invocation | Binary observable | Raw artifact |
| --- | --- | --- | --- |
| Play 2.8.22 / Scala 2.13.15 | `python3 run_build.py play28 .../final-build.log test stage 'show Compile / dependencyClasspath'` | exit 0, two JUnit passed, staged application class byte hash matches compiled class | `play28/final-build.log`, `play28/TEST-ContractTest.xml`, `play28/resolved-and-staged.json` |
| Play 2.9.6 / Scala 2.13.15 | same command with play29 | same observables; com.typesafe.play resolved core | `play29/` corresponding files |
| Play 3.0.6 / Scala 2.13.15 | same command with play30 | same observables; org.playframework resolved core | `play30/` corresponding files |
| Separate Scala 3.3.4 change on Play 3.0.6 | same command with play30-scala3 | same observables; native `_3` framework artifacts | `play30-scala3/` corresponding files |
| Production HTTP in all four combinations | `python3 http_matrix.py <variant> <variant>/final-http` | valid, 404, JSON 400, true dispatcher async 200/500, full WS body, WS timeout while downstream gated, CL8 / chunked bodies, socket cancellation termination, sessions | `<variant>/final-http/observations.json`, `server.log` |
| Production identity / resource exit | same HTTP command | actual AkkaHttpServer or PekkoHttpServer logger plus provider/actor-system class and loaded jar location; no forced kill, process terminated, listener closed, all downstream handlers finished | same JSON and server log |
| Obsolete Akka import | `python3 negative_import.py .../play30/final-negative-import` | real compile exit 1; `akka.util` missing; original source restored and hash matches current | `play30/final-negative-import/compile-failure.log`, `observations.json`, `legacy-import.java` |
| Obsolete configuration key | `python3 http_matrix.py play30 .../final-legacy-config --legacy-config` | legacy-only readback exists; active key unset; Server header absent; all remaining HTTP checks still pass | `play30/final-legacy-config/observations.json`, `legacy.conf`, `server.log` |
| Source / artifact reconciliation | `python3 collect_evidence.py .omo/evidence/play-migration-20261003` | 50 source/config/harness hashes, resolved jar hashes match staged jars, all required observations asserted | `manifest.json`, `verification-receipt.txt` |

All runs use Amazon Corretto 21.0.11 and sbt 1.10.7. Java 21 is outside Play 2.8.22's documented support range; the `java.lang` add-opens is a narrow Guice 4 compatibility workaround for this finite experiment. A meta-build-only scala-xml compatibility declaration permits the actual selected 2.3.0; it is not a global eviction/warning suppression. Initial failure logs remain under each version directory. Final build rerun uses the portable environment-based helper; earlier clean builds and negative clean compile logs are retained.

Limits: isolated loopback HTTP/1.1 only; no reverse proxy/TLS/HTTP2, cross-version cookie transfer, production traffic, arbitrary external plugins or Scala business-source migration. Security filters are deliberately disabled for the contract fixture. Poll counts vary and are not throughput measurements. Cleanup succeeds in recorded normal/negative runs; these receipts do not claim a separate signal-injection cleanup test.
