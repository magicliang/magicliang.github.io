# Ordered scan 1: anti-ai-tone

Input: draft.md. Profile: tech. This manual scan precedes anti-persona-fabrication and publication.

Support review: the introduction is supported by the preserved import compile failure and legacy-config production observation. Version and server table is supported by actual resolved/staged jar hashes and server logs. Old JDK and scala-xml exceptions retain first failures and narrow their scope. HTTP table maps to real assertions; future exercises explicitly describe unrun extensions. No benchmark or official support claim is inferred from local success.

Progression review: sections advance from separated version axes, through old baseline constraints, 2.9 platform changes, 3.0 type/config changes, separate Scala 3 resolution, network contracts, reproduction and exercises. No duplicate conclusion section. The narrative distinguishes compile, configuration readback and server consumption with concrete counterexamples.

Rhythm and continuity review: technical nouns remain explicit; no first-person or editorial revision story. Tables compare real version dimensions or contract observables. Two diagrams explain migration isolation and config consumption. No artificial dialogue, dramatic headings, consultant slogans or summary padding. Commands are single physical lines.

Auxiliary check_prose.py returned errors=0 and warnings=1. The warning at the groupId paragraph counts two source-line range en dashes in link labels, not narrative em dashes; retain the precise citations. The script supplements this review and is not a technical or prose-quality proof.

Verdict: PASS. Retain the draft unchanged for scan 2.
