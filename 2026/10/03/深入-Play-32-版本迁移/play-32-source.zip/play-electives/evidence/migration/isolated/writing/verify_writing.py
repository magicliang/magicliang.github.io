from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import xml.etree.ElementTree as ET

repo = Path(__file__).resolve().parents[4]
writing = Path(__file__).resolve().parent
post = repo/'source/_posts/2026-10-03-深入-Play-32-版本迁移.md'
cover = post.with_suffix('')/'cover.svg'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

first = json.loads((writing/'01-receipt.json').read_text())
second = json.loads((writing/'02-receipt.json').read_text())
assert first['completedAt'] < second['completedAt']
assert first['inputSha256'] == second['inputSha256'] == sha(post) == sha(writing/'draft.md')
assert second['previousReceiptSha256'] == sha(writing/'01-receipt.json')
assert first['reviewSha256'] == sha(writing/'01-anti-ai-tone.md')
assert second['reviewSha256'] == sha(writing/'02-anti-persona-fabrication.md')
print('ORDERED_SCANS_PASS anti-ai-tone -> anti-persona-fabrication; published SHA256', sha(post))

article = post.read_text()
assert article.count('```mermaid') == 2
assert '/private/tmp' not in article and '/Users/' not in article
assert (repo/'source/_posts/2026-10-03-深入-Play-31-性能与容量.md').is_file()
code = re.findall(r'```java\n(.*?)\n```', article, re.S)
assert len(code) == 1
java = writing/'java/examples/MigrationExample.java'
assert java.read_text() == code[0]+'\n'
jars = sorted(Path('/private/tmp/play-migration-work-20261003/play30/target/universal/stage/lib').glob('*.jar'))
assert len(jars) > 50
jdk = Path(os.environ['JAVA_HOME'])
command = [str(jdk/'bin/javac'), '-encoding', 'UTF-8', '-cp', os.pathsep.join(map(str,jars)),
           '-d', str(writing/'classes'), str(java)]
result = subprocess.run(command, capture_output=True, text=True, timeout=30)
(writing/'javac.log').write_text('COMMAND '+repr(command)+'\n'+result.stdout+result.stderr+'EXIT_CODE '+str(result.returncode)+'\n')
assert result.returncode == 0, result.stderr
compiled = writing/'classes/examples/MigrationExample.class'
assert compiled.is_file()
print('JAVA_DISPLAY_COMPILE_PASS', java.name, 'class SHA256', sha(compiled))

svg = ET.parse(cover).getroot()
assert svg.attrib['width']=='1200' and svg.attrib['height']=='480' and svg.attrib['viewBox']=='0 0 1200 480'
ns = {'s':'http://www.w3.org/2000/svg'}
nodes = [e for e in svg.findall('s:rect',ns) if e.attrib.get('class')=='node']
assert len(nodes)==4
for element in nodes:
    assert float(element.attrib['y'])==165
    assert float(element.attrib['y'])+float(element.attrib['height'])==255
for element in svg.findall('s:text',ns):
    assert 0 < float(element.attrib['x']) < 1200 and 0 < float(element.attrib['y']) <= 255
assert svg.find('s:title',ns) is not None and svg.find('s:desc',ns) is not None
print('SVG_XML_COORDINATES_PASS 1200x480; four nodes y=165..255; lower title space clear; browser rendering NOT_RUN here')

paths=[post,cover]+sorted(p for p in writing.rglob('*') if p.is_file() and p.name not in {'manifest.json','verification-receipt.txt'} and '__pycache__' not in p.parts)
manifest={'article':str(post),'cover':str(cover),'experimentManifest':str(writing.parent/'manifest.json'),
          'experimentManifestSha256':sha(writing.parent/'manifest.json'),
          'files':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths],
          'scope':'isolated experiments and article; shared integration, site build and CUA owned by parent'}
(writing/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print('WRITING_MANIFEST_PASS', len(paths), 'files; exact article, cover, scans and compiled display source hashes')
