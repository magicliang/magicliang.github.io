import static org.junit.Assert.*;
import static play.test.Helpers.*;
import org.junit.Test;
import play.Application;
import play.inject.guice.GuiceApplicationBuilder;
import play.libs.Json;
import play.mvc.Http;
import play.mvc.Result;

public final class ContractTest {
    @Test public void routesJsonAndAsyncContract() {
        Application app = new GuiceApplicationBuilder().build();
        running(app, () -> {
            Result good = route(app, new Http.RequestBuilder().method("GET").uri("/good"));
            assertEquals(200, good.status());
            assertEquals("same-contract", Json.parse(contentAsString(good)).get("value").asText());
            assertEquals(404, route(app, new Http.RequestBuilder().method("GET").uri("/missing")).status());
            Result bad = route(app, new Http.RequestBuilder().method("POST").uri("/echo").bodyJson(Json.newObject()));
            assertEquals(400, bad.status()); assertEquals("invalid-value", Json.parse(contentAsString(bad)).get("error").asText());
            assertEquals(200, route(app, new Http.RequestBuilder().method("GET").uri("/async")).status());
            IllegalStateException failure = assertThrows(IllegalStateException.class,
                    () -> route(app, new Http.RequestBuilder().method("GET").uri("/failed")));
            assertEquals("synthetic-stage-failure", failure.getMessage());
        });
    }
    @Test public void streamEntityAndRuntimeContract() {
        Application app = new GuiceApplicationBuilder().build();
        running(app, () -> {
            Result known = route(app, new Http.RequestBuilder().method("GET").uri("/known"));
            assertEquals(Long.valueOf(8L), known.body().contentLength().get());
            assertEquals("part-two", contentAsString(known, app.injector().instanceOf(akka.stream.Materializer.class)));
            Result unknown = route(app, new Http.RequestBuilder().method("GET").uri("/unknown"));
            assertFalse(unknown.body().contentLength().isPresent());
            assertEquals("part-two", contentAsString(unknown, app.injector().instanceOf(akka.stream.Materializer.class)));
            Result runtime = route(app, new Http.RequestBuilder().method("GET").uri("/runtime"));
            assertEquals("play.core.server.AkkaHttpServerProvider", Json.parse(contentAsString(runtime)).get("provider").asText());
        });
    }
}
