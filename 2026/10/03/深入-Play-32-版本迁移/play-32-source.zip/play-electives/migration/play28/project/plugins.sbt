addSbtPlugin("com.typesafe.play" % "sbt-plugin" % "2.8.22")
libraryDependencySchemes += "org.scala-lang.modules" %% "scala-xml" % VersionScheme.Always
