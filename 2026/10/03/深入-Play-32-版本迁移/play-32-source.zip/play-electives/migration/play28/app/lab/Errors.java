package lab;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import play.http.HttpErrorHandler;
import play.libs.Json;
import play.mvc.Http;
import play.mvc.Result;
import play.mvc.Results;

public final class Errors implements HttpErrorHandler {
    @Override public CompletionStage<Result> onClientError(Http.RequestHeader request, int status, String message) {
        return CompletableFuture.completedFuture(Results.status(status, Json.newObject().put("error", "client-" + status)));
    }
    @Override public CompletionStage<Result> onServerError(Http.RequestHeader request, Throwable error) {
        return CompletableFuture.completedFuture(Results.internalServerError(Json.newObject().put("error", "server-failure")));
    }
}
