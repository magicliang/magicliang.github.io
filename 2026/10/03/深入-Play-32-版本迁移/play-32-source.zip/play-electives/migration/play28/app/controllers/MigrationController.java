package controllers;

import akka.actor.ActorSystem;
import akka.stream.javadsl.Source;
import akka.util.ByteString;
import javax.inject.Inject;
import javax.inject.Singleton;
import com.typesafe.config.Config;
import java.time.Duration;
import java.util.Arrays;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.atomic.AtomicInteger;
import play.http.HttpEntity;
import play.libs.Json;
import play.libs.ws.WSClient;
import play.mvc.*;

@Singleton
public final class MigrationController extends Controller {
    private final WSClient ws;
    private final Config config;
    private final ActorSystem system;
    private final AtomicInteger streamTerminated = new AtomicInteger();
    @Inject public MigrationController(WSClient ws, Config config, ActorSystem system) {
        this.ws = ws; this.config = config; this.system = system;
    }
    public Result good() { return ok(Json.newObject().put("value", "same-contract")); }
    @BodyParser.Of(BodyParser.Json.class)
    public Result echo(Http.Request request) {
        var value = request.body().asJson().get("value");
        if (value == null || !value.isTextual()) return badRequest(Json.newObject().put("error", "invalid-value"));
        return ok(Json.newObject().put("value", value.asText()));
    }
    public CompletionStage<Result> async() {
        return CompletableFuture.supplyAsync(() -> ok(Json.newObject().put("value", "async-ok"))
                .withHeader("X-Async-Thread", Thread.currentThread().getName()), system.dispatcher());
    }
    public CompletionStage<Result> failed() {
        return CompletableFuture.supplyAsync(() -> { throw new IllegalStateException("synthetic-stage-failure"); }, system.dispatcher());
    }
    public CompletionStage<Result> downstream() {
        return ws.url(config.getString("lab.downstream") + "/body").setRequestTimeout(Duration.ofSeconds(3)).get()
                .thenApply(response -> ok(Json.newObject().put("status", response.getStatus()).put("body", response.getBody())));
    }
    public CompletionStage<Result> timeout() {
        return ws.url(config.getString("lab.downstream") + "/slow").setRequestTimeout(Duration.ofMillis(250)).get()
                .handle((response, error) -> error == null ? ok("unexpected-success")
                        : status(504, Json.newObject().put("error", "upstream-timeout")));
    }
    public Result known() {
        return ok().sendEntity(new HttpEntity.Streamed(Source.from(Arrays.asList(ByteString.fromString("part"), ByteString.fromString("-two"))),
                Optional.of(8L), Optional.of("text/plain")));
    }
    public Result unknown() {
        return ok().chunked(Source.from(Arrays.asList(ByteString.fromString("part"), ByteString.fromString("-two")))).as("text/plain");
    }
    public Result cancel() {
        var source = Source.tick(Duration.ZERO, Duration.ofMillis(40), ByteString.fromString("tick\n"))
                .watchTermination((control, done) -> {
                    done.whenComplete((value, error) -> streamTerminated.incrementAndGet());
                    return control;
                });
        return ok().chunked(source).as("text/plain");
    }
    public Result setSession(Http.Request request) { return ok("set").addingToSession(request, "marker", "same-session"); }
    public Result readSession(Http.Request request) { return ok(Json.newObject().put("marker", request.session().getOptional("marker").orElse("absent"))); }
    public Result runtime() {
        String path = "play.server.akka.server-header";
        return ok(Json.newObject().put("provider", config.getString("play.server.provider"))
                .put("configuredHeader", config.hasPath(path) ? config.getString(path) : "<unset>")
                .put("legacyHeader", config.hasPath("play.server.akka.server-header") ? config.getString("play.server.akka.server-header") : "<unset>")
                .put("actorSystemClass", system.getClass().getName())
                .put("playJar", play.Application.class.getProtectionDomain().getCodeSource().getLocation().toString())
                .put("streamTerminated", streamTerminated.get()));
    }
}
