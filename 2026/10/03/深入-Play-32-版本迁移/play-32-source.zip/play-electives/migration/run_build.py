from pathlib import Path
import os
import signal
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
project, log_path, *tasks = sys.argv[1:]
log = Path(log_path); log.parent.mkdir(parents=True, exist_ok=True)
env = dict(os.environ)
for name in ('JAVA_HOME', 'PLAY_LAB_SBT_LAUNCHER'):
    if not env.get(name): raise RuntimeError('Set '+name)
env['PLAY_LAB_JVM_ARGS'] = f'-Dsbt.override.build.repos=true -Dsbt.repository.config={root}/repositories'
command = ['bash', str(root/project/'sbtw'), *tasks]
with log.open('w') as output:
    print('COMMAND', repr(command), file=output, flush=True)
    start = time.monotonic()
    process = subprocess.Popen(command, stdout=output, stderr=subprocess.STDOUT, env=env, start_new_session=True)
    try:
        code = process.wait(timeout=420)
    except BaseException:
        os.killpg(process.pid, signal.SIGTERM)
        try: process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL); process.wait(timeout=5)
        raise
    finally:
        print('PROCESS_TERMINATED', process.poll() is not None, 'ELAPSED_SECONDS', round(time.monotonic()-start, 3), file=output, flush=True)
    print('EXIT_CODE', code, file=output, flush=True)
print(project, 'exit', code, str(log))
sys.exit(code)
