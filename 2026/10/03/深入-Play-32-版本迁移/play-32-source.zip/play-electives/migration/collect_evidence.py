from pathlib import Path
import difflib
import hashlib
import json
import re
import shutil
import sys
import xml.etree.ElementTree as ET
import zipfile

root = Path(__file__).resolve().parent
evidence = Path(sys.argv[1]).resolve()
versions = {'play28': ('2.8.22','2.13.15','com.typesafe.play'), 'play29': ('2.9.6','2.13.15','com.typesafe.play'),
            'play30': ('3.0.6','2.13.15','org.playframework'), 'play30-scala3': ('3.0.6','3.3.4','org.playframework')}
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def metadata(path): return {'path':str(path), 'sha256':sha(path), 'bytes':path.stat().st_size}
summary = {}
for variant, (version, scala, group) in versions.items():
    p = root/variant; out = evidence/variant
    log = (out/'final-build.log').read_text()
    assert 'EXIT_CODE 0' in log and 'Passed: Total 2, Failed 0, Errors 0, Passed 2' in log, variant
    junit = p/'target/test-reports/TEST-ContractTest.xml'
    xml = ET.parse(junit).getroot()
    assert xml.attrib['tests']=='2' and xml.attrib['failures']=='0' and xml.attrib['errors']=='0', variant
    shutil.copy2(junit, out/'TEST-ContractTest.xml')
    resolved = sorted(set(Path(path) for path in re.findall(r'Attributed\(([^)]*\.jar)\)', log)))
    assert resolved, variant
    jars = []
    for path in resolved:
        marker = '/maven2/'
        if marker in str(path):
            parts = str(path).split(marker,1)[1].split('/')
            coordinate = ':'.join(('.'.join(parts[:-3]), parts[-3], parts[-2]))
        else: coordinate = '<non-maven-path>'
        jars.append(dict(metadata(path), coordinate=coordinate))
    staged = sorted((p/'target/universal/stage/lib').glob('*.jar'))
    stage_meta = [metadata(path) for path in staged]
    stage_hashes = {item['sha256'] for item in stage_meta}
    assert all(item['sha256'] in stage_hashes for item in jars), variant
    core = [j for j in jars if j['coordinate'].split(':')[0]==group and re.match(r'play(?:-java)?_(?:2\.13|3):', j['coordinate'].split(':',1)[1])]
    assert len(core)>=2 and all(j['coordinate'].endswith(':'+version) for j in core), core
    assert any('scala3-library_3:3.3.4' in j['coordinate'] for j in jars) if scala.startswith('3.') else any('scala-library:2.13.15' in j['coordinate'] for j in jars)
    classdir = p/('target/scala-'+('3.3.4' if scala.startswith('3.') else '2.13')+'/classes')
    controller = classdir/'controllers/MigrationController.class'
    containing = []
    for path in staged:
        with zipfile.ZipFile(path) as jar:
            if 'controllers/MigrationController.class' in jar.namelist():
                assert hashlib.sha256(jar.read('controllers/MigrationController.class')).hexdigest()==sha(controller)
                containing.append(metadata(path))
    assert len(containing)==1
    http = json.loads((out/'final-http/observations.json').read_text())
    for key in ('matrixPassed','timeoutBeforeDownstreamRelease','cancelObserved','processTerminated','downstreamThreadTerminated','listenerClosed','allHandlersFinished'):
        assert http[key] is True, (variant,key)
    assert http['cleanupFailures']==[]
    server = 'PekkoHttpServer' if variant.startswith('play30') else 'AkkaHttpServer'
    server_log = (out/'final-http/server.log').read_text()
    assert 'play.core.server.'+server+' - Listening for HTTP' in server_log, variant
    assert any(r['path']=='/async' and 'actor.default-dispatcher' in r['headers']['X-Async-Thread'] for r in http['requests'])
    info = {'version':version,'scala':scala,'frameworkGroup':group,'junitPassed':2,'httpRequestsIncludingPolls':len(http['requests']),
            'server':server,'runtime':http['runtime'],'applicationJar':containing[0],'controllerClassSha256':sha(controller),
            'resolvedJars':jars,'stagedJars':stage_meta}
    (out/'resolved-and-staged.json').write_text(json.dumps(info,indent=2)+'\n')
    summary[variant] = {k:v for k,v in info.items() if k not in ('resolvedJars','stagedJars')}
    print('VERIFIED', variant, 'JUnit=2', 'HTTP='+str(len(http['requests'])), 'resolved='+str(len(jars)), 'staged='+str(len(staged)), server)
negative = json.loads((evidence/'play30/final-negative-import/observations.json').read_text())
assert negative['expectedCompileFailure'] and negative['restoredSha256']==sha(root/'play30/app/controllers/MigrationController.java')
legacy = json.loads((evidence/'play30/final-legacy-config/observations.json').read_text())
assert legacy['matrixPassed'] and legacy['runtime']['legacyHeader']=='legacy-only' and legacy['runtime']['configuredHeader']=='<unset>'
assert legacy['cleanupFailures']==[]
assert 'Server' not in legacy['requests'][0]['headers']
print('VERIFIED negative akka import rejected/restored; old config retained/readable but inactive')
for left,right in [('play28','play29'),('play29','play30'),('play30','play30-scala3')]:
    diff=[]
    for relative in ('project/plugins.sbt','build.sbt','sbtw','conf/application.conf','app/controllers/MigrationController.java','test/ContractTest.java'):
        diff.extend(difflib.unified_diff((root/left/relative).read_text().splitlines(True),(root/right/relative).read_text().splitlines(True),fromfile=left+'/'+relative,tofile=right+'/'+relative))
    (evidence/(left+'-to-'+right+'.diff')).write_text(''.join(diff))
files=[]
for variant in versions:
    for path in sorted((root/variant).rglob('*')):
        relative = path.relative_to(root/variant)
        if path.is_file() and 'target' not in relative.parts: files.append(metadata(path))
for path in sorted(root.glob('*.py')): files.append(metadata(path))
for path in sorted((root/'templates').glob('*')): files.append(metadata(path))
files.extend(metadata(root/name) for name in ('README.md','repositories'))
manifest={'sourceRoot':str(root),'sourcePins':{'2.8.22':'4564a5cf3a811399eccc4023d422c0413be09bf7','2.9.6':'b900221530c4162a59ac0452056af1ba557bc47c','3.0.6':'2e56aff7d4e7a74af61e4bd39ec9e3ed7f300cd6'},'summary':summary,'sourceAndHarnessFiles':files}
(evidence/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('MANIFEST_WRITTEN', len(files), 'source/config/harness files')
