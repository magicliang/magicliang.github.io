from pathlib import Path
root = Path(__file__).resolve().parent
variants = [('play28', '2.8.22', '2.13.15'), ('play29', '2.9.6', '2.13.15'), ('play30', '3.0.6', '2.13.15'), ('play30-scala3', '3.0.6', '3.3.4')]
routes = '\n'.join(f'{method} {path} controllers.MigrationController.{action}' for method, path, action in [
    ('GET', '/good', 'good'), ('POST', '/echo', 'echo(request: Request)'), ('GET', '/async', 'async'),
    ('GET', '/failed', 'failed'), ('GET', '/ws', 'downstream'), ('GET', '/timeout', 'timeout'),
    ('GET', '/known', 'known'), ('GET', '/unknown', 'unknown'), ('GET', '/cancel', 'cancel'),
    ('GET', '/session/set', 'setSession(request: Request)'), ('GET', '/session/read', 'readSession(request: Request)'),
    ('GET', '/runtime', 'runtime')]) + '\n'
for name, version, scala in variants:
    p = root / name
    namespace = 'pekko' if version.startswith('3.') else 'akka'
    provider = 'PekkoHttpServerProvider' if namespace == 'pekko' else 'AkkaHttpServerProvider'
    stream = 'org.apache.pekko' if namespace == 'pekko' else 'akka'
    inject = 'jakarta.inject' if namespace == 'pekko' else 'javax.inject'
    group = 'org.playframework' if namespace == 'pekko' else 'com.typesafe.play'
    files = {
        'project/build.properties': 'sbt.version=1.10.7\n',
        'project/plugins.sbt': f'addSbtPlugin("{group}" % "sbt-plugin" % "{version}")\n',
        'build.sbt': f'''ThisBuild / scalaVersion := "{scala}"
ThisBuild / organization := "example.playmigration"
ThisBuild / version := "0.1.0"
lazy val root = (project in file(".")).enablePlugins(PlayJava).settings(
  name := "{name}",
  libraryDependencies ++= Seq(guice, javaWs, "junit" % "junit" % "4.13.2" % Test,
    "com.github.sbt" % "junit-interface" % "0.13.3" % Test),
  Test / parallelExecution := false
)
''',
        'conf/routes': routes,
        'conf/application.conf': f'''play.http.secret.key="migration-local-only-synthetic-key-20261003-long-enough"
play.http.errorHandler="lab.Errors"
play.filters.enabled=[]
play.server.provider="play.core.server.{provider}"
play.server.{namespace}.server-header="migration-server"
lab.downstream="http://127.0.0.1:1"
''',
        'conf/logback.xml': '<configuration><appender name="STDOUT" class="ch.qos.logback.core.ConsoleAppender"><encoder><pattern>%date [%thread] %-5level %logger - %message%n</pattern></encoder></appender><root level="INFO"><appender-ref ref="STDOUT"/></root></configuration>\n',
        'app/controllers/MigrationController.java': (root/'templates/MigrationController.java.in').read_text().replace('STREAM_PACKAGE', stream).replace('INJECT_PACKAGE', inject).replace('SERVER_NAMESPACE', namespace),
        'app/lab/Errors.java': (root/'templates/Errors.java.in').read_text(),
        'test/ContractTest.java': (root/'templates/ContractTest.java.in').read_text().replace('STREAM_PACKAGE', stream).replace('SERVER_PROVIDER', provider),
        'sbtw': '''#!/usr/bin/env bash
set -euo pipefail
lab_dir="$(cd "$(dirname "$0")" && pwd)"
: "${JAVA_HOME:?Set JAVA_HOME to JDK 21}"
: "${PLAY_LAB_SBT_LAUNCHER:?Set PLAY_LAB_SBT_LAUNCHER}"
cd "$lab_dir"
exec "$JAVA_HOME/bin/java" -Xms256m -Xmx1536m -Dsbt.supershell=false -Dsbt.log.noformat=true -Dsbt.server.autostart=false ${PLAY_LAB_JVM_ARGS:-} -jar "$PLAY_LAB_SBT_LAUNCHER" "$@"
'''
    }
    if name == 'play28':
        files['project/plugins.sbt'] += 'libraryDependencySchemes += "org.scala-lang.modules" %% "scala-xml" % VersionScheme.Always\n'
        files['build.sbt'] = files['build.sbt'].replace('Test / parallelExecution := false', 'Test / parallelExecution := false,\n  Test / javaOptions += "--add-opens=java.base/java.lang=ALL-UNNAMED"')
        files['sbtw'] = files['sbtw'].replace('"$JAVA_HOME/bin/java" -Xms', '"$JAVA_HOME/bin/java" --add-opens=java.base/java.lang=ALL-UNNAMED -Xms')
    for relative, content in files.items():
        dest = p / relative; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_text(content)
    print(name, version, scala, len(files), 'files')
(root/'repositories').write_text('[repositories]\nlocal\nmaven-central: https://repo.maven.apache.org/maven2\nsbt-plugin-releases: https://scala.jfrog.io/artifactory/api/download/sbt-plugin-releases/, [organization]/[module]/(scala_[scalaVersion]/)(sbt_[sbtVersion]/)[revision]/[type]s/[artifact](-[classifier]).[ext]\n')
