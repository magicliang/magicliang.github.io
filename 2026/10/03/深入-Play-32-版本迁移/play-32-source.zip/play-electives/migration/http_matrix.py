from pathlib import Path
import argparse
import http.client
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
import signal
import socket
import subprocess
import threading
import time

parser = argparse.ArgumentParser()
parser.add_argument('variant', choices=['play28', 'play29', 'play30', 'play30-scala3'])
parser.add_argument('evidence', type=Path)
parser.add_argument('--legacy-config', action='store_true')
args = parser.parse_args()
root = Path(__file__).resolve().parent
out = args.evidence; out.mkdir(parents=True, exist_ok=True)
receipt = {'variant': args.variant, 'legacyConfig': args.legacy_config, 'requests': [], 'downstream': []}
entered = threading.Event(); release = threading.Event(); finished = threading.Event()

class Downstream(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def setup(self):
        super().setup()
        self.connection.settimeout(3)
    def log_message(self, *args): pass
    def do_GET(self):
        record = {'path': self.path, 'thread': threading.current_thread().name}
        receipt['downstream'].append(record)
        try:
            if self.path == '/slow':
                entered.set()
                if not release.wait(5): raise TimeoutError('downstream fixture gate timeout')
            body = b'complete-loopback-body'
            self.send_response(200); self.send_header('Content-Length', str(len(body)))
            self.send_header('Connection', 'close'); self.end_headers()
            self.wfile.write(body[:8]); self.wfile.flush()
            self.wfile.write(body[8:]); self.wfile.flush()
            record['written'] = len(body)
        except (BrokenPipeError, ConnectionResetError) as error:
            record['disconnect'] = type(error).__name__
        except BaseException as error:
            record['failure'] = repr(error)
        finally:
            record['finished'] = True
            if self.path == '/slow': finished.set()

server = None; server_thread = None; process = None; log = None
failures = []
port = None

def request(path, method='GET', body=None, headers=None):
    connection = http.client.HTTPConnection('127.0.0.1', port, timeout=5)
    try:
        connection.request(method, path, body, headers or {})
        response = connection.getresponse()
        raw = response.read()
        result = {'path': path, 'method': method, 'status': response.status,
                  'headers': dict(response.getheaders()), 'body': raw.decode()}
        receipt['requests'].append(result)
        return result
    finally: connection.close()

def check_json(path, code, value, method='GET', body=None, headers=None):
    result = request(path, method, body, headers)
    assert result['status'] == code, result
    assert json.loads(result['body']) == value, result
    return result

try:
    server = ThreadingHTTPServer(('127.0.0.1', 0), Downstream)
    server_thread = threading.Thread(target=lambda: server.serve_forever(poll_interval=0.05), name='migration-downstream')
    server_thread.start()
    with socket.socket() as reserve:
        reserve.bind(('127.0.0.1', 0)); port = reserve.getsockname()[1]
    command = ['bash', str(root/args.variant/'target/universal/stage/bin'/args.variant),
               '-Dhttp.address=127.0.0.1', f'-Dhttp.port={port}', '-Dpidfile.path=/dev/null',
               f'-Dlab.downstream=http://127.0.0.1:{server.server_port}']
    if args.variant == 'play28': command.append('-J--add-opens=java.base/java.lang=ALL-UNNAMED')
    if args.legacy_config:
        config = (root/args.variant/'conf/application.conf').read_text()
        config = config.replace('play.server.pekko.server-header="migration-server"',
                                'play.server.pekko.server-header=null\nplay.server.akka.server-header="legacy-only"')
        negative = out/'legacy.conf'; negative.write_text(config)
        command.append('-Dconfig.file='+str(negative.resolve()))
    receipt['command'] = command
    env = dict(os.environ)
    if not env.get('JAVA_HOME'): raise RuntimeError('Set JAVA_HOME to the JDK 21 installation')
    log = (out/'server.log').open('w')
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
    deadline = time.monotonic()+45
    while True:
        if process.poll() is not None: raise RuntimeError('stage exited during startup')
        try:
            result = request('/runtime')
            if result['status'] == 200: break
        except (ConnectionError, OSError): pass
        if time.monotonic() >= deadline: raise TimeoutError('stage startup timeout')
        time.sleep(0.1)
    runtime = json.loads(result['body']); receipt['runtime'] = runtime
    provider = 'PekkoHttpServerProvider' if args.variant.startswith('play30') else 'AkkaHttpServerProvider'
    assert runtime['provider'] == 'play.core.server.'+provider, runtime
    assert runtime['actorSystemClass'].startswith('org.apache.pekko.' if args.variant.startswith('play30') else 'akka.'), runtime
    if args.legacy_config:
        assert runtime['legacyHeader'] == 'legacy-only' and runtime['configuredHeader'] == '<unset>', runtime
        assert 'Server' not in result['headers'], result
    else:
        assert result['headers'].get('Server') == 'migration-server', result
    check_json('/good', 200, {'value':'same-contract'})
    check_json('/missing', 404, {'error':'client-404'})
    check_json('/echo', 200, {'value':'fixed-input'}, 'POST', '{"value":"fixed-input"}', {'Content-Type':'application/json'})
    check_json('/echo', 400, {'error':'invalid-value'}, 'POST', '{}', {'Content-Type':'application/json'})
    check_json('/echo', 400, {'error':'client-400'}, 'POST', '{broken', {'Content-Type':'application/json'})
    asynchronous = check_json('/async', 200, {'value':'async-ok'})
    assert 'actor.default-dispatcher' in asynchronous['headers'].get('X-Async-Thread',''), asynchronous
    check_json('/failed', 500, {'error':'server-failure'})
    check_json('/ws', 200, {'status':200, 'body':'complete-loopback-body'})
    check_json('/timeout', 504, {'error':'upstream-timeout'})
    assert entered.is_set() and not finished.is_set(), 'timeout must precede downstream release'
    receipt['timeoutBeforeDownstreamRelease'] = True
    release.set(); assert finished.wait(5), 'downstream did not finish'
    known = request('/known'); unknown = request('/unknown')
    for stream in (known, unknown): assert stream['status'] == 200 and stream['body'] == 'part-two', stream
    assert known['headers'].get('Content-Length') == '8' and 'Transfer-Encoding' not in known['headers'], known
    assert unknown['headers'].get('Transfer-Encoding') == 'chunked' and 'Content-Length' not in unknown['headers'], unknown
    first = request('/session/set'); cookie = first['headers']['Set-Cookie'].split(';',1)[0]
    check_json('/session/read', 200, {'marker':'same-session'}, headers={'Cookie':cookie})
    check_json('/session/read', 200, {'marker':'absent'})
    with socket.create_connection(('127.0.0.1', port), timeout=3) as stream_socket:
        stream_socket.sendall(b'GET /cancel HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n')
        received = b''
        while b'tick\n' not in received:
            chunk = stream_socket.recv(4096)
            if not chunk: raise AssertionError('stream ended before a tick')
            received += chunk
        receipt['cancelInitialBytes'] = received.decode()
    deadline = time.monotonic()+5
    while True:
        state = json.loads(request('/runtime')['body'])
        if state['streamTerminated'] == 1: break
        if time.monotonic() >= deadline: raise TimeoutError('stream cancellation not observed')
        time.sleep(0.05)
    receipt['cancelObserved'] = True
    receipt['matrixPassed'] = True
except BaseException as error:
    failures.append(error); receipt['failure'] = repr(error)
finally:
    release.set()
    if process is not None:
        try:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGTERM)
                try: process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL); process.wait(timeout=5)
                    raise RuntimeError('stage required forced kill')
            receipt['processTerminated'] = process.poll() is not None
            receipt['exitCode'] = process.returncode
        except BaseException as error: failures.append(error)
    if log is not None: log.close()
    if server is not None:
        try: server.shutdown(); server.server_close()
        except BaseException as error: failures.append(error)
    if server_thread is not None:
        server_thread.join(5)
        receipt['downstreamThreadTerminated'] = not server_thread.is_alive()
        if server_thread.is_alive(): failures.append(RuntimeError('downstream thread leaked'))
    if port is not None:
        with socket.socket() as probe:
            probe.settimeout(1); receipt['listenerClosed'] = probe.connect_ex(('127.0.0.1',port)) != 0
        if not receipt['listenerClosed']: failures.append(RuntimeError('stage listener leaked'))
    receipt['allHandlersFinished'] = all(record.get('finished') for record in receipt['downstream'])
    if not receipt['allHandlersFinished']: failures.append(RuntimeError('downstream handler leaked'))
    receipt['cleanupFailures'] = [repr(error) for error in failures]
    (out/'observations.json').write_text(json.dumps(receipt,indent=2)+'\n')
if failures: raise BaseExceptionGroup('migration HTTP matrix failed', failures)
print('HTTP_MATRIX_PASS', args.variant, 'requests', len(receipt['requests']), 'process/handler/listener terminated')
