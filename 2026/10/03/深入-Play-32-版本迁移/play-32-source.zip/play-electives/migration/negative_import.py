from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path(__file__).resolve().parent
evidence = Path(sys.argv[1]); evidence.mkdir(parents=True, exist_ok=True)
source = root/'play30/app/controllers/MigrationController.java'
original = source.read_bytes()
bad = original.replace(b'import org.apache.pekko.util.ByteString;', b'import akka.util.ByteString;')
assert bad != original
(evidence/'legacy-import.java').write_bytes(bad)
try:
    source.write_bytes(bad)
    process = subprocess.run([sys.executable, str(root/'run_build.py'), 'play30',
                              str(evidence/'compile-failure.log'), 'clean', 'compile'], timeout=450)
    output = (evidence/'compile-failure.log').read_text()
    assert process.returncode == 1 and 'akka.util' in output and 'javac returned non-zero' in output, output[-3000:]
    result = {'expectedCompileFailure': True, 'exitCode': process.returncode}
finally:
    source.write_bytes(original)
    assert source.read_bytes() == original
result['restoredSha256'] = hashlib.sha256(original).hexdigest()
(evidence/'observations.json').write_text(json.dumps(result,indent=2)+'\n')
print('LEGACY_IMPORT_REJECTED_AND_RESTORED', result['restoredSha256'])
