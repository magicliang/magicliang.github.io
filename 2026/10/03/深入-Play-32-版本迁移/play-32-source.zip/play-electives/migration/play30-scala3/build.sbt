ThisBuild / scalaVersion := "3.3.4"
ThisBuild / organization := "example.playmigration"
ThisBuild / version := "0.1.0"
lazy val root = (project in file(".")).enablePlugins(PlayJava).settings(
  name := "play30-scala3",
  libraryDependencies ++= Seq(guice, javaWs, "junit" % "junit" % "4.13.2" % Test,
    "com.github.sbt" % "junit-interface" % "0.13.3" % Test),
  Test / parallelExecution := false
)
