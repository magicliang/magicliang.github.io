# Play migration contract laboratory

Four independent Java applications hold a finite HTTP contract constant:

| Directory | Play | Scala | Framework group | Server |
| --- | --- | --- | --- | --- |
| play28 | 2.8.22 | 2.13.15 | com.typesafe.play | Akka HTTP |
| play29 | 2.9.6 | 2.13.15 | com.typesafe.play | Akka HTTP |
| play30 | 3.0.6 | 2.13.15 | org.playframework | Pekko HTTP |
| play30-scala3 | 3.0.6 | 3.3.4 | org.playframework | Pekko HTTP |

Prerequisites: Python 3.11+, JDK 21, sbt launcher 1.10.7. Set `JAVA_HOME` and `PLAY_LAB_SBT_LAUNCHER` to local installations. The scripts use only loopback listeners and close their own server processes. No database is used.

From this directory, for each variant:

```bash
python3 run_build.py play28 evidence/play28/final-build.log clean test stage 'show Compile / dependencyClasspath'
python3 http_matrix.py play28 evidence/play28/final-http
python3 run_build.py play29 evidence/play29/final-build.log clean test stage 'show Compile / dependencyClasspath'
python3 http_matrix.py play29 evidence/play29/final-http
python3 run_build.py play30 evidence/play30/final-build.log clean test stage 'show Compile / dependencyClasspath'
python3 http_matrix.py play30 evidence/play30/final-http
python3 run_build.py play30-scala3 evidence/play30-scala3/final-build.log clean test stage 'show Compile / dependencyClasspath'
python3 http_matrix.py play30-scala3 evidence/play30-scala3/final-http
```

Each application has two JUnit tests. The real staged process matrix verifies valid/invalid/malformed JSON, 404, asynchronous success and failure, a full WS body, gated downstream timeout, known and unknown stream lengths, cancellation observed by the server, session set/read, runtime server identity and terminated resources. The request total varies because readiness/cancellation polls are recorded. Filters are disabled solely to isolate these contracts; this is not a production security configuration.

The Play 2.8.22 fixture is a bounded compatibility experiment on JDK 21, **not a supported JDK declaration**. Its source supports Java 8/11 and experimentally 17. Guice 4 needs the narrow `java.base/java.lang` opening here, applied separately to sbt JVM, test JVM and stage JVM. Its meta-build alone declares the selected scala-xml artifact compatible, allowing the sbt 1.10.7-selected 2.3.0 to coexist with older plugin requirements. This declaration is not a general binary compatibility proof.

Negative scenarios mutate only this lab and restore the application source in `finally`:

```bash
python3 negative_import.py evidence/play30/final-negative-import
python3 run_build.py play30 evidence/play30/final-build.log clean test stage 'show Compile / dependencyClasspath'
python3 http_matrix.py play30 evidence/play30/final-http
python3 http_matrix.py play30 evidence/play30/final-legacy-config --legacy-config
python3 collect_evidence.py evidence
```

The old Akka import must fail compilation. The old server configuration key remains readable in HOCON but does not configure the Pekko server header. The negative HTTP matrix verifies both values and the actual response headers. `collect_evidence.py` validates raw logs, test XML, resolved/staged artifact hashes, application class byte identity, server type, network outcomes and resource termination before writing a manifest. Keep first-failure logs alongside final evidence.

The `research` directory and initial attempts belong to the isolated evidence archive; source commit identities are embedded in the collector. `create_projects.py` is the initial deterministic scaffold, and can overwrite the four lab projects; do not invoke it on local modifications. The scaffold is not needed for rerunning the checked-in applications.
