package models;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "orm_entry")
public class Entry {
    @Id
    public String id;
    public String label;

    public Entry() {
    }

    public Entry(String id, String label) {
        this.id = id;
        this.label = label;
    }
}
