from pathlib import Path
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET

here = Path(__file__).resolve().parent
repo = here.parents[4]
draft = here / 'draft.md'
content = draft.read_text()
source = Path('/private/tmp/play-orm-work-20261003')
evidence = repo / '.omo/evidence/play-orm-20261003'
java = Path('/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn/bin/javac')
blocks = re.findall(r'```java\n(.*?)\n```', content, re.S)
assert len(blocks) == 3, len(blocks)
for block in blocks:
    package = re.search(r'package ([\w.]+);', block)[1]
    name = re.search(r'public (?:final )?class (\w+)', block)[1]
    dest = here / 'java' / Path(package.replace('.', '/')) / (name + '.java')
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(block + '\n')
    print('EXTRACT', name, hashlib.sha256(dest.read_bytes()).hexdigest(), flush=True)
for kind, display in [('ebean', 'EbeanWrite'), ('hibernate', 'JpaWrite')]:
    classes = here / 'classes' / kind
    classes.mkdir(parents=True, exist_ok=True)
    command = [str(java), '--release', '21', '-Xlint:all', '-cp',
               str(source / kind / 'target/universal/stage/lib/*'), '-d', str(classes),
               str(here / 'java/models/Entry.java'), str(here / f'java/examples/{display}.java')]
    print('COMMAND', json.dumps(command), flush=True)
    subprocess.run(command, check=True, timeout=30)
    assert (classes / f'examples/{display}.class').is_file()
    print('DISPLAY_COMPILE_PASS', kind, flush=True)
    observation = json.loads((evidence / kind / 'observations.json').read_text())
    normal = observation[kind]
    interrupted = observation[kind + '-interrupted']
    expected = {'committedRows': 1, 'rolledBackRows': 0, 'stageDoneAfterActionReturns': False,
                'earlyRowsBeforeRelease': 1, 'earlyRowsAfterStageFailure': 1,
                'lateRowsAfterStageFailure': int(kind == 'ebean'), 'correctRowsBeforeRelease': 0,
                'correctRowsAfterCompletion': 1, 'workerTerminated': True}
    for key, value in expected.items():
        assert normal[key] == value, (kind, key)
    assert interrupted['primaryFailure'] == 'InterruptedException'
    assert interrupted['callerInterrupted'] is True
    assert interrupted['experiment']['workerTerminated'] is True
    junit = ET.parse(evidence / kind / 'TEST-OrmTest.xml').getroot()
    assert junit.attrib['tests'] == '2' and junit.attrib['failures'] == '0' and junit.attrib['errors'] == '0'
    http = json.loads((evidence / kind / 'http-observations.json').read_text())
    assert len(http['requests']) == 2
    assert all(r['status'] == 200 and r['body']['workerTerminated'] for r in http['requests'])
    assert http['processTerminated'] and http['listenerClosed']
    print('ARCHIVED_OBSERVATION_CONSISTENCY_PASS', kind, '2 JUnit + 2 HTTP; not a rerun', flush=True)
assert '/Users/' not in content and '/private/tmp/' not in content
assert content.count('```mermaid') == 2
print('DRAFT_SHA256', hashlib.sha256(draft.read_bytes()).hexdigest(), flush=True)
