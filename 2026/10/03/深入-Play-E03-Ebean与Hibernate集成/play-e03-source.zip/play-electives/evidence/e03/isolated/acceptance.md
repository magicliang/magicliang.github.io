# E03 isolated ORM acceptance

Two independent Play Java projects are ready for parent integration:

- /private/tmp/play-orm-work-20261003/ebean → examples/play-electives/e03-ebean
- /private/tmp/play-orm-work-20261003/hibernate → examples/play-electives/e03-hibernate

No shared application source, article or Git state was edited. The parent's PostgreSQL container play-db-lab-20261003-pipeline-43 remains running. Only e03_ebean_b83f and e03_hibernate_b83f schemas were created; both tables are empty after validation. Schemas are retained for parent reruns. database-final-state.log reports no remaining e03_* application connections.

## Reproduction and artifacts

All sbt invocations used JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn, PLAY_LAB_SBT_LAUNCHER=/private/tmp/play-series-tools/sbt-launch-1.10.7.jar and PLAY_LAB_JVM_ARGS='-Dsbt.override.build.repos=true -Dsbt.repository.config=/private/tmp/play-orm-work-20261003/repositories'.

| Claim / scenario | Actual invocation, from each project unless specified | Binary observable | Artifact |
| --- | --- | --- | --- |
| Actual dependency convergence | bash ./sbtw update 'show Compile / dependencyClasspath' dependencyTree | Framework core resolves 3.0.6, no surviving core 3.0.2; Ebean 15.1.0 / Hibernate 6.6.3.Final | each dependencies.log and dependency-verification.json |
| Final compilation, real PG tests and production packaging | bash ./sbtw clean test stage | Exit 0; each 2 passed, 0 failed/errors; stage success | each test-stage-verified.log, TEST-OrmTest.xml, stage-verification.json |
| Entity bytecode | JDK21 javap -p -classpath target/scala-2.13/classes models.Entry | Ebean implements EntityBean and has _ebean_intercept; Hibernate baseline is plain; staged class hash equals inspected output | each javap-final.txt and stage-verification.json |
| Ebean wrong enhancement package | bash ./sbtw 'set Compile / playEbeanModels := Seq("wrong.models.*")' clean compile | Exit 0 but javap contains no EntityBean | ebean/wrong-model-compile.log, javap-wrong-package.txt |
| Wrong-package startup | bash ./sbtw 'set Compile / playEbeanModels := Seq("wrong.models.*")' 'testOnly OrmTest' | Exit 1, real BeanNotEnhancedException during application startup | ebean/wrong-model-startup.log, wrong-model-TEST-OrmTest.xml |
| Production HTTP, two runs per project | python3 /private/tmp/play-orm-work-20261003/verify_http.py KIND /Users/magicliang/Desktop/Programming/git/hexo-blog/.omo/evidence/play-orm-20261003/KIND | Two HTTP 200 responses with complete matrix; process terminates without forced kill, listener closes | each http-server.log, http-verification.log, http-observations.json |
| Actual SQL | podman logs filtered to backend PIDs containing self-owned e03 identifiers | INSERT with bound run IDs, BEGIN, ROLLBACK, COMMIT and independent SELECT/DELETE are present | postgres-raw-sql.log |
| Finite resources and interruption | OrmTest.interruptedWaitPreservesFailureAndCleansWorkers in final test command | Primary InterruptedException and interrupt bit survive; worker terminates; only own rows removed | each observations.json and TEST-OrmTest.xml |

The negative enhancement override was scoped to temporary sbt sessions. Final clean test stage used the ordinary build, and final javap plus staged class hashes prove enhancement was restored. Attempt-1 failures are retained: Ebean wrapped the synthetic rollback in PersistenceException, and Hibernate required an explicit Consumer lambda for its overloaded transaction API. Attempt-2 passed; final tests additionally assert exact late-stage failure classes.

## Real observations

Both ORMs committed the successful row and rolled back the deliberate synchronous failure. Independent JDBC reads observed one and zero rows respectively; SQL logs recorded the corresponding transaction boundaries.

Ebean executes the actual Play TransactionalAction against a delegate returning a gated CompletionStage. Immediately after call returns, the stage is pending, the calling thread's current transaction is absent, and the early row is visible. The late worker has no current transaction; its independent save commits before its deliberate IllegalArgumentException makes the stage fail. Both early and late rows remain visible after that failed stage.

Hibernate uses the injected Play JPAApi.withTransaction. Returning the gated future commits the early row and closes the captured EntityManager. The late worker observes isOpen=false; persist fails with IllegalStateException, the early row remains visible, and no late row exists. This is a deliberate closed-manager counterexample, not a recommended cross-thread EntityManager pattern.

The correct alternative executes the entire synchronous transaction on e03-orm-worker. With the transaction paused after INSERT/flush, an independent JDBC connection sees zero rows. Releasing the gate lets the transaction commit; the completed task returns committed and the independent reader sees one row. Coordinator interruption is separately tested at its Future wait. Cleanup releases the fixture gate, awaits the worker, removes only the run's rows and restores the coordinator's interrupt. This does not claim interruption rolls back already-running database work.

## Version and source boundaries

Framework core artifacts resolve to Play 3.0.6. Independently versioned play-json/play-functional resolve to 3.0.4 and play-ebean to 8.3.0. No forced dependency overrides were introduced. Hibernate Validator remains 6.2.5.Final; the actual jakarta.validation-api:2.0.2 jar contains javax.validation classes. Hibernate's persistence unit explicitly sets validation-mode NONE; these tests do not claim entity Bean Validation.

The official Play Ebean source at a1b849ee530990edb6585ebbaa934f4c3e4dd03f declares Play 3.0.2 and Ebean 15.1.0 defaults in project/Dependencies.scala. The experiment confirms final framework convergence rather than inferring it from that declared compatibility.

source-lines.txt records exact local source lines and file hashes for PlayEbean's swallowed NonFatal enhancement branch, TransactionalAction's DB.executeCall wrapper, and Play 3.0.6 DefaultJPAApi's block/commit/finally-close sequence. ebean/source-scope.txt follows the actual Ebean 15.1.0 official source jar through DefaultServer.executeCall → ScopedTransaction.complete → ScopeTrans.complete/commitTransaction and scope removal. Source jar SHA-256 is in manifest.json.

Ebean enhancement is enabled by the plugin. The Hibernate project deliberately does not configure the optional Hibernate bytecode enhancer, so its plain entity is a measured baseline, not a claim that Hibernate never supports enhancement.

The final manifest lists 29 exact project source/config paths and hashes plus the HTTP harness and repository configuration. The harness currently expects sibling ebean/hibernate directories; adapt those two directory names when integrating the requested e03-prefixed destinations. No shared-main-series or article completion is asserted by this independent slice.
