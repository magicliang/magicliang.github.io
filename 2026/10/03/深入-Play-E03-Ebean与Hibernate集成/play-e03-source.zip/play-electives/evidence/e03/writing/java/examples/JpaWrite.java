package examples;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executor;
import models.Entry;
import play.db.jpa.JPAApi;

public final class JpaWrite {
    private JpaWrite() {
    }

    public static CompletionStage<String> save(
            JPAApi jpa, Executor databaseExecutor, String id) {
        return CompletableFuture.supplyAsync(() -> jpa.withTransaction(em -> {
            em.persist(new Entry(id, "complete transaction on worker"));
            return id;
        }), databaseExecutor);
    }
}
