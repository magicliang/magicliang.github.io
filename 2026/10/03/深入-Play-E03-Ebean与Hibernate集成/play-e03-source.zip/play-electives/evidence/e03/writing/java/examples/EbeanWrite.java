package examples;

import io.ebean.DB;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executor;
import models.Entry;

public final class EbeanWrite {
    private EbeanWrite() {
    }

    public static CompletionStage<String> save(Executor databaseExecutor, String id) {
        return CompletableFuture.supplyAsync(() -> DB.executeCall(() -> {
            DB.save(new Entry(id, "complete transaction on worker"));
            return id;
        }), databaseExecutor);
    }
}
