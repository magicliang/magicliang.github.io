# E03 writing delivery

Only the E03 Markdown, companion cover.svg and this writing evidence directory were authored. No source project, database fixture, Git state or other article was changed.

| Scenario | Actual invocation / observable | Artifact |
| --- | --- | --- |
| Ordered prose scan | anti-ai-tone then anti-persona-fabrication on draft SHA 3050ae62427b791bfa9ef60b662ebd99e2d418d6e8933c2c8a98c92c53c75625, before publication | 01-anti-ai-tone.md, 02-anti-persona-fabrication.md |
| Supplementary checker | check_prose.py --profile tech --json draft.md: 0 errors / 0 warnings | prose-auxiliary.json |
| Full display Java classes | javac --release 21 -Xlint:all, separately against each isolated stage classpath: exit 0 | compile-and-evidence.log, java/, classes/ |
| Claims versus archived raw observations | verify_writing.py re-read exact JUnit, HTTP and interruption JSON; each expected field asserted | compile-and-evidence.log |
| Publication equality | source article byte-for-byte equals scanned draft | verification-receipt.txt |
| Cover | XML parses with viewBox 0 0 1600 960 and accessible title/description; all three comparison columns and correct-worker row visually inspected | cover-browser.png, verification-receipt.txt |

The archived experiment result is isolated: two real-PG JUnit tests and two production-stage HTTP requests per application. The writing checks do not rerun PostgreSQL tests or claim shared integration. Those source results remain in .omo/evidence/play-orm-20261003 until parent integration copies them to examples/play-electives/evidence/e03/isolated.

Rendering caveat: QuickLook first failed under sandbox; an escalated retry produced a cropped square thumbnail, unsuitable as full-cover proof. A separate temporary Chrome profile produced the full 1600×960 cover screenshot; the command did not terminate within its 40-second bound and subprocess.run killed it. A subsequent process listing found no remaining process referencing this profile. The temporary profile was removed. This screenshot supports only local SVG visual inspection, not a successful browser lifecycle or generated-site CUA acceptance. Parent owns the final CUA check and requested no further headless runs.

No future ORM zip, E02 or E04 hyperlink was fabricated. The source-00 link is retained. Three compiled Java blocks, two mechanism Mermaid diagrams and two explicitly unrun exercises are present. Full schema/test/stage/curl commands use repository paths and public environment variable names.
