import static org.junit.Assert.*;
import com.fasterxml.jackson.databind.JsonNode;
import lab.OrmLab;
import org.junit.Test;
import play.Application;
import play.inject.guice.GuiceApplicationBuilder;
import play.test.WithApplication;

public class OrmTest extends WithApplication {
    @Override protected Application provideApplication() { return new GuiceApplicationBuilder().build(); }
    @Test public void realPostgresTransactionsAndAsyncBoundaries() {
        JsonNode out = app.injector().instanceOf(OrmLab.class).run();
        System.out.println("ORM ebean " + out);
        assertEquals(true, out.path("entityEnhanced").asBoolean());
        assertEquals(1, out.path("committedRows").asLong());
        assertEquals(0, out.path("rolledBackRows").asLong());
        assertEquals("PersistenceException", out.path("rollbackFailure").asText());
        assertEquals("IllegalArgumentException", out.path("rollbackCause").asText());
        assertTrue(out.path("transactionActiveInsideDelegate").asBoolean());
        assertFalse(out.path("stageDoneAfterActionReturns").asBoolean());
        assertEquals(1, out.path("earlyRowsBeforeRelease").asLong());
        assertEquals("failed", out.path("lateStageOutcome").asText());
        assertEquals("IllegalArgumentException", out.path("lateStageFailure").asText());
        assertEquals(1, out.path("earlyRowsAfterStageFailure").asLong());
        assertEquals(1, out.path("lateRowsAfterStageFailure").asLong());
        assertFalse(out.path("transactionActiveOnLateThread").asBoolean());
        assertEquals("e03-orm-worker", out.path("lateThread").asText());
        assertEquals("e03-orm-worker", out.path("correctThread").asText());
        assertTrue(out.path("correctTransactionActive").asBoolean());
        assertEquals(0, out.path("correctRowsBeforeRelease").asLong());
        assertEquals(1, out.path("correctRowsAfterCompletion").asLong());
        assertEquals("committed", out.path("correctOutcome").asText());
        assertTrue(out.path("workerTerminated").asBoolean());
        assertEquals(4, out.path("ownRowsRemoved").asInt());
    }
    @Test public void interruptedWaitPreservesFailureAndCleansWorkers() throws Exception {
        OrmLab lab = app.injector().instanceOf(OrmLab.class);
        var future = new java.util.concurrent.FutureTask<>(lab::interruptedRun);
        Thread coordinator = Thread.ofPlatform().name("e03-interrupted-coordinator").start(future);
        JsonNode out = future.get(20, java.util.concurrent.TimeUnit.SECONDS);
        coordinator.join(5000);
        System.out.println("ORM ebean-interrupted " + out);
        assertFalse(coordinator.isAlive());
        assertEquals("InterruptedException", out.path("primaryFailure").asText());
        assertTrue(out.path("callerInterrupted").asBoolean());
        assertTrue(out.path("experiment").path("interruptRestored").asBoolean());
        assertTrue(out.path("experiment").path("workerTerminated").asBoolean());
        assertTrue(out.path("experiment").path("ownRowsRemoved").asInt() >= 3);
    }
}
