package lab;

import com.fasterxml.jackson.databind.node.ObjectNode;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.*;
import play.db.Database;
import play.libs.Json;

final class Experiment implements AutoCloseable {
    final Database database;
    final String prefix = "e03-" + UUID.randomUUID() + "-";
    final ExecutorService worker = Executors.newSingleThreadExecutor(Thread.ofPlatform().name("e03-orm-worker").factory());
    final List<CountDownLatch> gates = new ArrayList<>();
    final ObjectNode out = Json.newObject().put("runPrefix", prefix).put("driverThread", Thread.currentThread().getName());
    Experiment(Database database) { this.database = database; }
    CountDownLatch gate() { var gate = new CountDownLatch(1); gates.add(gate); return gate; }
    static void await(CountDownLatch gate) {
        try { if (!gate.await(5, TimeUnit.SECONDS)) throw new IllegalStateException("gate timeout"); }
        catch (InterruptedException failure) { Thread.currentThread().interrupt(); throw new IllegalStateException(failure); }
    }
    static <T> T get(Future<T> future) {
        try { return future.get(5, TimeUnit.SECONDS); }
        catch (InterruptedException failure) { Thread.currentThread().interrupt(); throw new IllegalStateException(failure); }
        catch (ExecutionException | TimeoutException failure) { throw new IllegalStateException(failure); }
    }
    long count(String suffix) {
        try (Connection connection = database.getConnection();
             var statement = connection.prepareStatement("select count(*) from orm_entry where id = ?")) {
            statement.setString(1, prefix + suffix);
            try (var rows = statement.executeQuery()) { rows.next(); return rows.getLong(1); }
        } catch (Exception failure) { throw new IllegalStateException(failure); }
    }
    @Override public void close() throws Exception {
        boolean interrupted = Thread.interrupted();
        Exception first = null;
        gates.forEach(CountDownLatch::countDown);
        worker.shutdown();
        try {
            if (!worker.awaitTermination(5, TimeUnit.SECONDS)) {
                worker.shutdownNow();
                if (!worker.awaitTermination(5, TimeUnit.SECONDS)) throw new IllegalStateException("worker shutdown timeout");
            }
        } catch (Exception failure) { first = failure; worker.shutdownNow(); }
        finally { interrupted |= Thread.interrupted(); }
        try (var connection = database.getConnection();
             var statement = connection.prepareStatement("delete from orm_entry where id like ?")) {
            statement.setString(1, prefix + "%");
            out.put("ownRowsRemoved", statement.executeUpdate());
        } catch (Exception failure) {
            if (first == null) first = failure; else first.addSuppressed(failure);
        } finally {
            out.put("workerTerminated", worker.isTerminated());
            if (interrupted) Thread.currentThread().interrupt();
            out.put("interruptRestored", Thread.currentThread().isInterrupted());
        }
        if (first != null) throw first;
    }
}
