package controllers;

import jakarta.inject.Inject;
import lab.OrmLab;
import play.mvc.Controller;
import play.mvc.Result;

public final class OrmController extends Controller {
    private final OrmLab lab;
    @Inject public OrmController(OrmLab lab) { this.lab = lab; }
    public Result run() { return ok(lab.run()); }
}
