package lab;

import static lab.Experiment.*;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.ebean.DB;
import jakarta.inject.Inject;
import java.util.concurrent.*;
import models.Entry;
import play.db.DBApi;
import play.db.ebean.TransactionalAction;
import play.libs.Json;
import play.mvc.*;

public final class OrmLab {
    private final play.db.Database database;
    @Inject public OrmLab(DBApi api) { database = api.getDatabase("default"); }
    public ObjectNode run() { return run(false, Json.newObject()); }
    public ObjectNode interruptedRun() {
        ObjectNode receipt = Json.newObject();
        try { run(true, receipt); throw new AssertionError("expected interruption"); }
        catch (IllegalStateException failure) {
            return receipt.put("primaryFailure", failure.getCause().getClass().getSimpleName())
                    .put("callerInterrupted", Thread.currentThread().isInterrupted());
        }
    }
    private ObjectNode run(boolean interrupt, ObjectNode receipt) {
        Experiment e = new Experiment(database);
        receipt.set("experiment", e.out);
        try (e) {
            e.out.put("entityEnhanced", java.util.Arrays.stream(Entry.class.getInterfaces())
                    .anyMatch(type -> type.getName().equals("io.ebean.bean.EntityBean")));
            DB.execute(() -> DB.save(new Entry(e.prefix + "committed", "success")));
            e.out.put("committedRows", e.count("committed"));
            try {
                DB.execute(() -> {
                    DB.save(new Entry(e.prefix + "rolled-back", "rollback"));
                    throw new IllegalArgumentException("synthetic rollback");
                });
            } catch (jakarta.persistence.PersistenceException expected) {
                if (!(expected.getCause() instanceof IllegalArgumentException)) throw expected;
                e.out.put("rollbackFailure", expected.getClass().getSimpleName())
                        .put("rollbackCause", expected.getCause().getClass().getSimpleName());
            }
            e.out.put("rolledBackRows", e.count("rolled-back"));
            var lateRelease = e.gate();
            TransactionalAction action = new TransactionalAction();
            action.delegate = new Action.Simple() {
                @Override public CompletionStage<Result> call(Http.Request request) {
                    e.out.put("transactionActiveInsideDelegate", DB.currentTransaction() != null);
                    DB.save(new Entry(e.prefix + "early", "before pending stage"));
                    return CompletableFuture.supplyAsync(() -> {
                        await(lateRelease);
                        e.out.put("lateThread", Thread.currentThread().getName())
                                .put("transactionActiveOnLateThread", DB.currentTransaction() != null);
                        DB.save(new Entry(e.prefix + "late", "autocommit after action"));
                        throw new IllegalArgumentException("late stage failure");
                    }, e.worker);
                }
            };
            CompletionStage<Result> pending = action.call(new Http.RequestBuilder().build());
            e.out.put("stageDoneAfterActionReturns", pending.toCompletableFuture().isDone())
                    .put("transactionActiveAfterActionReturns", DB.currentTransaction() != null)
                    .put("earlyRowsBeforeRelease", e.count("early"));
            lateRelease.countDown();
            String lateOutcome = get(pending.handle((value, error) -> {
                if (error != null) e.out.put("lateStageFailure", error.getCause().getClass().getSimpleName());
                return error == null ? "success" : "failed";
            }).toCompletableFuture());
            e.out.put("lateStageOutcome", lateOutcome)
                    .put("earlyRowsAfterStageFailure", e.count("early")).put("lateRowsAfterStageFailure", e.count("late"));
            var entered = e.gate(); var release = e.gate();
            Future<String> correct = e.worker.submit(() -> DB.executeCall(() -> {
                e.out.put("correctThread", Thread.currentThread().getName())
                        .put("correctTransactionActive", DB.currentTransaction() != null);
                DB.save(new Entry(e.prefix + "correct", "complete synchronous transaction"));
                entered.countDown(); await(release); return "committed";
            }));
            await(entered);
            e.out.put("correctRowsBeforeRelease", e.count("correct"));
            if (interrupt) Thread.currentThread().interrupt();
            else release.countDown();
            e.out.put("correctOutcome", get(correct)).put("correctRowsAfterCompletion", e.count("correct"));
        } catch (RuntimeException failure) { throw failure; }
        catch (Exception failure) { throw new IllegalStateException(failure); }
        return e.out;
    }
}
