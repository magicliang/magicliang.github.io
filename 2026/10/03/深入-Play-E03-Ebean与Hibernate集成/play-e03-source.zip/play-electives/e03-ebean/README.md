# E03 ebean isolated lab

Pinned: Play 3.0.6, sbt 1.10.7, Scala 2.13.15, JDK 21, PostgreSQL JDBC 42.7.5; Play Ebean plugin 8.3.0 and Ebean 15.1.0. Play JSON/functional resolve separately to 3.0.4; no dependency overrides are applied. Play form validation remains javax.validation. Hibernate entity validation is explicitly NONE.

Prepare only the lab-owned schema using prepare_schema.sql against PostgreSQL. The provided configuration uses the parent's existing local fixture on 127.0.0.1:35711/play_lab and synthetic postgres/lab-only-password credentials; change the URL/credentials for another local fixture. Never remove the shared fixture.

Run from this directory:

```bash
export JAVA_HOME=/path/to/jdk-21
mkdir -p .tools
curl -fL https://repo.maven.apache.org/maven2/org/scala-sbt/sbt-launch/1.10.7/sbt-launch-1.10.7.jar -o .tools/sbt-launch-1.10.7.jar
bash ./sbtw clean test stage
python3 ../lab/orm_checks.py ebean ../evidence/e03/ebean-replay
```

Launcher SHA256: 3cca02818047327a83efde776103a1ef92f76f72c062badbbb062499a3270c07. PLAY_LAB_SBT_LAUNCHER may select an existing verified launcher. Override the full JDBC URL, including currentSchema, with -Ddb.default.url when building/testing and E03_JDBC_URL when running orm_checks.py against another own local fixture.

GET /orm executes a finite diagnostic scenario and returns its observations. Each request uses a unique row prefix, bounded worker/gates, and removes its own rows. The synchronous controller coordinates experiments; it is not a production request-path design.

The pending-stage case intentionally returns before asynchronous work completes. The correct case opens and completes a synchronous transaction entirely inside a named worker. The interrupted test interrupts the coordinator at its wait and verifies failure propagation, restored interruption and worker cleanup; releasing fixture gates during cleanup lets already-running transaction work finish.

Ebean's runtime model discovery and build-time enhancement are distinct. Run the wrong-package mutation in a temporary sbt session, inspect javap, and start the app: compile exit 0 alone is insufficient. Restore with an ordinary clean test stage.
