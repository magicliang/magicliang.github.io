ThisBuild / scalaVersion := "2.13.15"
ThisBuild / organization := "example.playlab.e03"
ThisBuild / version := "0.1.0"
lazy val root = (project in file(".")).enablePlugins(PlayJava).settings(
  name := "e03-hibernate",
  libraryDependencies ++= Seq(guice, javaJdbc, javaJpa, "org.hibernate.orm" % "hibernate-core" % "6.6.3.Final",
    "org.postgresql" % "postgresql" % "42.7.5",
    "junit" % "junit" % "4.13.2" % Test, "com.github.sbt" % "junit-interface" % "0.13.3" % Test),
  Test / parallelExecution := false
)
