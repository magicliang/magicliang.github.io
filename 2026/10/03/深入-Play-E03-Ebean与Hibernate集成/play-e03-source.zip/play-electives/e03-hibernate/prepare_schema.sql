CREATE SCHEMA IF NOT EXISTS e03_hibernate_b83f;
CREATE TABLE IF NOT EXISTS e03_hibernate_b83f.orm_entry (id varchar(255) PRIMARY KEY, label varchar(255));
