package lab;

import static lab.Experiment.*;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.inject.Inject;
import java.util.concurrent.*;
import models.Entry;
import play.db.DBApi;
import play.db.jpa.JPAApi;
import play.libs.Json;

public final class OrmLab {
    private final play.db.Database database;
    private final JPAApi jpa;
    @Inject public OrmLab(DBApi api, JPAApi jpa) { database = api.getDatabase("default"); this.jpa = jpa; }
    public ObjectNode run() { return run(false, Json.newObject()); }
    public ObjectNode interruptedRun() {
        ObjectNode receipt = Json.newObject();
        try { run(true, receipt); throw new AssertionError("expected interruption"); }
        catch (IllegalStateException failure) {
            return receipt.put("primaryFailure", failure.getCause().getClass().getSimpleName())
                    .put("callerInterrupted", Thread.currentThread().isInterrupted());
        }
    }
    private ObjectNode run(boolean interrupt, ObjectNode receipt) {
        Experiment e = new Experiment(database);
        receipt.set("experiment", e.out);
        try (e) {
            e.out.put("entityEnhanced", java.util.Arrays.stream(Entry.class.getInterfaces())
                    .anyMatch(type -> type.getName().equals("org.hibernate.engine.spi.ManagedEntity")));
            jpa.withTransaction(em -> { em.persist(new Entry(e.prefix + "committed", "success")); });
            e.out.put("committedRows", e.count("committed"));
            try {
                jpa.withTransaction((java.util.function.Consumer<jakarta.persistence.EntityManager>) em -> {
                    em.persist(new Entry(e.prefix + "rolled-back", "rollback")); em.flush();
                    throw new IllegalArgumentException("synthetic rollback");
                });
            } catch (IllegalArgumentException expected) { e.out.put("rollbackFailure", expected.getClass().getSimpleName()); }
            e.out.put("rolledBackRows", e.count("rolled-back"));
            var lateRelease = e.gate();
            CompletableFuture<String> pending = jpa.withTransaction(em -> {
                e.out.put("transactionActiveInsideDelegate", em.getTransaction().isActive());
                em.persist(new Entry(e.prefix + "early", "before pending stage"));
                return CompletableFuture.supplyAsync(() -> {
                    await(lateRelease);
                    e.out.put("lateThread", Thread.currentThread().getName()).put("entityManagerOpenOnLateThread", em.isOpen());
                    em.persist(new Entry(e.prefix + "late", "closed entity manager"));
                    return "unexpected-success";
                }, e.worker);
            });
            e.out.put("stageDoneAfterActionReturns", pending.isDone()).put("earlyRowsBeforeRelease", e.count("early"));
            lateRelease.countDown();
            String lateOutcome = get(pending.handle((value, error) -> {
                if (error != null) e.out.put("lateStageFailure", error.getCause().getClass().getSimpleName());
                return error == null ? "success" : "failed";
            }));
            e.out.put("lateStageOutcome", lateOutcome)
                    .put("earlyRowsAfterStageFailure", e.count("early")).put("lateRowsAfterStageFailure", e.count("late"));
            var entered = e.gate(); var release = e.gate();
            Future<String> correct = e.worker.submit(() -> jpa.withTransaction(em -> {
                e.out.put("correctThread", Thread.currentThread().getName())
                        .put("correctTransactionActive", em.getTransaction().isActive());
                em.persist(new Entry(e.prefix + "correct", "complete synchronous transaction")); em.flush();
                entered.countDown(); await(release); return "committed";
            }));
            await(entered);
            e.out.put("correctRowsBeforeRelease", e.count("correct"));
            if (interrupt) Thread.currentThread().interrupt();
            else release.countDown();
            e.out.put("correctOutcome", get(correct)).put("correctRowsAfterCompletion", e.count("correct"));
        } catch (RuntimeException failure) { throw failure; }
        catch (Exception failure) { throw new IllegalStateException(failure); }
        return e.out;
    }
}
