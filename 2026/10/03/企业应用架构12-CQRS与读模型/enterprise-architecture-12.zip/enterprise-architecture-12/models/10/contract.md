# 10 contract

Fixed frozen27 Money/Period semantics; HTTP adapter uses reduced teaching rental projection. Claims and exact scenarios in evidence/10/RUN.md. No baseline mutation.
