# 09 real JDBC concurrency contract

Six interleavings: unprotected/optimistic money update; unprotected/optimistic interval reservation; SELECT FOR UPDATE waiting success; SELECT FOR UPDATE timeout then retry. Each uses two actual threads, each DriverManager-created connection, READ_COMMITTED/autocommit=false. CyclicBarrier ensures two reads before writes; CountDownLatch orders first commit before stale second update. SQL log includes connection/thread, version binds, affected rows and commit/rollback.

Unprotected money25+5/+7 ends32 (lost first increment); version WHERE changes affected counts1/0 and result30; new transaction rereads version1, reapplies +7 and commits37. Optimistic conflict has no SQLException/SQLSTATE; reports VERSION_CONFLICT by affected0.

Unprotected reserve commits2 overlapping rows. Protected protocol reads equipment version BEFORE availability query, validates/increments that version in same transaction as insert; second CAS0 rolls back, one row remains. Retry rechecks occupancy and rejects. Every reservation writer must use same device protocol; direct SQL/other writers remain outside guarantee. Version-first order is essential under READ_COMMITTED.

Pessimistic protocol locks stable equipment row BEFORE occupancy query and insert; locks existing device rather than absent reservations. Main future timeout150ms proves waiter incomplete while holder retains lock; after release waiter sees committed overlap. Fault branch SET LOCK_TIMEOUT200 keeps holder until actual waiter SQLException HYT00/50200; elapsed logged (not asserted exact duration). Explicit rollback; holder then commits; fresh locked retry sees one row and rejects. No deadlock scenario claimed, no timing/performance benchmark.

22 assertions. Not PoEAA application-level long business transaction Offline Lock implementation, no lock lease/auth/session checkout, no full application SQL Repository. H2 isolation semantics not portable to PostgreSQL/MySQL. No thread shares a Sql connection; bounded awaits prevent silent hang.
