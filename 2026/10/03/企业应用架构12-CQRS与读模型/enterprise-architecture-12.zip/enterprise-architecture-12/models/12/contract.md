# Chapter 12 teaching model contract

Invocation: `bash run-lab.sh 12` with Java21, Python3 and H2 pinned by sql-support/v1/h2.json.

Every stage launches a separate JVM. Exact actual commands/exit codes: processes.json. Top-level exit0: normal.stdout.txt / normal.stderr.txt.

|Scenario|Binary observable|Captured artifact|
|---|---|---|
|write|paused lag=2, write amount=30, empty projection and CHECK23513|write.stdout.txt|
|project|gap rejected with watermark0, duplicate row count1, watermark2|project.stdout.txt|
|rebuild|read model amount30 after delete and replay|rebuild.stdout.txt|
|verify|new JVM reads source30, view30, watermark2|verify.stdout.txt|

Limits: local H2 file persistence under process exit, not power loss or production database. Simplified teaching model, frozen27 baseline unchanged. No production throughput inference.
