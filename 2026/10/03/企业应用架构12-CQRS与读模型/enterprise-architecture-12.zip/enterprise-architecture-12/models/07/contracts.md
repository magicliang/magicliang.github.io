# 07 identity and SQL work contract

Work owns one actual JDBC Sql session, identity map Key(tenant,id)→Managed reference, dirty set. First find uses two SELECTs header/details; repeat returns same reference without SQL. Managed mutation checks active owning Work; attach rejects another owner's object. Ended work refuses mutation, failure ends work; no transparent object-state rollback or retry of failed object.

replaceLines requires nonempty nonnegative scale2 lines, derives total with frozen Money. commit flushes header, deletes old details, inserts new details, then exactly one SQL commit. Mid-flush injection writes actual negative child amount after legal updates/inserts; CHECK23513 triggers explicit rollback once, zero commits. New connection observes original RESERVED/30.00/two lines. Includes naive duplicate load then stale update reproducing overwrite; session identity fixes duplicate references but not cross-transaction concurrency.

13 assertions normal exit0. No automatic dirty reflection, optimistic version predicate, merge of detached objects, delete lifecycle or full frozen27 SQL Repository. Read-only Work.close rolls back its transaction. H2 schema-v1/support fixed. SQL resources/counters emitted by actual JDBC wrapper.
