package enterprise.chapter11;

public record Presentation(String status, String message, boolean successful) {
    public static Presentation from(int response) {
        return response < 300 ? new Presentation("success","租赁已保存",true)
                : new Presentation("error",response==422?"金额必须为正数，币种为 CNY，结束时间须晚于开始时间":"保存失败，请检查输入",false);
    }
}
