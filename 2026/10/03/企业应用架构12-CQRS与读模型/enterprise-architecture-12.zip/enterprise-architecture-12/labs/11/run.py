import json,os,pathlib,subprocess,tempfile,time,urllib.request,urllib.error,urllib.parse
from html.parser import HTMLParser
root=pathlib.Path(__file__).resolve().parents[2]
evidence=pathlib.Path(os.environ.get('LAB_EVIDENCE',root/'evidence/11')); evidence.mkdir(parents=True,exist_ok=True)
class Controls(HTMLParser):
    def __init__(self):super().__init__();self.labels=set();self.fields=set();self.buttons=0
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='label':self.labels.add(a.get('for'))
        if tag=='input' and a.get('type')!='hidden':self.fields.add(a.get('id'))
        if tag=='button' and a.get('type')=='submit':self.buttons+=1
html=(root/'labs/11/form.html').read_text(); p=Controls();p.feed(html)
assert p.fields==p.labels and len(p.fields)==5 and p.buttons==1
broken=Controls();broken.feed(html.replace('for="amount"','for="missing"'));assert broken.fields!=broken.labels
assert 'com.sun.net.httpserver' not in (root/'labs/11/Presentation.java').read_text()
print('PASS labels matched and missing-label mutant rejected; presentation has no GUI imports')
java=str(pathlib.Path(os.environ['JAVA_HOME'])/'bin/java') if os.environ.get('JAVA_HOME') else 'java'
with tempfile.TemporaryDirectory(prefix='enterprise11-') as tmp:
    work=pathlib.Path(tmp); subprocess.run(['bash',str(root/'labs/10/compile.sh'),tmp],check=True)
    cp=str(work/'classes')+':'+(work/'h2-path').read_text()
    with (evidence/'form-http-server.log').open('w') as output:
        server=subprocess.Popen([java,'-cp',cp,'enterprise.chapter11.PageServer',str(work/'db'),'0',str(root/'labs/11/form.html'),str(work/'port')],stdout=output,stderr=subprocess.STDOUT)
        try:
            for _ in range(200):
                if(work/'port').exists():break
                if server.poll() is not None:raise RuntimeError('server exited')
                time.sleep(.05)
            base='http://127.0.0.1:'+(work/'port').read_text()+'/'
            payload=dict(id='HTTP1',equipment='E1',amount='-1',currency='CNY',starts='2026-10-03T10:00:00Z',ends='2026-10-03T11:00:00Z',version='1')
            records=[]
            def post(data):
                try:r=urllib.request.urlopen(base,urllib.parse.urlencode(data).encode())
                except urllib.error.HTTPError as e:r=e
                page=r.read().decode();records.append(dict(status=r.status,url=r.url,body=page));return r.status,page,r.url
            code,page,url=post(payload);assert code==422 and 'role="alert"' in page and '租赁已保存' not in page
            code,page,url=post(payload|dict(amount='25.00'));assert code==200 and url.endswith('?saved=1') and 'role="status"' in page
            refresh=urllib.request.urlopen(url);assert refresh.status==200
            code,page,url=post(payload|dict(amount='25.00'));assert code==200
            (evidence/'form-http.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
            print('PASS failed submit shows error; correction redirects; duplicate post returns prior outcome; refresh GET')
        finally:server.terminate();server.wait(timeout=10)
    result=subprocess.run([java,'-cp',cp,'enterprise.chapter10.RentalEndpoint',str(work/'db'),'count'],capture_output=True,text=True)
    (evidence/'form-restart-readback.log').write_text(result.stdout+result.stderr)
    assert result.returncode==0 and 'PERSISTED_COUNT=1' in result.stdout
print('RESULT enterprise11 automated PASS; actual browser evidence is separate')
