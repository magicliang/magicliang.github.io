package enterprise.chapter11;

import com.sun.net.httpserver.HttpServer;
import enterprise.chapter10.RentalEndpoint;
import enterprise.sql.Sql;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicInteger;

public final class PageServer {
    private PageServer() { }
    public static void main(String[] args) throws Exception {
        String url="jdbc:h2:"+Path.of(args[0]).toAbsolutePath();
        try(Sql db=Sql.open(url)) { db.update("CREATE TABLE IF NOT EXISTS api_contract(id VARCHAR PRIMARY KEY,tenant VARCHAR,equipment VARCHAR,amount DECIMAL(19,2),currency VARCHAR,starts VARCHAR,ends VARCHAR)"); db.commit(); }
        String page=Files.readString(Path.of(args[2]));
        var requests=new AtomicInteger();
        var server=HttpServer.create(new InetSocketAddress("127.0.0.1",Integer.parseInt(args[1])),0);
        server.createContext("/",exchange->{
            System.out.println("PAGE_HTTP request="+requests.incrementAndGet()+" method="+exchange.getRequestMethod()+" uri="+exchange.getRequestURI());
            try {
                if(exchange.getRequestMethod().equals("POST")) {
                    byte[] body=exchange.getRequestBody().readNBytes(1025);
                    int code=body.length>1024?413:RentalEndpoint.create(url,RentalEndpoint.decode(new String(body,StandardCharsets.UTF_8)));
                    var model=Presentation.from(code);
                    if(model.successful()) { exchange.getResponseHeaders().set("Location","/?saved=1"); exchange.sendResponseHeaders(303,-1); exchange.close(); }
                    else RentalEndpoint.reply(exchange,code,"text/html",page.replace("<!--MESSAGE-->","<p role=\"alert\" id=\"feedback\">"+model.message()+"</p>"));
                } else {
                    String message="saved=1".equals(exchange.getRequestURI().getRawQuery())?"<p role=\"status\" id=\"feedback\">租赁已保存</p>":"";
                    RentalEndpoint.reply(exchange,200,"text/html",page.replace("<!--MESSAGE-->",message));
                }
            } catch(Exception failure) { failure.printStackTrace(); RentalEndpoint.reply(exchange,500,"text/plain","保存失败"); }
        });
        server.start(); Files.writeString(Path.of(args[3]),Integer.toString(server.getAddress().getPort()));
        System.out.println("READY port="+server.getAddress().getPort());
    }
}
