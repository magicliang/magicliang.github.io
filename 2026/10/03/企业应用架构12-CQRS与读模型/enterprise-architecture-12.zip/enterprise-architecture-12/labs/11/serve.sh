#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
work=${1:?persistent work directory}; port=${2:-0}
bash "$root/labs/10/compile.sh" "$work"
exec "${JAVA_HOME:+$JAVA_HOME/bin/}java" -cp "$work/classes:$(cat "$work/h2-path")" enterprise.chapter11.PageServer "$work/db" "$port" "$root/labs/11/form.html" "$work/port"
