package enterprise.chapter07;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.List;
import enterprise.chapter05.ContractMapper;
import enterprise.chapter05.Lab05;
import enterprise.sql.Check;
import enterprise.sql.Contract;
import enterprise.sql.Sql;

public final class Lab07 {
    private Lab07() { }
    public static void main(String[] args) throws Exception {
        String url="jdbc:h2:"+Path.of(args[0]).toAbsolutePath(); Sql.migrate(url,Path.of(args[1]));
        var mapper=new ContractMapper();
        try(Sql db=Sql.open(url)) {
            db.update("INSERT INTO equipment(tenant_id,equipment_id,category,state) VALUES('T1','E1','camera','ACTIVE')");
            mapper.insert(db,Lab05.sample("C1","E1")); db.update("INSERT INTO contract_line VALUES('T1','C1',1,'rent',25.00)"); db.commit();
        }
        try(Sql db=Sql.open(url)) {
            var first=mapper.find(db,"T1","C1"); var second=mapper.find(db,"T1","C1");
            Check.that("without identity map two instances",first!=second);
            db.update("UPDATE rental_contract SET amount=? WHERE tenant_id=? AND contract_id=?",new BigDecimal("40.00"),first.tenant(),first.id());
            db.update("UPDATE rental_contract SET amount=? WHERE tenant_id=? AND contract_id=?",second.total().amount(),second.tenant(),second.id()); db.commit();
        }
        try(Sql db=Sql.open(url)) { Check.that("stale duplicate actually overwrote first change",mapper.find(db,"T1","C1").total().amount().equals(new BigDecimal("25.00"))); }
        Work.Managed held;
        try(Work work=new Work(url)) {
            var first=work.find("T1","C1"); int queries=work.queries(); var again=work.find("T1","C1");
            Check.that("same work returns same reference",first==again);
            Check.that("second find issues no SQL",work.queries()==queries && queries==2);
            first.replaceLines(List.of(new Work.Line("rent",new BigDecimal("25.00")),new Work.Line("fee",new BigDecimal("5.00"))));
            work.commit(false); held=first;
            Check.that("one real commit for aggregate and details",work.commits()==1 && work.rollbacks()==0);
        }
        try(Work work=new Work(url)) {
            var loaded=work.find("T1","C1");
            Check.that("new work creates new reference",held!=loaded);
            Check.that("new connection sees total and both lines",loaded.value().total().amount().equals(new BigDecimal("30.00")) && loaded.lines().size()==2);
            try { work.attach(held); throw new AssertionError("foreign object accepted"); }
            catch(IllegalArgumentException expected){Check.that("foreign work object rejected before commit",work.commits()==0);}
        }
        try { held.cancel(); throw new AssertionError("closed work mutation accepted"); }
        catch(IllegalStateException expected){Check.that("closed owner blocks mutation",true);}
        try(Work work=new Work(url)) {
            var contract=work.find("T1","C1"); contract.cancel();
            contract.replaceLines(List.of(new Work.Line("changed",new BigDecimal("99.00"))));
            try { work.commit(true); throw new AssertionError("injected line accepted"); }
            catch(SQLException failure){Check.that("mid-flush CHECK failure SQLSTATE23513",failure.getSQLState().equals("23513"));}
            Check.that("failed unit rolls back once and never commits",work.commits()==0 && work.rollbacks()==1);
        }
        try(Work read=new Work(url)) {
            var contract=read.find("T1","C1");
            Check.that("fresh connection header fully rolled back",contract.value().state()==Contract.State.RESERVED && contract.value().total().amount().equals(new BigDecimal("30.00")));
            Check.that("fresh connection deleted/reinserted lines rolled back",contract.lines().equals(List.of(new Work.Line("rent",new BigDecimal("25.00")),new Work.Line("fee",new BigDecimal("5.00")))));
        }
        Check.result("07");
    }
}
