package enterprise.chapter07;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import enterprise.chapter05.ContractMapper;
import enterprise.sql.Contract;
import enterprise.sql.Sql;
import rental.domain.Money;

public final class Work implements AutoCloseable {
    public record Line(String description, BigDecimal amount) {
        public Line { if (description == null || description.isBlank() || amount.signum()<0) throw new IllegalArgumentException("line"); amount=amount.setScale(2); }
    }
    public static final class Managed {
        private final Work owner;
        private Contract value;
        private List<Line> lines;
        private Managed(Work owner, Contract value, List<Line> lines) { this.owner=owner; this.value=value; this.lines=List.copyOf(lines); }
        public Contract value() { return value; }
        public List<Line> lines() { return lines; }
        public void cancel() { owner.active(); value=value.cancel(); owner.dirty.add(this); }
        public void replaceLines(List<Line> next) {
            owner.active();
            if(next.isEmpty()) throw new IllegalArgumentException("lines required");
            var sum=next.stream().map(Line::amount).reduce(BigDecimal.ZERO,BigDecimal::add);
            value=new Contract(value.tenant(),value.id(),value.equipment(),value.period(),new Money(sum,value.total().currency()),value.state(),value.version());
            lines=List.copyOf(next); owner.dirty.add(this);
        }
    }
    private record Key(String tenant,String id) { }
    private final Sql db;
    private final Map<Key,Managed> identity=new LinkedHashMap<>();
    private final Set<Managed> dirty=new LinkedHashSet<>();
    private boolean ended;
    public Work(String url) throws SQLException { db=Sql.open(url); }
    private void active() { if(ended || db.closed()) throw new IllegalStateException("work ended"); }
    public Managed find(String tenant,String id) throws SQLException {
        active(); var key=new Key(tenant,id); var found=identity.get(key); if(found!=null)return found;
        Contract value=new ContractMapper().find(db,tenant,id);
        List<Line> lines=db.query("SELECT description,amount FROM contract_line WHERE tenant_id=? AND contract_id=? ORDER BY line_no",r->new Line(r.getString(1),r.getBigDecimal(2)),tenant,id);
        found=new Managed(this,value,lines); identity.put(key,found); return found;
    }
    public void attach(Managed object) {
        active();
        if(object.owner!=this || identity.get(new Key(object.value.tenant(),object.value.id()))!=object) throw new IllegalArgumentException("foreign work object");
        dirty.add(object);
    }
    public void commit(boolean injectInvalidLine) throws SQLException {
        active();
        try {
            for(Managed object:dirty) {
                Contract value=object.value;
                int rows=db.update("UPDATE rental_contract SET amount=?,status=? WHERE tenant_id=? AND contract_id=?",value.total().amount(),value.state().name(),value.tenant(),value.id());
                if(rows!=1) throw new SQLException("missing aggregate");
                db.update("DELETE FROM contract_line WHERE tenant_id=? AND contract_id=?",value.tenant(),value.id());
                int number=0;
                for(Line line:object.lines)db.update("INSERT INTO contract_line VALUES(?,?,?,?,?)",value.tenant(),value.id(),++number,line.description(),line.amount());
                if(injectInvalidLine)db.update("INSERT INTO contract_line VALUES(?,?,?,?,?)",value.tenant(),value.id(),++number,"injected",new BigDecimal("-1.00"));
            }
            db.commit();
        } catch(SQLException|RuntimeException failure) { db.rollback(); throw failure; }
        finally { ended=true; dirty.clear(); }
    }
    public int queries() { return db.queries(); }
    public int commits() { return db.commits(); }
    public int rollbacks() { return db.rollbacks(); }
    @Override public void close() throws SQLException {
        try { if(!ended)db.rollback(); } finally { ended=true; db.close(); }
    }
}
