package enterprise.chapter09;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import enterprise.chapter05.ContractMapper;
import enterprise.chapter05.Lab05;
import enterprise.sql.Check;
import enterprise.sql.Sql;

public final class Lab09 {
    private Lab09() { }
    private record Outcome(int connection,int affected,String state,long millis) { }
    private static void await(CountDownLatch latch) throws InterruptedException {
        if(!latch.await(8,TimeUnit.SECONDS))throw new AssertionError("coordination timeout");
    }
    private static void reset(String url,boolean contract) throws SQLException {
        try(Sql db=Sql.open(url)) {
            db.update("DELETE FROM contract_line");db.update("DELETE FROM rental_contract");db.update("DELETE FROM equipment");
            db.update("INSERT INTO equipment(tenant_id,equipment_id,category,state) VALUES('T1','E1','camera','ACTIVE')");
            if(contract)new ContractMapper().insert(db,Lab05.sample("C1","E1"));db.commit();
        }
    }
    private static BigDecimal amount(String url) throws SQLException {
        try(Sql db=Sql.open(url)){return db.query("SELECT amount FROM rental_contract WHERE contract_id='C1'",r->r.getBigDecimal(1)).getFirst();}
    }
    private static boolean free(Sql db) throws SQLException {
        var period=Lab05.sample("x","E1").period();
        return db.query("SELECT COUNT(*) FROM rental_contract WHERE tenant_id='T1' AND equipment_id='E1' AND status='RESERVED' AND starts_at<? AND ?<ends_at",r->r.getInt(1),period.end(),period.start()).getFirst()==0;
    }
    private static long version(Sql db) throws SQLException {return db.query("SELECT version FROM equipment WHERE tenant_id='T1' AND equipment_id='E1'",r->r.getLong(1)).getFirst();}
    private static void reserve(Sql db,String id) throws SQLException {new ContractMapper().insert(db,Lab05.sample(id,"E1"));}
    private static void moneyRace(String url,boolean optimistic) throws Exception {
        reset(url,true);var read=new CyclicBarrier(2);var firstCommitted=new CountDownLatch(1);
        try(var pool=Executors.newFixedThreadPool(2)) {
            var first=pool.submit(()->{
                try(Sql db=Sql.open(url)){
                    var row=new ContractMapper().find(db,"T1","C1");read.await(8,TimeUnit.SECONDS);
                    String sql=optimistic?"UPDATE rental_contract SET amount=?,version=version+1 WHERE tenant_id='T1' AND contract_id='C1' AND version=?":"UPDATE rental_contract SET amount=? WHERE tenant_id='T1' AND contract_id='C1'";
                    int rows=optimistic?db.update(sql,row.total().amount().add(new BigDecimal("5.00")),row.version()):db.update(sql,row.total().amount().add(new BigDecimal("5.00")));
                    db.commit();return new Outcome(db.id(),rows,"OK",0);
                }finally{firstCommitted.countDown();}
            });
            var second=pool.submit(()->{
                try(Sql db=Sql.open(url)){
                    var row=new ContractMapper().find(db,"T1","C1");read.await(8,TimeUnit.SECONDS);await(firstCommitted);
                    int rows=optimistic?db.update("UPDATE rental_contract SET amount=?,version=version+1 WHERE tenant_id='T1' AND contract_id='C1' AND version=?",row.total().amount().add(new BigDecimal("7.00")),row.version()):db.update("UPDATE rental_contract SET amount=? WHERE tenant_id='T1' AND contract_id='C1'",row.total().amount().add(new BigDecimal("7.00")));
                    if(rows==1)db.commit();else db.rollback();return new Outcome(db.id(),rows,rows==0?"VERSION_CONFLICT":"OK",0);
                }
            });
            var a=first.get(10,TimeUnit.SECONDS);var b=second.get(10,TimeUnit.SECONDS);
            Check.that("money race uses independent connections optimistic="+optimistic,a.connection()!=b.connection());
            Check.that("actual update counts optimistic="+optimistic,a.affected()==1 && b.affected()==(optimistic?0:1));
            System.out.println("MONEY_RACE optimistic="+optimistic+" first="+a+" second="+b);
        }
        Check.that(optimistic?"version predicate prevents stale overwrite":"unprotected stale read loses first increment",amount(url).equals(new BigDecimal(optimistic?"30.00":"32.00")));
        if(optimistic){
            try(Sql db=Sql.open(url)){
                var fresh=new ContractMapper().find(db,"T1","C1");
                int rows=db.update("UPDATE rental_contract SET amount=?,version=version+1 WHERE tenant_id='T1' AND contract_id='C1' AND version=?",fresh.total().amount().add(new BigDecimal("7.00")),fresh.version());
                Check.that("retry rereads version1 and succeeds once",fresh.version()==1 && rows==1);db.commit();
            }
            Check.that("retry preserves both accepted increments",amount(url).equals(new BigDecimal("37.00")));
        }
    }
    private static void reservationRace(String url,boolean optimistic) throws Exception {
        reset(url,false);var read=new CyclicBarrier(2);var firstCommitted=new CountDownLatch(1);
        try(var pool=Executors.newFixedThreadPool(2)){
            var first=pool.submit(()->{
                try(Sql db=Sql.open(url)){
                    long observed=version(db);if(!free(db))throw new AssertionError("seed busy");read.await(8,TimeUnit.SECONDS);
                    int rows=optimistic?db.update("UPDATE equipment SET version=version+1 WHERE tenant_id='T1' AND equipment_id='E1' AND version=?",observed):1;
                    if(rows==1){reserve(db,"R1");db.commit();}return new Outcome(db.id(),rows,"OK",0);
                }finally{firstCommitted.countDown();}
            });
            var second=pool.submit(()->{
                try(Sql db=Sql.open(url)){
                    long observed=version(db);if(!free(db))throw new AssertionError("seed busy");read.await(8,TimeUnit.SECONDS);await(firstCommitted);
                    int rows=optimistic?db.update("UPDATE equipment SET version=version+1 WHERE tenant_id='T1' AND equipment_id='E1' AND version=?",observed):1;
                    if(rows==1){reserve(db,"R2");db.commit();}else db.rollback();return new Outcome(db.id(),rows,rows==0?"VERSION_CONFLICT":"OK",0);
                }
            });
            var a=first.get(10,TimeUnit.SECONDS);var b=second.get(10,TimeUnit.SECONDS);
            Check.that("reservation race independent connections optimistic="+optimistic,a.connection()!=b.connection());
            Check.that("reservation CAS affected rows optimistic="+optimistic,b.affected()==(optimistic?0:1));
            System.out.println("RESERVATION_RACE optimistic="+optimistic+" first="+a+" second="+b);
        }
        try(Sql db=Sql.open(url)){
            Check.that(optimistic?"one reservation survives device version protocol":"unprotected overlapping reservations reproduced",db.count("rental_contract")==(optimistic?1:2));
            if(optimistic)Check.that("retry must recheck availability and reject",!free(db));
        }
    }
    private static void lockRace(String url,boolean timeout) throws Exception {
        reset(url,false);var ownerLocked=new CountDownLatch(1);var waiterEntered=new CountDownLatch(1);var release=new CountDownLatch(1);
        try(var pool=Executors.newFixedThreadPool(2)){
            var first=pool.submit(()->{
                try(Sql db=Sql.open(url)){
                    db.query("SELECT equipment_id FROM equipment WHERE tenant_id='T1' AND equipment_id='E1' FOR UPDATE",r->r.getString(1));
                    if(!free(db))throw new AssertionError("seed busy");ownerLocked.countDown();await(release);reserve(db,"LOCKED");db.commit();return db.id();
                }finally{ownerLocked.countDown();}
            });
            var second=pool.submit(()->{
                await(ownerLocked);
                try(Sql db=Sql.open(url)){
                    db.update("SET LOCK_TIMEOUT "+(timeout?200:5000));waiterEntered.countDown();long start=System.nanoTime();
                    try{
                        db.query("SELECT equipment_id FROM equipment WHERE tenant_id='T1' AND equipment_id='E1' FOR UPDATE",r->r.getString(1));
                        boolean available=free(db);if(available)reserve(db,"WAITER");db.commit();
                        return new Outcome(db.id(),available?1:0,"OK",TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-start));
                    }catch(SQLException failure){db.rollback();return new Outcome(db.id(),0,failure.getSQLState()+"/"+failure.getErrorCode(),TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-start));}
                }finally{waiterEntered.countDown();}
            });
            Outcome result;
            try{
                await(waiterEntered);
                if(timeout){result=second.get(8,TimeUnit.SECONDS);Check.that("real H2 lock timeout HYT00/50200",result.state().equals("HYT00/50200"));}
                else{
                    try{second.get(150,TimeUnit.MILLISECONDS);throw new AssertionError("waiter finished while owner holds lock");}
                    catch(TimeoutException expected){Check.that("waiter actually blocked before owner release",true);}
                    release.countDown();result=second.get(8,TimeUnit.SECONDS);Check.that("waiter sees committed overlap after acquiring lock",result.state().equals("OK") && result.affected()==0);
                }
            }finally{release.countDown();}
            int firstId=first.get(8,TimeUnit.SECONDS);
            Check.that("lock owner and waiter independent connections",firstId!=result.connection());
            System.out.println("LOCK_RESULT timeout="+timeout+" owner="+firstId+" waiter="+result);
        }
        try(Sql db=Sql.open(url)){
            db.query("SELECT equipment_id FROM equipment WHERE tenant_id='T1' AND equipment_id='E1' FOR UPDATE",r->r.getString(1));
            Check.that("fresh locked retry sees one committed reservation",db.count("rental_contract")==1 && !free(db));db.rollback();
        }
    }
    public static void main(String[] args) throws Exception {
        String url="jdbc:h2:"+Path.of(args[0]).toAbsolutePath();Sql.migrate(url,Path.of(args[1]));
        moneyRace(url,false);moneyRace(url,true);reservationRace(url,false);reservationRace(url,true);lockRace(url,false);lockRace(url,true);
        Check.result("09");
    }
}
