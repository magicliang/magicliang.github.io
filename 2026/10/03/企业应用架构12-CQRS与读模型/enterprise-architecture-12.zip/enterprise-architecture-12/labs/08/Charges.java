package enterprise.chapter08;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Currency;
import java.util.List;
import enterprise.sql.Sql;
import rental.domain.Money;

public final class Charges {
    private Charges() { }
    public sealed interface Charge permits Fixed,Daily { String id(); Money total(); }
    public record Fixed(String id,Money amount) implements Charge {
        public Fixed { if(amount.amount().signum()<0)throw new IllegalArgumentException("negative"); }
        @Override public Money total(){return amount;}
    }
    public record Daily(String id,Money rate,int days) implements Charge {
        public Daily { if(days<=0 || rate.amount().signum()<0)throw new IllegalArgumentException("daily"); }
        @Override public Money total(){return new Money(rate.amount().multiply(BigDecimal.valueOf(days)),rate.currency());}
    }
    public static void schema(Sql db) throws SQLException {
        db.update("CREATE TABLE single_fee(id VARCHAR(20) PRIMARY KEY, kind VARCHAR(10) NOT NULL, currency VARCHAR(3) NOT NULL, fixed_amount DECIMAL(19,2), daily_rate DECIMAL(19,2), days INT, CHECK((kind='FIXED' AND fixed_amount IS NOT NULL AND fixed_amount>=0 AND daily_rate IS NULL AND days IS NULL) OR (kind='DAILY' AND fixed_amount IS NULL AND daily_rate IS NOT NULL AND daily_rate>=0 AND days IS NOT NULL AND days>0)))");
        db.update("CREATE TABLE fee_base(id VARCHAR(20) PRIMARY KEY,kind VARCHAR(10) NOT NULL CHECK(kind IN('FIXED','DAILY')),currency VARCHAR(3) NOT NULL)");
        db.update("CREATE TABLE fixed_fee(id VARCHAR(20) PRIMARY KEY REFERENCES fee_base(id), amount DECIMAL(19,2) NOT NULL CHECK(amount>=0))");
        db.update("CREATE TABLE daily_fee(id VARCHAR(20) PRIMARY KEY REFERENCES fee_base(id),rate DECIMAL(19,2) NOT NULL CHECK(rate>=0),days INT NOT NULL CHECK(days>0))");
        db.commit();
    }
    public static void insertSingle(Sql db,Charge charge) throws SQLException {
        switch(charge) {
            case Fixed f -> db.update("INSERT INTO single_fee VALUES(?,?,?,?,?,?)",f.id(),"FIXED",f.amount().currency().getCurrencyCode(),f.amount().amount(),null,null);
            case Daily d -> db.update("INSERT INTO single_fee VALUES(?,?,?,?,?,?)",d.id(),"DAILY",d.rate().currency().getCurrencyCode(),null,d.rate().amount(),d.days());
        }
    }
    public static void insertClass(Sql db,Charge charge) throws SQLException {
        db.update("INSERT INTO fee_base VALUES(?,?,?)",charge.id(),charge instanceof Fixed?"FIXED":"DAILY",charge.total().currency().getCurrencyCode());
        switch(charge) {
            case Fixed f -> db.update("INSERT INTO fixed_fee VALUES(?,?)",f.id(),f.amount().amount());
            case Daily d -> db.update("INSERT INTO daily_fee VALUES(?,?,?)",d.id(),d.rate().amount(),d.days());
        }
    }
    public static List<Charge> single(Sql db) throws SQLException {
        return db.query("SELECT * FROM single_fee ORDER BY id",r->{
            var currency=Currency.getInstance(r.getString("currency"));
            return switch(r.getString("kind")){
                case "FIXED"->new Fixed(r.getString("id"),new Money(r.getBigDecimal("fixed_amount"),currency));
                case "DAILY"->new Daily(r.getString("id"),new Money(r.getBigDecimal("daily_rate"),currency),r.getInt("days"));
                default->throw new SQLException("unknown discriminator");
            };
        });
    }
    public static List<Charge> classes(Sql db) throws SQLException {
        return db.query("SELECT b.id,b.kind,b.currency,f.amount,d.rate,d.days FROM fee_base b LEFT JOIN fixed_fee f ON f.id=b.id LEFT JOIN daily_fee d ON d.id=b.id ORDER BY b.id",r->{
            var currency=Currency.getInstance(r.getString("currency"));
            if(r.getString("kind").equals("FIXED") && r.getBigDecimal("amount")!=null && r.getBigDecimal("rate")==null)return new Fixed(r.getString("id"),new Money(r.getBigDecimal("amount"),currency));
            if(r.getString("kind").equals("DAILY") && r.getBigDecimal("rate")!=null && r.getBigDecimal("amount")==null)return new Daily(r.getString("id"),new Money(r.getBigDecimal("rate"),currency),r.getInt("days"));
            throw new SQLException("invalid subtype rows");
        });
    }
}
