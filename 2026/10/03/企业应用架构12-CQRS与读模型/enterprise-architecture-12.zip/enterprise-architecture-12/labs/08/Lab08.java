package enterprise.chapter08;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.Currency;
import java.util.List;
import enterprise.chapter05.ContractMapper;
import enterprise.chapter05.Lab05;
import enterprise.chapter07.Work;
import enterprise.sql.Check;
import enterprise.sql.Sql;
import rental.domain.Money;

public final class Lab08 {
    private Lab08() { }
    public static void main(String[] args) throws Exception {
        String url="jdbc:h2:"+Path.of(args[0]).toAbsolutePath();Sql.migrate(url,Path.of(args[1]));
        try(Sql db=Sql.open(url)) {
            db.update("INSERT INTO equipment(tenant_id,equipment_id,category,state) VALUES('T1','E1','camera','ACTIVE')");
            for(int i=1;i<=100;i++){
                String id=String.format("C%03d",i);new ContractMapper().insert(db,Lab05.sample(id,"E1"));
                db.update("INSERT INTO contract_line VALUES(?,?,?,?,?)","T1",id,1,"rent",new BigDecimal("20.00"));
                db.update("INSERT INTO contract_line VALUES(?,?,?,?,?)","T1",id,2,"fee",new BigDecimal("5.00"));
            }
            db.commit();Charges.schema(db);
        }
        for(int n:new int[]{1,10,100}){
            List<Aggregates.Complete> lazyValues;
            int lazyQueries;
            try(Sql db=Sql.open(url)){
                var lazy=Aggregates.lazy(db,n);var list=new java.util.ArrayList<Aggregates.Complete>();
                for(var value:lazy)list.add(value.complete());lazyValues=List.copyOf(list);lazyQueries=db.queries();
                Check.that("actual N+1 at size="+n,lazyQueries==n+1);
            }
            try(Sql db=Sql.open(url)){
                var values=Aggregates.batch(db,n);
                Check.that("batch same aggregates size="+n,values.equals(lazyValues) && values.size()==n);
                Check.that("two actual batch SELECTs size="+n,db.queries()==2);
                System.out.println("QUERY_COUNTS contracts="+n+" lazy="+lazyQueries+" batch="+db.queries());
            }
        }
        Aggregates.Lazy detached;
        try(Sql db=Sql.open(url)){detached=Aggregates.lazy(db,1).getFirst();}
        try{detached.complete();throw new AssertionError("detached lazy loaded");}catch(IllegalStateException expected){Check.that("unloaded detail refuses closed session",true);}
        Aggregates.Complete loaded;
        try(Sql db=Sql.open(url)){loaded=Aggregates.batch(db,1).getFirst();}
        Check.that("fully loaded immutable aggregate usable after close",loaded.lines().size()==2);
        try(Sql db=Sql.open(url)){db.update("UPDATE contract_line SET amount=99 WHERE tenant_id='T1' AND contract_id='C001' AND line_no=1");db.commit();}
        try(Sql db=Sql.open(url)){
            try{Aggregates.batch(db,1);throw new AssertionError("bypass total mismatch accepted");}catch(IllegalStateException expected){Check.that("bypassed child SQL breaks aggregate and is detected",true);}
        }
        try(Work work=new Work(url)){
            work.find("T1","C001").replaceLines(List.of(new Work.Line("rent",new BigDecimal("20.00")),new Work.Line("fee",new BigDecimal("5.00"))));work.commit(false);
        }
        try(Sql db=Sql.open(url)){Check.that("aggregate-owned repair restores roundtrip",Aggregates.batch(db,1).getFirst().equals(loaded));}
        var cny=Currency.getInstance("CNY");
        List<Charges.Charge> fees=List.of(new Charges.Fixed("F1",new Money(new BigDecimal("5.00"),cny)),new Charges.Daily("F2",new Money(new BigDecimal("10.00"),cny),2));
        try(Sql db=Sql.open(url)){for(var fee:fees){Charges.insertSingle(db,fee);Charges.insertClass(db,fee);}db.commit();}
        try(Sql db=Sql.open(url)){
            Check.that("single table polymorphic values roundtrip",Charges.single(db).equals(fees));
            Check.that("class table polymorphic values roundtrip",Charges.classes(db).equals(fees));
            Check.that("same fee totals across mappings",Charges.single(db).stream().map(Charges.Charge::total).toList().equals(Charges.classes(db).stream().map(Charges.Charge::total).toList()));
            try{db.update("INSERT INTO single_fee VALUES('BAD','FIXED','CNY',NULL,10,2)");throw new AssertionError("invalid discriminator accepted");}
            catch(SQLException failure){Check.that("single table shape CHECK23513",failure.getSQLState().equals("23513"));db.rollback();}
            db.update("INSERT INTO fee_base VALUES('ORPHAN','DAILY','CNY')");
            try{Charges.classes(db);throw new AssertionError("missing subtype accepted");}catch(SQLException expected){Check.that("class table missing subtype detected by mapper",true);db.rollback();}
        }
        Check.result("08");
    }
}
