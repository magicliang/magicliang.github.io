package enterprise.chapter08;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import enterprise.chapter05.ContractMapper;
import enterprise.chapter07.Work.Line;
import enterprise.sql.Contract;
import enterprise.sql.Sql;

public final class Aggregates {
    private Aggregates() { }
    public record Complete(Contract contract, List<Line> lines) {
        public Complete {
            lines=List.copyOf(lines);
            BigDecimal sum=lines.stream().map(Line::amount).reduce(BigDecimal.ZERO,BigDecimal::add);
            if(lines.isEmpty() || sum.compareTo(contract.total().amount())!=0) throw new IllegalStateException("aggregate total differs from child sum");
        }
    }
    public static final class Lazy {
        private final Sql session;
        private final Contract contract;
        private Complete loaded;
        private Lazy(Sql session,Contract contract) { this.session=session;this.contract=contract; }
        public Complete complete() throws SQLException {
            if(loaded!=null)return loaded;
            if(session.closed())throw new IllegalStateException("unloaded detail after session closed");
            loaded=new Complete(contract,session.query("SELECT description,amount FROM contract_line WHERE tenant_id=? AND contract_id=? ORDER BY line_no",r->new Line(r.getString(1),r.getBigDecimal(2)),contract.tenant(),contract.id()));
            return loaded;
        }
    }
    public static List<Lazy> lazy(Sql session,int size) throws SQLException {
        return session.query("SELECT * FROM rental_contract WHERE tenant_id=? ORDER BY contract_id FETCH FIRST ? ROWS ONLY",row->new Lazy(session,ContractMapper.read(row)),"T1",size);
    }
    public static List<Complete> batch(Sql session,int size) throws SQLException {
        var headers=session.query("SELECT * FROM rental_contract WHERE tenant_id=? ORDER BY contract_id FETCH FIRST ? ROWS ONLY",ContractMapper::read,"T1",size);
        record Child(String id,Line line) { }
        var children=session.query("SELECT contract_id,description,amount FROM contract_line WHERE tenant_id=? AND contract_id IN (SELECT contract_id FROM rental_contract WHERE tenant_id=? ORDER BY contract_id FETCH FIRST ? ROWS ONLY) ORDER BY contract_id,line_no",r->new Child(r.getString(1),new Line(r.getString(2),r.getBigDecimal(3))),"T1","T1",size);
        var grouped=new HashMap<String,List<Line>>();
        for(var child:children)grouped.computeIfAbsent(child.id(),ignored->new ArrayList<>()).add(child.line());
        return headers.stream().map(header->new Complete(header,grouped.getOrDefault(header.id(),List.of()))).toList();
    }
}
