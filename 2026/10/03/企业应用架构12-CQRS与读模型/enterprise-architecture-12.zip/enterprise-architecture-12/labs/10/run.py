import json, os, pathlib, subprocess, sys, tempfile, time, urllib.request, urllib.error, urllib.parse
root=pathlib.Path(__file__).resolve().parents[2]
evidence=pathlib.Path(os.environ.get('LAB_EVIDENCE',root/'evidence/10')); evidence.mkdir(parents=True,exist_ok=True)
java=str(pathlib.Path(os.environ['JAVA_HOME'])/'bin/java') if os.environ.get('JAVA_HOME') else 'java'
with tempfile.TemporaryDirectory(prefix='enterprise10-') as tmp:
    work=pathlib.Path(tmp)
    subprocess.run(['bash',str(root/'labs/10/compile.sh'),tmp],check=True)
    cp=str(work/'classes')+':'+(work/'h2-path').read_text()
    command=[java,'-ea','-cp',cp,'enterprise.chapter10.RentalEndpoint',str(work/'db'),'0',str(work/'port')]
    with (evidence/'http-server.log').open('w') as output:
        server=subprocess.Popen(command,stdout=output,stderr=subprocess.STDOUT)
        try:
            for _ in range(200):
                if (work/'port').exists():break
                if server.poll() is not None:raise RuntimeError('server exited')
                time.sleep(.05)
            port=(work/'port').read_text(); base='http://127.0.0.1:'+port+'/rentals'; records=[]
            payload=dict(id='R1',equipment='E1',amount='25.00',currency='CNY',starts='2026-10-03T10:00:00Z',ends='2026-10-03T11:00:00Z',version='1')
            def request(name,data=None,expected=200,path='',principal='tenant-one'):
                body=urllib.parse.urlencode(data).encode() if isinstance(data,dict) else data
                req=urllib.request.Request(base+path,data=body,headers={'X-Principal':principal,'Content-Type':'application/x-www-form-urlencoded'})
                try:response=urllib.request.urlopen(req)
                except urllib.error.HTTPError as failure:response=failure
                result=response.read().decode(); actual=response.status
                records.append(dict(scenario=name,request=req.full_url,input=data.decode() if isinstance(data,bytes) else data,status=actual,body=result))
                assert actual==expected,(name,actual,expected,result)
                print('PASS',name,'HTTP',actual)
                return result
            request('create',payload,201)
            dto=json.loads(request('query DTO',path='?id=R1')); assert dto==dict(id='R1',amount='25.00',currency='CNY')
            request('unknown field',payload|dict(secret='internal'),400)
            request('missing currency',{k:v for k,v in payload.items() if k!='currency'},400)
            request('expired version',payload|dict(version='0'),422)
            request('unauthorized equipment',payload|dict(equipment='E2'),403)
            request('oversized body',b'x'*1025,413)
            request('missing principal',payload,401,principal='')
            request('same id different payload',payload|dict(amount='30.00'),409)
            before=len(records)
            for field in ['id','amount','currency']:json.loads(request('chatty field '+field,path='?id=R1'))[field]
            assert len(records)-before==3
            request('bulk DTO one request',path='?id=R1')
            (evidence/'http-requests.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
            print('PASS measured chatty=3 bulk=1 loopback requests only')
        finally:
            server.terminate(); server.wait(timeout=10)
    verify=subprocess.run([java,'-ea','-cp',cp,'enterprise.chapter10.RentalEndpoint',str(work/'db'),'count'],capture_output=True,text=True)
    (evidence/'restart-readback.log').write_text(verify.stdout+verify.stderr)
    assert verify.returncode==0 and 'PERSISTED_COUNT=1' in verify.stdout
    print('PASS new JVM persisted count=1 after rejected requests')
print('RESULT enterprise10 PASS')
