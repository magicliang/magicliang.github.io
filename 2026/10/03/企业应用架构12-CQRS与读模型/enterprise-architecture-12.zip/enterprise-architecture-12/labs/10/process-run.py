import json,os,pathlib,subprocess,sys,tempfile
root=pathlib.Path(__file__).resolve().parents[2]
chapter=sys.argv[1]
evidence=pathlib.Path(os.environ.get('LAB_EVIDENCE',root/'evidence'/chapter)); evidence.mkdir(parents=True,exist_ok=True)
java=str(pathlib.Path(os.environ['JAVA_HOME'])/'bin/java') if os.environ.get('JAVA_HOME') else 'java'
scenarios={'12':[('write',0),('project',0),('rebuild',0),('verify',0)],'13':[('write',0),('replay',0),('race',0),('verify',0)],'14':[('init',0),('business-crash',73),('after-business',0),('publish-crash',73),('after-publish',0),('publish',0),('consume-crash',73),('after-consume',0),('consume',0),('conflict',1),('verify',0)]}
with tempfile.TemporaryDirectory(prefix='enterprise'+chapter+'-') as tmp:
    work=pathlib.Path(tmp)
    subprocess.run(['bash',str(root/'labs/10/compile.sh'),tmp],check=True)
    cp=str(work/'classes')+':'+(work/'h2-path').read_text()
    receipts=[]
    for scenario,expected in scenarios[chapter]:
        command=[java,'-ea','-cp',cp,'enterprise.chapter'+chapter+'.Lab'+chapter,str(work/'db'),scenario]
        result=subprocess.run(command,capture_output=True,text=True)
        (evidence/(scenario+'.stdout.txt')).write_text(result.stdout)
        (evidence/(scenario+'.stderr.txt')).write_text(result.stderr)
        (evidence/(scenario+'.exit.txt')).write_text(str(result.returncode)+'\n')
        receipts.append(dict(scenario=scenario,command=command,exit=result.returncode,expected=expected,stdout=scenario+'.stdout.txt',stderr=scenario+'.stderr.txt'))
        assert result.returncode==expected,(scenario,result.returncode,result.stdout,result.stderr)
        if expected==73:assert 'CRASH_AFTER_COMMIT' in result.stdout
        if scenario=='conflict':assert 'idempotency key payload conflict' in result.stderr
        print('PASS new JVM',scenario,'exit',result.returncode)
    (evidence/'processes.json').write_text(json.dumps(receipts,indent=2))
    files=[]
    for source in work.glob('*.mv.db'):
        import hashlib
        files.append(dict(name=source.name,size=source.stat().st_size,sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
    (evidence/'database-files.json').write_text(json.dumps(files,indent=2))
print('RESULT enterprise'+chapter+' PASS')
