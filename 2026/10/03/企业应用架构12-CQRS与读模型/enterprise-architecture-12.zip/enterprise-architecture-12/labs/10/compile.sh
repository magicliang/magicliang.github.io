#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
build=${1:?build directory}; mkdir -p "$build/classes"
java_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}java
javac_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}javac
"$java_cmd" -version
[[ $("$javac_cmd" -version 2>&1) == 'javac 21.'* ]] || { echo 'JDK21 required' >&2; exit 2; }
python3 "$root/labs/00/verify-baseline.py"
jar=$(python3 "$root/sql-support/v1/resolve-h2.py")
printf '%s' "$jar" > "$build/h2-path"
frozen="$root/rental-core/frozen-27"
sources=("$frozen"/rental-core/*.java "$frozen"/labs/00/*.java "$frozen"/labs/24/*.java "$frozen"/labs/25/*.java "$frozen"/labs/26/*.java "$frozen"/rental-application/*.java "$frozen"/labs/27/*.java "$root"/sql-support/v1/*.java)
for chapter in 10 11 12 13 14; do for file in "$root/labs/$chapter/"*.java; do [[ ! -f "$file" ]] || sources+=("$file"); done; done
"$javac_cmd" --release 21 -Xlint:all -Werror -d "$build/classes" "${sources[@]}"
