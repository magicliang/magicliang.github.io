package enterprise.chapter12;
import enterprise.sql.Sql;
import enterprise.sql.Check;
import java.nio.file.Path;

public final class Lab12 {
    private Lab12() { }
    private static int number(Sql db,String sql) throws Exception { return db.query(sql,r->r.getInt(1)).getFirst(); }
    private static void apply(Sql db,int sequence,String id,int amount) throws Exception {
        int watermark=number(db,"SELECT seq FROM watermark");
        if(sequence<=watermark) { System.out.println("DUPLICATE sequence="+sequence); return; }
        if(sequence!=watermark+1) throw new IllegalArgumentException("sequence gap");
        db.update("MERGE INTO delivery_view KEY(id) VALUES(?,?)",id,amount);
        db.update("UPDATE watermark SET seq=?",sequence); db.commit();
    }
    public static void main(String[] args) throws Exception {
        String url="jdbc:h2:"+Path.of(args[0]).toAbsolutePath();
        try(Sql db=Sql.open(url)) {
            switch(args[1]) {
                case "write" -> {
                    db.update("CREATE TABLE contracts(id VARCHAR PRIMARY KEY,amount INT CHECK(amount>0),version INT)");
                    db.update("CREATE TABLE changes(seq INT PRIMARY KEY,id VARCHAR,amount INT)");
                    db.update("CREATE TABLE delivery_view(id VARCHAR PRIMARY KEY,amount INT)");
                    db.update("CREATE TABLE watermark(seq INT)"); db.update("INSERT INTO watermark VALUES(0)"); db.commit();
                    db.update("INSERT INTO contracts VALUES('R1',25,1)"); db.update("INSERT INTO changes VALUES(1,'R1',25)"); db.commit();
                    db.update("UPDATE contracts SET amount=30,version=2 WHERE id='R1'"); db.update("INSERT INTO changes VALUES(2,'R1',30)"); db.commit();
                    Check.that("paused projection exposes lag two",number(db,"SELECT MAX(seq) FROM changes")-number(db,"SELECT seq FROM watermark")==2);
                    Check.that("write truth already current",number(db,"SELECT amount FROM contracts WHERE id='R1'")==30);
                    Check.that("projection still empty",number(db,"SELECT COUNT(*) FROM delivery_view")==0);
                    try { db.update("UPDATE contracts SET amount=-1 WHERE id='R1'"); throw new AssertionError("CHECK bypass"); }
                    catch(java.sql.SQLException expected) { Check.that("write model rejects invalid amount",expected.getSQLState().equals("23513")); db.rollback(); }
                }
                case "project" -> {
                    try { apply(db,2,"R1",30); throw new AssertionError("gap accepted"); }
                    catch(IllegalArgumentException expected) { Check.that("out of order rejected without advancing watermark",number(db,"SELECT seq FROM watermark")==0); }
                    var events=db.query("SELECT seq,id,amount FROM changes ORDER BY seq",r->new String[]{r.getString(1),r.getString(2),r.getString(3)});
                    for(var event:events) apply(db,Integer.parseInt(event[0]),event[1],Integer.parseInt(event[2]));
                    apply(db,2,"R1",30);
                    Check.that("duplicate no second row",number(db,"SELECT COUNT(*) FROM delivery_view")==1);
                    Check.that("caught up with source",number(db,"SELECT amount FROM delivery_view")==30 && number(db,"SELECT seq FROM watermark")==2);
                }
                case "rebuild" -> {
                    db.update("DELETE FROM delivery_view"); db.update("UPDATE watermark SET seq=0"); db.commit();
                    for(var event:db.query("SELECT seq,id,amount FROM changes ORDER BY seq",r->new String[]{r.getString(1),r.getString(2),r.getString(3)})) apply(db,Integer.parseInt(event[0]),event[1],Integer.parseInt(event[2]));
                    Check.that("lost projection rebuilt deterministically",number(db,"SELECT amount FROM delivery_view")==30 && number(db,"SELECT seq FROM watermark")==2);
                }
                case "verify" -> Check.that("restart persisted read and write agreement",number(db,"SELECT amount FROM contracts")==30 && number(db,"SELECT amount FROM delivery_view")==30 && number(db,"SELECT seq FROM watermark")==2);
                default -> throw new IllegalArgumentException("mode");
            }
        }
        Check.result("12 "+args[1]);
    }
}
