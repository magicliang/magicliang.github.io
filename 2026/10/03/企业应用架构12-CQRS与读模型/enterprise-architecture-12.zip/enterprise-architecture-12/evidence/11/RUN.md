# Chapter 11

Invocation: `bash run-lab.sh 11` with JAVA_HOME=JDK21 and optional H2_JAR matching sql-support/v1/h2.json.

Result: exit 0; see normal.stdout.txt and normal.stderr.txt. Java HTTP server uses actual loopback, actual file H2, subprocess termination and fresh JVM readback.

Binary observable: HTTP positive/negative expected status, exact DTO fields / error and success presentation, final PERSISTED_COUNT=1.

Artifacts: form-http.json, form-http-server.log, form-restart-readback.log, browser-invalid.png, browser-success.png, browser-restart-readback.log.

Limits: one tenant, fixed authenticated-context stand-in, serial server, no TLS or production auth. 11 form resets inputs on failure and saved query flag is presentation-only. Browser evidence collected independently by root; raw request/SQL and restart artifact correspond to the browser instance.
