# Primary source research, read 2026-10-03

https://martinfowler.com/eaaCatalog/dataTransferObject.html : remote call batching and assembler.
https://martinfowler.com/eaaDev/PresentationModel.html : presentation state independent of widgets.
https://martinfowler.com/bliki/CQRS.html : separate models and added complexity.
https://martinfowler.com/eaaDev/EventSourcing.html : rebuilding and external side-effect boundary.
https://microservices.io/patterns/data/transactional-outbox.html : transactional message record, relay may duplicate.
https://microservices.io/patterns/communication-style/idempotent-consumer.html : processed-message record in same transaction.
https://docs.oracle.com/en/java/javase/21/docs/api/jdk.httpserver/com/sun/net/httpserver/HttpServer.html : default single dispatch thread, actual network server.
https://html.spec.whatwg.org/multipage/forms.html : labels and native form submission.

Article claims chiefly rely on inspected chapter code and fresh SQL/HTTP/process logs. No prose copied. H2 pinned source GitHub web open failed; local executing dependency version and SHA checked by resolver.
