# Actual primary-source review

2026-10-03 web实际打开原始目录条目全文（公开摘要，不冒充付费书籍全文）：

- https://martinfowler.com/eaaCatalog/dependentMapping.html
- https://martinfowler.com/eaaCatalog/embeddedValue.html
- https://martinfowler.com/eaaCatalog/inheritanceMappers.html
- https://martinfowler.com/eaaCatalog/singleTableInheritance.html
- https://martinfowler.com/eaaCatalog/classTableInheritance.html
- https://martinfowler.com/eaaCatalog/concreteTableInheritance.html
- https://martinfowler.com/eaaCatalog/lazyLoad.html

H2固定tag文档：https://github.com/h2database/h2database/blob/version-2.1.214/h2/src/docsrc/html/advanced.html；实际读取Transaction Isolation/MVCC/Lock Timeout，DDL多数隐式提交、READ_COMMITTED默认、逐连接锁超时。发布tag及features同版本已打开。实际Java编译21，H2SELECT H2VERSION()==2.1.214。参数化、约束与错误码另由本章实际SQL验证，不推导其他数据库。
