# E05 isolated acceptance

Source project: `/private/tmp/play-actor-work-20261003`.
Manifest: `manifest.json`, exactly 13 source/config/example files for `examples/play-electives/e05-typed-actors`. No shared lab or configuration edits.

Invocation: `JAVA_HOME=<JDK21> PLAY_LAB_SBT_LAUNCHER=<sbt1.10.7> bash sbtw test stage`; build-02.log exit 0, TEST-ActorTest.xml has two executed tests, no failures/skips. The synthetic restart exception is intentional and asserted. Manifest checks ten actual app class byte arrays against the production stage app jar.

Invocation: `JAVA_HOME=<JDK21> python3 verify.py <run-01>`; exit 0, summary PASS. Twenty-two real HTTP observations include bounded polling. 30 ms ask returns 504 at 49.819 ms; same message ID is absent immediately afterward and appears later with a dead-letter late reply. Four-slot bounded mailbox partitions 20 IDs into 4 handled and 16 dead letters; sets disjoint and complete. Explicit restart changes count 2 to 0, generation 1 to 2, preserving the external experimental ledger. PostStop is observed before sending after_stop, which appears in dead letters. Repeated one-shot controls return 409.

SIGTERM exit 143 without forced kill. cleanup.json records normal actor, bounded actor and observer termination; loopback listener refuses connections. Actors are spawned through Adapter into injected Play ActorSystem. Tests and the standalone example own separate ActorSystems and await their termination. No database/container changes.

Article and 1200x480 SVG now exist in source/_posts. The draft passed java-tech-writer review, then anti-ai-tone, then anti-persona-fabrication. Final writing-receipt.json contains SHA and exact equality of complete Java block with ActorCounterExample.java. That example was compiled against actual stage jars and executed; example.log contains count=1 plus system termination.

Raw official Pekko sources are pinned to 4f77c8108aaf548a65531d2c8807da13dbba8146 under research/. Root owns public-source integration/replay, package download, generated pages/browser checks, navigation/status and local commit. Evidence destination: examples/play-electives/evidence/e05/isolated.
