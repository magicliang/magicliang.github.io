import java.time.Duration;
import java.util.concurrent.TimeUnit;
import org.apache.pekko.actor.typed.ActorRef;
import org.apache.pekko.actor.typed.ActorSystem;
import org.apache.pekko.actor.typed.Behavior;
import org.apache.pekko.actor.typed.javadsl.AskPattern;
import org.apache.pekko.actor.typed.javadsl.Behaviors;

public final class ActorCounterExample {
    interface Command {}
    record Increment() implements Command {}
    record Read(ActorRef<Integer> replyTo) implements Command {}

    static Behavior<Command> counter(int value) {
        return Behaviors.receive(Command.class)
            .onMessage(Increment.class, message -> counter(value + 1))
            .onMessage(Read.class, message -> {
                message.replyTo().tell(value);
                return Behaviors.same();
            }).build();
    }

    public static void main(String[] args) throws Exception {
        ActorSystem<Command> system = ActorSystem.create(counter(0), "counter-example");
        try {
            system.tell(new Increment());
            int result = AskPattern.<Command, Integer>ask(system, Read::new,
                Duration.ofSeconds(2), system.scheduler()).toCompletableFuture().get(3, TimeUnit.SECONDS);
            if (result != 1) throw new AssertionError(result);
            System.out.println("count=" + result);
        } finally {
            system.terminate();
            system.getWhenTerminated().toCompletableFuture().get(5, TimeUnit.SECONDS);
        }
    }
}
