import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request

root = Path(__file__).resolve().parent
out = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root / 'evidence/run'
out.mkdir(parents=True, exist_ok=False)
with socket.socket() as s:
    s.bind(('127.0.0.1', 0))
    port = s.getsockname()[1]
base = f'http://127.0.0.1:{port}'
observations = []
summary = {'status': 'FAIL', 'port': port}

def save(name, value):
    (out / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def get(path):
    start = time.monotonic()
    try:
        with urllib.request.urlopen(base + path, timeout=5) as response:
            code, raw = response.status, response.read().decode()
    except urllib.error.HTTPError as e:
        code, raw = e.code, e.read().decode()
    try:
        data = json.loads(raw)
    except ValueError:
        data = raw
    result = {'path': path, 'code': code, 'body': data, 'millis': (time.monotonic() - start) * 1000}
    observations.append(result)
    return result

def until(predicate):
    for _ in range(120):
        item = get('/stats')
        assert item['code'] == 200
        if predicate(item['body']):
            return item['body']
        time.sleep(.025)
    raise AssertionError('bounded condition did not arrive')

stage = root / 'target/universal/stage'
save('stage-manifest.json', {str(p.relative_to(stage)): hashlib.sha256(p.read_bytes()).hexdigest()
                             for p in sorted(stage.rglob('*')) if p.is_file()})
log = (out / 'server.log').open('w')
command = [str(stage / 'bin/play-actors'), f'-Dhttp.port={port}', '-Dhttp.address=127.0.0.1',
           f'-Dpidfile.path={out / "RUNNING_PID"}', f'-Dactor.evidence={out}', '-J-Xms256m', '-J-Xmx768m']
process = subprocess.Popen(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
summary['command'] = command
try:
    for _ in range(200):
        if process.poll() is not None:
            raise AssertionError(f'server exited {process.returncode}')
        try:
            ready = get('/stats')
            if ready['code'] == 200 and ready['body']['observerReady']:
                break
        except (OSError, urllib.error.URLError):
            pass
        time.sleep(.1)
    else:
        raise AssertionError('startup timeout')
    before = get('/ask/baseline')
    assert before['code'] == 200 and before['body']['count'] == 1
    timeout = get('/ask/late?delay=300&timeout=30')
    assert timeout['code'] == 504
    at_timeout = get('/stats')['body']
    assert not any(x['id'] == 'late' for x in at_timeout['normal']), at_timeout
    late = until(lambda d: any(x['id'] == 'late' for x in d['normal']) and
                 any(x['id'] == 'late' and x['type'] == 'reply' for x in d['dead']))
    save('late.json', {'http': timeout, 'atTimeout': at_timeout, 'after': late})
    burst = get('/burst')
    assert burst['code'] == 200
    full = until(lambda d: len(d['bounded']) == 4 and len([x for x in d['dead'] if x['id'].startswith('burst_')]) == 16)
    processed = {x['id'] for x in full['bounded']}
    dropped = {x['id'] for x in full['dead'] if x['id'].startswith('burst_')}
    assert len(processed) == 4 and len(dropped) == 16 and not (processed & dropped)
    assert processed | dropped == {f'burst_{i}' for i in range(20)}
    save('mailbox.json', {'processed': sorted(processed), 'deadLetters': sorted(dropped), 'snapshot': full})
    assert get('/burst')['code'] == 409
    restarted = get('/restart')
    assert restarted['code'] == 200
    assert restarted['body']['before']['count'] == 2
    assert restarted['body']['after']['count'] == 0 and restarted['body']['after']['generation'] == 2
    assert get('/restart')['code'] == 409
    after = get('/ask/after_restart')
    assert after['code'] == 200 and after['body']['count'] == 1 and after['body']['generation'] == 2
    stopped = get('/stop')
    assert stopped['code'] == 200
    final = until(lambda d: d['boundedStopped'] and any(x['id'] == 'after_stop' for x in d['dead']))
    assert not final['normalStopped']
    assert all('actor-lab-dispatcher' in x['thread'] for x in final['normal'] + final['bounded'])
    assert get('/stop')['code'] == 409
    summary.update(status='PASS', lateWorkAfter504=True, boundedProcessed=len(processed), dropped=len(dropped),
                   restart=restarted['body'], snapshot=final)
finally:
    primary = sys.exc_info()[1]
    errors = []
    try:
        if process.poll() is None:
            process.send_signal(signal.SIGTERM)
            try:
                summary['exit'] = process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
                raise AssertionError('forced kill required')
        else:
            summary['exit'] = process.returncode
        summary['cleanup'] = json.loads((out / 'cleanup.json').read_text())
        assert all(summary['cleanup'][k] for k in ('normalStopped', 'boundedStopped', 'observerStopped'))
        try:
            with socket.create_connection(('127.0.0.1', port), timeout=.3):
                raise AssertionError('listener remains open')
        except ConnectionRefusedError:
            summary['listenerClosed'] = True
    except BaseException as error:
        errors.append(repr(error))
    finally:
        log.close()
    if primary:
        summary.update(status='FAIL', primaryError=repr(primary))
    if errors:
        summary.update(status='FAIL', cleanupErrors=errors)
    save('observations.json', observations)
    save('summary.json', summary)
    if errors and not primary:
        raise RuntimeError(errors)
print(json.dumps(summary, ensure_ascii=False, indent=2))
