package controllers;

import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import labactors.Counter;
import labactors.DeadObserver;
import org.apache.pekko.actor.ActorSystem;
import org.apache.pekko.actor.Props;
import org.apache.pekko.actor.typed.ActorRef;
import org.apache.pekko.actor.typed.DispatcherSelector;
import org.apache.pekko.actor.typed.MailboxSelector;
import org.apache.pekko.actor.typed.SupervisorStrategy;
import org.apache.pekko.actor.typed.javadsl.Adapter;
import org.apache.pekko.actor.typed.javadsl.AskPattern;
import org.apache.pekko.actor.typed.javadsl.Behaviors;
import play.inject.ApplicationLifecycle;
import play.libs.Json;
import play.mvc.*;

@Singleton
public final class ActorController extends Controller {
    private final ActorSystem system;
    private final Counter.Ledger normal = new Counter.Ledger();
    private final Counter.Ledger bounded = new Counter.Ledger();
    private final List<Map<String, String>> dead = new CopyOnWriteArrayList<>();
    private final CompletableFuture<Void> observerReady = new CompletableFuture<>();
    private final CompletableFuture<Void> observerStopped = new CompletableFuture<>();
    private final ActorRef<Counter.Command> actor;
    private final ActorRef<Counter.Command> mailbox;
    private final org.apache.pekko.actor.ActorRef observer;
    private final AtomicBoolean burstUsed = new AtomicBoolean();
    private final AtomicBoolean restartUsed = new AtomicBoolean();
    private final AtomicBoolean stopUsed = new AtomicBoolean();

    @Inject
    public ActorController(ActorSystem system, ApplicationLifecycle lifecycle) {
        this.system = system;
        actor = Adapter.spawn(system, Behaviors.supervise(Counter.create(normal))
            .onFailure(IllegalStateException.class, SupervisorStrategy.restart()), "lab-counter",
            DispatcherSelector.fromConfig("actor-lab-dispatcher"));
        mailbox = Adapter.spawn(system, Counter.create(bounded), "lab-bounded",
            DispatcherSelector.fromConfig("actor-lab-dispatcher").withNext(MailboxSelector.bounded(4)));
        observer = system.actorOf(Props.create(DeadObserver.class, dead, observerReady, observerStopped), "lab-dead-observer");
        lifecycle.addStopHook(() -> {
            system.stop(Adapter.toClassic(actor));
            system.stop(Adapter.toClassic(mailbox));
            system.stop(observer);
            return CompletableFuture.allOf(normal.stopped, bounded.stopped, observerStopped)
                .orTimeout(5, TimeUnit.SECONDS).thenApply(ignored -> {
                    try {
                        Path p = Path.of(System.getProperty("actor.evidence", "evidence/run"));
                        Files.createDirectories(p);
                        Files.writeString(p.resolve("cleanup.json"), Json.stringify(Json.toJson(Map.of(
                            "normalStopped", normal.stopped.isDone(), "boundedStopped", bounded.stopped.isDone(),
                            "observerStopped", observerStopped.isDone(), "system", system.name(),
                            "boundedProcessed", bounded.events.size(), "normalProcessed", normal.events.size()))));
                        return null;
                    } catch (Exception e) { throw new CompletionException(e); }
                });
        });
    }

    private CompletionStage<Counter.Reply> read() {
        return AskPattern.ask(actor, Counter.Read::new, Duration.ofSeconds(1), Adapter.toTyped(system).scheduler());
    }

    public Result stats() {
        return ok(Json.toJson(Map.of("normal", normal.events, "bounded", bounded.events, "dead", dead,
            "generation", normal.generations.get(), "observerReady", observerReady.isDone(),
            "normalStopped", normal.stopped.isDone(), "boundedStopped", bounded.stopped.isDone(),
            "system", system.name(), "actorPath", actor.path().toString(), "pid", ProcessHandle.current().pid())));
    }

    public CompletionStage<Result> ask(String id, int delay, int timeout) {
        if (!id.matches("[a-zA-Z0-9_-]{1,40}") || delay < 0 || delay > 500 || timeout < 10 || timeout > 2000)
            return CompletableFuture.completedFuture(badRequest("invalid finite input"));
        return AskPattern.<Counter.Command, Counter.Reply>ask(actor, reply -> new Counter.Work(id, delay, reply),
                Duration.ofMillis(timeout), Adapter.toTyped(system).scheduler())
            .handle((reply, error) -> error == null ? ok(Json.toJson(reply)) : status(504, error.getClass().getSimpleName()));
    }

    public CompletionStage<Result> burst() {
        if (!burstUsed.compareAndSet(false, true)) return CompletableFuture.completedFuture(status(409, "one burst per run"));
        CompletableFuture<Void> entered = new CompletableFuture<>();
        CountDownLatch release = new CountDownLatch(1);
        mailbox.tell(new Counter.Gate(entered, release));
        return entered.orTimeout(2, TimeUnit.SECONDS).thenApply(ignored -> {
            try {
                for (int i = 0; i < 20; i++) mailbox.tell(new Counter.Work("burst_" + i, 0, null));
                return ok(Json.toJson(Map.of("sent", 20, "capacity", 4)));
            } finally { release.countDown(); }
        });
    }

    public CompletionStage<Result> restart() {
        if (!restartUsed.compareAndSet(false, true)) return CompletableFuture.completedFuture(status(409, "one restart per run"));
        return read().thenCompose(before -> {
            actor.tell(new Counter.Crash());
            return read().thenApply(after -> ok(Json.toJson(Map.of("before", before, "after", after))));
        });
    }

    public CompletionStage<Result> stop() {
        if (!stopUsed.compareAndSet(false, true)) return CompletableFuture.completedFuture(status(409, "one stop per run"));
        system.stop(Adapter.toClassic(mailbox));
        return bounded.stopped.orTimeout(2, TimeUnit.SECONDS).thenApply(ignored -> {
            mailbox.tell(new Counter.Work("after_stop", 0, null));
            return ok("bounded actor stopped; post-stop message sent");
        });
    }
}
