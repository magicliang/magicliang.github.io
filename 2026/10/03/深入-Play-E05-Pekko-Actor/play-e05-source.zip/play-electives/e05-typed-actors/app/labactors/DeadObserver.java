package labactors;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import org.apache.pekko.actor.AbstractActor;
import org.apache.pekko.actor.DeadLetter;

public final class DeadObserver extends AbstractActor {
    private final List<Map<String, String>> events;
    private final CompletableFuture<Void> ready;
    private final CompletableFuture<Void> stopped;
    public DeadObserver(List<Map<String, String>> events, CompletableFuture<Void> ready, CompletableFuture<Void> stopped) {
        this.events = events;
        this.ready = ready;
        this.stopped = stopped;
    }
    @Override public void preStart() {
        getContext().getSystem().eventStream().subscribe(getSelf(), DeadLetter.class);
        ready.complete(null);
    }
    @Override public Receive createReceive() {
        return receiveBuilder().match(DeadLetter.class, dead -> {
            if (dead.message() instanceof Counter.Work work)
                events.add(Map.of("type", "work", "id", work.id(), "recipient", dead.recipient().path().toString()));
            if (dead.message() instanceof Counter.Reply reply)
                events.add(Map.of("type", "reply", "id", reply.id(), "recipient", dead.recipient().path().toString()));
        }).build();
    }
    @Override public void postStop() {
        getContext().getSystem().eventStream().unsubscribe(getSelf());
        stopped.complete(null);
    }
}
