package labactors;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.pekko.actor.typed.ActorRef;
import org.apache.pekko.actor.typed.Behavior;
import org.apache.pekko.actor.typed.PostStop;
import org.apache.pekko.actor.typed.javadsl.Behaviors;

public final class Counter {
    public interface Command {}
    public record Work(String id, int delay, ActorRef<Reply> replyTo) implements Command {}
    public record Read(ActorRef<Reply> replyTo) implements Command {}
    public record Crash() implements Command {}
    public record Gate(CompletableFuture<Void> entered, CountDownLatch release) implements Command {}
    public record Reply(String id, int count, int generation) {}
    public static final class Ledger {
        public final AtomicInteger generations = new AtomicInteger();
        public final List<Map<String, Object>> events = new CopyOnWriteArrayList<>();
        public final CompletableFuture<Void> stopped = new CompletableFuture<>();
    }

    public static Behavior<Command> create(Ledger ledger) {
        return Behaviors.setup(context -> {
            int generation = ledger.generations.incrementAndGet();
            int[] count = {0};
            return Behaviors.receive(Command.class)
                .onMessage(Work.class, work -> {
                    if (work.delay() > 0) Thread.sleep(work.delay());
                    count[0]++;
                    ledger.events.add(Map.of("id", work.id(), "count", count[0], "generation", generation,
                        "finishedNanos", System.nanoTime(), "thread", Thread.currentThread().getName()));
                    if (work.replyTo() != null) work.replyTo().tell(new Reply(work.id(), count[0], generation));
                    return Behaviors.same();
                })
                .onMessage(Read.class, read -> {
                    read.replyTo().tell(new Reply("read", count[0], generation));
                    return Behaviors.same();
                })
                .onMessage(Crash.class, crash -> { throw new IllegalStateException("synthetic-restart"); })
                .onMessage(Gate.class, gate -> {
                    gate.entered().complete(null);
                    if (!gate.release().await(2, TimeUnit.SECONDS)) throw new IllegalStateException("gate timed out");
                    return Behaviors.same();
                })
                .onSignal(PostStop.class, signal -> {
                    ledger.stopped.complete(null);
                    return Behaviors.same();
                }).build();
        });
    }
}
