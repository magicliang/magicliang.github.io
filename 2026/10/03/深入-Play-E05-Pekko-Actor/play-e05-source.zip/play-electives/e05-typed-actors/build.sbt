ThisBuild / scalaVersion := "2.13.15"
ThisBuild / organization := "example.playactors"
ThisBuild / version := "0.1.0"
lazy val root = (project in file(".")).enablePlugins(PlayJava).settings(
  name := "play-actors",
  libraryDependencies ++= Seq(guice, "org.apache.pekko" %% "pekko-actor-typed" % "1.0.3",
    "junit" % "junit" % "4.13.2" % Test, "com.github.sbt" % "junit-interface" % "0.13.3" % Test),
  Test / parallelExecution := false
)
