# Play E05: Typed Actor boundaries

Independent local-only Play 3.0.6 / Pekko Actor Typed 1.0.3 project. JDK 21, Scala 2.13.15, sbt 1.10.7. The controller injects Play's classic ActorSystem and spawns typed actors through Adapter.spawn; it does not create a second production ActorSystem. The standalone example and JUnit tests own isolated systems and await termination.

```sh
export JAVA_HOME=/path/to/jdk-21
export PLAY_LAB_SBT_LAUNCHER=/path/to/sbt-launch-1.10.7.jar
bash sbtw test stage
python3 verify.py evidence/run-new
```

Use a fresh evidence directory. The helper runs a stage binary on a random loopback port, records actual HTTP, and stops only its process. No database or external service is used. This fixture has a synthetic secret, disabled authentication, state-changing GET routes and an in-memory diagnostic ledger. Do not deploy it as a public service or load it without the finite harness.

The normal counter uses explicit restart supervision. A 30 ms ask expires while the actor handles a 300 ms synthetic blocking message on a dedicated two-thread dispatcher. The script first observes no completion after the HTTP 504, then observes the same message ID processed and its late reply sent to dead letters. No automatic cancellation is inferred.

The second actor has MailboxSelector.bounded(4). A controlled gate holds one message in processing while exactly 20 business messages are sent. Exactly four queue and sixteen appear as dead letters; the script checks that the two ID sets are disjoint and cover all 20 IDs. The gate has a two-second limit and is released in finally. Repeated burst, restart and stop invocations return 409 to prevent invalid reuse of a one-shot scenario.

The restart scenario checks state 2 before failure, state 0 / generation 2 after explicit restart, then state 1 after new work. The external experimental ledger still records earlier effects; this is not persistence and survives only while this process does. The stop scenario awaits PostStop, sends one additional message, and verifies its dead-letter ID while the other actor remains alive.

ApplicationLifecycle stops the two owned actors and the dead-letter observer, waits for each observed termination, and writes cleanup.json. The helper also verifies process exit and TCP refusal. Play owns ActorSystem shutdown; the controller never terminates that shared system itself.

The article's complete example can be compiled against the resolved stage dependencies:

```sh
mkdir -p evidence/example-classes
"$JAVA_HOME/bin/javac" -cp 'target/universal/stage/lib/*' -d evidence/example-classes ActorCounterExample.java
"$JAVA_HOME/bin/java" -cp 'evidence/example-classes:target/universal/stage/lib/*' ActorCounterExample
```

The in-memory ledger, deliberate Thread.sleep, and gate are instrumentation for finite experiments. They do not implement backpressure, durable delivery, idempotency, cancellation, cluster routing or production actor scheduling.
