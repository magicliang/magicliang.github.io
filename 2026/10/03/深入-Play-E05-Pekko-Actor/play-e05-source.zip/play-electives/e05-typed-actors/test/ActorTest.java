import java.time.Duration;
import java.util.concurrent.TimeUnit;
import labactors.Counter;
import org.apache.pekko.actor.typed.ActorSystem;
import org.apache.pekko.actor.typed.SupervisorStrategy;
import org.apache.pekko.actor.typed.javadsl.AskPattern;
import org.apache.pekko.actor.typed.javadsl.Behaviors;
import org.junit.Test;
import static org.junit.Assert.*;

public class ActorTest {
    @Test public void sameActorProcessesStateSequentially() throws Exception {
        Counter.Ledger ledger = new Counter.Ledger();
        ActorSystem<Counter.Command> actor = ActorSystem.create(Counter.create(ledger), "state-test");
        try {
            Counter.Reply a = AskPattern.<Counter.Command, Counter.Reply>ask(actor,
                r -> new Counter.Work("a", 0, r), Duration.ofSeconds(2), actor.scheduler()).toCompletableFuture().get();
            Counter.Reply b = AskPattern.<Counter.Command, Counter.Reply>ask(actor,
                r -> new Counter.Work("b", 0, r), Duration.ofSeconds(2), actor.scheduler()).toCompletableFuture().get();
            assertEquals(1, a.count());
            assertEquals(2, b.count());
        } finally { actor.terminate(); actor.getWhenTerminated().toCompletableFuture().get(3, TimeUnit.SECONDS); }
        assertTrue(ledger.stopped.isDone());
    }
    @Test public void supervisedRestartRecreatesVolatileState() throws Exception {
        Counter.Ledger ledger = new Counter.Ledger();
        ActorSystem<Counter.Command> actor = ActorSystem.create(Behaviors.supervise(Counter.create(ledger))
            .onFailure(IllegalStateException.class, SupervisorStrategy.restart()), "restart-test");
        try {
            actor.tell(new Counter.Work("before", 0, null));
            Counter.Reply before = AskPattern.<Counter.Command, Counter.Reply>ask(actor,
                Counter.Read::new, Duration.ofSeconds(2), actor.scheduler()).toCompletableFuture().get();
            actor.tell(new Counter.Crash());
            Counter.Reply after = AskPattern.<Counter.Command, Counter.Reply>ask(actor,
                Counter.Read::new, Duration.ofSeconds(2), actor.scheduler()).toCompletableFuture().get();
            assertEquals(1, before.count());
            assertEquals(0, after.count());
            assertEquals(2, after.generation());
            assertEquals(1, ledger.events.size());
        } finally { actor.terminate(); actor.getWhenTerminated().toCompletableFuture().get(3, TimeUnit.SECONDS); }
    }
}
