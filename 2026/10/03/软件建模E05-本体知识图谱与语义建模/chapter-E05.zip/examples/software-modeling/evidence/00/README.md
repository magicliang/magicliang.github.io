# 00 实验记录

判定：VERIFIED_LOCAL。Java 21 编译和 48 项显式检查通过；Java 8 入口拒绝通过。运行发生于 `environment.txt` 的 UTC 时间。日期标签来自教学输入，不代表运行时钟。

## 调用

工作目录：仓库根目录。

```bash
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn ./examples/software-modeling/run-lab.sh 00
JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/8.0.472-zulu ./examples/software-modeling/run-lab.sh 00
```

第一条 stdout/stderr 合并捕获到 `java21-output.txt`，原始退出码在 `java21-exit.txt`。第二条分别为 `java8-output.txt`、`java8-exit.txt`。其他机器替换 JAVA_HOME 为实际安装目录，不依赖这里的个人路径。

## 验收映射

| 场景 | 调用 | 二值判定与工件 |
| --- | --- | --- |
| 最小可运行 Java 21 基线 | 第一条 | `java21-exit.txt` 为 0；`java21-output.txt` 末行为 `PASS total=48` |
| 身份与时间值不可变 | 第一条的 javac 编译；读取 `rental-core/RentalDesk.java` | 四种输入为 Java record，字段只含 String、Instant、其他 record；`javac --release 21 -Xlint:all -Werror` 成功，源快照指纹在 `source-sha256.txt` |
| 空身份、空字段、零长、逆序区间拒绝 | 第一条 | 输出前九项均 PASS；例外类别明确，未抛或抛错类别均使进程非零退出 |
| 半开区间相邻接受、分离接受 | 第一条 | `[5,10)`、`[20,25)`、`[0,5)`、`[25,30)` 对 `[10,20)` 为 CONFIRMED |
| 部分重叠、包含、相同、共享单端点但内部重叠拒绝 | 第一条 | 七种冲突候选均为 OVERLAP_REJECTED |
| 不同设备互不冲突 | 第一条 | `PASS different equipment accepts same interval` |
| 同请求负载重试、变负载拒绝 | 第一条 | `same payload retry`、`changed interval`、`changed equipment` 全部 PASS |
| 取消释放、重复取消、未知取消、拒绝请求取消 | 第一条 | 四项取消检查 PASS；新请求成功占用释放区间 |
| 取消后旧请求不复活，失败请求结果稳定 | 第一条 | `retry after cancellation`、`rejected outcome remains stable`、`old retry did not rebook` 均 PASS |
| Java 8 不能产生假成功 | 第二条 | `java8-exit.txt` 为 2；`java8-output.txt` 含 JDK 21 required，未输出业务 PASS |

输入使用固定 UTC 基准 `2026-10-02T00:00:00Z` 加秒数。断言由 `check` / `expect` 显式抛错实现，不依赖 JVM 是否启用 assert。所有场景逐项原始输出保留在本目录。

边界：单线程、单进程、内存状态；没有数据库、服务端、并发或生产租赁系统验证。新建 Java、Shell 与实验文档未修改文章，因此不触发 `source/_posts/` 的散文双扫描。
