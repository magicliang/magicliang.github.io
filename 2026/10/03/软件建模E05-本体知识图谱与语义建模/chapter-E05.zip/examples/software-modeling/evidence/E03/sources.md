# Primary source record

Checked2026-10-03.

Official tlaplus GitHub release https://github.com/tlaplus/tlaplus/releases/tag/v1.7.4 browsed; fixed artifact SHA1 bee4a54f3ee3d4afc347c3240ec2d9e93b075104 verified against actual download, actualSHA256 locked. Project TLC docs https://docs.tlapl.us/using:tlc:start browsed for finite explicit-state checker and CLI. Actual binaryhelp/run banner checkedTLC2 2.19 rev5a47802. No latestversion claim; noAlloy execution. Model and diagrams are local original finite rental abstraction. Jar fromhttps://github.com/tlaplus/tlaplus/releases/download/v1.7.4/tla2tools.jar only.
