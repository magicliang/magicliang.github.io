# Pre-publication review

Entry: blog-editor. Ordered gate: anti-ai-tone → anti-persona-fabrication → exact draft publication.

Support pass: linked primary sources support only stated terminology and methods; implementation claims trace to own files and real output. Local teaching policy, finite scope, unimplemented capabilities and source concept are distinct.
Progression pass: concrete failure → representation → executed counterexample → constraints/limits → rerun. No repeated slogan or consultation filler.
Rhythm pass: tech profile; concrete records, variables, dates and outputs. No numbered prose ladder, over-bold text, stock metaphors or narrator voice.
Continuity pass: source facts and current implementation form continuous prose; no drafting dialogue or revision commentary.
Ten tone categories manually reviewed; tool warnings/errors zero. Then ten persona categories and three redlines reviewed; no personal narration/experience, anthropomorphism or storyteller framing. PASS.
