# Chapter 11 evidence

Primary invocation: `bash examples/software-modeling/labs/11/run.sh`. Python 3.14.4, standard library only; no environment-specific absolute paths are in reader commands. The model JSON is read relative to the script, not the caller's working directory. command.txt and environment.txt capture invocation/runtime. checks use explicit AssertionError and expected exceptions.

| Criterion | Exact scenario | Binary observable | Captured artifact |
|---|---|---|---|
| Physical equipment / runtime type object separation | `same-type-distinct-physical-identities`; `new-model-same-language-class`; `runtime-type-delegates-feature` | Distinct E1/E2 share one type; CAM-B retains same Python class; delegated waterproof result differs. | `output.txt`, `exit-code.txt` |
| Fixed enum versus runtime configuration | `fixed-enum-rejects-new-model`; `unknown-category` | CAM-B rejected by fixed model enum but constructed from runtime JSON; category remains intentionally closed. | `output.txt`, `exit-code.txt` |
| Wrong service classification | `camera-cannot-use-projector-service` | ValueError from category compatibility check. | `output.txt`, `exit-code.txt` |
| Specification revision and historical contract | `old-contract-original-price`; `old-contract-pinned-specification`; `old-price-stays-after-new-specification`; `new-contract-selects-new-specification`; `latest-spec-rejects-old-seven-day-term`; `naive-latest-rate-reprices-history` | Old agreed amount=70000; new contract=36000; incorrect latest-rate replay=84000; complete latest spec rejects 7 days. | `output.txt`, `exit-code.txt` |
| Overwrite and physical-upgrade counterexamples | `duplicate-specification-version`; `frozen-old-price-cannot-be-assigned`; `catalog-update-does-not-upgrade-physical-device`; `zero-day-service`; `separate-actual-services-share-specification` | Duplicate revision and normal mutation rejected; E1 stays non-8k; separate contracts can share a spec. | `output.txt`, `exit-code.txt` |
| Independent execution | Copy only labs/11 and models/11 under examples/software-modeling/ in a fresh temporary directory; run same invocation at extraction root | Exit 0 and 17 passing scenario records | isolated-output.txt, isolated-exit-code.txt |
| Prose before write | check_prose.py --profile tech --json article-draft.md, then anti-persona-fabrication scan/manual reading | Zero errors/warnings, no persona hits; digest matches published article | anti-ai-tone.json, persona-scan.json, PROSE-REVIEW.md |

Primary references and verified sections: sources.md. Executable fixture and documented assumption boundary: models/11/. Source hashes: source-sha256.txt. Artifact existence, counts and whitespace validation: artifact-check.json.

ZIP creation, final extraction tests, complete Hexo generation and browser checks are owned by the parent agent. The isolated-copy check is not represented as a ZIP/browser test.

Limits: local synchronous semantic experiments only; no persistent store, concurrency, global identity uniqueness, production integration or tamper-resistant audit guarantee. Detailed per-model omissions are in models/11/semantics.md.
