# 原始来源

2026-10-03实际web打开Evans官方DDD Reference页面及其PDF： https://www.domainlanguage.com/ddd/reference/ ，https://www.domainlanguage.com/wp-content/uploads/2016/05/DDD_Reference_2015-03.pdf 。核对Entities印刷页11（PDF18）、Value Objects页12（PDF19）的身份连续性、属性表达、不可变与无副作用行为。该文为2015模式摘要，不冒称2004原书全文。

Java21官方文档实际打开：
- https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/math/BigDecimal.html ：BigDecimal不可变，equals含scale，compareTo按数值；UNNECESSARY在需舍入时失败。
- https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/List.html#copyOf(java.util.Collection) ：不可修改列表不等于任意元素深度不可变。本文元素限定String。

设备生命周期、退役限制、有序标签、CNY/USD两位小数金额、允许有符号金额均为本章设计，不归为Evans或Java规定的租赁政策。EquipmentId与Period直接引用当前RentalDesk源码，未修改共享基线。
