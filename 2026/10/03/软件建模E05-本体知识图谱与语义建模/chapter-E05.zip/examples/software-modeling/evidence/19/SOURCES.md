# 19 原始资料核对

2026-10-03直接通过web.open/click读取，非只用搜索摘要：

- https://www.domainlanguage.com/ddd/reference/ ：官方说明该资料是定义/模式摘要，不能替代完整解释。
- https://www.domainlanguage.com/wp-content/uploads/2016/05/DDD_Reference_2015-03.pdf ：2015版，Eric Evans；Ubiquitous Language印刷页3—4（PDF页10—11），Refactoring Toward Deeper Insight印刷页8（PDF页15）。核对共享语言与代码脱节、用模型表达场景、将领域认识反馈到模型及实现、领域人员与开发者共同参与。正文短段意译，未复制原图。

客户角色、预约可用性、结算差额算法均为本文合成案例，不归于Evans原文。InitialCandidate不是共享Java核心的历史实现。无真实访谈、团队共识或生产效果材料。
