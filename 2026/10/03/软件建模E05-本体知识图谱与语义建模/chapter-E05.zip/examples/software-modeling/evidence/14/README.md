# 14 验证索引

公开入口：`bash examples/software-modeling/labs/14/run.sh`。原始stdout/stderr：`output.txt`，退出码：`exit-code.txt`（0）。记录环境以output首行为准。

| 场景/成功标准 | 二元可观察结果 | 原始证据 |
|---|---|---|
| 计划不占用、承诺非实际 | plan_alone_reserves_nothing=0、commitment_is_not_actual=0、plan_is_not_actual REJECT | output.txt |
| 类型容量按同时峰值判断、半开端点相邻可用 | general_capacity_conflict、general_adjacent、capacity_peak_not_overlap_sum、capacity_excess_on_subinterval PASS | output.txt |
| 指定实物身份/类型/重复与重叠约束 | specific_* PASS、wrong_type/duplicate_asset REJECT | output.txt |
| 取消释放资源保留回执、旧拒绝不重算、替换释放E1 | general_cancel_*、general_retry_*、general_replay_*、replacement_* PASS | output.txt |
| 部分履约不覆盖原承诺、实际后取消失败保持状态 | partial_fulfillment、promise_retained_after_partial PASS、cancel_after_actual REJECT | output.txt |

语法、模型图与正文一致、前章链接存在、正文摘录来自输出、稿件哈希一致检查见`static-checks.txt`。同入口从临时目录执行见`standalone-output.txt`/`standalone-exit-code.txt`。主动将未预留计划提交实际动作并任由CLI报错，见`negative-uncommitted.txt`/`negative-uncommitted-exit-code.txt`（非零）。

`anti-ai-tone.json`先于`anti-persona-fabrication.json`；人工复核去AI腔后再查虚构叙述，原始图与教学自定政策区分明确。扫描稿与文章SHA一致，见`source-hashes.sha256`。来源身份和单位界限见`SOURCES.md`。

本切片未执行Hexo构建、浏览器验图或zip重打包，交由root集成；无外部交付、并发或全局排程验证。未修改共享core/runner/README，未提交。
