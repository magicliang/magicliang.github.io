# 来源与实现归属

2026-10-03 实际 web 打开 Stephen Palmer，2009-12-04，An Introduction to Feature-Driven Development – Part 2：https://dzone.com/articles/introduction-feature-driven-2 。核对配对执行 Design by Feature / Build by Feature、按涉及类所有者组队、设计审阅、单元和 feature 测试、代码检查及提升到常规构建。原文不强制测试先后，也不指定固定构建节奏。

类所有权为责任而非永久排他，对照 Palmer 第一部分：https://dzone.com/articles/introduction-feature-driven （2009-11-20，实际打开全文）。正文保持概括，不引用其生产力结论。

延期规则、Python 实现、RED/GREEN 命令、12 项回归、SHA-256 临时目录集成都为本次实际构造和执行。教学角色由同一执行者模拟，无多人会议、签字、真实 FDD 组织采用或生产效率证据。模型使用整数日，不接入 Java rental-core。
