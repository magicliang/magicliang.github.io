# Chapter 08: review repair pre-write scan

Timestamp: 2026-10-03T09:59:17.935143+00:00
Order: blog-editor -> anti-ai-tone tech profile -> anti-persona-fabrication -> source Markdown copy.

Material/progression/continuity review: concrete teaching facts and scenario outputs retained; chapter08's invalid shape-test claim removed. Cancellation remains a semantic boundary with behavior coverage assigned to existing Java experiments, not proven here. No duplicate conclusion or editorial-history prose was inserted. Chapter10 article text is unchanged; narrower runtime annotations do not change its claims.

Tone script: errors=0; see anti-ai-tone.json. Second pass: ten persona symptom categories and three red lines reviewed; lexical hits=0; see persona-scan.json. Draft SHA256: 4590209a7b043fee85815cf5219a63e3e852b2bbc96675411d05885eff427e51.

Previous scan artifacts are historical under .omo/evidence/modeling-08-10/review-fix/superseded/08/; do not use them as current proof.
