# Source verification

Retrieved 2026-10-03. Source statements were checked directly, independently of earlier reports.

- https://www.omg.org/spec/BPMN/2.0.2/PDF: web open succeeded; title/version 2.0.2; section 8.4.13, printed p95 / PDF p125, Sequence Flow order of flow elements. Mermaid figure is explicitly illustrative; no executable BPMN claim.
- https://www.omg.org/spec/DMN/1.5/PDF: web fetch rejected 15,036,261-byte document because of size. Official specification landing page opened successfully. Read-only Python urllib download succeeded; pypdf extracted PDF p80, printed p72, section 8.2.11.1. Unique disjointness is separate from completeness; First is order dependent. Extract in dmn-source-excerpts.txt. No normative engine conformity claim.
- https://www.omg.org/spec/UML/2.5.1/PDF: web fetch rejected 18,069,510-byte document because of size. Official specification landing page opened successfully. Read-only urllib download succeeded; pypdf extracted chapter 14 state/event/guard sections in uml-source-excerpts.txt. Article uses only basic distinctions and explicitly omits event-pool/concurrency semantics.

Full downloaded PDFs are temporary research inputs; they are not included in the reader archive. No third-party tutorial was used as normative authority.
