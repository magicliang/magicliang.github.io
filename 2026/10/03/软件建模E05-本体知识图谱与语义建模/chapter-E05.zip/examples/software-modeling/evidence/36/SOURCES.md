# 一手来源核验
2026-10-03通过web直接打开及定位正文，未凭搜索摘要。
- https://martinfowler.com/apsupp/apchap8.pdf ：作者网站托管Pierre De Swert的原书第8章UML补充图；Fig8.13 Proposed/Implemented Action与资源分配，8.14 General/Specific Allocation。教学计划不占用、取消重放规则非原文保证。
- https://www.informit.com/content/images/013011510X/samplechapter/013011510X.pdf ：原书出版商第5章样章，印刷157页pink project/yellow roles，176–177页blue templates/green documents。租赁四种视角映射是教学推演。
- https://www.domainlanguage.com/wp-content/uploads/2016/05/DDD_Reference_2015-03.pdf ：Evans2015 Reference，Aggregates（PDF22页）同步维护边界内一致性与Repository封装讨论。Python串行字典不代表并发聚合保证。
- https://speakerdeck.com/agilesingapore/strategies-for-success-a-singapore-case-study-and-a-look-to-the-future-jeff-de-luca-agile-sg-2013 ：Jeff De Luca2013演讲第三张及transcript五流程名称。
- https://dzone.com/articles/introduction-feature-driven ：Stephen Palmer本人2009文章，总体模型广度先行、特征驱动迭代、四色不是强制，非借第三方转述作原始定义。
nebulon latestprocesses及fddprocessesA4 PDF直接访问失败，未用它们支撑正文。FDD门禁是教学追踪，不声称实际团队采用、工期或生产效率。
