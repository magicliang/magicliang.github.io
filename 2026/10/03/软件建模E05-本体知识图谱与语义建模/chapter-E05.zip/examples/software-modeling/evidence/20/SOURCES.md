# 20 原始资料核对

2026-10-03直接通过web.open读取：

- https://www.eventstorming.com/ ：官方定义协作探索复杂领域的灵活工作坊形式，并有不同用途/风格。
- https://www.eventstorming.com/book/ ：Alberto Brandolini原作者书页，集体学习目的；未把其写作状态推成固定出版版次。
- https://leanpub.com/podcasts/leanpub/alberto-brandolini-01-05-19 ：2019-05-01发布，2019-04-23录制；本人回答对应网页139—149行，事件片段/时间线/参与者纠正与例外；195行说明早期博客流程已不同于其当时做法。正文只短段意译这些方法说明，不复制人物经历。
- https://leanpub.com/introducing_eventstorming ：实际打开作者书页，目录含Hotspot及Commands主题。目录未作为章内方法细则证据。

资料缺口：样章PDF的S3/样章域名与在线read地址未成功获取，早期Blogspot直读被拦；未将搜索摘录冒充已读样章内容。本文不教授未经核验的原方法颜色和强制步骤；图用文字类别，JSON语法、同步政策和校验顺序明确为本章教学选择。

所有租赁动作/政策/热点来自单人合成输入；模型校验不证明业务发现、跨职能沟通或现实退款发生。H1/H2保持OPEN，owner_role仅是待确认职责，不是已分派任务。
