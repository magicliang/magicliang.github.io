# 一手资料核对

- 2026-10-03 直接读取 https://c2.com/doc/oopsla89/paper.html ，Beck/Cunningham, A Laboratory for Teaching Object-Oriented Thinking, OOPSLA 1989。
- §2：职责采用带主动动词的短语；协作者是发送或接收消息的对象，关系不一定对称。文章将此用于职责表，不把字段枚举当作 CRC。
- §3：从少量明确对象开始执行场景，缺少职责时补到已有对象或新增对象，避免为虚构的未来需求建对象。对应本篇两个候选以及清洁变化卡。
- §4：作者明确尚无 follow-up studies。文章不作因果生产率提升结论。
- 本文的租赁规则、Ledger/Schedule 候选和实验均为原创教学应用，原论文未给出这些租赁方案。

源码基线：examples/software-modeling/rental-core/RentalDesk.java；行为契约：README.md、models/00/three-models.md、models/01/scenarios-and-rules.md。03 SQL 是独立候选模型，不能宣称已经接入 Java。
