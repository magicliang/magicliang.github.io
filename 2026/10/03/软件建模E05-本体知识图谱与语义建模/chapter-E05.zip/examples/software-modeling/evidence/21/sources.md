# Source verification — 2026-10-03

- Primary author Adam Dymitruk, “Event Modeling: What is it?”, 2019-06-23: https://eventmodeling.org/posts/what-is-event-modeling/ . Browsed with web open. Read “A Model That Works”, “Commands”, “Views”, workshop steps and “Elaborate Scenarios”: fields follow input/storage/output paths; commands and views receive explicit scenarios; implementation is not fixed by the information blueprint. Article paraphrases briefly; own rental example, lineage checks and state-table implementation are teaching additions. Does not claim Event Sourcing implementation or verified real workshop.
- Official EventStorming site: https://www.eventstorming.com/ . Browsed with web open: collaborative exploration includes business flows, architecture and software design. Used to avoid false dichotomy that EventStorming is merely sticky-note brainstorming or cannot contain commands/read models.
- Repository plan: writing-plans/软件建模-从业务语义到领域模型与模型驱动开发-系列写作计划.md, chapter21 acceptance.

No original figure is copied. Both diagrams were authored for the executed teaching scenario. Source retrieval used extracted web text; no browser rendering claim.
