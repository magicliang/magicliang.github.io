from pathlib import Path
import hashlib
import os
import subprocess
import tempfile
import zipfile

root = Path(__file__).resolve().parents[4]
base = root / 'examples/software-modeling'
article = root / 'source/_posts/2026-10-03-软件建模01-场景用例与规则.md'
archive = article.with_suffix('') / 'scenarios.zip'
expected_article = '656be75bfb7dab8527d9b1989dcc1be1fed0a2089e265d76cf7a9892a7cde9d5'
assert hashlib.sha256(article.read_bytes()).hexdigest() == expected_article
assert '(scenarios.zip)' in article.read_text()
files = [base / name for name in ('README.md', 'run-lab.sh', 'rental-core/RentalDesk.java')]
for kind in ('labs', 'models', 'evidence'):
    for chapter in ('00', '01'):
        files.extend(p for p in (base / kind / chapter).rglob('*')
                     if p.is_file() and p.name != 'check-package.py')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as bundle:
    for path in sorted(files):
        bundle.write(path, path.relative_to(root))
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for name in bundle.namelist():
        path = Path(name)
        assert name.startswith('examples/software-modeling/') and '..' not in path.parts
        if path.parts[2] in ('labs', 'models', 'evidence'):
            assert path.parts[3] in ('00', '01')
    print('PASS archive path and chapter scope; files=' + str(len(bundle.namelist())), flush=True)
env = dict(os.environ, JAVA_HOME='/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn')
with tempfile.TemporaryDirectory(prefix='modeling-01-unpack-') as temporary:
    subprocess.run(['unzip', '-q', str(archive), '-d', temporary], check=True)
    commands = [(['./examples/software-modeling/run-lab.sh', '00'], 'PASS total=48'),
                (['bash', 'examples/software-modeling/run-lab.sh', '01'], 'PASS total=20'),
                (['bash', 'examples/software-modeling/labs/01/run.sh'], 'PASS total=20')]
    for command, last_line in commands:
        print('CWD=' + temporary, flush=True)
        print('COMMAND=' + ' '.join(command), flush=True)
        result = subprocess.run(command, cwd=temporary, env=env, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        print(result.stdout, end='', flush=True)
        print('EXIT_CODE=' + str(result.returncode), flush=True)
        assert result.returncode == 0 and result.stdout.rstrip().endswith(last_line)
assert hashlib.sha256(article.read_bytes()).hexdigest() == expected_article
print('PASS current article hash=' + expected_article)
print('PASS archive sha256=' + hashlib.sha256(archive.read_bytes()).hexdigest())
print('PASS integration package validation')
