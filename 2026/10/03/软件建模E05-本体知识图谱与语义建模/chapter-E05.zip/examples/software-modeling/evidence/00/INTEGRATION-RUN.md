# 00 入口集成复跑

扩展共享入口支持已实现章节后，重新运行 00。

命令：`shasum -a 256 examples/software-modeling/rental-core/RentalDesk.java examples/software-modeling/labs/00/BaselineCheck.java examples/software-modeling/run-lab.sh`，随后 `JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn bash examples/software-modeling/run-lab.sh 00`。

退出码：0。下列原始输出来自该次执行。原 source-sha256.txt 记录首次 00 验证的入口；这里只改变章节分发，00 行为仍由原检查回归。

```text
3b3c488738ad84e50db33e57fe91413617a719eeec96886a0d7e5c4acf9aaf00  examples/software-modeling/rental-core/RentalDesk.java
a676c6cc0d5e43e54265060d9a1cfb1688e8ca40734a7728d7d77ce911415c68  examples/software-modeling/labs/00/BaselineCheck.java
bd2a55d0afe6eadac7f8716b30c5b2d19a74e22a313518cb91d5f93cda2716bc  examples/software-modeling/run-lab.sh
PASS blank equipment id -> IllegalArgumentException
PASS null request id -> IllegalArgumentException
PASS zero-length interval -> IllegalArgumentException
PASS reversed interval -> IllegalArgumentException
PASS missing start -> NullPointerException
PASS missing end -> NullPointerException
PASS missing request identity -> NullPointerException
PASS missing equipment identity -> NullPointerException
PASS missing period -> NullPointerException
PASS reference booking 0
PASS interval [5,10) against [10,20): CONFIRMED
PASS reference booking 1
PASS interval [20,25) against [10,20): CONFIRMED
PASS reference booking 2
PASS interval [0,5) against [10,20): CONFIRMED
PASS reference booking 3
PASS interval [25,30) against [10,20): CONFIRMED
PASS reference booking 4
PASS interval [5,11) against [10,20): OVERLAP_REJECTED
PASS reference booking 5
PASS interval [19,25) against [10,20): OVERLAP_REJECTED
PASS reference booking 6
PASS interval [12,18) against [10,20): OVERLAP_REJECTED
PASS reference booking 7
PASS interval [5,25) against [10,20): OVERLAP_REJECTED
PASS reference booking 8
PASS interval [10,20) against [10,20): OVERLAP_REJECTED
PASS reference booking 9
PASS interval [10,15) against [10,20): OVERLAP_REJECTED
PASS reference booking 10
PASS interval [15,20) against [10,20): OVERLAP_REJECTED
PASS initial request confirmed
PASS same payload retry returns original outcome
PASS changed interval under reused id rejected -> IllegalArgumentException
PASS changed equipment under reused id rejected -> IllegalArgumentException
PASS failed changed payload leaves original booking active
PASS different equipment accepts same interval
PASS unknown cancellation changes nothing
PASS rejected request has no booking to cancel
PASS cancellation releases original booking
PASS repeated cancellation reports no active booking
PASS retry after cancellation retains original outcome
PASS rejected outcome remains stable after availability changes
PASS rejected request id cannot change payload -> IllegalArgumentException
PASS new request uses released interval; old retry did not rebook
PASS replacement booking protects released interval again
PASS null request rejected -> NullPointerException
PASS null cancellation rejected -> NullPointerException
PASS total=48
```
