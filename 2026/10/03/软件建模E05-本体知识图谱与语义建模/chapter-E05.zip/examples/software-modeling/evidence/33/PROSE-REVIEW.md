# Pre-publication prose review

Entry: blog-editor. Sequence: anti-ai-tone → anti-persona-fabrication → exact draft copy.

Support: external pattern intent comes from the linked author pages; concrete implementation statements trace to own source and raw behavior logs. Original pattern inheritance is separated from local composition. Added reason policy and renamed state are explicit teaching changes.
Progression: concrete behavioral failure precedes mechanism, boundary and rerun. Each paragraph adds a test, consequence, source boundary or limit.
Rhythm: tech profile; concrete fields/operations, ordinary paragraphs, no numbered prose ladder, bold emphasis, metaphor chains or slogan ending.
Continuity: no review dialogue, drafting history or first-person process claims.
Ten AI-tone categories manually checked after four positive passes; helper errors=0/warnings=0.
Ten persona categories and three redlines manually checked after tone scan. No fabricated body, time investment, relationship, personal experience, writing narration or identity. No anthropomorphic software narration. PASS.
