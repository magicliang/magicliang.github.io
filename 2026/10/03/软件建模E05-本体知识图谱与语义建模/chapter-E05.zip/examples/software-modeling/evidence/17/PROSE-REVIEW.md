# 预落盘审查

入口：blog-editor；只使用与正文有直接解释关系的 Mermaid，不额外获取装饰封面。所需技能与 prose-quality.md 已读取。

第一遍 anti-ai-tone：材料支撑来自原作者三份已打开材料、plan.json 与真实检查输出；段落推进从业务结果到对象关系、feature 映射、依赖与容量、实际负例；没有空泛组织效果结论。长句警告拆句后重跑，最终 errors=0、warnings=0，正文汉字2404。

第二遍 anti-persona-fabrication：扫描并通读，非人称陈述，无编造作者经历、业务采访、多人评审或拟人化程序。责任角色与 slot 明示教学选择。

扫描顺序、时间和哈希见 anti-persona-fabrication.json；落盘文件与草稿逐字相同，见 publication.json。post_link 在落盘时全部已存在。2404字口径为技能检查器正文统计，不含代码、图与 front matter。
