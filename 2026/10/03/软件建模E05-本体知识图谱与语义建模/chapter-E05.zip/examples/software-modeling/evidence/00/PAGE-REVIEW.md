# 00 页面验证

隔离生成命令：`node examples/software-modeling/build-pages.cjs`。首次生成仅包含 00 篇，Hexo 退出 0，日志没有 ERROR。私有源、缓存和输出，不修改共享 public、db.json，也不评审其他系列。

静态检查：标题正确，8 个表格，两个 Mermaid 源块，两个附件文件都在本页目录内；baseline.zip 具有有效 ZIP 文件签名。初检误用绝对路径及 class 完全匹配导致断言失败，修正检查器的相对路径解析及 class token 检查后通过，文章无须据此修改。

在 Codex 内置浏览器打开 localhost 页面，点击目录“流程模型：一次请求走哪条分支”。看到预留、回执与载荷比较流程，文字和箭头可辨；概念图也已转成 SVG。DOM 实际 SVG ID 为 mermaid-0、mermaid-1，无 Syntax/Parse error；8 张表格和两个教学附件链接出现在文章区域。附属类名在渲染后发生变化，使用 SVG 而非原始 .mermaid class 判定。

环境：Node.js 22.22.2，npm 10.9.7，页面页脚 Hexo 8.1.2、Butterfly 5.6.1。浏览器观察证明页面呈现，不证明业务并发或生产环境。

增加 00→01 系列导航后的最终生成记录另存本目录。整站构建与部署 NOT_RUN；本次只验收这两个系列。
