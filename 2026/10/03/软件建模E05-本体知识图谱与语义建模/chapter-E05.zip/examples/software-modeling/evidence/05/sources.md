# 一手资料核对

- 直接访问 https://www.omg.org/spec/UML/2.5.1 ，官方入口列 formal/17-12-05 PDF，版本采用日期 2017-12。
- 网页工具拒绝18MB PDF后，执行 `curl -L --fail --max-time 80 https://www.omg.org/spec/UML/2.5.1/PDF -o /tmp/modeling-uml-2.5.1.pdf`，实际下载成功；以 Python pypdf 6.16.2 读取正式 PDF。未复制完整版权资料到文章附件。
- §11.4 Classes，印刷194–195页（PDF236–237页）：类的结构/行为特征及操作；类图采用实现投影。
- §11.5 Associations，印刷199–201页（PDF241–243页）：实例链接、关联端、多重性约束链接集合数量、可导航性；文章按实际字段/集合值及对象共享分析关系，未宣称泛型推导完整多重性。
- §17.3 Lifelines，印刷572页（PDF614页）：生命线事件次序，纵向距离无实际时间度量意义。
- §17.4 Messages，印刷574–575页（PDF616–617页）：消息签名引用 Operation 或 Signal，名字相符；同步调用与返回。本文明确只检查 Mermaid 中声明的方法签名子集。

实际方法与类型通过当前 RentalDesk.class 的 reflection 校验；返回标注按擦除后的 Class 精确检查，boolean 映射原始类型。Map 与私有 Receipt 均来自当前实现，未创造 Repository 接口。
