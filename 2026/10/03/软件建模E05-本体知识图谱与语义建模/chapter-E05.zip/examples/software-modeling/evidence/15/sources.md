# Source checks for chapters 15–16

Primary source: Peter Coad, Eric Lefebvre, Jeff De Luca, Java Modeling in Color with UML, publisher chapter5 sample, printed154–181 (28 PDF pages): https://www.informit.com/content/images/013011510X/samplechapter/013011510X.pdf

Web text opened and inspected in this writing turn:
- 5.1.1, printed157 / PDF page index3: pink Project and ProjectActivityRequest; yellow role links; green ActivityRequestPool. The request itself is NOT the green request pool.
- 5.2.1, printed167 / index13: green accounts; yellow holder roles; pink exchange rate links blue currency-pair description. Used for a compact color boundary example only; no accounting implementation included.
- 5.3.1, printed176–177 / indices22–23: blue document templates, green documents; both link to versions.
- 5.3.2, printed178–179 / indices24–25: document build/approval/release/access are moment-interval activities. No complete document-management implementation claimed.

Three web screenshot requests returned unsupported/content-type errors. No image-level multiplicities were inferred. Chapter1 mirror was not relied upon. The local graphs are original rental teaching sketches; no source diagrams or extended prose copied.

Attribution boundary: original archetype/component examples above come from the publisher. Rental half-open periods, stable identities, revision pinning, compatibility checks, extension/substitution validation and in-memory update order are teaching choices validated by the own chapter labs. No concurrency, durable transactions, legal authority or production behavior inferred from sources.
