# Pre-publication prose review

Entry: blog-editor. Order: anti-ai-tone, then anti-persona-fabrication, then copy checked draft to post.

- Support: primary-source method statements have direct links; rental amounts/periods and assumptions are explicitly teaching additions, and execution claims match raw lab output.
- Progression: concrete discrepancy → declared inputs/rules → mechanisms → negative scenarios → limitations and rerun; no paragraph kept solely as a summary slogan.
- Rhythm: technical prose profile, concrete subjects and operations, no bold emphasis repetition or numbered prose ladder. Tables compare real fields/semantic conditions.
- Continuity: final article contains no editorial history or review dialogue. Two diagrams explain the actual tested path/boundaries and their exclusions.
- Persona: manually read all ten symptom categories and three redlines; no first-person narration, invented lived experience, workshop participation claim or storyteller framing. PASS.

Automated tone findings and the lexical persona aid are separate artifacts; the latter is not claimed to replace manual review.
