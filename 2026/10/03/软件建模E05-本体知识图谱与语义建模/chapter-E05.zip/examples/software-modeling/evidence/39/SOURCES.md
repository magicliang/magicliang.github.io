# 39 primary sources
2026-10-03 web直接打开并定位：
- https://martinfowler.com/eaaDev/AccountingEntry.html 2005-01-22草稿，变更数量、新记录、与引起变化事件的关系；原书Account/Entry组织与后期草稿不同。这里只借显式调整依据，未实现会计事务。
- https://martinfowler.com/eaaDev/RetroactiveEvent.html 原始草稿，过去事实修正及后续处理；本文只增量调整，不称完整retroactive event engine或事件重放实现。
所有三张变化卡、操作号重试、候选快照、迁移版本、同类设备/开始前修订限制均为本地教学政策，非作者方法自动保证。没有财务或法律合规主张。
