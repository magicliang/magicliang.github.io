# 28 正文预落盘扫描

入口采用blog-editor，草稿在article-draft.md。按anti-ai-tone → anti-persona-fabrication顺序扫描后，由.omo/evidence/modeling-27-28/finalize.py写入正式source/_posts文件。tone为tech profile，0 errors / 0 warnings；persona词项扫描无命中，人工通读无第一人称叙事、拟人化、说书人腔、领域访谈或生产经历虚构。时间顺序保存在anti-persona-fabrication.json。

正文2536汉字，两个Mermaid图；post_link目标逐一确认已存在。正式稿与已扫描草稿哈希相同：00e5b27ff464f8a0e1d51b272bda72787af4266dee9dd34475dcb7e90bf5b61e。

机制描述均对应实际Java代码；27区分受信内存仓储与数据库、提交前回滚与提交后发布失败；28保留真实InlineAdmission对照并比较48条完整轨迹。错误ACTIVE-only方法明确为构造反例，不虚构已有章节缺陷。新模型无保养缓冲等暗增规则；限制与观察范围已写入正文。独立review和站点/ZIP验证由主任务后续完成。
