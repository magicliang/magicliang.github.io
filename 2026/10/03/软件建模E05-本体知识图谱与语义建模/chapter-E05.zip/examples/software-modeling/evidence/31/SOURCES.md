# 31 一手来源核验

2026-10-03直接web.open读取OMG《MDA Guide Version1.0》2003-05-01，文档号omg/2003-05-01：https://www.omg.org/mda/mda_files/MDA_Guide_Version1-0.pdf 。核对2.2.9—2.2.15的平台相对独立、CIM/PIM/PSM、模型转换；3.8转换记录的源目标关联（PDF第25页）。正文明确引用这个历史版，不声称引用最新版。

OMG MDA specs页面可读：https://www.omg.org/mda/specs.htm 。其中2.0 Guide链接请求失败，未依赖其正文，也未将页面过时的UML版本说明当作当前规范。本文具体转换是自定义JSON+Python教学链，无MOF/XMI/QVT符合性声明。

业务条款、词汇表、映射决策、损失清单与执行结论来自本章源码/输入/日志。来源指南解释视角，不证明本地转换正确或业务授权已实现。
