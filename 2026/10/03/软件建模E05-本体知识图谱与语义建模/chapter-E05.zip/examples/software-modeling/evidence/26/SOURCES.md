# 26 来源核验

2026-10-03 通过 web.open/find 直接读取以下原文。

- Eric Evans, DDD Reference (2015-03), Services印刷页14、Factories印刷页18（PDF第21/25页）：https://www.domainlanguage.com/wp-content/uploads/2016/05/DDD_Reference_2015-03.pdf 。核对不自然属于Entity/VO的领域操作、命名服务契约，以及完整创建对象并维护不变量。未把原文interface一词机械解释为必须增加Java interface。
- Eric Evans & Martin Fowler, Specifications，第1—3页：https://martinfowler.com/apsupp/spec.pdf 。核对作者、条件与候选分离、选择/验证/按条件构建用途、硬编码/参数化/组合策略。文档首部无印刷年份，本篇不猜测年份；只实现参数化租期规则。

提前一小时、最长48小时、不足小时向上计费、revision标签均为本篇教学政策，不归因于原书。Money行为以 labs/24/Money.java 实码为准；计费和失败来自 run.txt / negative.txt，不以原文代替执行证据。
