# 05 验证记录

完整调用见 command.txt。默认入口编译当前 RentalDesk 与检查器，读取实际 classes.mmd/cancel-replay.mmd，核对操作的 Java 名称/参数/返回类型、已声明消息端点与操作、六条关联字段类型与固定多重性。output.txt 含 PASS class_operations_receivers_associations；exit-code.txt 为 0。

负例：默认套件检测缺少 previous 接收者、Receipt.refund() 不存在、bookings 多重性错误；独立 CLI 以 missing-receiver.mmd、missing-method.mmd 作为输入，分别产生 missing-receiver-output.txt、missing-method-output.txt 异常及对应 *-exit.txt 的 1。意外通过为失败。实际行为探针执行 A 确认→取消→重放→新 F 同时段，F=CONFIRMED；必填设备为空构造失败。

M1 关联边界回归：六条合法关系须各出现一次，拒绝额外关系和重复关系。conflicting-association、unknown-association、duplicate-association 三份模型先在修复前重现退出0（*-before-output.txt、*-before-exit.txt），修复后独立 CLI 均退出1（*-output.txt、*-exit.txt），前两者报告 unsupported association，后者报告 duplicate association。默认套件同时增加这三项 DETECTED；旧接收者/方法负例已重跑。

返回类型回归：wrong-return-type.mmd 将 cancel(RequestId) boolean 改成 Outcome；wrong-return-type-before-output.txt 与 wrong-return-type-before-exit.txt 记录修复前误通过0。增加 boolean 原始类型映射并精确比较反射 getReturnType 后，wrong-return-type-output.txt 记录 return type mismatch RentalDesk.cancel，wrong-return-type-exit.txt 为1。最终默认套件包括七类变异且退出0，所有六个独立 CLI 负例均在最终实现上重跑。

prose-review：PROSE-REVIEW.md 记录两轮顺序，JSON 保存扫描结果和正文草稿哈希；post-model-check.txt 核对正文与草稿、两个 Mermaid 块与模型文件逐字一致。source-sha256.txt 标记验证源文件。

限制：自定义 Mermaid 子集，不是完整 UML 校验；完整泛型、返回标签、调用顺序和运行时消息跟踪未自动验证。源码人工核对已记录在 subset.md 与正文。共享构建、浏览器和 ZIP 由主代理集成。
