# 37 primary sources
2026-10-03 web直接打开并定位：
- https://www.domainlanguage.com/wp-content/uploads/2016/05/DDD_Reference_2015-03.pdf 印刷34/PDF40页Anticorruption Layer：以下游模型表达上游功能、必要方向翻译。
- https://martinfowler.com/bliki/StranglerFigApplication.html 2024修订页：行为难还原、分批替换、过渡结构；正文的迁移政策与字段解释是合成教学设计。
- https://martinfowler.com/articles/patterns-legacy-displacement/ Cartwright/Horn/Lewis原始文章，目标、拆分、增量交付和组织改变；用于核对方法范围，未复用其案例或效率数据。
23/28/34仓库合同只读；并未宣称把34结构反向推导成业务真相。CSV和旧谓词均为本次合成，但函数确实执行。
