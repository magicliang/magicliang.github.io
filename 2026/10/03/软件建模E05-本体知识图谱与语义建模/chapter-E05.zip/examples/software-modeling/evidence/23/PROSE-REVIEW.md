# 23 正文预落盘复核

入口采用 blog-editor；草稿先保存为 article-draft.md。正式 source/_posts 文件由 .omo/evidence/modeling-23-24/finalize.py 在扫描完成后写入。

1. anti-ai-tone：tech profile，0 errors、0 warnings，详见 anti-ai-tone.json。
2. anti-persona-fabrication：在第一步结束后执行词项扫描并通读；无第一人称经历、供应商访谈、真实团队协商或生产效果的虚构。时间顺序与草稿哈希见 anti-persona-fabrication.json。
3. publication.json：正文 2404 汉字、2 个 Mermaid 图；所有 post_link 指向已存在文章。正式稿与受检草稿 SHA-256 相同：54c3ced3104a61eedc573326d2b23b6d6bb95e0b053c67efad0d86c02f356816。

教学业务规则与 Evans 原文模式分开。23 的组织关系是场景设定，程序只证明 DTO 翻译和拒绝规则；24 的设备生命周期与 CNY/USD 金额精度是教学契约，原始 RentalDesk 未接入生命周期门禁。没有将局部实验描述为真实供应商、生产并发或完整 DDD 项目的验证。来源核验入口见 SOURCES.md。

本项为作者自查，独立审查、下载 ZIP 与页面渲染由主任务另验收。
