# DSL version1; model sha256=9aec55d3cdf99f3d40774ce1cf42ee5f1ba041dc9a1dfa1e073e624e82566468
INITIAL = 'INSPECTION_REQUIRED'
TRANSITIONS = {('ACTIVE', 'requireInspection'): 'INSPECTION_REQUIRED', ('ACTIVE', 'retire'): 'RETIRED', ('INSPECTION_REQUIRED', 'approveInspection'): 'ACTIVE', ('INSPECTION_REQUIRED', 'retire'): 'RETIRED'}

def step(state: str, operation: str) -> str:
    try:
        return TRANSITIONS[(state, operation)]
    except KeyError as error:
        raise ValueError('OPERATION_NOT_ALLOWED') from error
