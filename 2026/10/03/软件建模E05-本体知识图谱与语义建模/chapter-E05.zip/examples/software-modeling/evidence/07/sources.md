# Source verification

Retrieved 2026-10-03 with web open/find against official Java 21 documentation.

- https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/time/LocalDate.html: class description states no time or time zone; requires extra zone/offset information to represent an instant. atStartOfDay(ZoneId) chooses earliest valid time under zone rules. The 23-hour specific date is supported by fresh ValueCheck output, not inferred solely from documentation.
- https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/math/BigDecimal.html: equals requires equal value and scale; compareTo compares numerical value; setScale with explicit RoundingMode controls rounding. Fresh output checks 10.005 with HALF_UP and HALF_EVEN plus implicit-rounding rejection.

Synthetic Money/Quantity/Revision constraints are authored teaching decisions, not presented as Java API guarantees or production business rules.
