# 36 实验记录

命令 bash examples/software-modeling/labs/36/run.sh；Python3.14.4标准库，无外部依赖。模型限制与语义见models/36/contracts.md。

|场景|参数|二元观察|原始工件|
|---|---|---|---|
|3候选同8场景及2门禁|无|24个预期结果+2门禁符合，退出0|run.txt/run.exit|
|Flat交付门禁|flat|三个feature false，退出1|negative-flat.txt/.exit|
|Semantic交付门禁|semantic|取消重放false，退出1|negative-semantic.txt/.exit|
|Bounded交付门禁|bounded|三个feature true，退出0|gate-bounded.txt/.exit|
|独立目录|绝对路径run.sh，从/private/tmp|完整报告，退出0|standalone.txt/.exit|

standalone指定PYTHON_BINARY=/opt/homebrew/opt/python@3.14/bin/python3.14。变化卡目录v1=10改v2=15：Flat旧2h价20→30；另外两候选旧价20不变，新2h价30。两角色A/requester B/payer真实查询比较。默认通过表示预期缺陷已复现，不表示所有候选可交付。

无并发、持久化或完整FDD组织实验。article-draft.md先AI扫描再persona扫描后首次发布；source-hashes.sha256及static-checks.json锁稿。ZIP/Hexo/browser由集成者负责，本证据未覆盖。
