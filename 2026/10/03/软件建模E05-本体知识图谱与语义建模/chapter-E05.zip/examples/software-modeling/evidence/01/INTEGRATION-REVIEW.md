# 01 集成修订复核

范围：源文章、下载附件和本章证据。未修改共享 runner/core、其他章节或提交。

## 正文版本与历史边界

当前文章：source/_posts/2026-10-03-软件建模01-场景用例与规则.md。

- 当前 SHA-256：`656be75bfb7dab8527d9b1989dcc1be1fed0a2089e265d76cf7a9892a7cde9d5`，2678 个 Unicode Han 字符（含 front matter）。
- 原 article-draft.md SHA-256：`310aa381a0412ff33d6fa61cf6273181f976d7e1ca04147cfb69d03806f86886`，2642 个 Han 字符。
- 实际差异只有两处：主任务增加 scenarios.zip 下载说明；主任务将前篇 post_link 的目标从带日期文件名改为无日期 Hexo slug `软件建模00-模型帮助作出什么决定`。

当前文章与原草稿不相等。artifact-check.json 的 article_matches_reviewed_draft=true、review-order.md 的一致声明以及原始 receipt 只描述上述原草稿哈希当时的初次落盘，不能用于证明当前文章逐字相等。保留这些历史记录，不改写既往结果。本文件及 integration-* 工件是本轮集成复核；本轮没有重新声称全站生成或浏览器检查完成。

## 重新顺序审稿

1. anti-ai-tone：运行 `python3 /Users/magicliang/.codex/skills/anti-ai-tone/scripts/check_prose.py --profile tech --json source/_posts/2026-10-03-软件建模01-场景用例与规则.md`。真实输出 integration-anti-ai-tone.json：0 errors，1 warning；命中的“第 2—4 节”是来源节号范围，保留。逐段人工复核：正文仍按目标、场景、规则来源、回执反例、实测、未决项推进；新下载说明只是定位附件，无未支撑的性能或生产结论；post_link 修复只改变定位符。
2. anti-persona-fabrication：在第1步完成后逐段复核，再执行字符串辅助扫描，实际输出 integration-persona-scan.json。无第一人称叙事、身体情绪、虚构社交、虚构采访、写作过程或说书过门；测试输入 UTC 时刻和20项通过仍对应真实实验；授权与清洁仍明确未决。没有重写正文。

## 附件范围与验证方式

scenarios.zip 中每个文件使用 `examples/software-modeling/` 仓库相对前缀。只收录 README、共享入口和本例核心，以及 labs/00、labs/01、models/00、models/01、evidence/00、evidence/01；不收录其他章节或编译产物。

在全新临时目录解压，然后从解压根目录执行 README 的00命令、共享入口01命令和正文的独立01命令。临时目录外的仓库源码不能被这些命令引用。真实运行输出保存在 .omo/evidence/modeling-01/integration-package-check.txt；成功条件是00末行 PASS total=48，两种01入口均 PASS total=20，全部进程退出码0，ZIP清单前缀/章节范围断言通过，打包后源文章哈希仍等于本记录。

下载包校验脚本是 evidence/01/check-package.py。它显式列举根文件和00/01目录；为了避免包含校验输出的循环归档，外部验收日志及此脚本不收录到ZIP。ZIP中的历史证据按本节版本边界理解。
