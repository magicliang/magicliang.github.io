# Primary-source verification — 2026-10-03

- Martin Fowler, Domain Specific Languages author page: https://martinfowler.com/books/dsl.html . web open read small language focus and external/internal DSL distinction. This lab uses a JSON-based external representation with independently defined semantics, not a custom textual grammar or universal DSL toolkit.
- Douglas C. Schmidt, Model-Driven Engineering, 2006 p27, author-hosted https://www.dre.vanderbilt.edu/~schmidt/PDF/GEI.pdf . web open read metamodel relation/constraint discussion. Python dataclasses and validation are original teaching realization, not a prescribed standard implementation.
- RFC8259 §4/§6: https://www.rfc-editor.org/rfc/rfc8259 . web open verified object-name SHOULD uniqueness, divergent duplicate-name handling, and rejection of NaN/Infinity by JSON grammar. Our strict duplicate-key rejection is explicitly an entry policy, not misquoted RFC MUST.
- OMG MOF2.5.1 about page https://www.omg.org/spec/MOF/2.5.1/About-MOF was inspected as reference boundary only; no normative MOF clause or conformance claim is made in the article.
- Repository chapter24 lifecycle contract supplies the separate validate_equipment_contract gate; generic FSM constraints do not define all domain validity. models/30/contracts.md is the frozen downstream API.

No original diagrams copied. All invalid JSON/model samples and wrong-policy fixture are synthetic teaching inputs; local tests prove finite examples, not security or universal semantic correctness.
