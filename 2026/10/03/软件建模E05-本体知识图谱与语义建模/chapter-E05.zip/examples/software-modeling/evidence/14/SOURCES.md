# 原始资料核对

核对日期：2026-10-03。web.open 直接解析 https://martinfowler.com/apsupp/apchap8.pdf 全文，8页，标题 UML Diagrams for Chapter 8 of Analysis Patterns，署名 Pierre De Swert，托管于Fowler站点。正文未给此补充虚构出版日期。

定位：PDF第6页的图8.13，Proposed Action / Implemented Action 与 Resource Allocation 的 books / uses 关系；第7页图8.14，General / Specific Resource Allocation、Asset Type / Asset，相关Quantity附带time units约束。

边界：这是第8章的UML补充图，不把整理者误写为Fowler本人；未声称逐字引用原书整章。图文经PDF文本解析核对，浏览器图像截图未完成，不声称截图证据。示例的整数设备数量加独立UTC时间段是教学变体，非把原Quantity单位改称台数；实现与正文没有复制原图全部关系。

取消锁定、单次部分履约、保持全部原承诺、替换分两次调用及回执语义均由教学规则声明并通过本地实验检查，不是原图保证。未验证真实设备交付或全局排程最优性。
