# DSL version1; model sha256=627d82f32adaf7280dceb0374c2b41ab71d028f9e5f4339d209fabae37b2e88c
INITIAL = 'INSPECTION_REQUIRED'
TRANSITIONS = {('ACTIVE', 'requireInspection'): 'INSPECTION_REQUIRED', ('ACTIVE', 'retire'): 'INSPECTION_REQUIRED', ('INSPECTION_REQUIRED', 'approveInspection'): 'ACTIVE', ('INSPECTION_REQUIRED', 'retire'): 'RETIRED'}

def step(state: str, operation: str) -> str:
    try:
        return TRANSITIONS[(state, operation)]
    except KeyError as error:
        raise ValueError('OPERATION_NOT_ALLOWED') from error
