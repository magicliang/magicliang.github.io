# 原始来源

2026-10-03实际使用web打开Evans官方页面 https://www.domainlanguage.com/ddd/reference/ ，从页面链接进入 https://www.domainlanguage.com/wp-content/uploads/2016/05/DDD_Reference_2015-03.pdf 。官方页面明确这是模式摘要，并非原书全文。

全文抽取核对Customer/Supplier Development印刷页32（PDF第39页）、Conformist页33（PDF40）、Anticorruption Layer页34（PDF41）。Customer/Supplier要求下游优先级影响上游计划，不是任意API调用；Conformist接受上游模型；ACL以下游领域模型表达上游功能。本文只简短概括，其余映射和协作安排为合成教学设计。

原文模式没有规定本文的BLOCKED/RELEASED/REVIEW_REQUIRED、DTO版本、设备映射或优先级。这些完整冻结在models/23/contracts.md，实验无供应商连接或实际团队协商。
