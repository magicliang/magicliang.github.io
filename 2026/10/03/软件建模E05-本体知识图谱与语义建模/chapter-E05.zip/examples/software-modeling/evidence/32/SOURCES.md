# 32 一手来源核验

2026-10-03通过web.open/find直接读取OMG OCL2.4正式PDF：https://www.omg.org/spec/OCL/2.4/PDF 。核对7.1（PDF第21页）表达式无副作用、7.3.3—7.3.4（PDF第24页）不变量与操作前后置条件的上下文。正文只说明约束可放置的位置，没有提供假装运行的OCL代码或宣称引擎验收。

设备业务合同来自models/24/contracts.md、冻结30 toolkit.validate_equipment_contract；本章错误样本故意移除RETIRED终态标记并添加出边。实际反例轨迹与分层结果见run.txt，不由OCL规范推断。

租期/引用检查为本章Python标准库实现，限定UTC整秒、半开区间、给定快照内部；未将其称为Java核心调用或跨线程一致性验证。
