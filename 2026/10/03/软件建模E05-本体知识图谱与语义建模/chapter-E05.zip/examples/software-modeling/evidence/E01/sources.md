# Primary source record

Checked2026-10-03.

Terry Halpin, ORM 2 Graphical Notation, updated2023-10-06: https://orm.net/pdf/ORM2GraphicalNotation.pdf . Browsed PDF pages1–4: predicate role positions/type links, set population, uniqueness, mandatory, subset/exclusion. Article uses short paraphrases and original teaching diagrams, not formal ORM notation. Rental policy and executable population validator are local teaching adaptations; ternary decomposition result is real local computation, not attributed to original examples.
