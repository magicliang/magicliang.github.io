# 一手来源核验
2026-10-03通过web直接打开正文。
- https://docs.oracle.com/javase/specs/jls/se21/html/jls-9.html#jls-9.1.4 ：sealed interface及permits限制，非结构鸭子类型。
- https://docs.oracle.com/javase/specs/jls/se21/html/jls-8.html#jls-8.10 ：record components、fields、canonical constructor；不将record推导为任意引用对象深度不可变。
- https://docs.oracle.com/javase/specs/jls/se21/html/jls-14.html#jls-14.11.1.1 ：sealed类型的switch穷尽性；14.11.1.2及14.11.3 null行为。负例由Java21实际编译确认。
所有业务时间、金额、生命周期规则来自仓库24/26实际代码；无函数式优越性、生产采用或纯度自动证明主张。
