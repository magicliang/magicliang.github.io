# Primary source record

Checked2026-10-03.

Official EMF https://eclipse.dev/emf/ and overview https://help.eclipse.org/latest/topic/org.eclipse.emf.doc/references/overview/EMF.html browsed for Ecore/runtime/reflective API/XMI persistence. POMs downloaded from https://repo.maven.apache.org/maven2/org/eclipse/emf/org.eclipse.emf.ecore/2.39.0/org.eclipse.emf.ecore-2.39.0.pom and https://repo.maven.apache.org/maven2/org/eclipse/emf/org.eclipse.emf.ecore.xmi/2.39.0/org.eclipse.emf.ecore.xmi-2.39.0.pom , savedecore.pom/xmi.pom; pin nonoptionalcommon2.42.0 andecore/xmi2.39.0. EachjarcheckedCentralSHA1 thenSHA256lock. Xtext https://eclipse.dev/Xtext/documentation/102_domainmodelwalkthrough.html andOCL https://projects.eclipse.org/projects/modeling.ocl browsed for capability distinctions only, neither tool executed. DynamiclocalEcore/XMI andJava businesscheck are original teaching implementation. No automaticcodegenerator/modelmigrationclaim.
