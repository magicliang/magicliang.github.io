# Pre-publication prose review

Entry: blog-editor. Sequence: anti-ai-tone → anti-persona-fabrication → copy exact reviewed draft to article.

Support pass: brief primary-source terminology statements have direct URLs; lifecycle facts traced to chapter24 files; local implementation claims tied to actual raw lab output. No claim of rerunning Java24 or completing integration27.
Progression pass: concrete failed transition → scope/terms → implementation mechanism → behavior counterexample → limits and rerun. No repeated summary slogans.
Rhythm pass: tech profile, concrete fields/functions/observations, ordinary paragraphs and necessary comparison/diagrams. No numbered prose ladder, bold repetition, exaggerated metaphor or canned conclusion.
Continuity pass: final prose contains facts and reasoning, not review dialogue or drafting history.
Persona pass: all ten symptom families and three redlines reviewed; no invented presence, private experience, social anecdote or first-person narration. PASS. Lexical aid recorded separately; not claimed as complete automatic review.
