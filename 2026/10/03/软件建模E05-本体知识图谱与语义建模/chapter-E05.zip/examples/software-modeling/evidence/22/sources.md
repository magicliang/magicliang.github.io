# Source verification — 2026-10-03

Primary: Eric Evans, DDD Reference, March 2015, https://www.domainlanguage.com/wp-content/uploads/2016/05/DDD_Reference_2015-03.pdf . Browsed PDF text with web open/find.

- Printed p2 / PDF index8: Bounded Context defines where a model applies, considers teams/application scope/code/schema, requires consistent terms within the boundary.
- Printed p29 / PDF index35: Context Map identifies each model, names contexts, describes contact points and explicit translation.
- Printed p41 / PDF index47: Generic Subdomains discussed as cohesive portions that may be separated; not used to assert rental/maintenance/billing are universally generic/core/supporting.
- Printed p42 / PDF index48: domain vision can span multiple bounded contexts. Used as background only; no one-to-one mapping is attributed to Evans.

PDF screenshot attempt failed (tool content-type resolution); verification relies on readable extracted primary text, not on unseen graphics. Brief paraphrase only, no copied figures. Both boundary candidates, predicates, amounts and Python implementation are original teaching assumptions. Plan chapter22 asks problem-space/solution-space separation and comparison; current tests prove the finite semantic trace only.
