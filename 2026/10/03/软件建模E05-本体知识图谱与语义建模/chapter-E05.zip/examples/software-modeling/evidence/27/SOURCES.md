# 原始来源核验

2026-10-03 通过 web 工具实际打开并读取以下原作者资料。术语解释依据这些资料；教学 Java 实现、参数、实验数字由本仓库独立实验产生，不归于原作者。

- Eric Evans, DDD Reference (2015)：https://www.domainlanguage.com/wp-content/uploads/2016/05/DDD_Reference_2015-03.pdf 。实际读取印刷页8（PDF第15页）Refactoring Toward Deeper Insight、印刷页13（PDF第20页）Domain Events、印刷页17（PDF第24页）Repositories。深化领域理解可推动模型及代码表达变化；领域事件表达已发生的领域活动；仓储保持应用侧领域访问语言。该摘要不是原书全文。
- Fowler站 Repository 模式页：https://martinfowler.com/eaaCatalog/repository.html 。实际读取集合式领域对象访问与映射隔离定义；页面署名Edward Hieatt、Rob Mee，日期2003-03-05。正文以“Fowler的模式目录”指网站/书目归属，不将此页署名替换为Fowler。
- Martin Fowler, Unit of Work：https://martinfowler.com/eaaCatalog/unitOfWork.html ，2003-03-05。读取协调事务涉及对象变更与写出的定义；本实验只有一次内存快照替换，不冒称完整数据库工作单元。
- Martin Fowler, Definition Of Refactoring：https://martinfowler.com/bliki/DefinitionOfRefactoring.html ，2004-09-01。实际读取保持可观察行为的定义；有限实验没有声称形式化证明全部输入等价。

公开来源只为上述概念解释提供支撑。没有用目录页推导数据库事务、可靠消息、领域专家访谈或生产部署结果。网页当前内容与PDF相关段落均已实际读取；没有引用未取得的付费章节。
