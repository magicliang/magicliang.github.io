# 原始资料核对

核对日期：2026-10-03。通过 web.open 直接读取以下页面正文，未以搜索摘要代替原文。

- https://martinfowler.com/eaaDev/AccountingEntry.html ，Martin Fowler，2005-01-22，页面声明 draft。How it Works 解释 Account/Entry 在原书同属一个模式，网页讨论中拆开；同节和 Simple Example 允许始终不可变或 booked 后不可变的不同选择。正文明确使用2005网页草稿组织，不冒充原书章节。
- https://martinfowler.com/eaaDev/AccountingTransaction.html ，Martin Fowler，2005-01-22，draft。定义连接至少两条、总和为零的 entries；How it Works 区分 two-legged 和 multi-legged。本文只提取分组/零和约束；合成租赁的账户符号、退款次序、唯一冲正与禁止修改都是实验选择。

数据库原子性不等于会计约束的结论由本地 fault injection 与 BYPASS 两个实际实验分别支撑，不归因于草稿原文的存储保证。无外部支付、真实用户访谈或财务合规验证。
