# Primary-source verification

Source opened directly with web on 2026-10-03:
https://martinfowler.com/articles/bitemporal-history.html

Observed title: Bitemporal History. Author: Martin Fowler. Visible date and Significant Revisions both say 07 April 2021 published. Open followed by find for actual history, append-only and necessary.

Verified sections:
- The Two Dimensions: actual history and record history; valid/effective and transaction terminology correspondence; a two-parameter query; future-valid facts can be recorded in advance.
- Using Bitemporality: retroactive corrections motivate the distinction, but retained action inputs or simpler effective history may suffice; complexity has a cost.
- Append-only History: later knowledge is added without changing what was previously known.
- Consequences of Retroactive Changes: retrieving corrected history alone does not implement dependent compensation.

Teaching design: the CAM-DAY price fixture, CNY values, year domain, strictly ordered UTC record timestamps, full-snapshot append API and complete half-open partition checks are original. This is not SQL temporal conformance, event-sourcing infrastructure or tamper-proof auditing.
