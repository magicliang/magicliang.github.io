# Primary-source verification

Source opened directly with web on 2026-10-03:
https://www.cs.ox.ac.uk/jeremy.gibbons/dpa/typeobject.pdf

Observed PDF: The Type Object Pattern; authors Ralph Johnson and Bobby Woolf; 13 pages. Page 1 Intent explains runtime type creation using instances; pages 2–3 separate TypeClass, TypeObject, Class and Object; page 4 collaborations distinguish instance-specific operations from delegation to type objects; page 5 identifies implementation/reference complexity. PDF footer carries 10/19/96; no unsupported publication-edition attribution is made.

Article mapping is deliberately narrow: runtime type objects for shared description/behavior; equipment, versioned service specifications, integer CNY fees and historical-contract pinning are explicit original teaching choices. No claim that this is a verbatim Analysis Patterns chapter or mandatory storage design.

Fresh web invocation: open(url above), response_length=long. No secondary tutorial relied upon.
