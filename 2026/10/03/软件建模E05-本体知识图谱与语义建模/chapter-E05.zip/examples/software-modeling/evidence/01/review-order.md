# 第 01 篇落盘前双扫描

对象：article-draft.md。目标：source/_posts/2026-10-03-软件建模01-场景用例与规则.md。

1. blog-editor 已读取，核对 source/_posts/AGENTS.md。按已批准系列题目独立新增，不合并既有文章；未引入外部封面，沿用站点默认封面。正文无图片附件引用，不制造空附件。
2. anti-ai-tone 在正文落入 source/_posts 前执行。脚本命令：`python3 /Users/magicliang/.codex/skills/anti-ai-tone/scripts/check_prose.py --profile tech --json examples/software-modeling/evidence/01/article-draft.md`，结果见 anti-ai-tone.json：0 error，1 warning。warning 的两个“第 2—4 节”是节号范围而非插入式破折号，保留。人工依次核对：开头由 A0 反例支撑；目标/正常异常边界/规则追踪/取消回执/实测/未决问题逐段增加新材料；只保留真实操作步骤编号及多维映射表；无广告式子标题、无空泛升华、无段尾口号；代码与结果均在本地核对。正文中文 2642 字（含 front matter，Unicode Han 计数），115 行。
3. anti-persona-fabrication 在上述检查完成后执行。逐段检查第一人称、身体情绪、社交来源、连续时间行动、伪造写作过程、说书人过门：均未出现。开头明示合成教学材料；经办角色为模型角色，不是声称受访者；UTC 时间是测试输入；“本次本地运行通过20项”由真实 run.log 与 exit-code.txt 支撑。取消授权和清洁均标为未决或候选要求，不声称访谈或生产效果。

最终准许落盘内容与该草稿一致。具体机器辅助第一人称/套话扫描结果另存 persona-scan.json；扫描只辅助定位，不能替代以上逐段审阅。
