# Primary-source verification

Accessed through web tools on 2026-10-03. Short paraphrases only; no copied original diagrams.

- Martin Fowler, Semantic Model: https://martinfowler.com/dslCatalog/semanticModel.html . Author catalogue intent: a domain model populated by a DSL. Used only for input text / semantic model distinction, not as proof of this local implementation or full book coverage.
- Martin Fowler, Generation Gap: https://martinfowler.com/dslCatalog/generationGap.html . Author describes separating generated and non-generated code through inheritance; rationale includes avoiding hand editing generated code. Articles explicitly distinguish local function composition from that inheritance pattern. No claim of implementing the original pattern unchanged.
- Pramod Sadalage and Martin Fowler, Evolutionary Database Design: https://martinfowler.com/articles/evodb.html . Read schema/data migration and regression-testing discussion. Chapter34 borrows need for explicit old-data migration, but operates only on a trusted in-memory equipment snapshot, not a database upgrade.

Attempted CodeGeneration and RoundTripEngineering bliki URLs were unavailable; neither is used as a source. Runtime output, determinism, overwrite/conflict and migration claims come from actual local code and output.txt, not from these essays. Diagrams are original depictions of the executed teaching experiments.
