# DSL version1; model sha256=c3bf9d83424386108383eb4634ebc4f000bc5678720b89b8297c7abd635f1ba3
INITIAL = 'INSPECTION_REQUIRED'
TRANSITIONS = {('INSPECTION_REQUIRED', 'approveInspection'): 'READY', ('INSPECTION_REQUIRED', 'retire'): 'RETIRED', ('READY', 'requireInspection'): 'INSPECTION_REQUIRED', ('READY', 'retire'): 'RETIRED'}

def step(state: str, operation: str) -> str:
    try:
        return TRANSITIONS[(state, operation)]
    except KeyError as error:
        raise ValueError('OPERATION_NOT_ALLOWED') from error
