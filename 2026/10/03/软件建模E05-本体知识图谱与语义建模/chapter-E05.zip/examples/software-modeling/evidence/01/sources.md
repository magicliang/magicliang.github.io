# 核对过的来源

查询：web.open 同时打开以下两个原始 PDF，获取全文页码/节号；2026-10-03 本轮执行。

- https://alistaircockburn.com/Use%20Case%20Foundation.pdf ：标题 Use-Case Foundation；作者 Ivar Jacobson、Alistair Cockburn；Version 1.1。第1页包括系统边界、主要参与者与目标、场景集合及用例；第4页明确 basic scenario 与 extensions，以及扩展从基本步骤何处分叉/返回。文章仅依据这些方法定义。
- https://www.businessrulesgroup.org/brmanifesto/BRManifesto.pdf ：Business Rules Manifesto；Business Rules Group；Version 2.0, November 1, 2003。第2节规则与过程分离，第3节术语/事实/规则关系，第4节声明式表达及规则与执行机制分离。文章未扩展成必须使用规则引擎的结论。

租赁规则来源：当前 examples/software-modeling/README.md 与 models/00/three-models.md；逐条核对 rental-core/RentalDesk.java 和本篇20项实测。以上公开资料均不被当作租赁政策来源。
