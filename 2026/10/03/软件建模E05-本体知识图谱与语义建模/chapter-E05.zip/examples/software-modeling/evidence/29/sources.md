# Primary-source verification — 2026-10-03

- Eric Evans, DDD Reference 2015, printed p6 / PDF index12: https://www.domainlanguage.com/wp-content/uploads/2016/05/DDD_Reference_2015-03.pdf . web open read Model-Driven Design definition: direct relation of model, terminology, responsibility and code; iterative model/implementation feedback. Brief paraphrase; no claim it mandates code generation.
- Douglas C. Schmidt, Model-Driven Engineering, IEEE Computer 39(2), 2006, pp26–27: author-hosted PDF https://www.dre.vanderbilt.edu/~schmidt/PDF/GEI.pdf . web open verified DSML/metamodel constraints and transformation/generator discussion. MDD/MDE labels in this series are declared working usage, not a universal strict taxonomy.
- OMG MDA official page: https://www.omg.org/mda/ . web open verified business/platform separation and associated OMG standards. MDA Guide link retrieval failed; no detailed guide clauses or conformance claims are attributed to unread material.
- Direct repo source: examples/software-modeling/models/24/contracts.md and labs/24/Equipment.java. Only lifecycle state subset was projected into Python. Chapter24 Java suite was NOT rerun here.
- Read models/27/ARCHITECTURE-BASELINE.md while author was working; no chapter27 runtime integration or acceptance claim. This lab has no Java application dependency.

All figures are original teaching diagrams. Actual code-generation/interpretation mechanisms are own scripts, not an OMG MDA implementation, general UML tool, or Evans reference implementation.
