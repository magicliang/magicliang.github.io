# 35 实验记录

依赖及API范围：models/35/contracts.md。源码基线承接调用方给定ed5a420a0189945118b8b0211f6da39e989a453d；未改24–27。

|场景|入口参数|二元观察|原始工件|
|---|---|---|---|
|对象与纯函数租期/生命周期/空值/时间边界|run.sh|44项通过，退出0|run.txt/run.exit|
|遗漏失败分支|run.sh negative IncompleteSwitch|javac拒绝，退出1|negative-switch.txt/.exit|
|非法结果变体|run.sh negative UnexpectedVariant|javac拒绝，退出1|negative-variant.txt/.exit|
|独立工作目录|绝对路径run.sh，从/private/tmp|44项及编译负例通过，退出0|standalone.txt/.exit|

JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn；所有编译--release21 -Xlint:all -Werror。run.txt包含期望编译错误，不是正向构建失败。稿件先存在article-draft.md，经anti-ai-tone.json再anti-persona-fabrication.json后首次发布，同稿hash。source-hashes.sha256锁定编译依赖与稿件。未验收ZIP/Hexo/browser，不涉及数据库或网络。
