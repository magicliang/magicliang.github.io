# 19 验证索引

实际命令：`bash examples/software-modeling/labs/19/run.sh`。输出`output.txt`，退出码`exit-code.txt`（0）；21项检查。

| 成功标准 | 实际二元可观察结果 | 原始证据 |
|---|---|---|
| 客户角色产生模型差异 | customer_counterexample为PERSON-B→ORG-A；同主体多角色通过、缺失拒绝 | output.txt |
| 可用按区间与物况回答 | availability_counterexample为True→False；相邻/前段通过，物况不合格拒绝 | output.txt |
| 结算明确待收/待退/归零 | settlement_counterexample为SETTLED→REFUND_DUE；退款后归零、部分支付待收 | output.txt |
| 输入边界 | 空区间/负数/超额退款/超额折扣/浮点数REJECT | output.txt |
| 跨目录复跑与非法输入CLI | standalone-output一致、exit0；negative-invalid-period为ValueError且exit1 | standalone-*、negative-* |

静态核对在`static-checks.txt`，原始调用在`commands.txt`，源哈希在`source-hashes.sha256`。原始资料核对见`SOURCES.md`。两张模型图与正文Mermaid逐字一致；正文输出摘录逐行存在于实际输出。

预落盘：blog-editor入口→anti-ai-tone脚本与人工材料/结构复核→anti-persona-fabrication检索与人工复核→apply_patch正文。稿件SHA绑定于persona JSON，正式文章与稿件相同。LSP未安装且已有拒绝安装设置，使用Python实跑/AST解析、bash -n和JSON解析，不声称LSP检查。

root负责ZIP、共享入口、Hexo、浏览器与提交，本切片不宣称这些集成项完成。
