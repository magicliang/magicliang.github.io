# Chapter 06 verification

Command: `bash examples/software-modeling/labs/06/run.sh` with JAVA_HOME selecting Amazon Corretto 21.0.11. Exact invocation in command.txt, runtime in environment.txt. Scenario checks use explicit AssertionError / expected-exception checks, not disabled JVM assertions.

| Criterion | Scenario / binary marker | Observable | Artifact |
|---|---|---|---|
| Normal lifecycle and illegal transitions | `normal_state_cycle; handover_without_hold; reserve_during_inspection` | PASS markers; forbidden events rejected with IllegalStateException | `output.txt`, `exit-code.txt` |
| Timeout boundary | `timeout_before_deadline; handover_at_deadline; timeout_at_deadline` | PASS markers; early timeout and exact-deadline handover rejected | `output.txt`, `exit-code.txt` |
| Workflow branching | `pickup_flow; timeout_flow` | Exact role trace asserted; terminal OUT/AVAILABLE respectively | `output.txt`, `exit-code.txt` |
| Decision overlap, gap and finite completeness | `complete_unique_domain_1_to_30; overlap_day_7; gap_day_8; outside_domain_day_0; outside_domain_day_31` | 30 legal integer inputs checked; overlap matches=2; gap matches=0; external inputs rejected | `output.txt`, `exit-code.txt` |
| Simpler alternative and First sensitivity | `first_order_changes_result` | First matching row changes 100 to 80 when row order reverses | `output.txt`, `exit-code.txt` |
| Standalone download | Extract chapter-06.zip into empty temporary directory; run same command from extraction root | Exit 0 and all PASS markers | archive-output.txt, archive-exit-code.txt |
| Writing checks | check_prose.py --profile tech --json article-draft.md; then persona scan and manual reading | 0 errors, 0 warnings, no persona hits | anti-ai-tone.json, persona-scan.json, PROSE-REVIEW.md |

Source/model mapping: models/06/semantics.md; sources.md. Reader archive contains repository-relative paths and no dependency on checkout. source-sha256.txt identifies delivered input files and archive.

Limits: local synchronous teaching tests only. No production, database persistence, concurrent execution or service integration verified. The leader owns combined Hexo generation, navigation and real browser checks; those are not claimed by this per-chapter lab evidence.
