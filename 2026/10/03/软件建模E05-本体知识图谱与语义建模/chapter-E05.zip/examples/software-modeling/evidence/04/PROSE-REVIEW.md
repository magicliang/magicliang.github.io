# 落盘前双扫描

目标：article-draft.md，正文随后原样写入 04 博文。

1. 已读取 blog-editor、anti-ai-tone 与 prose-quality.md，按 tech profile 审读。材料依据为当前 core、CRC 原论文和本地实验。段落按职责粒度、候选分配、场景、反例、变化推进；表格用于候选横向比较；没有工作坊或生产经历声明。执行 `python3 /Users/magicliang/.codex/skills/anti-ai-tone/scripts/check_prose.py --profile tech --json examples/software-modeling/evidence/04/article-draft.md`；产物 anti-ai-tone.json，errors=0、warnings=0。
2. 此后执行 anti-persona-fabrication token 扫描并人工连读全部段落，检查体感、时间行动、社交、身份与写作旁白。persona-scan.json 无命中，保留稿件 SHA256。已明确书面合成场景、无真实访谈，无伪造 CRC 现场。

先完成 1，再完成 2，最后落盘博文。实验采用本地 Java 执行证据，静态变化卡明确未实现。
