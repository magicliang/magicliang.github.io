# 来源核验

2026-10-03 实际通过 web 打开正文，不凭搜索摘要补写方法。

- Jeff De Luca，2013-11-07 Agile Singapore，Strategies for Success，第 3 张幻灯片及页面 transcript：https://speakerdeck.com/agilesingapore/strategies-for-success-a-singapore-case-study-and-a-look-to-the-future-jeff-de-luca-agile-sg-2013 。确认五个流程名称。正文仅引用流程，不复述银行项目业绩。
- Stephen Palmer，2009-11-20，An Introduction to Feature-Driven Development：https://dzone.com/articles/introduction-feature-driven 。署名与参考文献确认作者为 A Practical Guide to Feature-Driven Development 的作者之一。实际全文核对：前三流程、动作/结果/对象语法、短期小组 feature 设计构建、模型广度优先、类所有权为责任而非排他。
- Stephen Palmer，2009-12-04，Part 2：https://dzone.com/articles/introduction-feature-driven-2 。全文确认两周以内、不固定长度且不要求团队同步起止的 DBF/BBF 迭代；不把两周写成固定冲刺或项目工期保证。

检索过程中的 fddoverview.pdf 和 node/505 直接打开超时；node/505 搜索返回作者完整讨论，但最终正文未依赖该线程，以已打开的 Palmer 两篇为主。所有模型、slot 容量限制、整数日、F01/F02/F03 是本篇教学设计，非原作者指定案例。
