# 26 执行证据

环境：Amazon Corretto JDK21.0.11，JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn。公开 run.sh 从 /private/tmp 调用，使用自身位置定位依赖。

| 场景 | 调用 | 二值可观察结果 | 原始工件 |
|---|---|---|---|
| 严格编译与旧基线 | run.sh | --release21 -Xlint:all -Werror成功、基线48项PASS | run.txt、run.exit=0 |
| 时间规格/计费边界/工厂及快照不变量 | run.sh | 本章27项PASS，包含秒/纳秒边界、错误报价/币种 | run.txt |
| 合法草案不等于承诺 | run.sh | 创建后日历为空；2份合法草案仅1份确认 | run.txt中OBSERVED与对应PASS |
| 公开工厂拒绝过早租期 | run.sh invalid-period | IllegalArgumentException: rental period: TOO_SOON，退出1 | negative.txt、negative.exit |

正文首次落盘前依次运行 anti-ai-tone、anti-persona-fabrication，详见对应JSON与稿哈希。source-hashes.sha256覆盖依赖Money、ReservationCalendar及本章源码。

未执行：设备在役/维修应用集成、数据库或远程支付、ZIP解包、Hexo构建、浏览器渲染。草案恢复只验证内部报价一致性；原政策版本、持久化来源和授权不在本章范围。
