# Pre-write prose review

Entry: blog-editor. Draft is reviewed before publication path is written.

1. anti-ai-tone: tech profile; machine output in anti-ai-tone.json. Manual support pass ties paragraphs to source APIs/specification, concrete code or explicit teaching assumptions. Paragraph progression follows distinct failure modes; no repeated closing summary or review-history prose.
2. anti-persona-fabrication: persona-scan.json, plus manual reading of all paragraphs: no fabricated personal history, time spent, social relations, emotions, narration or anthropomorphism.

Existing series already fixes article scope; no duplicate chapter exists. Use configured default cover consistent with series, no external photo dependency.
