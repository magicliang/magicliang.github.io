# 25 来源核验

2026-10-03 通过 web.open/find 直接读取正文，未用搜索摘要替代原文。

- Eric Evans, DDD Reference (2015-03), Aggregates, 印刷页16 / PDF第23页：https://www.domainlanguage.com/wp-content/uploads/2016/05/DDD_Reference_2015-03.pdf 。核对整体不变量、根的维护责任、事务边界和跨边界更新；本章单日历与单锁方案是教学推导，非书中租赁示例。
- Java SE21 JLS17.1与17.4.5：https://docs.oracle.com/javase/specs/jls/se21/html/jls-17.html 。核对实例同步方法的监视器、互斥与解锁到后续加锁的 happens-before；不外推数据库或跨进程事务。
- Java SE21 CyclicBarrier：https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/CyclicBarrier.html 。核对 await等待所有参与者及内存一致性条款；实际代码给屏障与Future结果设置超时。

来源用于方法和语言机制说明；竞争输出来自 run.txt，来源文字不构成本地执行证明。
