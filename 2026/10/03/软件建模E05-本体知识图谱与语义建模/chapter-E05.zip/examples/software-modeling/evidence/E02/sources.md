# Primary source record

Checked2026-10-03.

Kimball Group primary pages browsed: Grain https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/grain/ ; Type2 https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/type-2/ ; Multipass SQL https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/multipass-sql/ . Brief paraphrase only of grain consistency, added dimension versions, and separate fact aggregation. SQLite schema/policy and all numerical outputs are original teaching data, not source quotations.
