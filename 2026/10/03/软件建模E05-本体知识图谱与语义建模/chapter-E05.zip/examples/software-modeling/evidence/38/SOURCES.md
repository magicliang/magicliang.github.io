# 38 primary sources
2026-10-03 web直接打开正文：
- https://martinfowler.com/eaaCatalog/transactionScript.html 请求对应业务过程，可调用子过程。
- https://martinfowler.com/eaaCatalog/domainModel.html 行为和数据一起组织的对象模型。
- https://c4model.com/diagrams/dynamic 用例协作运行视图；https://c4model.com/diagrams/deployment 环境中软件实例部署到节点。
- https://arc42.org/overview/ 构建块、运行、部署、决定、质量和风险分开组织。
ISO42010概念页直接访问失败，文章未凭摘要引用它的规范定义。Mermaid自绘且与真实同JVM回环实验一致；非完整C4/4+1认证或企业架构实现。

执行环境：首次受限沙箱bind返回SocketException Operation not permitted；随后自动审批允许临时localhost监听，实际正向/负例/standalone完成并关闭。run.txt记录完成的真实网络链，不将初始失败隐藏为网络成功推断。
