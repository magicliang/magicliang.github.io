# Sources verified 2026-10-03

- https://martinfowler.com/books/ap.html — author book page and supplement links, opened with web tool.
- https://martinfowler.com/apsupp/accountability.pdf — pp.5–6 (PDF indices 4–5): person/organization abstraction, common behavior, caution against mechanically adopting Role Object. pp.17–18 (indices 16–17): typed two-party relation and multiple authority relationships. Opened with web tool and inspected text.
- https://martinfowler.com/apsupp/apchap3.pdf — 1999 UML supplement by Igor Janicijevic and Martin Fowler; Fig3.2 quantity amount/unit; Fig3.6 measurement; Fig3.7 category; Fig3.11 applicability/recording time; Fig3.12 rejected observation. Opened with web tool and inspected text. This is not a quoted full book chapter.

No original diagrams or prose copied. Article descriptions are brief paraphrases; fixture rules, validation code, graphs and consequences are teaching adaptations. No clinical claim or original-source provenance assigned to the synthetic examples.
