from dataclasses import dataclass


@dataclass(frozen=True)
class Period:
    start: int
    end: int

    def __post_init__(self):
        if type(self.start) is not int or type(self.end) is not int or self.start >= self.end:
            raise ValueError("invalid period")

    def overlaps(self, other):
        return self.start < other.end and other.start < self.end


@dataclass(frozen=True)
class Rental:
    id: str
    equipment: str
    period: Period


class ReservationBook:
    def __init__(self, equipment=("E1", "E2")):
        self.equipment = frozenset(equipment)
        self.rentals = {}

    def validate(self, candidate):
        if candidate.equipment not in self.equipment:
            raise ValueError("unknown equipment")
        for other in self.rentals.values():
            if (other.id != candidate.id and other.equipment == candidate.equipment
                    and other.period.overlaps(candidate.period)):
                raise ValueError("conflict")

    def reserve(self, rental_id, equipment, start, end):
        if not rental_id or rental_id in self.rentals:
            raise ValueError("invalid rental id")
        candidate = Rental(rental_id, equipment, Period(start, end))
        self.validate(candidate)
        self.rentals[rental_id] = candidate
        return candidate

    def cancel(self, rental_id):
        if rental_id not in self.rentals:
            raise ValueError("unknown rental")
        return self.rentals.pop(rental_id)

    def extend(self, rental_id, new_end):
        raise NotImplementedError("F02 not implemented")
