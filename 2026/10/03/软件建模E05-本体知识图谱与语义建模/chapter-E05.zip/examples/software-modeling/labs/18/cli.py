import json
import sys
from dataclasses import asdict
from rental import ReservationBook


def main():
    book = ReservationBook()
    results = []
    for command in json.load(sys.stdin):
        action = command["action"]
        args = command.get("args", [])
        try:
            if action not in ("reserve", "extend", "cancel"):
                raise ValueError("unknown action")
            value = getattr(book, action)(*args)
            results.append({"ok": True, "rental": asdict(value)})
        except ValueError as exc:
            results.append({"ok": False, "error": str(exc)})
    print(json.dumps({"results": results, "rentals": {k: asdict(v) for k, v in book.rentals.items()}}, sort_keys=True))


if __name__ == "__main__":
    main()
