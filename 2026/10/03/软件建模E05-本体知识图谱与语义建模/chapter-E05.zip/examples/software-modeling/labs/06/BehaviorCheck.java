import java.time.Instant;
import java.util.List;

public class BehaviorCheck {
    enum State { AVAILABLE, HELD, OUT, INSPECTION }
    enum Event { RESERVE, HANDOVER, RETURN, INSPECT, TIMEOUT }
    record Equipment(State state, Instant deadline) {
        Equipment on(Event event, Instant now) {
            State next = switch (state) {
                case AVAILABLE -> event == Event.RESERVE ? State.HELD : null;
                case HELD -> event == Event.HANDOVER && now.isBefore(deadline) ? State.OUT
                        : event == Event.TIMEOUT && !now.isBefore(deadline) ? State.AVAILABLE : null;
                case OUT -> event == Event.RETURN ? State.INSPECTION : null;
                case INSPECTION -> event == Event.INSPECT ? State.AVAILABLE : null;
            };
            if (next == null) throw new IllegalStateException(state + "/" + event);
            return new Equipment(next, deadline);
        }
    }
    record Rule(int first, int last, int yuanPerDay) {
        boolean matches(int days) { return first <= days && days <= last; }
    }
    static final List<Rule> RULES = List.of(new Rule(1, 7, 100), new Rule(8, 30, 80));
    static int unique(List<Rule> rules, int days) {
        var hits = rules.stream().filter(r -> r.matches(days)).toList();
        if (hits.size() != 1) throw new IllegalArgumentException("matches=" + hits.size() + " days=" + days);
        return hits.getFirst().yuanPerDay();
    }
    static int first(List<Rule> rules, int days) {
        return rules.stream().filter(r -> r.matches(days)).findFirst().orElseThrow().yuanPerDay();
    }
    static List<String> process(int days, boolean pickedUp, Instant now, Instant deadline) {
        int rate = unique(RULES, days);
        var equipment = new Equipment(State.AVAILABLE, deadline).on(Event.RESERVE, now);
        if (pickedUp) {
            equipment = equipment.on(Event.HANDOVER, now);
            return List.of("desk:quote=" + days * rate, "desk:hold", "warehouse:handover", equipment.state().name());
        }
        equipment = equipment.on(Event.TIMEOUT, now);
        return List.of("desk:quote=" + days * rate, "desk:hold", "timer:release", equipment.state().name());
    }
    static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        System.out.println("PASS " + name);
    }
    static void rejects(String name, Class<? extends RuntimeException> type, Runnable action) {
        try { action.run(); } catch (RuntimeException e) {
            if (!type.isInstance(e)) throw e;
            System.out.println("PASS " + name + " rejected=" + e.getMessage()); return;
        }
        throw new AssertionError("accepted " + name);
    }
    public static void main(String[] args) {
        var deadline = Instant.parse("2026-10-03T10:00:00Z");
        var early = deadline.minusSeconds(1);
        var initial = new Equipment(State.AVAILABLE, deadline);
        var held = initial.on(Event.RESERVE, early);
        var returned = held.on(Event.HANDOVER, early).on(Event.RETURN, early);
        check("normal_state_cycle", returned.on(Event.INSPECT, early).state() == State.AVAILABLE);
        rejects("handover_without_hold", IllegalStateException.class, () -> initial.on(Event.HANDOVER, early));
        rejects("reserve_during_inspection", IllegalStateException.class, () -> returned.on(Event.RESERVE, early));
        rejects("timeout_before_deadline", IllegalStateException.class, () -> held.on(Event.TIMEOUT, early));
        rejects("handover_at_deadline", IllegalStateException.class, () -> held.on(Event.HANDOVER, deadline));
        check("timeout_at_deadline", held.on(Event.TIMEOUT, deadline).state() == State.AVAILABLE);
        var pickup = process(8, true, early, deadline);
        var timeout = process(8, false, deadline, deadline);
        check("pickup_flow", pickup.equals(List.of("desk:quote=640", "desk:hold", "warehouse:handover", "OUT")));
        check("timeout_flow", timeout.equals(List.of("desk:quote=640", "desk:hold", "timer:release", "AVAILABLE")));
        System.out.println("TRACE pickup=" + pickup + " timeout=" + timeout);
        for (int day = 1; day <= 30; day++) {
            if (unique(RULES, day) != (day <= 7 ? 100 : 80)) throw new AssertionError("rate " + day);
        }
        check("complete_unique_domain_1_to_30", true);
        var overlap = List.of(new Rule(1, 7, 100), new Rule(7, 30, 80));
        var gap = List.of(new Rule(1, 7, 100), new Rule(9, 30, 80));
        rejects("overlap_day_7", IllegalArgumentException.class, () -> unique(overlap, 7));
        rejects("gap_day_8", IllegalArgumentException.class, () -> unique(gap, 8));
        rejects("outside_domain_day_0", IllegalArgumentException.class, () -> unique(RULES, 0));
        rejects("outside_domain_day_31", IllegalArgumentException.class, () -> unique(RULES, 31));
        check("first_order_changes_result", first(overlap, 7) == 100 && first(overlap.reversed(), 7) == 80);
        System.out.println("RESULT PASS chapter=06 checks=14 scope=local_finite_model");
    }
}
