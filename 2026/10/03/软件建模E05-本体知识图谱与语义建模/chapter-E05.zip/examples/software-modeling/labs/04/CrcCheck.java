package rental;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import rental.RentalDesk.*;

public final class CrcCheck {
    private record Receipt(ReserveRequest request, Outcome outcome) {}

    private static final class Ledger {
        private final Map<RequestId, Receipt> receipts = new HashMap<>();
        Receipt lookup(ReserveRequest request) {
            Receipt previous = receipts.get(request.requestId());
            if (previous != null && !previous.request().equals(request)) {
                throw new IllegalArgumentException("different payload");
            }
            return previous;
        }
        void remember(ReserveRequest request, Outcome result) {
            receipts.put(request.requestId(), new Receipt(request, result));
        }
    }

    private static final class Schedule {
        private final Map<RequestId, ReserveRequest> bookings = new HashMap<>();
        Outcome reserve(ReserveRequest request) {
            boolean conflict = bookings.values().stream().anyMatch(existing ->
                    existing.equipmentId().equals(request.equipmentId())
                            && existing.period().overlaps(request.period()));
            if (conflict) return Outcome.OVERLAP_REJECTED;
            bookings.put(request.requestId(), request);
            return Outcome.CONFIRMED;
        }
        boolean release(RequestId id) { return bookings.remove(id) != null; }
    }

    private static final class SplitDesk {
        private final Ledger ledger = new Ledger();
        private final Schedule schedule = new Schedule();
        Outcome reserve(ReserveRequest request) {
            Objects.requireNonNull(request);
            Receipt previous = ledger.lookup(request);
            if (previous != null) return previous.outcome();
            Outcome result = schedule.reserve(request);
            ledger.remember(request, result);
            return result;
        }
        boolean cancel(RequestId id) { return schedule.release(Objects.requireNonNull(id)); }
    }

    private static ReserveRequest request(String id, String equipment, int start, int end) {
        return new ReserveRequest(new RequestId(id), new EquipmentId(equipment), new Period(
                Instant.parse("2026-10-03T%02d:00:00Z".formatted(start)),
                Instant.parse("2026-10-03T%02d:00:00Z".formatted(end))));
    }

    private static void expect(String label, Object actual, Object expected) {
        if (!Objects.equals(actual, expected)) {
            throw new AssertionError(label + " expected=" + expected + " actual=" + actual);
        }
        System.out.println("PASS " + label + " actual=" + actual);
    }

    private static void scenario(String name, Function<ReserveRequest, Outcome> reserve,
                                 Function<RequestId, Boolean> cancel) {
        ReserveRequest a = request("A", "E1", 10, 12);
        ReserveRequest b = request("B", "E1", 11, 13);
        expect(name + ".confirm", reserve.apply(a), Outcome.CONFIRMED);
        expect(name + ".overlap", reserve.apply(b), Outcome.OVERLAP_REJECTED);
        expect(name + ".adjacent", reserve.apply(request("C", "E1", 12, 13)), Outcome.CONFIRMED);
        expect(name + ".equipment", reserve.apply(request("D", "E2", 10, 12)), Outcome.CONFIRMED);
        expect(name + ".retry", reserve.apply(a), Outcome.CONFIRMED);
        try {
            reserve.apply(request("A", "E2", 10, 12));
            throw new AssertionError("changed payload accepted");
        } catch (IllegalArgumentException expected) {
            System.out.println("PASS " + name + ".changed_payload rejected");
        }
        expect(name + ".cancel", cancel.apply(a.requestId()), true);
        expect(name + ".cancel_twice", cancel.apply(a.requestId()), false);
        expect(name + ".replay_cancelled", reserve.apply(a), Outcome.CONFIRMED);
        expect(name + ".cancel_adjacent", cancel.apply(new RequestId("C")), true);
        expect(name + ".old_rejection", reserve.apply(b), Outcome.OVERLAP_REJECTED);
        expect(name + ".fresh_after_replay", reserve.apply(request("F", "E1", 10, 12)), Outcome.CONFIRMED);
        expect(name + ".cancel_rejected", cancel.apply(b.requestId()), false);
    }

    public static void main(String[] args) {
        RentalDesk central = new RentalDesk();
        scenario("central", central::reserve, central::cancel);
        SplitDesk split = new SplitDesk();
        scenario("split", split::reserve, split::cancel);

        SplitDesk broken = new SplitDesk();
        ReserveRequest a = request("A", "E1", 10, 12);
        broken.reserve(a);
        broken.cancel(a.requestId());
        broken.ledger.receipts.remove(a.requestId());
        expect("broken.replay_same_return", broken.reserve(a), Outcome.CONFIRMED);
        Outcome observed = broken.reserve(request("F", "E1", 10, 12));
        expect("broken.probe", observed, Outcome.OVERLAP_REJECTED);
        System.out.println("DETECTED cancelled_request_resurrected expected=CONFIRMED actual=" + observed);
        System.out.println("PASS crc_behavior_and_counterexample");
    }
}
