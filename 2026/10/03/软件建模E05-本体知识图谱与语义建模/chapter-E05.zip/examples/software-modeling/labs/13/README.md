# 13：最小教学账本

从仓库根目录或实验包解压根目录运行：

```bash
bash examples/software-modeling/labs/13/run.sh
```

依赖Python标准库decimal/sqlite3/pathlib/platform；实跑Python3.14.4、SQLite3.51.3。运行入口通过自身路径定位`examples/software-modeling/models/13/schema.sql`，与调用者当前目录无关；不读取Java core或其他章节代码。每次新建内存数据库。

输出逐项PASS/REJECT，23项全部满足则exit0；断言不符或预期异常未发生则非零退出。预期REJECT表示拒绝行为通过检查，不是脚本崩溃。故障注入和绕过应用的DB提交独立验证存储/业务边界。详见`examples/software-modeling/models/13/semantics.md`。

原始输出和退出码在`examples/software-modeling/evidence/13/output.txt`、`exit-code.txt`，来源说明在同目录`SOURCES.md`。不需要网络、付款网关或新增依赖。
