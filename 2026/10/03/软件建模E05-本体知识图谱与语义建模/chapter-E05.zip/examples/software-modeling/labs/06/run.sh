#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
java_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}java
javac_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}javac
"$java_cmd" -version
"$javac_cmd" -version
build=$(mktemp -d)
trap 'rm -rf "$build"' EXIT
"$javac_cmd" --release 21 -d "$build" "$root/labs/06/BehaviorCheck.java"
"$java_cmd" -cp "$build" BehaviorCheck
