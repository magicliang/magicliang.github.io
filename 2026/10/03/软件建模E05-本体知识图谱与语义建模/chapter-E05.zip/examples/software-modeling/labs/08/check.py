"""Executable teaching comparison; no dependency on RentalDesk."""
from dataclasses import dataclass
from decimal import Decimal
import json


def check(name, actual, expected):
    if actual != expected:
        raise AssertionError((name, actual, expected))
    print(json.dumps({'scenario': name, 'actual': actual, 'expected': expected, 'pass': True}, ensure_ascii=False))


@dataclass(frozen=True)
class Fact:
    subject: str
    phenomenon: str
    value: str
    unit: str
    at: int


def latest(facts, subject, phenomenon, at):
    candidates = [f for f in facts if f.subject == subject and f.phenomenon == phenomenon and f.at <= at]
    return max(candidates, key=lambda f: f.at).value if candidates else None


def model_choice(needs_history, multiple_kinds):
    # Explicit teaching decision table, not a general pattern detector.
    return 'observation' if needs_history or multiple_kinds else 'fixed-field'


def main():
    fixed = {'E1': '120'}
    facts = [Fact('E1', 'operating-hours', '120', 'h', 10)]
    check('single-current-field-agrees', fixed['E1'], latest(facts, 'E1', 'operating-hours', 10))
    check('single-current-choose-simple', model_choice(False, False), 'fixed-field')
    fixed['E1'] = '126'
    facts.append(Fact('E1', 'operating-hours', '126', 'h', 12))
    check('overwrite-loses-historical-answer', fixed['E1'] == '120', False)
    check('observation-preserves-checkout', latest(facts, 'E1', 'operating-hours', 10), '120')
    check('history-choose-observation', model_choice(True, False), 'observation')
    facts.append(Fact('E1', 'condition', 'scratched', 'category', 12))
    check('multiple-kinds-remain-distinct', latest(facts, 'E1', 'condition', 12), 'scratched')
    # Synthetic clinical structure comparison; no diagnostic interpretation.
    facts += [Fact('P1', 'height', '170', 'cm', 9), Fact('P1', 'height', '171', 'cm', 13)]
    check('independent-subject-history', latest(facts, 'P1', 'height', 10), '170')
    check('subject-isolation', latest(facts, 'P2', 'height', 10), None)
    check('raw-number-unit-error', Decimal('60') == Decimal('1'), False)
    check('explicit-minute-hour-normalization', Decimal('60') / 60 == Decimal('1'), True)
    print('PASS 08: 10 scenarios; selection table is a teaching policy, not inferred suitability')


if __name__ == '__main__':
    main()
