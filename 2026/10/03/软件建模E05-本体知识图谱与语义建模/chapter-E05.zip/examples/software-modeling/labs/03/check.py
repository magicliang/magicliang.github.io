import platform
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def main():
    db = sqlite3.connect(":memory:")
    db.executescript((ROOT / "models/03/schema.sql").read_text())
    assert db.execute("PRAGMA foreign_keys").fetchone() == (1,)
    print(f"ENV python={platform.python_version()} sqlite={sqlite3.sqlite_version} foreign_keys=1")
    db.execute("INSERT INTO party VALUES ('P1','教学客户')")
    db.execute("INSERT INTO equipment VALUES ('E1')")
    insert = "INSERT INTO receipt VALUES (?, ?, ?, ?, ?, ?)"
    db.execute(insert, ("A", "E1", "P1", 10, 12, "CONFIRMED"))
    db.execute(insert, ("B", "E1", "P1", 11, 13, "OVERLAP_REJECTED"))
    db.execute(insert, ("C", "E1", None, 12, 13, "CONFIRMED"))
    db.execute("INSERT INTO booking VALUES ('A')")
    db.execute("INSERT INTO booking VALUES ('C')")
    assert db.execute("SELECT count(*) FROM receipt WHERE party_id='P1'").fetchone() == (2,)
    assert db.execute("SELECT party_id FROM receipt WHERE request_id='C'").fetchone() == (None,)
    assert db.execute("SELECT count(*) FROM booking WHERE request_id='B'").fetchone() == (0,)
    print("PASS cardinality: party_has_two_receipts, anonymous_receipt, rejected_without_booking")
    negative = [
        ("missing_equipment", insert, ("D", "missing", None, 14, 15, "CONFIRMED"), "FOREIGN KEY"),
        ("missing_party", insert, ("D", "E1", "missing", 14, 15, "CONFIRMED"), "FOREIGN KEY"),
        ("duplicate_request", insert, ("A", "E1", None, 14, 15, "CONFIRMED"), "UNIQUE"),
        ("empty_period", insert, ("D", "E1", None, 14, 14, "CONFIRMED"), "CHECK"),
        ("orphan_booking", "INSERT INTO booking VALUES (?)", ("missing",), "FOREIGN KEY"),
        ("duplicate_booking", "INSERT INTO booking VALUES (?)", ("A",), "UNIQUE"),
        ("delete_referenced_receipt", "DELETE FROM receipt WHERE request_id=?", ("A",), "FOREIGN KEY"),
    ]
    for name, sql, values, reason in negative:
        try:
            db.execute(sql, values)
        except sqlite3.IntegrityError as error:
            assert reason in str(error), (name, str(error))
            print(f"PASS rejects_{name}: {error}")
        else:
            raise AssertionError(f"negative fixture accepted: {name}")
    before = db.execute("SELECT * FROM receipt WHERE request_id='A'").fetchone()
    db.execute("DELETE FROM booking WHERE request_id='A'")
    assert db.execute("SELECT * FROM receipt WHERE request_id='A'").fetchone() == before
    assert db.execute("SELECT count(*) FROM booking WHERE request_id='A'").fetchone() == (0,)
    print("PASS cancel_preserves_original_receipt")
    db.execute("SAVEPOINT gap")
    db.execute("INSERT INTO booking VALUES ('B')")
    db.execute(insert, ("OVERLAP", "E1", None, 12, 14, "CONFIRMED"))
    db.execute("INSERT INTO booking VALUES ('OVERLAP')")
    assert db.execute("SELECT count(*) FROM booking").fetchone() == (3,)
    db.execute("ROLLBACK TO gap")
    print("GAP confirmed: schema permits rejected booking and overlapping confirmed periods")
    assert db.execute("PRAGMA foreign_key_check").fetchall() == []
    print("PASS foreign_key_check_empty")
    db.close()


if __name__ == "__main__":
    main()
