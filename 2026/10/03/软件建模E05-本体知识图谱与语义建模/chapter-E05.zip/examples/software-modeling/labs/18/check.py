import argparse
import hashlib
import json
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


LAB = Path(__file__).resolve().parent
MODEL = LAB.parents[1] / "models/18"


def run(output):
    output.mkdir(parents=True, exist_ok=True)
    results = []

    def stage(name, args, cwd=LAB, expected=0, stdin=None):
        process = subprocess.run([sys.executable, *args], cwd=cwd, input=stdin,
                                 text=True, capture_output=True)
        (output / f"{name}.stdout.txt").write_text(process.stdout)
        (output / f"{name}.stderr.txt").write_text(process.stderr)
        results.append({"stage": name, "args": args, "exit_code": process.returncode, "expected": expected})
        (output / "stages.json").write_text(json.dumps(results, indent=2))
        assert process.returncode == expected, (name, process.stdout, process.stderr)
        print(f"PASS {name}: exit={process.returncode}")
        return process

    (output / "environment.json").write_text(json.dumps({"python": platform.python_version(), "platform": platform.platform()}, indent=2))
    red = stage("baseline", ["acceptance.py", "baseline"], expected=1)
    assert "NotImplementedError: F02 not implemented" in red.stderr
    stage("acceptance", ["acceptance.py", "rental"])
    stage("unit", ["-m", "unittest", "-v", "test_rental"])
    with tempfile.TemporaryDirectory(prefix="fdd-integration-") as directory:
        target = Path(directory)
        manifest = {}
        for name in ("baseline.py", "rental.py", "test_rental.py", "cli.py"):
            source = LAB / name
            shutil.copyfile(source, target / name)
            digest = hashlib.sha256(source.read_bytes()).hexdigest()
            assert hashlib.sha256((target / name).read_bytes()).hexdigest() == digest
            manifest[name] = digest
        (output / "integration-manifest.json").write_text(json.dumps(manifest, indent=2))
        stage("integrated-unit", ["-m", "unittest", "-v", "test_rental"], cwd=target)
        commands = (MODEL / "integration.json").read_text()
        result = stage("integrated-cli", ["cli.py"], cwd=target, stdin=commands)
        actual = json.loads(result.stdout)
        assert [r["ok"] for r in actual["results"]] == [True, True, True, False, True, True]
        assert actual["results"][3] == {"ok": False, "error": "conflict"}
        assert actual["results"][4]["rental"]["period"] == {"start": 1, "end": 5}
        assert set(actual["rentals"]) == {"R2", "R3"}
        assert actual["rentals"]["R3"]["period"] == {"start": 1, "end": 5}
    print("RESULT baseline RED observed; acceptance GREEN; 12 unit tests; isolated integration GREEN")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.output:
        run(args.output.resolve())
    else:
        with tempfile.TemporaryDirectory(prefix="fdd-evidence-") as temporary:
            run(Path(temporary))
