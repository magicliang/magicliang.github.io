import rental.RentalDesk;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.time.zone.ZoneRulesProvider;
import java.util.*;

public class ValueCheck {
    record Money(BigDecimal amount, Currency currency) {
        Money {
            Objects.requireNonNull(currency);
            amount = Objects.requireNonNull(amount).setScale(2, RoundingMode.UNNECESSARY);
        }
        Money add(Money other) {
            if (!currency.equals(other.currency)) throw new IllegalArgumentException("currency mismatch");
            return new Money(amount.add(other.amount), currency);
        }
    }
    record Quantity(BigDecimal value, String unit) {
        Quantity {
            Objects.requireNonNull(value);
            if (!Set.of("hour", "piece").contains(unit)) throw new IllegalArgumentException("unsupported unit");
        }
        Quantity add(Quantity other) {
            if (!unit.equals(other.unit)) throw new IllegalArgumentException("unit mismatch");
            return new Quantity(value.add(other.value), unit);
        }
    }
    record Revision(RentalDesk.EquipmentId id, int version, String label) {}
    static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        System.out.println("PASS " + name);
    }
    static void rejects(String name, Class<? extends RuntimeException> type, Runnable action) {
        try { action.run(); } catch (RuntimeException e) {
            if (!type.isInstance(e)) throw e;
            System.out.println("PASS " + name + " rejected=" + e.getClass().getSimpleName()); return;
        }
        throw new AssertionError("accepted " + name);
    }
    public static void main(String[] args) {
        var start = Instant.parse("2026-10-03T10:00:00Z");
        var end = start.plusSeconds(3600);
        var p = new RentalDesk.Period(start, end);
        var adjacent = new RentalDesk.Period(end, end.plusSeconds(3600));
        check("adjacent_half_open", !p.overlaps(adjacent) && !adjacent.overlaps(p));
        check("one_nanosecond_overlap", p.overlaps(new RentalDesk.Period(end.minusNanos(1), end.plusSeconds(1))));
        rejects("zero_length", IllegalArgumentException.class, () -> new RentalDesk.Period(start, start));
        rejects("reverse_interval", IllegalArgumentException.class, () -> new RentalDesk.Period(end, start));
        var zone = ZoneId.of("America/New_York");
        var day = LocalDate.of(2026, 3, 8);
        var a = day.atStartOfDay(zone).toInstant();
        var b = day.plusDays(1).atStartOfDay(zone).toInstant();
        long hours = Duration.between(a, b).toHours();
        check("calendar_day_is_23_hours", ChronoUnit.DAYS.between(day, day.plusDays(1)) == 1 && hours == 23);
        check("plus_24_hours_misses_midnight", !a.plus(Duration.ofHours(24)).equals(b));
        check("date_needs_zone", !day.atStartOfDay(ZoneOffset.UTC).toInstant().equals(a));
        System.out.println("TIME start=" + a + " end=" + b + " hours=" + hours + " tzdb=" + ZoneRulesProvider.getVersions(zone.getId()).lastKey());
        var cny = Currency.getInstance("CNY");
        var usd = Currency.getInstance("USD");
        var ten = new Money(new BigDecimal("10.0"), cny);
        check("money_normalizes_scale", ten.equals(new Money(new BigDecimal("10.00"), cny)));
        check("same_currency_sum", ten.add(ten).amount().equals(new BigDecimal("20.00")));
        rejects("cross_currency", IllegalArgumentException.class, () -> ten.add(new Money(BigDecimal.ONE, usd)));
        rejects("implicit_rounding", ArithmeticException.class, () -> new Money(new BigDecimal("10.005"), cny));
        var raw = new BigDecimal("10.005");
        check("explicit_rounding", raw.setScale(2, RoundingMode.HALF_UP).equals(new BigDecimal("10.01")) && raw.setScale(2, RoundingMode.HALF_EVEN).equals(new BigDecimal("10.00")));
        check("bigdecimal_equality_boundary", !new BigDecimal("10.0").equals(new BigDecimal("10.00")) && new BigDecimal("10.0").compareTo(new BigDecimal("10.00")) == 0);
        var hour = new Quantity(BigDecimal.ONE, "hour");
        check("same_unit_sum", hour.add(hour).value().compareTo(new BigDecimal("2")) == 0);
        rejects("mixed_units", IllegalArgumentException.class, () -> hour.add(new Quantity(BigDecimal.ONE, "piece")));
        var v1 = new Revision(new RentalDesk.EquipmentId("E1"), 1, "camera");
        var v2 = new Revision(v1.id(), 2, "camera-renamed");
        var other = new Revision(new RentalDesk.EquipmentId("E2"), 1, "camera");
        var history = List.of(v1, v2);
        check("same_identity_different_revision", v1.id().equals(v2.id()) && !v1.equals(v2));
        check("same_label_different_identity", v1.label().equals(other.label()) && !v1.id().equals(other.id()));
        check("history_keeps_old_label", history.get(0).label().equals("camera") && history.get(1).version() == 2);
        System.out.println("RESULT PASS chapter=07 checks=18 scope=local_value_semantics");
    }
}
