from dataclasses import dataclass
import platform


@dataclass(frozen=True)
class Period:
    start: int
    end: int

    def __post_init__(self):
        if type(self.start) is not int or type(self.end) is not int or not 0 <= self.start < self.end <= 24:
            raise ValueError("invalid UTC teaching-day period")

    def overlaps(self, other):
        return self.start < other.end and other.start < self.end


@dataclass(frozen=True)
class ProposedAction:
    identity: str
    asset_type: str
    quantity: int
    period: Period

    def __post_init__(self):
        if not self.identity or type(self.quantity) is not int or self.quantity <= 0:
            raise ValueError("positive integer quantity and identity required")


@dataclass(frozen=True)
class Allocation:
    proposed: ProposedAction
    assets: tuple


@dataclass(frozen=True)
class ImplementedAction:
    reservation: str
    quantity: int
    actual_period: Period


class ResourceBook:
    def __init__(self, mode, capacities, assets):
        if mode not in {"general", "specific"}:
            raise ValueError("unknown allocation mode")
        if any(type(value) is not int or value <= 0 for value in capacities.values()):
            raise ValueError("invalid capacity")
        if any(asset_type not in capacities for asset_type in assets.values()):
            raise ValueError("unknown asset type")
        self.mode = mode
        self.capacities = dict(capacities)
        self.assets = dict(assets)
        self.active = {}
        self.receipts = {}
        self.implemented = {}

    def book(self, proposed, assets=()):
        selected = tuple(sorted(assets))
        allocation = Allocation(proposed, selected)
        previous = self.receipts.get(proposed.identity)
        if previous is not None:
            if previous[0] != allocation:
                raise ValueError("request identity reused with different payload")
            return previous[1]
        if proposed.asset_type not in self.capacities:
            raise ValueError("unknown asset type")
        if self.mode == "general" and selected:
            raise ValueError("general allocation has no selected asset")
        if self.mode == "specific":
            if len(selected) != proposed.quantity or len(set(selected)) != len(selected):
                raise ValueError("asset count or duplicate mismatch")
            if any(self.assets.get(asset) != proposed.asset_type for asset in selected):
                raise ValueError("asset type mismatch")
            conflict = any(proposed.period.overlaps(other.proposed.period)
                           and bool(set(selected) & set(other.assets)) for other in self.active.values())
        else:
            peers = [other.proposed for other in self.active.values()
                     if other.proposed.asset_type == proposed.asset_type and proposed.period.overlaps(other.proposed.period)]
            boundaries = {proposed.period.start, proposed.period.end}
            for peer in peers:
                boundaries.add(max(proposed.period.start, peer.period.start))
                boundaries.add(min(proposed.period.end, peer.period.end))
            conflict = any(proposed.quantity + sum(peer.quantity for peer in peers
                           if peer.period.start <= point < peer.period.end) > self.capacities[proposed.asset_type]
                           for point in sorted(boundaries)[:-1])
        result = "REJECTED" if conflict else "CONFIRMED"
        self.receipts[proposed.identity] = (allocation, result)
        if not conflict:
            self.active[proposed.identity] = allocation
        return result

    def cancel(self, identity):
        if identity in self.implemented:
            raise ValueError("implemented action locks cancellation")
        return self.active.pop(identity, None) is not None

    def implement(self, identity, quantity, actual_period):
        allocation = self.active.get(identity)
        if allocation is None:
            raise ValueError("no active commitment")
        if identity in self.implemented:
            raise ValueError("actual action already recorded")
        promised = allocation.proposed
        if type(quantity) is not int or not 0 < quantity <= promised.quantity:
            raise ValueError("actual quantity outside promise")
        if not promised.period.start <= actual_period.start < actual_period.end <= promised.period.end:
            raise ValueError("actual period outside promise")
        action = ImplementedAction(identity, quantity, actual_period)
        self.implemented[identity] = action
        return action


checks = 0


def expect(label, actual, expected):
    global checks
    if actual != expected:
        raise AssertionError(f"{label}: {actual!r} != {expected!r}")
    checks += 1
    print(f"PASS {label} actual={actual}")


def reject(label, call, message):
    global checks
    try:
        call()
    except ValueError as error:
        if message not in str(error):
            raise AssertionError(f"wrong rejection {error}") from error
        checks += 1
        print(f"REJECT {label} {error}")
    else:
        raise AssertionError(f"accepted {label}")


def plan(identity, start=10, end=12, quantity=1, asset_type="CAM-A"):
    return ProposedAction(identity, asset_type, quantity, Period(start, end))


def book(mode):
    return ResourceBook(mode, {"CAM-A": 2, "PROJECTOR": 1},
                        {"E1": "CAM-A", "E2": "CAM-A", "P1": "PROJECTOR"})


def main():
    print(f"Python {platform.python_version()}; fixed day=2026-10-03 UTC; [start,end)")
    general = book("general")
    a = plan("A", quantity=2)
    expect("plan_alone_reserves_nothing", len(general.active), 0)
    reject("plan_is_not_actual", lambda: general.implement("A", 1, Period(10, 11)), "no active commitment")
    expect("general_two_units", general.book(a), "CONFIRMED")
    expect("commitment_is_not_actual", len(general.implemented), 0)
    b = plan("B", 11, 13)
    expect("general_capacity_conflict", general.book(b), "REJECTED")
    expect("general_adjacent", general.book(plan("C", 12, 13, 2)), "CONFIRMED")
    expect("general_cancel_A", general.cancel("A"), True)
    expect("general_cancel_C", general.cancel("C"), True)
    expect("general_retry_keeps_rejection", general.book(b), "REJECTED")
    expect("general_replay_cancelled", general.book(a), "CONFIRMED")
    expect("general_replay_does_not_rebook", "A" in general.active, False)
    expect("general_fresh_after_release", general.book(plan("F", 11, 13, 2)), "CONFIRMED")
    reject("changed_retry", lambda: general.book(plan("F", 11, 13, 1)), "different payload")

    sweep = book("general")
    sweep.book(plan("L", 10, 11))
    sweep.book(plan("R", 11, 12))
    expect("capacity_peak_not_overlap_sum", sweep.book(plan("W", 10, 12)), "CONFIRMED")
    expect("capacity_excess_on_subinterval", sweep.book(plan("X", 10, 11)), "REJECTED")

    specific = book("specific")
    s1 = plan("S1")
    expect("specific_E1", specific.book(s1, ("E1",)), "CONFIRMED")
    expect("specific_same_asset_conflict", specific.book(plan("S-B", 11, 13), ("E1",)), "REJECTED")
    expect("specific_other_asset", specific.book(plan("S-E2"), ("E2",)), "CONFIRMED")
    expect("specific_adjacent", specific.book(plan("S-C", 12, 13), ("E1",)), "CONFIRMED")
    reject("wrong_type", lambda: specific.book(plan("TYPE"), ("P1",)), "asset type")
    reject("duplicate_asset", lambda: specific.book(plan("DUP", quantity=2), ("E1", "E1")), "count or duplicate")
    specific.cancel("S-E2")
    specific.cancel("S1")
    expect("replacement_new_request_E2", specific.book(plan("S2"), ("E2",)), "CONFIRMED")
    expect("old_request_receipt_survives", specific.book(s1, ("E1",)), "CONFIRMED")
    expect("replacement_releases_E1", specific.book(plan("S3"), ("E1",)), "CONFIRMED")

    partial = book("general")
    partial.book(plan("PART", quantity=2))
    reject("over_delivery", lambda: partial.implement("PART", 3, Period(10, 11)), "quantity")
    reject("outside_promised_time", lambda: partial.implement("PART", 1, Period(9, 11)), "period")
    actual = partial.implement("PART", 1, Period(10, 11))
    expect("partial_fulfillment", (actual.quantity, actual.actual_period), (1, Period(10, 11)))
    expect("promise_retained_after_partial", partial.active["PART"].proposed.quantity, 2)
    reject("cancel_after_actual", lambda: partial.cancel("PART"), "locks cancellation")
    expect("failed_cancel_keeps_promise", "PART" in partial.active, True)
    reject("duplicate_actual", lambda: partial.implement("PART", 1, Period(10, 11)), "already recorded")
    reject("empty_period", lambda: Period(10, 10), "period")
    reject("fractional_count", lambda: plan("FRACTION", quantity=1.5), "integer quantity")
    print(f"PASS 14: {checks} scenarios; plan != commitment != actual")


if __name__ == "__main__":
    main()
