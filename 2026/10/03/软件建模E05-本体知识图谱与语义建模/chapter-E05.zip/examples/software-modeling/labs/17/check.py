import copy
import json
from pathlib import Path


def validate(plan):
    features = plan["features"]
    ids = [f["id"] for f in features]
    if len(ids) != len(set(ids)):
        raise ValueError("duplicate feature")
    by_id = {f["id"]: f for f in features}
    occupancy = set()
    for feature in features:
        if not feature["name"] or not feature["activity"] or not feature["area"]:
            raise ValueError("missing business description")
        if not feature["classes"] or set(feature["classes"]) - plan["classes"].keys():
            raise ValueError("unknown or empty class mapping")
        if not feature["scenarios"] or set(feature["scenarios"]) - plan["scenarios"].keys():
            raise ValueError("unknown or empty scenario mapping")
        if type(feature["slot"]) is not int or feature["slot"] < 1:
            raise ValueError("invalid slot")
        for dep in feature["depends_on"]:
            if dep not in by_id or by_id[dep]["slot"] >= feature["slot"]:
                raise ValueError("unknown dependency or invalid order")
        owners = {plan["classes"][c] for c in feature["classes"]}
        if "" in owners:
            raise ValueError("missing owner")
        for owner in owners:
            key = (feature["slot"], owner)
            if key in occupancy:
                raise ValueError("owner capacity conflict")
            occupancy.add(key)
    return {f["id"]: sorted({plan["classes"][c] for c in f["classes"]}) for f in features}


def main():
    path = Path(__file__).resolve().parents[2] / "models/17/plan.json"
    plan = json.loads(path.read_text())
    teams = validate(plan)
    print("PASS valid-plan " + json.dumps(teams, sort_keys=True))
    mutations = [
        ("duplicate", lambda p: p["features"].append(copy.deepcopy(p["features"][0])), "duplicate feature"),
        ("unknown-class", lambda p: p["features"][1]["classes"].append("Ghost"), "unknown or empty class mapping"),
        ("empty-class", lambda p: p["features"][1].update(classes=[]), "unknown or empty class mapping"),
        ("missing-scenario", lambda p: p["features"][1].update(scenarios=[]), "unknown or empty scenario mapping"),
        ("unknown-scenario", lambda p: p["features"][1].update(scenarios=["ghost"]), "unknown or empty scenario mapping"),
        ("unknown-dependency", lambda p: p["features"][1].update(depends_on=["F99"]), "unknown dependency or invalid order"),
        ("dependency-cycle", lambda p: p["features"][0].update(depends_on=["F02"]), "unknown dependency or invalid order"),
        ("owner-conflict", lambda p: p["features"][2].update(slot=2), "owner capacity conflict"),
        ("missing-owner", lambda p: p["classes"].update(Period=""), "missing owner"),
        ("missing-business", lambda p: p["features"][1].update(name=""), "missing business description"),
        ("invalid-slot", lambda p: p["features"][1].update(slot=0), "invalid slot"),
    ]
    for name, mutate, expected in mutations:
        candidate = copy.deepcopy(plan)
        mutate(candidate)
        try:
            validate(candidate)
        except ValueError as exc:
            assert str(exc) == expected, (name, str(exc))
            print(f"PASS reject-{name}: {exc}")
        else:
            raise AssertionError(f"accepted invalid plan: {name}")
    print("RESULT 12 checks passed; business behavior NOT_EXECUTED")


if __name__ == "__main__":
    main()
