"""Rental adaptation of activity/document component ideas; in-memory only."""
from dataclasses import dataclass, replace
from pathlib import Path
import json


@dataclass(frozen=True)
class Resource:
    id: str
    kind: str


@dataclass(frozen=True)
class Template:
    id: str
    revision: int
    heading: str


@dataclass(frozen=True)
class Rental:
    id: str
    party: str
    resource: str
    required_kind: str
    start: int
    end: int


@dataclass(frozen=True)
class Document:
    rental_id: str
    revision: int
    template: Template
    resource: str
    start: int
    end: int


class RentalService:
    def __init__(self, resources: list[Resource], template: Template):
        self.resources = {r.id: r for r in resources}
        self.template = template
        self.rentals: dict[str, Rental] = {}
        self.documents: dict[str, tuple[Document, ...]] = {}

    def validate(self, candidate: Rental) -> None:
        if candidate.start >= candidate.end:
            raise ValueError('empty or reversed interval')
        resource = self.resources.get(candidate.resource)
        if resource is None or resource.kind != candidate.required_kind:
            raise ValueError('resource kind mismatch or missing resource')
        for existing in self.rentals.values():
            if existing.id == candidate.id:
                continue
            if existing.resource == candidate.resource and candidate.start < existing.end and existing.start < candidate.end:
                raise ValueError('overlapping resource commitment')

    def make_document(self, candidate: Rental) -> Document:
        previous = self.documents.get(candidate.id, ())
        template = previous[0].template if previous else self.template
        return Document(candidate.id, len(previous) + 1, template, candidate.resource, candidate.start, candidate.end)

    def save(self, candidate: Rental) -> None:
        self.validate(candidate)
        document = self.make_document(candidate)
        self.rentals[candidate.id] = candidate
        self.documents[candidate.id] = self.documents.get(candidate.id, ()) + (document,)

    def create(self, rental: Rental) -> None:
        if rental.id in self.rentals:
            raise ValueError('duplicate rental id')
        self.save(rental)

    def extend(self, rental_id: str, new_end: int) -> None:
        old = self.rentals[rental_id]
        if new_end <= old.end:
            raise ValueError('extension must lengthen rental')
        self.save(replace(old, end=new_end))

    def substitute(self, rental_id: str, resource_id: str) -> None:
        self.save(replace(self.rentals[rental_id], resource=resource_id))

    def naive_extend_document_first(self, rental_id: str, new_end: int) -> None:
        candidate = replace(self.rentals[rental_id], end=new_end)
        self.documents[rental_id] += (self.make_document(candidate),)
        self.validate(candidate)
        self.rentals[rental_id] = candidate


def check(name, actual, expected):
    if actual != expected:
        raise AssertionError((name, actual, expected))
    print(json.dumps({'scenario': name, 'actual': actual, 'expected': expected, 'pass': True}, ensure_ascii=False))


def rejects(name, operation):
    try:
        operation()
    except ValueError as error:
        print(json.dumps({'scenario': name, 'rejected': str(error), 'pass': True}))
        return
    raise AssertionError(name + ': invalid input accepted')


def setup(fixture):
    service = RentalService([Resource(**r) for r in fixture['resources']], Template(**fixture['template']))
    service.create(Rental('A1', 'P1', 'E1', 'camera', 10, 11))
    service.create(Rental('A2', 'P2', 'E1', 'camera', 12, 14))
    service.create(Rental('A3', 'P3', 'E2', 'camera', 10, 12))
    return service


def main():
    fixture = json.loads((Path(__file__).parents[2] / 'models/16/fixture.json').read_text())
    service = setup(fixture)
    rejects('extension-conflict', lambda: service.extend('A1', 13))
    check('failed-extension-keeps-rental-and-document', [service.rentals['A1'].end, len(service.documents['A1'])], [11, 1])
    service.extend('A1', 12)
    check('adjacent-extension-accepted', service.rentals['A1'].end, 12)
    check('extension-retains-original-document', [(d.revision, d.end) for d in service.documents['A1']], [(1, 11), (2, 12)])
    rejects('substitute-occupied-resource', lambda: service.substitute('A1', 'E2'))
    rejects('substitute-incompatible-kind', lambda: service.substitute('A1', 'E3'))
    check('failed-substitutions-keep-state', [service.rentals['A1'].resource, len(service.documents['A1'])], ['E1', 2])
    service.template = replace(service.template, revision=2, heading='New rental form')
    service.substitute('A1', 'E4')
    check('compatible-free-replacement', service.rentals['A1'].resource, 'E4')
    check('replacement-keeps-old-resource-history', [d.resource for d in service.documents['A1']], ['E1', 'E1', 'E4'])
    check('existing-rental-keeps-template-version', [d.template.revision for d in service.documents['A1']], [1, 1, 1])
    service.create(Rental('A4', 'P4', 'E1', 'camera', 10, 12))
    check('replacement-releases-old-resource', service.rentals['A4'].resource, 'E1')
    check('new-rental-selects-new-template', service.documents['A4'][0].template.revision, 2)
    rejects('extension-cannot-shorten', lambda: service.extend('A1', 11))
    rejects('duplicate-rental-id', lambda: service.create(service.rentals['A1']))
    naive = setup(fixture)
    rejects('naive-document-first-still-fails-capacity', lambda: naive.naive_extend_document_first('A1', 13))
    check('naive-partial-update-is-observable', [naive.rentals['A1'].end, naive.documents['A1'][-1].end], [11, 13])
    print('PASS 16: 16 behavior scenarios; sequential in-memory validation only, no durable transaction guarantee')


if __name__ == '__main__':
    main()
