"""Typed quantities and observations; deliberately restricted teaching units."""
from dataclasses import dataclass, replace
from decimal import Decimal
import json

UNITS = {'h': ('duration', Decimal('60')), 'min': ('duration', Decimal('1')),
         'cm': ('length', Decimal('1')), 'm': ('length', Decimal('100'))}


@dataclass(frozen=True)
class Quantity:
    amount: Decimal
    unit: str

    def __post_init__(self) -> None:
        if not isinstance(self.amount, Decimal) or not self.amount.is_finite() or self.unit not in UNITS:
            raise ValueError('invalid amount or unknown unit')

    def in_unit(self, unit: str) -> Decimal:
        if unit not in UNITS or UNITS[self.unit][0] != UNITS[unit][0]:
            raise ValueError('incompatible unit')
        return self.amount * UNITS[self.unit][1] / UNITS[unit][1]


@dataclass(frozen=True)
class PhenomenonType:
    name: str
    kind: str
    unit: str | None = None
    categories: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.name or self.kind not in {'numeric', 'category'}:
            raise ValueError('invalid phenomenon type')
        if self.kind == 'numeric' and (self.unit not in UNITS or self.categories):
            raise ValueError('numeric type requires unit only')
        if self.kind == 'category' and (self.unit is not None or not self.categories):
            raise ValueError('category type requires categories only')


@dataclass(frozen=True)
class Observation:
    id: str
    subject: str
    phenomenon: PhenomenonType
    valid_at: int
    recorded_at: int
    value: Quantity | str | None = None
    missing: str | None = None
    rejected: str | None = None

    def __post_init__(self) -> None:
        if not self.id or not self.subject or self.recorded_at < self.valid_at:
            raise ValueError('invalid identity or recording before observation')
        if (self.value is None) == (self.missing is None):
            raise ValueError('exactly one of value and missing reason required')
        if self.missing is not None:
            if self.missing not in {'not-measured', 'sensor-failed'}:
                raise ValueError('unknown missing reason')
            return
        p = self.phenomenon
        if p.kind == 'numeric':
            if not isinstance(self.value, Quantity):
                raise ValueError('numeric observation needs quantity')
            self.value.in_unit(p.unit)
        elif not isinstance(self.value, str) or self.value not in p.categories:
            raise ValueError('invalid category')


def available(rows: list[Observation], subject: str, known_at: int) -> list[str]:
    return [r.id for r in rows if r.subject == subject and r.recorded_at <= known_at and not r.rejected]


def check(name, actual, expected):
    if actual != expected:
        raise AssertionError((name, actual, expected))
    print(json.dumps({'scenario': name, 'actual': actual, 'expected': expected, 'pass': True}, ensure_ascii=False))


def rejects(name, action):
    try:
        action()
    except ValueError as error:
        print(json.dumps({'scenario': name, 'rejected': str(error), 'pass': True}))
        return
    raise AssertionError(name + ': accepted invalid input')


def main():
    hours = PhenomenonType('operating-hours', 'numeric', 'h')
    condition = PhenomenonType('condition', 'category', categories=('intact', 'scratched'))
    height = PhenomenonType('height', 'numeric', 'cm')
    q = Quantity(Decimal('60'), 'min')
    check('convert-minute-to-hour', str(q.in_unit('h')), '1')
    check('convert-meter-to-cm', str(Quantity(Decimal('1.70'), 'm').in_unit('cm')), '170.00')
    n = Observation('N1', 'E1', hours, 10, 12, q)
    c = Observation('C1', 'E1', condition, 10, 10, 'scratched')
    check('numeric-and-category-distinct', [n.phenomenon.kind, c.phenomenon.kind], ['numeric', 'category'])
    check('late-record-not-yet-known', available([n, c], 'E1', 11), ['C1'])
    check('late-record-known-later', available([n, c], 'E1', 12), ['N1', 'C1'])
    missing = Observation('M1', 'E1', hours, 11, 11, missing='sensor-failed')
    zero = Observation('Z1', 'E1', hours, 11, 11, Quantity(Decimal('0'), 'h'))
    check('missing-not-zero', [missing.value is None, zero.value.amount == 0], [True, True])
    rejected = replace(n, rejected='instrument calibration invalid')
    check('rejected-retained-but-excluded', [rejected.id, available([rejected, c], 'E1', 12)], ['N1', ['C1']])
    clinical = Observation('H1', 'P1', height, 9, 9, Quantity(Decimal('170'), 'cm'))
    check('synthetic-clinical-quantity', str(clinical.value.in_unit('m')), '1.7')
    rejects('wrong-dimension', lambda: Observation('X', 'E1', hours, 10, 10, Quantity(Decimal('2'), 'm')))
    rejects('category-in-measurement', lambda: Observation('X', 'E1', hours, 10, 10, 'scratched'))
    rejects('number-in-category', lambda: Observation('X', 'E1', condition, 10, 10, q))
    rejects('unknown-category', lambda: Observation('X', 'E1', condition, 10, 10, 'normal-ish'))
    rejects('unexplained-null', lambda: Observation('X', 'E1', hours, 10, 10))
    rejects('value-with-missing', lambda: Observation('X', 'E1', hours, 10, 10, q, 'sensor-failed'))
    rejects('unknown-unit', lambda: Quantity(Decimal('1'), 'fortnight'))
    rejects('nonfinite-value', lambda: Quantity(Decimal('NaN'), 'h'))
    rejects('record-before-valid', lambda: Observation('X', 'E1', hours, 10, 9, q))
    print('PASS 10: 17 scenarios; no clinical diagnosis, full dimensional algebra or bitemporal revision store')


if __name__ == '__main__':
    main()
