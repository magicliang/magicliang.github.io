package rental;

import java.time.Instant;
import rental.RentalDesk.*;

public final class BaselineCheck {
    private static int checks;
    private static final Instant BASE = Instant.parse("2026-10-02T00:00:00Z");

    public static void main(String[] args) {
        expect(IllegalArgumentException.class, () -> new EquipmentId(" "), "blank equipment id");
        expect(IllegalArgumentException.class, () -> new RequestId(null), "null request id");
        expect(IllegalArgumentException.class, () -> period(10, 10), "zero-length interval");
        expect(IllegalArgumentException.class, () -> period(20, 10), "reversed interval");
        expect(NullPointerException.class, () -> new Period(null, BASE), "missing start");
        expect(NullPointerException.class, () -> new Period(BASE, null), "missing end");
        expect(NullPointerException.class, () -> new ReserveRequest(null, new EquipmentId("camera"), period(10, 20)), "missing request identity");
        expect(NullPointerException.class, () -> new ReserveRequest(new RequestId("x"), null, period(10, 20)), "missing equipment identity");
        expect(NullPointerException.class, () -> new ReserveRequest(new RequestId("x"), new EquipmentId("camera"), null), "missing period");

        long[][] candidates = {{5, 10}, {20, 25}, {0, 5}, {25, 30}, {5, 11}, {19, 25}, {12, 18}, {5, 25}, {10, 20}, {10, 15}, {15, 20}};
        Outcome[] expected = {Outcome.CONFIRMED, Outcome.CONFIRMED, Outcome.CONFIRMED, Outcome.CONFIRMED,
                Outcome.OVERLAP_REJECTED, Outcome.OVERLAP_REJECTED, Outcome.OVERLAP_REJECTED,
                Outcome.OVERLAP_REJECTED, Outcome.OVERLAP_REJECTED, Outcome.OVERLAP_REJECTED, Outcome.OVERLAP_REJECTED};
        for (int i = 0; i < candidates.length; i++) {
            RentalDesk desk = new RentalDesk();
            check(desk.reserve(request("base", "camera", 10, 20)) == Outcome.CONFIRMED, "reference booking " + i);
            long[] candidate = candidates[i];
            check(desk.reserve(request("candidate", "camera", candidate[0], candidate[1])) == expected[i],
                    "interval [" + candidate[0] + "," + candidate[1] + ") against [10,20): " + expected[i]);
        }

        RentalDesk desk = new RentalDesk();
        ReserveRequest original = request("r1", "camera", 10, 20);
        check(desk.reserve(original) == Outcome.CONFIRMED, "initial request confirmed");
        check(desk.reserve(request("r1", "camera", 10, 20)) == Outcome.CONFIRMED, "same payload retry returns original outcome");
        expect(IllegalArgumentException.class, () -> desk.reserve(request("r1", "camera", 20, 30)), "changed interval under reused id rejected");
        expect(IllegalArgumentException.class, () -> desk.reserve(request("r1", "tripod", 10, 20)), "changed equipment under reused id rejected");
        check(desk.reserve(request("r2", "camera", 12, 18)) == Outcome.OVERLAP_REJECTED, "failed changed payload leaves original booking active");
        check(desk.reserve(request("r3", "tripod", 10, 20)) == Outcome.CONFIRMED, "different equipment accepts same interval");
        check(!desk.cancel(new RequestId("unknown")), "unknown cancellation changes nothing");
        check(!desk.cancel(new RequestId("r2")), "rejected request has no booking to cancel");
        check(desk.cancel(new RequestId("r1")), "cancellation releases original booking");
        check(!desk.cancel(new RequestId("r1")), "repeated cancellation reports no active booking");
        check(desk.reserve(original) == Outcome.CONFIRMED, "retry after cancellation retains original outcome");
        check(desk.reserve(request("r2", "camera", 12, 18)) == Outcome.OVERLAP_REJECTED, "rejected outcome remains stable after availability changes");
        expect(IllegalArgumentException.class, () -> desk.reserve(request("r2", "camera", 30, 40)), "rejected request id cannot change payload");
        check(desk.reserve(request("r4", "camera", 10, 20)) == Outcome.CONFIRMED, "new request uses released interval; old retry did not rebook");
        check(desk.reserve(request("r5", "camera", 12, 18)) == Outcome.OVERLAP_REJECTED, "replacement booking protects released interval again");
        expect(NullPointerException.class, () -> desk.reserve(null), "null request rejected");
        expect(NullPointerException.class, () -> desk.cancel(null), "null cancellation rejected");
        System.out.println("PASS total=" + checks);
    }

    private static Period period(long start, long end) {
        return new Period(BASE.plusSeconds(start), BASE.plusSeconds(end));
    }

    private static ReserveRequest request(String id, String equipment, long start, long end) {
        return new ReserveRequest(new RequestId(id), new EquipmentId(equipment), period(start, end));
    }

    private static void check(boolean condition, String scenario) {
        if (!condition) throw new AssertionError(scenario);
        checks++;
        System.out.println("PASS " + scenario);
    }

    private static void expect(Class<? extends Throwable> expected, Runnable action, String scenario) {
        try {
            action.run();
        } catch (Throwable failure) {
            if (!expected.isInstance(failure)) throw new AssertionError(scenario, failure);
            check(true, scenario + " -> " + expected.getSimpleName());
            return;
        }
        throw new AssertionError(scenario + ": expected " + expected.getSimpleName());
    }
}
