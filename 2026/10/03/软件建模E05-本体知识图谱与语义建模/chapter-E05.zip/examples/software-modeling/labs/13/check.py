from decimal import Decimal, InvalidOperation
from pathlib import Path
import platform
import sqlite3


def minor(text):
    try:
        value = Decimal(text)
    except InvalidOperation as error:
        raise ValueError("invalid amount") from error
    if not value.is_finite() or value.copy_abs() > Decimal("1000000000"):
        raise ValueError("amount outside teaching range")
    if value == 0:
        return 0
    sign, digits, exponent = value.as_tuple()
    while digits[-1] == 0:
        digits = digits[:-1]
        exponent += 1
    if exponent < -2:
        raise ValueError("fractional minor unit")
    coefficient = int("".join(map(str, digits)))
    return (-1 if sign else 1) * coefficient * 10 ** (exponent + 2)


class Ledger:
    def __init__(self):
        self.db = sqlite3.connect(":memory:")
        schema = Path(__file__).resolve().parents[2] / "models/13/schema.sql"
        self.db.executescript(schema.read_text())
        with self.db:
            self.db.executemany("INSERT INTO account VALUES (?,?)", [
                ("receivable", "CNY"), ("revenue", "CNY"),
                ("cash", "CNY"), ("usd-cash", "USD")])

    def fact(self, identity, kind, amount, currency="CNY"):
        if kind not in {"fee", "payment", "reversal", "discount", "refund"}:
            raise ValueError("unknown fact kind")
        if currency not in {"CNY", "USD"} or minor(amount) <= 0:
            raise ValueError("invalid fact amount/currency")
        with self.db:
            self.db.execute("INSERT INTO fact VALUES (?,?,?,?,?)", (
                identity, kind, currency, minor(amount), "2026-10-03T10:00:00Z"))

    def post(self, identity, fact_id, lines, reverses=None, fail_after=None):
        fact = self.db.execute("SELECT currency, amount_minor FROM fact WHERE id=?", (fact_id,)).fetchone()
        if fact is None:
            raise ValueError("unknown fact")
        if len(lines) < 2:
            raise ValueError("at least two entries")
        normalized = []
        for account, amount in lines:
            row = self.db.execute("SELECT currency FROM account WHERE id=?", (account,)).fetchone()
            if row is None or row[0] != fact[0]:
                raise ValueError("account currency mismatch")
            value = minor(amount)
            if value == 0:
                raise ValueError("zero entry")
            normalized.append((account, value))
        if sum(value for _, value in normalized) != 0:
            raise ValueError("unbalanced journal")
        if sum(value for _, value in normalized if value > 0) != fact[1]:
            raise ValueError("fact amount mismatch")
        with self.db:
            self.db.execute("INSERT INTO journal VALUES (?,?,?)", (identity, fact_id, reverses))
            for index, (account, value) in enumerate(normalized):
                self.db.execute("INSERT INTO entry VALUES (?,?,?,?)", (identity, index, account, value))
                if fail_after == index + 1:
                    raise RuntimeError("injected storage failure")

    def reverse(self, original, identity, fact_id):
        rows = self.db.execute("SELECT account_id,amount_minor FROM entry WHERE journal_id=? ORDER BY ordinal", (original,)).fetchall()
        if not rows:
            raise ValueError("unknown original journal")
        self.post(identity, fact_id, [(account, str(Decimal(-value) / 100)) for account, value in rows], original)

    def entries(self):
        return self.db.execute("SELECT * FROM entry ORDER BY journal_id,ordinal").fetchall()

    def balances(self):
        return dict(self.db.execute("SELECT account_id,SUM(amount_minor) FROM entry GROUP BY account_id"))


checks = 0


def expect(label, actual, expected):
    global checks
    if actual != expected:
        raise AssertionError(f"{label}: {actual!r} != {expected!r}")
    checks += 1
    print(f"PASS {label} actual={actual}")


def reject(label, operation, category, message):
    global checks
    try:
        operation()
    except category as error:
        if message not in str(error):
            raise AssertionError(f"wrong rejection: {error}") from error
        checks += 1
        print(f"REJECT {label} {type(error).__name__}: {error}")
    else:
        raise AssertionError(f"accepted {label}")


def main():
    print(f"Python {platform.python_version()} SQLite {sqlite3.sqlite_version}")
    ledger = Ledger()
    for args in [("F1", "fee", "120.00"), ("V1", "reversal", "120.00"),
                 ("F2", "fee", "100.00"), ("P1", "payment", "100.00"),
                 ("D1", "discount", "25.00"), ("R1", "refund", "25.00")]:
        ledger.fact(*args)
    expect("fee_fact_does_not_post", ledger.entries(), [])
    ledger.post("T1", "F1", [("receivable", "120"), ("revenue", "-120")])
    original = ledger.entries()
    ledger.reverse("T1", "T1-R", "V1")
    expect("reversal_preserves_original", [row for row in ledger.entries() if row[0] == "T1"], original)
    expect("reversal_zero_balances", ledger.balances(), {"receivable": 0, "revenue": 0})
    ledger.post("T2", "F2", [("receivable", "100"), ("revenue", "-100")])
    ledger.post("T3", "P1", [("cash", "100"), ("receivable", "-100")])
    ledger.post("T4", "D1", [("revenue", "25"), ("receivable", "-25")])
    expect("discount_is_not_cash_refund", ledger.balances(), {"cash": 10000, "receivable": -2500, "revenue": -7500})
    ledger.post("T5", "R1", [("receivable", "25"), ("cash", "-25")])
    expect("final_balances_minor", ledger.balances(), {"cash": 7500, "receivable": 0, "revenue": -7500})
    sums = ledger.db.execute("SELECT journal_id,COUNT(*),SUM(amount_minor) FROM entry GROUP BY journal_id").fetchall()
    expect("six_balanced_journals", len(sums), 6)
    expect("every_journal_two_legs_zero", all(count >= 2 and total == 0 for _, count, total in sums), True)
    before = ledger.entries()
    reject("unbalanced", lambda: ledger.post("BAD1", "F2", [("receivable", "100"), ("revenue", "-99")]), ValueError, "unbalanced")
    reject("cross_currency", lambda: ledger.post("BAD2", "F2", [("usd-cash", "100"), ("revenue", "-100")]), ValueError, "currency")
    reject("single_entry", lambda: ledger.post("BAD3", "F2", [("receivable", "100")]), ValueError, "two entries")
    reject("wrong_fact_amount", lambda: ledger.post("BAD4", "F2", [("cash", "50"), ("revenue", "-50")]), ValueError, "fact amount")
    reject("duplicate_journal", lambda: ledger.post("T2", "F2", [("receivable", "100"), ("revenue", "-100")]), sqlite3.IntegrityError, "journal.id")
    reject("duplicate_reversal", lambda: ledger.reverse("T1", "SECOND-R", "V1"), sqlite3.IntegrityError, "journal.reverses")
    reject("overwrite_entry", lambda: ledger.db.execute("UPDATE entry SET amount_minor=1 WHERE journal_id='T1'"), sqlite3.IntegrityError, "immutable entry")
    ledger.db.rollback()
    expect("rejections_preserve_entries", ledger.entries(), before)
    reject("extra_precision", lambda: minor("10.005"), ValueError, "fractional minor")
    reject("long_fraction_not_rounded", lambda: minor("10.00000000000000000000000000001"), ValueError, "fractional minor")
    reject("tiny_fraction_not_zero", lambda: minor("1E-1000000"), ValueError, "fractional minor")
    reject("nonfinite", lambda: minor("NaN"), ValueError, "outside teaching range")
    reject("mid_write_failure", lambda: ledger.post("FAIL", "F2", [("receivable", "100"), ("revenue", "-100")], fail_after=1), RuntimeError, "storage failure")
    expect("database_rollback_entries", ledger.entries(), before)
    expect("database_rollback_header", ledger.db.execute("SELECT COUNT(*) FROM journal WHERE id='FAIL'").fetchone()[0], 0)

    bypass = Ledger()
    bypass.fact("F", "fee", "100")
    with bypass.db:
        bypass.db.execute("INSERT INTO journal VALUES ('BYPASS','F',NULL)")
        bypass.db.execute("INSERT INTO entry VALUES ('BYPASS',0,'cash',10000)")
    expect("db_commit_can_be_unbalanced", bypass.db.execute("SELECT SUM(amount_minor) FROM entry").fetchone()[0], 10000)
    print(f"PASS 13: {checks} scenarios; accounting_validation != database_atomicity")


if __name__ == "__main__":
    main()
