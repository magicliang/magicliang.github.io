"""Append-only complete valid-time snapshots; one service's synthetic CNY day price."""
from dataclasses import dataclass, FrozenInstanceError, replace
from datetime import date, datetime, timedelta
from pathlib import Path
import json
import platform


def utc(value):
    if not isinstance(value, datetime) or value.tzinfo is None or value.utcoffset() != timedelta(0):
        raise ValueError('UTC-aware record timestamp required')
    return value


@dataclass(frozen=True)
class Segment:
    start: date
    end: date
    cents: int

    def __post_init__(self):
        if self.start >= self.end:
            raise ValueError('empty or reverse valid interval')
        if type(self.cents) is not int or self.cents <= 0:
            raise ValueError('positive integer CNY cents required')


@dataclass(frozen=True)
class Revision:
    recorded_at: datetime
    segments: tuple[Segment, ...]

    def __post_init__(self):
        utc(self.recorded_at)
        if not isinstance(self.segments, tuple) or not self.segments:
            raise ValueError('nonempty immutable segments required')


class History:
    def __init__(self, start, end):
        if start >= end:
            raise ValueError('empty valid domain')
        self.start, self.end = start, end
        self._revisions = ()

    @property
    def revisions(self):
        return self._revisions

    def append(self, revision):
        if self._revisions and revision.recorded_at <= self._revisions[-1].recorded_at:
            raise ValueError('record time must increase strictly')
        cursor = self.start
        for segment in revision.segments:
            if segment.start != cursor:
                raise ValueError('valid intervals have gap, overlap or wrong order')
            cursor = segment.end
        if cursor != self.end:
            raise ValueError('snapshot must cover declared valid domain')
        self._revisions += (revision,)

    def price_at(self, valid_on, known_at):
        utc(known_at)
        if not self.start <= valid_on < self.end:
            return None
        candidates = [r for r in self._revisions if r.recorded_at <= known_at]
        if not candidates:
            return None
        revision = candidates[-1]
        return next(s.cents for s in revision.segments if s.start <= valid_on < s.end)


def check(name, actual, expected):
    if actual != expected:
        raise AssertionError((name, actual, expected))
    print(json.dumps({'scenario': name, 'actual': actual, 'expected': expected, 'pass': True}))


def rejects(name, exception, action):
    try:
        action()
    except exception as error:
        print(json.dumps({'scenario': name, 'rejected': type(error).__name__, 'reason': str(error), 'pass': True}))
        return
    raise AssertionError(name + ': accepted invalid input')


def main():
    print('ENV python=' + platform.python_version() + ' platform=' + platform.platform())
    data = json.loads((Path(__file__).resolve().parents[2] / 'models/12/history.json').read_text())
    if data['currency'] != 'CNY':
        raise ValueError('fixture supports CNY only')
    start, end = map(date.fromisoformat, data['valid_domain'])
    history = History(start, end)
    for raw in data['revisions']:
        history.append(Revision(datetime.fromisoformat(raw['recorded_at']), tuple(Segment(date.fromisoformat(a), date.fromisoformat(b), cents) for a, b, cents in raw['segments'])))
    t1, t2, t3 = (r.recorded_at for r in history.revisions)
    valid = date(2026, 2, 20)
    query = history.price_at
    check('as-known-before-correction', query(valid, datetime.fromisoformat('2026-02-20T00:00:00+00:00')), 10000)
    check('first-retroactive-correction', query(valid, t2), 8000)
    check('second-retroactive-correction', query(valid, t3), 9000)
    check('old-perspective-survives-new-records', query(valid, t1), 10000)
    check('before-valid-boundary', query(date(2026, 2, 14), t3), 10000)
    check('at-valid-boundary', query(date(2026, 2, 15), t3), 9000)
    check('before-record-boundary', query(valid, t2 - timedelta(microseconds=1)), 10000)
    check('at-record-boundary', query(valid, t2), 8000)
    check('before-first-record-is-unknown', query(valid, t1 - timedelta(microseconds=1)), None)
    check('valid-domain-end-is-excluded', query(end, t3), None)
    check('valid-domain-start-is-included', query(start, t3), 10000)
    check('outside-valid-domain-is-unknown', query(start - timedelta(days=1), t3), None)
    rejects('empty-valid-interval', ValueError, lambda: Segment(start, start, 10000))
    rejects('reverse-valid-interval', ValueError, lambda: Segment(end, start, 10000))
    future = t3 + timedelta(days=1)
    boundary = date(2026, 2, 15)
    prefix = history.revisions
    rejects('overlapping-valid-segments', ValueError, lambda: history.append(Revision(future, (Segment(start, boundary, 10000), Segment(boundary - timedelta(days=1), end, 9000)))))
    rejects('gap-in-valid-segments', ValueError, lambda: history.append(Revision(future, (Segment(start, boundary, 10000), Segment(boundary + timedelta(days=1), end, 9000)))))
    rejects('duplicate-record-time', ValueError, lambda: history.append(history.revisions[-1]))
    rejects('backdated-record-insertion', ValueError, lambda: history.append(replace(history.revisions[-1], recorded_at=t2)))
    rejects('naive-record-query', ValueError, lambda: query(valid, datetime(2026, 4, 5)))
    rejects('overwrite-old-snapshot', FrozenInstanceError, lambda: setattr(history.revisions[0].segments[0], 'cents', 9000))
    check('failed-writes-leave-history-intact', history.revisions == prefix and len(history.revisions) == 3, True)
    latest_only = {valid: 9000}
    check('latest-only-cannot-reproduce-old-price', latest_only[valid] == query(valid, t1), False)
    print('MATRIX ' + json.dumps({'valid_on': str(valid), 'known_prices': [[r.recorded_at.isoformat(), query(valid, r.recorded_at)] for r in history.revisions], 'currency': 'CNY', 'unit': 'cent/day'}))
    print('PASS 12: 22 scenarios; complete snapshots, half-open time semantics, no tamper/concurrency guarantee')


if __name__ == '__main__':
    main()
