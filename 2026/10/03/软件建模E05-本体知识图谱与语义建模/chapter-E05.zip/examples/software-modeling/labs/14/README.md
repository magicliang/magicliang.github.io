# 14：两种资源分配候选

从仓库根目录或实验包解压根目录运行：

```bash
bash examples/software-modeling/labs/14/run.sh
```

只依赖Python标准库dataclasses/platform，实跑Python3.14.4。独立内存实验，不读取Java core、13账本或其他章节代码。固定2026-10-03 UTC、整数小时和静态库存。

33项场景覆盖计划/承诺/实际区别、分段容量峰值、指定设备冲突、相邻端点、取消、回执、替换与部分履约。全部满足则exit0；结果不符或预期异常未发生则非零退出。原始输出在`examples/software-modeling/evidence/14/output.txt`，规则与未实现部分在`examples/software-modeling/models/14/semantics.md`。

General和Specific是两个独立实例中的候选，不能把库存相加，也未实现类型级承诺向具体实物分配的转换。替换是取消后新建，非原子操作。
