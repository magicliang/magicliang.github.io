package rental;

import java.time.Instant;
import rental.RentalDesk.*;

public final class ScenarioCheck {
    private static int checks;
    private static final Instant DAY = Instant.parse("2026-10-03T00:00:00Z");

    public static void main(String[] args) {
        RentalDesk desk = new RentalDesk();
        ReserveRequest a = request("A", "E1", 10, 12);
        ReserveRequest b = request("B", "E1", 11, 13);
        equal(desk.reserve(a), Outcome.CONFIRMED, "S01 normal booking");
        equal(desk.reserve(b), Outcome.OVERLAP_REJECTED, "S02 overlap refused");
        equal(desk.reserve(request("C", "E1", 12, 13)), Outcome.CONFIRMED, "S03 touching endpoint accepted");
        equal(desk.reserve(request("D", "E2", 10, 12)), Outcome.CONFIRMED, "S04 equipment isolation");
        illegal(() -> request("Z", "E1", 10, 10), "S05 zero duration refused");
        illegal(() -> request("Z", "E1", 12, 10), "S05 reversed duration refused");
        equal(desk.reserve(a), Outcome.CONFIRMED, "S06 identical replay");
        illegal(() -> desk.reserve(request("A", "E2", 10, 12)), "S07 changed payload refused");
        equal(desk.reserve(request("E", "E1", 10, 11)), Outcome.OVERLAP_REJECTED, "S07 rejection preserves original booking");
        equal(desk.cancel(new RequestId("A")), true, "S08 cancellation releases booking");
        equal(desk.cancel(new RequestId("A")), false, "S08 repeated cancellation changes nothing");
        equal(desk.reserve(a), Outcome.CONFIRMED, "S08 replay retains original receipt");
        equal(desk.reserve(request("F", "E1", 10, 12)), Outcome.CONFIRMED, "S08 new request proves replay did not rebook");

        RentalDesk deniedReplay = new RentalDesk();
        equal(deniedReplay.reserve(a), Outcome.CONFIRMED, "S09 setup occupied equipment");
        equal(deniedReplay.reserve(b), Outcome.OVERLAP_REJECTED, "S09 initial rejection");
        equal(deniedReplay.cancel(new RequestId("A")), true, "S09 remove only blocker");
        equal(deniedReplay.reserve(b), Outcome.OVERLAP_REJECTED, "S09 rejected receipt survives availability change");
        equal(deniedReplay.reserve(request("G", "E1", 11, 13)), Outcome.CONFIRMED, "S09 new intent can succeed");
        equal(deniedReplay.cancel(new RequestId("B")), false, "S10 rejected request has no active booking");
        equal(deniedReplay.cancel(new RequestId("missing")), false, "S10 unknown cancellation changes nothing");
        System.out.println("PASS total=" + checks);
    }

    private static ReserveRequest request(String id, String equipment, long start, long end) {
        return new ReserveRequest(new RequestId(id), new EquipmentId(equipment),
                new Period(DAY.plusSeconds(start * 3600), DAY.plusSeconds(end * 3600)));
    }

    private static void equal(Object actual, Object expected, String scenario) {
        if (!expected.equals(actual)) throw new AssertionError(scenario + ": expected=" + expected + " actual=" + actual);
        checks++;
        System.out.println("PASS " + scenario + " -> " + actual);
    }

    private static void illegal(Runnable action, String scenario) {
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            equal(expected.getClass(), IllegalArgumentException.class, scenario);
            return;
        }
        throw new AssertionError(scenario + ": expected IllegalArgumentException");
    }
}
