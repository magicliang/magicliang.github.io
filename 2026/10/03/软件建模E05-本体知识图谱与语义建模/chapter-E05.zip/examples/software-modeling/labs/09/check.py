"""Party and temporal accountability teaching model; UTC integer hours."""
from dataclasses import dataclass, replace
import json


@dataclass(frozen=True)
class Party:
    id: str
    kind: str

    def __post_init__(self):
        if not self.id.strip() or self.kind not in {'person', 'organization'}:
            raise ValueError('invalid party')


@dataclass(frozen=True)
class Responsibility:
    id: str
    principal: Party
    agent: Party
    role: str
    start: int
    end: int
    ended_at: int | None = None

    def __post_init__(self):
        if not self.id.strip() or self.start >= self.end:
            raise ValueError('invalid interval or id')
        if self.principal.kind != 'organization' or self.agent.kind != 'person':
            raise ValueError('expected organization -> person')
        if self.role not in {'renter', 'inspector'}:
            raise ValueError('unknown role')
        if self.ended_at is not None and not self.start <= self.ended_at <= self.end:
            raise ValueError('invalid termination time')

    def active(self, at):
        end = self.end if self.ended_at is None else self.ended_at
        return self.start <= at < end

    def terminate(self, at):
        if not self.start <= at < self.end:
            raise ValueError('termination outside appointment')
        if self.ended_at is not None:
            if at != self.ended_at:
                raise ValueError('conflicting termination')
            return self
        return replace(self, ended_at=at)


def roles(rows, party, principal, at):
    return sorted(r.role for r in rows if r.agent.id == party.id and r.principal.id == principal.id and r.active(at))


def check(name, actual, expected):
    if actual != expected:
        raise AssertionError((name, actual, expected))
    print(json.dumps({'scenario': name, 'actual': actual, 'expected': expected, 'pass': True}, ensure_ascii=False))


def rejects(name, action):
    try:
        action()
    except ValueError as error:
        print(json.dumps({'scenario': name, 'rejected': str(error), 'pass': True}))
        return
    raise AssertionError(name + ': accepted invalid input')


def main():
    person = Party('P1', 'person')
    a, b = Party('O1', 'organization'), Party('O2', 'organization')
    renter = Responsibility('R1', a, person, 'renter', 10, 20)
    inspector = Responsibility('R2', a, person, 'inspector', 12, 22)
    rows = [renter, inspector, Responsibility('R3', b, person, 'renter', 10, 25)]
    check('before-start', roles(rows, person, a, 9), [])
    check('inclusive-start', roles(rows, person, a, 10), ['renter'])
    check('multiple-roles-same-party', roles(rows, person, a, 12), ['inspector', 'renter'])
    rows[0] = renter.terminate(15)
    check('historical-responsibility-retained', roles(rows, person, a, 14), ['inspector', 'renter'])
    check('exclusive-termination-boundary', roles(rows, person, a, 15), ['inspector'])
    check('other-principal-unaffected', roles(rows, person, b, 15), ['renter'])
    check('natural-expiry', roles(rows, person, a, 22), [])
    check('termination-replay-idempotent', rows[0].terminate(15) == rows[0], True)
    rejects('conflicting-termination', lambda: rows[0].terminate(16))
    rejects('empty-period', lambda: Responsibility('X', a, person, 'renter', 10, 10))
    rejects('wrong-party-direction', lambda: Responsibility('X', person, a, 'renter', 10, 20))
    rejects('termination-before-start', lambda: renter.terminate(9))
    # Counterexample: deleting the row also deletes the historical answer.
    check('delete-loses-history', roles(rows[1:], person, a, 14), ['inspector'])
    print('PASS 09: 13 scenarios; business-valid time only; no authorization or record-time history')


if __name__ == '__main__':
    main()
