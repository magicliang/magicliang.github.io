import copy
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MODEL = ROOT / "models/02/dfd.json"


def boundary(flows, external):
    return Counter(("in" if source in external else "out",
                    source if source in external else target, name)
                   for source, target, name in flows
                   if (source in external) != (target in external))


def validate(model):
    external = set(model["external"])
    processes = set(model["processes"])
    stores = set(model["stores"])
    nodes = external | processes | stores
    assert len(nodes) == len(external) + len(processes) + len(stores), "overlapping node kinds"
    for source, target, name in model["context"]:
        assert {source, target} <= external | {"System"}, "unknown context node"
        assert (source == "System") != (target == "System"), "invalid context edge"
        assert name in model["dictionary"], "undefined flow"
    for source, target, name in model["detail"]:
        assert source in nodes and target in nodes, "unknown detail node"
        assert source in processes or target in processes, "flow bypasses process"
        assert name in model["dictionary"], "undefined flow"
    assert boundary(model["context"], external) == boundary(model["detail"], external), "boundary imbalance"


def diagram(model, level):
    nodes = dict(model["nodes"])
    nodes["System"] = "0 租赁预留系统"
    used = {node for source, target, _ in model[level] for node in (source, target)}
    lines = ["flowchart LR"]
    for node in sorted(used):
        label = nodes[node]
        if node in model["stores"]:
            lines.append(f'  {node}[("{label}")]')
        elif node in model["external"]:
            lines.append(f'  {node}["{label}"]')
        else:
            lines.append(f'  {node}(["{label}"])')
    lines += [f"  {source} -->|{name}| {target}" for source, target, name in model[level]]
    return "\n".join(lines) + "\n"


def main():
    model = json.loads(MODEL.read_text())
    validate(model)
    print("PASS balanced_boundary: 2 inputs, 2 outputs, 10 detail flows")
    for label, mutate in [
        ("missing_output", lambda m: m["detail"].pop(3)),
        ("duplicate_output", lambda m: m["detail"].append(m["detail"][3])),
        ("undefined_flow", lambda m: m["dictionary"].pop("booking_records")),
        ("store_bypass", lambda m: m["detail"].append(["Clerk", "Bookings", "booking_records"])),
    ]:
        broken = copy.deepcopy(model)
        mutate(broken)
        try:
            validate(broken)
        except AssertionError as error:
            print(f"PASS rejects_{label}: {error}")
        else:
            raise AssertionError(f"negative fixture accepted: {label}")
    for level in ("context", "detail"):
        path = ROOT / f"models/02/{level}.mmd"
        assert path.read_text() == diagram(model, level), f"diagram drift: {path}"
    print("PASS diagram_source_matches_model")


if __name__ == "__main__":
    main()
