import importlib
import sys
import unittest


class ExtendAcceptance(unittest.TestCase):
    def test_extend_free_period(self):
        book = importlib.import_module(sys.argv[1]).ReservationBook()
        book.reserve("R1", "E1", 1, 3)
        book.reserve("R2", "E1", 5, 8)
        actual = book.extend("R1", 5)
        self.assertEqual((actual.id, actual.equipment, actual.period.start, actual.period.end),
                         ("R1", "E1", 1, 5))


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ExtendAcceptance)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)
