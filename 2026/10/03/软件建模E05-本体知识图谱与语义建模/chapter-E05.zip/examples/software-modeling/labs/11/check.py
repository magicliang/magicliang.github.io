"""Runtime type objects and pinned specifications; synthetic CNY rental example."""
from dataclasses import dataclass, FrozenInstanceError
from enum import Enum
from pathlib import Path
import json
import platform


class Category(Enum):
    CAMERA = 'camera'
    PROJECTOR = 'projector'


class FixedModel(Enum):
    CAM_A = 'CAM-A'


@dataclass(frozen=True)
class EquipmentType:
    id: str
    revision: int
    category: Category
    features: tuple[str, ...]

    def __post_init__(self):
        if not self.id.strip() or self.revision < 1 or not isinstance(self.category, Category):
            raise ValueError('invalid equipment type')
        if not isinstance(self.features, tuple) or any(not isinstance(f, str) or not f for f in self.features):
            raise ValueError('immutable named features required')


@dataclass(frozen=True)
class ServiceSpec:
    id: str
    revision: int
    required_category: Category
    max_days: int
    daily_cents: int

    def __post_init__(self):
        if not self.id.strip() or self.revision < 1 or not isinstance(self.required_category, Category):
            raise ValueError('invalid service type')
        if type(self.max_days) is not int or type(self.daily_cents) is not int or self.max_days <= 0 or self.daily_cents <= 0:
            raise ValueError('positive integer days and cents required')

    def price(self, equipment, days):
        if equipment.model.category != self.required_category:
            raise ValueError('equipment category incompatible with service')
        if type(days) is not int or not 1 <= days <= self.max_days:
            raise ValueError('days outside service specification')
        return days * self.daily_cents


@dataclass(frozen=True)
class Equipment:
    id: str
    model: EquipmentType

    def supports(self, feature):
        return feature in self.model.features


@dataclass(frozen=True)
class Agreement:
    id: str
    equipment: Equipment
    spec: ServiceSpec
    days: int
    agreed_cents: int

    @classmethod
    def sign(cls, id, equipment, spec, days):
        return cls(id, equipment, spec, days, spec.price(equipment, days))


class Catalog:
    def __init__(self):
        self._versions = {}

    def add(self, spec):
        key = (spec.id, spec.revision)
        if key in self._versions:
            raise ValueError('revision key already exists')
        self._versions[key] = spec

    def get(self, id, revision):
        return self._versions[(id, revision)]

    def latest(self, id):
        return max((s for (name, _), s in self._versions.items() if name == id), key=lambda s: s.revision)


def check(name, actual, expected):
    if actual != expected:
        raise AssertionError((name, actual, expected))
    print(json.dumps({'scenario': name, 'actual': actual, 'expected': expected, 'pass': True}))


def rejects(name, exception, action):
    try:
        action()
    except exception as error:
        print(json.dumps({'scenario': name, 'rejected': type(error).__name__, 'reason': str(error), 'pass': True}))
        return
    raise AssertionError(name + ': accepted invalid input')


def main():
    print('ENV python=' + platform.python_version() + ' platform=' + platform.platform())
    fixture = Path(__file__).resolve().parents[2] / 'models/11/catalog.json'
    data = json.loads(fixture.read_text())
    models, services = Catalog(), Catalog()
    for row in data['equipment_types']:
        models.add(EquipmentType(row['id'], row['revision'], Category(row['category']), tuple(row['features'])))
    for row in data['service_specs']:
        if row['id'] == 'CAM-DAY' and row['revision'] == 2:
            continue
        services.add(ServiceSpec(row['id'], row['revision'], Category(row['required_category']), row['max_days'], row['daily_cents']))
    a = Equipment('E1', models.get('CAM-A', 1))
    b = Equipment('E2', models.get('CAM-A', 1))
    runtime = Equipment('E3', models.get('CAM-B', 1))
    check('same-type-distinct-physical-identities', (a.id != b.id) and a.model is b.model, True)
    check('new-model-same-language-class', type(runtime) is type(a) and type(runtime.model) is type(a.model), True)
    check('runtime-type-delegates-feature', [a.supports('waterproof'), runtime.supports('waterproof')], [False, True])
    rejects('fixed-enum-rejects-new-model', ValueError, lambda: FixedModel('CAM-B'))
    old = Agreement.sign('C1', a, services.get('CAM-DAY', 1), 7)
    check('old-contract-original-price', old.agreed_cents, 70000)
    row = next(r for r in data['service_specs'] if r['id'] == 'CAM-DAY' and r['revision'] == 2)
    services.add(ServiceSpec(row['id'], row['revision'], Category(row['required_category']), row['max_days'], row['daily_cents']))
    check('old-contract-pinned-specification', [old.spec.revision, old.spec.max_days], [1, 7])
    check('old-price-stays-after-new-specification', old.spec.price(old.equipment, old.days), 70000)
    new = Agreement.sign('C2', a, services.latest('CAM-DAY'), 3)
    check('new-contract-selects-new-specification', [new.spec.revision, new.agreed_cents], [2, 36000])
    rejects('latest-spec-rejects-old-seven-day-term', ValueError, lambda: services.latest('CAM-DAY').price(a, old.days))
    check('naive-latest-rate-reprices-history', old.days * services.latest('CAM-DAY').daily_cents, 84000)
    rejects('camera-cannot-use-projector-service', ValueError, lambda: Agreement.sign('BAD', a, services.get('PROJ-DAY', 1), 1))
    rejects('duplicate-specification-version', ValueError, lambda: services.add(services.get('CAM-DAY', 1)))
    rejects('frozen-old-price-cannot-be-assigned', FrozenInstanceError, lambda: setattr(old.spec, 'daily_cents', 1))
    check('catalog-update-does-not-upgrade-physical-device', [a.supports('8k'), '8k' in models.latest('CAM-A').features], [False, True])
    rejects('unknown-category', ValueError, lambda: Category('vehicle'))
    rejects('zero-day-service', ValueError, lambda: Agreement.sign('BAD', a, old.spec, 0))
    check('separate-actual-services-share-specification', Agreement.sign('C3', b, old.spec, 1).spec is old.spec, True)
    print('PASS 11: 17 scenarios; runtime type objects, pinned specifications, local single-process only')


if __name__ == '__main__':
    main()
