#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
java_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}java
javac_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}javac
java_version=$("$java_cmd" -version 2>&1)
javac_version=$("$javac_cmd" -version 2>&1)
if [[ ! "$java_version" =~ version\ \"21[.\"] || ! "$javac_version" =~ ^javac\ 21[.\ ] ]]; then
  printf 'JDK 21 required; set JAVA_HOME.\n%s\n%s\n' "$java_version" "$javac_version" >&2
  exit 2
fi
printf '%s\n%s\n' "$java_version" "$javac_version"
classes=$(mktemp -d "${TMPDIR:-/tmp}/modeling04.XXXXXX")
trap 'rm -rf "$classes"' EXIT
"$javac_cmd" --release 21 -Xlint:all -Werror -d "$classes" "$root/rental-core/RentalDesk.java" "$root/labs/04/CrcCheck.java"
"$java_cmd" -ea -cp "$classes" rental.CrcCheck
