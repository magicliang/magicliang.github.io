"""Four-archetype rental teaching candidate; colors do not decide identity."""
from dataclasses import dataclass, replace
from pathlib import Path
import json


@dataclass(frozen=True)
class ModelDescription:
    id: str
    revision: int
    label: str


@dataclass(frozen=True)
class Equipment:
    id: str
    model: ModelDescription


@dataclass(frozen=True)
class Role:
    id: str
    party: str
    organization: str
    kind: str
    start: int
    end: int

    def active(self, hour: int) -> bool:
        return self.start <= hour < self.end

    def terminate(self, hour: int) -> 'Role':
        if not self.start <= hour < self.end:
            raise ValueError('termination outside role interval')
        return replace(self, end=hour)


@dataclass(frozen=True)
class RentalAgreement:
    id: str
    equipment: Equipment
    renter: Role
    start: int
    end: int

    def __post_init__(self) -> None:
        if self.start >= self.end:
            raise ValueError('empty or reversed agreement interval')
        if self.renter.kind != 'renter' or not self.renter.active(self.start):
            raise ValueError('renter role required at agreement start')


def check(name, actual, expected):
    if actual != expected:
        raise AssertionError((name, actual, expected))
    print(json.dumps({'scenario': name, 'actual': actual, 'expected': expected, 'pass': True}, ensure_ascii=False))


def rejects(name, operation):
    try:
        operation()
    except ValueError as error:
        print(json.dumps({'scenario': name, 'rejected': str(error), 'pass': True}))
        return
    raise AssertionError(name + ': invalid input accepted')


def main():
    fixture = json.loads((Path(__file__).parents[2] / 'models/15/fixture.json').read_text())
    v1 = ModelDescription(**fixture['description'])
    equipment = [Equipment(id, v1) for id in fixture['equipment_ids']]
    check('two-physical-identities', [e.id for e in equipment], ['E1', 'E2'])
    naive_by_model = {e.model.id: e for e in equipment}
    check('deduplicate-by-description-loses-equipment', [e.id for e in naive_by_model.values()], ['E2'])
    check('identity-index-keeps-both', sorted({e.id: e for e in equipment}), ['E1', 'E2'])
    renter = Role('R1', 'P1', 'O1', 'renter', 10, 20)
    inspector = Role('R2', 'P1', 'O1', 'inspector', 10, 22)
    roles = [renter, inspector]
    check('same-person-two-roles', [r.kind for r in roles if r.active(12)], ['renter', 'inspector'])
    agreement = RentalAgreement('A1', equipment[0], renter, 10, 12)
    roles[0] = renter.terminate(15)
    check('role-termination-keeps-other-role', [r.kind for r in roles if r.active(15)], ['inspector'])
    check('role-history-before-termination', roles[0].active(14), True)
    check('agreement-keeps-original-party-and-resource', [agreement.renter.party, agreement.equipment.id], ['P1', 'E1'])
    naive_person_kind = {r.party: r.kind for r in [renter, inspector]}
    check('role-as-person-kind-overwrites-renter', naive_person_kind['P1'], 'inspector')
    v2 = replace(v1, revision=2, label='Camera model A revised')
    revisions = {(v.id, v.revision): v for v in [v1, v2]}
    check('description-has-two-revisions', sorted(k[1] for k in revisions), [1, 2])
    check('agreement-description-pinned', agreement.equipment.model.label, 'Camera model A')
    latest_label = max(revisions.values(), key=lambda v: v.revision).label
    check('latest-description-rewrites-old-agreement', latest_label == agreement.equipment.model.label, False)
    check('same-description-identity-different-revision', [v1.id == v2.id, v1 == v2], [True, False])
    rejects('expired-role-cannot-start-new-agreement', lambda: RentalAgreement('A2', equipment[1], roles[0], 16, 18))
    rejects('empty-agreement-period', lambda: RentalAgreement('A2', equipment[1], renter, 10, 10))
    print('PASS 15: 14 behavior scenarios; classification is a documented design choice, not inferred from color')


if __name__ == '__main__':
    main()
