package rental;

import java.lang.reflect.ParameterizedType;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import rental.RentalDesk.*;

public final class UmlCheck {
    private static final Map<String, Class<?>> TYPES = types();
    private static Map<String, Class<?>> types() {
        Map<String, Class<?>> result = new HashMap<>();
        result.put("RentalDesk", RentalDesk.class);
        result.put("Map", Map.class);
        result.put("Object", Object.class);
        result.put("boolean", boolean.class);
        for (Class<?> type : RentalDesk.class.getDeclaredClasses()) result.put(type.getSimpleName(), type);
        return result;
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new IllegalArgumentException(message);
    }

    private static void validate(String classes, String sequence) throws ReflectiveOperationException {
        Map<String, Set<String>> methods = new HashMap<>();
        Set<String> associations = new HashSet<>();
        String owner = null;
        var classPattern = Pattern.compile("class (\\w+)(?: \\{)?");
        var operation = Pattern.compile("\\+(\\w+)\\(([^)]*)\\) (\\w+)");
        for (String line : classes.lines().map(String::strip).toList()) {
            var declaration = classPattern.matcher(line);
            var method = operation.matcher(line);
            if (declaration.matches()) {
                owner = declaration.group(1);
                require(TYPES.containsKey(owner), "unknown class " + owner);
                methods.put(owner, new HashSet<>());
            } else if (method.matches()) {
                require(owner != null, "operation without class");
                String[] arguments = method.group(2).isEmpty() ? new String[0] : method.group(2).split(",");
                Class<?>[] parameters = new Class<?>[arguments.length];
                for (int i = 0; i < arguments.length; i++) {
                    parameters[i] = TYPES.get(arguments[i]);
                    require(parameters[i] != null, "unknown parameter " + arguments[i]);
                }
                var reflected = TYPES.get(owner).getMethod(method.group(1), parameters);
                require(reflected.getReturnType().equals(TYPES.get(method.group(3))),
                        "return type mismatch " + owner + "." + method.group(1));
                methods.get(owner).add(method.group(1) + "(" + method.group(2) + ")");
            } else if (line.equals("}")) owner = null;
            else if (line.contains(" --> ")) require(associations.add(line), "duplicate association " + line);
            else require(line.isEmpty() || line.equals("classDiagram"), "unsupported class syntax " + line);
        }
        association(associations, "RentalDesk", "1", "0..*", "Receipt", "receipts", true);
        association(associations, "RentalDesk", "0..*", "0..*", "ReserveRequest", "bookings", true);
        association(associations, "Receipt", "0..*", "1", "ReserveRequest", "request", false);
        association(associations, "ReserveRequest", "0..*", "1", "RequestId", "requestId", false);
        association(associations, "ReserveRequest", "0..*", "1", "EquipmentId", "equipmentId", false);
        association(associations, "ReserveRequest", "0..*", "1", "Period", "period", false);
        require(associations.isEmpty(), "unsupported association " + associations);

        Map<String, String> participants = new HashMap<>();
        var participant = Pattern.compile("participant (\\w+) as (\\w+)");
        var message = Pattern.compile("(\\w+)(->>|-->>)(\\w+): (.+)");
        for (String line : sequence.lines().map(String::strip).toList()) {
            var declaration = participant.matcher(line);
            var send = message.matcher(line);
            if (declaration.matches()) {
                require(methods.containsKey(declaration.group(2)), "participant class missing");
                participants.put(declaration.group(1), declaration.group(2));
            } else if (line.equals("actor caller")) participants.put("caller", "actor");
            else if (send.matches()) {
                String sender = send.group(1), receiver = send.group(3);
                require(participants.containsKey(sender), "missing sender " + sender);
                require(participants.containsKey(receiver), "missing receiver " + receiver);
                if (send.group(2).equals("->>")) {
                    String type = participants.get(receiver);
                    require(methods.containsKey(type) && methods.get(type).contains(send.group(4)),
                            "missing method " + type + "." + send.group(4));
                }
            } else require(line.isEmpty() || line.equals("sequenceDiagram") || line.startsWith("Note over "), "unsupported sequence syntax " + line);
        }
    }

    private static void association(Set<String> associations, String owner, String lower, String upper,
                                    String target, String field, boolean collection) throws ReflectiveOperationException {
        String expected = owner + " \"" + lower + "\" --> \"" + upper + "\" " + target + " : " + field;
        require(associations.remove(expected), "association mismatch " + field);
        var actual = TYPES.get(owner).getDeclaredField(field);
        if (collection) {
            var generic = (ParameterizedType) actual.getGenericType();
            require(generic.getRawType().equals(Map.class), "not a Map " + field);
            require(generic.getActualTypeArguments()[1].equals(TYPES.get(target)), "value type mismatch " + field);
        } else require(actual.getType().equals(TYPES.get(target)), "field type mismatch " + field);
    }

    private static void rejected(String name, String classes, String sequence, String expected) throws ReflectiveOperationException {
        try {
            validate(classes, sequence);
            throw new AssertionError("negative model accepted " + name);
        } catch (IllegalArgumentException error) {
            require(error.getMessage().contains(expected), "unexpected rejection " + error);
            System.out.println("DETECTED " + name + " " + error.getMessage());
        }
    }

    private static void behaviorProbe() {
        RentalDesk desk = new RentalDesk();
        Period period = new Period(Instant.parse("2026-10-03T10:00:00Z"), Instant.parse("2026-10-03T12:00:00Z"));
        ReserveRequest a = new ReserveRequest(new RequestId("A"), new EquipmentId("E1"), period);
        require(desk.reserve(a) == Outcome.CONFIRMED, "initial confirm");
        require(desk.cancel(a.requestId()), "cancel failed");
        require(desk.reserve(a) == Outcome.CONFIRMED, "replay result changed");
        require(desk.reserve(new ReserveRequest(new RequestId("F"), a.equipmentId(), period)) == Outcome.CONFIRMED, "replay resurrected");
        try {
            new ReserveRequest(a.requestId(), null, period);
            throw new AssertionError("required equipment accepted null");
        } catch (NullPointerException expected) {
            System.out.println("PASS required_equipment_nonnull");
        }
        System.out.println("PASS cancel_replay_probe fresh=CONFIRMED");
    }

    public static void main(String[] args) throws Exception {
        require(args.length == 2 || args.length == 3, "classes sequence [suite]");
        String classes = Files.readString(Path.of(args[0]));
        String sequence = Files.readString(Path.of(args[1]));
        validate(classes, sequence);
        System.out.println("PASS class_operations_receivers_associations");
        if (args.length == 3) {
            rejected("missing_receiver", classes, sequence.replace("    participant previous as Receipt\n", ""), "missing receiver previous");
            rejected("missing_method", classes, sequence.replace("outcome()", "refund()"), "missing method Receipt.refund()");
            rejected("wrong_multiplicity", classes.replace("\"0..*\" ReserveRequest : bookings", "\"1\" ReserveRequest : bookings"), sequence, "association mismatch bookings");
            rejected("conflicting_association", classes + "    RentalDesk \"0..*\" --> \"1\" ReserveRequest : bookings\n", sequence, "unsupported association");
            rejected("unknown_association", classes + "    Ghost \"1\" --> \"1\" RentalDesk : imaginary\n", sequence, "unsupported association");
            rejected("duplicate_association", classes + "    RentalDesk \"0..*\" --> \"0..*\" ReserveRequest : bookings\n", sequence, "duplicate association");
            rejected("wrong_return_type", classes.replace("cancel(RequestId) boolean", "cancel(RequestId) Outcome"), sequence, "return type mismatch RentalDesk.cancel");
            behaviorProbe();
        }
    }
}
