# 企业应用架构：设备租赁实验

24章编号00–23。统一入口在仓库根目录调用，也可从累计ZIP保留的examples目录结构调用：

```bash
bash examples/enterprise-application-architecture/run-lab.sh 14
```

全部章节顺序执行：

```bash
bash examples/enterprise-application-architecture/run-lab.sh all
```

需要Java 21的java与javac、Python 3，以及首次解析第三方依赖时的网络访问。JAVA_HOME指向已安装的JDK；PYTHON可选择Python解释器。05起使用H2 2.1.214，sql-support/v1/h2.json固定版本与SHA-256，H2_JAR可指向匹配文件。15–19的依赖由labs/15/dependencies.json固定坐标与摘要；ENTERPRISE_INTEGRATION_CACHE指定可写缓存。第三方jar不随源码包提交。

| 范围 | 实际验证面 |
|---|---|
|00–04|冻结领域契约、职责分配、依赖和JPMS边界|
|05–09|真实SQL、映射、查询、工作单元和独立连接并发|
|10–14|环回HTTP、表单、读模型、事件恢复与SQL spool退出窗口|
|15–19|ActiveMQ TCP/KahaDB、拆分聚合、关联、三库补偿及Camunda持久流程|
|20–23|受限数据库账号、插件、迁移回退及部分退款恢复|

每章models保存受限契约及决策，labs保存执行入口，evidence保存实际命令、退出码、环境与非空原始日志。运行器可能重建本章证据；需要保留历史结果时先复制证据，15–19可用ENTERPRISE_EVIDENCE_DIR选择独立输出目录。进程级故障73/74/75由外层驱动检查，正常完整入口最终返回0。独立negative或mutant入口按本章RUN.md的预期返回非零，不能把预期子进程故障等同整体失败。

27-v1语义基线来自软件建模系列的已提交27篇，副本及完整来源清单见models/00/baseline-manifest.json。labs/00/verify-baseline.py核对19份源文件；该内存基线与后续缩小持久化样本的证明范围分别记录，后者不会改写历史语义。

这些都是合成教学实验。环回服务器使用固定教学身份，14的传输是持久SQL spool，15–17才运行实际消息代理，18使用本地参与者函数与三个文件数据库，19运行Camunda BPMN引擎。没有真实支付、生产身份认证、公网性能或灾难恢复保证。完整论文式规范符合性与生产交付不由本地PASS推导。
