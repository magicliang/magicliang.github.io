package enterprise.chapter17;

import enterprise.integration.Messaging;
import enterprise.sql.Check;
import enterprise.sql.Sql;

public final class Lab17 {
    private Lab17() { }
    public static void main(String[] args) throws Exception {
        String url = "jdbc:h2:" + args[0] + ";WRITE_DELAY=0";
        try (Sql db = Sql.open(url); Messaging mq = new Messaging(args[1])) {
            switch (args[2]) {
                case "init" -> {
                    db.update("CREATE TABLE requests(correlation VARCHAR PRIMARY KEY,business_id VARCHAR,state VARCHAR,deadline BIGINT,result VARCHAR)");
                    db.update("CREATE TABLE service_results(correlation VARCHAR PRIMARY KEY,business_id VARCHAR,result VARCHAR)"); db.commit();
                    for (int i = 1; i <= 2; i++) {
                        db.update("INSERT INTO requests VALUES(?,?,'PENDING',?,NULL)", "C" + i, "R" + i, System.currentTimeMillis() + 1000);
                        mq.send("reservation.requests", "M" + i, "R" + i, 1, "C" + i);
                    }
                    db.commit(); mq.commit();
                    Check.that("two requests outstanding before replies", db.query("SELECT COUNT(*) FROM requests WHERE state='PENDING'", r -> r.getInt(1)).getFirst() == 2);
                }
                case "service" -> {
                    var first = mq.receive("reservation.requests");
                    var second = mq.receive("reservation.requests");
                    for (var message : new javax.jms.Message[]{second, first}) {
                        String business = Messaging.body(message), correlation = message.getJMSCorrelationID();
                        String result = business.equals("R1") ? "RESERVED-E1" : "RESERVED-E2";
                        db.update("INSERT INTO service_results VALUES(?,?,?)", correlation, business, result); db.commit();
                        if (business.equals("R2")) mq.send("reservation.replies", "reply-" + correlation, business + "|" + result, 1, correlation);
                        else System.out.println("RESULT_DURABLE_REPLY_DELAYED business=" + business + " correlation=" + correlation);
                    }
                    mq.commit();
                }
                case "timeout" -> {
                    Check.that("deadline marks unknown not failed", db.update("UPDATE requests SET state='UNKNOWN' WHERE state='PENDING' AND deadline<=?", System.currentTimeMillis()) == 2); db.commit();
                }
                case "reconcile" -> {
                    for (var row : db.query("SELECT correlation,business_id,result FROM service_results WHERE correlation='C1'", r -> new String[]{r.getString(1), r.getString(2), r.getString(3)})) {
                        System.out.println("QUERY authoritative-result business=" + row[1] + " correlation=" + row[0]);
                        mq.send("reservation.replies", "query-" + row[0], row[1] + "|" + row[2], 1, row[0]);
                        mq.send("reservation.replies", "duplicate-" + row[0], row[1] + "|" + row[2], 1, row[0]);
                    }
                    mq.send("reservation.replies", "unknown", "R9|RESERVED-E9", 1, "C9"); mq.commit();
                }
                case "receive" -> {
                    for (int i = 0; i < 4; i++) {
                        var message = mq.receive("reservation.replies");
                        Check.that("reply exists " + i, message != null);
                        String correlation = message.getJMSCorrelationID();
                        String[] body = Messaging.body(message).split("\\|");
                        var original = db.query("SELECT business_id,state,result FROM requests WHERE correlation=?", r -> new String[]{r.getString(1), r.getString(2), r.getString(3)}, correlation);
                        if (original.isEmpty() || !original.getFirst()[0].equals(body[0])) {
                            mq.send("reservation.quarantine", message.getStringProperty("message_id"), Messaging.body(message), 1, correlation);
                        } else if (original.getFirst()[1].equals("CONFIRMED")) {
                            Check.that("duplicate result agrees", original.getFirst()[2].equals(body[1]));
                        } else {
                            db.update("UPDATE requests SET state='CONFIRMED',result=? WHERE correlation=?", body[1], correlation); db.commit();
                            System.out.println("RECOVERED business=" + body[0] + " correlation=" + correlation + " result=" + body[1]);
                        }
                        mq.commit();
                    }
                    Check.that("R1 response not swapped", db.query("SELECT result FROM requests WHERE business_id='R1'", r -> r.getString(1)).getFirst().equals("RESERVED-E1"));
                    Check.that("R2 response not swapped", db.query("SELECT result FROM requests WHERE business_id='R2'", r -> r.getString(1)).getFirst().equals("RESERVED-E2"));
                    Check.that("unknown correlation isolated", mq.receive("reservation.quarantine") != null); mq.commit();
                }
                case "negative" -> Check.that("timeout cannot be reported as definite failure", db.query("SELECT COUNT(*) FROM requests WHERE state='FAILED'", r -> r.getInt(1)).getFirst() == 2);
                default -> throw new IllegalArgumentException("mode");
            }
        }
        Check.result("17 " + args[2]);
    }
}
