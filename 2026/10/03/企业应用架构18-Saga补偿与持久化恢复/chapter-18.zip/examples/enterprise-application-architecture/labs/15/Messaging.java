package enterprise.integration;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerService;

public final class Messaging implements AutoCloseable {
    private final Connection connection;
    public final Session session;
    private final Map<String, MessageConsumer> consumers = new HashMap<>();
    public Messaging(String address) throws Exception {
        ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory(address);
        factory.getRedeliveryPolicy().setMaximumRedeliveries(2);
        factory.getRedeliveryPolicy().setInitialRedeliveryDelay(0);
        factory.getRedeliveryPolicy().setRedeliveryDelay(0);
        connection = factory.createConnection();
        session = connection.createSession(true, Session.SESSION_TRANSACTED);
        connection.start();
    }
    public void send(String channel, String id, String body, int version, String correlation) throws Exception {
        MessageProducer producer = session.createProducer(session.createQueue(channel));
        try {
            TextMessage message = session.createTextMessage(body);
            message.setStringProperty("message_id", id);
            message.setIntProperty("schema_version", version);
            message.setJMSCorrelationID(correlation);
            producer.send(message, DeliveryMode.PERSISTENT, 4, 0);
            System.out.println("SEND channel=" + channel + " id=" + id + " version=" + version + " correlation=" + correlation + " jms=" + message.getJMSMessageID() + " raw=" + body);
        } finally { producer.close(); }
    }
    public Message receive(String channel) throws Exception {
        MessageConsumer consumer = consumers.get(channel);
        if (consumer == null) { consumer = session.createConsumer(session.createQueue(channel)); consumers.put(channel, consumer); }
        Message message = consumer.receive(1000);
        if (message != null) System.out.println("RECEIVE channel=" + channel + " id=" + message.getStringProperty("message_id") + " correlation=" + message.getJMSCorrelationID() + " delivery=" + message.getIntProperty("JMSXDeliveryCount") + " raw=" + ((TextMessage) message).getText());
        return message;
    }
    public void commit() throws Exception { session.commit(); }
    public void rollback() throws Exception { session.rollback(); }
    @Override public void close() throws javax.jms.JMSException { connection.close(); }
    public static String body(Message message) throws Exception { return ((TextMessage) message).getText(); }
    public static void main(String[] args) throws Exception {
        BrokerService broker = new BrokerService();
        broker.setBrokerName("enterprise-lab");
        broker.setUseJmx(false);
        broker.setPersistent(true);
        broker.setDataDirectory(args[0]);
        var connector = broker.addConnector("tcp://127.0.0.1:0");
        broker.start(); broker.waitUntilStarted();
        Runtime.getRuntime().addShutdownHook(new Thread(() -> { try { broker.stop(); } catch (Exception failure) { failure.printStackTrace(); } }));
        Files.writeString(Path.of(args[1]), connector.getPublishableConnectString());
        System.out.println("BROKER_READY persistent=KahaDB address=" + connector.getPublishableConnectString());
        new CountDownLatch(1).await();
    }
}
