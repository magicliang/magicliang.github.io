# 18：Saga持久化与补偿

执行 `bash examples/enterprise-application-architecture/labs/18/run.sh`，最终退出0；追加 `negative` 在已交付R2自动取消处退出1。Java21/Python3及缓存参数见15/RUN.md；此章不启动消息broker。

协调、库存、收费为三个真实H2文件。reserve-crash与release-crash各在参与者提交后halt73，运行器必须看到73，随后由新JVM恢复。release-fail真实回滚库存修改，协调状态持久为RETRY_COMPENSATION。恢复后R1 held=false、releases=1、charges=0。R2已交付取消转MANUAL_REVIEW，仍held=true、releases=0、收费25教学整数单位。

chargeSucceeded入口从持久状态决定推进：RESERVED条件更新CHARGED；终态记IGNORE_TERMINAL；相同event_id/saga重复返回已有决定。正常R2和迟到R1各输入两次，received只有两行，R1不复活。迟到输入未伪造真实资金到账。

`evidence/18/`内三个`database-*-snapshot.sql`分别保留协调、库存、收费数据；reserve-crash/release-crash日志为EXIT73；late.log证明两类重复输入；verify.log读回11条迁移。负例独立目录含自动取消拒绝。

这是本机参与者本地事务实验，没有真实支付、物流或后台重试调度。临时数据库保留。多个协调器竞争和网络分区未覆盖。
