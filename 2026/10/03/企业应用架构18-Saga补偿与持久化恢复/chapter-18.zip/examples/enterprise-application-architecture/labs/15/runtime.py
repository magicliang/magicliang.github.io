import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import urllib.request

BASE = Path(__file__).resolve().parents[2]
JAVA = Path(os.environ.get('JAVA_HOME', '')) / 'bin/java' if os.environ.get('JAVA_HOME') else Path('java')
JAVAC = JAVA.with_name('javac')

def dependencies():
    cache = Path(os.environ.get('ENTERPRISE_INTEGRATION_CACHE', Path.home() / '.cache/enterprise-integration'))
    cache.mkdir(parents=True, exist_ok=True)
    jars = []
    for item in json.loads((BASE / 'labs/15/dependencies.json').read_text()):
        jar = cache / item['file']
        if not jar.exists():
            with urllib.request.urlopen(item['url'], timeout=60) as response: data = response.read()
            if hashlib.sha256(data).hexdigest() != item['sha256']: raise ValueError('download checksum ' + jar.name)
            jar.write_bytes(data)
        if hashlib.sha256(jar.read_bytes()).hexdigest() != item['sha256']: raise ValueError('cache checksum ' + jar.name)
        jars.append(str(jar))
    return jars

def run(chapter, negative=False):
    root = Path(tempfile.mkdtemp(prefix='enterprise-' + chapter + '-'))
    evidence = Path(os.environ.get('ENTERPRISE_EVIDENCE_DIR', str(BASE / 'evidence' / chapter)))
    if negative: evidence = evidence / 'negative'
    evidence.mkdir(parents=True, exist_ok=True)
    jars = dependencies()
    cp = os.pathsep.join(jars)
    sources = [BASE / 'sql-support/v1/Sql.java', BASE / 'sql-support/v1/Check.java', BASE / 'labs/15/Messaging.java']
    sources += list((BASE / 'labs' / chapter).glob('Lab*.java'))
    compile_command = [str(JAVAC), '--release', '21', '-Xlint:all', '-Werror', '-cp', cp, '-d', str(root / 'classes'), *map(str, sources)]
    compiled = subprocess.run(compile_command, capture_output=True, text=True)
    (evidence / 'compile.log').write_text('COMMAND ' + repr(compile_command) + '\n' + compiled.stdout + compiled.stderr + '\nEXIT ' + str(compiled.returncode))
    if compiled.returncode: raise RuntimeError(compiled.stderr)
    cp = str(root / 'classes') + os.pathsep + cp
    java = [str(JAVA), '-ea', '-cp', cp]
    environment = subprocess.run([str(JAVA), '-version'], capture_output=True, text=True)
    (evidence / 'environment.txt').write_text(environment.stdout + environment.stderr + '\nActiveMQ Classic 5.18.6; H2 2.1.214; Camunda 7.23.0\n')
    steps = []
    def step(mode, expected=0):
        command = java + ['enterprise.chapter' + chapter + '.Lab' + chapter, str(root / 'database'), address, mode]
        result = subprocess.run(command, capture_output=True, text=True, timeout=90)
        (evidence / (mode + '.log')).write_text('COMMAND ' + repr(command) + '\n' + result.stdout + result.stderr + '\nEXIT ' + str(result.returncode))
        steps.append({'mode': mode, 'exit': result.returncode, 'expected': expected, 'log': mode + '.log'})
        if result.returncode != expected: raise AssertionError((mode, result.returncode, result.stdout, result.stderr))
        print('STEP', chapter, mode, 'exit', result.returncode, flush=True)
    broker = None
    handles = []
    def start(number):
        marker = root / ('address-' + str(number))
        handle = (evidence / ('broker-' + str(number) + '.log')).open('w')
        handles.append(handle)
        process = subprocess.Popen(java + ['enterprise.integration.Messaging', str(root / 'broker'), str(marker)], stdout=handle, stderr=subprocess.STDOUT)
        for _ in range(200):
            if marker.exists(): return process, marker.read_text()
            if process.poll() is not None: raise RuntimeError('broker failed; inspect broker log')
            time.sleep(0.05)
        process.terminate(); process.wait(timeout=15)
        raise TimeoutError('broker startup')
    try:
        if chapter in ['18', '19']:
            address = str(BASE / 'models' / chapter)
        else:
            broker, address = start(1)
        step('init', 73 if chapter == '19' else 0)
        if chapter == '15':
            step('send'); broker.terminate(); broker.wait(timeout=20)
            broker, address = start(2)
            if negative: step('negative', 1)
            else:
                for mode in ['consume', 'poison', 'verify']: step(mode)
        elif chapter == '16':
            step('workers'); step('aggregate-partial')
            if negative: step('negative', 1)
            else:
                time.sleep(1.1); step('timeout'); step('finish')
        elif chapter == '17':
            step('service'); time.sleep(1.1); step('timeout')
            if negative: step('negative', 1)
            else:
                step('reconcile'); step('receive')
        elif chapter == '18':
            step('reserve-crash', 73); step('resume-reserve'); step('charge-fail'); step('release-fail')
            step('release-crash', 73); step('recover'); step('deliver')
            if negative: step('negative', 1)
            else:
                step('cancel-delivered'); step('late'); step('verify')
        elif chapter == '19':
            step('restart')
            if negative: step('negative', 1)
            else: step('finish')
        else: raise ValueError(chapter)
        for database in root.glob('*.mv.db'):
            database_base = str(database)[:-6]
            output = evidence / (database.stem.replace('.mv', '') + '-snapshot.sql')
            snapshot = subprocess.run(java + ['org.h2.tools.Script', '-url', 'jdbc:h2:' + database_base,
                                              '-user', 'sa', '-password', '', '-script', str(output)], capture_output=True, text=True)
            if snapshot.returncode: raise RuntimeError(snapshot.stdout + snapshot.stderr)
        report = {'chapter': chapter, 'negative': negative, 'result': 'PASS', 'workspace': str(root), 'steps': steps}
        (evidence / ('negative.json' if negative else 'run.json')).write_text(json.dumps(report, indent=2))
        print('RESULT enterprise' + chapter + ' PASS workspace=' + str(root))
    finally:
        if broker is not None and broker.poll() is None: broker.terminate(); broker.wait(timeout=20)
        for handle in handles: handle.close()
    return 1 if negative else 0

if __name__ == '__main__':
    sys.exit(run(sys.argv[1], sys.argv[2:] == ['negative']))
