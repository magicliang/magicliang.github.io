package enterprise.chapter15;

import enterprise.integration.Messaging;
import enterprise.sql.Check;
import enterprise.sql.Sql;

public final class Lab15 {
    private Lab15() { }
    private static String translate(String body, int version) {
        String[] fields = body.split("\\|", -1);
        if (version != 1 || fields.length != 2 || fields[0].isBlank() || fields[1].isBlank()) throw new IllegalArgumentException("unsupported or invalid maintenance request version=" + version);
        return "repair-request|contract=" + fields[0] + "|asset=ASSET-" + fields[1];
    }
    public static void main(String[] args) throws Exception {
        String url = "jdbc:h2:" + args[0] + ";WRITE_DELAY=0";
        String address = args[1];
        switch (args[2]) {
            case "init" -> { try (Sql db = Sql.open(url)) { db.update("CREATE TABLE maintenance(message_id VARCHAR PRIMARY KEY,contract_id VARCHAR,asset_ref VARCHAR,source_body VARCHAR,target_body VARCHAR)"); db.commit(); } }
            case "send" -> {
                try (Messaging mq = new Messaging(address)) {
                    mq.send("maintenance.request", "M1", "R1|E1", 1, "R1");
                    mq.send("maintenance.request", "M2", "R2|", 1, "R2");
                    mq.send("maintenance.request", "M3", "R3|E3", 99, "R3");
                    mq.send("wrong.channel", "M4", "R4|E4", 1, "R4");
                    mq.send("poison", "M5", "handler-fails", 1, "R5");
                    mq.commit();
                }
                try (Sql db = Sql.open(url)) { Check.that("offline consumer has no result", db.query("SELECT COUNT(*) FROM maintenance", r -> r.getInt(1)).getFirst() == 0); }
            }
            case "consume" -> {
                try (Messaging mq = new Messaging(address); Sql db = Sql.open(url)) {
                    for (int i = 0; i < 3; i++) {
                        var message = mq.receive("maintenance.request");
                        Check.that("persistent message survived broker restart", message != null);
                        String id = message.getStringProperty("message_id"), body = Messaging.body(message);
                        String[] fields = body.split("\\|", -1);
                        if (message.getIntProperty("schema_version") != 1 || fields.length != 2 || fields[1].isBlank()) {
                            mq.send("maintenance.quarantine", id, body, message.getIntProperty("schema_version"), message.getJMSCorrelationID());
                        } else {
                            String translated = translate(body, message.getIntProperty("schema_version"));
                            db.update("INSERT INTO maintenance VALUES(?,?,?,?,?)", id, fields[0], "ASSET-" + fields[1], body, translated); db.commit();
                            System.out.println("TRANSLATED " + translated);
                        }
                        mq.commit();
                    }
                    Check.that("wrong channel does not reach endpoint", mq.receive("maintenance.request") == null);
                    var wrong = mq.receive("wrong.channel");
                    Check.that("wrong channel retained separately", wrong != null);
                    mq.send("maintenance.quarantine", "M4", Messaging.body(wrong), 1, "R4"); mq.commit();
                }
            }
            case "poison" -> {
                try (Messaging mq = new Messaging(address)) {
                    for (int i = 1; i <= 3; i++) {
                        var message = mq.receive("poison");
                        Check.that("poison actual delivery " + i, message != null && message.getIntProperty("JMSXDeliveryCount") == i);
                        mq.rollback();
                    }
                    Check.that("poison exhausted", mq.receive("poison") == null);
                    Check.that("broker dead letter queue contains poison", mq.receive("ActiveMQ.DLQ") != null); mq.commit();
                }
            }
            case "verify" -> {
                try (Sql db = Sql.open(url); Messaging mq = new Messaging(address)) {
                    Check.that("one durable endpoint result", db.query("SELECT COUNT(*) FROM maintenance", r -> r.getInt(1)).getFirst() == 1);
                    Check.that("translation isolates external equipment reference", db.query("SELECT asset_ref FROM maintenance WHERE message_id='M1'", r -> r.getString(1)).getFirst().equals("ASSET-E1"));
                    for (int i = 0; i < 3; i++) Check.that("invalid or wrong route quarantined " + i, mq.receive("maintenance.quarantine") != null);
                    mq.commit();
                }
            }
            case "negative" -> translate("R3|E3", 99);
            default -> throw new IllegalArgumentException("mode");
        }
        Check.result("15 " + args[2]);
    }
}
