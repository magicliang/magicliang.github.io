# 16：拆分、路由与聚合

执行 `bash examples/enterprise-application-architecture/labs/16/run.sh`，预期退出0；追加 `negative` 在R1只有一项完成时错误要求两项，预期退出1。Java21/Python3及缓存参数见15/RUN.md。

真实ActiveMQ处理R1/B1的E1、P1和R2/B1的E2。结果发送顺序E2、E1、E1；P1缺项。`aggregate-partial.log`必须显示R1 WAITING、R2 COMPLETE、R1完成数1。真实截止时间到期后R1/B1 TIMED_OUT；创建R1/B2，再输入旧P1和新E1，旧消息隔离，新批次完成。

`evidence/16/run.json`列出独立JVM阶段；`workers.log`含实际路由接收；`finish.log`含新旧批次检查；`database-snapshot.sql`含batches/tasks；`negative/negative.log`含预期AssertionError。broker日志、严格编译和Java版本同目录。

临时数据库保留。单聚合器顺序场景，不覆盖并发聚合、动态增项或SQL与JMS提交窗口；设备交付为合成结果，不代表真实物流动作。
