package enterprise.chapter10;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import enterprise.sql.Sql;
import rental.RentalDesk.Period;
import rental.domain.Money;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.util.Currency;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

public final class RentalEndpoint {
    private RentalEndpoint() { }
    public record CreateDto(String id, String equipment, String amount, String currency, String starts, String ends, String version) { }
    public record Rental(String id, String equipment, Money total, Period period) { }
    public static Rental assemble(CreateDto dto) {
        if (!dto.id().matches("[A-Za-z0-9-]{1,40}")) throw new IllegalArgumentException("id");
        if (!dto.version().equals("1")) throw new IllegalArgumentException("version");
        if (!dto.currency().equals("CNY")) throw new IllegalArgumentException("currency");
        var total = new Money(new BigDecimal(dto.amount()), Currency.getInstance(dto.currency()));
        if (total.amount().signum() <= 0 || total.amount().compareTo(new BigDecimal("100000")) > 0) throw new IllegalArgumentException("amount");
        return new Rental(dto.id(), dto.equipment(), total, new Period(Instant.parse(dto.starts()), Instant.parse(dto.ends())));
    }
    public static Map<String,String> decode(String encoded) {
        if (encoded == null || encoded.isEmpty()) throw new IllegalArgumentException("form");
        var result = new HashMap<String,String>();
        for (String part : encoded.split("&")) {
            String[] pair = part.split("=",2);
            if (pair.length != 2) throw new IllegalArgumentException("form");
            String key = URLDecoder.decode(pair[0],StandardCharsets.UTF_8);
            if (result.put(key,URLDecoder.decode(pair[1],StandardCharsets.UTF_8)) != null) throw new IllegalArgumentException("duplicate field");
        }
        return result;
    }
    public static void reply(HttpExchange exchange,int code,String type,String value) throws IOException {
        byte[] bytes=value.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type",type+"; charset=utf-8");
        exchange.sendResponseHeaders(code,bytes.length);
        try(var body=exchange.getResponseBody()) { body.write(bytes); }
    }
    public static int create(String url, Map<String,String> input) throws Exception {
        if (!input.keySet().equals(Set.of("id","equipment","amount","currency","starts","ends","version"))) return 400;
        Rental rental;
        try { rental=assemble(new CreateDto(input.get("id"),input.get("equipment"),input.get("amount"),input.get("currency"),input.get("starts"),input.get("ends"),input.get("version"))); }
        catch(IllegalArgumentException | DateTimeParseException failure) { return 422; }
        try(Sql db=Sql.open(url)) {
            if (!rental.equipment().equals("E1")) return 403;
            var existing=db.query("SELECT equipment,amount,currency,starts,ends FROM api_contract WHERE id=?",r -> r.getString(1)+"|"+r.getBigDecimal(2).toPlainString()+"|"+r.getString(3)+"|"+r.getString(4)+"|"+r.getString(5),rental.id());
            String payload=rental.equipment()+"|"+rental.total().amount().setScale(2).toPlainString()+"|CNY|"+rental.period().start()+"|"+rental.period().end();
            if (!existing.isEmpty()) return existing.getFirst().equals(payload)?200:409;
            db.update("INSERT INTO api_contract VALUES(?,?,?,?,?,?,?)",rental.id(),"T1",rental.equipment(),rental.total().amount(),"CNY",rental.period().start().toString(),rental.period().end().toString());
            db.commit(); return 201;
        }
    }
    public static void main(String[] args) throws Exception {
        String url="jdbc:h2:"+Path.of(args[0]).toAbsolutePath();
        try(Sql db=Sql.open(url)) { db.update("CREATE TABLE IF NOT EXISTS api_contract(id VARCHAR PRIMARY KEY,tenant VARCHAR,equipment VARCHAR,amount DECIMAL(19,2),currency VARCHAR,starts VARCHAR,ends VARCHAR)"); db.commit(); }
        if (args[1].equals("count")) { try(Sql db=Sql.open(url)) { System.out.println("PERSISTED_COUNT="+db.query("SELECT COUNT(*) FROM api_contract",r->r.getInt(1)).getFirst()); } return; }
        var requests=new AtomicInteger();
        var server=HttpServer.create(new InetSocketAddress("127.0.0.1",Integer.parseInt(args[1])),0);
        server.createContext("/rentals", exchange -> {
            System.out.println("HTTP request="+requests.incrementAndGet()+" method="+exchange.getRequestMethod()+" uri="+exchange.getRequestURI());
            try {
                if (!"tenant-one".equals(exchange.getRequestHeaders().getFirst("X-Principal"))) { reply(exchange,401,"text/plain","unauthorized"); return; }
                if (exchange.getRequestMethod().equals("POST")) {
                    byte[] bytes=exchange.getRequestBody().readNBytes(1025);
                    if(bytes.length>1024) { reply(exchange,413,"text/plain","too large"); return; }
                    int status=create(url,decode(new String(bytes,StandardCharsets.UTF_8)));
                    reply(exchange,status,"text/plain",status<300?"accepted":"rejected");
                } else if(exchange.getRequestMethod().equals("GET")) {
                    var query=decode(exchange.getRequestURI().getRawQuery());
                    if (!query.keySet().equals(Set.of("id")) || !query.get("id").matches("[A-Za-z0-9-]{1,40}")) throw new IllegalArgumentException("query");
                    try(Sql db=Sql.open(url)) {
                        var found=db.query("SELECT id,amount,currency FROM api_contract WHERE id=? AND tenant=?",r->"{\"id\":\""+r.getString(1)+"\",\"amount\":\""+r.getBigDecimal(2).toPlainString()+"\",\"currency\":\""+r.getString(3)+"\"}",query.get("id"),"T1");
                        reply(exchange,found.isEmpty()?404:200,"application/json",found.isEmpty()?"{}":found.getFirst());
                    }
                } else reply(exchange,405,"text/plain","method");
            } catch(IllegalArgumentException failure) { reply(exchange,400,"text/plain","malformed"); }
            catch(Exception failure) { failure.printStackTrace(); reply(exchange,500,"text/plain","failure"); }
        });
        server.start();
        Files.writeString(Path.of(args[2]),Integer.toString(server.getAddress().getPort()));
        System.out.println("READY port="+server.getAddress().getPort());
    }
}
