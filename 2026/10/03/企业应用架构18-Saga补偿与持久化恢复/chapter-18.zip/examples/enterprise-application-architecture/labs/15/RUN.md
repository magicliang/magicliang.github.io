# 15：真实通道、端点和转换

Java 21、Python 3。执行 `bash examples/enterprise-application-architecture/labs/15/run.sh`，预期退出0。追加 `negative`，未知schema99经过同一Translator被拒绝，预期退出1。

`dependencies.json`固定官方Maven Central坐标、SHA1和SHA256；运行器每次核对SHA256，缺失时下载。`ENTERPRISE_INTEGRATION_CACHE`可指定可写缓存；`ENTERPRISE_EVIDENCE_DIR`可指定证据目录。为15–19统一复跑，清单包含ActiveMQ、Camunda、H2及其锁定依赖；15不启动Camunda。

正常场景依次为init、send、consume、poison、verify。send后正常停止并重启独立broker JVM；客户端使用本机随机TCP端口。合法R1/E1落库为ASSET-E1；缺字段、版本99和错误通道进入隔离；毒消息交付计数1/2/3后进入ActiveMQ.DLQ。最终maintenance表只有一条合法结果。

证据在`evidence/15/`：`compile.log`严格编译退出0；`broker-1.log`/`broker-2.log`是真实broker输出；各阶段日志含原始接收、SQL与退出码；`database-snapshot.sql`可核对持久结果；`run.json`索引阶段。负例写入`negative/`。

运行器结束broker进程，但保留临时KahaDB与H2目录，位置在run.json。测试没有覆盖硬断电、多节点、认证、JMS与H2跨资源原子性或15端点重复消费窗口。不要从本机PASS外推生产保障。
