# 17：请求关联与未知结果恢复

执行 `bash examples/enterprise-application-architecture/labs/17/run.sh`，预期退出0；追加 `negative` 错误要求超时后两条FAILED，预期退出1。Java21/Python3及缓存参数见15/RUN.md。

init保存C1/R1、C2/R2两条PENDING并退出。service逆序处理请求，保存两份权威结果，只回复C2。timeout按真实deadline写UNKNOWN。reconcile查询C1持久结果，发送C1答复、重复件及未知C9。receive逐条从真实ActiveMQ接收C2/C1/C1/C9，确认R1=RESERVED-E1、R2=RESERVED-E2，未知C9隔离。

`evidence/17/`含每阶段独立Java命令、SQL和原始报文，`run.json`列退出码，`database-snapshot.sql`保存requests/service_results。独立负例证据在negative/。

请求与权威结果两表位于同一个教学H2文件，访问由独立JVM完成，没有跨系统查询API；两请求同时未完成，不代表线程竞态已测。超时恢复没有重做预留。临时目录保留，路径在运行报告。
