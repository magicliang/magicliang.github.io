package enterprise.chapter16;

import enterprise.integration.Messaging;
import enterprise.sql.Check;
import enterprise.sql.Sql;

public final class Lab16 {
    private Lab16() { }
    private static void batch(Sql db, Messaging mq, String contract, String batch, String[][] items) throws Exception {
        db.update("INSERT INTO batches VALUES(?,?,?,'WAITING',?)", contract, batch, items.length, System.currentTimeMillis() + 1000);
        for (String[] item : items) {
            String task = contract + "/" + batch + "/" + item[1];
            db.update("INSERT INTO tasks VALUES(?,?,?,?,FALSE)", task, contract, batch, item[1]);
            mq.send("delivery." + item[0], task, contract + "|" + batch + "|" + item[1], 1, contract + "/" + batch);
        }
        db.commit(); mq.commit();
    }
    private static void aggregate(Sql db, Messaging mq) throws Exception {
        var message = mq.receive("delivery.results");
        if (message == null) throw new AssertionError("missing result");
        String id = message.getStringProperty("message_id");
        String[] fields = Messaging.body(message).split("\\|");
        var state = db.query("SELECT state FROM batches WHERE contract_id=? AND batch_id=?", r -> r.getString(1), fields[0], fields[1]);
        var known = db.query("SELECT done FROM tasks WHERE task_id=? AND contract_id=? AND batch_id=? AND equipment=?", r -> r.getBoolean(1), id, fields[0], fields[1], fields[2]);
        if (state.isEmpty() || !state.getFirst().equals("WAITING") || known.isEmpty()) {
            mq.send("delivery.late", id, Messaging.body(message), 1, message.getJMSCorrelationID());
            System.out.println("ISOLATE late-or-unknown task=" + id);
        } else if (!known.getFirst()) {
            db.update("UPDATE tasks SET done=TRUE WHERE task_id=?", id);
            int expected = db.query("SELECT expected FROM batches WHERE contract_id=? AND batch_id=?", r -> r.getInt(1), fields[0], fields[1]).getFirst();
            int done = db.query("SELECT COUNT(*) FROM tasks WHERE contract_id=? AND batch_id=? AND done=TRUE", r -> r.getInt(1), fields[0], fields[1]).getFirst();
            if (done == expected) db.update("UPDATE batches SET state='COMPLETE' WHERE contract_id=? AND batch_id=?", fields[0], fields[1]);
            db.commit();
        } else { System.out.println("DEDUP task=" + id); }
        mq.commit();
    }
    public static void main(String[] args) throws Exception {
        String url = "jdbc:h2:" + args[0] + ";WRITE_DELAY=0";
        try (Sql db = Sql.open(url); Messaging mq = new Messaging(args[1])) {
            switch (args[2]) {
                case "init" -> {
                    db.update("CREATE TABLE batches(contract_id VARCHAR,batch_id VARCHAR,expected INT,state VARCHAR,deadline BIGINT,PRIMARY KEY(contract_id,batch_id))");
                    db.update("CREATE TABLE tasks(task_id VARCHAR PRIMARY KEY,contract_id VARCHAR,batch_id VARCHAR,equipment VARCHAR,done BOOLEAN)"); db.commit();
                    batch(db, mq, "R1", "B1", new String[][]{{"camera", "E1"}, {"projector", "P1"}});
                    batch(db, mq, "R2", "B1", new String[][]{{"camera", "E2"}});
                }
                case "workers" -> {
                    var projector = mq.receive("delivery.projector");
                    Check.that("router projector endpoint", Messaging.body(projector).endsWith("P1"));
                    var camera1 = mq.receive("delivery.camera");
                    var camera2 = mq.receive("delivery.camera");
                    Check.that("router camera endpoint", Messaging.body(camera1).endsWith("E1") && Messaging.body(camera2).endsWith("E2"));
                    for (var message : new javax.jms.Message[]{camera2, camera1, camera1}) mq.send("delivery.results", message.getStringProperty("message_id"), Messaging.body(message), 1, message.getJMSCorrelationID());
                    mq.commit();
                    System.out.println("WITHHELD projector=" + Messaging.body(projector));
                }
                case "aggregate-partial" -> {
                    for (int i = 0; i < 3; i++) aggregate(db, mq);
                    Check.that("R1 not prematurely complete", db.query("SELECT state FROM batches WHERE contract_id='R1'", r -> r.getString(1)).getFirst().equals("WAITING"));
                    Check.that("R2 completes independently", db.query("SELECT state FROM batches WHERE contract_id='R2'", r -> r.getString(1)).getFirst().equals("COMPLETE"));
                    Check.that("duplicate adds no completion", db.query("SELECT COUNT(*) FROM tasks WHERE contract_id='R1' AND done=TRUE", r -> r.getInt(1)).getFirst() == 1);
                }
                case "timeout" -> {
                    Check.that("deadline elapsed", db.update("UPDATE batches SET state='TIMED_OUT' WHERE contract_id='R1' AND batch_id='B1' AND state='WAITING' AND deadline<=?", System.currentTimeMillis()) == 1); db.commit();
                    batch(db, mq, "R1", "B2", new String[][]{{"camera", "E1"}});
                    mq.send("delivery.results", "R1/B1/P1", "R1|B1|P1", 1, "R1/B1");
                    mq.send("delivery.results", "R1/B2/E1", "R1|B2|E1", 1, "R1/B2"); mq.commit();
                }
                case "finish" -> {
                    aggregate(db, mq); aggregate(db, mq);
                    Check.that("old batch remains timed out", db.query("SELECT state FROM batches WHERE contract_id='R1' AND batch_id='B1'", r -> r.getString(1)).getFirst().equals("TIMED_OUT"));
                    Check.that("new batch independently complete", db.query("SELECT state FROM batches WHERE contract_id='R1' AND batch_id='B2'", r -> r.getString(1)).getFirst().equals("COMPLETE"));
                    Check.that("late old result isolated", mq.receive("delivery.late") != null); mq.commit();
                }
                case "negative" -> {
                    int count = db.query("SELECT COUNT(*) FROM tasks WHERE contract_id='R1' AND done=TRUE", r -> r.getInt(1)).getFirst();
                    Check.that("cannot certify missing item", count == 2);
                }
                default -> throw new IllegalArgumentException("mode");
            }
        }
        Check.result("16 " + args[2]);
    }
}
