package enterprise.chapter18;

import enterprise.sql.Check;
import enterprise.sql.Sql;

public final class Lab18 {
    private Lab18() { }
    private static String url(String base, String participant) { return "jdbc:h2:" + base + "-" + participant + ";WRITE_DELAY=0"; }
    private static void crash(String point) { System.out.println("HALT_AFTER_DURABLE_COMMIT " + point); System.out.flush(); Runtime.getRuntime().halt(73); }
    private static String state(String base, String saga) throws Exception {
        try (Sql db = Sql.open(url(base, "coordinator"))) { return db.query("SELECT state FROM sagas WHERE id=?", r -> r.getString(1), saga).getFirst(); }
    }
    private static void transition(String base, String saga, String expected, String next, String reason) throws Exception {
        try (Sql db = Sql.open(url(base, "coordinator"))) {
            int changed = db.update("UPDATE sagas SET state=? WHERE id=? AND state=?", next, saga, expected);
            if (changed != 1) throw new IllegalStateException("unexpected saga state " + saga + " expected=" + expected);
            db.update("INSERT INTO transitions(saga,previous_state,next_state,reason) VALUES(?,?,?,?)", saga, expected, next, reason); db.commit();
        }
    }
    private static boolean operation(String base, String participant, String saga, String action) throws Exception {
        String key = saga + "/" + action;
        try (Sql db = Sql.open(url(base, participant))) {
            if (!db.query("SELECT id FROM operations WHERE id=?", r -> r.getString(1), key).isEmpty()) {
                System.out.println("IDEMPOTENT participant=" + participant + " key=" + key); return false;
            }
            db.update("INSERT INTO operations VALUES(?,?,?)", key, saga, action);
            if (action.equals("reserve")) db.update("INSERT INTO resources VALUES(?,TRUE,0)", saga);
            if (action.equals("release")) Check.that("release existing reservation", db.update("UPDATE resources SET held=FALSE,releases=releases+1 WHERE saga=? AND held=TRUE", saga) == 1);
            if (action.equals("charge")) db.update("INSERT INTO charges VALUES(?,25)", saga);
            db.commit(); return true;
        }
    }
    private static void compensate(String base, boolean crashAfter) throws Exception {
        String status = state(base, "R1");
        if (status.equals("COMPENSATED")) { System.out.println("IDEMPOTENT saga=R1 already compensated"); return; }
        if (!status.equals("COMPENSATING") && !status.equals("RETRY_COMPENSATION")) throw new IllegalStateException("not compensatable: " + status);
        operation(base, "inventory", "R1", "release");
        if (crashAfter) crash("release-before-coordinator-record");
        transition(base, "R1", status, "COMPENSATED", "release-confirmed");
    }
    private static void chargeSucceeded(String base, String event, String saga) throws Exception {
        try (Sql db = Sql.open(url(base, "coordinator"))) {
            var prior = db.query("SELECT saga,decision FROM received WHERE event_id=?", r -> new String[]{r.getString(1), r.getString(2)}, event);
            if (!prior.isEmpty()) {
                if (!prior.getFirst()[0].equals(saga)) throw new IllegalStateException("event identity conflict " + event);
                System.out.println("EVENT_DEDUP id=" + event + " decision=" + prior.getFirst()[1]);
                return;
            }
            String current = db.query("SELECT state FROM sagas WHERE id=?", r -> r.getString(1), saga).getFirst();
            String decision;
            if (current.equals("RESERVED")) {
                Check.that("charge-success conditional transition", db.update("UPDATE sagas SET state='CHARGED' WHERE id=? AND state='RESERVED'", saga) == 1);
                db.update("INSERT INTO transitions(saga,previous_state,next_state,reason) VALUES(?,'RESERVED','CHARGED','payment-confirmed')", saga);
                decision = "ADVANCED";
            } else if (current.equals("COMPENSATED") || current.equals("MANUAL_REVIEW") || current.equals("DELIVERED")) {
                decision = "IGNORE_TERMINAL";
            } else {
                decision = "IGNORE_UNEXPECTED_STATE";
            }
            db.update("INSERT INTO received VALUES(?,?,?)", event, saga, decision);
            db.commit();
            System.out.println("EVENT_DECISION id=" + event + " saga=" + saga + " current=" + current + " decision=" + decision);
        }
    }
    public static void main(String[] args) throws Exception {
        String base = args[0], mode = args[2];
        switch (mode) {
            case "init" -> {
                try (Sql db = Sql.open(url(base, "coordinator"))) {
                    db.update("CREATE TABLE sagas(id VARCHAR PRIMARY KEY,state VARCHAR)");
                    db.update("CREATE TABLE transitions(seq BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,saga VARCHAR,previous_state VARCHAR,next_state VARCHAR,reason VARCHAR)");
                    db.update("CREATE TABLE received(event_id VARCHAR PRIMARY KEY,saga VARCHAR,decision VARCHAR)");
                    for (String id : new String[]{"R1", "R2"}) { db.update("INSERT INTO sagas VALUES(?,'STARTED')", id); db.update("INSERT INTO transitions(saga,previous_state,next_state,reason) VALUES(?,'NONE','STARTED','accepted')", id); }
                    db.commit();
                }
                for (String participant : new String[]{"inventory", "billing"}) try (Sql db = Sql.open(url(base, participant))) {
                    db.update("CREATE TABLE operations(id VARCHAR PRIMARY KEY,saga VARCHAR,action VARCHAR)");
                    if (participant.equals("inventory")) db.update("CREATE TABLE resources(saga VARCHAR PRIMARY KEY,held BOOLEAN,releases INT)");
                    else db.update("CREATE TABLE charges(saga VARCHAR PRIMARY KEY,amount INT)");
                    db.commit();
                }
            }
            case "reserve-crash" -> { operation(base, "inventory", "R1", "reserve"); crash("reserve-before-coordinator-record"); }
            case "resume-reserve" -> {
                Check.that("restarted coordinator recovers durable reservation without duplication", !operation(base, "inventory", "R1", "reserve"));
                transition(base, "R1", "STARTED", "RESERVED", "participant-query");
            }
            case "charge-fail" -> {
                try (Sql db = Sql.open(url(base, "billing"))) {
                    db.update("INSERT INTO operations VALUES('R1/charge-rejected','R1','rejected')"); db.commit();
                }
                transition(base, "R1", "RESERVED", "CHARGE_FAILED", "insufficient-funds");
                transition(base, "R1", "CHARGE_FAILED", "COMPENSATING", "release-required");
            }
            case "release-fail" -> {
                try (Sql db = Sql.open(url(base, "inventory"))) {
                    db.update("UPDATE resources SET held=FALSE WHERE saga='R1'"); db.rollback();
                }
                transition(base, "R1", "COMPENSATING", "RETRY_COMPENSATION", "injected-participant-failure");
                Check.that("failed compensation remains durably retryable", state(base, "R1").equals("RETRY_COMPENSATION"));
            }
            case "release-crash" -> compensate(base, true);
            case "recover" -> { compensate(base, false); compensate(base, false); }
            case "deliver" -> {
                operation(base, "inventory", "R2", "reserve"); transition(base, "R2", "STARTED", "RESERVED", "reserve-confirmed");
                operation(base, "billing", "R2", "charge");
                chargeSucceeded(base, "R2-charge-success", "R2");
                chargeSucceeded(base, "R2-charge-success", "R2");
                transition(base, "R2", "CHARGED", "DELIVERED", "physical-handover-confirmed");
            }
            case "cancel-delivered" -> transition(base, "R2", "DELIVERED", "MANUAL_REVIEW", "physical-delivery-not-reversible-by-software");
            case "late" -> {
                chargeSucceeded(base, "late-charge-success", "R1");
                chargeSucceeded(base, "late-charge-success", "R1");
                try (Sql db = Sql.open(url(base, "coordinator"))) {
                    Check.that("terminal late event stored once", db.query("SELECT COUNT(*) FROM received WHERE event_id='late-charge-success' AND decision='IGNORE_TERMINAL'", r -> r.getInt(1)).getFirst() == 1);
                    Check.that("normal and late duplicate inputs add no event rows", db.query("SELECT COUNT(*) FROM received", r -> r.getInt(1)).getFirst() == 2);
                }
                Check.that("late reply does not resurrect compensated saga", state(base, "R1").equals("COMPENSATED"));
            }
            case "verify" -> {
                Check.that("R1 compensated", state(base, "R1").equals("COMPENSATED"));
                Check.that("irreversible R2 is manual", state(base, "R2").equals("MANUAL_REVIEW"));
                try (Sql db = Sql.open(url(base, "inventory"))) {
                    Check.that("R1 released exactly once after crash and replay", db.query("SELECT releases FROM resources WHERE saga='R1' AND held=FALSE", r -> r.getInt(1)).getFirst() == 1);
                    Check.that("R2 not falsely released", db.query("SELECT releases FROM resources WHERE saga='R2' AND held=TRUE", r -> r.getInt(1)).getFirst() == 0);
                }
                try (Sql db = Sql.open(url(base, "billing"))) {
                    Check.that("failed R1 never charged", db.query("SELECT COUNT(*) FROM charges WHERE saga='R1'", r -> r.getInt(1)).getFirst() == 0);
                    Check.that("R2 one monetary effect", db.query("SELECT SUM(amount) FROM charges WHERE saga='R2'", r -> r.getInt(1)).getFirst() == 25);
                    Check.that("repeated charge deduplicated", !operation(base, "billing", "R2", "charge"));
                }
                try (Sql db = Sql.open(url(base, "coordinator"))) {
                    var history = db.query("SELECT saga,previous_state,next_state,reason FROM transitions ORDER BY seq", r -> r.getString(1) + ":" + r.getString(2) + "->" + r.getString(3) + ":" + r.getString(4));
                    history.forEach(row -> System.out.println("DURABLE_TRANSITION " + row));
                    Check.that("every modeled transition durably recorded", history.size() == 11);
                }
            }
            case "negative" -> {
                if (state(base, "R2").equals("DELIVERED")) throw new IllegalStateException("automatic cancel forbidden after physical delivery");
                throw new AssertionError("negative precondition missing");
            }
            default -> throw new IllegalArgumentException("mode");
        }
        Check.result("18 " + mode);
    }
}
