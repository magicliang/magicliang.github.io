# Chapter 10

Invocation: `bash run-lab.sh 10` with Java 21 and optional H2_JAR matching sql-support/v1/h2.json.

Result: exit 0; see normal.stdout.txt and normal.stderr.txt. The Java server receives real loopback HTTP requests and commits to file H2; after termination a fresh JVM reads persisted state.

Binary observables: create 201; exact three-field DTO 200; invalid starts/ends 422; GET missing query, unknown-only/extra field, empty/duplicate id 400; valid absent id 404. Existing authorization, size, version and payload conflict regressions remain passing. Final PERSISTED_COUNT=1 proves rejected creates did not add contracts.

Artifacts: http-requests.json, http-server.log, restart-readback.log.

Limits: one tenant, fixed authenticated-context stand-in, serial server, no TLS or production authentication.
