# Enterprise Architecture 13

Requires Java 21 and Python 3.10+. Set JAVA_HOME to your JDK21 installation. Run `bash run-lab.sh 13`. H2 2.1.214 is resolved from pinned Maven Central URL with mandatory SHA256 verification. H2_JAR may point to a predownloaded matching jar. SQL databases are temporary and isolated per run. See evidence/13/RUN.md for scenarios and limits.
