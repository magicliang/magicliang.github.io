import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanContext;
import io.opentelemetry.api.trace.TraceFlags;
import io.opentelemetry.api.trace.TraceState;
import io.opentelemetry.context.Context;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public final class ContextAcrossThread {
    public static void main(String[] args) throws Exception {
        String traceId = "11111111111111111111111111111111";
        String spanId = "2222222222222222";
        var span = Span.wrap(SpanContext.create(
            traceId, spanId, TraceFlags.getSampled(), TraceState.getDefault()));
        var context = Context.root().with(span);
        var executor = Executors.newSingleThreadExecutor();
        try {
            executor.submit(context.wrap(() -> {
                var observed = Span.current().getSpanContext();
                if (!traceId.equals(observed.getTraceId())
                        || !spanId.equals(observed.getSpanId())) {
                    throw new AssertionError("context mismatch");
                }
            })).get(2, TimeUnit.SECONDS);
            if (Span.current().getSpanContext().isValid()) {
                throw new AssertionError("caller context changed");
            }
            System.out.println("workerContext=matched callerContext=restored");
        } finally {
            executor.shutdownNow();
            if (!executor.awaitTermination(2, TimeUnit.SECONDS)) {
                throw new AssertionError("executor not terminated");
            }
        }
    }
}

