#!/usr/bin/env python3
import hashlib,json,os,pathlib,shutil,zipfile,xml.etree.ElementTree as ET
root=pathlib.Path(__file__).resolve().parent
evidence=pathlib.Path(os.environ['OTEL_EVIDENCE_ROOT'])
repo=pathlib.Path(os.environ['OTEL_REPO_ROOT'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=['README.md','build.sbt','project/plugins.sbt','project/build.properties','conf/routes','conf/application.conf','app/controllers/TelemetryController.java','app/telemetry/ScalaBoundary.scala','test/TelemetryTest.java','otel_checks.py','collector_parser.py','test_collector_parser.py','analyze_collector.py','collect_evidence.py','writing/ContextAcrossThread.java']
sources=[dict(source=str(root/f),destination='examples/play-electives/e06-otel/'+f,sha256=sha(root/f)) for f in files]
report=root/'target/test-reports/TEST-TelemetryTest.xml'
xml=ET.parse(report).getroot()
assert int(xml.attrib['tests'])==2 and int(xml.attrib['failures'])==0 and int(xml.attrib['errors'])==0
shutil.copyfile(report,evidence/'TEST-TelemetryTest.xml')
lib=root/'target/universal/stage/lib'
assert not list(lib.glob('*opentelemetry-sdk*'))
jar=next(lib.glob('*play-otel-0.1.0-sans-externalized.jar'))
checks=[]
with zipfile.ZipFile(jar) as z:
 for name in ['controllers/TelemetryController.class','telemetry/ScalaBoundary.class','telemetry/ScalaBoundary$.class']:
  p=root/'target/scala-2.13/classes'/name
  assert z.read(name)==p.read_bytes()
  checks.append(dict(name=name,sha256=sha(p),jar=jar.name))
summary=json.loads((evidence/'run-final/summary.json').read_text())
assert summary['status']=='PASS' and summary['checks']==60
assert len(json.loads((evidence/'run-final/scope-lineage.json').read_text())['traces'])==3
assert 'workerContext=matched callerContext=restored' in (evidence/'java-example.log').read_text()
assert json.loads((evidence/'anti-ai-tone-final.json').read_text())['errors']==0
assert not json.loads((evidence/'anti-persona-final.json').read_text())['findings']
post=repo/'source/_posts/2026-10-03-深入-Play-E06-OpenTelemetry集成.md'
data=dict(status='PASS',sources=sources,productionClassChecks=checks,summary=summary,junitTests=2,post=dict(path=str(post),sha256=sha(post)),evidenceDestination='examples/play-electives/evidence/e06/isolated',boundaries=['Agent mode owns SDK; standalone SDK test only','Collector debug output is not durable storage','No database business commit evidence','No performance ranking'])
(evidence/'integration-manifest.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(status='PASS',sources=len(sources),classes=len(checks),junit=2,checks=summary['checks'],postSha256=sha(post))))
