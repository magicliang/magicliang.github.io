#!/usr/bin/env python3
import json,pathlib,re,sys,zipfile,hashlib
root=pathlib.Path(sys.argv[1])
log=(root/"collector.log").read_text()
scopes=[]
for m in re.finditer(r"InstrumentationScope ([^\n]+)",log):scopes.append(dict(offset=m.start(),value=m.group(1)))
spans=json.loads((root/"spans.json").read_text())
for span in spans:
    position=log.find("ID             : "+span["spanId"])
    previous=[s for s in scopes if s["offset"]<position]
    span["scope"]=previous[-1]["value"] if previous else ""
receipts=[]
for row in json.loads((root/"responses.json").read_text()):
    if row["mode"]!="agent":continue
    trace=[s for s in spans if s["traceId"]==row["trace"]]
    byid={s["spanId"]:s for s in trace}
    server=[s for s in trace if s["kind"]=="Server"]
    assert len(server)==1 and server[0]["parentId"]=="2222222222222222"
    controller=byid[row["data"]["controllerId"]]
    auto_controller=byid[controller["parentId"]]
    assert auto_controller["parentId"]==server[0]["spanId"]
    assert auto_controller["scope"].startswith("io.opentelemetry.play-mvc-2.6 ")
    wire=json.loads(row["data"]["downstream"])["traceparent"].split("-")[2]
    assert byid[wire]["scope"].startswith("io.opentelemetry.play-ws-2.1 ")
    receipts.append(dict(traceId=row["trace"],server=server[0]["spanId"],automaticController=auto_controller["spanId"],manualController=controller["spanId"],automaticClient=wire,
        serverScope=server[0]["scope"],controllerScope=auto_controller["scope"],clientScope=byid[wire]["scope"]))
(root/"scope-lineage.json").write_text(json.dumps(dict(status="PASS",traces=receipts),indent=2)+"\n")
print(json.dumps(dict(status="PASS",traces=len(receipts))))
