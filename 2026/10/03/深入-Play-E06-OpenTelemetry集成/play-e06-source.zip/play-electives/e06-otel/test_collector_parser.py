import unittest
from collector_parser import parse

class CollectorParserTest(unittest.TestCase):
    def test_empty_parent_stays_empty(self):
        span=parse("Span #0\n    Trace ID : 11111111111111111111111111111111\n    Parent ID : \n    ID : 2222222222222222\n    Name : root\n    Kind : Server\n")[0]
        self.assertEqual("",span["parentId"])
        self.assertEqual("2222222222222222",span["spanId"])
        self.assertEqual("root",span["name"])

    def test_explicit_parent_and_adjacent_spans(self):
        spans=parse("Span #0\nParent ID : 1111111111111111\nID : 2222222222222222\nSpan #1\nParent ID :\nID : 3333333333333333\n")
        self.assertEqual(2,len(spans))
        self.assertEqual("1111111111111111",spans[0]["parentId"])
        self.assertEqual("",spans[1]["parentId"])
        self.assertEqual("3333333333333333",spans[1]["spanId"])

if __name__ == '__main__':unittest.main()
