import re

def parse(log):
    spans=[]
    for block in re.split(r"Span #\d+[ \t]*\r?\n",log)[1:]:
        def field(name):
            m=re.search(r"^[ \t]*"+re.escape(name)+r"[ \t]*:[ \t]*([^\r\n]*)$",block,re.M)
            return m.group(1).strip() if m else ""
        spans.append(dict(traceId=field("Trace ID"),spanId=field("ID"),parentId=field("Parent ID"),name=field("Name"),kind=field("Kind"),block=block))
    return spans
