package telemetry
import io.opentelemetry.api.GlobalOpenTelemetry
import io.opentelemetry.context.Context
import java.util.concurrent.{CompletableFuture, CompletionStage, Executor}
import scala.concurrent.{ExecutionContext, Future}

object ScalaBoundary {
  def run(parent: Context, executor: Executor): CompletionStage[String] = {
    implicit val ec: ExecutionContext = ExecutionContext.fromExecutor(executor)
    val result = new CompletableFuture[String]()
    Future {
      val scope = parent.makeCurrent()
      val span = GlobalOpenTelemetry.getTracer("play-e06-manual", "1")
        .spanBuilder("manual.scala-future").startSpan()
      try result.complete(span.getSpanContext.getSpanId)
      catch { case error: Throwable => result.completeExceptionally(error) }
      finally { span.end(); scope.close() }
    }
    result
  }
}

