package controllers;
import javax.inject.Inject;
import javax.inject.Singleton;
import play.mvc.*;
import play.libs.Json;
import play.libs.ws.*;
import play.inject.ApplicationLifecycle;
import io.opentelemetry.api.*;
import io.opentelemetry.api.trace.*;
import io.opentelemetry.context.*;
import org.apache.pekko.stream.javadsl.Source;
import org.apache.pekko.util.ByteString;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.nio.file.*;

@Singleton
public final class TelemetryController extends Controller {
    private final Tracer tracer=GlobalOpenTelemetry.getTracer("play-e06-manual","1");
    private final WSClient ws;
    private final ThreadPoolExecutor executor=new ThreadPoolExecutor(2,2,0,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<>(16),
        r->new Thread(r,"otel-business"),new ThreadPoolExecutor.AbortPolicy());
    private final AtomicInteger completed=new AtomicInteger();
    private final AtomicInteger cancelled=new AtomicInteger();
    private final AtomicInteger activeStreams=new AtomicInteger();
    @Inject public TelemetryController(WSClient ws,ApplicationLifecycle life){
        this.ws=ws;
        life.addStopHook(()->{
            executor.shutdown();
            try {
                boolean drained=executor.awaitTermination(5,TimeUnit.SECONDS);
                Files.writeString(Path.of(System.getenv("OTEL_LAB_JOURNAL")),"drained="+drained+";executor="+executor.isTerminated()+";activeStreams="+activeStreams.get());
                return CompletableFuture.completedFuture(null);
            }catch(Exception e){return CompletableFuture.failedFuture(e);}
        });
    }
    public Result ready(){return ok("ready");}
    private Context parent(Http.Request request) {
        Context current=Context.current();
        if(Span.fromContext(current).getSpanContext().isValid())return current;
        return GlobalOpenTelemetry.getPropagators().getTextMapPropagator().extract(current,request,
            new io.opentelemetry.context.propagation.TextMapGetter<Http.Request>() {
                public Iterable<String> keys(Http.Request r){return r.getHeaders().toMap().keySet();}
                public String get(Http.Request r,String key){return r.getHeaders().get(key).orElse(null);}
            });
    }
    public CompletionStage<Result> work(Http.Request request){
        Span controller=tracer.spanBuilder("manual.controller").setParent(parent(request)).startSpan();
        Context controllerContext=parent(request).with(controller);
        CompletableFuture<Result> answer=new CompletableFuture<>();
        executor.execute(controllerContext.wrap(()->{
            Span worker=tracer.spanBuilder("manual.worker").startSpan();
            Context workerContext=Context.current().with(worker);
            try(Scope scope=workerContext.makeCurrent()){
                CompletionStage<String> scalaStage=telemetry.ScalaBoundary.run(workerContext,executor);
                Span client=tracer.spanBuilder("manual.ws").setSpanKind(SpanKind.INTERNAL).startSpan();
                Context clientContext=workerContext.with(client);
                Map<String,String> headers=new HashMap<>();
                GlobalOpenTelemetry.getPropagators().getTextMapPropagator().inject(clientContext,headers,Map::put);
                WSRequest call=ws.url(System.getenv("OTEL_LAB_DOWNSTREAM")).setRequestTimeout(Duration.ofSeconds(2));
                for(var h:headers.entrySet())call=call.addHeader(h.getKey(),h.getValue());
                CompletionStage<WSResponse> responseStage;
                try(Scope dispatch=clientContext.makeCurrent()){responseStage=call.get();}
                responseStage.thenCombine(scalaStage,(response,scalaId)->Map.entry(response,scalaId)).whenComplete((combined,error)->{
                    try(Scope callback=clientContext.makeCurrent()){
                        if(error!=null){client.recordException(error);client.setStatus(StatusCode.ERROR);answer.complete(internalServerError("downstream"));}
                        else {
                            WSResponse response=combined.getKey();
                            completed.incrementAndGet();
                            answer.complete(ok(Json.toJson(Map.of("value","ok","recording",controller.isRecording(),
                                "traceId",controller.getSpanContext().getTraceId(),"controllerId",controller.getSpanContext().getSpanId(),
                                "workerId",worker.getSpanContext().getSpanId(),"wsId",client.getSpanContext().getSpanId(),"scalaId",combined.getValue(),
                                "downstream",response.getBody()))));
                        }
                    }finally{client.end();worker.end();controller.end();}
                });
            }catch(Exception error){worker.recordException(error);worker.end();controller.end();answer.complete(internalServerError());}
        }));
        return answer;
    }
    public Result stream(Http.Request request){
        Span span=tracer.spanBuilder("manual.stream").setParent(parent(request)).startSpan();
        Context context=parent(request).with(span);
        activeStreams.incrementAndGet();
        Source<ByteString,?> source=Source.repeat(ByteString.fromString("data: tick\n\n")).throttle(1,Duration.ofMillis(30))
            .watchTermination((m,done)->{
                done.whenComplete((value,error)->{
                    try(Scope scope=context.makeCurrent()){
                        span.addEvent("stream.terminated");
                        span.setAttribute("terminal.error",error!=null);
                        cancelled.incrementAndGet();activeStreams.decrementAndGet();span.end();
                    }
                });return m;
            });
        return ok().chunked(source).as("text/event-stream").withHeader("X-Lab-Trace",span.getSpanContext().getTraceId())
            .withHeader("X-Lab-Span",span.getSpanContext().getSpanId());
    }
    public Result state(){return ok(Json.toJson(Map.of("completed",completed.get(),"streamTerminals",cancelled.get(),"activeStreams",activeStreams.get())));}
}
