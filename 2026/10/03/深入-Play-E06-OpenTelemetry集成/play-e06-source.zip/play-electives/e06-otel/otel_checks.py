#!/usr/bin/env python3
"""Real OTLP HTTP/protobuf receiver plus bounded Play agent/on/off/export-failure scenarios."""
import hashlib,http.server,json,os,pathlib,re,socket,subprocess,threading,time,urllib.request,urllib.error,uuid
ROOT=pathlib.Path(__file__).resolve().parent
OUT=pathlib.Path(os.environ["OTEL_LAB_EVIDENCE"]).resolve();OUT.mkdir(parents=True,exist_ok=True)
AGENT=pathlib.Path(os.environ["OTEL_LAB_AGENT"])
COLLECTOR=pathlib.Path(os.environ["OTEL_LAB_COLLECTOR"])
assert hashlib.sha256(AGENT.read_bytes()).hexdigest()=="d05f6e36fac8db629263a6aaec2841cc934d064d7b19bfe38425b604b8b54926"
checks=[];responses=[];wire=[];downstream=[];processes=[];summary={"status":"FAIL"}
def port():
    with socket.socket() as s:s.bind(("127.0.0.1",0));return s.getsockname()[1]
collector_port=port()
class Proxy(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        header=self.headers.get("traceparent","")
        downstream.append(dict(traceparent=header))
        body=json.dumps(dict(traceparent=header)).encode()
        self.send_response(200);self.end_headers();self.wfile.write(body)
    def do_POST(self):
        body=self.rfile.read(int(self.headers["Content-Length"]))
        content=self.headers.get("Content-Type","")
        forwarded=urllib.request.Request("http://127.0.0.1:"+str(collector_port)+self.path,data=body,headers={"Content-Type":content},method="POST")
        with urllib.request.urlopen(forwarded,timeout=3) as received:
            data=received.read();status=received.status
        wire.append(dict(path=self.path,contentType=content,bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),collectorStatus=status))
        self.send_response(status);self.end_headers();self.wfile.write(data)
    def log_message(self,*args):pass
proxy=http.server.ThreadingHTTPServer(("127.0.0.1",0),Proxy)
threading.Thread(target=proxy.serve_forever,daemon=True).start()
def req(base,path,trace=None):
    h={"traceparent":"00-"+trace+"-2222222222222222-01"} if trace else {}
    t=time.perf_counter()
    try:
        with urllib.request.urlopen(urllib.request.Request(base+path,headers=h),timeout=8) as r:s=r.status;b=r.read().decode()
    except urllib.error.HTTPError as e:s=e.code;b=e.read().decode()
    return dict(status=s,body=b,millis=(time.perf_counter()-t)*1000)
def check(name,ok,**data):
    checks.append(dict(name=name,passed=bool(ok),**data));assert ok,(name,data)
from collector_parser import parse
config=OUT/"collector.yaml"
config.write_text("receivers:\n  otlp:\n    protocols:\n      http:\n        endpoint: 127.0.0.1:"+str(collector_port)+"\nprocessors:\n  batch:\n    timeout: 100ms\n    send_batch_size: 8\nexporters:\n  debug:\n    verbosity: detailed\n    sampling_initial: 10000\n    sampling_thereafter: 1\nservice:\n  telemetry:\n    metrics:\n      level: none\n  pipelines:\n    traces:\n      receivers: [otlp]\n      processors: [batch]\n      exporters: [debug]\n")
try:
    collector_log=open(OUT/"collector.log","w")
    collector=subprocess.Popen([str(COLLECTOR),"--config="+str(config)],stdout=collector_log,stderr=subprocess.STDOUT)
    processes.append((collector,collector_log))
    for _ in range(100):
        if collector.poll() is not None:raise AssertionError("collector startup")
        try:socket.create_connection(("127.0.0.1",collector_port),timeout=.1).close();break
        except OSError:time.sleep(.1)
    else:raise AssertionError("collector timeout")
    for mode in ("agent","disabled","export-failure"):
        app_port=port();base="http://127.0.0.1:"+str(app_port);journal=OUT/(mode+"-cleanup.txt")
        endpoint="http://127.0.0.1:"+str(proxy.server_port if mode!="export-failure" else port())
        env=os.environ|dict(OTEL_LAB_JOURNAL=str(journal),OTEL_LAB_DOWNSTREAM="http://127.0.0.1:"+str(proxy.server_port)+"/downstream",
            APPLICATION_SECRET=uuid.uuid4().hex+uuid.uuid4().hex,OTEL_SERVICE_NAME="play-e06-"+mode,
            OTEL_EXPORTER_OTLP_PROTOCOL="http/protobuf",OTEL_EXPORTER_OTLP_ENDPOINT=endpoint,
            OTEL_TRACES_EXPORTER="otlp",OTEL_METRICS_EXPORTER="none",OTEL_LOGS_EXPORTER="none",
            OTEL_BSP_MAX_QUEUE_SIZE="16",OTEL_BSP_MAX_EXPORT_BATCH_SIZE="8",OTEL_BSP_SCHEDULE_DELAY="100",OTEL_BSP_EXPORT_TIMEOUT="1000",
            OTEL_EXPORTER_OTLP_TIMEOUT="500",OTEL_TRACES_SAMPLER="always_on")
        cmd=[str(ROOT/"target/universal/stage/bin/play-otel"),"-Dhttp.port="+str(app_port),"-Dhttp.address=127.0.0.1","-Dpidfile.path=/dev/null"]
        if mode!="disabled":cmd.append("-J-javaagent:"+str(AGENT))
        log=open(OUT/(mode+"-server.log"),"w")
        process=subprocess.Popen(cmd,env=env,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT);processes.append((process,log))
        for _ in range(400):
            if process.poll() is not None:raise AssertionError((mode,"startup",process.returncode))
            try:
                if req(base,"/ready")["status"]==200:break
            except OSError:pass
            time.sleep(.1)
        else:raise AssertionError("app startup")
        for n in range(3):
            trace=uuid.uuid4().hex
            response=req(base,"/work",trace);data=json.loads(response["body"])
            responses.append(dict(mode=mode,trace=trace,response=response,data=data))
            check(mode+" business result",response["status"]==200 and data["value"]=="ok")
            check(mode+" recording contract",data["recording"]==(mode!="disabled"))
            if mode!="disabled":check(mode+" incoming trace",data["traceId"]==trace,trace=trace,data=data)
        if mode=="agent":
            for _ in range(2):
                trace=uuid.uuid4().hex
                with socket.create_connection(("127.0.0.1",app_port),timeout=5) as s:
                    s.sendall(("GET /stream HTTP/1.1\r\nHost: 127.0.0.1\r\ntraceparent: 00-"+trace+"-2222222222222222-01\r\nConnection: close\r\n\r\n").encode())
                    raw=b""
                    while b"data: tick" not in raw:raw+=s.recv(4096)
                responses.append(dict(mode="stream",trace=trace,header=raw.split(b"\r\n\r\n")[0].decode()))
            for _ in range(100):
                state=json.loads(req(base,"/state")["body"])
                if state["streamTerminals"]==2 and state["activeStreams"]==0:break
                time.sleep(.05)
            check("stream cancel terminal",state["streamTerminals"]==2 and state["activeStreams"]==0,state=state)
        if mode=="export-failure":
            for _ in range(50):
                if "Failed to export spans" in (OUT/(mode+"-server.log")).read_text():break
                time.sleep(.1)
            check("export failure logged","Failed to export spans" in (OUT/(mode+"-server.log")).read_text())
        time.sleep(.8)
        process.terminate();exit_code=process.wait(timeout=20);log.close()
        check(mode+" application drained",journal.read_text()=="drained=true;executor=true;activeStreams=0",exit=exit_code)
    time.sleep(.5)
    collector.terminate();collector.wait(timeout=10);collector_log.close()
    spans=parse((OUT/"collector.log").read_text())
    (OUT/"spans.json").write_text(json.dumps(spans,indent=2)+"\n")
    check("root parent remains empty",any(s["parentId"]=="" for s in spans) and all(re.fullmatch(r"[0-9a-f]{16}",s["spanId"]) and (s["parentId"]=="" or re.fullmatch(r"[0-9a-f]{16}",s["parentId"])) for s in spans))
    check("real protobuf receiver",len(wire)>0 and all(x["contentType"].startswith("application/x-protobuf") and x["collectorStatus"]==200 and x["bytes"]>0 for x in wire),batches=len(wire))
    for row in responses:
        if row["mode"]=="agent":
            d=row["data"];byid={s["spanId"]:s for s in spans if s["traceId"]==row["trace"]}
            for key in ("controllerId","workerId","wsId","scalaId"):check("collector has "+key,d[key] in byid)
            check("worker child",byid[d["workerId"]]["parentId"]==d["controllerId"])
            check("ws child",byid[d["wsId"]]["parentId"]==d["workerId"])
            check("Scala Future child",byid[d["scalaId"]]["parentId"]==d["workerId"])
            child=json.loads(d["downstream"])["traceparent"]
            check("wire downstream same trace",child.split("-")[1]==row["trace"],traceparent=child)
            wire_span=child.split("-")[2]
            check("actual automatic WS descendant",wire_span in byid and byid[wire_span]["kind"]=="Client" and byid[wire_span]["parentId"]==d["wsId"],spanId=wire_span)
        if row["mode"]=="stream":
            matches=[s for s in spans if s["traceId"]==row["trace"] and s["name"]=="manual.stream"]
            check("cancel span exported",len(matches)==1 and "stream.terminated" in matches[0]["block"])
    summary=dict(status="PASS",checks=len(checks),collectorSpans=len(spans),protobufBatches=len(wire))
finally:
    cleanup=[]
    for process,log in reversed(processes):
        try:
            if process.poll() is None:
                process.terminate()
                try:process.wait(timeout=20)
                except subprocess.TimeoutExpired:process.kill();process.wait();cleanup.append("forced kill")
        finally:log.close()
    proxy.shutdown();proxy.server_close()
    if cleanup:summary={"status":"FAIL","cleanup":cleanup}
    for name,data in [("summary",summary),("checks",checks),("responses",responses),("wire",wire),("downstream",downstream)]:
        (OUT/(name+".json")).write_text(json.dumps(data,indent=2)+"\n")
print(json.dumps(summary))
