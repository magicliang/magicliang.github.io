# Play 3 OpenTelemetry laboratory

Requires JDK 21, Python 3.9+, sbt 1.10.7, Play 3.0.6. Production depends only on OpenTelemetry API 1.44.1; standalone SDK tests use SDK 1.44.1. The 2.10.0 agent owns its SDK. Do not register a second GlobalOpenTelemetry provider in the application.

From this directory, select your installed JDK 21 and download fixed artifacts. The Collector command below is for macOS ARM64; select the official matching release asset on other platforms and verify its published checksum.

```sh
export JAVA_HOME=/path/to/jdk-21
curl -fL https://repo.maven.apache.org/maven2/org/scala-sbt/sbt-launch/1.10.7/sbt-launch-1.10.7.jar -o /tmp/otel-sbt-launch.jar
curl -fL https://github.com/open-telemetry/opentelemetry-java-instrumentation/releases/download/v2.10.0/opentelemetry-javaagent.jar -o /tmp/opentelemetry-javaagent-2.10.0.jar
curl -fL https://github.com/open-telemetry/opentelemetry-collector-releases/releases/download/v0.113.0/otelcol_0.113.0_darwin_arm64.tar.gz -o /tmp/otelcol-0.113.0.tar.gz
mkdir -p /tmp/otelcol-0.113.0
tar -xzf /tmp/otelcol-0.113.0.tar.gz -C /tmp/otelcol-0.113.0
shasum -a 256 /tmp/opentelemetry-javaagent-2.10.0.jar /tmp/otelcol-0.113.0.tar.gz
"$JAVA_HOME/bin/java" -Dsbt.supershell=false -jar /tmp/otel-sbt-launch.jar test stage
```

Expected SHA256: agent `d05f6e36fac8db629263a6aaec2841cc934d064d7b19bfe38425b604b8b54926`; Darwin ARM64 tar `3333be6b3175df32907e3e43b5274a1b41ef997c86b99adf85e580936dbfc013`. The driver enforces the agent digest. The test process uses an SDK exporter only in test scope. The bounded processor test creates 101 spans, exports 17 and drops 84 while one export is deliberately held.

```sh
export OTEL_LAB_AGENT=/tmp/opentelemetry-javaagent-2.10.0.jar
export OTEL_LAB_COLLECTOR=/tmp/otelcol-0.113.0/otelcol
export OTEL_LAB_EVIDENCE=/tmp/play-otel-run-1
python3 otel_checks.py
python3 analyze_collector.py "$OTEL_LAB_EVIDENCE"
python3 -m unittest test_collector_parser.py
```

Use a new evidence directory per run. The driver starts only loopback listeners and its own three application processes. The protobuf proxy forwards real requests to the official Collector; it is not an OTLP decoder or replacement receiver. Collector debug output is the decoded-span evidence. Agent, disabled, and failed-export modes execute the same business endpoint. Two stream requests are closed at TCP after reading data. All owned processes are stopped in finally blocks.

The observed automatic scopes include Pekko HTTP, Play MVC and Play WS on this frozen combination. Muzzle build coordinates are not a runtime Maven-group switch. Manual `manual.ws` is INTERNAL and its automatic child is CLIENT: these are two spans for one downstream business call. Collector HTTP 200 is neither durable storage nor business commit proof.

Compile the complete API-only example against the staged API and context jars:

```sh
export OTEL_API_CP="$(printf '%s:' target/universal/stage/lib/io.opentelemetry.opentelemetry-{api,context}-1.44.1.jar)"
"$JAVA_HOME/bin/javac" -cp "$OTEL_API_CP" -d writing writing/ContextAcrossThread.java
"$JAVA_HOME/bin/java" -cp "writing:$OTEL_API_CP" ContextAcrossThread
```

Expected: `workerContext=matched callerContext=restored`. No database, persistence backend, load ranking, agent queue-drop count or production shutdown under saturation is claimed. The stored isolated evidence and later integrated replay are separate runs with distinct trace IDs and timestamps.
