import org.junit.Test;
import static org.junit.Assert.*;
import io.opentelemetry.api.trace.*;
import io.opentelemetry.context.*;
import io.opentelemetry.sdk.trace.*;
import io.opentelemetry.sdk.trace.export.*;
import io.opentelemetry.sdk.testing.exporter.InMemorySpanExporter;
import io.opentelemetry.sdk.common.CompletableResultCode;
import io.opentelemetry.sdk.trace.data.SpanData;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.time.Duration;

public class TelemetryTest {
    @Test public void explicitContextMakesChildAcrossExecutor() throws Exception {
        var exporter=InMemorySpanExporter.create();
        try(var provider=SdkTracerProvider.builder().addSpanProcessor(SimpleSpanProcessor.create(exporter)).build()) {
            Tracer tracer=provider.get("test");
            Span parent=tracer.spanBuilder("parent").startSpan();
            Context context=Context.root().with(parent);
            var executor=Executors.newSingleThreadExecutor();
            try {
                executor.submit(context.wrap(()->{Span child=tracer.spanBuilder("child").startSpan();child.end();})).get(2,TimeUnit.SECONDS);
                parent.end();
                var spans=exporter.getFinishedSpanItems();
                var child=spans.stream().filter(s->s.getName().equals("child")).findFirst().orElseThrow();
                assertEquals(parent.getSpanContext().getSpanId(),child.getParentSpanId());
                assertEquals(parent.getSpanContext().getTraceId(),child.getTraceId());
            }finally {executor.shutdownNow();assertTrue(executor.awaitTermination(2,TimeUnit.SECONDS));}
        }
    }
    @Test public void boundedProcessorDropsWithoutBlockingBusiness() throws Exception {
        CountDownLatch first=new CountDownLatch(1);
        CompletableResultCode gate=new CompletableResultCode();
        AtomicInteger exported=new AtomicInteger();
        SpanExporter sink=new SpanExporter(){
            public CompletableResultCode export(Collection<SpanData> spans){
                exported.addAndGet(spans.size());first.countDown();return gate;
            }
            public CompletableResultCode flush(){return CompletableResultCode.ofSuccess();}
            public CompletableResultCode shutdown(){return CompletableResultCode.ofSuccess();}
        };
        var processor=BatchSpanProcessor.builder(sink).setMaxQueueSize(16).setMaxExportBatchSize(1)
            .setScheduleDelay(Duration.ofMillis(1)).setExporterTimeout(Duration.ofSeconds(5)).build();
        var provider=SdkTracerProvider.builder().addSpanProcessor(processor).build();
        try {
            var tracer=provider.get("queue-test");
            tracer.spanBuilder("block").startSpan().end();
            assertTrue(first.await(2,TimeUnit.SECONDS));
            for(int i=0;i<100;i++)tracer.spanBuilder("finite-"+i).startSpan().end();
            assertEquals(1,exported.get());
            gate.succeed();
            assertTrue(provider.forceFlush().join(3,TimeUnit.SECONDS).isSuccess());
            assertTrue(exported.get()>1);
            assertTrue("Queue bound must drop some of 101 spans",exported.get()<=17);
            System.out.println("queueScenario produced=101 exported="+exported.get()+" dropped="+(101-exported.get()));
        }finally {gate.succeed();assertTrue(provider.shutdown().join(3,TimeUnit.SECONDS).isSuccess());}
    }
}
