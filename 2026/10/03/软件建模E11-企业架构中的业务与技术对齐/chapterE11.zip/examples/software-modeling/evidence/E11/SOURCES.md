# E11 primary source reading

Read 2026-10-03. Source content supports definitions only; scenario results come from local raw run logs.

https://www.opengroup.org/togaf-standard-10th-edition-downloads | Official fixed10th edition entry read.
https://help.opengroup.org/hc/en-us/articles/32115987894930-How-the-ArchiMate-Language-and-the-TOGAF-Standard-Complement-Each-Other | Official method/language relation read.
https://www.opengroup.org.cn/sites/default/files/N221C_%E6%97%A0%E6%B0%B4%E5%8D%B0%E7%89%88.pdf | Official Chinese ArchiMate3.2 reference cards©2022N221, relation page1 and application page7 inspected.
https://pubs.opengroup.org/architecture/archimate32-doc/ | Redirected login; complete normative rule matrix NOT_READ.
https://zachman-feac.com/zachman/about-the-zachman-framework | Official concise2008 definition and six questions/reification rows read; no reproduced copyrighted frameworkgraphic.

No source is used as proof of unexecuted enterprise deployment. Framework details are paraphrased within read scope; local cases and constraints are explicitly teaching assumptions.
