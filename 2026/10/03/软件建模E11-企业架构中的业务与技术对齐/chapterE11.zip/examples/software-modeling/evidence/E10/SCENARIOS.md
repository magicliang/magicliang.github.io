# E10 run matrix

normal: exit0, actual E09/38 HTTP and PASS E10; invalid-concern: exit1 stakeholder concern has no viewpoint; invalid-boundary: exit1 cross-view boundary contradiction.

Each scenario has COMMAND/STDOUT/STDERR/EXIT files under this directory. Expected negative exit is1, not a success result. Empty stderr in successful run is expected. Environment captured in environment.txt. ISO42010:2022 public abstract only; no standard conformance. SEI official Views and Beyond second-edition description and arc42 official12sections.


New independent mutant: invalid-recovery-evidence exits1 capability has no verified runtime evidence. Concern-to-runtime-capability mapping rejects HTTP success as restart proof. Restart remains NOT_RUN.
