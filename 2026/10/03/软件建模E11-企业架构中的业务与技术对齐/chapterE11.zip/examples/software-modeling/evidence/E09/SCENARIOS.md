# E09 run matrix

normal: exit0, RESULT chapter38 checks=10 and PASS E09; invalid-boundary: exit1 false deployment boundary; invalid-owner: exit1 contradictory ownership; invalid-path: exit1 HTTP request path contradicts trace; invalid-source: exit1 missing source.

Each scenario has COMMAND/STDOUT/STDERR/EXIT files under this directory. Expected negative exit is1, not a success result. Empty stderr in successful run is expected. Environment captured in environment.txt. Same-JVM real HttpClient/HttpServer, four stable element identities; no database node or client process.


New independent mutants: invalid-c4-layer exits1 C4 abstraction layer mismatch; invalid-c4-reference exits1 unknown C4 containment endpoint. C4 Person/SoftwareSystem/Container/Component identities and system-container-component containment are enforced.
