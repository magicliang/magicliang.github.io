# E10 primary source reading

Read 2026-10-03. Source content supports definitions only; scenario results come from local raw run logs.

https://www.iso.org/standard/74393.html | Official abstract read; paid normative全文NOT_READ.
https://www.sei.cmu.edu/library/documenting-software-architectures-views-and-beyond-second-edition/ | Official authors and book description read, not fullbook.
https://www.sei.cmu.edu/training/documenting-software-architectures/ | Stakeholder/view selection description read.
https://arc42.org/overview/ | Official12chapter structure read.

No source is used as proof of unexecuted enterprise deployment. Framework details are paraphrased within read scope; local cases and constraints are explicitly teaching assumptions.
