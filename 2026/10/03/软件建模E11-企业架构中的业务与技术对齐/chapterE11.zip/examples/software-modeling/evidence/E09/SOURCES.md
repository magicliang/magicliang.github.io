# E09 primary source reading

Read 2026-10-03. Source content supports definitions only; scenario results come from local raw run logs.

https://www.cs.ubc.ca/~gregor/teaching/papers/4%2B1view-architecture.pdf | Kruchten original1995, pages1–5 read; four views and scenarios.
https://c4model.com/diagrams | Official diagram levels read; levels are not one-to-one 4+1 views.

No source is used as proof of unexecuted enterprise deployment. Framework details are paraphrased within read scope; local cases and constraints are explicitly teaching assumptions.
