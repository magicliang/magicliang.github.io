# E11 run matrix

normal: exit0, PASS E11 typed-relations=9 migration-steps=4; invalid-type: exit1 invalid typed relationship; invalid-order: exit1 migration order violates dependency; invalid-reference: exit1 unknown relationship endpoint; invalid-claim: exit1 unverified deployment presented as real.

Each scenario has COMMAND/STDOUT/STDERR/EXIT files under this directory. Expected negative exit is1, not a success result. Empty stderr in successful run is expected. Environment captured in environment.txt. TOGAF10th, ArchiMate3.2 selected type subset, Zachman2008 concise definition. Target rental/maintenance/settlement deployment all NOT_RUN.
