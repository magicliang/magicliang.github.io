#!/usr/bin/env bash
set -euo pipefail
python3 "$(dirname "$0")/../10/process-run.py" 13 "$@"
