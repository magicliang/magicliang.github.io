package enterprise.chapter13;
import enterprise.sql.Sql;
import enterprise.sql.Check;
import java.nio.file.Path;
import java.sql.SQLException;

public final class Lab13 {
    private Lab13() { }
    public record State(int version,int days,String status) { }
    public record Event(int version,String eventId,String kind,int format,int days) { }
    private static State evolve(State state,Event event) {
        if(event.version()!=state.version()+1) throw new IllegalArgumentException("stream gap");
        if(event.format()!=1 && event.format()!=2) throw new IllegalArgumentException("format");
        return switch(event.kind()) {
            case "CREATED" -> new State(event.version(),(event.format()==1?event.days()/24:event.days()),"ACTIVE");
            case "EXTENDED" -> new State(event.version(),state.days()+event.days(),state.status());
            case "CANCELLED" -> new State(event.version(),state.days(),"CANCELLED");
            default -> throw new IllegalArgumentException("kind");
        };
    }
    private static State replay(Sql db,State initial) throws Exception {
        State state=initial;
        for(var event:db.query("SELECT version,event_id,kind,format,days FROM events WHERE version>? ORDER BY version",r->new Event(r.getInt(1),r.getString(2),r.getString(3),r.getInt(4),r.getInt(5)),initial.version())) state=evolve(state,event);
        return state;
    }
    private static void append(Sql db,int expected,String id,String kind,int format,int days) throws Exception {
        if(db.update("UPDATE stream_head SET version=version+1 WHERE version=?",expected)!=1) { db.rollback(); throw new IllegalStateException("append conflict"); }
        db.update("INSERT INTO events VALUES(?,?,?,?,?)",expected+1,id,kind,format,days); db.commit();
    }
    public static void main(String[] args) throws Exception {
        String url="jdbc:h2:"+Path.of(args[0]).toAbsolutePath();
        try(Sql db=Sql.open(url)) {
            switch(args[1]) {
                case "write" -> {
                    db.update("CREATE TABLE events(version INT PRIMARY KEY,event_id VARCHAR UNIQUE,kind VARCHAR,format INT,days INT)");
                    db.update("CREATE TABLE stream_head(version INT)"); db.update("INSERT INTO stream_head VALUES(0)");
                    db.update("CREATE TABLE snapshot(version INT,days INT,status VARCHAR)");
                    db.update("CREATE TABLE derived(version INT,days INT,status VARCHAR)");
                    db.update("CREATE TABLE notifications(event_id VARCHAR PRIMARY KEY)"); db.commit();
                    append(db,0,"E1","CREATED",1,48); append(db,1,"E2","EXTENDED",2,3);
                    State atTwo=replay(db,new State(0,0,"NONE")); db.update("INSERT INTO snapshot VALUES(?,?,?)",atTwo.version(),atTwo.days(),atTwo.status()); db.commit();
                    append(db,2,"E3","CANCELLED",2,0);
                    db.update("INSERT INTO notifications VALUES('E3')"); db.commit();
                    Check.that("three persisted events",db.query("SELECT COUNT(*) FROM events",r->r.getInt(1)).getFirst()==3);
                }
                case "replay" -> {
                    db.update("DELETE FROM derived"); db.commit();
                    State full=replay(db,new State(0,0,"NONE"));
                    State snapshot=db.query("SELECT version,days,status FROM snapshot",r->new State(r.getInt(1),r.getInt(2),r.getString(3))).getFirst();
                    Check.that("snapshot suffix equals full replay",full.equals(replay(db,snapshot)));
                    Check.that("old format upcast keeps days",full.equals(new State(3,5,"CANCELLED")));
                    db.update("INSERT INTO derived VALUES(?,?,?)",full.version(),full.days(),full.status()); db.commit();
                    Check.that("replay sends no additional notification",db.query("SELECT COUNT(*) FROM notifications",r->r.getInt(1)).getFirst()==1);
                    try { append(db,1,"E4","EXTENDED",2,1); throw new AssertionError("stale append accepted"); }
                    catch(IllegalStateException expected) { Check.that("stale expected version rejected",true); }
                    try { append(db,3,"E3","CANCELLED",2,0); throw new AssertionError("duplicate accepted"); }
                    catch(SQLException expected) { Check.that("duplicate event SQLSTATE23505",expected.getSQLState().equals("23505")); db.rollback(); }
                    Check.that("duplicate rollback restores head",db.query("SELECT version FROM stream_head",r->r.getInt(1)).getFirst()==3);
                }
                case "race" -> {
                    String race=url+"-race";
                    try(Sql setup=Sql.open(race)) { setup.update("CREATE TABLE stream_head(version INT)"); setup.update("INSERT INTO stream_head VALUES(0)"); setup.update("CREATE TABLE events(version INT PRIMARY KEY,event_id VARCHAR UNIQUE,kind VARCHAR,format INT,days INT)"); setup.commit(); }
                    var ready=new java.util.concurrent.CountDownLatch(2);
                    var go=new java.util.concurrent.CountDownLatch(1);
                    var won=new java.util.concurrent.atomic.AtomicInteger();
                    var rejected=new java.util.concurrent.atomic.AtomicInteger();
                    var failures=new java.util.concurrent.ConcurrentLinkedQueue<Throwable>();
                    Runnable task=()-> { try(Sql independent=Sql.open(race)) {
                        int expected=independent.query("SELECT version FROM stream_head",r->r.getInt(1)).getFirst(); ready.countDown(); go.await();
                        try { append(independent,expected,Thread.currentThread().getName(),"CREATED",2,2); won.incrementAndGet(); }
                        catch(IllegalStateException conflict) { rejected.incrementAndGet(); }
                    } catch(Throwable failure) { failures.add(failure); } };
                    Thread first=new Thread(task,"writer-a"), second=new Thread(task,"writer-b"); first.start(); second.start();
                    if(!ready.await(10,java.util.concurrent.TimeUnit.SECONDS)) throw new AssertionError("writers not ready");
                    go.countDown(); first.join(); second.join();
                    Check.that("concurrent independent connections one append one conflict",failures.isEmpty() && won.get()==1 && rejected.get()==1);
                    try(Sql fresh=Sql.open(race)) { Check.that("race fresh connection exactly one event",fresh.query("SELECT COUNT(*) FROM events",r->r.getInt(1)).getFirst()==1); }
                }
                case "verify" -> {
                    Check.that("restart rebuilt state persisted",db.query("SELECT version,days,status FROM derived",r->new State(r.getInt(1),r.getInt(2),r.getString(3))).getFirst().equals(new State(3,5,"CANCELLED")));
                    Check.that("restart events and notifications unchanged",db.query("SELECT COUNT(*) FROM events",r->r.getInt(1)).getFirst()==3 && db.query("SELECT COUNT(*) FROM notifications",r->r.getInt(1)).getFirst()==1);
                }
                default -> throw new IllegalArgumentException("mode");
            }
        }
        Check.result("13 "+args[1]);
    }
}
