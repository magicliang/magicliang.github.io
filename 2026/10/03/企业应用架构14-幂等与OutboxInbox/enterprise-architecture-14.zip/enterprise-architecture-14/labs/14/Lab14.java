package enterprise.chapter14;
import enterprise.sql.Sql;
import enterprise.sql.Check;
import java.nio.file.Path;

public final class Lab14 {
    private Lab14() { }
    private static String url(String base,String suffix) { return "jdbc:h2:"+Path.of(base+suffix).toAbsolutePath()+";WRITE_DELAY=0"; }
    private static int count(Sql db,String sql) throws Exception { return db.query(sql,r->r.getInt(1)).getFirst(); }
    private static void crash(String point) { System.out.println("CRASH_AFTER_COMMIT point="+point); System.out.flush(); Runtime.getRuntime().halt(73); }
    private static boolean consume(String receiver,String id,int amount) throws Exception {
        try(Sql db=Sql.open(receiver)) {
            var existing=db.query("SELECT amount FROM inbox WHERE message_id=?",r->r.getInt(1),id);
            if(!existing.isEmpty()) {
                if(existing.getFirst()!=amount) throw new IllegalArgumentException("idempotency key payload conflict");
                System.out.println("DEDUP message="+id); return false;
            }
            db.update("INSERT INTO inbox VALUES(?,?)",id,amount);
            db.update("UPDATE ledger SET amount=amount+?",amount); db.commit(); return true;
        }
    }
    public static void main(String[] args) throws Exception {
        String sender=url(args[0],"-sender"),spool=url(args[0],"-spool"),receiver=url(args[0],"-receiver");
        switch(args[1]) {
            case "init" -> {
                try(Sql db=Sql.open(sender)) { db.update("CREATE TABLE contracts(id VARCHAR PRIMARY KEY,amount INT)"); db.update("CREATE TABLE outbox(message_id VARCHAR PRIMARY KEY,amount INT,sent BOOLEAN)"); db.commit(); }
                try(Sql db=Sql.open(spool)) { db.update("CREATE TABLE queue(delivery_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,message_id VARCHAR,amount INT,acked BOOLEAN)"); db.commit(); }
                try(Sql db=Sql.open(receiver)) { db.update("CREATE TABLE inbox(message_id VARCHAR PRIMARY KEY,amount INT)"); db.update("CREATE TABLE ledger(amount INT)"); db.update("INSERT INTO ledger VALUES(0)"); db.commit(); }
            }
            case "business-crash" -> {
                try(Sql db=Sql.open(sender)) { db.update("INSERT INTO contracts VALUES('R1',25)"); db.update("INSERT INTO outbox VALUES('M1',25,FALSE)"); db.commit(); }
                crash("business-before-publish");
            }
            case "publish-crash", "publish" -> {
                try(Sql db=Sql.open(sender)) {
                    for(var row:db.query("SELECT message_id,amount FROM outbox WHERE sent=FALSE",r->new String[]{r.getString(1),r.getString(2)})) {
                        try(Sql transport=Sql.open(spool)) { transport.update("INSERT INTO queue(message_id,amount,acked) VALUES(?,?,FALSE)",row[0],Integer.valueOf(row[1])); transport.commit(); }
                        if(args[1].equals("publish-crash")) crash("publish-before-outbox-ack");
                        db.update("UPDATE outbox SET sent=TRUE WHERE message_id=?",row[0]); db.commit();
                    }
                }
            }
            case "consume-crash", "consume" -> {
                try(Sql queue=Sql.open(spool)) {
                    for(var row:queue.query("SELECT delivery_id,message_id,amount FROM queue WHERE acked=FALSE ORDER BY delivery_id",r->new String[]{r.getString(1),r.getString(2),r.getString(3)})) {
                        consume(receiver,row[1],Integer.parseInt(row[2]));
                        if(args[1].equals("consume-crash")) crash("consumer-commit-before-queue-ack");
                        queue.update("UPDATE queue SET acked=TRUE WHERE delivery_id=?",Long.valueOf(row[0])); queue.commit();
                    }
                }
            }
            case "after-business" -> {
                try(Sql db=Sql.open(sender)) { Check.that("restart contract and pending outbox atomic",count(db,"SELECT COUNT(*) FROM contracts")==1 && count(db,"SELECT COUNT(*) FROM outbox WHERE sent=FALSE")==1); }
                try(Sql db=Sql.open(spool)) { Check.that("no publish before crash",count(db,"SELECT COUNT(*) FROM queue")==0); }
            }
            case "after-publish" -> {
                try(Sql db=Sql.open(sender)) { Check.that("outbox still pending before ack",count(db,"SELECT COUNT(*) FROM outbox WHERE sent=FALSE")==1); }
                try(Sql db=Sql.open(spool)) { Check.that("one durable delivery before retry",count(db,"SELECT COUNT(*) FROM queue")==1); }
            }
            case "after-consume" -> {
                try(Sql db=Sql.open(receiver)) { Check.that("consumer committed inbox and ledger before ack",count(db,"SELECT COUNT(*) FROM inbox")==1 && count(db,"SELECT amount FROM ledger")==25); }
                try(Sql db=Sql.open(spool)) { Check.that("two physical deliveries still unacked",count(db,"SELECT COUNT(*) FROM queue WHERE acked=FALSE")==2); }
            }
            case "conflict" -> consume(receiver,"M1",99);
            case "verify" -> {
                try(Sql db=Sql.open(sender)) { Check.that("restart outbox complete",count(db,"SELECT COUNT(*) FROM outbox WHERE sent=TRUE")==1); }
                try(Sql db=Sql.open(spool)) { Check.that("two delivery attempts acknowledged",count(db,"SELECT COUNT(*) FROM queue WHERE acked=TRUE")==2); }
                try(Sql db=Sql.open(receiver)) { Check.that("one inbox one monetary effect despite duplicate deliveries",count(db,"SELECT COUNT(*) FROM inbox")==1 && count(db,"SELECT amount FROM ledger")==25); }
            }
            default -> throw new IllegalArgumentException("mode");
        }
        Check.result("14 "+args[1]);
    }
}
