# Chapter 14 execution receipt

Invocation: `bash run-lab.sh 14` with Java21, Python3 and H2 pinned by sql-support/v1/h2.json.

Every stage launches a separate JVM. Exact actual commands/exit codes: processes.json. Top-level exit0: normal.stdout.txt / normal.stderr.txt.

|Scenario|Binary observable|Captured artifact|
|---|---|---|
|business-crash / after-business|halt73 after commit; new JVM contract1 and pending outbox1, queue0|business-crash.stdout.txt;after-business.stdout.txt|
|publish-crash / after-publish|halt73 after spool commit; new JVM pending1 and queue1|publish-crash.stdout.txt;after-publish.stdout.txt|
|publish / consume-crash / after-consume|duplicate publish; halt73 after inbox+ledger commit; new JVM inbox1 ledger25 queue-unacked2|consume-crash.stdout.txt;after-consume.stdout.txt|
|consume / conflict / verify|retry dedups; changed payload exits1; new JVM outbox-sent1 queue-acked2 inbox1 ledger25|consume.stdout.txt;conflict.stderr.txt;verify.stdout.txt|

Limits: local H2 file persistence under process exit, not power loss or production database. Simplified teaching model, frozen27 baseline unchanged. No production throughput inference.
Transport is actual persisted SQL spool, not a message broker. Single publisher and single consumer. No claim of globally exactly-once delivery or concurrent-consumer coverage. halt73 occurs only after commit returns.
