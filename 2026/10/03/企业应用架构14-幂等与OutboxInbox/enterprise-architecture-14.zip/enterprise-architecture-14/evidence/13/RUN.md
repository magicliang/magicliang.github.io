# Chapter 13 execution receipt

Invocation: `bash run-lab.sh 13` with Java21, Python3 and H2 pinned by sql-support/v1/h2.json.

Every stage launches a separate JVM. Exact actual commands/exit codes: processes.json. Top-level exit0: normal.stdout.txt / normal.stderr.txt.

|Scenario|Binary observable|Captured artifact|
|---|---|---|
|write|three events persisted|write.stdout.txt|
|replay|full state(3,5,CANCELLED)=snapshot suffix, notifications1, stale rejection, unique23505 and head3|replay.stdout.txt|
|race|two independent connections read same version; exactly one append, one conflict|race.stdout.txt|
|verify|new JVM state(3,5,CANCELLED), events3, notifications1|verify.stdout.txt|

Limits: local H2 file persistence under process exit, not power loss or production database. Simplified teaching model, frozen27 baseline unchanged. No production throughput inference.
Old-format sample48 hours upcasts to2 days; nonintegral day migration not covered. notifications table is effect counter, not actual external notification delivery.
