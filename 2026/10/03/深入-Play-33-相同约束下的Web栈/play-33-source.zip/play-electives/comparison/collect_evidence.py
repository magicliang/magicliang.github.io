#!/usr/bin/env python3
import hashlib,json,pathlib,zipfile
root=pathlib.Path(__file__).resolve().parent
import os
evidence=pathlib.Path(os.environ["CMP_EVIDENCE_ROOT"])
post=pathlib.Path(os.environ["CMP_REPO_ROOT"])/"source/_posts/2026-10-03-深入-Play-33-相同约束下的Web栈.md"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sources=[]
for p in root.rglob("*"):
    if not p.is_file() or any(x in p.parts for x in ("target",".bsp",".idea",".settings","__pycache__")):continue
    if p.name in (".classpath",".project"):continue
    if p.name in ("article-draft.md","ResponseIsNotCommit.class"):continue
    sources.append(dict(source=str(p),destination="examples/play-electives/comparison/"+str(p.relative_to(root)),sha256=sha(p)))
assert len({sha(root/k/("app/comparison/Kernel.java" if k=="play" else "src/main/java/comparison/Kernel.java")) for k in ("play","mvc","webflux")})==1
bytechecks=[]
for kind in ("play","mvc","webflux"):
    if kind=="play":
        jar=next((root/kind/"target/universal/stage/lib").glob("*comparison-play*.jar"))
        prefix="";classes=root/kind/"target/scala-2.13/classes"
    else:
        jar=root/kind/"target"/("comparison-"+kind+"-0.1.0.jar")
        prefix="BOOT-INF/classes/";classes=root/kind/"target/classes"
    with zipfile.ZipFile(jar) as z:
        for name in ("comparison/Kernel.class","comparison/Kernel$Reply.class"):
            expected=(classes/name).read_bytes()
            assert z.read(prefix+name)==expected
            bytechecks.append(dict(kind=kind,name=name,sha256=hashlib.sha256(expected).hexdigest(),artifact=jar.name))
summary=json.loads((evidence/"run-final/summary.json").read_text())
assert summary==dict(status="PASS",cells=18,requests=396,checks=69),summary
assert (evidence/"java-example.log").read_text().strip()=="response=504 committed=1"
assert json.loads((evidence/"anti-ai-tone-final.json").read_text())["errors"]==0
assert not json.loads((evidence/"anti-persona-final.json").read_text())["findings"]
for k in ("play","mvc","webflux"):
    log=(evidence/(k+"-build-final.log")).read_text()
    assert ("BUILD SUCCESS" in log if k!="play" else log.count("[success]")>=2)
data=dict(status="PASS",sources=sources,productionClassChecks=bytechecks,summary=summary,post=dict(path=str(post),sha256=sha(post)),
          evidenceDestination="examples/play-electives/evidence/comparison/isolated",boundaries=["No JUnit tests; real HTTP/SQL integration assertions","Idle SIGTERM only","No browser/page acceptance in this isolated lane"])
(evidence/"integration-manifest.json").write_text(json.dumps(data,indent=2)+"\n")
print(json.dumps(dict(status="PASS",sources=len(sources),classes=len(bytechecks),checks=69,postSha256=sha(post))))
