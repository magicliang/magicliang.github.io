package comparison;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.sql.*;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public final class Kernel implements AutoCloseable {
    public record Reply(int status, Map<String,Object> body) {}
    private final HikariDataSource pool;
    private final ThreadPoolExecutor workers;
    private final ScheduledExecutorService clock = Executors.newSingleThreadScheduledExecutor();
    private final HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build();
    private final AtomicInteger completed = new AtomicInteger();
    private final String downstream = System.getenv("CMP_DOWNSTREAM");
    private volatile boolean accepting = true;

    public Kernel() throws Exception {
        String schema = System.getenv("CMP_SCHEMA");
        if (schema == null || !schema.matches("cmp_[a-z0-9_]+")) throw new IllegalArgumentException("CMP_SCHEMA");
        HikariConfig cfg = new HikariConfig();
        cfg.setJdbcUrl(System.getenv("CMP_JDBC_URL"));
        cfg.setUsername("postgres");
        cfg.setPassword("lab-only-password");
        cfg.setMaximumPoolSize(2);
        cfg.setMinimumIdle(2);
        cfg.setConnectionTimeout(2000);
        cfg.setSchema(schema);
        cfg.addDataSourceProperty("ApplicationName",schema);
        pool = new HikariDataSource(cfg);
        try (Connection c = pool.getConnection(); Statement s = c.createStatement()) {
            s.execute("CREATE SCHEMA " + schema);
            s.execute("CREATE TABLE " + schema + ".stock (id int PRIMARY KEY, quantity int NOT NULL CHECK(quantity>=0))");
            s.execute("INSERT INTO " + schema + ".stock VALUES(1,1000)");
            s.execute("CREATE TABLE " + schema + ".orders (key text PRIMARY KEY, payload text NOT NULL)");
        }
        workers = new ThreadPoolExecutor(2,2,0,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<>(16),
            r -> new Thread(r,"business-worker"),new ThreadPoolExecutor.AbortPolicy());
    }
    public static Reply reply(int status, String code) { return new Reply(status, Map.of("code",code)); }
    public CompletionStage<Reply> create(String key, String payload, int delay, boolean fail) {
        if (key == null || !key.matches("[a-zA-Z0-9_-]{1,80}") || payload == null) {
            return CompletableFuture.completedFuture(reply(400,"invalid"));
        }
        if (!accepting) return CompletableFuture.completedFuture(reply(503,"stopping"));
        CompletableFuture<Reply> answer = new CompletableFuture<>();
        ScheduledFuture<?> alarm = clock.schedule(() -> answer.complete(reply(504,"budget")),150,TimeUnit.MILLISECONDS);
        try {
            workers.execute(() -> {
                try { answer.complete(transaction(key,payload,delay,fail)); }
                catch (Exception e) { answer.complete(reply(500,"failed")); }
                finally { completed.incrementAndGet(); alarm.cancel(false); }
            });
        } catch (RejectedExecutionException e) { alarm.cancel(false); answer.complete(reply(503,"capacity")); }
        return answer;
    }
    private Reply transaction(String key, String payload, int delay, boolean fail) throws Exception {
        try (Connection c = pool.getConnection()) {
            c.setAutoCommit(false);
            try {
                try (PreparedStatement q=c.prepareStatement("SELECT pg_advisory_xact_lock(hashtext(?))")) {
                    q.setString(1,key); q.execute();
                }
                try (PreparedStatement q=c.prepareStatement("SELECT payload FROM orders WHERE key=?")) {
                    q.setString(1,key);
                    try (ResultSet r=q.executeQuery()) {
                        if (r.next()) { boolean same=payload.equals(r.getString(1)); c.commit(); return reply(same?200:409,same?"existing":"conflict"); }
                    }
                }
                try (Statement q=c.createStatement(); ResultSet r=q.executeQuery("SELECT quantity FROM stock WHERE id=1 FOR UPDATE")) {
                    r.next(); if(r.getInt(1)==0) { c.rollback(); return reply(409,"stock"); }
                }
                try (PreparedStatement q=c.prepareStatement("SELECT pg_sleep(?)")) {
                    q.setDouble(1,delay/1000.0); q.execute();
                }
                client.send(HttpRequest.newBuilder(URI.create(downstream)).timeout(Duration.ofSeconds(2)).GET().build(),HttpResponse.BodyHandlers.discarding());
                try (PreparedStatement q=c.prepareStatement("INSERT INTO orders VALUES(?,?)")) {
                    q.setString(1,key); q.setString(2,payload); q.executeUpdate();
                }
                try (Statement q=c.createStatement()) { q.executeUpdate("UPDATE stock SET quantity=quantity-1 WHERE id=1"); }
                if(fail) throw new SQLException("injected rollback");
                c.commit(); return reply(200,"created");
            } catch (Exception e) { c.rollback(); throw e; }
        }
    }
    public CompletionStage<Reply> get(String key) {
        return CompletableFuture.supplyAsync(() -> {
            try { return read(key); } catch(Exception e) {return reply(500,"failed");}
        },workers);
    }
    private Reply read(String key) throws Exception {
        try(Connection c=pool.getConnection();PreparedStatement q=c.prepareStatement("SELECT payload FROM orders WHERE key=?")) {
            q.setString(1,key);try(ResultSet r=q.executeQuery()) { return r.next()?new Reply(200,Map.of("payload",r.getString(1))):reply(404,"missing"); }
        }
    }
    public Reply state() { return new Reply(200,Map.of("active",workers.getActiveCount(),"queued",workers.getQueue().size(),
        "completed",completed.get(),"poolActive",pool.getHikariPoolMXBean().getActiveConnections(),"poolTotal",pool.getHikariPoolMXBean().getTotalConnections())); }
    public void close() throws Exception {
        accepting=false; workers.shutdown();
        boolean drained=workers.awaitTermination(8,TimeUnit.SECONDS);
        clock.shutdownNow(); client.close(); pool.close();
        Files.writeString(Path.of(System.getenv("CMP_JOURNAL")),"drained="+drained+";workers="+workers.isTerminated()+";clock="+clock.isShutdown()+";pool="+pool.isClosed()+";client="+client.isTerminated());
    }
}
