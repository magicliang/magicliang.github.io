# Same constraints, three HTTP stacks

Java 21 is required. Play is fixed to 3.0.6 / Scala 2.13.15 / sbt 1.10.7; MVC and WebFlux use Boot 3.3.6. All three copies of Kernel.java must remain byte-identical. HikariCP is explicitly fixed to 5.1.0 and PostgreSQL JDBC to 42.7.5.

Use a local PostgreSQL 17.6 fixture with database play_lab, user postgres and synthetic password lab-only-password. The harness creates a fresh cmp_* schema for each process; it does not stop the fixture or delete schemas. Never point this demo at production.

From the comparison directory, build each app:

```bash
export JAVA_HOME=/path/to/jdk-21
curl -fsSL https://repo.maven.apache.org/maven2/org/scala-sbt/sbt-launch/1.10.7/sbt-launch-1.10.7.jar -o /tmp/comparison-sbt-launch-1.10.7.jar
(cd play && "$JAVA_HOME/bin/java" -Dsbt.supershell=false -jar /tmp/comparison-sbt-launch-1.10.7.jar test stage)
(cd mvc && mvn -B package)
(cd webflux && mvn -B package)
```

These projects have no JUnit tests. Real contract assertions live in comparison_checks.py. Stage/package proves compilation and packaging, not behavior.

Run the finite HTTP/SQL matrix:

```bash
export CMP_JDBC_URL='jdbc:postgresql://127.0.0.1:5432/play_lab?connectTimeout=3&socketTimeout=5'
export CMP_CONTAINER=play-comparison-db
export PODMAN=podman
export CMP_EVIDENCE="$PWD/evidence"
python3 comparison_checks.py
```

The fixture must be the container named CMP_CONTAINER so the independent SQL observer reaches the same database as JDBC. Python 3.9+ is required. JAVA_HOME controls staged Play and Boot JVMs. Each process binds to a random loopback port. A shared local HTTP server injects 20 ms delay. Build artifacts must exist before running.

18 finite cells contain 396 measured requests plus warmups and fault scenarios. There are only 2 worker threads / 16 queue slots / 2 database connections per app. MVC waits synchronously at its chosen handler; MVC also supports async handlers, which this combination does not measure. WebFlux and Play return asynchronously but both run blocking JDBC and JDK HttpClient calls on the same bounded business executor.

150 ms outer response timeout does not cancel SQL or queued work. Assertions verify late writes through independent psql and retry idempotency. A 32-request bounded burst tests capacity rejection without writes. SIGTERM is tested after business work drains; in-flight SIGTERM and SIGKILL are not covered. Results are finite observations, not a general performance ranking.

Evidence includes summary.json, cells.json, checks.json, sql.json, server logs and per-process cleanup journals. The driver preserves a failure result and stops its own application processes in finally. It never stops PostgreSQL.

Compile and run the explanatory Java example:

```bash
"$JAVA_HOME/bin/javac" -d writing writing/ResponseIsNotCommit.java
"$JAVA_HOME/bin/java" -cp writing ResponseIsNotCommit
```

