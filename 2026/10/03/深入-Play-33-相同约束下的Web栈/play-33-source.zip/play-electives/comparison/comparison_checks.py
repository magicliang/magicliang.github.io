#!/usr/bin/env python3
"""Finite, loopback-only comparison; requires JAVA_HOME and an existing PostgreSQL fixture."""
import concurrent.futures as futures
import hashlib, http.server, json, os, pathlib, socket, statistics, subprocess, threading, time, urllib.request, urllib.error, urllib.parse, uuid, zipfile, io

ROOT=pathlib.Path(__file__).resolve().parent
EVIDENCE=pathlib.Path(os.environ["CMP_EVIDENCE"]).resolve()
EVIDENCE.mkdir(parents=True,exist_ok=True)
JAVA=pathlib.Path(os.environ["JAVA_HOME"])/"bin/java"
CONTAINER=os.environ.get("CMP_CONTAINER","play-comparison-db")
PODMAN=os.environ.get("PODMAN","podman")
JDBC=os.environ.get("CMP_JDBC_URL","jdbc:postgresql://127.0.0.1:5432/play_lab?connectTimeout=3&socketTimeout=5")
rows=[]; checks=[]; sql_rows=[]; current=None; processes=[]
class Slow(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        time.sleep(.02); self.send_response(200); self.end_headers(); self.wfile.write(b"ok")
    def log_message(self,*args): pass
slow=http.server.ThreadingHTTPServer(("127.0.0.1",0),Slow)
threading.Thread(target=slow.serve_forever,daemon=True).start()
def port():
    with socket.socket() as s:s.bind(("127.0.0.1",0));return s.getsockname()[1]
def sql(schema,query):
    p=subprocess.run([PODMAN,"exec",CONTAINER,"psql","-U","postgres","-d","play_lab","-Atc","SET search_path TO "+schema+"; "+query],capture_output=True,text=True,check=True)
    value=p.stdout.strip().splitlines()[-1]
    sql_rows.append(dict(schema=schema,query=query,value=value))
    return value
def request(base,path,method="GET"):
    start=time.perf_counter()
    try:
        with urllib.request.urlopen(urllib.request.Request(base+path,method=method),timeout=8) as r: status=r.status; body=r.read().decode()
    except urllib.error.HTTPError as e:status=e.code;body=e.read().decode()
    return dict(status=status,body=body,millis=(time.perf_counter()-start)*1000)
def order(base,key,payload="a",delay=0,fail=False):
    return request(base,"/orders?"+urllib.parse.urlencode(dict(key=key,payload=payload,delay=delay,fail=str(fail).lower())),"POST")
def assert_check(name,condition,**data):
    checks.append(dict(name=name,passed=bool(condition),**data))
    assert condition,(name,data)
def idle(base):
    for _ in range(100):
        s=json.loads(request(base,"/state")["body"])
        if s["active"]==s["queued"]==0:return
        time.sleep(.1)
    raise AssertionError("workers not idle")
try:
    for kind in ("play","mvc","webflux"):
        schema="cmp_"+kind+"_"+uuid.uuid4().hex[:8]
        p=port();base="http://127.0.0.1:"+str(p);journal=EVIDENCE/(kind+"-cleanup.txt")
        env=os.environ|dict(CMP_SCHEMA=schema,CMP_JDBC_URL=JDBC,CMP_JOURNAL=str(journal),CMP_DOWNSTREAM="http://127.0.0.1:"+str(slow.server_port),APPLICATION_SECRET=uuid.uuid4().hex+uuid.uuid4().hex)
        if kind=="play":
            command=[str(ROOT/kind/"target/universal/stage/bin/comparison-play"),"-Dhttp.port="+str(p),"-Dhttp.address=127.0.0.1","-Dpidfile.path=/dev/null"]
        else:command=[str(JAVA),"-jar",str(ROOT/kind/"target"/("comparison-"+kind+"-0.1.0.jar")),"--server.port="+str(p),"--server.address=127.0.0.1","--server.shutdown=graceful","--spring.lifecycle.timeout-per-shutdown-phase=10s"]
        log=open(EVIDENCE/(kind+"-server.log"),"w")
        current=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,cwd=ROOT/kind)
        processes.append((current,log))
        for _ in range(300):
            if current.poll() is not None:raise AssertionError((kind,"startup",current.returncode))
            try:
                if request(base,"/ready")["status"]==200:break
            except (OSError,urllib.error.URLError):pass
            time.sleep(.1)
        else:raise AssertionError("startup timeout")
        # Warm database/JIT/client before the finite measurement cells.
        for i in range(8):order(base,"warm"+str(i))
        idle(base)
        for round_no in range(3):
            for concurrency,count in ((1,12),(8,32)):
                started=time.perf_counter()
                with futures.ThreadPoolExecutor(max_workers=concurrency) as executor:
                    result=list(executor.map(lambda n:order(base,f"r{round_no}c{concurrency}n{n}"),range(count)))
                elapsed=time.perf_counter()-started
                idle(base)
                times=sorted(r["millis"] for r in result)
                rows.append(dict(kind=kind,round=round_no,concurrency=concurrency,count=count,elapsed=elapsed,p50=statistics.median(times),p95=times[int(.95*(len(times)-1))],statusCounts={str(s):sum(r["status"]==s for r in result) for s in sorted(set(r["status"] for r in result))},responses=result))
                assert_check(kind+" finite cell",all((r["status"],json.loads(r["body"])["code"]) in ((200,"created"),(504,"budget"),(503,"capacity")) for r in result),round=round_no,concurrency=concurrency)
                committed=int(sql(schema,"SELECT count(*) FROM orders WHERE key LIKE 'r"+str(round_no)+"c"+str(concurrency)+"n%'"))
                assert_check(kind+" finite admitted commits",committed==sum(r["status"]!=503 for r in result),committed=committed)
        with futures.ThreadPoolExecutor(max_workers=32) as executor:
            saturation=list(executor.map(lambda n:order(base,"burst"+str(n),delay=200),range(32)))
        idle(base)
        rejected=sum(r["status"]==503 for r in saturation)
        assert_check(kind+" capacity saturation",rejected>0 and all(r["status"] in (503,504) for r in saturation),rejected=rejected,responses=saturation)
        assert_check(kind+" capacity no write",int(sql(schema,"SELECT count(*) FROM orders WHERE key LIKE 'burst%'"))==32-rejected)
        state=json.loads(request(base,"/state")["body"])
        assert_check(kind+" fixed pool",state["poolTotal"]==2 and state["poolActive"]==0,state=state)
        with futures.ThreadPoolExecutor(max_workers=4) as executor:
            conflict=list(executor.map(lambda x:order(base,"same-key",x),["a","a","b","b"]))
        idle(base)
        assert_check(kind+" conflict",sorted(r["status"] for r in conflict)==[200,200,409,409],responses=conflict)
        assert_check(kind+" single row",sql(schema,"SELECT count(*) FROM orders WHERE key='same-key'")=="1")
        before=int(sql(schema,"SELECT quantity FROM stock WHERE id=1"))
        rollback=order(base,"rollback",fail=True);idle(base)
        assert_check(kind+" rollback",rollback["status"]==500 and sql(schema,"SELECT count(*) FROM orders WHERE key='rollback'")=="0" and int(sql(schema,"SELECT quantity FROM stock WHERE id=1"))==before,response=rollback)
        late=order(base,"late",delay=400)
        early=sql(schema,"SELECT count(*) FROM orders WHERE key='late'")
        idle(base);after=sql(schema,"SELECT count(*) FROM orders WHERE key='late'")
        retry=order(base,"late")
        assert_check(kind+" late commit",late["status"]==504 and early=="0" and after=="1" and retry["status"]==200,timeout=late,early=early,after=after,retry=retry)
        assert_check(kind+" stock invariant",sql(schema,"SELECT (SELECT quantity FROM stock)+(SELECT count(*) FROM orders)")=="1000")
        current.terminate();exit_code=current.wait(timeout=15);log.close();current=None
        cleanup=journal.read_text()
        assert_check(kind+" shutdown",all(x in cleanup for x in ["drained=true","workers=true","clock=true","pool=true","client=true"]),exit=exit_code,journal=cleanup)
        try:socket.create_connection(("127.0.0.1",p),timeout=.2).close();closed=False
        except OSError:closed=True
        assert_check(kind+" listener closed",closed)
        assert_check(kind+" database sessions closed",sql(schema,"SELECT count(*) FROM pg_stat_activity WHERE application_name='"+schema+"'")=="0")
    summary=dict(status="PASS",cells=len(rows),requests=sum(r["count"] for r in rows),checks=len(checks))
except BaseException as error:
    summary=dict(status="FAIL",error=repr(error));raise
finally:
    for process,log in processes:
        if process.poll() is None:
            process.terminate()
            try:process.wait(timeout=15)
            except subprocess.TimeoutExpired:process.kill();process.wait()
        log.close()
    slow.shutdown();slow.server_close()
    for name,data in [("summary",summary),("cells",rows),("checks",checks),("sql",sql_rows)]:
        (EVIDENCE/(name+".json")).write_text(json.dumps(data,indent=2)+"\n")
print(json.dumps(summary))
