package comparison;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import reactor.core.publisher.Mono;
@SpringBootApplication
@RestController
public class Application {
    private Kernel kernel;
    @Bean(destroyMethod="close") Kernel kernel() throws Exception {kernel=new Kernel(); return kernel;}
    public static void main(String[] args){SpringApplication.run(Application.class,args);}
    private ResponseEntity<?> result(Kernel.Reply r){return ResponseEntity.status(r.status()).body(r.body());}
    @GetMapping("/ready") String ready(){return "ready";}
    @PostMapping("/orders") Mono<ResponseEntity<?>> create(
        @RequestParam String key,@RequestParam String payload,
        @RequestParam(defaultValue="0") int delay,@RequestParam(defaultValue="false") boolean fail) throws Exception {
        return Mono.fromCompletionStage(kernel.create(key,payload,delay,fail)).map(this::result);
    }
    @GetMapping("/orders/{key}") Mono<ResponseEntity<?>> get(@PathVariable String key) {return Mono.fromCompletionStage(kernel.get(key)).map(this::result);}
    @GetMapping("/state") ResponseEntity<?> state(){return result(kernel.state());}
}
