package controllers;
import comparison.Kernel;
import javax.inject.*;
import play.mvc.*;
import play.libs.Json;
import play.inject.ApplicationLifecycle;
import java.util.concurrent.*;
@Singleton
public final class ComparisonController extends Controller {
    private final Kernel kernel;
    @Inject public ComparisonController(ApplicationLifecycle life) throws Exception {
        kernel=new Kernel();
        life.addStopHook(() -> { try {kernel.close();return CompletableFuture.completedFuture(null);}
            catch(Exception e){return CompletableFuture.failedFuture(e);} });
    }
    private Result result(Kernel.Reply r){return status(r.status(),Json.toJson(r.body()));}
    public Result ready(){return ok("ready");}
    public CompletionStage<Result> create(Http.Request r){
        String delay=r.getQueryString("delay");
        return kernel.create(r.getQueryString("key"),r.getQueryString("payload"),
            delay==null?0:Integer.parseInt(delay),"true".equals(r.getQueryString("fail"))).thenApply(this::result);
    }
    public CompletionStage<Result> get(String key){return kernel.get(key).thenApply(this::result);}
    public Result state(){return result(kernel.state());}
}
