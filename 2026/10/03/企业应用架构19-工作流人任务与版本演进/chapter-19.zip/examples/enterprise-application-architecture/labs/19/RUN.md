# 19：真实工作流、人任务和版本

执行 `bash examples/enterprise-application-architecture/labs/19/run.sh`，最终退出0；追加 `negative` 对不存在任务调用真实TaskService.complete，预期退出1。Java21/Python3及缓存参数见15/RUN.md。

Camunda Engine7.23.0、H2 2.1.214，真实部署`models/19/approval-v1.bpmn`与v2。init启动R1，approve人任务提交后halt73。restart新JVM恢复R1，部署v2并启动R2；R1绑定v1，R2绑定v2。R1完成approve即结束，R2继续等待supervisor。finish第三JVM恢复主管待办、完成，历史2实例/3任务，ACT_RU_TASK为0。

`evidence/19/init.log`包含预期EXIT73；restart.log为版本与等待恢复；finish.log为真实历史API和SQL读回；database-snapshot.sql为引擎数据库导出；run.json索引阶段。negative/保留引擎真实异常与未完待办快照。

API模拟人任务完成，没有Tasklist浏览器或身份认证实验。关闭job executor，因此定时器、后台重试、历史清理未验证；没有规则引擎执行、规则覆盖或实例迁移。plainNext仅比较转换规则，不是另一个完整持久化工作流。临时数据库保留。
