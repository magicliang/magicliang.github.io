package enterprise.chapter19;

import enterprise.sql.Check;
import enterprise.sql.Sql;
import java.nio.file.Files;
import java.nio.file.Path;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.ProcessEngineConfiguration;
import org.camunda.bpm.engine.impl.cfg.ProcessEngineConfigurationImpl;

public final class Lab19 {
    private Lab19() { }
    private static String plainNext(int version, String state) {
        return switch (state) {
            case "approve" -> version == 1 ? "END" : "supervisor";
            case "supervisor" -> "END";
            default -> throw new IllegalArgumentException("unknown state");
        };
    }
    private static void deploy(ProcessEngine engine, Path file) throws Exception {
        try (var input = Files.newInputStream(file)) {
            engine.getRepositoryService().createDeployment().name(file.getFileName().toString()).addInputStream("approval.bpmn", input).deploy();
        }
    }
    public static void main(String[] args) throws Exception {
        String url = "jdbc:h2:" + args[0] + ";WRITE_DELAY=0";
        var configuration = (ProcessEngineConfigurationImpl) ProcessEngineConfiguration.createStandaloneProcessEngineConfiguration();
        configuration.setJdbcUrl(url); configuration.setJdbcUsername("sa"); configuration.setJdbcPassword("");
        configuration.setDatabaseSchemaUpdate("true"); configuration.setJobExecutorActivate(false);
        configuration.setHistory("full"); configuration.setMetricsEnabled(false);
        ProcessEngine engine = configuration.buildProcessEngine();
        try {
            var tasks = engine.getTaskService();
            var runtime = engine.getRuntimeService();
            var repository = engine.getRepositoryService();
            switch (args[2]) {
                case "init" -> {
                    deploy(engine, Path.of(args[1], "approval-v1.bpmn"));
                    var instance = runtime.startProcessInstanceByKey("rentalApproval", "R1");
                    Check.that("real user task waits durably", tasks.createTaskQuery().processInstanceId(instance.getId()).singleResult().getTaskDefinitionKey().equals("approve"));
                    System.out.println("HALT_AFTER_ENGINE_COMMIT instance=" + instance.getId()); System.out.flush(); Runtime.getRuntime().halt(73);
                }
                case "restart" -> {
                    var old = runtime.createProcessInstanceQuery().processInstanceBusinessKey("R1").singleResult();
                    Check.that("new JVM recovers old user task", tasks.createTaskQuery().processInstanceId(old.getId()).count() == 1);
                    deploy(engine, Path.of(args[1], "approval-v2.bpmn"));
                    var newer = runtime.startProcessInstanceByKey("rentalApproval", "R2");
                    Check.that("old instance remains version one", repository.createProcessDefinitionQuery().processDefinitionId(old.getProcessDefinitionId()).singleResult().getVersion() == 1);
                    Check.that("new instance selects version two", repository.createProcessDefinitionQuery().processDefinitionId(newer.getProcessDefinitionId()).singleResult().getVersion() == 2);
                    var oldTask = tasks.createTaskQuery().processInstanceId(old.getId()).singleResult();
                    tasks.complete(oldTask.getId());
                    Check.that("v1 matches plain baseline END", plainNext(1, "approve").equals("END") && runtime.createProcessInstanceQuery().processInstanceId(old.getId()).count() == 0);
                    var newTask = tasks.createTaskQuery().processInstanceId(newer.getId()).singleResult();
                    tasks.complete(newTask.getId());
                    Check.that("v2 matches plain baseline supervisor", tasks.createTaskQuery().processInstanceId(newer.getId()).singleResult().getTaskDefinitionKey().equals(plainNext(2, "approve")));
                    System.out.println("PERSISTED_SUPERVISOR_WAIT business=R2");
                }
                case "finish" -> {
                    var instance = runtime.createProcessInstanceQuery().processInstanceBusinessKey("R2").singleResult();
                    var task = tasks.createTaskQuery().processInstanceId(instance.getId()).singleResult();
                    Check.that("another JVM recovers supervisor wait", task.getTaskDefinitionKey().equals("supervisor") && task.getAssignee().equals("supervisor"));
                    tasks.complete(task.getId());
                    Check.that("v2 reaches END after second human action", plainNext(2, "supervisor").equals("END") && runtime.createProcessInstanceQuery().count() == 0);
                    Check.that("two historic finished instances", engine.getHistoryService().createHistoricProcessInstanceQuery().finished().count() == 2);
                    Check.that("three historic finished user tasks", engine.getHistoryService().createHistoricTaskInstanceQuery().finished().count() == 3);
                    try (Sql db = Sql.open(url)) {
                        Check.that("actual engine task table now empty", db.query("SELECT COUNT(*) FROM ACT_RU_TASK", r -> r.getInt(1)).getFirst() == 0);
                        System.out.println("HISTORY_ROWS " + db.query("SELECT PROC_DEF_ID_,BUSINESS_KEY_,STATE_ FROM ACT_HI_PROCINST ORDER BY BUSINESS_KEY_", r -> r.getString(1) + ":" + r.getString(2) + ":" + r.getString(3)));
                    }
                }
                case "negative" -> tasks.complete("missing-task");
                default -> throw new IllegalArgumentException("mode");
            }
            Check.result("19 " + args[2]);
        } finally { engine.close(); }
    }
}
