package controllers;

import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import lab.Negotiator;
import play.i18n.Lang;
import play.i18n.MessagesApi;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;
import play.twirl.api.Html;

@Singleton
public final class I18nController extends Controller {
    private record Identity(String tenant, String user) {}
    private record Key(String tenant, String user, String language, String media) {}
    private record Representation(String body, String media, String language) {}
    private static final Map<String, Identity> IDENTITIES = Map.of(
            "alice", new Identity("red", "alice"), "carol", new Identity("red", "carol"),
            "bob", new Identity("blue", "bob"));
    private static final String PAYLOAD = "<img src=x onerror=alert(1)>";
    private final MessagesApi messages;
    private final Map<Key, Representation> correct = new ConcurrentHashMap<>();
    private final Map<String, Representation> flawed = new ConcurrentHashMap<>();

    @Inject public I18nController(MessagesApi messages, play.inject.ApplicationLifecycle lifecycle) {
        this.messages = messages;
        lifecycle.addStopHook(() -> {
            correct.clear();
            flawed.clear();
            System.out.println("I18N_CACHE_CLOSED correct=" + correct.size() + " flawed=" + flawed.size());
            return java.util.concurrent.CompletableFuture.completedFuture(null);
        });
    }

    private Result vary(Result result) {
        return result.withHeader("Vary", "Accept, Accept-Language, Cookie")
                .withHeader("Cache-Control", "private, no-store");
    }

    public Result health() { return ok("ready"); }

    public Result identity(String name) {
        if (!IDENTITIES.containsKey(name)) return badRequest("unknown synthetic identity");
        return vary(ok("synthetic identity set").withSession(Map.of("identity", name)));
    }

    public Result language(String code) {
        if (!java.util.Set.of("en", "fr", "zh-CN").contains(code)) return badRequest("unsupported language");
        return vary(messages.setLang(ok("language set"), Lang.forCode(code)));
    }

    public Result probe(Http.Request request) {
        var selected = messages.preferred(request);
        return vary(ok(Json.newObject().put("language", selected.lang().code())
                .put("greeting", selected.at("greeting")).put("fallbackMessage", selected.at("only.default"))
                .put("missingMessage", selected.at("absent.key"))
                .put("acceptsJson", request.accepts("application/json"))
                .put("acceptsHtml", request.accepts("text/html"))));
    }

    public Result stats() { return ok(Json.newObject().put("correctEntries", correct.size()).put("flawedEntries", flawed.size())); }

    public Result document(Http.Request request, String tenant) {
        Identity identity = request.session().getOptional("identity").map(IDENTITIES::get).orElse(null);
        if (identity == null) return vary(unauthorized("signed identity required"));
        if (!identity.tenant().equals(tenant)) return vary(forbidden("tenant mismatch"));
        String media;
        try {
            var accepts = request.getHeaders().getAll("Accept");
            media = Negotiator.choose(accepts.isEmpty() ? null : String.join(",", accepts)).orElse(null);
        } catch (IllegalArgumentException e) {
            return vary(badRequest(e.getMessage()));
        }
        if (media == null) return vary(status(406, "available: application/json, text/html"));
        String transientCode = request.getQueryString("transient");
        if (transientCode != null) {
            if (!java.util.Set.of("en", "fr", "zh-CN").contains(transientCode)) return vary(badRequest("unsupported transient language"));
            request = request.withTransientLang(Lang.forCode(transientCode));
        }
        var selected = messages.preferred(request);
        String language = selected.lang().code();
        var key = new Key(identity.tenant(), identity.user(), language, media);
        var representation = new Representation(media.equals("application/json")
                ? Json.newObject().put("tenant", identity.tenant()).put("user", identity.user())
                    .put("language", language).put("greeting", selected.at("greeting")).toString()
                : views.html.document.render(language, identity.tenant(), identity.user(), selected.at("greeting"),
                    PAYLOAD, new Html("<strong>fixed trusted markup</strong>")).body(), media, language);
        String mode = request.getQueryString("cache");
        Representation result = "bad".equals(mode)
                ? flawed.computeIfAbsent("document", ignored -> representation)
                : correct.computeIfAbsent(key, ignored -> representation);
        return vary(ok(result.body()).as(result.media()).withHeader("Content-Language", result.language()));
    }
}
