package lab;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

public final class Negotiator {
    private static final List<String> OFFERED = List.of("application/json", "text/html");
    private record Range(String type, int quality, int specificity) {
        boolean matches(String offered) {
            return type.equals("*/*") || type.equals(offered)
                    || (type.endsWith("/*") && offered.startsWith(type.substring(0, type.length() - 1)));
        }
    }

    public static Optional<String> choose(String accept) {
        if (accept == null) return Optional.of(OFFERED.getFirst());
        if (accept.isBlank()) return Optional.empty();
        if (accept.length() > 2048) throw new IllegalArgumentException("Accept too long");
        List<Range> ranges = new ArrayList<>();
        var seen = new HashSet<String>();
        for (String item : accept.split(",", -1)) {
            String[] parts = item.trim().toLowerCase(Locale.ROOT).split(";", -1);
            String type = parts[0].trim();
            if (!type.matches("(?:[a-z0-9!#$&^_.+-]+/(?:[a-z0-9!#$&^_.+-]+|\\*)|\\*/\\*)")
                    || parts.length > 2 || !seen.add(type)) {
                throw new IllegalArgumentException("unsupported or duplicate media range");
            }
            int quality = 1000;
            if (parts.length == 2) {
                String q = parts[1].trim();
                if (!q.matches("q=(?:0(?:\\.[0-9]{0,3})?|1(?:\\.0{0,3})?)")) {
                    throw new IllegalArgumentException("only q with at most three decimals is supported");
                }
                quality = new java.math.BigDecimal(q.substring(2)).movePointRight(3).intValueExact();
            }
            ranges.add(new Range(type, quality, type.equals("*/*") ? 0 : type.endsWith("/*") ? 1 : 2));
        }
        String selected = null;
        int selectedQuality = 0;
        for (String offered : OFFERED) {
            int specificity = -1;
            int quality = 0;
            for (Range range : ranges) {
                if (range.matches(offered) && range.specificity() > specificity) {
                    specificity = range.specificity();
                    quality = range.quality();
                }
            }
            if (quality > selectedQuality) {
                selected = offered;
                selectedQuality = quality;
            }
        }
        return Optional.ofNullable(selected);
    }

    public static void main(String[] args) {
        if (!choose("application/json;q=0, */*;q=0.8").orElseThrow().equals("text/html")) {
            throw new AssertionError("specific q=0 must override wildcard");
        }
        if (choose("application/json;q=0,text/html;q=0").isPresent()) throw new AssertionError("expected 406");
        System.out.println("PASS q=0 overrides wildcard; no acceptable representation");
    }
}
