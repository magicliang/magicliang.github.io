import hashlib
import http.client
from http.cookies import SimpleCookie
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
out = Path(sys.argv[1]).resolve()
out.mkdir(parents=True, exist_ok=False)
with socket.socket() as s:
    s.bind(('127.0.0.1', 0))
    port = s.getsockname()[1]
records = []
summary = {'status': 'FAIL', 'port': port}

def save(name, value):
    (out / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def get(path, headers=None, jar=None):
    headers = dict(headers or {})
    if jar:
        headers['Cookie'] = '; '.join(f'{k}={v}' for k, v in jar.items())
    c = http.client.HTTPConnection('127.0.0.1', port, timeout=5)
    try:
        c.request('GET', path, headers=headers)
        r = c.getresponse()
        raw = r.read().decode()
        pairs = r.getheaders()
        h = {k.lower(): v for k, v in pairs}
        if jar is not None:
            for k, v in pairs:
                if k.lower() == 'set-cookie':
                    cookies = SimpleCookie(v)
                    jar.update({n: m.value for n, m in cookies.items()})
        try:
            body = json.loads(raw)
        except ValueError:
            body = raw
        record = {'path': path, 'requestHeaders': headers, 'status': r.status, 'headers': h, 'body': body}
        records.append(record)
        return record
    finally:
        c.close()

def doc(tenant='red', accept='application/json', language='en', jar=None, query=''):
    h = {'Accept-Language': language}
    if accept is not None:
        h['Accept'] = accept
    result = get('/document/' + tenant + query, h, jar)
    assert result['headers']['vary'] == 'Accept, Accept-Language, Cookie'
    assert result['headers']['cache-control'] == 'private, no-store'
    return result

stage = root / 'target/universal/stage'
save('stage-manifest.json', {str(p.relative_to(stage)): hashlib.sha256(p.read_bytes()).hexdigest()
    for p in sorted(stage.rglob('*')) if p.is_file()})
command = [str(stage / 'bin/play-i18n'), f'-Dhttp.port={port}', '-Dhttp.address=127.0.0.1',
    f'-Dpidfile.path={out / "RUNNING_PID"}', '-J-Xms256m', '-J-Xmx768m']
summary['command'] = command
log = (out / 'server.log').open('w')
process = subprocess.Popen(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
try:
    for _ in range(200):
        if process.poll() is not None:
            raise AssertionError('server exited during startup')
        try:
            if get('/health')['status'] == 200:
                break
        except OSError:
            pass
        time.sleep(.1)
    else:
        raise AssertionError('startup timeout')
    assert doc(language='fr')['status'] == 401
    alice, bob, carol = {}, {}, {}
    for name, jar in [('alice', alice), ('bob', bob), ('carol', carol)]:
        assert get('/identity/' + name, jar=jar)['status'] == 200
        assert 'PLAY_SESSION' in jar
    assert doc(language='fr', jar=alice)['body']['greeting'] == 'Bonjour'
    assert doc(language='fr-CH,zh-CN;q=0.5', jar=alice)['body']['language'] == 'fr'
    assert doc(language='de', jar=alice)['body']['language'] == 'en'
    cookie_jar = dict(alice)
    assert get('/lang/zh-CN', jar=cookie_jar)['status'] == 200
    assert doc(language='fr', jar=cookie_jar)['body']['language'] == 'zh-CN'
    assert doc(language='fr', jar=cookie_jar, query='?transient=en')['body']['language'] == 'en'
    assert doc(language='fr', jar=cookie_jar)['body']['language'] == 'zh-CN'
    probe = get('/probe', {'Accept': 'application/json;q=0,text/html;q=1', 'Accept-Language': 'fr'})
    assert probe['body']['acceptsJson'] is True and probe['body']['acceptsHtml'] is True
    assert probe['body']['fallbackMessage'] == 'Default catalog' and probe['body']['missingMessage'] == 'absent.key'
    negotiated = []
    for accept, expected in [(None, 'application/json'), ('*/*', 'application/json'),
        ('application/*;q=0.7,text/*;q=0.3', 'application/json'),
        ('application/json;q=0.2,text/html;q=0.9', 'text/html'),
        ('application/json;q=0,*/*;q=0.8', 'text/html'),
        ('text/html;q=0.5,application/json;q=0.5', 'application/json')]:
        r = doc(accept=accept, jar=alice)
        assert r['status'] == 200 and r['headers']['content-type'].startswith(expected)
        negotiated.append({'accept': accept, 'selected': expected})
    for accept in ['application/xml', 'application/json;q=0,text/html;q=0', '*/*;q=0']:
        assert doc(accept=accept, jar=alice)['status'] == 406
    for accept in ['text/html;q=1.1', 'text/html;charset=utf-8', 'text/html,text/html']:
        assert doc(accept=accept, jar=alice)['status'] == 400
    html = doc(accept='text/html', jar=alice)
    assert '<img src=x onerror=alert(1)>' not in html['body']
    assert '&lt;img src=x onerror=alert(1)&gt;' in html['body']
    assert '<strong>fixed trusted markup</strong>' in html['body']
    (out / 'rendered.html').write_text(html['body'])
    assert doc(tenant='blue', jar=alice, language='zh-CN')['status'] == 403
    assert doc(tenant='red', jar=bob, language='fr')['status'] == 403
    tampered = dict(alice)
    value = tampered['PLAY_SESSION']
    tampered['PLAY_SESSION'] = ('A' if value[0] != 'A' else 'B') + value[1:]
    assert doc(jar=tampered)['status'] == 401
    good = [doc(jar=alice), doc(tenant='blue', jar=bob, language='fr'), doc(jar=carol, language='fr')]
    assert [r['body']['user'] for r in good] == ['alice', 'bob', 'carol']
    assert [r['body']['language'] for r in good] == ['en', 'fr', 'fr']
    bad_first = doc(jar=alice, query='?cache=bad')
    bad_second = doc(tenant='blue', jar=bob, language='fr', query='?cache=bad')
    assert bad_second['body'] == bad_first['body']
    assert bad_second['body']['tenant'] == 'red' and bad_second['body']['language'] == 'en'
    bad_media = doc(tenant='blue', jar=bob, accept='text/html', language='fr', query='?cache=bad')
    assert bad_media['headers']['content-type'].startswith('application/json')
    save('cache-isolation.json', {'good': good, 'badFirst': bad_first, 'badSecond': bad_second, 'badMedia': bad_media})
    save('negotiation.json', negotiated)
    summary.update(status='PASS', scenarios=['language-chain', 'fallback', 'media-q-specificity', 'q-zero-406',
        'malformed-400', 'signed-identity', 'tenant-authorization', 'cache-isolation', 'cache-leak-counterexample', 'twirl-escape'],
        stats=get('/stats')['body'])
finally:
    process.terminate()
    try:
        process.wait(timeout=15)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)
        summary['status'] = 'FAIL'
    log.close()
    summary['exitCode'] = process.returncode
    try:
        with socket.create_connection(('127.0.0.1', port), timeout=.2):
            closed = False
    except OSError:
        closed = True
    summary['portClosed'] = closed
    summary['cacheClosed'] = 'I18N_CACHE_CLOSED correct=0 flawed=0' in (out / 'server.log').read_text()
    summary['httpObservations'] = len(records)
    if not closed or not summary['cacheClosed']:
        summary['status'] = 'FAIL'
    save('http.json', records)
    save('summary.json', summary)
assert summary['status'] == 'PASS', summary
print(json.dumps(summary, indent=2))
