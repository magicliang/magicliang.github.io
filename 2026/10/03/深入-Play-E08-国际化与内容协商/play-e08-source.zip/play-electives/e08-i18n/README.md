# Play E08: internationalization and representation negotiation

Fixed versions: Play 3.0.6, Scala 2.13.15, sbt 1.10.7, JDK 21. The application uses the bundled Twirl compiler and native signed Play session. It has no database or external service dependency.

Set `JAVA_HOME` to your JDK 21 installation and `PLAY_LAB_SBT_LAUNCHER` to a downloaded sbt 1.10.7 launcher JAR. From this directory:

```sh
bash sbtw test stage
python3 verify.py evidence/run-01
```

The output directory must not already exist. The verifier starts a production stage server on a free loopback port, makes finite HTTP requests, terminates it, and checks cache cleanup and port closure. See `summary.json`, `http.json`, `cache-isolation.json`, `rendered.html` and `stage-manifest.json` in the output directory. Only Python's standard library is required.

`app/lab/Negotiator.java` is also a complete standalone JDK 21 example:

```sh
mkdir -p evidence/example-classes
"$JAVA_HOME/bin/javac" -d evidence/example-classes app/lab/Negotiator.java
"$JAVA_HOME/bin/java" -cp evidence/example-classes lab.Negotiator
```

The negotiation contract deliberately supports simple media ranges with only an optional q parameter; additional media parameters, duplicate ranges, malformed q and headers above 2048 characters return 400. This is a bounded teaching implementation, not a general RFC parser. Specific ranges override wildcard quality, q=0 excludes a representation, and no acceptable representation returns 406. Equal quality prefers JSON by server policy. The controller combines repeated Accept field values before parsing.

`GET /identity/alice`, `/identity/carol`, `/identity/bob` issue synthetic identities without credential verification. `/lang/:code` sets the language cookie. `/document/red` and `/document/blue` require the signed session identity and enforce its tenant. The `transient` query is limited to en/fr/zh-CN. The `cache=bad` branch intentionally shares one cache entry across identity/language/media; it demonstrates a leak despite authorization before cache lookup. The default branch includes tenant, user, selected language and selected media in its key.

The fixture secret, disabled filters and GET state mutations are for local experiments only. Sessions are signed, not encrypted; this is not a production login. Both caches are process-local and finite in this fixture (at most 18 correct keys and one deliberately flawed key). All document responses use `Cache-Control: private, no-store` and `Vary: Accept, Accept-Language, Cookie`. These HTTP fields do not fix an application cache key.

HTML rendering passes a hostile string through normal Twirl escaping and a fixed trusted literal through `Html`. No user-controlled string is marked trusted. The script checks the returned HTML bytes, not browser script execution.

NOT_RUN: real credential authentication, external shared-cache/CDN behavior, distributed invalidation, full RFC parameter grammar, browser XSS execution and production load. See the article's exercises for bounded extensions.
