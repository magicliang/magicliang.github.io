package lab;

import org.junit.Test;
import static org.junit.Assert.*;

public class NegotiatorTest {
    @Test public void preferenceSpecificityAndExclusion() {
        assertEquals("text/html", Negotiator.choose("application/json;q=0.2,text/html;q=0.9").orElseThrow());
        assertEquals("text/html", Negotiator.choose("application/json;q=0,*/*;q=0.8").orElseThrow());
        assertEquals("application/json", Negotiator.choose("text/*;q=0.3,application/*;q=0.7").orElseThrow());
        assertEquals("application/json", Negotiator.choose("*/*").orElseThrow());
        assertEquals("application/json", Negotiator.choose(null).orElseThrow());
        assertTrue(Negotiator.choose("application/xml").isEmpty());
        assertTrue(Negotiator.choose("application/json;q=0,text/html;q=0").isEmpty());
    }

    @Test public void inputBoundaryAndStableServerTieBreak() {
        assertEquals("application/json", Negotiator.choose("text/html;q=0.5,application/json;q=0.5").orElseThrow());
        assertTrue(Negotiator.choose("").isEmpty());
        for (String invalid : new String[] {"text/html;q=1.1", "text/html;q=0.1234", "text/html;q=-1",
                "*/html", "text/html;charset=utf-8", "text/html,text/html", "text/html,", "x".repeat(2049)}) {
            assertThrows(IllegalArgumentException.class, () -> Negotiator.choose(invalid));
        }
    }
}
