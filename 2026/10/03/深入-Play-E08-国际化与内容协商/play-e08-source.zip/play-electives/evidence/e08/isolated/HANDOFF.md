# E08 isolated acceptance

Source project: `/private/tmp/play-i18n-work-20261003`. `manifest.json` lists exactly 16 source/config files for `examples/play-electives/e08-i18n`, with SHA-256 and 12 compiled app/controller/Twirl class byte comparisons against the stage JAR.

Invocation: `JAVA_HOME=<JDK21> PLAY_LAB_SBT_LAUNCHER=<sbt1.10.7> bash sbtw test stage`. `build-02.log` exit 0, two executed JUnit tests, no failures or skips. `build-01.log` preserves the initial withSession signature compile failure; it was fixed to Map form and the full build rerun.

Invocation: `JAVA_HOME=<JDK21> python3 verify.py <run-01>`. `run-01/summary.json` PASS, 36 real HTTP observations. Language transient/cookie/header/fallback; q preference/specificity/wildcards/q0/406; malformed or unsupported parser inputs 400; native accepts reports both media true despite JSON q0; no identity/tampered signed cookie 401; tenant mismatch 403; correct tenant/user/language/media cache isolation; deliberately wrong cache leaks Alice English JSON to Bob requesting French/HTML; Twirl String escapes hostile sample while fixed Html remains raw. Responses assert Vary and private/no-store; rendered.html captures bytes. This is synthetic identity issuance, not credential authentication.

SIGTERM exit 143, lifecycle cache clear observable in server.log, loopback port refused after exit. No external services or user processes touched.

Standalone Negotiator.java was compiled with javac and executed; complete-example.log PASS. Exact article Java block equals this production class source. The Java writing entry review preceded anti-ai-tone (0 errors/0 warnings), then persona scan and manual prose review. Article SHA is in writing-receipt.json; two Mermaid mechanisms and 1200x480 SVG cover are written in source/_posts.

NOT_RUN: real credential login, external caches/CDN, distributed invalidation, full Accept parameter grammar, multiple Accept HTTP field lines, browser execution and production load. Root owns source archive, article entry links, site/browser validation, status and local Git commit. This agent will also integrate/replay E04 and E08 per the later assignment.
