import json
from dataclasses import asdict
from pathlib import Path
from adapter import translate, require_released


contract = json.loads((Path(__file__).resolve().parents[2] / "models/23/contract.json").read_text())
base = {"version": 1, "asset": "vendor-501", "status": "DONE", "inspection": "PASS", "returned": True}
checks = 0


def check(condition, name):
    global checks
    assert condition, name
    checks += 1
    print("PASS " + name)


def reject(dto, message):
    try:
        translate(dto, contract)
    except ValueError as exc:
        check(str(exc) == message, "reject " + message)
    else:
        raise AssertionError(message)


ready = translate(base, contract)
check(ready.restriction == "RELEASED" and require_released(ready) == "E1", "v1 release maps equipment identity")
for status in ("OPEN", "IN_PROGRESS"):
    check(translate(base | {"status": status}, contract).restriction == "BLOCKED", status + " is blocked")
cancelled = translate(base | {"status": "CANCELLED"}, contract)
check(cancelled.restriction == "REVIEW_REQUIRED", "cancelled is not repaired")
failed = translate(base | {"inspection": "FAIL"}, contract)
check(failed.restriction == "BLOCKED", "DONE with failed inspection is blocked")
check(translate(base | {"inspection": "PENDING"}, contract).restriction == "REVIEW_REQUIRED", "pending needs review")
check(translate(base | {"returned": False}, contract).restriction == "BLOCKED", "DONE without physical return is blocked")
v2 = {"version": 2, "asset": "vendor-501", "phase": "CLOSED", "disposition": "REPAIRED", "inspection": "PASSED", "returned": True}
check(translate(v2, contract).restriction == "RELEASED", "v2 repaired release")
check(translate(v2 | {"disposition": "NO_FAULT"}, contract).restriction == "RELEASED", "v2 no-fault inspected return")
check(translate(v2 | {"disposition": "CANCELLED"}, contract).restriction == "REVIEW_REQUIRED", "v2 CLOSED cancellation is not release")
for dto, message in [
    (base | {"version": 3}, "unsupported version"),
    (base | {"version": True}, "unsupported version"),
    (base | {"status": "ARCHIVED"}, "unknown v1 status"),
    (base | {"inspection": "MAYBE"}, "unknown v1 inspection"),
    (base | {"asset": "other"}, "unmapped equipment"),
    (base | {"returned": "false"}, "returned must be boolean"),
    (v2 | {"phase": "ARCHIVED"}, "unknown v2 phase"),
    (v2 | {"disposition": "SCRAPPED"}, "unknown v2 disposition"),
    (v2 | {"inspection": "PASS"}, "unknown v2 inspection"),
]:
    reject(dto, message)
for assessment in (cancelled, failed):
    try:
        require_released(assessment)
    except ValueError as exc:
        check(str(exc) == "maintenance release required", "consumer refuses " + assessment.restriction)
    else:
        raise AssertionError("consumer admitted unsafe assessment")
unfinished = translate(base | {"status": "OPEN"}, contract)
check(unfinished.restriction == failed.restriction and unfinished.reason != failed.reason, "many-to-one restriction retains reason")
check(unfinished.source_state != failed.source_state, "source state retained for diagnosis")
naive = (base | {"inspection": "FAIL"})["status"] == "DONE"
check(naive and failed.restriction == "BLOCKED", "counterexample: DONE-only mapping loses failed inspection")
print("SAMPLE " + json.dumps(asdict(failed), sort_keys=True))
print(f"RESULT {checks} checks passed; no network or rental-core mutation")
