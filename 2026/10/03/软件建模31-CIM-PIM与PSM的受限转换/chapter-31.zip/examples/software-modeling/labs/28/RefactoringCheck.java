package rental.application;

import java.util.ArrayList;
import java.util.List;
import rental.RentalDesk.EquipmentId;
import rental.RentalDesk.RequestId;
import rental.application.AvailabilityModel.Commitments;
import rental.application.RentalApplication.AdmissionPolicy;
import rental.application.RentalApplication.Event;
import rental.application.RentalApplication.Maintenance;
import rental.application.RentalApplication.MemoryRepository;
import rental.application.RentalApplication.Snapshot;
import rental.application.RentalApplication.Status;
import rental.domain.Equipment;
import static rental.application.ApplicationCheck.E1;
import static rental.application.ApplicationCheck.NONE;
import static rental.application.ApplicationCheck.NOW;
import static rental.application.ApplicationCheck.SPEC;
import static rental.application.ApplicationCheck.command;
import static rental.application.ApplicationCheck.initial;

public final class RefactoringCheck {
    private record Trace(List<String> outcomes, List<Snapshot> snapshots, List<Event> events) {
        private Trace { outcomes = List.copyOf(outcomes); snapshots = List.copyOf(snapshots); events = List.copyOf(events); }
    }
    private static int checks;
    private RefactoringCheck() { }
    private static Trace execute(AdmissionPolicy policy, String state, Maintenance maintenance, long start, long end) {
        var repo = new MemoryRepository(initial(), NONE);
        var events = new ArrayList<Event>();
        var seed = new RentalApplication(repo, id -> Maintenance.RELEASED, events::add, NONE, policy, SPEC);
        seed.reserve(command("seed", "E1", 7200, 10800), NOW);
        if (state.equals("RETIRED")) repo.transact(s -> { s.equipment(E1).retire(); return null; });
        if (state.equals("INSPECTION_REQUIRED")) repo.transact(s -> { s.equipment(E1).requireInspection(); return null; });
        String id = state.equals("UNKNOWN") ? "missing" : "E1";
        var app = new RentalApplication(repo, equipment -> maintenance, events::add, NONE, policy, SPEC);
        var candidate = command("candidate", id, start, end);
        var outcomes = new ArrayList<String>();
        var snapshots = new ArrayList<Snapshot>();
        outcomes.add(app.reserve(candidate, NOW).name()); snapshots.add(repo.read());
        outcomes.add(app.reserve(candidate, NOW.plusSeconds(999999)).name()); snapshots.add(repo.read());
        outcomes.add(Boolean.toString(app.cancel(new RequestId("seed")))); snapshots.add(repo.read());
        outcomes.add(app.reserve(candidate, NOW).name()); snapshots.add(repo.read());
        outcomes.add(app.reserve(command("fresh", id, start, end), NOW).name()); snapshots.add(repo.read());
        outcomes.add(Boolean.toString(app.cancel(new RequestId("candidate")))); snapshots.add(repo.read());
        return new Trace(outcomes, snapshots, events);
    }
    public static void main(String[] args) {
        if (args.length != 0) throw new IllegalArgumentException("unknown arguments");
        int scenarios = 0;
        for (String state : List.of("ACTIVE", "INSPECTION_REQUIRED", "RETIRED", "UNKNOWN")) {
            for (Maintenance maintenance : Maintenance.values()) {
                for (long[] bounds : List.of(new long[] {1, 3600}, new long[] {7200, 10800},
                        new long[] {10800, 14400}, new long[] {7200, 200000})) {
                    Trace before = execute(new RentalApplication.InlineAdmission(), state, maintenance, bounds[0], bounds[1]);
                    Trace after = execute(new AvailabilityModel(), state, maintenance, bounds[0], bounds[1]);
                    check("trajectory " + state + "/" + maintenance + "/" + bounds[0] + "-" + bounds[1], before.equals(after));
                    scenarios++;
                    System.out.println("TRACE " + scenarios + " " + after.outcomes());
                }
            }
        }
        var model = new AvailabilityModel();
        var repo = new MemoryRepository(initial(), NONE);
        var events = new ArrayList<Event>();
        var app = new RentalApplication(repo, id -> Maintenance.RELEASED, events::add, NONE, model, SPEC);
        var request = command("query", "E1", 7200, 10800);
        var equipment = Equipment.restore(repo.read().equipment().get(E1));
        var before = model.inspect(E1, equipment, Maintenance.RELEASED, request.request().period(), NOW, SPEC, repo.read().calendar());
        check("available before promise", before.available());
        app.reserve(command("competitor", "E1", 7200, 10800), NOW);
        check("stale query cannot authorize reservation", before.available() && app.reserve(request, NOW) == Status.OVERLAP_REJECTED);
        var during = model.inspect(E1, equipment, Maintenance.RELEASED, request.request().period(), NOW, SPEC, repo.read().calendar());
        check("ACTIVE and RELEASED insufficient for requested window", !during.available() && during.commitments() == Commitments.COMMITTED);
        var adjacent = command("adjacent", "E1", 10800, 14400);
        check("same equipment different window available", model.inspect(E1, equipment, Maintenance.RELEASED,
                adjacent.request().period(), NOW, SPEC, repo.read().calendar()).available());
        app.cancel(new RequestId("competitor"));
        check("cancel releases commitment despite retained receipt", model.inspect(E1, equipment, Maintenance.RELEASED,
                request.request().period(), NOW, SPEC, repo.read().calendar()).available());
        check("available now cannot change past refusal", app.reserve(request, NOW) == Status.OVERLAP_REJECTED);
        check("new request can use free window", app.reserve(command("new", "E1", 7200, 10800), NOW) == Status.CONFIRMED);
        System.out.println("OBSERVED naiveAvailable=" + (equipment.state() == Equipment.State.ACTIVE)
                + " qualified=true timeValid=true committed=true available=" + during.available());
        System.out.println("RESULT chapter28 scenarios=" + scenarios + " checks=" + checks + " equalOutcomeSnapshotEventTrajectories=true");
    }
    private static void check(String label, boolean value) {
        if (!value) throw new AssertionError(label);
        checks++;
        System.out.println("PASS " + label);
    }
}
