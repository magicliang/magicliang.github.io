#!/usr/bin/env bash
set -euo pipefail
lab_dir=$(cd "$(dirname "$0")" && pwd)
export PYTHONDONTWRITEBYTECODE=1
python_cmd=${PYTHON_BINARY:-python3}
"$python_cmd" -c 'import sys; print(sys.version); sys.exit(0 if sys.version_info >= (3, 10) else "Python 3.10+ required; set PYTHON_BINARY.")'
exec "$python_cmd" "$lab_dir/check.py" "$@"
