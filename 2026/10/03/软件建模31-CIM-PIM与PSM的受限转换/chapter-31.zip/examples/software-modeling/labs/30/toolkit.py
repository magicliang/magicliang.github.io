"""Version1 finite-state DSL. Standard library only; no UML/MOF conformance claim."""
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re


class ModelError(ValueError):
    def __init__(self, code: str, path: str, message: str):
        self.code, self.path = code, path
        super().__init__(f'{code} at {path}: {message}')


@dataclass(frozen=True)
class Transition:
    from_state: str
    operation: str
    to_state: str


@dataclass(frozen=True)
class Model:
    version: int
    name: str
    states: tuple[str, ...]
    initial: str
    terminal: tuple[str, ...]
    operations: tuple[str, ...]
    transitions: tuple[Transition, ...]

    def as_dict(self) -> dict:
        return {'version':self.version,'name':self.name,'states':list(self.states),
                'initial':self.initial,'terminal':list(self.terminal),'operations':list(self.operations),
                'transitions':[{'from':e.from_state,'operation':e.operation,'to':e.to_state} for e in self.transitions]}


def _object(pairs):
    result = {}
    for key,value in pairs:
        if key in result:
            raise ModelError('DUPLICATE_KEY', '$', key)
        result[key] = value
    return result


def _constant(value):
    raise ModelError('JSON_SYNTAX', '$', f'non-JSON constant {value}')


def _identifier(value, path):
    if not isinstance(value, str) or re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', value) is None:
        raise ModelError('SHAPE', path, 'ASCII identifier required')
    return value


def _names(value, path, nonempty=True):
    if not isinstance(value, list) or (nonempty and not value):
        raise ModelError('SHAPE', path, 'array required')
    result = []
    for i,item in enumerate(value):
        _identifier(item, f'{path}[{i}]')
        if item in result:
            raise ModelError('DUPLICATE_NAME', f'{path}[{i}]', item)
        result.append(item)
    return tuple(result)


def parse_model(text: str) -> Model:
    try:
        raw = json.loads(text, object_pairs_hook=_object, parse_constant=_constant)
    except json.JSONDecodeError as error:
        raise ModelError('JSON_SYNTAX', f'line:{error.lineno}:column:{error.colno}', error.msg) from error
    fields = {'version','name','states','initial','terminal','operations','transitions'}
    if not isinstance(raw, dict) or set(raw) != fields:
        raise ModelError('SHAPE', '$', 'exact model fields required')
    if type(raw['version']) is not int or raw['version'] != 1:
        raise ModelError('VERSION', '$.version', 'only integer version1 supported')
    name = _identifier(raw['name'], '$.name')
    states = _names(raw['states'], '$.states')
    operations = _names(raw['operations'], '$.operations')
    terminal = _names(raw['terminal'], '$.terminal', False)
    initial = _identifier(raw['initial'], '$.initial')
    if initial not in states:
        raise ModelError('UNKNOWN_STATE', '$.initial', initial)
    for i,state in enumerate(terminal):
        if state not in states:
            raise ModelError('UNKNOWN_STATE', f'$.terminal[{i}]', state)
    if not isinstance(raw['transitions'], list):
        raise ModelError('SHAPE', '$.transitions', 'array required')
    transitions, seen = [], set()
    for i,edge in enumerate(raw['transitions']):
        path = f'$.transitions[{i}]'
        if not isinstance(edge, dict) or set(edge) != {'from','operation','to'}:
            raise ModelError('SHAPE', path, 'exact transition fields required')
        for key in ('from','operation','to'):
            _identifier(edge[key], path+'.'+key)
        for key in ('from','to'):
            if edge[key] not in states:
                raise ModelError('UNKNOWN_STATE', path+'.'+key, edge[key])
        if edge['operation'] not in operations:
            raise ModelError('UNKNOWN_OPERATION', path+'.operation', edge['operation'])
        pair = (edge['from'], edge['operation'])
        if pair in seen:
            raise ModelError('NONDETERMINISTIC', path, 'duplicate source/operation')
        if edge['from'] in terminal:
            raise ModelError('TERMINAL_OUTGOING', path+'.from', edge['from'])
        seen.add(pair)
        transitions.append(Transition(edge['from'],edge['operation'],edge['to']))
    reached = {initial}
    while True:
        expanded = reached | {e.to_state for e in transitions if e.from_state in reached}
        if expanded == reached:
            break
        reached = expanded
    if reached != set(states):
        raise ModelError('UNREACHABLE', '$.states', ','.join(sorted(set(states)-reached)))
    return Model(1,name,states,initial,terminal,operations,tuple(transitions))


def load_model(path: str | Path) -> Model:
    return parse_model(Path(path).read_text(encoding='utf-8'))


def step(model: Model, state: str, operation: str) -> str:
    for edge in model.transitions:
        if (edge.from_state, edge.operation) == (state, operation):
            return edge.to_state
    raise ModelError('OPERATION_NOT_ALLOWED', '$.runtime', f'{state}/{operation}')


def validate_equipment_contract(model: Model) -> None:
    expected = {('INSPECTION_REQUIRED','approveInspection','ACTIVE'),
                ('ACTIVE','requireInspection','INSPECTION_REQUIRED'),
                ('INSPECTION_REQUIRED','retire','RETIRED'),('ACTIVE','retire','RETIRED')}
    actual = {(e.from_state,e.operation,e.to_state) for e in model.transitions}
    if (set(model.states) != {'INSPECTION_REQUIRED','ACTIVE','RETIRED'} or
        model.initial != 'INSPECTION_REQUIRED' or set(model.terminal) != {'RETIRED'} or
        set(model.operations) != {'approveInspection','requireInspection','retire'} or actual != expected):
        raise ModelError('EQUIPMENT_CONTRACT', '$', 'chapter24 lifecycle subset mismatch')


def generate_python(model: Model) -> str:
    # Model values must originate from parse_model/load_model, not direct construction.
    canonical = json.dumps(model.as_dict(), sort_keys=True, separators=(',', ':'))
    digest = hashlib.sha256(canonical.encode()).hexdigest()
    table = {(e.from_state,e.operation):e.to_state for e in sorted(model.transitions,key=lambda e:(e.from_state,e.operation))}
    return (f'# DSL version1; model sha256={digest}\nINITIAL = {model.initial!r}\n'
            f'TRANSITIONS = {table!r}\n\n'
            'def step(state: str, operation: str) -> str:\n'
            '    try:\n        return TRANSITIONS[(state, operation)]\n'
            "    except KeyError as error:\n        raise ValueError('OPERATION_NOT_ALLOWED') from error\n")
