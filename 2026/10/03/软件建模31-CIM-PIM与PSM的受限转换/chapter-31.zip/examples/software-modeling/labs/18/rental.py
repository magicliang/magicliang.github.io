from dataclasses import replace
from baseline import Period, Rental, ReservationBook as BaseReservationBook


class ReservationBook(BaseReservationBook):
    def extend(self, rental_id, new_end):
        if rental_id not in self.rentals:
            raise ValueError("unknown rental")
        old = self.rentals[rental_id]
        if type(new_end) is not int or new_end <= old.period.end:
            raise ValueError("extension must increase end")
        candidate = replace(old, period=Period(old.period.start, new_end))
        self.validate(candidate)
        self.rentals[rental_id] = candidate
        return candidate
