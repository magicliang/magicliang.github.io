package rental.domain;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Currency;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import rental.RentalDesk;
import rental.RentalDesk.EquipmentId;
import rental.RentalDesk.Period;
import rental.RentalDesk.RequestId;
import rental.RentalDesk.ReserveRequest;

public final class IdentityCheck {
    private static int checks;

    private IdentityCheck() {}

    private record UnsafeDescription(List<String> tags) {}

    public static void main(String[] args) {
        var tags = new ArrayList<>(List.of("camera"));
        var unsafe = new UnsafeDescription(tags);
        var description = new EquipmentDescription("CAM-A", tags);
        tags.add("changed outside");
        check(unsafe.tags().size() == 2, "counterexample record alone leaks mutable list alias");
        check(description.tags().equals(List.of("camera")), "description copies input list");
        expect(UnsupportedOperationException.class, () -> description.tags().add("other"), "output list rejects mutation");
        check(description.equals(new EquipmentDescription("CAM-A", List.of("camera"))), "description has structural equality");
        expect(NullPointerException.class, () -> new EquipmentDescription("CAM-A", null), "null tags rejected");

        var e1 = new Equipment(new EquipmentId("E1"), description);
        var e2 = new Equipment(new EquipmentId("E2"), description);
        check(!e1.equals(e2), "same attributes different identities");
        var initial = e1.snapshot();
        var restored = Equipment.restore(initial);
        check(e1 != restored && e1.equals(restored), "different references same entity identity");
        check(e1.hashCode() == restored.hashCode(), "equal entities have equal hash");
        Set<Equipment> identitySet = new HashSet<>();
        identitySet.add(e1);
        int hash = e1.hashCode();
        Equipment alias = e1;
        e1.approveInspection();
        check(alias.state() == Equipment.State.ACTIVE, "entity aliases observe lifecycle change");
        check(e1.equals(restored) && !e1.snapshot().equals(restored.snapshot()), "identity equality is not state equality");
        check(e1.hashCode() == hash && identitySet.contains(e1), "hash identity stable after state mutation");
        check(initial.state() == Equipment.State.INSPECTION_REQUIRED, "snapshot retains old state");
        e1.changeDescription(new EquipmentDescription("CAM-A revised", List.of("camera")));
        check(e1.id().equals(initial.id()) && e1.equals(restored), "description change preserves identity");
        e1.requireInspection();
        check(e1.state() == Equipment.State.INSPECTION_REQUIRED, "active can require inspection");
        e1.approveInspection();
        expect(IllegalStateException.class, e1::approveInspection, "duplicate approval rejected");
        e1.retire();
        expect(IllegalStateException.class, e1::approveInspection, "retired cannot reactivate");
        expect(IllegalStateException.class, e1::requireInspection, "retired cannot require inspection");
        expect(IllegalStateException.class, () -> e1.changeDescription(description), "retired description cannot change");
        expect(IllegalStateException.class, e1::retire, "duplicate retirement rejected");
        check(e1.state() == Equipment.State.RETIRED, "rejected transitions leave retired state");
        e2.retire();
        check(e2.state() == Equipment.State.RETIRED, "unapproved equipment may retire");
        check(!e1.id().equals(new RequestId("E1")), "different identifier types do not compare equal");

        var a = money("10.0", "CNY");
        var b = money("10.00", "CNY");
        check(!new BigDecimal("10.0").equals(new BigDecimal("10.00")), "counterexample raw decimal equals includes scale");
        check(a.equals(b) && a.hashCode() == b.hashCode(), "money normalizes scale for equality and hash");
        check(!a.equals(money("10", "USD")), "same numeric amount different currency");
        check(a.add(money("2", "CNY")).equals(money("12", "CNY")) && a.equals(b), "money addition returns value without changing operand");
        check(money("-2", "CNY").add(a).equals(money("8", "CNY")), "signed amount supported without payment meaning");
        expect(IllegalArgumentException.class, () -> a.add(money("2", "USD")), "mixed currency addition rejected");
        expect(ArithmeticException.class, () -> money("0.001", "CNY"), "precision loss rejected without rounding");
        expect(IllegalArgumentException.class, () -> money("1", "JPY"), "unsupported currency rejected");

        Instant start = Instant.parse("2026-10-03T00:00:00Z");
        var period = new Period(start, start.plusSeconds(3600));
        check(period.equals(new Period(start, start.plusSeconds(3600))), "existing core Period value equality");
        check(!period.overlaps(new Period(period.end(), period.end().plusSeconds(3600))), "existing core half-open boundary retained");
        expect(IllegalArgumentException.class, () -> new Period(start, start), "existing core rejects empty period");
        var desk = new RentalDesk();
        var request = new ReserveRequest(new RequestId("R1"), e1.id(), period);
        check(desk.reserve(request) == RentalDesk.Outcome.CONFIRMED, "boundary: unchanged core does not know entity retirement");
        check(desk.reserve(request) == RentalDesk.Outcome.CONFIRMED, "existing core same request retry retained");
        check(desk.cancel(request.requestId()), "existing core cancellation retained");
        System.out.println("RESULT " + checks + " checks passed; lifecycle gate not integrated into RentalDesk");
    }

    private static Money money(String value, String currency) {
        return new Money(new BigDecimal(value), Currency.getInstance(currency));
    }

    private static void check(boolean condition, String name) {
        if (!condition) throw new AssertionError(name);
        checks++;
        System.out.println("PASS " + name);
    }

    private static void expect(Class<? extends Throwable> expected, Runnable action, String name) {
        try {
            action.run();
        } catch (Throwable actual) {
            if (!expected.isInstance(actual)) throw new AssertionError(name, actual);
            check(true, name);
            return;
        }
        throw new AssertionError("not rejected: " + name);
    }
}
