package rental.domain;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.Currency;
import rental.RentalDesk.EquipmentId;
import rental.RentalDesk.Outcome;
import rental.RentalDesk.Period;
import rental.RentalDesk.RequestId;
import rental.RentalDesk.ReserveRequest;
import rental.domain.PricingService.HourlyRate;
import rental.domain.RentalPeriodSpecification.Result;

public final class ResponsibilityCheck {
    private static int checks;
    private static final Instant NOW = Instant.parse("2026-10-03T08:00:00Z");
    private ResponsibilityCheck() { }
    private static Money money(String amount, String currency) {
        return new Money(new BigDecimal(amount), Currency.getInstance(currency));
    }
    private static Period period(long startSeconds, long durationSeconds) {
        Instant start = NOW.plusSeconds(startSeconds);
        return new Period(start, start.plusSeconds(durationSeconds));
    }

    public static void main(String[] args) {
        var spec = new RentalPeriodSpecification(Duration.ofHours(1), Duration.ofHours(48));
        var pricing = new PricingService();
        var rate = new HourlyRate("rate-v1", money("12.50", "CNY"));
        var factory = new RentalContract.Factory(spec, pricing);
        if (args.length == 1 && args[0].equals("invalid-period")) {
            factory.create(new ReserveRequest(new RequestId("bad"), new EquipmentId("E1"), period(3599, 3600)), rate, NOW);
            throw new AssertionError("invalid period accepted");
        }
        if (args.length != 0) throw new IllegalArgumentException("unknown mode");
        check("lead boundary accepted", spec.isSatisfiedBy(period(3600, 3600), NOW));
        check("one second early rejected", spec.evaluate(period(3599, 3600), NOW) == Result.TOO_SOON);
        check("past start rejected", spec.evaluate(period(-1, 3600), NOW) == Result.TOO_SOON);
        check("maximum duration accepted", spec.isSatisfiedBy(period(3600, 48 * 3600), NOW));
        check("over maximum rejected", spec.evaluate(period(3600, 48 * 3600 + 1), NOW) == Result.TOO_LONG);
        reject("negative lead rejected", () -> new RentalPeriodSpecification(Duration.ofSeconds(-1), Duration.ofHours(1)));
        reject("zero maximum rejected", () -> new RentalPeriodSpecification(Duration.ZERO, Duration.ZERO));
        check("one hour quote", pricing.quote(period(3600, 3600), rate).equals(money("12.50", "CNY")));
        check("ninety minute rounded up", pricing.quote(period(3600, 5400), rate).equals(money("25.00", "CNY")));
        var nanos = new Period(NOW.plusSeconds(3600), NOW.plusSeconds(7200).plusNanos(1));
        check("one nanosecond over hour rounded up", pricing.quote(nanos, rate).equals(money("25.00", "CNY")));
        check("subsecond still one hour", pricing.quote(new Period(NOW, NOW.plusNanos(1)), rate).equals(money("12.50", "CNY")));
        reject("negative hourly rate", () -> new HourlyRate("bad", money("-1", "CNY")));
        var request = new ReserveRequest(new RequestId("r1"), new EquipmentId("E1"), period(7200, 5400));
        var contract = factory.create(request, rate, NOW);
        check("factory preserves request", contract.request().equals(request));
        check("factory quote invariant", contract.total().equals(pricing.quote(contract.request().period(), contract.rate())));
        check("contract snapshot round trip", RentalContract.restore(contract.snapshot()).snapshot().equals(contract.snapshot()));
        reject("tampered quote rejected", () -> new RentalContract.Snapshot(request, rate, money("1", "CNY")));
        reject("tampered quote currency rejected", () -> new RentalContract.Snapshot(request, rate, money("25", "USD")));
        check("cover exact amount", contract.covers(money("25", "CNY")));
        check("cover rejects short amount", !contract.covers(money("24.99", "CNY")));
        reject("coverage refuses currency conversion", () -> contract.covers(money("25", "USD")));
        var laterRate = new HourlyRate("rate-v2", money("20", "CNY"));
        check("new rate cannot change old draft", factory.create(request, laterRate, NOW).total().equals(money("40", "CNY"))
                && contract.total().equals(money("25", "CNY")) && contract.rate().revision().equals("rate-v1"));
        reject("factory refuses too soon", () -> factory.create(new ReserveRequest(new RequestId("soon"),
                new EquipmentId("E1"), period(1, 3600)), rate, NOW));
        reject("factory refuses too long", () -> factory.create(new ReserveRequest(new RequestId("long"),
                new EquipmentId("E1"), period(3600, 49 * 3600)), rate, NOW));
        var calendar = new ReservationCalendar("shop-A");
        var other = factory.create(new ReserveRequest(new RequestId("r2"), new EquipmentId("E1"), period(9000, 3600)), rate, NOW);
        check("factory creates no reservation", calendar.snapshot().receipts().isEmpty());
        check("first draft can reserve", calendar.reserve(contract.request()) == Outcome.CONFIRMED);
        check("second valid draft still conflicts", calendar.reserve(other.request()) == Outcome.OVERLAP_REJECTED);
        check("domain service has no reservation side effects", calendar.snapshot().receipts().size() == 2
                && pricing.quote(request.period(), rate).equals(contract.total()) && calendar.snapshot().receipts().size() == 2);
        System.out.println("OBSERVED quote=25.00 CNY revision=rate-v1 validDrafts=2 confirmations=1");
        System.out.println("PASS chapter26 checks=" + checks);
    }

    private static void reject(String label, Runnable operation) {
        try { operation.run(); } catch (IllegalArgumentException expected) { check(label, true); return; }
        throw new AssertionError("expected rejection: " + label);
    }
    private static void check(String label, boolean condition) {
        if (!condition) throw new AssertionError(label);
        checks++;
        System.out.println("PASS " + label);
    }
}
