#!/usr/bin/env bash
set -euo pipefail
lab_dir="$(cd "$(dirname "$0")" && pwd)"
python3 --version
exec python3 "$lab_dir/check.py"
