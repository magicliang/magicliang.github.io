package rental.domain;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import rental.RentalDesk.EquipmentId;
import rental.RentalDesk.Outcome;
import rental.RentalDesk.Period;
import rental.RentalDesk.RequestId;
import rental.RentalDesk.ReserveRequest;
import rental.domain.ReservationCalendar.Receipt;
import rental.domain.ReservationCalendar.Snapshot;

public final class AggregateCheck {
    private static int checks;
    private AggregateCheck() { }

    private static final class ContractCandidate {
        private final List<ReserveRequest> shared;
        private ContractCandidate(List<ReserveRequest> shared) { this.shared = shared; }
        synchronized Outcome reserve(ReserveRequest request, CyclicBarrier afterRead,
                                    List<String> trace) throws Exception {
            boolean conflict = shared.stream().anyMatch(old -> old.equipmentId().equals(request.equipmentId())
                    && old.period().overlaps(request.period()));
            trace.add(Thread.currentThread().getName() + " " + request.requestId().value()
                    + " read conflict=" + conflict);
            afterRead.await(5, TimeUnit.SECONDS);
            if (conflict) return Outcome.OVERLAP_REJECTED;
            shared.add(request);
            trace.add(Thread.currentThread().getName() + " " + request.requestId().value() + " inserted");
            return Outcome.CONFIRMED;
        }
    }

    private static ReserveRequest request(String id, String equipment, int start, int end) {
        Instant base = Instant.parse("2026-10-03T00:00:00Z");
        return new ReserveRequest(new RequestId(id), new EquipmentId(equipment),
                new Period(base.plusSeconds(start * 3600L), base.plusSeconds(end * 3600L)));
    }

    private static List<Outcome> race(boolean broken) throws Exception {
        List<ReserveRequest> shared = new CopyOnWriteArrayList<>();
        List<String> trace = new CopyOnWriteArrayList<>();
        CyclicBarrier barrier = new CyclicBarrier(2);
        ReservationCalendar calendar = new ReservationCalendar("shop-A");
        var pool = Executors.newFixedThreadPool(2);
        try {
            var one = pool.submit(() -> {
                ReserveRequest request = request("r1", "E1", 10, 12);
                if (broken) return new ContractCandidate(shared).reserve(request, barrier, trace);
                barrier.await(5, TimeUnit.SECONDS);
                Outcome outcome = calendar.reserve(request);
                trace.add(Thread.currentThread().getName() + " r1 " + outcome);
                return outcome;
            });
            var two = pool.submit(() -> {
                ReserveRequest request = request("r2", "E1", 11, 13);
                if (broken) return new ContractCandidate(shared).reserve(request, barrier, trace);
                barrier.await(5, TimeUnit.SECONDS);
                Outcome outcome = calendar.reserve(request);
                trace.add(Thread.currentThread().getName() + " r2 " + outcome);
                return outcome;
            });
            List<Outcome> outcomes = List.of(one.get(10, TimeUnit.SECONDS), two.get(10, TimeUnit.SECONDS));
            trace.forEach(line -> System.out.println("TRACE " + (broken ? "broken " : "guarded ") + line));
            long active = broken ? shared.size() : calendar.snapshot().receipts().stream().filter(Receipt::active).count();
            System.out.println("OBSERVED " + (broken ? "broken" : "guarded") + " outcomes=" + outcomes + " active=" + active);
            check("active state agrees with outcomes", active == outcomes.stream().filter(o -> o == Outcome.CONFIRMED).count());
            return outcomes;
        } finally {
            pool.shutdownNow();
            if (!pool.awaitTermination(5, TimeUnit.SECONDS)) throw new AssertionError("worker termination timeout");
        }
    }

    public static void main(String[] args) throws Exception {
        List<Outcome> broken = race(true);
        if (args.length == 1 && args[0].equals("require-broken-safe")) {
            check("at most one confirmation", broken.stream().filter(o -> o == Outcome.CONFIRMED).count() <= 1);
            return;
        }
        if (args.length != 0) throw new IllegalArgumentException("unknown mode");
        check("controlled race violates exclusion", broken.equals(List.of(Outcome.CONFIRMED, Outcome.CONFIRMED)));
        List<Outcome> guarded = race(false);
        check("guarded race confirms one", guarded.stream().filter(o -> o == Outcome.CONFIRMED).count() == 1);
        check("guarded race rejects one", guarded.contains(Outcome.OVERLAP_REJECTED));

        var calendar = new ReservationCalendar("shop-A");
        var first = request("a", "E1", 10, 12);
        var rejected = request("b", "E1", 11, 13);
        check("first confirmation", calendar.reserve(first) == Outcome.CONFIRMED);
        check("overlap rejection", calendar.reserve(rejected) == Outcome.OVERLAP_REJECTED);
        check("same payload replay", calendar.reserve(first) == Outcome.CONFIRMED && calendar.snapshot().receipts().size() == 2);
        reject("changed payload across equipment", () -> calendar.reserve(request("a", "E2", 10, 12)));
        check("cancel active", calendar.cancel(first.requestId()));
        check("repeat cancel false", !calendar.cancel(first.requestId()));
        check("cancelled receipt stays confirmed", calendar.reserve(first) == Outcome.CONFIRMED);
        check("cancelled replay does not reactivate", calendar.snapshot().receipts().stream().noneMatch(Receipt::active));
        check("rejected receipt stays rejected", calendar.reserve(rejected) == Outcome.OVERLAP_REJECTED);
        check("new request after release", calendar.reserve(request("c", "E1", 11, 13)) == Outcome.CONFIRMED);
        check("adjacent period", calendar.reserve(request("d", "E1", 13, 14)) == Outcome.CONFIRMED);
        check("other equipment", calendar.reserve(request("e", "E2", 11, 13)) == Outcome.CONFIRMED);
        Snapshot before = calendar.snapshot();
        var restored = ReservationCalendar.restore(before);
        check("snapshot round trip", restored.snapshot().equals(before));
        check("restored replay", restored.reserve(first) == Outcome.CONFIRMED && restored.reserve(rejected) == Outcome.OVERLAP_REJECTED);
        restored.cancel(new RequestId("c"));
        check("restored instance independent", calendar.snapshot().equals(before));
        try { before.receipts().clear(); throw new AssertionError("mutable snapshot"); }
        catch (UnsupportedOperationException expected) { check("snapshot immutable", true); }
        var duplicated = new ArrayList<>(before.receipts());
        duplicated.add(before.receipts().getFirst());
        reject("duplicate restored request", () -> ReservationCalendar.restore(new Snapshot("shop-A", duplicated)));
        reject("overlapping restored active records", () -> ReservationCalendar.restore(new Snapshot("shop-A", List.of(
                new Receipt(first, Outcome.CONFIRMED, true), new Receipt(rejected, Outcome.CONFIRMED, true)))));
        reject("rejection cannot be active", () -> new Receipt(rejected, Outcome.OVERLAP_REJECTED, true));

        var separateOne = new ReservationCalendar("shop-A");
        var separateTwo = new ReservationCalendar("shop-A");
        check("separate instances do not share a lock", separateOne.reserve(first) == Outcome.CONFIRMED
                && separateTwo.reserve(rejected) == Outcome.CONFIRMED);
        boolean contractWritten = false;
        var interrupted = new ReservationCalendar("shop-B");
        try {
            interrupted.reserve(first);
            throw new IllegalStateException("injected contract write failure");
        } catch (IllegalStateException expected) {
            System.out.println("OBSERVED cross-boundary failure=" + expected.getMessage());
        }
        check("local reservation survives later contract failure", !contractWritten
                && interrupted.snapshot().receipts().getFirst().active());
        System.out.println("PASS chapter25 checks=" + checks);
    }

    private static void reject(String label, Runnable operation) {
        try { operation.run(); } catch (IllegalArgumentException expected) { check(label, true); return; }
        throw new AssertionError("expected rejection: " + label);
    }
    private static void check(String label, boolean condition) {
        if (!condition) throw new AssertionError(label);
        checks++;
        System.out.println("PASS " + label);
    }
}
