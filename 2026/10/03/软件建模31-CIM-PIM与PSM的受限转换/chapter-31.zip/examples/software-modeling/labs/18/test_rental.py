import unittest
from rental import Period, ReservationBook


class RentalTests(unittest.TestCase):
    def setUp(self):
        self.book = ReservationBook()
        self.old = self.book.reserve("R1", "E1", 1, 3)
        self.book.reserve("R2", "E1", 5, 8)

    def assert_rejected_unchanged(self, message, action):
        before = dict(self.book.rentals)
        with self.assertRaisesRegex(ValueError, message):
            action()
        self.assertEqual(self.book.rentals, before)

    def test_extension_preserves_identity_and_old_value(self):
        extended = self.book.extend("R1", 4)
        self.assertEqual((extended.id, extended.equipment, extended.period), ("R1", "E1", Period(1, 4)))
        self.assertEqual(self.old.period, Period(1, 3))
        self.assertEqual(self.book.rentals["R1"], extended)

    def test_adjacent_boundary(self):
        self.assertEqual(self.book.extend("R1", 5).period, Period(1, 5))

    def test_conflict_preserves_state(self):
        self.assert_rejected_unchanged("conflict", lambda: self.book.extend("R1", 6))

    def test_equal_end_rejected(self):
        self.assert_rejected_unchanged("increase", lambda: self.book.extend("R1", 3))

    def test_shrink_rejected(self):
        self.assert_rejected_unchanged("increase", lambda: self.book.extend("R1", 2))

    def test_unknown_rental(self):
        self.assert_rejected_unchanged("unknown rental", lambda: self.book.extend("missing", 4))

    def test_non_integer_boundary(self):
        self.assert_rejected_unchanged("increase", lambda: self.book.extend("R1", 4.5))

    def test_other_equipment_independent(self):
        self.book.reserve("R3", "E2", 1, 20)
        self.assertEqual(self.book.extend("R1", 5).period.end, 5)

    def test_duplicate_reserve_does_not_overwrite(self):
        self.assert_rejected_unchanged("invalid rental id", lambda: self.book.reserve("R1", "E2", 1, 2))

    def test_cancel_releases_extended_period(self):
        self.book.extend("R1", 5)
        self.book.cancel("R1")
        self.assertEqual(self.book.reserve("R3", "E1", 1, 5).period, Period(1, 5))

    def test_unknown_equipment(self):
        self.assert_rejected_unchanged("unknown equipment", lambda: self.book.reserve("R3", "E9", 1, 2))

    def test_empty_period(self):
        self.assert_rejected_unchanged("invalid period", lambda: self.book.reserve("R3", "E2", 1, 1))


if __name__ == "__main__":
    unittest.main(verbosity=2)
