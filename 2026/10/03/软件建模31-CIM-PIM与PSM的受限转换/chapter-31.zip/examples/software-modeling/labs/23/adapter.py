from dataclasses import dataclass


@dataclass(frozen=True)
class Assessment:
    equipment_id: str
    restriction: str
    reason: str
    source_version: int
    source_state: str
    source_inspection: str
    returned: bool


def translate(dto, contract):
    version = dto.get("version")
    if type(version) is not int or version not in (1, 2):
        raise ValueError("unsupported version")
    external_id = dto.get("asset")
    if not isinstance(external_id, str) or external_id not in contract["equipment_mapping"]:
        raise ValueError("unmapped equipment")
    returned = dto.get("returned")
    if type(returned) is not bool:
        raise ValueError("returned must be boolean")
    if version == 1:
        state = dto.get("status")
        inspection = dto.get("inspection")
        if state not in contract["v1_status"]:
            raise ValueError("unknown v1 status")
        if inspection not in contract["v1_inspection"]:
            raise ValueError("unknown v1 inspection")
        completed = state == "DONE"
        cancelled = state == "CANCELLED"
        passed, failed = inspection == "PASS", inspection == "FAIL"
    else:
        phase, disposition = dto.get("phase"), dto.get("disposition")
        inspection = dto.get("inspection")
        if phase not in contract["v2_phase"]:
            raise ValueError("unknown v2 phase")
        if disposition not in contract["v2_disposition"]:
            raise ValueError("unknown v2 disposition")
        if inspection not in contract["v2_inspection"]:
            raise ValueError("unknown v2 inspection")
        state = f"{phase}/{disposition}"
        completed = phase == "CLOSED" and disposition in ("REPAIRED", "NO_FAULT")
        cancelled = disposition == "CANCELLED"
        passed, failed = inspection == "PASSED", inspection == "FAILED"
    if failed:
        restriction, reason = "BLOCKED", "inspection failed"
    elif cancelled:
        restriction, reason = "REVIEW_REQUIRED", "cancelled work does not prove release"
    elif not completed:
        restriction, reason = "BLOCKED", "repair unfinished"
    elif not returned:
        restriction, reason = "BLOCKED", "equipment not returned"
    elif not passed:
        restriction, reason = "REVIEW_REQUIRED", "inspection pending"
    else:
        restriction, reason = "RELEASED", "repair passed and returned"
    return Assessment(contract["equipment_mapping"][external_id], restriction, reason,
                      version, state, inspection, returned)


def require_released(assessment):
    if assessment.restriction != "RELEASED":
        raise ValueError("maintenance release required")
    return assessment.equipment_id
