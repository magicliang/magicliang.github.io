# 19：术语消歧前后行为

从仓库根目录或下载包解压根目录执行：

```bash
bash examples/software-modeling/labs/19/run.sh
```

Python标准库；入口按自身位置读取`examples/software-modeling/models/19/cases.json`，可从任意cwd执行。21项断言通过exit0，不符或错误输入未拒绝时exit非零。InitialCandidate为有意构造的初稿，不是前章共享核心；角色、区间、差额查询均独立于共享核心。

完整输出、CLI反例、源哈希和范围见`examples/software-modeling/evidence/19/`及`examples/software-modeling/models/19/semantics.md`。固定UTC教学日、单币种CNY分，无外部服务、数据库迁移或并发验证。
