#!/usr/bin/env python3
"""Single-process, state-based Event Modeling teaching slice; Python >=3.10."""
import json
from copy import deepcopy
from pathlib import Path

FIELDS = {'rental_id': ('ui', 'rental_id'), 'equipment_id': ('ui', 'equipment_id'),
          'start': ('ui', 'start'), 'end': ('ui', 'end'),
          'customer_id': ('session', 'customer_id'), 'accepted_at': ('clock', 'now')}
VIEW_FIELDS = tuple(FIELDS) + ('duration',)


def command_from(operation: dict) -> dict:
    if operation.get('action') != 'submit-reservation':
        raise ValueError('unsupported action')
    try:
        command = {key: operation[group][field] for key, (group, field) in FIELDS.items()}
    except KeyError as error:
        raise ValueError('missing input') from error
    if any(not isinstance(command[k], str) or not command[k] for k in ('rental_id', 'equipment_id', 'customer_id')):
        raise ValueError('invalid identity')
    if any(type(command[k]) is not int for k in ('start', 'end', 'accepted_at')):
        raise ValueError('invalid time')
    if command['start'] >= command['end']:
        raise ValueError('empty period')
    return command


class ReservationStore:
    def __init__(self) -> None:
        self.rows: dict[str, dict] = {}

    def reserve(self, command: dict) -> dict:
        if command['rental_id'] in self.rows:
            raise ValueError('duplicate rental')
        if any(row['equipment_id'] == command['equipment_id'] and
               command['start'] < row['end'] and row['start'] < command['end']
               for row in self.rows.values()):
            raise ValueError('overlap')
        self.rows[command['rental_id']] = deepcopy(command)
        return {'type': 'ReservationConfirmed', **deepcopy(command)}


def project(event: dict) -> dict:
    if event.get('type') != 'ReservationConfirmed':
        raise ValueError('unsupported event')
    try:
        row = {field: event[field] for field in FIELDS}
        row['duration'] = event['end'] - event['start']
    except KeyError as error:
        raise ValueError('missing event source') from error
    return row


def trace(operation: dict, command: dict, event: dict, view: dict) -> dict:
    if set(view) != set(VIEW_FIELDS):
        raise ValueError('view has untraced or missing field')
    paths = {}
    for field, (group, key) in FIELDS.items():
        try:
            values = [operation[group][key], command[field], event[field], view[field]]
        except KeyError as error:
            raise ValueError('broken lineage') from error
        if not all(value == values[0] for value in values):
            raise ValueError('lineage value mismatch')
        paths[field] = [f'input.{group}.{key}', f'command.{field}', f'event.{field}', f'view.{field}']
    if view['duration'] != event['end'] - event['start']:
        raise ValueError('duration formula mismatch')
    paths['duration'] = {'sources': [paths['start'], paths['end']], 'rule': 'end - start'}
    return paths


def check(name: str, actual: object, expected: object) -> None:
    passed = actual == expected
    print(json.dumps({'scenario': name, 'actual': actual, 'expected': expected, 'pass': passed}, ensure_ascii=False))
    if not passed:
        raise AssertionError(name)


def rejected(action) -> bool:
    try:
        action()
    except ValueError:
        return True
    return False


def main() -> None:
    fixture = json.loads((Path(__file__).resolve().parents[2] / 'models/21/fixture.json').read_text())
    operation = fixture['operation']
    store = ReservationStore()
    command = command_from(operation)
    event = store.reserve(command)
    view = project(event)
    check('submit-produces-event', event['type'], 'ReservationConfirmed')
    check('screen-shows-input-and-context', view, fixture['expected_view'])
    lineage = trace(operation, command, event, view)
    check('all-seven-view-fields-traced', sorted(lineage), sorted(VIEW_FIELDS))
    # Actual paths are captured, not just a count or static diagram.
    check('customer-session-lineage', lineage['customer_id'],
          ['input.session.customer_id', 'command.customer_id', 'event.customer_id', 'view.customer_id'])
    before = deepcopy(store.rows)
    check('refresh-same-view', project(event), view)
    check('refresh-does-not-write-reservation', store.rows, before)
    altered = deepcopy(operation)
    altered['ui'].update(rental_id='R2', start=12, end=15)
    changed_command = command_from(altered)
    changed_event = store.reserve(changed_command)
    changed_view = project(changed_event)
    trace(altered, changed_command, changed_event, changed_view)
    check('adjacent-new-input-changes-duration', changed_view['duration'], 3)
    conflict = deepcopy(operation)
    conflict['ui'].update(rental_id='R3', start=11, end=13)
    check('overlap-rejects-command', rejected(lambda: store.reserve(command_from(conflict))), True)
    check('rejected-command-preserves-two-rows', sorted(store.rows), ['R1', 'R2'])
    missing = deepcopy(operation)
    del missing['session']['customer_id']
    check('missing-session-rejects-input', rejected(lambda: command_from(missing)), True)
    orphan = dict(view, deposit=100)
    check('orphan-deposit-rejects-lineage', rejected(lambda: trace(operation, command, event, orphan)), True)
    incomplete = dict(event)
    del incomplete['accepted_at']
    check('missing-event-field-rejects-projection', rejected(lambda: project(incomplete)), True)
    forged = dict(view, customer_id='C999')
    check('present-but-wrong-value-rejects-lineage', rejected(lambda: trace(operation, command, event, forged)), True)
    wrong_duration = dict(view, duration=999)
    check('wrong-derived-value-rejects-lineage', rejected(lambda: trace(operation, command, event, wrong_duration)), True)
    # Persistence authority is the state table; mutating an emitted copy cannot change it.
    event['end'] = 99
    check('event-copy-is-not-state-authority', store.rows['R1']['end'], 12)


if __name__ == '__main__':
    main()
