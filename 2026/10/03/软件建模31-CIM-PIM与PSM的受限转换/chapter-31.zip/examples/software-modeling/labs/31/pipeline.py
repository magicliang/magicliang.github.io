import argparse
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(BASE / 'labs/30'))
from toolkit import generate_python, parse_model, validate_equipment_contract

STATE_SYMBOLS = {'待检': 'INSPECTION_REQUIRED', '在役': 'ACTIVE', '退役': 'RETIRED'}
OPERATION_SYMBOLS = {'验收通过': 'approveInspection', '送检': 'requireInspection', '退役': 'retire'}
DECISIONS = {'runtime': 'Python>=3.10', 'state': 'str', 'dispatch': 'dict_tuple_key',
             'invalid_operation': 'ValueError:OPERATION_NOT_ALLOWED', 'persistence': 'caller_owned'}


class MappingError(ValueError):
    pass


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise MappingError(f'duplicate CIM key: {key}')
        result[key] = value
    return result


def _non_json(value):
    raise MappingError(f'non-JSON constant: {value}')


def _fields(value, expected, path):
    if not isinstance(value, dict) or set(value) != set(expected):
        raise MappingError(f'{path}: exact fields required')


def _text(value, path):
    if not isinstance(value, str) or not value.strip():
        raise MappingError(f'{path}: nonblank text required')
    return value


def _symbol(table, value, path):
    _text(value, path)
    if value not in table:
        raise MappingError(f'{path}: unsupported term {value}')
    return table[value]


def load_cim(text):
    return json.loads(text, object_pairs_hook=_object, parse_constant=_non_json)


def cim_to_pim(cim):
    _fields(cim, ['version', 'name', 'initial', 'terminal', 'rules', 'context'], '$')
    if type(cim['version']) is not int or cim['version'] != 1:
        raise MappingError('$.version: only integer 1 supported')
    if not isinstance(cim['terminal'], list) or not isinstance(cim['rules'], list) or not cim['rules']:
        raise MappingError('terminal and nonempty rules must be arrays')
    _fields(cim['context'], ['purpose', 'actors', 'authorization', 'response_goal'], '$.context')
    mapping, losses, transitions, ids = [], [], [], set()
    initial = _symbol(STATE_SYMBOLS, cim['initial'], '$.initial')
    terminal = [_symbol(STATE_SYMBOLS, term, '$.terminal') for term in cim['terminal']]
    mapping.extend([{'source': '$.initial', 'target': '$.initial', 'value': initial},
                    {'source': '$.terminal', 'target': '$.terminal', 'value': terminal}])
    for index, rule in enumerate(cim['rules']):
        path = f'$.rules[{index}]'
        _fields(rule, ['id', 'before', 'action', 'after', 'statement'], path)
        identity = _text(rule['id'], path + '.id')
        if identity in ids:
            raise MappingError(f'{path}.id: duplicate requirement')
        ids.add(identity)
        transition = {'from': _symbol(STATE_SYMBOLS, rule['before'], path + '.before'),
                      'operation': _symbol(OPERATION_SYMBOLS, rule['action'], path + '.action'),
                      'to': _symbol(STATE_SYMBOLS, rule['after'], path + '.after')}
        transitions.append(transition)
        mapping.append({'requirement': identity, 'source': path, 'target': f'$.transitions[{index}]',
                        'rule': 'explicit-vocabulary-substitution', 'value': transition})
        losses.append({'source': path + '.statement', 'value': _text(rule['statement'], path + '.statement'),
                       'disposition': 'retained-in-ledger-only',
                       'reason': 'Prose is not parsed; reviewed before/action/after fields are authoritative.'})
    for key, value in cim['context'].items():
        if key == 'actors':
            if not isinstance(value, list) or not value:
                raise MappingError('$.context.actors: nonempty array required')
            for actor in value:
                _text(actor, '$.context.actors')
        else:
            _text(value, '$.context.' + key)
        losses.append({'source': '$.context.' + key, 'value': value,
                       'disposition': 'not-implemented',
                       'reason': 'Lifecycle FSM has no purpose, actor, authorization, or response-time semantics.'})
    raw = {'version': 1, 'name': cim['name'], 'states': list(STATE_SYMBOLS.values()),
           'initial': initial, 'terminal': terminal, 'operations': list(OPERATION_SYMBOLS.values()),
           'transitions': transitions}
    model = parse_model(json.dumps(raw))
    validate_equipment_contract(model)
    mapping.append({'source': '$.name', 'target': '$.name', 'value': model.name})
    mapping.append({'source': 'converter-v1 vocabulary', 'target': '$.states/$.operations',
                    'value': {'states': list(model.states), 'operations': list(model.operations)}})
    return model, mapping, losses


def pim_to_psm(model):
    validate_equipment_contract(model)
    return {'psm_version': 1, 'target': 'python-table-v1', 'decisions': dict(DECISIONS),
            'model': model.as_dict()}


def psm_to_python(psm):
    _fields(psm, ['psm_version', 'target', 'decisions', 'model'], '$psm')
    if type(psm['psm_version']) is not int or psm['psm_version'] != 1:
        raise MappingError('unsupported PSM version')
    if psm['target'] != 'python-table-v1' or psm['decisions'] != DECISIONS:
        raise MappingError('unsupported platform decision')
    model = parse_model(json.dumps(psm['model']))
    validate_equipment_contract(model)
    return generate_python(model)


def transform(cim, output):
    model, mapping, losses = cim_to_pim(cim)
    psm = pim_to_psm(model)
    source = psm_to_python(psm)
    mapping.append({'stage': 'PIM_TO_PSM', 'source': 'pim:$.initial',
                    'target': 'psm:$.model.initial', 'implementation': 'equipment_runtime.py:INITIAL'})
    for index, transition in enumerate(model.transitions):
        mapping.append({'stage': 'PIM_TO_PSM', 'source': f'pim:$.transitions[{index}]',
                        'target': f'psm:$.model.transitions[{index}]',
                        'implementation': 'equipment_runtime.py:TRANSITIONS',
                        'key': [transition.from_state, transition.operation], 'value': transition.to_state})
    mapping.append({'stage': 'PLATFORM_BINDING', 'source': 'python-table-v1 mapping policy',
                    'target': 'psm:$.decisions', 'value': dict(DECISIONS)})
    losses.append({'source': 'pim:$.states/$.terminal/$.operations',
                   'value': {'states': list(model.states), 'terminal': list(model.terminal),
                             'operations': list(model.operations)},
                   'disposition': 'not-emitted-as-runtime-metadata',
                   'reason': 'Module keeps INITIAL/TRANSITIONS; runtime ValueError omits structured ModelError code/path.'})
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    for filename, value in [('pim.json', model.as_dict()), ('mapping.json', mapping),
                            ('loss-ledger.json', losses), ('psm.json', psm)]:
        (output / filename).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (output / 'equipment_runtime.py').write_text(source, encoding='utf-8')
    return model, psm


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--cim', type=Path, default=BASE / 'models/31/requirements.json')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    model, _ = transform(load_cim(args.cim.read_text(encoding='utf-8')), args.output)
    print(json.dumps({'transformed': model.name, 'transitions': len(model.transitions),
                      'output': str(args.output)}, ensure_ascii=False))
