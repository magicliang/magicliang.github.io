#!/usr/bin/env python3
"""Two in-process boundary candidates, not a microservice deployment."""
from dataclasses import dataclass
import json
from pathlib import Path


@dataclass
class Settlement:
    due: int
    paid: int = 0

    def pay(self, amount: int) -> None:
        if type(amount) is not int or amount <= 0 or amount > self.due - self.paid:
            raise ValueError('invalid payment')
        self.paid += amount

    def completed(self) -> bool:
        return self.paid == self.due


@dataclass
class UnifiedOperations:
    """Candidate A: rental and inspection use one explicit equipment model."""
    returned: bool = False
    repaired: bool = False
    inspected: bool = False

    def receive_return(self) -> None:
        self.returned = True

    def finish_repair(self) -> None:
        if not self.returned:
            raise ValueError('equipment not returned')
        self.repaired = True

    def approve_inspection(self) -> None:
        if not self.repaired:
            raise ValueError('repair incomplete')
        self.inspected = True

    def rentable(self) -> bool:
        return self.returned and self.inspected


@dataclass
class RentalContext:
    """Candidate B: rental holds a translated release fact, not repair details."""
    equipment_id: str
    returned: bool = False
    released: bool = False

    def receive_return(self) -> dict:
        self.returned = True
        return {'kind': 'EquipmentReturned', 'equipment_id': self.equipment_id}

    def accept_release(self, message: dict) -> None:
        if message != {'kind': 'EquipmentReleased', 'equipment_id': self.equipment_id}:
            raise ValueError('unrecognized release fact')
        self.released = True

    def rentable(self) -> bool:
        return self.returned and self.released


@dataclass
class MaintenanceContext:
    equipment_id: str
    received: bool = False
    repaired: bool = False
    inspected: bool = False

    def accept_return(self, message: dict) -> None:
        if message != {'kind': 'EquipmentReturned', 'equipment_id': self.equipment_id}:
            raise ValueError('unrecognized return fact')
        self.received = True

    def finish_repair(self) -> None:
        if not self.received:
            raise ValueError('equipment not received')
        self.repaired = True

    def approve_inspection(self) -> dict:
        if not self.repaired:
            raise ValueError('repair incomplete')
        self.inspected = True
        return {'kind': 'EquipmentReleased', 'equipment_id': self.equipment_id}


@dataclass
class NaiveSharedCompletion:
    status: str = 'OPEN'

    def receive_return(self) -> None:
        self.status = 'COMPLETED'

    def rentable(self) -> bool:
        return self.status == 'COMPLETED'

    def settled(self) -> bool:
        return self.status == 'COMPLETED'


def check(name: str, actual: object, expected: object) -> None:
    passed = actual == expected
    print(json.dumps({'scenario': name, 'actual': actual, 'expected': expected, 'pass': passed}, ensure_ascii=False))
    if not passed:
        raise AssertionError(name)


def rejected(action) -> bool:
    try:
        action()
    except ValueError:
        return True
    return False


def main() -> None:
    f = json.loads((Path(__file__).resolve().parents[2] / 'models/22/fixture.json').read_text())
    a = UnifiedOperations()
    b = RentalContext(f['equipment_id'])
    maintenance = MaintenanceContext(f['equipment_id'])
    bill_a, bill_b = Settlement(f['due']), Settlement(f['due'])
    trace_a, trace_b = [], []
    def snapshot() -> None:
        trace_a.append([a.returned, a.repaired, a.rentable(), bill_a.completed(), bill_a.due-bill_a.paid])
        trace_b.append([b.returned, maintenance.repaired, b.rentable(), bill_b.completed(), bill_b.due-bill_b.paid])
    check('A-premature-inspection-rejected', rejected(a.approve_inspection), True)
    check('B-premature-inspection-rejected', rejected(maintenance.approve_inspection), True)
    a.receive_return()
    maintenance.accept_return(b.receive_return())
    snapshot()
    check('returned-is-neither-ready-nor-settled', trace_a[-1], [True, False, False, False, 120])
    check('B-return-does-not-close-billing', trace_b[-1], trace_a[-1])
    # Wrong shared status collapses three distinct completion predicates.
    naive = NaiveSharedCompletion()
    naive.receive_return()
    naive_ready = naive.rentable()
    naive_settled = naive.settled()
    check('global-completed-produces-false-availability', [naive_ready, a.rentable()], [True, False])
    check('global-completed-produces-false-settlement', [naive_settled, bill_a.completed()], [True, False])
    a.finish_repair()
    maintenance.finish_repair()
    snapshot()
    check('repair-complete-still-awaits-inspection', trace_b[-1], [True, True, False, False, 120])
    check('ambiguous-completed-message-rejected', rejected(lambda: b.accept_release({'status':'COMPLETED'})), True)
    check('foreign-equipment-release-rejected', rejected(lambda: b.accept_release({'kind':'EquipmentReleased','equipment_id':'E9'})), True)
    check('rejected-message-does-not-release', b.rentable(), False)
    a.approve_inspection()
    release = maintenance.approve_inspection()
    b.accept_release(release)
    snapshot()
    check('inspection-releases-equipment-not-debt', trace_b[-1], [True, True, True, False, 120])
    for amount in f['payments']:
        bill_a.pay(amount)
        bill_b.pay(amount)
        snapshot()
    check('partial-payment-is-not-completion', trace_b[-2], [True, True, True, False, 70])
    check('full-payment-completes-only-settlement', trace_b[-1], [True, True, True, True, 0])
    check('both-boundaries-preserve-entire-business-trace', trace_b, trace_a)
    check('trace-matches-independent-fixture', trace_a, f['expected_trace'])
    check('overpayment-rejected', rejected(lambda: bill_b.pay(1)), True)
    check('rejected-payment-keeps-balance', bill_b.due-bill_b.paid, 0)


if __name__ == '__main__':
    main()
