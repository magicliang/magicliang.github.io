#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
java_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}java
javac_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}javac
"$java_cmd" -version
"$javac_cmd" -version
build=$(mktemp -d)
trap 'rm -rf "$build"' EXIT
"$javac_cmd" --release 21 -Xlint:all -Werror -d "$build" "$root/rental-core/RentalDesk.java" "$root/labs/00/BaselineCheck.java" "$root/labs/25/ReservationCalendar.java" "$root/labs/25/AggregateCheck.java"
"$java_cmd" -ea -cp "$build" rental.BaselineCheck
"$java_cmd" -ea -cp "$build" rental.domain.AggregateCheck "$@"
