from dataclasses import dataclass
from pathlib import Path
import json
import platform


@dataclass(frozen=True)
class Period:
    start: int
    end: int

    def __post_init__(self):
        if type(self.start) is not int or type(self.end) is not int or not 0 <= self.start < self.end <= 24:
            raise ValueError("invalid UTC teaching-day period")

    def overlaps(self, other):
        return self.start < other.end and other.start < self.end


@dataclass(frozen=True)
class Parties:
    lessee: str
    collector: str
    payer: str

    def __post_init__(self):
        if any(not isinstance(value, str) or not value.strip() for value in (self.lessee, self.collector, self.payer)):
            raise ValueError("explicit nonblank party roles required")

    def invoice_recipient(self):
        return self.lessee


@dataclass(frozen=True)
class Asset:
    fit: bool
    booked: tuple

    def can_reserve(self, period):
        return self.fit and not any(period.overlaps(existing) for existing in self.booked)


@dataclass(frozen=True)
class SettlementFacts:
    fee: int
    discount: int
    received: int
    refunded: int

    def __post_init__(self):
        if any(type(n) is not int or n < 0 for n in (self.fee, self.discount, self.received, self.refunded)):
            raise ValueError("nonnegative CNY minor units required")
        if self.discount > self.fee or self.refunded > self.received:
            raise ValueError("adjustment exceeds source amount")

    def reconcile(self):
        outstanding = self.fee - self.discount - self.received + self.refunded
        state = "COLLECTION_DUE" if outstanding > 0 else "REFUND_DUE" if outstanding < 0 else "RECONCILED"
        return state, outstanding


class InitialCandidate:
    @staticmethod
    def invoice_recipient(collector):
        return collector

    @staticmethod
    def available(fit):
        return fit

    @staticmethod
    def settlement(facts):
        return "SETTLED" if facts.received >= facts.fee else "UNSETTLED"


checks = 0


def expect(label, actual, expected):
    global checks
    if actual != expected:
        raise AssertionError(f"{label}: {actual!r} != {expected!r}")
    checks += 1
    print(f"PASS {label} actual={actual}")


def reject(label, operation, message):
    global checks
    try:
        operation()
    except ValueError as error:
        if message not in str(error):
            raise AssertionError(f"wrong error: {error}") from error
        checks += 1
        print(f"REJECT {label}: {error}")
    else:
        raise AssertionError(f"accepted {label}")


def main():
    data = json.loads((Path(__file__).resolve().parents[2] / "models/19/cases.json").read_text())
    print(f"Python {platform.python_version()}; synthetic initial/refined candidates; 2026-10-03 UTC")
    parties = Parties(**data["roles"])
    expect("customer_counterexample", (InitialCandidate.invoice_recipient(parties.collector), parties.invoice_recipient()), ("PERSON-B", "ORG-A"))
    expect("payer_is_not_lessee", parties.payer != parties.invoice_recipient(), True)
    expect("same_person_multiple_roles", Parties("P", "P", "P").invoice_recipient(), "P")
    reject("missing_role", lambda: Parties("ORG-A", " ", "ORG-C"), "party roles")
    asset = Asset(data["asset"]["fit"], tuple(Period(*p) for p in data["asset"]["booked"]))
    expect("availability_counterexample", (InitialCandidate.available(asset.fit), asset.can_reserve(Period(11, 13))), (True, False))
    for case in data["windows"]:
        expect(case["id"], asset.can_reserve(Period(*case["period"])), case["expected"])
    expect("unfit_still_rejected", Asset(False, ()).can_reserve(Period(12, 13)), False)
    expect("released_period_query", Asset(True, ()).can_reserve(Period(11, 13)), True)
    expect("query_preserves_commitment", asset.booked, (Period(10, 12),))
    reject("empty_period", lambda: Period(10, 10), "period")
    for case in data["accounts"]:
        facts = SettlementFacts(**{key: case[key] for key in ("fee", "discount", "received", "refunded")})
        expect(case["id"], facts.reconcile(), tuple(case["expected"]))
        if case["id"] == "discount_after_payment":
            expect("settlement_counterexample", (InitialCandidate.settlement(facts), facts.reconcile()[0]), ("SETTLED", "REFUND_DUE"))
    reject("negative_money", lambda: SettlementFacts(10000, 0, -1, 0), "nonnegative")
    reject("excess_refund", lambda: SettlementFacts(10000, 0, 5000, 5001), "exceeds")
    reject("excess_discount", lambda: SettlementFacts(10000, 10001, 0, 0), "exceeds")
    reject("float_money", lambda: SettlementFacts(100.0, 0, 0, 0), "minor units")
    print(f"PASS 19: {checks} scenarios; 3 witnessed model differences")


if __name__ == "__main__":
    main()
