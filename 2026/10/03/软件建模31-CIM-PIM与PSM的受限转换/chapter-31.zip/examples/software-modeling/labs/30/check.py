import json
from pathlib import Path
from toolkit import ModelError, generate_python, load_model, parse_model, step, validate_equipment_contract

BASE = Path(__file__).resolve().parents[2]


def check(name, actual, expected):
    passed = actual == expected
    print(json.dumps({'scenario':name,'actual':actual,'expected':expected,'pass':passed}))
    if not passed:
        raise AssertionError(name)


def error_of(action):
    try:
        action()
    except ModelError as error:
        return {'code':error.code,'path':error.path}
    raise AssertionError('expected ModelError')


def main():
    model = load_model(BASE/'models/30/equipment.json')
    validate_equipment_contract(model)
    check('parse-valid-model', [model.name,len(model.states),len(model.transitions)], ['EquipmentLifecycle',3,4])
    cases = json.loads((BASE/'models/30/invalid-cases.json').read_text())
    for case in cases:
        raw = (BASE/'models/30/invalid'/case['file']).read_text()
        check(case['name'], error_of(lambda: parse_model(raw)), {'code':case['code'],'path':case['path']})
    state = model.initial
    history = [state]
    for operation in ['approveInspection','requireInspection','approveInspection','retire']:
        state = step(model,state,operation)
        history.append(state)
    check('interpreter-runs-lifecycle', history, ['INSPECTION_REQUIRED','ACTIVE','INSPECTION_REQUIRED','ACTIVE','RETIRED'])
    check('runtime-retired-approval-rejected', error_of(lambda: step(model,state,'approveInspection')), {'code':'OPERATION_NOT_ALLOWED','path':'$.runtime'})
    check('runtime-rejection-keeps-old-state', state, 'RETIRED')
    wrong = load_model(BASE/'models/30/wrong-policy.json')
    check('structurally-valid-policy-retires-on-approval', step(wrong,wrong.initial,'approveInspection'), 'RETIRED')
    check('equipment-contract-rejects-wrong-policy', error_of(lambda: validate_equipment_contract(wrong)), {'code':'EQUIPMENT_CONTRACT','path':'$'})
    source = generate_python(model)
    artifact = BASE/'evidence/30/generated-equipment.py'
    artifact.write_text(source)
    namespace = {}
    exec(compile(artifact.read_text(),str(artifact),'exec'),namespace)
    check('generated-approval-runs', namespace['step'](namespace['INITIAL'],'approveInspection'), 'ACTIVE')
    try:
        namespace['step']('RETIRED','retire')
    except ValueError:
        rejected = True
    else:
        rejected = False
    check('generated-retired-retirement-rejected', rejected, True)
    check('model-roundtrip-preserves-behavior', step(parse_model(json.dumps(model.as_dict())),'ACTIVE','requireInspection'), 'INSPECTION_REQUIRED')
    check('generator-deterministic', generate_python(model)==source, True)


if __name__ == '__main__':
    main()
