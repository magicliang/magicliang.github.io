import copy
import json
from pathlib import Path
import sys
import tempfile

from pipeline import BASE, MappingError, cim_to_pim, load_cim, pim_to_psm, psm_to_python, transform
from toolkit import ModelError, load_model, step

COUNT = 0


def check(name, condition):
    global COUNT
    if not condition:
        raise AssertionError(name)
    COUNT += 1
    print('PASS', name)


def reject(name, action, expected):
    try:
        action()
    except expected as error:
        check(name, True)
        print('REJECTED', type(error).__name__, str(error))
        return
    raise AssertionError('expected rejection: ' + name)


def main():
    cim = load_cim((BASE / 'models/31/requirements.json').read_text(encoding='utf-8'))
    if len(sys.argv) == 2 and sys.argv[1] == 'unsupported-term':
        cim['rules'][0]['action'] = '自动出租'
        cim_to_pim(cim)
        raise AssertionError('unknown term accepted')
    if len(sys.argv) != 1:
        raise ValueError('unknown arguments')
    output = BASE / 'evidence/31/generated'
    model, psm = transform(cim, output)
    check('PIM equals frozen chapter30 fixture', model == load_model(BASE / 'models/30/equipment.json'))
    check('emitted PIM reparses', load_model(output / 'pim.json') == model)
    check('emitted PSM consumed by generator', psm_to_python(json.loads((output / 'psm.json').read_text()))
          == (output / 'equipment_runtime.py').read_text())
    namespace = {}
    exec(compile((output / 'equipment_runtime.py').read_text(), str(output / 'equipment_runtime.py'), 'exec'), namespace)
    state = namespace['INITIAL']
    history = [state]
    for operation in ['approveInspection', 'requireInspection', 'approveInspection', 'retire']:
        state = namespace['step'](state, operation)
        history.append(state)
    check('generated full lifecycle executed', history == ['INSPECTION_REQUIRED', 'ACTIVE', 'INSPECTION_REQUIRED', 'ACTIVE', 'RETIRED'])
    print('OBSERVED generated history=' + json.dumps(history))
    for state in model.states:
        for operation in model.operations:
            try:
                expected = step(model, state, operation)
            except ModelError:
                reject(f'generated rejects {state}/{operation}', lambda s=state, o=operation: namespace['step'](s, o), ValueError)
            else:
                check(f'generated preserves {state}/{operation}', namespace['step'](state, operation) == expected)
    mapping = json.loads((output / 'mapping.json').read_text())
    check('all four requirements traced', {entry.get('requirement') for entry in mapping if 'requirement' in entry} == {'R1', 'R2', 'R3', 'R4'})
    check('all PIM edges traced to target dispatch', len([entry for entry in mapping
          if entry.get('stage') == 'PIM_TO_PSM' and 'key' in entry]) == len(model.transitions))
    losses = json.loads((output / 'loss-ledger.json').read_text())
    check('eight CIM losses plus one platform metadata loss', len(losses) == 9
          and losses[-1]['disposition'] == 'not-emitted-as-runtime-metadata')
    check('authorization not silently implemented', any(entry['source'] == '$.context.authorization'
          and entry['disposition'] == 'not-implemented' for entry in losses))
    changed_context = copy.deepcopy(cim)
    changed_context['context']['authorization'] = '改为双人批准。'
    changed_model, _, changed_losses = cim_to_pim(changed_context)
    check('authorization change invisible in PIM', changed_model == model)
    check('authorization change retained in ledger', changed_losses != cim_to_pim(cim)[2])
    unsupported = copy.deepcopy(psm)
    unsupported['decisions']['persistence'] = 'sqlite'
    reject('unsupported platform decision', lambda: psm_to_python(unsupported), MappingError)
    duplicate = copy.deepcopy(cim)
    duplicate['rules'][1]['id'] = 'R1'
    reject('duplicate requirement id', lambda: cim_to_pim(duplicate), MappingError)
    wrong = copy.deepcopy(cim)
    wrong['rules'][0]['after'] = '退役'
    reject('wrong policy rejected before emission', lambda: cim_to_pim(wrong), ModelError)
    extra = copy.deepcopy(cim)
    extra['invented'] = 'ignored?'
    reject('unknown CIM field is not dropped', lambda: cim_to_pim(extra), MappingError)
    reject('duplicate CIM JSON key', lambda: load_cim('{"version":1,"version":1}'), MappingError)
    with tempfile.TemporaryDirectory() as directory:
        transform(cim, directory)
        check('all emitted artifacts deterministic', all(p.read_bytes() == (Path(directory) / p.name).read_bytes()
                                                       for p in output.iterdir() if p.is_file()))
    check('PSM has explicit Python target', pim_to_psm(model)['target'] == 'python-table-v1')
    print(f'PASS chapter31 checks={COUNT}')


if __name__ == '__main__':
    main()
