"""Hand-written Python projection of chapter24's lifecycle-only contract."""
def step(state: str, operation: str) -> str:
    if state == 'INSPECTION_REQUIRED':
        if operation == 'approveInspection':
            return 'ACTIVE'
        if operation == 'retire':
            return 'RETIRED'
    elif state == 'ACTIVE':
        if operation == 'requireInspection':
            return 'INSPECTION_REQUIRED'
        if operation == 'retire':
            return 'RETIRED'
    raise ValueError('operation not allowed')
