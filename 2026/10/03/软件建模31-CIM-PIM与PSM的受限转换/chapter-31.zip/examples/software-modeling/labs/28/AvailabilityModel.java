package rental.application;

import java.time.Instant;
import rental.RentalDesk.EquipmentId;
import rental.RentalDesk.Period;
import rental.application.RentalApplication.AdmissionPolicy;
import rental.application.RentalApplication.Maintenance;
import rental.application.RentalApplication.Status;
import rental.domain.Equipment;
import rental.domain.RentalPeriodSpecification;
import rental.domain.RentalPeriodSpecification.Result;
import rental.domain.ReservationCalendar;

public final class AvailabilityModel implements AdmissionPolicy {
    public enum Qualification { UNKNOWN, INELIGIBLE, MAINTENANCE_RESTRICTED, QUALIFIED }
    public enum Commitments { FREE, COMMITTED }
    public record Assessment(Qualification qualification, Result timeWindow, Commitments commitments) {
        public boolean available() {
            return qualification == Qualification.QUALIFIED && timeWindow == Result.SATISFIED
                    && commitments == Commitments.FREE;
        }
    }
    private static Qualification qualification(Equipment equipment, Maintenance maintenance) {
        if (equipment == null) return Qualification.UNKNOWN;
        if (equipment.state() != Equipment.State.ACTIVE) return Qualification.INELIGIBLE;
        if (maintenance != Maintenance.RELEASED) return Qualification.MAINTENANCE_RESTRICTED;
        return Qualification.QUALIFIED;
    }
    public Assessment inspect(EquipmentId id, Equipment equipment, Maintenance maintenance, Period period,
                              Instant now, RentalPeriodSpecification specification,
                              ReservationCalendar.Snapshot calendar) {
        boolean committed = calendar.receipts().stream().filter(ReservationCalendar.Receipt::active)
                .map(ReservationCalendar.Receipt::request)
                .anyMatch(request -> request.equipmentId().equals(id) && request.period().overlaps(period));
        return new Assessment(qualification(equipment, maintenance), specification.evaluate(period, now),
                committed ? Commitments.COMMITTED : Commitments.FREE);
    }
    @Override public Status reject(Equipment equipment, Maintenance maintenance, Period period, Instant now,
                                   RentalPeriodSpecification specification) {
        return switch (qualification(equipment, maintenance)) {
            case UNKNOWN -> Status.UNKNOWN_EQUIPMENT;
            case INELIGIBLE -> Status.INELIGIBLE;
            case MAINTENANCE_RESTRICTED -> Status.MAINTENANCE_RESTRICTED;
            case QUALIFIED -> specification.isSatisfiedBy(period, now) ? null : Status.INVALID_PERIOD;
        };
    }
}
