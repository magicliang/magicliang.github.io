from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import json
import platform


OUTPUTS = {"Reserve": {"ReservationConfirmed", "ReservationRejected"},
           "RecordPayment": {"PaymentRecorded"}, "Cancel": {"ReservationCancelled"},
           "OpenRefundReview": {"RefundReviewOpened"}}
POLICY = {"id": "P1", "when": "ReservationCancelled", "condition": "has_recorded_payment", "then": "OpenRefundReview"}


def utc(text):
    stamp = datetime.fromisoformat(text.replace("Z", "+00:00"))
    if stamp.tzinfo is None or stamp.utcoffset() != timezone.utc.utcoffset(stamp):
        raise ValueError("explicit UTC required")
    if stamp.date().isoformat() != "2026-10-03":
        raise ValueError("outside teaching day")
    return stamp


def period(raw):
    if len(raw) != 2 or any(type(n) is not int for n in raw) or not 0 <= raw[0] < raw[1] <= 24:
        raise ValueError("invalid period")
    return tuple(raw)


def overlaps(left, right):
    return left[0] < right[1] and right[0] < left[1]


def validate_board(board):
    if board["policies"] != [POLICY]:
        raise ValueError("unsupported policy subset")
    ids = set()
    previous = None
    for command in board["commands"]:
        if command["id"] in ids or command["id"].startswith("policy:"):
            raise ValueError("duplicate or reserved command id")
        ids.add(command["id"])
        if command["kind"] not in {"Reserve", "RecordPayment", "Cancel"}:
            raise ValueError("unsupported command")
        now = utc(command["at"])
        if previous is not None and now < previous:
            raise ValueError("command time reversed")
        previous = now
    hotspot_ids = set()
    for hotspot in board["hotspots"]:
        if hotspot["id"] in hotspot_ids:
            raise ValueError("duplicate hotspot")
        hotspot_ids.add(hotspot["id"])
        for field in ("question", "owner_role", "evidence_needed"):
            if not isinstance(hotspot.get(field), str) or not hotspot[field].strip():
                raise ValueError(f"missing hotspot {field}")
        if hotspot["status"] != "OPEN" or hotspot["anchor"] not in {"RefundReviewOpened", "ReservationCancelled"}:
            raise ValueError("unsupported hotspot status/anchor")


class Rehearsal:
    def __init__(self):
        self.receipts = {}
        self.active = {}
        self.payments = {}
        self.events = []
        self.commands = []

    def emit(self, kind, command):
        self.events.append({"id": f"E{len(self.events) + 1}", "kind": kind,
                            "at": command["at"], "request": command["request"], "cause": command["id"]})

    def execute(self, command):
        if any(old["id"] == command["id"] for old in self.commands):
            raise ValueError("duplicate command id")
        now = utc(command["at"])
        if self.commands and now < utc(self.commands[-1]["at"]):
            raise ValueError("command time reversed")
        kind, request = command["kind"], command["request"]
        if kind not in OUTPUTS or not isinstance(request, str) or not request.strip():
            raise ValueError("unsupported command or request")
        if kind == "Reserve":
            if command["equipment"] not in {"E1", "E2"}:
                raise ValueError("unknown equipment")
            payload = command["equipment"], period(command["period"])
            old = self.receipts.get(request)
            if old is not None and old[0] != payload:
                raise ValueError("request payload changed")
            self.commands.append(deepcopy(command))
            if old is not None:
                return old[1]
            conflict = any(equipment == payload[0] and overlaps(window, payload[1]) for equipment, window in self.active.values())
            result = "OVERLAP_REJECTED" if conflict else "CONFIRMED"
            self.receipts[request] = payload, result
            if not conflict:
                self.active[request] = payload
            self.emit("ReservationRejected" if conflict else "ReservationConfirmed", command)
            return result
        if kind == "RecordPayment":
            if request not in self.active or type(command["minor"]) is not int or command["minor"] <= 0:
                raise ValueError("active reservation and positive CNY minor units required")
            self.commands.append(deepcopy(command))
            self.payments[request] = self.payments.get(request, 0) + command["minor"]
            self.emit("PaymentRecorded", command)
            return "RECORDED"
        if kind == "Cancel":
            self.commands.append(deepcopy(command))
            if self.active.pop(request, None) is None:
                return False
            self.emit("ReservationCancelled", command)
            if self.payments.get(request, 0) > 0:
                self.execute({"id": "policy:" + command["id"], "kind": "OpenRefundReview",
                              "at": command["at"], "request": request})
            return True
        if not self.events or self.events[-1]["kind"] != "ReservationCancelled" or self.events[-1]["request"] != request or self.payments.get(request, 0) <= 0:
            raise ValueError("refund review needs paid cancellation")
        self.commands.append(deepcopy(command))
        self.emit("RefundReviewOpened", command)
        return "REVIEW_OPENED"


def validate_trace(events, commands):
    causes = {command["id"]: command for command in commands}
    if len(causes) != len(commands):
        raise ValueError("duplicate command id")
    seen, active, paid, pending = set(), set(), set(), set()
    previous = None
    for event in events:
        if event["id"] in seen:
            raise ValueError("duplicate event id")
        seen.add(event["id"])
        cause = causes.get(event["cause"])
        if cause is None or event["kind"] not in OUTPUTS.get(cause["kind"], set()):
            raise ValueError("command/event mismatch")
        now = utc(event["at"])
        if previous is not None and now < previous:
            raise ValueError("event time reversed")
        previous = now
        if now != utc(cause["at"]) or event["request"] != cause["request"]:
            raise ValueError("event cause scope mismatch")
        kind, request = event["kind"], event["request"]
        if kind == "ReservationConfirmed":
            active.add(request)
        elif kind == "PaymentRecorded":
            if request not in active:
                raise ValueError("payment before active reservation")
            paid.add(request)
        elif kind == "ReservationCancelled":
            if request not in active:
                raise ValueError("cancellation before confirmation")
            active.remove(request)
            if request in paid:
                pending.add(request)
        elif kind == "RefundReviewOpened":
            if request not in pending:
                raise ValueError("unexpected refund review")
            pending.remove(request)
    if pending:
        raise ValueError("unresolved synchronous policy obligation")


checks = 0


def expect(label, actual, expected):
    global checks
    if actual != expected:
        raise AssertionError(f"{label}: {actual!r} != {expected!r}")
    checks += 1
    print(f"PASS {label} actual={actual}")


def reject(label, call, message):
    global checks
    try:
        call()
    except ValueError as error:
        if message not in str(error):
            raise AssertionError(f"wrong rejection: {error}") from error
        checks += 1
        print(f"REJECT {label}: {error}")
    else:
        raise AssertionError(f"accepted {label}")


def main():
    board = json.loads((Path(__file__).resolve().parents[2] / "models/20/board.json").read_text())
    print(f"Python {platform.python_version()}; synthetic single-person rehearsal; UTC")
    validate_board(board)
    run = Rehearsal()
    results = [run.execute(command) for command in board["commands"]]
    expect("command_results", results, ["CONFIRMED", "RECORDED", "OVERLAP_REJECTED", True, "CONFIRMED", "OVERLAP_REJECTED", "CONFIRMED"])
    expect("timeline", [f'{e["kind"]}:{e["request"]}' for e in run.events], board["expected_timeline"])
    validate_trace(run.events, run.commands)
    expect("trace_valid", True, True)
    for event in run.events:
        print("EVENT " + json.dumps(event, ensure_ascii=False, sort_keys=True))
    expect("cancelled_replay_does_not_rebook", "A" in run.active, False)
    expect("only_fresh_F_active", sorted(run.active), ["F"])
    expect("replays_do_not_emit_again", len(run.events), 6)
    expect("review_is_not_refund", any(e["kind"] == "RefundCompleted" for e in run.events), False)
    expect("hotspots_stay_open", [h["status"] for h in board["hotspots"]], ["OPEN", "OPEN"])
    for hotspot in board["hotspots"]:
        print("HOTSPOT " + json.dumps(hotspot, ensure_ascii=False, sort_keys=True))
    unpaid = Rehearsal()
    unpaid.execute(board["commands"][0])
    unpaid.execute(board["commands"][3])
    validate_trace(unpaid.events, unpaid.commands)
    expect("unpaid_cancel_no_review", [e["kind"] for e in unpaid.events], ["ReservationConfirmed", "ReservationCancelled"])
    missing_review = [e for e in run.events if e["kind"] != "RefundReviewOpened"]
    reject("omitted_policy_result", lambda: validate_trace(missing_review, run.commands), "policy obligation")
    reversed_time = deepcopy(run.events)
    reversed_time[1], reversed_time[2] = reversed_time[2], reversed_time[1]
    reject("reversed_timeline", lambda: validate_trace(reversed_time, run.commands), "time reversed")
    fake_refund = deepcopy(run.events)
    fake_refund[4]["kind"] = "RefundCompleted"
    reject("invented_refund_fact", lambda: validate_trace(fake_refund, run.commands), "command/event mismatch")
    wrong_cause = deepcopy(run.events)
    wrong_cause[1]["cause"] = "C4"
    reject("wrong_command_cause", lambda: validate_trace(wrong_cause, run.commands), "command/event mismatch")
    missing_question = deepcopy(board)
    missing_question["hotspots"][0]["question"] = ""
    reject("empty_hotspot", lambda: validate_board(missing_question), "hotspot question")
    bad_policy = deepcopy(board)
    bad_policy["policies"][0]["then"] = "RefundCompleted"
    reject("policy_event_as_command", lambda: validate_board(bad_policy), "policy subset")
    changed = deepcopy(board["commands"][4])
    changed.update(id="C8", at="2026-10-03T09:07:00Z", period=[11, 13])
    reject("changed_retry", lambda: run.execute(changed), "payload changed")
    expect("failed_retry_keeps_timeline", len(run.events), 6)
    reject("missing_UTC", lambda: utc("2026-10-03T09:00:00"), "explicit UTC")
    print(f"PASS 20: {checks} scenarios; OPEN hotspots are not business consensus")


if __name__ == "__main__":
    main()
