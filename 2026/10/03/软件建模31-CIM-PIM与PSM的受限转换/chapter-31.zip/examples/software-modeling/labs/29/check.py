import hashlib
import json
from copy import deepcopy
from pathlib import Path
import handwritten
from pipeline import generate, interpret

BASE = Path(__file__).resolve().parents[2]


def check(name, actual, expected):
    passed = actual == expected
    print(json.dumps({'scenario':name,'actual':actual,'expected':expected,'pass':passed}))
    if not passed:
        raise AssertionError(name)


def outcome(fn, state, operation):
    try:
        return fn(state, operation)
    except ValueError:
        return 'REJECT'


def main():
    model_path = BASE/'models/29/equipment.json'
    model = json.loads(model_path.read_text())
    cases = json.loads((BASE/'models/29/contract-cases.json').read_text())
    generated = generate(model)
    artifact = BASE/'evidence/29/generated-equipment.py'
    artifact.write_text(generated)
    namespace = {}
    exec(compile(artifact.read_text(), str(artifact), 'exec'), namespace)
    for case in cases:
        state, operation, expected = case
        values = [outcome(handwritten.step, state, operation),
                  outcome(lambda s,o: interpret(model,s,o), state, operation),
                  outcome(namespace['step'], state, operation)]
        check(f'matrix:{state}:{operation}', values, [expected]*3)
    state = model['initial']
    trace = [state]
    for operation in ['approveInspection','requireInspection','approveInspection','retire']:
        state = namespace['step'](state, operation)
        trace.append(state)
    check('generated-lifecycle-trace', trace, ['INSPECTION_REQUIRED','ACTIVE','INSPECTION_REQUIRED','ACTIVE','RETIRED'])
    check('deterministic-generation', generate(model), generated)
    changed = deepcopy(model)
    changed['transitions'] = [e for e in changed['transitions'] if not (e['from']=='ACTIVE' and e['operation']=='retire')]
    check('changed-model-interpreter-rejects-retire', outcome(lambda s,o: interpret(changed,s,o),'ACTIVE','retire'), 'REJECT')
    check('old-generated-artifact-still-allows-retire', outcome(namespace['step'],'ACTIVE','retire'), 'RETIRED')
    refreshed = {}
    exec(compile(generate(changed), '<regenerated>', 'exec'), refreshed)
    check('regenerated-artifact-observes-removed-edge', outcome(refreshed['step'],'ACTIVE','retire'), 'REJECT')
    check('handwritten-contract-detects-model-drift', outcome(handwritten.step,'ACTIVE','retire'), 'RETIRED')
    invalid = deepcopy(model)
    invalid['transitions'].append({'from':'RETIRED','operation':'approveInspection','to':'ACTIVE'})
    check('unchecked-model-can-violate-domain-contract',
          [outcome(lambda s,o: interpret(invalid,s,o),'RETIRED','approveInspection'),outcome(handwritten.step,'RETIRED','approveInspection')],
          ['ACTIVE','REJECT'])
    paths = [model_path, Path(__file__).resolve().with_name('handwritten.py'), Path(__file__).resolve().with_name('pipeline.py'), artifact]
    (BASE/'evidence/29/artifact-chain.json').write_text(json.dumps({str(p.relative_to(BASE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},indent=2)+'\n')


if __name__ == '__main__':
    main()
