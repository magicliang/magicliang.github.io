"""Trusted chapter29 fixture only; public-input validation belongs to chapter30."""
import hashlib
import json


def interpret(model: dict, state: str, operation: str) -> str:
    for edge in model['transitions']:
        if edge['from'] == state and edge['operation'] == operation:
            return edge['to']
    raise ValueError('operation not allowed')


def generate(model: dict) -> str:
    digest = hashlib.sha256(json.dumps(model, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    table = {(edge['from'], edge['operation']): edge['to']
             for edge in sorted(model['transitions'], key=lambda e: (e['from'], e['operation']))}
    return (f'# Generated from equipment model sha256={digest}\n'
            f'INITIAL = {model["initial"]!r}\nTRANSITIONS = {table!r}\n\n'
            'def step(state: str, operation: str) -> str:\n'
            '    try:\n        return TRANSITIONS[(state, operation)]\n'
            "    except KeyError as error:\n        raise ValueError('operation not allowed') from error\n")
