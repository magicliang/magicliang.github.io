# 20：合成事件时间线

从仓库根目录或下载包解压根目录执行：

```bash
bash examples/software-modeling/labs/20/run.sh
```

Python标准库；仅读取`examples/software-modeling/models/20/board.json`，不导入其他章节。18项断言通过exit0；事件时间倒退、原因错误、政策结果缺失等负例未被拒绝则非零退出。逐条EVENT/HOTSPOT输出与最终结果保留在`examples/software-modeling/evidence/20/output.txt`。

这是单人合成材料的程序演练，非真实多人工作坊、通用EventStorming语法检查器或事件溯源框架。只支持代码所列命令/事件和P1同步政策；两个未决热点保留OPEN。详见本章semantics.md及SOURCES.md。
