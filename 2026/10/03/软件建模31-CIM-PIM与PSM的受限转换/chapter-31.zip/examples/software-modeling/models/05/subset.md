# 05 可检查的图记法子集

来源：OMG UML 2.5.1 第11章类/关联、第17章交互。图由 Mermaid 表达，非完整 UML 或 XMI。

classes.mmd 的操作行固定为 `+method(Type,Type) ReturnType`，类型使用本图短名；Map 使用擦除后的 Object。检测公开方法的名称和参数类型是否在编译后的实际类存在，并精确比较反射返回类型；boolean 映射原始类型，其他类型取本图对应 Class。不检查完整泛型、可见性变化、继承规则或所有 UML 约束。Receipt 为当前 RentalDesk 的私有嵌套 record，展示内部视角，不是对外 API。

cancel-replay.mmd 的 `participant id as Type` 把生命线映射到类。`actor caller` 是外部调用方，不映射 Java 类型。`->>` 为被检查的同步调用，标签必须是方法签名；`-->>` 返回标签、Note 内容不作方法解析。每个端点必须先声明；调用的接收者必须提供类图里声明的该签名，并经反射核对实际 Java 方法。只验证该受限输入格式，不是通用 Mermaid/UML 解析器。

关联检查只接受图中的六条关系，每条必须恰好出现一次；重复行、额外冲突关系或未知关系均拒绝。实际反射核对 RentalDesk.receipts/bookings 的 Map 泛型值类型，以及 Receipt/ReserveRequest 的 record component 类型。共享 ReserveRequest、Period 和 ID 可被多个持有者引用，因此反向多重性为 0..*；内部新建 Receipt 归一个 desk。目标 1 的必填构造校验由当前 core 源码与运行输入断言核对。Map 本身也画出以匹配生命线；图中两条 desk 关联是集合值关系，不声称每条关联都是一个独立 Java 字段对象。

前置状态由 executable behaviorProbe 建立：A E1 [2026-10-03T10:00Z,12:00Z) 确认，然后取消、重放，再提交新 F 同设备同租期。F 必须确认，作为重放未重新占位的外部探针。相邻请求与完整冲突覆盖沿用 00/04。本篇没有实现调用跟踪器；静态消息核对和运行状态结果是两份不同证据。

负例从真实图文本复制并分别删除 previous 接收者声明、把 outcome() 改成 refund()、改动 bookings 的多重性，以及追加冲突关联、未知 Ghost 关联、重复关联和把 cancel 的 boolean 返回类型改成 Outcome。七个变化必须分别被相应检查拒绝。单独校验入口允许传入两个模型文件：`run.sh path/to/classes.mmd path/to/sequence.mmd`；不合规退出非零。默认运行检查全部正反例。
