PRAGMA foreign_keys = ON;
CREATE TABLE account (id TEXT PRIMARY KEY, currency TEXT NOT NULL);
CREATE TABLE fact (
  id TEXT PRIMARY KEY, kind TEXT NOT NULL, currency TEXT NOT NULL,
  amount_minor INTEGER NOT NULL CHECK(amount_minor > 0), occurred_at TEXT NOT NULL
);
CREATE TABLE journal (
  id TEXT PRIMARY KEY, fact_id TEXT NOT NULL REFERENCES fact(id),
  reverses TEXT UNIQUE REFERENCES journal(id)
);
CREATE TABLE entry (
  journal_id TEXT NOT NULL REFERENCES journal(id), ordinal INTEGER NOT NULL,
  account_id TEXT NOT NULL REFERENCES account(id), amount_minor INTEGER NOT NULL,
  PRIMARY KEY(journal_id, ordinal)
);
CREATE TRIGGER entry_no_update BEFORE UPDATE ON entry BEGIN SELECT RAISE(ABORT, 'immutable entry'); END;
CREATE TRIGGER entry_no_delete BEFORE DELETE ON entry BEGIN SELECT RAISE(ABORT, 'immutable entry'); END;
CREATE TRIGGER journal_no_update BEFORE UPDATE ON journal BEGIN SELECT RAISE(ABORT, 'immutable journal'); END;
CREATE TRIGGER journal_no_delete BEFORE DELETE ON journal BEGIN SELECT RAISE(ABORT, 'immutable journal'); END;
CREATE TRIGGER fact_no_update BEFORE UPDATE ON fact BEGIN SELECT RAISE(ABORT, 'immutable fact'); END;
CREATE TRIGGER fact_no_delete BEFORE DELETE ON fact BEGIN SELECT RAISE(ABORT, 'immutable fact'); END;
