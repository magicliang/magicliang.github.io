# 13 教学账本

来源：Fowler 2005-01-22 的 Accounting Entry / Accounting Transaction 草稿。原书将 Account/Entry 放在同一模式；此处引用后来的分篇草稿，不冒充原书逐字定义。至少两条分录且有符号金额合计零。

独立 Python/SQLite 实验，不修改 Java 租赁基线。Fact 是已登记费用/收款/折扣/退款/冲正事实的夹具，occurred_at 固定 UTC；不自动计算报价、不接付款网关，不证明事件真伪或外部支付完成。Account 是按币种分类的累计视角；Entry 是账户上的带符号变化；Journal 将一组 Entry 关联到 Fact。

教学符号：receivable/cash 增加记正，revenue 的对应增加记负。不输出借贷借记术语、不提供会计科目表或合规解释。CNY/USD 只接收精确到分、有限且绝对额不超过10亿的十进制输入，转为整数分；不隐式舍入、换汇。每个 journal 至少两条非零 entry、同一币种、合计零、正项合计等于原事实金额。

费用F1=120 → T1；冲正T1-R反向复制T1且保留原分录；正确费用F2=100 → T2；收款P1=100 → T3；折扣D1=25 → T4；退款R1=25 → T5。最终cash=7500、receivable=0、revenue=-7500分。业务规则和符号是合成教学选择，不是Fowler规定的租赁入账政策。

entry/journal/fact 的UPDATE/DELETE由SQLite trigger拒绝；追加INSERT仍可能绕过业务入口。唯一journal id拒绝重复，不沿用reserve的同ID重放；unique reverses拒绝二次冲正同原事务。Fact可关联多个journal，没有业务事件幂等性/授权/篡改防护保证。

post先验证，再用SQLite事务将header及entries写入；第一条entry后故障注入验证全部回滚。另一独立连接绕过post直接事务提交单条entry，实际不平衡但提交成功，区分数据库原子性与会计零和。无并发、文件持久化、进程崩溃或对账外部数据实验。
