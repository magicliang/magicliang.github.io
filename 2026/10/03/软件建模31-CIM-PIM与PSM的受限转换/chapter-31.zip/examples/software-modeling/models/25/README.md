# 25：聚合边界实验

真实候选与 API 见 [contracts.md](contracts.md)。图1是受控双线程的错误交错；图2是正确候选的状态边界。Mermaid 文件与正文图逐字同步，非自动证明。

仓库根入口：`JAVA_HOME=/path/to/jdk21 examples/software-modeling/labs/25/run.sh`。

反例入口：`JAVA_HOME=/path/to/jdk21 examples/software-modeling/labs/25/run.sh require-broken-safe`，预期退出1。

下载包应保留 `examples/software-modeling/` 路径前缀，包含 rental-core/RentalDesk.java、labs/00/BaselineCheck.java、labs/25、models/25、evidence/25。仅 Java 21 标准库；临时编译目录执行后清除。

证据边界：实际线程与共享内存、同步方法、快照往返；无数据库、分布式协调、吞吐或公平性测试。当前同步粒度覆盖日历内所有设备。
