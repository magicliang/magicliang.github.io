# 28：可用性模型与保持行为的重构

`labs/28/AvailabilityModel.java` 以27 AdmissionPolicy为接入点，实际供同一个RentalApplication使用。没有替换仓储、工厂、日历、回执和发布机制。

- Qualification区分UNKNOWN、INELIGIBLE、MAINTENANCE_RESTRICTED、QUALIFIED；与27原有拒绝优先级一致。
- timeWindow使用26 RentalPeriodSpecification.Result；Instant起止、minimumLead=1h/maxDuration=48h不变。
- Commitments按25 Snapshot中同设备active记录与请求半开Period相交判断；历史确认但inactive不构成当前承诺。
- Assessment.available只在三个条件同时满足时true。inspect是给新请求的快照查询，无锁延伸到后续命令，不能授权预留，也不处理RequestId历史回放。
- reject是注入27应用的资格/时间策略，返回对应拒绝或null；承诺冲突仍由同一Repository事务内的25日历reserve决定，不提前消费或绕过日历回执。
- 保留InlineAdmission作为可执行的重构前对照；不是将错误的ACTIVE-only实现说成历史27实现。naiveAvailable只作为新造反例。

运行 `bash examples/software-modeling/labs/28/run.sh`，需要JDK21；先执行00基线和27用例，再比较48条场景轨迹（4设备条件×3维修结果×4时间区间）。每条执行reserve、晚时钟回放、取消seed、再次回放、换IDreserve、取消candidate；比较每一步返回值、全部仓储Snapshot以及最终事件顺序。另7项检查覆盖快照过期、未来承诺、相邻窗口、取消历史与新请求；最终55 checks。

本实验只证明选定有限场景下两种策略的可观察等价，未证明全输入空间或性能改进。没有新增保养缓冲/延期/换设备/价格迁移规则；这些会改变契约，应另建场景，不伪装为纯重构。维护评估的可信来源/时效、持久化、并发与可靠消息仍沿用27限制。
