# 16: Rental activity and document adaptation

Source: publisher chapter5 5.1.1–5.1.2 (project/activity requests and activities), 5.3.1 (template and document), 5.3.2 (document activity). Teaching implementation uses selected distinctions only, not the full original component set or original rental code. Diagram cardinalities are not copied.

Rental(id,party,resource,required_kind,start,end) expresses a confirmed plan, not actual equipment handover. Resource has physical id/kind. Document snapshots resource and interval plus selected Template revision. A new rental chooses current template; revisions of existing rental keep its initial template. This template policy is teaching-specific.

All times are integer UTC hours on one fixture day; half-open intervals. Same resource must not overlap across rental ids. Extension must strictly increase end. Substitution requires known free resource of the declared kind. No substitutes by category without conflict checking. Successful replacement releases old resource's interval by replacing current rental reference; old document snapshots stay.

validate -> construct document -> update both dictionaries is safe against the tested validation exceptions in sequential in-memory use. It is NOT a durable atomic transaction: no concurrency locks, crash recovery, storage, authentication, idempotency receipts, actual operations, quotas or pricing. Unexpected failures between dictionary assignments are not handled.

Naive alternative appends document before conflict validation; rejected extension leaves rental ending11 and latest document ending13. Correct path leaves end11/document-count1 on same input. This real state mismatch demonstrates why semantic color does not choose the consistency boundary.

Dependencies: only own lab script, models/16/fixture.json, bash and Python >=3.10 standard library. No cross-chapter/core dependency.
