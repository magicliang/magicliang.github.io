# 31：受限转换API（供33/34使用）

实现 `labs/31/pipeline.py`，Python>=3.10标准库。直接导入稳定30 toolkit，未复制或修改30实现。导入前把 labs/31 加入 sys.path；pipeline 自己定位同树 labs/30。

- `load_cim(text) -> dict`：JSON加载，拒绝重复键/NaN/Infinity；JSON语法错误为JSONDecodeError，映射输入错误为MappingError(ValueError)。不解析自然语言。
- `cim_to_pim(cim:dict) -> (toolkit.Model,mapping:list,losses:list)`：精确支持requirements.json字段集合、中文固定词汇表和24设备生命周期子集。name进入PIM；初态/终态/四条rule显式映射；规则ID唯一。业务prose是人工整理说明，before/action/after才是转换输入，矛盾prose不会被自动识别。
- `pim_to_psm(model) -> dict`：要求24设备合同，目标唯一为python-table-v1。PSM嵌入完整有限模型及decisions：Python>=3.10、str状态、tuple-key字典、ValueError拒绝未知操作、调用方管理持久化。
- `psm_to_python(psm:dict) -> str`：校验PSM完整字段、版本、唯一目标和全部平台选择，再调用30 parse_model、validate_equipment_contract、generate_python。平台选择不能只修改注释；例如persistence=sqlite被拒绝。输出独立Python模块INITIAL、TRANSITIONS、step，无toolkit运行时依赖。
- `transform(cim,output:Path|str) -> (Model,psm:dict)`：验证全部成功后写pim.json、psm.json、mapping.json、loss-ledger.json、equipment_runtime.py。覆盖同名输出，不提供多文件原子提交、手工改动保留或反向转换。建议空临时目录；不可将不可信路径当作发布目录。

mapping记录CIM条款到PIM边，以及PIM边到PSM嵌入模型/生成TRANSITIONS键。cim_to_pim产生8项损失：4项条款原文（仅保留在账本，不解释）和4项业务环境（目的、人员、授权、响应目标，未实现）。transform再追加1项平台层元数据损失：生成模块只暴露INITIAL/TRANSITIONS，状态/终态/操作声明列表与结构化ModelError诊断没有进入运行时。最终loss-ledger.json共9项。这不是“全需求已实现”的证书。

生成模型等于冻结models/30/equipment.json。范围只有3状态×3操作，测试全部9对及一条4步轨迹，不覆盖24实体身份/快照/描述/金额和27累计Java应用。无MOF/XMI/QVT标准符合性声明，属于说明MDA转换视角的自定义教学链。

## 运行及包依赖

`examples/software-modeling/labs/31/run.sh` 写本章 evidence/31/generated。附加unsupported-term触发MappingError、exit1。入口先检查Python>=3.10；可用PYTHON_BINARY=/path/to/python3指定解释器，默认python3。

单独转换：`python3 examples/software-modeling/labs/31/pipeline.py --cim examples/software-modeling/models/31/requirements.json --output /tmp/modeling31-output`。

正常包依赖 labs/30/toolkit.py、models/30/equipment.json、本章labs/models/evidence。累计30回归需要完整labs/30和models/30；在临时副本运行原run.sh，避免覆盖源树30/evidence。CLI只支持受限模型，无任意Python表达式输入；执行的是已验证模型经过固定模板生成的代码。
