# 10: Quantities and observation facts

Quantity = finite Decimal + known unit; h/min duration and cm/m length conversions only. Unsupported dimensions reject. Decimal division follows Python's default context; this is not unlimited precision or complete unit algebra.
PhenomenonType = name + numeric/unit OR category/allowed-values.
Observation = id + subject + phenomenon + valid_at + recorded_at + either value or missing reason + optional rejection reason.

Numeric observation corresponds to Measurement semantics but is implemented as a validated branch, not a Python subclass. Category observation accepts one of its type's strings. Missing reasons are not-measured or sensor-failed; unexplained null and a simultaneous value/missing reject. Rejection retains the row but excludes it from available results. available filters record cutoff, subject and rejection; it is not a latest-valid-time selector or historical rejection-version query.

Teaching assumptions: actual past observations only; integer UTC hours; recorded_at >= valid_at. No predictions; no medical diagnosis or thresholds. Synthetic P1 height checks structural reuse only. No calibrated instrumentation, uncertainty, measurement protocol, security or database.

Source: Igor Janicijevic and Martin Fowler, UML Diagrams for Chapter 3 of Analysis Patterns (1999), Fig3.2 quantity, Fig3.6 measurement, Fig3.7 category observation, Fig3.11 applicability and recording time, Fig3.12 rejected observation. Device example, missing-reason representation and validation rules are teaching adaptations.
