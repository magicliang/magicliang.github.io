# F02 延长既有预留：设计走查

这是单一执行者在实现前完成的设计自查，非多人会议或独立评审记录。
教学假设：整数表示相对同一起点的日边界，租期半开；已存在预留才允许延期，终点必须严格增加；同设备不能重叠。无费用、交付、授权或数据库。

## 检查对象与修订决定

| 检查项 | 候选方案与问题 | 采纳决定 | 可观察验收 |
|---|---|---|---|
| 同一预留的身份 | 与全部现存区间比较会撞到自己的旧区间 | 用 rental id 排除自身，只比较其他预留 | 单独预留 [1,3) 可延至 5 |
| 交界 | 使用 <= 判交会拒绝与下份预留相邻的区间 | 使用 a.start < b.end 且 b.start < a.end | 下一份 [5,8)，延至 5 成功、6 拒绝 |
| 写入时机 | 先覆盖旧区间再检查会在拒绝后留下变更 | 构造不可变候选，检查完再替换一次 | 冲突前后 snapshot 相等 |
| 身份与归属 | 重建预留时容易改变编号或设备 | dataclasses.replace 只修改 period | id、equipment 保持相等 |
| 旧能力兼容 | 延期代码不应破坏创建和取消 | 保留 baseline 的 reserve/cancel 与回归 | 集成先延期、拒绝冲突、取消再预留 |

## 类责任与接口

Period(start,end)：合法半开区间和 overlaps；Rental(id,equipment,period)：不可变记录；ReservationBook：按 id 管理记录并执行 reserve/cancel/extend。
逻辑责任角色为 interval-owner 与 booking-owner；本次由一个执行者模拟二者自查，不记录虚构出席者或批准者。

`extend(rental_id,new_end) -> Rental`：未知 id 拒绝；等长/缩短拒绝；检查同设备其他预留；成功后更新一次。异常不改变内存记录。没有锁、事务、失败恢复或并发保证。

## 可复跑交付安排

保留 baseline.py 的未实现 extend；同一 acceptance.py 先对 baseline 执行，再对 rental 执行，分别要求真实退出 1 与 0。回归测试后复制所需代码到临时集成目录，校验 SHA-256，运行回归与 cli.py 的 JSON 输入输出。该目录模拟提升到集成构建，不是合并生产分支。
