# 09: Party and temporal responsibility

Party(id, kind): kind is person or organization. Stable id identifies the participant; dataclass equality compares all fields and is not used as entity identity.
Responsibility(id, principal, agent, role, start, end, ended_at): typed directed two-party relation; principal organization -> agent person. Only renter and inspector accepted.

Business assumptions: UTC integer hours on one teaching day; [start,end); role claims are scoped to principal. Multiple responsibilities allowed. Termination makes effective end=ended_at, preserves queries before it, and leaves other roles/principals unchanged. Same termination replay returns same value; conflicting time rejects. This is business-valid-time history only. No transaction time, authorization, cycle checking, global id registry, duplicate appointment prevention, party merge, or persistence.

Cancellation here means ending an appointment; it does not call RentalDesk.cancel and does not release equipment. There is no responsibility-to-booking coupling implemented.

Source mapping: Fowler accountability supplement pp.5–6 Party; pp.17–18 typed two-party relationships. Role validity and termination policy are this series' teaching choices. This uses value records, not a mandatory Role Object implementation.
