# 14 计划、资源与承诺

出处：Fowler站点托管的 Pierre De Swert《UML Diagrams for Chapter 8 of Analysis Patterns》，Fig8.13 ProposedAction books / ImplementedAction uses ResourceAllocation；Fig8.14 General/SpecificResourceAllocation、AssetType/Asset。原图约束相关Quantity使用time units；本实验使用半开时间段加整数设备台数，是显式教学变体，不把原Quantity直接解释为台数。

独立Python内存实验，固定2026-10-03 UTC，整数小时0..24和非空[start,end)。ProposedAction保存意图，构造不会占用；book确认后创建Allocation；implement显式登记ImplementedAction，不以计划或承诺推断真实发生。无真实传感器或交付系统。

General候选：CAM-A同时容量2、PROJECTOR容量1，按重叠边界分段逐段核对数量峰值，不简单相加所有重叠订单。无指定实物、维护日历或容量修订。Specific候选：E1/E2属CAM-A，P1属PROJECTOR；所选实物数等于数量、无重复、类型相符且每台区间不冲突。两种候选是各自独立的ResourceBook实例，不能将两份库存同时出售；没有实现从一般承诺转为具体分配。

请求身份契约沿用00意图：同ID同负载重放原结果；变载荷拒绝；成功和失败回执都保留。cancel仅移除尚无ImplementedAction的活跃分配，取消后重放不重建；旧拒绝需新ID重新尝试。

教学锁定规则：每个承诺至多一条实际执行记录；实际数量<=承诺数量且实际时间包含于承诺期；部分履约保留全部原承诺，取消已登记执行的承诺拒绝。未实现分批交付、提前归还、余量释放、期外实际事件处理或冲销实际记录。此规则不是原图的业务保证。

替换演练是取消原E1请求、以新ID申请E2，并验证E1被释放与旧回执仍在。两步不是原子替换，失败恢复未实现。无多线程、多进程持久化、全局排程、成本优化或任意类型库存算法保证。
