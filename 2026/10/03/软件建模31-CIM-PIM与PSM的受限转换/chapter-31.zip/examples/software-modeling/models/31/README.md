# 31：CIM到Python目标

`requirements.json` 是人工整理的合成业务条款，非自然语言自动理解结果。两张图与正文一致；可复用API见contracts.md。

运行：`examples/software-modeling/labs/31/run.sh`。需要Python>=3.10；如默认python3版本不足，使用 `PYTHON_BINARY=/path/to/python3 examples/software-modeling/labs/31/run.sh`。

负例：入口追加 `unsupported-term`，预期exit1。

五份真实转换产物在evidence/31/generated：pim.json、psm.json、mapping.json、loss-ledger.json、equipment_runtime.py。生成物可覆盖，不支持手改保留或反向还原CIM。

包保留examples/software-modeling前缀，包含labs/30/toolkit.py、models/30/equipment.json及本章labs/models/evidence。如复跑30原入口回归，还需完整labs/30、models/30以及可写evidence/30目录；本次回归在临时副本执行，未写原目录。
