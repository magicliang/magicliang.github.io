# Chapter 07 value model

RentalDesk.Period is reused unchanged: nonempty half-open Instant intervals [start,end), overlap iff a.start < b.end && b.start < a.end.

Independent teaching value types in ValueCheck.java:
- Money: amount plus Currency, canonical scale 2, no implicit rounding. CNY/USD example only; scale 2 is not a universal currency rule. Cross-currency addition rejects. No FX conversion.
- Quantity: BigDecimal value plus hour/piece token; mixed units reject. No conversion, count-integrality or complete dimensional algebra.
- Revision: EquipmentId, version and label are immutable record fields. Entity identity compares id; complete revision equality compares every field. A two-element list retains both revisions. No persistence, revision uniqueness, concurrency control or bitemporal query.
- Calendar experiment: 2026-03-08, America/New_York, local start of day to next start of day. Java's bundled tzdb supplies offsets. Calendar days and elapsed duration are deliberately distinct.

Each behavior is asserted in labs/07/ValueCheck.java. The lab uses no current wall-clock input and contacts no service.
