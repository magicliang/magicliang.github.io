# 08: Pattern selection by scenario

Scope: independent Python teaching experiment; does not extend Java RentalDesk.

Fixed field = one current operating-hours value per equipment.
Fact = subject + phenomenon + value + unit + valid integer UTC hour.
Facts are append-only in this fixture; latest is a maximum valid-hour query. Ties, amendments and record time are not implemented.

Selection policy (explicit teaching assumption): choose fixed field if only one current kind is required; choose observation if historical answers or multiple kinds are required. This is a small decision table, not a universal discovery algorithm.

Scenarios: current answer matches both candidates; overwrite destroys checkout reading; history retains checkout; condition differs from numeric hours; independent synthetic height history transfers the question structure; unrelated subject returns None; 60 min and 1 h need explicit normalization. Cancellation is outside this model and stays with RentalDesk.

Source: Fowler Analysis Patterns book landing page; 1999 UML supplement chapter 3 figures 3.2, 3.6, 3.7. Rental/clinical fixtures and selection policy are original teaching adaptations. No source code/diagrams copied.
