# 12: Valid time and record time

Source mapping: Martin Fowler, Bitemporal History, published 2021-04-07, The Two Dimensions and Using Bitemporality. Article calls the axes actual history and record history; this teaching model uses valid_on and known_at. Price schedule, values and full-snapshot algorithm are original adaptations, not copied salary data or an SQL temporal conformance claim.

One series only: CAM-DAY, CNY integer cents/day. Valid time = calendar date over [2026-01-01,2027-01-01). No implicit conversion between calendar dates and timestamps. Record time = supplied UTC-aware datetime, strictly increasing per appended snapshot. Future valid prices may be recorded ahead of their effective date; do not require valid <= record.

history.json contains three complete valid-time snapshots:
- recorded 2026-01-01T00:00:00Z: all domain at 10000.
- recorded 2026-03-15T00:00:00Z: before Feb15 at 10000, from Feb15 at 8000.
- recorded 2026-04-05T00:00:00Z: before Feb15 at 10000, from Feb15 at 9000.

price_at(valid_on,known_at) chooses the last snapshot recorded <= known_at, then the segment start <= valid_on < end. Implied record interval for each snapshot is [recorded_at,next_recorded_at); final snapshot is open-ended. No old snapshot/end timestamp is overwritten. Before the first record or outside the declared valid domain returns None, not zero.

append validates a nonempty ordered contiguous partition of the whole valid domain before changing the tuple of snapshots. Duplicate/backdated record timestamps reject; late business corrections use current record time with past valid dates. Gaps, overlaps, zero/reversed valid periods reject. This completeness policy is pedagogical, not inherent to all bitemporal systems.

Limits: caller-supplied record clock, immutable records and one-process in-memory API. No persistence, tamper resistance, transaction isolation, multi-writer concurrency, multiple recording organizations, holiday/timezone conversion, invoicing, refunds or automatic financial compensation.
