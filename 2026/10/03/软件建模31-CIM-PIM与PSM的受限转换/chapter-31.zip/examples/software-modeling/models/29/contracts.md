# 29: model-guided / interpreted / generated lifecycle comparison

Input is the lifecycle subset of chapter24's `models/24/contracts.md` and `labs/24/Equipment.java`, inspected directly. `equipment.json` is an explicitly authored projection; `contract-cases.json` enumerates all three states × three operations independently as expected results. Handwritten Python contains explicit branches; interpreter reads transitions; generator writes a standalone Python transition table and step function. Generated code is actually compiled and executed. No 30 runtime import.

Only state transitions are compared. Identity, snapshot restore, changeDescription, money, period, reservation, repositories and application gating are not represented. This does not replace or claim to reverify chapter24 Java tests, nor does it claim completed chapter27 integration.

`pipeline.py` deliberately accepts only the trusted teaching fixture shape. Malformed/untrusted input handling is not its API. Invalid-model experiment appends a retirement exit to demonstrate missing semantic validation; chapter30 supplies an explicit validated API. Do not expose chapter29 interpreter/generator as an untrusted-input service.

`evidence/29/generated-equipment.py` is reproducibly overwritten by run.sh, and artifact-chain.json records source/model/generator/output hashes. Generated output is not an independent truth source. Removal of ACTIVE/retire edge affects interpreter immediately, old generated output only after regeneration; hand-written implementation retains original contract and therefore detects drift.
