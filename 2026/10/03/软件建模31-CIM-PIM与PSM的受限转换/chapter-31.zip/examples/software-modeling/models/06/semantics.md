# Chapter 06 candidate model

Synthetic rental teaching assumptions, separate from RentalDesk baseline:
- One current physical device: AVAILABLE -> HELD -> OUT -> INSPECTION -> AVAILABLE.
- RESERVE/HANDOVER/RETURN/INSPECT trigger the corresponding transitions.
- HELD + TIMEOUT -> AVAILABLE only when now >= deadline.
- HANDOVER requires now < deadline. No late pickup exception.
- A timeout event is explicitly supplied; no scheduler is implemented.
- Historical booking and future interval occupancy are not represented by this physical state.
- Staff roles are labels in a synchronous local trace, not authentication or a BPMN engine.

Quote decision: integer billing days 1..30; 1..7 -> CNY 100/day, 8..30 -> CNY 80/day, whole-rental rate, no progressive tiers. Days are supplied, not derived from clock duration. Exactly one row is a teaching requirement: Unique only provides at most one match in DMN; completeness is extra. No FEEL, DMN XML or conformity claim.

BehaviorCheck.java contains the executable transition function and decision rows. Its mutated overlapping interval starts at 7; its mutated gap interval starts at 9. These variants are expected to be rejected. First-hit order sensitivity is observed separately.

OMG sources: UML 2.5.1 chapter 14; BPMN 2.0.2 8.4.13 (Sequence Flow); DMN 1.5 8.2.11.1 (hit policy). Official source excerpts and retrieval limits are recorded in evidence/06/sources.md.
