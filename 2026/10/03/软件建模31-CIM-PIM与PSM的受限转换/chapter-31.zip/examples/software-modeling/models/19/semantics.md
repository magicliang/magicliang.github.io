# 19：消歧的可观察差异

来源：Eric Evans, DDD Reference (2015-03)，Ubiquitous Language（印刷页3—4）、Refactoring Toward Deeper Insight（印刷页8）。资料为模式摘要，不把它称为2004原书全文。

本章自行构造InitialCandidate作为被反驳的初稿，不是00—18既有实现。独立Python只做查询，不新增reserve/cancel入口、不变更共享Java基线。

| 教学疑问 | 初稿假设 | 改进表达/规则 | 对应行为 |
|---|---|---|---|
| “客户”是取设备的人还是合同承租方？ | customer=collector，账单交给customer | Parties.lessee/collector/payer显式区分，本例账单归承租方 | PERSON-B→ORG-A；角色可相同但不可省略 |
| “可用”是物况合格还是某时段可预留？ | available=fit | Asset.can_reserve(period)=fit且与已有承诺无重叠 | E1物况合格但[11,13)不可预留；[12,13)仍可预留 |
| “结算”是收到原价还是款项已核对？ | received>=fee则SETTLED | reconcile=(fee-discount)-(received-refunded)，区分待收/待退/归零 | 收100减价25尚未退款时为REFUND_DUE -2500；退25后归零 |

规则是合成输入，并非真实业务访谈结论。固定2026-10-03 UTC整数小时[0,24]、非空半开区间。金额为单币种CNY整数分、不含付款网关、费用重算、账本写入、会计或授权保证。reconcile只计算已提供数字，不证明数据齐全。

依赖概念：01场景/回执，06状态不等于区间，09角色，13折扣/退款，14承诺/实际。运行时只读取本章cases.json。迁移歧义客户字段不能靠猜测把同值填入全部角色；需要来源证据，此实验不执行数据库迁移。
