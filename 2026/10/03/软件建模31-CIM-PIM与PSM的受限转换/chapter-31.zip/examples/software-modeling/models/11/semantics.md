# 11: Classification, specification and runtime type objects

Source mapping: Johnson/Woolf, The Type Object Pattern, Intent, Structure/Participants, Collaborations and Consequences, pp.1–5. The source separates application instances from runtime objects describing their common attributes/behavior. This chapter applies the idea to equipment models; versioned service specifications and contract pinning are original teaching choices, not claims about an Analysis Patterns chapter.

Executable fixture: catalog.json. EquipmentType instances describe models; Equipment instances describe physical assets. supports(feature) delegates to the referenced type object. CAM-B is a catalog value, not a new Python class. Category(camera/projector) stays a fixed enum; only catalog instances are configurable. Runtime type objects do not permit arbitrary new operations or a new category without code changes.

Equipment E1/E2 -> CAM-A revision 1; E3 -> CAM-B revision 1. Equipment model revision 2 lists 8k, but E1 remains pinned to revision 1; publishing a catalog revision does not physically upgrade existing units. Unknown categories and camera/projector-service mismatch reject.

ServiceSpec CAM-DAY revision 1: 1..7 integer days, CNY 10000 cents/day. Revision 2: 1..5 integer days, CNY 12000 cents/day. Agreement C1 signs revision 1 for 7 days, before revision 2 is inserted. Its pinned spec and agreed 70000 cents remain unchanged. C2 uses revision 2 for 3 days (36000 cents). Naive latest-rate lookup returns 84000 for C1; full revision-2 validation rejects its seven-day term. Actual service here means a specific signed service agreement, not completed delivery.

Catalog.add rejects duplicate (id,revision). Frozen records reject ordinary field assignment; attributes use immutable tuples. These are API-level safeguards, not immutable audit storage. Direct construction, reflection/private attribute mutation, persistence, concurrency, authorization and physical inspection are outside validation. Equipment and Agreement IDs are fixture identities, not a global uniqueness registry.
