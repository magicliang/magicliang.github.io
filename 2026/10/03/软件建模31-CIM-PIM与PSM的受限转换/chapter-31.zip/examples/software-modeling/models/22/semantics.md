# 22: two context boundary candidates

Problem space: rental/maintenance/settlement subdomains. These are a teaching partition, not a prescribed mapping to deployments.

Candidate A: UnifiedOperations owns returned/repaired/inspected in one coherent equipment-operations model; Settlement is separate. Candidate B: RentalContext owns returned/released; MaintenanceContext owns received/repaired/inspected; explicit EquipmentReturned and EquipmentReleased dictionaries connect them; Settlement is separate. Both run synchronously in the same Python process. No billing creation/integration protocol is implemented: due=120 comes from the fixture.

The trace columns are [return complete, repair complete, rentable, settlement complete, balance]. Rentable means returned AND inspection released only; future reservations and customer eligibility are outside this predicate. Settlement complete means paid=due. Payments are positive integer yuan with no overpayment.

NaiveSharedCompletion performs a return operation by writing one COMPLETED state and incorrectly derives both rentable and settled. Its wrong decisions are compared against the real candidate objects at the same business point.

Both candidates must match the independent fixture trace through return, repair, inspection, payment50, payment70. Early inspection, ambiguous status message, foreign equipment release and overpayment are rejected. No distributed ordering, reliability, transaction, organizational productivity or security claim follows from these local tests.
