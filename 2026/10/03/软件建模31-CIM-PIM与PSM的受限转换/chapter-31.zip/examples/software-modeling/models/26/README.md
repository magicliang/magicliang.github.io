# 26：规则与创建实验

复用 API 见 [contracts.md](contracts.md)。图1解释职责和依赖；图2描述实际 Factory 的调用与失败流程，Mermaid 为说明图。

仓库根入口：`JAVA_HOME=/path/to/jdk21 examples/software-modeling/labs/26/run.sh`。

负入口：`JAVA_HOME=/path/to/jdk21 examples/software-modeling/labs/26/run.sh invalid-period`，预期 TOO_SOON、退出1。

下载包应保留 `examples/software-modeling/` 路径前缀，包含 rental-core/RentalDesk.java、labs/00/BaselineCheck.java、labs/24/Money.java、labs/25/ReservationCalendar.java、labs/26、models/26、evidence/26。编译 Java 21 标准库，无框架或新依赖。

草案仅表达请求、保留单价和报价；无设备在役判断、占用副作用、付款事实或持久化协议。Snapshot 恢复不重新执行随时间改变的新建规则。
