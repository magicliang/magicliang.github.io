# 21: information path contract

Teaching adaptation, independent from Java rental core. Python >=3.10 stdlib.

`fixture.json` represents a submit-reservation operation; UI supplies rental/equipment IDs and integer hours, session supplies customer identity, injected clock supplies accepted_at. Time convention: one day, integer hours, [start,end). The fixture does not authenticate a customer or prove clock trust.

Command conversion requires the six inputs. ReservationStore keeps current rows, rejects duplicate IDs and overlaps, and emits a copied ReservationConfirmed dictionary. Projection maps six event fields and derives duration=end-start. Trace checks all seven view fields, verifies values along input→command→event→view paths, and verifies the formula. It is a hand-written contract, not a general lineage engine or proof of requirement completeness.

Success scenarios: R1[10,12), R2[12,15); refresh reads without state mutation. Negative scenarios: R3[11,13) overlap, missing session customer, orphan deposit, missing event accepted_at, forged customer, incorrect duration. Emitted-event mutation leaves stored row unchanged. No Event Sourcing, durable transactions, queues, browser UI or authentication is implemented.
