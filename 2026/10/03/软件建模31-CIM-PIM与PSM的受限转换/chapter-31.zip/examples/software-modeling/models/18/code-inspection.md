# F02 实现后代码自查

检查者为实现者，非独立代码审查或真实 feature team 的签字。

检查 rental.py 的 extend：未知 id 检查发生在读取前；new_end 明确限制 int 并拒绝 bool/float；replace 保留 id/equipment；validate 在赋值之前调用。检查 baseline.py 的 validate：以 id 排除自身；设备不同不比较占用；Period.overlaps 使用两个严格小于。test_rental.py 的 12 个实际测试和 acceptance.py 覆盖这些路径与旧创建/取消行为。

发现的边界：rentals 字典公开，调用方可以绕过方法直接修改；CLI 仅接受可信教学输入，不提供输入协议健壮性；进程结束数据即丢失；未考虑并发、收费或审计。故“拒绝不改状态”仅指通过方法调用、单线程内存执行的已测场景，不能提升为数据库原子性或访问控制证明。

集成方式：对 baseline.py/rental.py/test_rental.py/cli.py 逐一复制并比较 SHA-256，在独立临时目录运行测试与真实 subprocess CLI。不是复制既有日志；stages.json 保存每个子进程的真实退出码。只有这些检查成功，外层 runner 才退出 0。
