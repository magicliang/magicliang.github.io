# Finite-state DSL v1: stable API for chapters 31–34

Implementation: `examples/software-modeling/labs/30/toolkit.py`, Python >=3.10, stdlib only. Import by adding its directory to sys.path, then `from toolkit import ...`; no installed package. Downstream chapters must ship this exact dependency when packaging. No shared/core or Java changes.

## Source language

UTF-8 JSON, exactly these fields: `version` integer 1 (boolean rejected), `name` ASCII identifier, nonempty `states` identifier array, `initial` identifier, `terminal` identifier array (empty allowed), nonempty `operations` identifier array, `transitions` array. Every transition has exactly `from`, `operation`, `to` identifiers. Identifier grammar: `[A-Za-z][A-Za-z0-9_]*`. All object duplicate keys and non-JSON NaN/Infinity constants rejected. No expressions, guards, effects, nesting, parameters, parallel states, or import statements. JSON whitespace/object-field order do not alter semantics.

## Public functions/types

- `parse_model(text: str) -> Model`: JSON parse + strict shape + generic finite-state semantic validation. `load_model(path: str | Path) -> Model` reads UTF-8 and delegates. IO errors are ordinary filesystem errors, not ModelError.
- `Model`: frozen dataclass fields `version:int`, `name:str`, `states:tuple[str,...]`, `initial:str`, `terminal:tuple[str,...]`, `operations:tuple[str,...]`, `transitions:tuple[Transition,...]`. `Transition` frozen fields `from_state`, `operation`, `to_state`. `Model.as_dict()` returns a fresh JSON-shaped dict/list representation.
- `step(model:Model,state:str,operation:str) -> str`: pure next-state lookup, or `ModelError('OPERATION_NOT_ALLOWED','$.runtime',...)`; never mutates model/state. Caller decides whether/how to store returned state.
- `validate_equipment_contract(model:Model) -> None`: separate domain gate requiring exactly chapter24 lifecycle subset (three states, initial INSPECTION_REQUIRED, terminal RETIRED, three operations and four exact edges). Raises EQUIPMENT_CONTRACT at `$`. Name is not a domain invariant. Does not cover EquipmentId/equality/description/Money/Period/restore.
- `generate_python(model:Model) -> str`: deterministic source for one model representation; output provides INITIAL, TRANSITIONS and `step(state,operation)`. Missing pair raises ordinary ValueError('OPERATION_NOT_ALLOWED'); it does not import toolkit or JSON at runtime. Source contains canonical JSON SHA256. No promise of equal hashes for semantically equal models with differently ordered arrays.
- Runtime/generator functions trust a validated Model from parse/load. Direct construction of dataclasses bypasses validation and is not a supported untrusted-input path. No `eval` of model text; generated values are quoted data.

## Generic semantic gates

Names unique within states/operations/terminal; all state/operation references resolve; each (source,operation) pair occurs once; terminal states have no outgoing edge; all states reachable from initial. Unused operations and nonterminal dead-end states are permitted in this small language. Completeness against a domain contract is a separate check.

`ModelError(ValueError)` exposes `code` and `path`; string message is explanatory, not a stable comparison target. Codes: JSON_SYNTAX, DUPLICATE_KEY, SHAPE, VERSION, DUPLICATE_NAME, UNKNOWN_STATE, UNKNOWN_OPERATION, NONDETERMINISTIC, TERMINAL_OUTGOING, UNREACHABLE, OPERATION_NOT_ALLOWED, EQUIPMENT_CONTRACT. First error only; paths use `$.field[index]`, runtime `$.runtime`; JSON syntax carries line/column. Duplicate object keys currently report `$` (hook lacks nested source position).

## Frozen device fixture and extension boundary

`equipment.json` matches 24 contracts: INSPECTION_REQUIRED→ACTIVE via approveInspection; ACTIVE→INSPECTION_REQUIRED via requireInspection; either non-retired state→RETIRED via retire. RETIRED has no exit. `wrong-policy.json` is a valid generic FSM that swaps approval/retirement targets; it must pass parse but fail equipment contract.

31 may map an explicitly restricted requirement/PIM into this format and then a named target platform; do not call this script a complete MDA tool. 32 may add named business constraints outside generic parsing. 33 may compare generated/interpreted behavior. 34 may evolve fixtures explicitly and describe migration; changing states/operations requires acknowledging equipment-contract change. Keep v1 parsing semantics stable; use an explicit new version for incompatible syntax. Generated artifacts have no hand-edit preservation or reverse transformation guarantee.

27 cumulative Java application is not a runtime dependency. This tool only models lifecycle state transitions; deployment, persistence, approvals/authentication, event delivery, equipment identity and reservation availability are out of scope.
