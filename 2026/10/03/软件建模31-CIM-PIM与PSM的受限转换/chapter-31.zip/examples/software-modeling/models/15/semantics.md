# 15: Four archetypes as semantic hypotheses

Original-source checks: Coad/LeFebvre/De Luca publisher chapter5, printed157 section5.1.1 says pink project/request, yellow roles, green request pool. Printed167 section5.2.1 distinguishes green account, yellow account-holder role, pink exchange-rate fact and blue currency-pair description. Printed177 section5.3.1 allows versions on blue template and green document. These facts do not supply a universal Entity/ValueObject or aggregate mapping. Chapter1 not read; no specific multiplicity claims made.

Teaching mapping in fixture.json: RentalAgreement pink Moment-Interval; Role yellow; Equipment green Party-Place-Thing; ModelDescription blue Description. This is not the book's rental implementation. Fixture color strings document decisions and are not treated as proof of behavior.

Fixed day UTC integer hours [start,end). P1 has renter and inspector roles at O1. Role termination changes current role record but retains historical eligibility before end. Existing agreement embeds original immutable role/equipment records. New agreement requires renter active at start; no rule that role covers entire rental, no authorization or durable audit. Start/end must be ordered. No ID registry or role-constructor validation claimed.

E1/E2 share CAM-A revision1 but have distinct physical identities. Deduplicating by model loses E1. Making party kind equal its last role loses renter classification. Description revision2 has the same logical model id and a revised label; old agreement stays on revision1. Latest-version lookup would display the revised label for that historical agreement. Frozen records are this lab's implementation choice, not a result of blue color or an audit-store guarantee.

No effect on Java RentalDesk, billing, stock allocation, legal contract validity, database or concurrency. Signed contract document versus contractual relationship is a semantic discussion only in this lab; document behaviors are chapter16.
