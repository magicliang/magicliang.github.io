# Play 34 isolated delivery

Current artifact: integration-manifest.json, exact add-only source paths to examples/play-electives/diagnosis. Shared post and cover are already present. Root owns page/browser/shared replay/navigation/commit.

Invocation: JAVA_HOME=Corretto21.0.11 DIAG_EVIDENCE=run2 python3 diagnosis_checks.py after sbt stage (build-final2.log). Binary observable: summary PASS, six cases,26 assertions. No JUnit cases.

Observed:
- A: two actual default-dispatcher sleep stacks; health1609.753583ms. Fixed actual diagnosis-business stacks; health20.073625ms. Same two2-second slow operations. Raw jcmd snapshots in A-* directories.
- B: first504/independentSQL0/retry504/drain/SQL2. Fixed unique-key and ON CONFLICT sequence endsSQL1. Both pool application_name session counts0 after shutdown.
- C: two real TCP reads and closes; terminalCount2 but file/openChannel/lease2, permit0, next503. lsof confirms both open paths. Fixed same sequence yields allresourcecounts0,permit2,next200. Recovery reap closes intentionally leaked fault resources before shutdown.
- All6 own production JVMs exited and lifecycle journals report worker/clock/poolclosed,permits2,leases0. Existing PostgreSQL fixture left running.
- First run retained:400ms SQL delay window was shorter than externalpsql overhead, so earlySQL0 failed. Controlleddelay increased to1.5s and allsix scenariosreranPASS.

Source proof: two controller/Lease class bytes match actual stagedjar; hash manifest. Pekko1.0.3 official Flow.scala saved and watchTermination lines3863–3869 inspected. Play3.0.6 pinnedJavaAsync source inspected. PostgreSQL17 INSERT documentation inspected.

Writing: Java entry skill, anti-ai-tone-final (0errors0warnings), anti-persona-final, then articlewrite. CompleteOnceLease Java21 compiledandran; java-example.log. Cover XMLvalid. No browser or Hexo proof claimed.

Boundaries: namedA/B/C root-cause-hidden exercise; automatedregressionknowsitsoracle. classify_observations.py consumescapturedobservationsonly. No independenthumanblindstudy. No diskerrorinjection, forcedkill, in-flightSIGTERM or proxycancellation claimed.
