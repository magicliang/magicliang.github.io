# Three fault packages and same-load regression

Java21 / Play3.0.6 / Scala2.13.15 / sbt1.10.7. This is an independent loopback diagnosis application; intentional defects are selected by DIAG_PROFILE A/B/C and DIAG_FIXED=false. Do not deploy it publicly. The cumulative Play series application is not modified.

A: default-dispatcher blocking versus a dedicated bounded executor.
B: outer HTTP timeout plus retry duplicates versus a unique business key.
C: real TCP cancellation with unclosed application file/permit leases versus termination-bound release.

Build:

```bash
export JAVA_HOME=/path/to/jdk-21
curl -fsSL https://repo.maven.apache.org/maven2/org/scala-sbt/sbt-launch/1.10.7/sbt-launch-1.10.7.jar -o /tmp/diagnosis-sbt-launch-1.10.7.jar
"$JAVA_HOME/bin/java" -Dsbt.supershell=false -jar /tmp/diagnosis-sbt-launch-1.10.7.jar stage
```

Use a local PostgreSQL17.6 container with database play_lab, postgres user and synthetic lab-only-password. The driver creates fresh diag_* schemas and never drops unrelated data or stops the fixture. Independent SQL uses podman exec, so the named container must be the same database as the JDBC URL.

```bash
export DIAG_JDBC_URL='jdbc:postgresql://127.0.0.1:5432/play_lab?connectTimeout=3&socketTimeout=5'
export DIAG_CONTAINER=play-diagnosis-db
export PODMAN=podman
export DIAG_EVIDENCE="$PWD/evidence"
python3 diagnosis_checks.py
python3 classify_observations.py "$DIAG_EVIDENCE"
```

Requirements: Python3.9+, JDK jcmd, lsof, Podman CLI. Each run needs a new evidence directory. Six production processes start sequentially on random loopback ports. A takes two thread dumps; B writes only synthetic rows; C opens two application-owned scratch files and cuts real TCP connections after data arrives. Files are side resources owned by the application; this does not claim FileIO itself leaks.

Read A/B/C observations first to practice diagnosis without the source answer. classify_observations.py reads only captured observations and thread dumps. The regression driver knows expected outcomes; this is not an independent human double-blind study.

There are no JUnit cases. stage proves compilation/package; the actual acceptance is six real scenarios and 26 HTTP/thread/SQL/resource assertions. Retain summary.json, observations.json, checks.json, sql.json and case directories. Intentional leaked resources are reclaimed through the private reap endpoint before SIGTERM. The endpoint is a lab recovery mechanism, not a production fix.

The idle shutdown journal must report worker=true, clock=true, permits=2, leases=0, pool=true. B additionally checks no remaining PostgreSQL sessions under the unique application_name. In-flight signal, forced kill, disk failure, database crash and real proxy cancellation are not covered.

Compile the complete resource example:

```bash
"$JAVA_HOME/bin/javac" -d writing writing/OnceLease.java
"$JAVA_HOME/bin/java" -cp writing OnceLease
```

