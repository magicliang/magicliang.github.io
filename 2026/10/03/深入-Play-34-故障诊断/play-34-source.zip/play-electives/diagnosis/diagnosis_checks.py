#!/usr/bin/env python3
"""Finite anonymous fault fixtures A/B/C, each replayed before and after its minimal fix."""
import concurrent.futures as cf
import json,os,pathlib,socket,subprocess,time,urllib.request,urllib.error,uuid
ROOT=pathlib.Path(__file__).resolve().parent
OUT=pathlib.Path(os.environ["DIAG_EVIDENCE"]).resolve();OUT.mkdir(parents=True,exist_ok=True)
JAVA=pathlib.Path(os.environ["JAVA_HOME"])/"bin"
PODMAN=os.environ.get("PODMAN","podman")
CONTAINER=os.environ.get("DIAG_CONTAINER","play-diagnosis-db")
JDBC=os.environ.get("DIAG_JDBC_URL","jdbc:postgresql://127.0.0.1:5432/play_lab?connectTimeout=3&socketTimeout=5")
observations=[];checks=[];sql_rows=[];processes=[];summary={"status":"FAIL"}
def req(base,path,method="GET"):
    t=time.perf_counter()
    try:
        with urllib.request.urlopen(urllib.request.Request(base+path,method=method),timeout=10) as r:s=r.status;b=r.read().decode()
    except urllib.error.HTTPError as e:s=e.code;b=e.read().decode()
    return dict(status=s,body=b,millis=(time.perf_counter()-t)*1000)
def check(name,value,**data):
    checks.append(dict(name=name,passed=bool(value),**data));assert value,(name,data)
def state(base):return json.loads(req(base,"/resources")["body"])
def sql(schema,q):
    result=subprocess.run([PODMAN,"exec",CONTAINER,"psql","-U","postgres","-d","play_lab","-Atc","SET search_path TO "+schema+";"+q],capture_output=True,text=True,check=True)
    value=result.stdout.strip().splitlines()[-1];sql_rows.append(dict(schema=schema,query=q,value=value));return value
def wait_idle(base):
    for _ in range(100):
        s=state(base)
        if s["active"]==s["queue"]==0:return s
        time.sleep(.05)
    raise AssertionError("not drained")
def stream_cut(port):
    with socket.create_connection(("127.0.0.1",port),timeout=5) as s:
        s.sendall(b"GET /stream HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n")
        data=b""
        while b"\r\n\r\n" not in data:data+=s.recv(8192)
        head,body=data.split(b"\r\n\r\n",1)
        if b" 200 " in head.split(b"\r\n")[0]:
            while len(body)<8192:body+=s.recv(8192)
        return dict(header=head.decode(),bytesRead=len(body))
try:
    for profile in ("A","B","C"):
        for fixed in (False,True):
            name=profile+("-fixed" if fixed else "-fault")
            ev=OUT/name;ev.mkdir()
            with socket.socket() as s:s.bind(("127.0.0.1",0));port=s.getsockname()[1]
            base="http://127.0.0.1:"+str(port);schema="diag_"+uuid.uuid4().hex[:10]
            directory=ev/"files";journal=ev/"cleanup.txt"
            env=os.environ|dict(DIAG_PROFILE=profile,DIAG_FIXED=str(fixed).lower(),DIAG_SCHEMA=schema,DIAG_FILES=str(directory),DIAG_JDBC_URL=JDBC,DIAG_JOURNAL=str(journal),APPLICATION_SECRET=uuid.uuid4().hex+uuid.uuid4().hex)
            log=open(ev/"server.log","w")
            process=subprocess.Popen([str(ROOT/"target/universal/stage/bin/play-diagnosis"),"-Dhttp.port="+str(port),"-Dhttp.address=127.0.0.1","-Dpidfile.path=/dev/null"],env=env,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
            processes.append((process,log))
            for _ in range(200):
                if process.poll() is not None:raise AssertionError("startup failed "+name)
                try:
                    if req(base,"/ready")["status"]==200:break
                except OSError:pass
                time.sleep(.1)
            else:raise AssertionError("startup timeout")
            observation=dict(case=name,pid=process.pid)
            if profile=="A":
                with cf.ThreadPoolExecutor(max_workers=2) as executor:
                    a=executor.submit(req,base,"/hold","POST");b=executor.submit(req,base,"/hold","POST")
                    time.sleep(.2)
                    dump=subprocess.run([str(JAVA/"jcmd"),str(process.pid),"Thread.print","-l"],capture_output=True,text=True,check=True)
                    (ev/"threads.txt").write_text(dump.stdout)
                    health=req(base,"/health")
                    work=[a.result(),b.result()]
                observation.update(health=health,work=work)
                blocks=dump.stdout.split("\n\n")
                sleepers=[x for x in blocks if "DiagnosisController.sleep" in x and "Thread.sleep" in x]
                check(name+" actual sleeper threads",len(sleepers)>=2,headers=[x.splitlines()[0] for x in sleepers])
                if fixed:
                    check(name+" dedicated workers",all("diagnosis-business" in x for x in sleepers))
                    check(name+" responsive health",health["millis"]<500,health=health)
                else:
                    check(name+" default dispatcher",all("default-dispatcher" in x for x in sleepers))
                    check(name+" health delayed",health["millis"]>700,health=health)
                observation["diagnosis"]="default-dispatcher blocking" if not fixed else "dedicated bounded executor"
            elif profile=="B":
                first=req(base,"/order/retry-key","POST")
                early=sql(schema,"SELECT count(*) FROM orders")
                second=req(base,"/order/retry-key","POST")
                wait_idle(base)
                final=sql(schema,"SELECT count(*) FROM orders")
                observation.update(first=first,early=early,second=second,rows=final)
                check(name+" both outer timeout",first["status"]==second["status"]==504)
                check(name+" first no commit yet",early=="0")
                check(name+" final row count",final==("1" if fixed else "2"),rows=final)
                observation["diagnosis"]="outer timeout plus unguarded retry" if not fixed else "database unique-key deduplication"
            else:
                cuts=[stream_cut(port),stream_cut(port)]
                for _ in range(100):
                    current=state(base)
                    if current["terminals"]>=2 and (not fixed or current["leases"]==0):break
                    time.sleep(.05)
                lsof=subprocess.run(["lsof","-nP","-p",str(process.pid)],capture_output=True,text=True)
                (ev/"lsof.txt").write_text(lsof.stdout)
                files=[str(p) for p in directory.glob("*.bin")]
                third=stream_cut(port)
                observation.update(cuts=cuts,state=current,files=files,third=third)
                check(name+" backend saw cancel",current["terminals"]>=2)
                if fixed:
                    check(name+" cleanup",current["leases"]==current["openChannels"]==0 and current["permits"]==2 and not files)
                    check(name+" admission restored"," 200 " in third["header"].splitlines()[0])
                else:
                    check(name+" observed leaked resources",current["leases"]==current["openChannels"]==2 and current["permits"]==0 and len(files)==2 and all(p in lsof.stdout for p in files))
                    check(name+" third request rejected"," 503 " in third["header"].splitlines()[0])
                req(base,"/reap","POST")
                observation["diagnosis"]="termination observed but application lease not released" if not fixed else "termination-bound lease release"
            observations.append(observation)
            process.terminate();exit_code=process.wait(timeout=15);log.close()
            cleanup=journal.read_text()
            check(name+" process cleanup",all(v in cleanup for v in ("worker=true","clock=true","permits=2","leases=0","pool=true")),exit=exit_code,journal=cleanup)
            if profile=="B":check(name+" pool sessions zero",sql(schema,"SELECT count(*) FROM pg_stat_activity WHERE application_name='"+schema+"'")=="0")
    summary=dict(status="PASS",cases=len(observations),checks=len(checks))
finally:
    errors=[]
    for process,log in processes:
        try:
            if process.poll() is None:
                process.terminate()
                try:process.wait(timeout=15)
                except subprocess.TimeoutExpired:process.kill();process.wait();errors.append("forced kill")
        finally:log.close()
    if errors:summary={"status":"FAIL","cleanupErrors":errors}
    for name,data in [("summary",summary),("observations",observations),("checks",checks),("sql",sql_rows)]:
        (OUT/(name+".json")).write_text(json.dumps(data,indent=2)+"\n")
print(json.dumps(summary))
