ThisBuild / scalaVersion := "2.13.15"
ThisBuild / version := "0.1.0"
lazy val root = (project in file(".")).enablePlugins(PlayJava).settings(
 name := "play-diagnosis",
 libraryDependencies ++= Seq(guice,"com.zaxxer" % "HikariCP" % "5.0.1","org.postgresql" % "postgresql" % "42.7.5"))

