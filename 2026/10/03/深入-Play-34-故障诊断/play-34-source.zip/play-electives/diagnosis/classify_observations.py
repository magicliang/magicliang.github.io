#!/usr/bin/env python3
"""Classify captured observations without loading application source or launch profiles."""
import json,pathlib,sys
root=pathlib.Path(sys.argv[1])
answers=[]
for obs in json.loads((root/"observations.json").read_text()):
    case=obs["case"]
    if "health" in obs:
        dump=(root/case/"threads.txt").read_text()
        sleepers=[b for b in dump.split("\n\n") if "DiagnosisController.sleep" in b and "Thread.sleep" in b]
        default=any("default-dispatcher" in b for b in sleepers)
        result="shared executor starvation" if default and obs["health"]["millis"]>700 else "isolated blocking work"
        evidence=["health latency","actual sleeper thread names and stack"]
    elif "rows" in obs:
        timed_out=obs["first"]["status"]==obs["second"]["status"]==504
        result="timeout did not prevent duplicate write" if timed_out and obs["rows"]=="2" else "retry deduplicated after timeout"
        evidence=["two HTTP504","early independent SQL0","final independent SQL"+obs["rows"]]
    else:
        st=obs["state"]
        leaked=st["terminals"]>=2 and st["openChannels"]>0 and st["permits"]==0
        result="cancel observed but application resources leaked" if leaked else "termination released owned resources"
        evidence=["stream terminal count","lease/open descriptor/files","next admission status"]
    answers.append(dict(case=case,diagnosis=result,evidence=evidence))
(root/"black-box-diagnosis.json").write_text(json.dumps(answers,indent=2)+"\n")
print(json.dumps(answers,indent=2))

