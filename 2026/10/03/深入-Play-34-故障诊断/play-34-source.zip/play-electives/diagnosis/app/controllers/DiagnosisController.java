package controllers;

import com.zaxxer.hikari.*;
import javax.inject.*;
import play.mvc.*;
import play.libs.Json;
import play.inject.ApplicationLifecycle;
import org.apache.pekko.stream.javadsl.Source;
import org.apache.pekko.util.ByteString;
import java.sql.*;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

@Singleton
public final class DiagnosisController extends Controller {
    private final String profile=System.getenv("DIAG_PROFILE");
    private final boolean fixed=Boolean.parseBoolean(System.getenv("DIAG_FIXED"));
    private final ThreadPoolExecutor worker=new ThreadPoolExecutor(2,2,0,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<>(16),
        r -> new Thread(r,"diagnosis-business"),new ThreadPoolExecutor.AbortPolicy());
    private final ScheduledExecutorService clock=Executors.newSingleThreadScheduledExecutor();
    private final AtomicInteger holds=new AtomicInteger();
    private final Semaphore permits=new Semaphore(2);
    private final ConcurrentHashMap<String,Lease> leases=new ConcurrentHashMap<>();
    private final AtomicInteger terminals=new AtomicInteger();
    private final AtomicInteger rows=new AtomicInteger();
    private final Path directory=Path.of(System.getenv("DIAG_FILES"));
    private final HikariDataSource pool;
    private record Lease(Path path,FileChannel channel) {}
    @Inject public DiagnosisController(ApplicationLifecycle life) throws Exception {
        Files.createDirectories(directory);
        if(profile.equals("B")) {
            String schema=System.getenv("DIAG_SCHEMA");
            if(!schema.matches("diag_[a-z0-9_]+"))throw new IllegalArgumentException();
            HikariConfig cfg=new HikariConfig();
            cfg.setJdbcUrl(System.getenv("DIAG_JDBC_URL"));cfg.setUsername("postgres");cfg.setPassword("lab-only-password");
            cfg.setMaximumPoolSize(2);cfg.setMinimumIdle(2);cfg.setSchema(schema);cfg.addDataSourceProperty("ApplicationName",schema);
            pool=new HikariDataSource(cfg);
            try(Connection c=pool.getConnection();Statement s=c.createStatement()){
                s.execute("CREATE SCHEMA "+schema);
                s.execute("CREATE TABLE "+schema+".orders(id bigserial PRIMARY KEY, key text NOT NULL"+(fixed?" UNIQUE":"")+")");
            }
        }else pool=null;
        life.addStopHook(() -> {
            worker.shutdown();
            try {
                if(!worker.awaitTermination(8,TimeUnit.SECONDS))throw new IllegalStateException("worker not drained");
                clock.shutdownNow();reap();
                if(pool!=null)pool.close();
                Files.writeString(Path.of(System.getenv("DIAG_JOURNAL")),"worker="+worker.isTerminated()+";clock="+clock.isShutdown()+";permits="+permits.availablePermits()+";leases="+leases.size()+";pool="+(pool==null||pool.isClosed()));
                return CompletableFuture.completedFuture(null);
            }catch(Exception e){return CompletableFuture.failedFuture(e);}
        });
    }
    public Result ready(){return ok("ready");}
    public Result health(){return ok(Json.toJson(Map.of("status","up","holds",holds.get())));}
    private Result sleep() {
        holds.incrementAndGet();
        try{Thread.sleep(2000);return ok("held");}
        catch(InterruptedException e){Thread.currentThread().interrupt();return internalServerError();}
        finally{holds.decrementAndGet();}
    }
    public CompletionStage<Result> hold() {
        if(profile.equals("A")&&!fixed)return CompletableFuture.completedFuture(sleep());
        return CompletableFuture.supplyAsync(this::sleep,worker);
    }
    public CompletionStage<Result> order(String key) {
        if(pool==null)return CompletableFuture.completedFuture(badRequest());
        CompletableFuture<Result> result=new CompletableFuture<>();
        var timeout=clock.schedule(() -> result.complete(status(504,"budget")),150,TimeUnit.MILLISECONDS);
        worker.execute(() -> {
            try(Connection c=pool.getConnection()) {
                c.setAutoCommit(false);
                try {
                    try(Statement s=c.createStatement()){s.execute("SELECT pg_sleep(1.5)");}
                    try(PreparedStatement p=c.prepareStatement("INSERT INTO orders(key) VALUES(?)"+(fixed?" ON CONFLICT(key) DO NOTHING":""))){
                        p.setString(1,key);rows.addAndGet(p.executeUpdate());
                    }
                    c.commit();result.complete(ok("committed"));
                }catch(Exception e){c.rollback();throw e;}
            }catch(Exception e){result.complete(internalServerError(e.getClass().getSimpleName()));}
            finally{timeout.cancel(false);}
        });
        return result;
    }
    public Result stream() throws Exception {
        if(!permits.tryAcquire())return status(503,"capacity");
        Path p=null;FileChannel channel=null;
        try {
            p=Files.createTempFile(directory,"stream-", ".bin");
            channel=FileChannel.open(p,StandardOpenOption.READ,StandardOpenOption.WRITE);
            channel.write(java.nio.ByteBuffer.wrap(new byte[8192]));
            String id=UUID.randomUUID().toString();
            Lease lease=new Lease(p,channel);leases.put(id,lease);
            Source<ByteString,?> body=Source.repeat(ByteString.fromArray(new byte[8192]))
                .throttle(1,Duration.ofMillis(30))
                .watchTermination((m,done) -> {
                    done.whenComplete((v,error) -> {
                        terminals.incrementAndGet();
                        if(fixed)release(id);
                    });
                    return m;
                });
            return ok().chunked(body).as("application/octet-stream");
        }catch(Exception e){
            if(channel!=null)channel.close();if(p!=null)Files.deleteIfExists(p);permits.release();throw e;
        }
    }
    private void release(String id) {
        Lease lease=leases.remove(id);
        if(lease==null)return;
        try{lease.channel().close();Files.deleteIfExists(lease.path());}
        catch(Exception e){throw new CompletionException(e);}
        finally{permits.release();}
    }
    public Result resources() {
        return ok(Json.toJson(Map.of("active",worker.getActiveCount(),"queue",worker.getQueue().size(),"holds",holds.get(),
            "permits",permits.availablePermits(),"leases",leases.size(),"openChannels",leases.values().stream().filter(l->l.channel().isOpen()).count(),
            "terminals",terminals.get(),"committedStatements",rows.get())));
    }
    public Result reap() {
        for(String id:List.copyOf(leases.keySet()))release(id);
        return resources();
    }
}
