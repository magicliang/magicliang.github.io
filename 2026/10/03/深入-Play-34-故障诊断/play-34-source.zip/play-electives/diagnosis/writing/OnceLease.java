import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public final class OnceLease implements AutoCloseable {
    private final Path path;
    private final FileChannel channel;
    private final Semaphore permits;
    private final AtomicBoolean closed = new AtomicBoolean();

    public OnceLease(Semaphore permits) throws Exception {
        this.permits = permits;
        permits.acquire();
        Path created = null;
        try {
            created = Files.createTempFile("lease-example-", ".bin");
            channel = FileChannel.open(created, StandardOpenOption.READ);
            path = created;
        } catch (Exception e) {
            if (created != null) {
                try { Files.deleteIfExists(created); }
                catch (Exception cleanup) { e.addSuppressed(cleanup); }
            }
            permits.release();
            throw e;
        }
    }

    @Override
    public void close() throws Exception {
        if (!closed.compareAndSet(false, true)) return;
        try {
            channel.close();
            Files.deleteIfExists(path);
        } finally {
            permits.release();
        }
    }

    public static void main(String[] args) throws Exception {
        var permits = new Semaphore(1);
        var lease = new OnceLease(permits);
        var pool = Executors.newFixedThreadPool(2);
        try {
            var first = pool.submit(() -> { lease.close(); return null; });
            var second = pool.submit(() -> { lease.close(); return null; });
            first.get(2, TimeUnit.SECONDS);
            second.get(2, TimeUnit.SECONDS);
            if (permits.availablePermits() != 1
                    || lease.channel.isOpen() || Files.exists(lease.path)) {
                throw new AssertionError();
            }
            System.out.println("permits=1 channelClosed=true fileAbsent=true");
        } finally {
            lease.close();
            pool.shutdownNow();
            if (!pool.awaitTermination(2, TimeUnit.SECONDS)) {
                throw new AssertionError("pool not terminated");
            }
        }
    }
}
