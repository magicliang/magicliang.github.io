#!/usr/bin/env python3
import hashlib,json,os,pathlib,zipfile,xml.etree.ElementTree as ET
root=pathlib.Path(__file__).resolve().parent
ev=pathlib.Path(os.environ["DIAG_EVIDENCE_ROOT"])
repo=pathlib.Path(os.environ["DIAG_REPO_ROOT"])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sources=[]
for p in root.rglob("*"):
    if not p.is_file() or any(x in p.parts for x in ("target",".bsp",".idea",".settings","__pycache__")):continue
    if p.name in ("article-draft.md","OnceLease.class",".classpath",".project"):continue
    sources.append(dict(source=str(p),destination="examples/play-electives/diagnosis/"+str(p.relative_to(root)),sha256=sha(p)))
jar=next((root/"target/universal/stage/lib").glob("*play-diagnosis*.jar"))
classes=[]
with zipfile.ZipFile(jar) as z:
    for n in ("controllers/DiagnosisController.class","controllers/DiagnosisController$Lease.class"):
        b=(root/"target/scala-2.13/classes"/n).read_bytes()
        assert b==z.read(n)
        classes.append(dict(name=n,sha256=hashlib.sha256(b).hexdigest()))
summary=json.loads((ev/"run2/summary.json").read_text())
assert summary==dict(status="PASS",cases=6,checks=26)
assert "[success]" in (ev/"build-final2.log").read_text()
assert (ev/"java-example.log").read_text().strip()=="permits=1 channelClosed=true fileAbsent=true"
assert json.loads((ev/"anti-ai-tone-final.json").read_text())["errors"]==0
assert not json.loads((ev/"anti-persona-final.json").read_text())["findings"]
post=repo/"source/_posts/2026-10-03-深入-Play-34-故障诊断.md"
cover=post.with_suffix("")/"cover.svg";ET.parse(cover)
data=dict(status="PASS",sources=sources,productionArtifact=dict(path=str(jar),sha256=sha(jar),classes=classes),summary=summary,
 post=dict(path=str(post),sha256=sha(post)),cover=dict(path=str(cover),sha256=sha(cover)),evidenceDestination="examples/play-electives/evidence/diagnosis/isolated",
 boundaries=["No JUnit cases","A/B/C hidden-root-cause exercise, not independent human blind study","Idle SIGTERM only","Root still owns shared integration/page/browser/commit"])
(ev/"integration-manifest.json").write_text(json.dumps(data,indent=2)+"\n")
print(json.dumps(dict(status="PASS",sources=len(sources),productionClasses=len(classes),cases=6,checks=26,postSha256=sha(post))))

