package controllers;
import jakarta.inject.*;
import java.util.concurrent.*;
import lab.*;
import play.libs.Json;
import play.mvc.*;
@Singleton public final class JavaApi extends Controller {
    private final LabWorker worker; private final StreamProbe probe;
    @Inject public JavaApi(LabWorker worker,StreamProbe probe){this.worker=worker;this.probe=probe;}
    public Result health(){return ok(Json.newObject().put("status","ready").put("classOrigin",getClass().getProtectionDomain().getCodeSource().getLocation().toString()));}
    @With(AuthJava.class) @BodyParser.Of(BodyParser.Json.class)
    public Result json(Http.Request request) {
        var value=request.body().asJson().get("value");
        if(value==null||!value.isNumber()||value.decimalValue().stripTrailingZeros().scale()>0||value.decimalValue().compareTo(java.math.BigDecimal.ONE)<0||value.decimalValue().compareTo(java.math.BigDecimal.valueOf(100))>0) return badRequest("{\"error\":\"value\"}").as("application/json");
        return ok(Json.newObject().put("user",request.attrs().get(AuthJava.USER)).put("value",value.intValue()*2));
    }
    @With(AuthJava.class)
    public CompletionStage<Result> context(Http.Request request,boolean fail) {
        String user=request.attrs().get(AuthJava.USER), origin=Thread.currentThread().getName();
        return CompletableFuture.supplyAsync(()->{
            if(fail)throw new IllegalStateException("synthetic");
            return ok(Json.newObject().put("user",user).put("local",LabWorker.LOCAL.get()==null?"absent":LabWorker.LOCAL.get()).put("origin",origin).put("worker",Thread.currentThread().getName()));
        },worker.executor).exceptionally(e->status(503,"{\"error\":\"worker\"}").as("application/json"));
    }
    public Result stream(String id){return ok().chunked(probe.source(id)).as("application/octet-stream");}
    public Result state(String id){return ok(probe.state(id));}
}
