package lab;
import java.util.concurrent.*;
import play.libs.typedmap.TypedKey;
import play.mvc.*;
public final class AuthJava extends Action.Simple {
    public static final TypedKey<String> USER=TypedKey.create("user");
    @Override public CompletionStage<Result> call(Http.Request request) {
        String user=request.header("X-User").orElse("");
        if(!user.matches("[a-z]{1,20}")) return CompletableFuture.completedFuture(unauthorized("{\"error\":\"unauthorized\"}").as("application/json"));
        LabWorker.LOCAL.set(user);
        try {return delegate.call(request.addAttr(USER,user));}
        finally {LabWorker.LOCAL.remove();}
    }
}
