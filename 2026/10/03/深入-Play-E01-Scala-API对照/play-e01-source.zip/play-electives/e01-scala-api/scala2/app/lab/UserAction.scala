package lab
import jakarta.inject.Inject
import play.api.mvc._
import scala.concurrent.{ExecutionContext, Future}
final class UserRequest[A](val user: String, request: Request[A]) extends WrappedRequest[A](request)
final class UserAction @Inject()(val parser: BodyParsers.Default)(implicit val executionContext: ExecutionContext)
    extends ActionBuilder[UserRequest, AnyContent] {
  override def invokeBlock[A](request: Request[A], block: UserRequest[A] => Future[Result]): Future[Result] = {
    val user = request.headers.get("X-User").getOrElse("")
    if (!user.matches("[a-z]{1,20}")) Future.successful(Results.Unauthorized("{\"error\":\"unauthorized\"}").as("application/json"))
    else {
      LabWorker.LOCAL.set(user)
      try block(new UserRequest(user, request))
      finally LabWorker.LOCAL.remove()
    }
  }
}
