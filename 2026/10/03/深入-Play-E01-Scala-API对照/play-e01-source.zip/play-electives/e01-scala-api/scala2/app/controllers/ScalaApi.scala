package controllers
import jakarta.inject.{Inject, Singleton}
import lab._
import play.api.libs.json._
import play.api.mvc._
import scala.concurrent.{ExecutionContext, Future}
@Singleton
final class ScalaApi @Inject()(cc: ControllerComponents, auth: UserAction, worker: LabWorker, probe: StreamProbe)
    extends AbstractController(cc) {
  private implicit val workerContext: ExecutionContext = ExecutionContext.fromExecutor(worker.executor)
  def json: Action[JsValue] = auth(parse.json(1024)) { request =>
    (request.body \ "value").asOpt[Int].filter(v => v >= 1 && v <= 100) match {
      case Some(value) => Ok(Json.obj("user" -> request.user, "value" -> (value * 2)))
      case None => BadRequest(Json.obj("error" -> "value"))
    }
  }
  def context(fail: Boolean): Action[AnyContent] = auth.async { request =>
    val user = request.user
    val origin = Thread.currentThread().getName
    Future {
      if (fail) throw new IllegalStateException("synthetic")
      val local: String = Option(LabWorker.LOCAL.get()).map(_.toString).getOrElse("absent")
      Ok(Json.obj("user" -> user, "local" -> local,
        "origin" -> origin, "worker" -> Thread.currentThread().getName))
    }.recover { case _: IllegalStateException => ServiceUnavailable(Json.obj("error" -> "worker")) }
  }
  def stream(id: String): Action[AnyContent] = Action {
    Ok.chunked(probe.source(id).asScala).as("application/octet-stream")
  }
}
