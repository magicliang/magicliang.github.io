package lab;
import jakarta.inject.*;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.time.Duration;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.pekko.stream.javadsl.Source;
import org.apache.pekko.util.ByteString;
import play.inject.ApplicationLifecycle;
import play.libs.Json;
import com.fasterxml.jackson.databind.node.ObjectNode;
@Singleton public final class StreamProbe {
    private final LabWorker worker;
    private final ConcurrentHashMap<String,Entry> entries=new ConcurrentHashMap<>();
    private final class Entry {
        final Path path; final FileChannel file;
        final AtomicInteger produced=new AtomicInteger(); volatile boolean closed;
        Entry(String id) throws Exception {path=worker.directory.resolve(id+".resource");file=FileChannel.open(path,StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE);}
        synchronized void close() {if(closed)return; try {file.close();Files.delete(path);closed=true;}catch(Exception e){throw new IllegalStateException(e);}}
    }
    @Inject public StreamProbe(LabWorker worker,ApplicationLifecycle lifecycle) {
        this.worker=worker;
        lifecycle.addStopHook(()->{entries.values().forEach(Entry::close);return CompletableFuture.completedFuture(null);});
    }
    public synchronized Source<ByteString,?> source(String id) {
        if(!id.matches("[a-z0-9_]{1,30}")||entries.containsKey(id)||entries.size()>=12)throw new IllegalArgumentException("finite unique id");
        final Entry entry;
        try {entry=new Entry(id);entries.put(id,entry);}catch(Exception e){throw new IllegalStateException(e);}
        return Source.range(1,64).throttle(1,Duration.ofMillis(40)).map(i->{entry.produced.incrementAndGet();return ByteString.fromArray(new byte[8192]);})
            .watchTermination((m,f)->{f.whenComplete((v,e)->entry.close());return m;});
    }
    public ObjectNode state(String id) {
        Entry e=entries.get(id); if(e==null)return Json.newObject().put("missing",true);
        return Json.newObject().put("produced",e.produced.get()).put("closed",e.closed).put("fileOpen",e.file.isOpen()).put("fileExists",Files.exists(e.path));
    }
}
