package lab;
import jakarta.inject.*;
import java.nio.file.*;
import java.util.concurrent.*;
import com.typesafe.config.Config;
import play.inject.ApplicationLifecycle;
@Singleton public final class LabWorker {
    public static final ThreadLocal<String> LOCAL=new ThreadLocal<>();
    public final ExecutorService executor=Executors.newSingleThreadExecutor(r->new Thread(r,"api-worker"));
    public final Path directory;
    @Inject public LabWorker(Config config, ApplicationLifecycle lifecycle) {
        try { directory=Files.createDirectories(Path.of(config.getString("lab.workdir"))); }
        catch(Exception e){throw new IllegalStateException(e);}
        lifecycle.addStopHook(()->{
            executor.shutdown();
            try {
                if(!executor.awaitTermination(3,TimeUnit.SECONDS)) throw new IllegalStateException("worker not stopped");
                Files.writeString(directory.resolve("worker-stopped"),"true");
                return CompletableFuture.completedFuture(null);
            } catch(Exception e){return CompletableFuture.failedFuture(e);}
        });
    }
}
