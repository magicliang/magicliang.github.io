import static org.junit.Assert.*;
import static play.test.Helpers.*;
import java.nio.file.*;
import org.junit.Test;
import play.inject.guice.GuiceApplicationBuilder;
import play.libs.Json;
import play.mvc.Http;
public final class ApiTest {
    private void contract(String api) throws Exception {
        var dir=Files.createTempDirectory("api-test");
        var app=new GuiceApplicationBuilder().configure("lab.workdir",dir.toString()).build();
        running(app,()->{
            var good=route(app,new Http.RequestBuilder().method("POST").uri("/"+api+"/json").header("X-User","alice").bodyJson(Json.parse("{\"value\":2}")));
            assertEquals(200,good.status()); assertEquals(4,Json.parse(contentAsString(good)).get("value").intValue());
            var bad=route(app,new Http.RequestBuilder().method("POST").uri("/"+api+"/json").header("X-User","alice").bodyJson(Json.parse("{\"value\":0}")));
            assertEquals(400,bad.status());
            var denied=route(app,new Http.RequestBuilder().method("POST").uri("/"+api+"/json").bodyJson(Json.parse("{\"value\":2}")));
            assertEquals(401,denied.status());
        });
        assertEquals("true",Files.readString(dir.resolve("worker-stopped")));Files.delete(dir.resolve("worker-stopped"));Files.delete(dir);
    }
    @Test public void javaContract() throws Exception {contract("java");}
    @Test public void scalaContract() throws Exception {contract("scala");}
}
