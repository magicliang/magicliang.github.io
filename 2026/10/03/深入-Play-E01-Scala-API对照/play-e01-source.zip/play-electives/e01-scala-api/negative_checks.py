import argparse
import json
import os
from pathlib import Path
import subprocess
parser=argparse.ArgumentParser()
parser.add_argument('--evidence',type=Path,required=True)
args=parser.parse_args(); args.evidence.mkdir(parents=True,exist_ok=True)
root=Path(__file__).resolve().parent
classpath=os.environ['SCALA_COMPILER_CP']
stage=root/'scala2/target/universal/stage/lib'
command=[str(Path(os.environ['JAVA_HOME'])/'bin/java'),'-cp',classpath,'scala.tools.nsc.Main','-classpath',':'.join(str(p) for p in stage.glob('*.jar')),'-d',str(args.evidence),str(root/'negative/MixedResult.scala')]
result=subprocess.run(command,capture_output=True,text=True,timeout=30)
(args.evidence/'compile.log').write_text(json.dumps(command)+'\n'+result.stdout+result.stderr+'\nEXIT='+str(result.returncode))
assert result.returncode!=0 and 'play.api.mvc.Result' in result.stderr and 'play.mvc.Result' in result.stderr
(args.evidence/'summary.json').write_text(json.dumps({'status':'PASS','expectedCompileFailure':True,'exit':result.returncode}))
print('EXPECTED_COMPILE_FAILURE')

