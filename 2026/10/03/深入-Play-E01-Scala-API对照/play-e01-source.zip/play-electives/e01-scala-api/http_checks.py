import argparse
import concurrent.futures
import hashlib
import http.client
import json
import os
from pathlib import Path
import secrets
import socket
import subprocess
import time

parser=argparse.ArgumentParser()
parser.add_argument('--evidence',type=Path,required=True)
args=parser.parse_args()
evidence=args.evidence.resolve(); evidence.mkdir(parents=True,exist_ok=False)
root=Path(__file__).resolve().parent
records=[]; processes=[]; summary={'status':'FAIL'}
def request(port,path,method='GET',body=None,user=None,content='application/json'):
    c=http.client.HTTPConnection('127.0.0.1',port,timeout=10)
    headers={'Content-Type':content}
    if user is not None: headers['X-User']=user
    try:
        c.request(method,path,body,headers)
        r=c.getresponse(); return r.status,r.read()
    finally: c.close()
try:
    for kind in ['scala2','scala3']:
        directory=evidence/kind; directory.mkdir(); resources=directory/'resources'
        with socket.socket() as s: s.bind(('127.0.0.1',0)); port=s.getsockname()[1]
        stage=root/kind/'target/universal/stage'
        script=next(p for p in (stage/'bin').iterdir() if not p.name.endswith('.bat'))
        log=(directory/'server.log').open('w')
        command=['bash',str(script),'-J-Xms64m','-J-Xmx256m','-Dhttp.address=127.0.0.1','-Dhttp.port='+str(port),'-Dpidfile.path='+str(directory/'running.pid'),'-Dlab.workdir='+str(resources)]
        p=subprocess.Popen(command,cwd=stage,env={**os.environ,'APPLICATION_SECRET':secrets.token_hex(32)},stdout=log,stderr=subprocess.STDOUT)
        processes.append((p,log))
        start=time.monotonic()
        while time.monotonic()-start<40:
            assert p.poll() is None,kind+' startup failed'
            try:
                status,body=request(port,'/health')
                if status==200: break
            except (OSError,http.client.HTTPException): pass
            time.sleep(.03)
        else: raise AssertionError('startup timeout')
        assert str(stage) in json.loads(body)['classOrigin']
        records.append({'version':kind,'scenario':'production-start','health':json.loads(body)})
        outputs={}
        for api in ['java','scala']:
            cases=[('valid','{"value":2}',200,{'user':'alice','value':4}),('numeric-scale','{"value":2.0}',200,{'user':'alice','value':4}),('zero','{"value":0}',400,{'error':'value'}),('fraction','{"value":2.5}',400,{'error':'value'}),('wrong-field-type','{"value":"2"}',400,{'error':'value'}),('missing','{}',400,{'error':'value'}),('overflow','{"value":2147483648}',400,{'error':'value'}),('syntax','{',400,None),('oversize','{"value":2,"padding":"'+'x'*2048+'"}',413,None)]
            for name,body,expected,payload in cases:
                status,response=request(port,'/'+api+'/json','POST',body,'alice')
                assert status==expected,(kind,api,name,status,response[:100])
                if payload is not None: assert json.loads(response)==payload,(kind,api,name,response)
                outputs[(api,name)]=status
                records.append({'version':kind,'api':api,'scenario':'json-'+name,'status':status,'body':json.loads(response) if payload is not None else 'framework-error-body-not-contracted'})
            for name,body,user,expected in [('missing-user','{"value":2}',None,401),('invalid-user','{"value":2}','Alice!',401),('malformed-without-user','{',None,400)]:
                status,response=request(port,'/'+api+'/json','POST',body,user)
                assert status==expected,(kind,api,name,status)
                records.append({'version':kind,'api':api,'scenario':name,'status':status})
            status,_=request(port,'/'+api+'/json','POST','x','alice','text/plain'); assert status==415
            records.append({'version':kind,'api':api,'scenario':'wrong-content-type','status':status})
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
                futures={user:executor.submit(request,port,'/'+api+'/context',user=user) for user in ['alice','bob']}
                contexts=[]
                for user,future in futures.items():
                    status,response=future.result(); value=json.loads(response)
                    assert status==200 and value['user']==user and value['local']=='absent'
                    assert value['worker']=='api-worker' and value['origin']!=value['worker']
                    contexts.append(value)
                records.append({'version':kind,'api':api,'scenario':'cross-thread-context','results':contexts})
            status,response=request(port,'/'+api+'/context?fail=true',user='alice')
            assert status==503 and json.loads(response)=={'error':'worker'}
            records.append({'version':kind,'api':api,'scenario':'future-failure','status':status})
            id=api+'_cancel'; c=http.client.HTTPConnection('127.0.0.1',port,timeout=10)
            c.request('GET','/'+api+'/stream?id='+id); r=c.getresponse()
            assert r.status==200 and r.getheader('Transfer-Encoding')=='chunked'
            first=r.read(8192); assert first==bytes(8192); r.close(); c.close()
            deadline=time.monotonic()+6
            while time.monotonic()<deadline:
                status,body=request(port,'/state?id='+id); terminal=json.loads(body)
                if terminal.get('closed'): break
                time.sleep(.03)
            assert terminal['closed'] and not terminal['fileOpen'] and not terminal['fileExists'] and terminal['produced']<64
            records.append({'version':kind,'api':api,'scenario':'tcp-cancel','readBytes':8192,'terminal':terminal})
        assert all(outputs[('java',name)]==outputs[('scala',name)] for name,_,_,_ in cases)
        p.terminate(); code=p.wait(timeout=12); log.close(); assert code in [143,-15]
        assert (resources/'worker-stopped').read_text()=='true' and not list(resources.glob('*.resource'))
        with socket.socket() as s: assert s.connect_ex(('127.0.0.1',port))!=0
        records.append({'version':kind,'scenario':'shutdown','exit':code,'executorTerminated':True,'listenerClosed':True,'resourceFiles':0})
    summary.update(status='PASS',scenarios=len(records))
finally:
    errors=[]
    for p,log in processes:
        if p.poll() is None:
            p.terminate()
            try: p.wait(timeout=12)
            except subprocess.TimeoutExpired: p.kill(); p.wait(timeout=5); errors.append('forced cleanup')
        log.close()
    if errors: summary.update(status='FAIL',cleanupErrors=errors)
    (evidence/'observations.json').write_text(json.dumps(records,indent=2))
    (evidence/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary))
