object MixedResult {
  val result: play.mvc.Result = play.api.mvc.Results.Ok("hello")
}
