# E01: Java and Scala HTTP API contracts

Requires JDK 21 and Python 3. Set JAVA_HOME to your own JDK installation. Each independent project contains the same Java and Scala application files. scala2 freezes Scala 2.13.15; scala3 freezes Scala 3.3.4. Both use Play 3.0.6, sbt 1.10.7, PlayScala, guice and explicit javaCore (needed for Java lifecycle bindings).

From this directory:
```sh
mkdir -p .tools
curl -fL https://repo.maven.apache.org/maven2/org/scala-sbt/sbt-launch/1.10.7/sbt-launch-1.10.7.jar -o .tools/sbt-launch-1.10.7.jar
shasum -a 256 .tools/sbt-launch-1.10.7.jar
export PLAY_LAB_SBT_LAUNCHER="$PWD/.tools/sbt-launch-1.10.7.jar"
python3 build_checks.py --evidence evidence/build
python3 http_checks.py --evidence evidence/run
```

Launcher SHA256: 3cca02818047327a83efde776103a1ef92f76f72c062badbbb062499a3270c07. Network evidence directory must not already exist.

The driver starts only owned production stage scripts, generated secrets and ephemeral loopback ports. It validates equivalent successful JSON and business-error bodies; parser status codes; parser-before-auth error precedence; named-worker Future/CompletionStage context; explicit user isolation; recovered worker failure; real TCP cancellation of chunked streams; actual file resource closure/deletion before shutdown; and worker termination plus closed listeners. Every process is stopped on success or failure.

X-User is a synthetic local test identity, not a production authentication design. The ThreadLocal probe is deliberately not propagated. User identity is copied from a Scala UserRequest or Java typed request attribute into the asynchronous operation.

The negative/MixedResult.scala fixture deliberately assigns a Scala Result to a Java Result. It is outside compilation roots. To reproduce its expected compile failure with the Scala 2 compiler:

```sh
for module in scala-compiler scala-library scala-reflect; do curl -fL "https://repo.maven.apache.org/maven2/org/scala-lang/$module/2.13.15/$module-2.13.15.jar" -o ".tools/$module-2.13.15.jar"; done
export SCALA_COMPILER_CP="$PWD/.tools/scala-compiler-2.13.15.jar:$PWD/.tools/scala-library-2.13.15.jar:$PWD/.tools/scala-reflect-2.13.15.jar"
python3 negative_checks.py --evidence evidence/negative
```

The driver expects a nonzero compiler exit and diagnostics naming both Result types. It exits successfully only when the expected rejection is present.

This is a finite contract comparison. It does not establish performance, universal third-party Scala 3 compatibility, implicit MDC propagation, task cancellation on HTTP disconnect, or distributed identity propagation.
