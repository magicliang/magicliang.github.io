# Compile-time component graph

Two independent Play 3.0.6 applications use Scala 2.13.15, JDK 21 and sbt 1.10.7. `manual` has no Guice runtime dependency. `guice` is a comparison application with the same controller, service, filter and routes source bytes. Jakarta Inject 2.0.1 is an annotation API shared by both; manual wiring never interprets the annotations.

Set `JAVA_HOME` to an installed JDK 21. Download the official sbt 1.10.7 launcher, verify SHA-256 `3cca02818047327a83efde776103a1ef92f76f72c062badbbb062499a3270c07`, and set `PLAY_LAB_SBT_LAUNCHER` to its file path.

```bash
curl -fL https://repo.maven.apache.org/maven2/org/scala-sbt/sbt-launch/1.10.7/sbt-launch-1.10.7.jar -o sbt-launch-1.10.7.jar
python3 build_checks.py --evidence evidence/build
python3 http_checks.py --evidence evidence/run
```

Commands run from this directory. The HTTP evidence directory must not already exist. Tests need no database, container or external service. The helper starts only its own loopback production processes and stops each of them. It performs an expected javac failure, an expected bad-config startup failure, and three interleaved full JVM startup rounds per application. It verifies the same HTTP body, custom/security filters, host rejection, lifecycle hook and closed listener. Startup samples include JVM and HTTP polling overhead; they do not establish a universal framework performance ranking.

The manual entrypoint is a public top-level `lab.ManualLoader`. `lab.Components` constructs one `Greeting`, one `HelloController`, a generated router, and explicit filters. Its replacement constructor supplies a test service without a runtime container. The fixture at `negative/MissingDependency.java` is intentionally invalid and remains outside both applications' compilation source roots.
