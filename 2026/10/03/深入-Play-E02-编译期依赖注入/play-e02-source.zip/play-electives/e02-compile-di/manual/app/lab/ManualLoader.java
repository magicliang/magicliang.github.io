package lab;
import play.Application;
import play.ApplicationLoader;
import play.LoggerConfigurator;
public final class ManualLoader implements ApplicationLoader {
    @Override public Application load(Context context) {
        LoggerConfigurator.apply(context.environment().classLoader()).ifPresent(logger ->
                logger.configure(context.environment(), context.initialConfig()));
        return new Components(context).application();
    }
}
