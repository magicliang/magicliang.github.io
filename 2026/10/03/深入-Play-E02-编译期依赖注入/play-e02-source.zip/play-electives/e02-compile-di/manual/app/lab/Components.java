package lab;
import java.util.ArrayList;
import java.util.List;
import play.ApplicationLoader;
import play.BuiltInComponentsFromContext;
import play.filters.components.HttpFiltersComponents;
import play.mvc.EssentialFilter;
import play.routing.Router;
import controllers.HelloController;
public final class Components extends BuiltInComponentsFromContext implements HttpFiltersComponents {
    private final Message message;
    private final HelloController controller;
    public Components(ApplicationLoader.Context context) { this(context, null); }
    public Components(ApplicationLoader.Context context, Message replacement) {
        super(context);
        message = replacement == null ? new Greeting(config(), applicationLifecycle()) : replacement;
        controller = new HelloController(message);
    }
    public Message message() { return message; }
    @Override public Router router() { return new router.Routes(scalaHttpErrorHandler(), controller).asJava(); }
    @Override public List<EssentialFilter> httpFilters() {
        List<EssentialFilter> filters = new ArrayList<>(HttpFiltersComponents.super.httpFilters());
        filters.add(new HeaderFilter(materializer()).asScala().asJava());
        return filters;
    }
}
