import static org.junit.Assert.*;
import static play.test.Helpers.*;
import java.util.Map;
import org.junit.Test;
import lab.Components;
import lab.Greeting;
import play.Application;
import play.ApplicationLoader;
import play.Environment;
import play.mvc.Http;
public final class ComponentsTest {
    private ApplicationLoader.Context context() { return new ApplicationLoader.Context(Environment.simple(), Map.of("lab.greeting", "prod")); }
    @Test public void realGraphRoutesFiltersAndLifecycle() {
        Components components = new Components(context());
        Greeting greeting = (Greeting) components.message();
        Application app = components.application();
        running(app, () -> {
            var result = route(app, new Http.RequestBuilder().uri("/hello"));
            assertEquals("hello:prod", contentAsString(result));
            assertEquals("explicit", result.header("X-Graph").orElseThrow());
            assertSame(greeting, components.message());
            assertFalse(greeting.closed.get());
        });
        assertTrue(greeting.closed.get());
    }
    @Test public void replacementIsExplicitConstructorInput() {
        Components components = new Components(context(), () -> "test-double");
        Application app = components.application();
        running(app, () -> assertEquals("hello:test-double", contentAsString(route(app, new Http.RequestBuilder().uri("/hello")))));
    }
}
