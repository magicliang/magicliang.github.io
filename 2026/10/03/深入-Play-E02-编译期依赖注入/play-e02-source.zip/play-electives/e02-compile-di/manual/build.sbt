ThisBuild / scalaVersion := "2.13.15"
ThisBuild / version := "0.1.0"
lazy val root = (project in file(".")).enablePlugins(PlayJava).settings(
  name := "compile-di-manual",
  libraryDependencies ++= Seq("jakarta.inject" % "jakarta.inject-api" % "2.0.1", "junit" % "junit" % "4.13.2" % Test, "com.github.sbt" % "junit-interface" % "0.13.3" % Test),
  Test / parallelExecution := false)
