from pathlib import Path
import argparse
import os
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--evidence', type=Path, required=True)
args = parser.parse_args()
args.evidence.mkdir(parents=True, exist_ok=True)
root = Path(__file__).resolve().parent
java = str(Path(os.environ['JAVA_HOME']) / 'bin/java')
launcher = os.environ['PLAY_LAB_SBT_LAUNCHER']
for kind in ['manual', 'guice']:
    command = [java, '-Xms256m', '-Xmx1536m', '-Dsbt.supershell=false', '-Dsbt.log.noformat=true', '-Dsbt.server.autostart=false', '-jar', launcher, 'clean', 'test', 'stage']
    with (args.evidence / (kind + '-build.log')).open('w') as log:
        print(command, file=log, flush=True)
        started = time.monotonic()
        process = subprocess.Popen(command, cwd=root/kind, stdout=log, stderr=subprocess.STDOUT)
        try: code = process.wait(timeout=360)
        finally:
            if process.poll() is None:
                process.terminate()
                try: process.wait(timeout=15)
                except subprocess.TimeoutExpired: process.kill(); process.wait(timeout=5)
        print('EXIT', code, 'SECONDS', time.monotonic()-started, file=log)
    print(kind, code, flush=True)
    if code: raise SystemExit(code)
