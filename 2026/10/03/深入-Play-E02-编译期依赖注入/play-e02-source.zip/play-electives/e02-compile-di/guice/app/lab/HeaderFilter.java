package lab;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import java.util.concurrent.CompletionStage;
import java.util.function.Function;
import org.apache.pekko.stream.Materializer;
import play.mvc.Filter;
import play.mvc.Http;
import play.mvc.Result;
@Singleton
public final class HeaderFilter extends Filter {
    @Inject public HeaderFilter(Materializer materializer) { super(materializer); }
    public CompletionStage<Result> apply(Function<Http.RequestHeader, CompletionStage<Result>> next, Http.RequestHeader request) {
        return next.apply(request).thenApply(result -> result.withHeader("X-Graph", "explicit"));
    }
}
