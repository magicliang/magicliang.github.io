package lab;
public interface Message { String text(); }
