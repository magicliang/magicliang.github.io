import com.google.inject.AbstractModule;
public final class Module extends AbstractModule {
    @Override protected void configure() { bind(lab.Message.class).to(lab.Greeting.class); }
}
