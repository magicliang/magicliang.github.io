import static org.junit.Assert.*;
import static play.test.Helpers.*;
import org.junit.Test;
import play.inject.guice.GuiceApplicationBuilder;
import play.mvc.Http;
public final class GuiceTest {
    @Test public void equivalentHelloAndFilter() {
        var app = new GuiceApplicationBuilder().build();
        running(app, () -> {
            var result = route(app, new Http.RequestBuilder().uri("/hello"));
            assertEquals("hello:prod", contentAsString(result));
            assertEquals("explicit", result.header("X-Graph").orElseThrow());
        });
    }
}
