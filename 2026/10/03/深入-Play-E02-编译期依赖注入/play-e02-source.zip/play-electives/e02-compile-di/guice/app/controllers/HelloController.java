package controllers;
import jakarta.inject.Inject;
import lab.Message;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
public final class HelloController extends Controller {
    private final Message message;
    @Inject public HelloController(Message message) { this.message = message; }
    public Result hello() { return ok("hello:" + message.text()); }
    public Result state() { return ok(Json.newObject().put("serviceClass", message.getClass().getName())); }
}
