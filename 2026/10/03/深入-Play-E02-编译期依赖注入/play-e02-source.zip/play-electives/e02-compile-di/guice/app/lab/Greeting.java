package lab;
import com.typesafe.config.Config;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import play.inject.ApplicationLifecycle;
@Singleton
public final class Greeting implements Message {
    private final String greeting;
    public final AtomicBoolean closed = new AtomicBoolean();
    @Inject public Greeting(Config config, ApplicationLifecycle lifecycle) {
        greeting = config.getString("lab.greeting");
        if (greeting.isBlank()) throw new IllegalArgumentException("nonempty lab.greeting required");
        lifecycle.addStopHook(() -> {
            closed.set(true);
            try {
                if (config.hasPath("lab.journal")) Files.writeString(Path.of(config.getString("lab.journal")), "greeting-closed\n", StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                return CompletableFuture.completedFuture(null);
            } catch (Exception error) { return CompletableFuture.failedFuture(error); }
        });
    }
    public String text() { return greeting; }
}
