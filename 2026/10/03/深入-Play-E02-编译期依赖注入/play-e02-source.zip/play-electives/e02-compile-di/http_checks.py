import argparse
import hashlib
import http.client
import json
import os
from pathlib import Path
import secrets
import socket
import statistics
import subprocess
import time
import xml.etree.ElementTree as ET
import zipfile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--evidence', type=Path, required=True)
    args = parser.parse_args()
    evidence = args.evidence.resolve()
    evidence.mkdir(parents=True, exist_ok=False)
    root = Path(__file__).resolve().parent
    java_home = Path(os.environ['JAVA_HOME'])
    records, processes = [], []
    summary = {'status': 'FAIL'}

    def port():
        with socket.socket() as s:
            s.bind(('127.0.0.1', 0)); return s.getsockname()[1]

    def request(number, host='localhost'):
        conn = http.client.HTTPConnection('127.0.0.1', number, timeout=2)
        try:
            conn.request('GET', '/hello', headers={'Host':host})
            response = conn.getresponse()
            return response.status, response.read().decode(), dict(response.getheaders())
        finally: conn.close()

    class Instance:
        def __init__(self, kind, name, bad=False):
            self.name, self.port = name, port()
            self.journal = evidence/(name+'.journal')
            self.log = (evidence/(name+'.log')).open('w')
            stage = root/kind/'target/universal/stage'
            script = next(p for p in (stage/'bin').iterdir() if not p.name.endswith('.bat'))
            command = ['bash',str(script),'-J-Xms64m','-J-Xmx256m','-Dhttp.address=127.0.0.1','-Dhttp.port='+str(self.port),'-Dpidfile.path='+str(evidence/(name+'.pid')),'-Dlab.journal='+str(self.journal)]
            if bad: command.append('-Dlab.greeting=')
            self.start = time.monotonic()
            self.process = subprocess.Popen(command, cwd=stage, env={**os.environ,'JAVA_HOME':str(java_home),'APPLICATION_SECRET':secrets.token_hex(32)}, stdout=self.log, stderr=subprocess.STDOUT)
            processes.append(self)

        def ready(self):
            deadline = time.monotonic()+30
            while time.monotonic()<deadline:
                assert self.process.poll() is None, self.name+' exited before ready'
                try:
                    status, body, headers = request(self.port)
                    if status == 200: return time.monotonic()-self.start, body, headers
                except (OSError,http.client.HTTPException): pass
                time.sleep(.01)
            raise AssertionError(self.name+' startup timeout')

        def stop(self):
            if self.process.poll() is None:
                self.process.terminate()
                try: code = self.process.wait(timeout=12)
                except BaseException:
                    self.process.kill(); self.process.wait(timeout=5); raise
                assert code in (143,-15)
            self.log.close()
            with socket.socket() as s: assert s.connect_ex(('127.0.0.1',self.port)) != 0

    try:
        shared = ['app/lab/Message.java','app/lab/Greeting.java','app/lab/HeaderFilter.java','app/controllers/HelloController.java','conf/routes']
        assert all((root/'manual'/p).read_bytes() == (root/'guice'/p).read_bytes() for p in shared)
        manifests = {}
        for kind in ['manual','guice']:
            jars = sorted((root/kind/'target/universal/stage/lib').glob('*.jar'))
            manifests[kind] = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in jars}
            has_guice = any(p.name.startswith(('com.google.inject.guice-', 'org.playframework.play-guice_')) for p in jars)
            assert has_guice == (kind == 'guice')
            for test in (root/kind/'target/test-reports').glob('TEST-*.xml'):
                report = ET.parse(test).getroot()
                assert report.attrib['failures'] == '0' and report.attrib['errors'] == '0' and report.attrib['skipped'] == '0'
            records.append({'scenario':'dependency-boundary','kind':kind,'jarCount':len(jars),'guiceJarPresent':has_guice})
        (evidence/'artifacts.json').write_text(json.dumps(manifests,indent=2))
        cp = ':'.join(str(p) for p in (root/'manual/target/universal/stage/lib').glob('*.jar'))
        result = subprocess.run([str(java_home/'bin/javac'),'-J-Duser.language=en','--release','21','-cp',cp,'-d',str(evidence/'negative-classes'),str(root/'negative/MissingDependency.java')],capture_output=True,text=True)
        (evidence/'missing-dependency-javac.log').write_text(result.stdout+result.stderr+'\nEXIT='+str(result.returncode))
        assert result.returncode != 0 and 'constructor HelloController' in result.stderr and 'required: Message' in result.stderr
        records.append({'scenario':'missing-constructor-dependency','javacExit':result.returncode,'required':'Message','provided':'no arguments'})
        bad = Instance('manual','bad-config',bad=True)
        code = bad.process.wait(timeout=30)
        bad.stop()
        assert code != 0 and 'nonempty lab.greeting required' in (evidence/'bad-config.log').read_text()
        records.append({'scenario':'bad-runtime-config','exit':code,'listenerClosed':True,'reason':'nonempty lab.greeting required'})
        samples = {'manual':[],'guice':[]}
        for round_no in range(3):
            order = ['manual','guice'] if round_no % 2 == 0 else ['guice','manual']
            for kind in order:
                current = Instance(kind,kind+'-'+str(round_no))
                elapsed,body,headers = current.ready()
                assert body == 'hello:prod' and headers.get('X-Graph') == 'explicit'
                assert headers.get('X-Content-Type-Options') == 'nosniff'
                rejected,_,_ = request(current.port,'untrusted.invalid')
                assert rejected == 400
                samples[kind].append(elapsed)
                current.stop()
                assert current.journal.read_text() == 'greeting-closed\n'
                records.append({'scenario':'production-start-stop','round':round_no,'kind':kind,'secondsToFirst200':elapsed,'body':body,'filter':'explicit','securityHeader':'nosniff','badHostStatus':rejected,'stopHook':'greeting-closed','exit':current.process.returncode,'listenerClosed':True})
        summary.update(status='PASS', rounds=3, samples=samples, medians={k:statistics.median(v) for k,v in samples.items()},scenarios=len(records))
    finally:
        errors=[]
        for process in processes:
            try: process.stop()
            except BaseException as error: errors.append(repr(error))
        if errors: summary.update(status='FAIL',cleanupErrors=errors)
        for name,data in [('summary.json',summary),('observations.json',records)]:
            (evidence/name).write_text(json.dumps(data,indent=2))
        if errors: raise RuntimeError(errors)
    print(json.dumps(summary))


if __name__ == '__main__': main()
