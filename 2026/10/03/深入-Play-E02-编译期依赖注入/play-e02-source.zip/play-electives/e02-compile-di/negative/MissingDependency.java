public final class MissingDependency {
    public static void main(String[] args) {
        new controllers.HelloController();
    }
}
