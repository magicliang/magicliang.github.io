from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

evidence = Path(__file__).resolve().parent
root = Path('/private/tmp/play-compile-di-work-20261003')
draft = evidence/'article-draft.md'
writing = evidence/'writing'
writing.mkdir(exist_ok=True)
scan = subprocess.run(['python3','/Users/magicliang/.codex/skills/anti-ai-tone/scripts/check_prose.py','--profile','tech','--json',str(draft)],capture_output=True,text=True,check=True)
(writing/'01-anti-ai-tone.json').write_text(scan.stdout)
assert json.loads(scan.stdout)['errors'] == 0 and json.loads(scan.stdout)['warnings'] == 0
prose = re.sub(r'```.*?```','',draft.read_text(),flags=re.S)
matches = [p for p in ['我们','咱们','本人','我觉得','我认为','各位看官','欲知后事','让我','我在','花了一个下午'] if p in prose]
assert not matches
(writing/'02-anti-persona-fabrication.json').write_text(json.dumps({'status':'PASS','matches':matches,'manualReview':'Read after anti-ai-tone. No invented bodily experience, personal history, identity or writing narration. Technical prose grounded in fixed source and retained observations.'},indent=2))
blocks = re.findall(r'```java\n(.*?)\n```',draft.read_text(),re.S)
assert len(blocks) == 2
sources=[]
for block in blocks:
    name = re.search(r'public final class (\w+)',block).group(1)
    expected = root/'manual/app/lab'/(name+'.java')
    assert expected.read_text().strip() == block.strip()
    output = writing/(name+'.java')
    output.write_text(block+'\n')
    sources.append(str(output))
cp=':'.join(str(p) for p in (root/'manual/target/universal/stage/lib').glob('*.jar'))
classes=writing/'compiled'
classes.mkdir(exist_ok=True)
cmd=[str(Path(os.environ['JAVA_HOME'])/'bin/javac'),'--release','21','-cp',cp,'-d',str(classes)]+sources
result=subprocess.run(cmd,capture_output=True,text=True)
(writing/'javac.log').write_text(json.dumps(cmd)+'\n'+result.stdout+result.stderr+'\nEXIT='+str(result.returncode))
assert result.returncode == 0
for name in ['ManualLoader','Components']: assert (classes/'lab'/(name+'.class')).stat().st_size > 0
build={}
for kind in ['manual','guice']:
    output=evidence/('junit-'+kind)
    output.mkdir(exist_ok=True)
    cases=[]
    for file in (root/kind/'target/test-reports').glob('TEST-*.xml'):
        shutil.copy2(file,output/file.name)
        for case in ET.parse(file).getroot().iter('testcase'):
            assert all(case.find(k) is None for k in ['failure','error','skipped'])
            cases.append(case.attrib['classname']+'.'+case.attrib['name'])
    assert len(cases) == (2 if kind == 'manual' else 1)
    jar=next((root/kind/'target/universal/stage/lib').glob('*-sans-externalized.jar'))
    byteproof={}
    with zipfile.ZipFile(jar) as z:
        for cls in (root/kind/'target/scala-2.13/classes').rglob('*.class'):
            name=str(cls.relative_to(root/kind/'target/scala-2.13/classes'))
            if name.startswith(('controllers/HelloController','lab/')) or name == 'Module.class':
                assert cls.read_bytes() == z.read(name)
                byteproof[name]=hashlib.sha256(cls.read_bytes()).hexdigest()
    build[kind]={'executedMethods':cases,'applicationJarSHA256':hashlib.sha256(jar.read_bytes()).hexdigest(),'classByteEquality':byteproof}
(evidence/'build-summary.json').write_text(json.dumps(build,indent=2))
paths=[]
for kind in ['manual','guice']:
    for sub in ['app','conf','test']:
        paths.extend(p for p in (root/kind/sub).rglob('*') if p.is_file())
    paths += [root/kind/'build.sbt',root/kind/'project/plugins.sbt',root/kind/'project/build.properties']
paths += [root/p for p in ['README.md','build_checks.py','http_checks.py','negative/MissingDependency.java']]
manifest={'sources':[{'source':str(p),'destination':'examples/play-electives/e02-compile-di/'+str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(paths)],'evidenceDestination':'examples/play-electives/evidence/e02/isolated'}
(evidence/'integration-manifest.json').write_text(json.dumps(manifest,indent=2))
network=json.loads((evidence/'run-final/summary.json').read_text())
assert network['status'] == 'PASS'
assert len(re.findall('```mermaid',draft.read_text())) == 2
receipt={'status':'PASS','sourceFiles':len(paths),'junitExecuted':3,'junitSkipped':0,'network':network,'orderedScans':['01-anti-ai-tone.json','02-anti-persona-fabrication.json'],'completeJavaExamplesCompiled':2,'mermaidDiagrams':2,'articleSHA256':hashlib.sha256(draft.read_bytes()).hexdigest()}
(evidence/'delivery.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))
