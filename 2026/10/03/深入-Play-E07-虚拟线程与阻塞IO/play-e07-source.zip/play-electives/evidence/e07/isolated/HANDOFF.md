# E07 isolated acceptance

Source project: `/private/tmp/play-virtual-thread-work-20261003`.
Public destination: `examples/play-electives/e07-virtual-threads`.
Use `manifest.json` for exactly 11 source/config/example files. Do not copy target or unrelated temporary files.

Acceptance: `JAVA_HOME=<JDK21> PLAY_LAB_SBT_LAUNCHER=<1.10.7 jar> bash sbtw test stage` exited 0; `build-04.log` and `TEST-VirtualTest.xml` contain 2 executed tests, no failures/skips. Manifest compares the compiled VirtualController class bytes against the actual production stage application jar.

Runtime: `JAVA_HOME=<JDK21> PODMAN=<podman path> VT_DB_CONTAINER=play-db-lab-20261003-pipeline-43 python3 verify.py <run-02>` exited 0. `run-02/summary.json` PASS; 12 cells / 288 HTTP measurement requests, plus a 48-task fixed burst, timeout/late SQL, monitor and lock comparisons. Independent SQL counts match every cell. Preserve exact timings from run-02 in the article; future shared replay should receive a new evidence directory.

JFR: `run-02/runtime.jfr`, `pinned-events.json`, and actual `threads.json`. Six monitorSleep pinned events; zero lockSleep events or submit failures. Dump contains 40 named business virtual threads (38 Hikari borrow / 2 execute), while an earlier sample recorded 48 active tasks / 46 pool waiters. Zero JDBC pinned events is scoped to this recording and 20 ms threshold.

Cleanup: SIGTERM exit 143, recording/pool/platform/virtual/clock closed, running 0, permits 4, listener closed, independent pg_stat_activity count 0. The fixture container remains running and belongs to the root task. Failed run-01 preserves a real JFR JVM shutdown-hook race, fixed by explicit recording archival before SIGTERM and pool cleanup independent of recording errors. The full matrix reran after the fix.

Writing: `article.md` passed java-tech-writer review, anti-ai-tone (0 errors / 0 warnings), then anti-persona-fabrication (no narration hits; manual review). `writing-receipt.json` records the final SHA. Exact complete Java block equals AdmissionExample.java, compiled and executed with output in `example.log`. Shared E07 post and 1200×480 SVG cover now exist. Root still owns packaging, generated page/browser validation, navigation/status integration and local commit.

No Git/index, shared lab, status, browser, or other posts were modified by this slice. Evidence can be copied to `examples/play-electives/evidence/e07/isolated`; omit generated example-classes if desired, retaining compilation invocation and output.
