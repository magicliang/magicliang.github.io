#!/usr/bin/env python3
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import statistics
import subprocess
import sys
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parent
OUT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / 'evidence/run'
OUT.mkdir(parents=True, exist_ok=False)
JAVA = Path(os.environ['JAVA_HOME']) / 'bin'
PODMAN = os.environ.get('PODMAN', 'podman')
CONTAINER = os.environ['VT_DB_CONTAINER']
SCHEMA = 'vt_' + str(time.time_ns())
with socket.socket() as s:
    s.bind(('127.0.0.1', 0))
    PORT = s.getsockname()[1]
BASE = f'http://127.0.0.1:{PORT}'
observations = []
sql_observations = []

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def request(path):
    start = time.monotonic()
    try:
        with urllib.request.urlopen(BASE + path, timeout=15) as r:
            code, body = r.status, r.read().decode()
    except urllib.error.HTTPError as e:
        code, body = e.code, e.read().decode()
    try:
        data = json.loads(body)
    except ValueError:
        data = body
    return {'path': path, 'code': code, 'body': data, 'millis': (time.monotonic() - start) * 1000}

def stats():
    r = request('/stats')
    assert r['code'] == 200, r
    return r['body']

def sql(query):
    p = subprocess.run([PODMAN, 'exec', CONTAINER, 'psql', '-U', 'postgres', '-d', 'play_lab',
                        '-XAt', '-v', 'ON_ERROR_STOP=1', '-c', query], text=True, capture_output=True, check=True)
    sql_observations.append({'sql': query, 'stdout': p.stdout, 'stderr': p.stderr})
    return p.stdout.strip()

def drain():
    for _ in range(100):
        n = stats()
        if n['running'] == 0 and n['platformQueued'] == 0 and n['permits'] == 4:
            return n
        time.sleep(.025)
    raise AssertionError('workers did not drain')

def percentile(values, q):
    values = sorted(values)
    return values[min(len(values) - 1, int((len(values) - 1) * q))]

stage = ROOT / 'target/universal/stage'
jar_manifest = {str(p.relative_to(stage)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in sorted(stage.rglob('*')) if p.is_file()}
save('stage-manifest.json', jar_manifest)
log = (OUT / 'server.log').open('w')
cmd = [str(stage / 'bin/play-virtual'), f'-Dhttp.port={PORT}', '-Dhttp.address=127.0.0.1',
       f'-Dpidfile.path={OUT / "RUNNING_PID"}', f'-Dvt.evidence={OUT}', f'-Dvt.schema={SCHEMA}',
       '-J-Xms256m', '-J-Xmx768m', '-J-Djdk.virtualThreadScheduler.parallelism=2']
process = subprocess.Popen(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                           env={**os.environ, 'JAVA_HOME': str(JAVA.parent)})
summary = {'status': 'FAIL', 'schema': SCHEMA, 'port': PORT, 'command': cmd}
try:
    for _ in range(240):
        if process.poll() is not None:
            raise AssertionError(f'server exited {process.returncode}')
        try:
            first = stats()
            break
        except (OSError, urllib.error.URLError):
            time.sleep(.1)
    else:
        raise AssertionError('server did not start')
    save('initial.json', first)
    assert first['permits'] == 4
    cells = []
    for round_number in range(3):
        for concurrency in (1, 8):
            for mode in ('platform', 'virtual'):
                before = drain()
                start = time.monotonic()
                with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as clients:
                    results = list(clients.map(request, [f'/work/{mode}/r{round_number}_{concurrency}_{mode}_{i}'
                                                        for i in range(24)]))
                elapsed = time.monotonic() - start
                observations.extend(results)
                after = drain()
                good = [x for x in results if x['code'] == 200]
                assert good and all(x['code'] in (200, 503) for x in results)
                assert all(x['body']['virtual'] == (mode == 'virtual') and x['body']['committed'] for x in good)
                assert all(x['body']['thread'].startswith('vt-business-' if mode == 'virtual' else 'vt-platform-') for x in good)
                assert after['peakPoolActive'] <= 2 and after['peakRunning'] <= 4
                count = int(sql(f"SELECT count(*) FROM {SCHEMA}.writes WHERE id LIKE 'r{round_number}_{concurrency}_{mode}_%';"))
                assert count == len(good)
                cells.append({'round': round_number, 'concurrency': concurrency, 'mode': mode,
                              'requests': 24, 'ok': len(good), 'rejected': 24 - len(good),
                              'elapsedSeconds': elapsed, 'successfulPerSecond': len(good) / elapsed,
                              'p50Millis': statistics.median([x['millis'] for x in good]),
                              'p95Millis': percentile([x['millis'] for x in good], .95),
                              'queueMaxMillis': max(x['body']['queueMillis'] for x in good),
                              'poolWaitMaxMillis': max(x['body']['poolWaitMillis'] for x in good),
                              'before': before, 'after': after})
    save('cells.json', cells)
    before_timeout = drain()
    timeout = request('/work/virtual/late_write?millis=100&budget=10')
    observations.append(timeout)
    assert timeout['code'] == 504, timeout
    at_timeout = stats()
    assert at_timeout['finished'] == before_timeout['finished'] and at_timeout['running'] == 1, at_timeout
    drain()
    assert sql(f"SELECT count(*) FROM {SCHEMA}.writes WHERE id='late_write';") == '1'
    save('late-write.json', {'http': timeout, 'atTimeout': at_timeout, 'sqlCommittedAfter504': True})
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as client:
        future = client.submit(request, '/burst')
        for _ in range(100):
            during = stats()
            if during['poolWait'] >= 30:
                break
            time.sleep(.005)
        assert during['poolActive'] == 2 and during['poolWait'] >= 30, during
        dump = subprocess.run([str(JAVA / 'jcmd'), str(first['pid']), 'Thread.dump_to_file',
                               '-format=json', str(OUT / 'threads.json')], text=True, capture_output=True, check=True)
        (OUT / 'thread-dump-command.txt').write_text(dump.stdout + dump.stderr)
        burst = future.result()
    observations.append(burst)
    assert burst['code'] == 200 and len(burst['body']) == 48
    assert all(x['virtual'] and x['committed'] for x in burst['body'])
    assert sql(f"SELECT count(*) FROM {SCHEMA}.writes WHERE id LIKE 'burst_%';") == '48'
    save('burst.json', {'during': during, 'after': drain(), 'maxPoolWaitMillis': max(x['poolWaitMillis'] for x in burst['body'])})
    for kind in ('monitor', 'lock'):
        r = request('/pin/' + kind)
        observations.append(r)
        assert r['code'] == 200 and r['body']['virtual']
    summary.update(status='PASS', cells=len(cells), requests=288, snapshot=drain())
    assert request('/recording')['code'] == 200
finally:
    failures = []
    try:
        process.send_signal(signal.SIGTERM)
        try:
            summary['exit'] = process.wait(timeout=25)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
            failures.append('SIGTERM timed out; forced kill')
        log.close()
        summary['cleanup'] = json.loads((OUT / 'cleanup.json').read_text())
        assert all(summary['cleanup'][key] for key in ('platformTerminated', 'virtualTerminated', 'clockTerminated', 'poolClosed', 'recordingClosed'))
        assert summary['cleanup']['permits'] == 4 and summary['cleanup']['running'] == 0
        assert sql(f"SELECT count(*) FROM pg_stat_activity WHERE application_name='{SCHEMA}';") == '0'
        try:
            with socket.create_connection(('127.0.0.1', PORT), timeout=.3):
                raise AssertionError('listener remains open')
        except ConnectionRefusedError:
            summary['listenerClosed'] = True
        printed = subprocess.run([str(JAVA / 'jfr'), 'print', '--json', '--events',
                                  'jdk.VirtualThreadPinned,jdk.VirtualThreadSubmitFailed', str(OUT / 'runtime.jfr')],
                                 text=True, capture_output=True, check=True)
        (OUT / 'pinned-events.json').write_text(printed.stdout)
        events = json.loads(printed.stdout)['recording']['events']
        pinned = [x for x in events if x['type'] == 'jdk.VirtualThreadPinned']
        def has_frame(event, name):
            return any(f['method']['name'] == name for f in (event['values'].get('stackTrace') or {}).get('frames', []))
        summary['jfr'] = {'pinnedEvents': len(pinned),
                          'monitorSleepEvents': sum(has_frame(x, 'monitorSleep') for x in pinned),
                          'lockSleepEvents': sum(has_frame(x, 'lockSleep') for x in pinned),
                          'submitFailed': sum(x['type'] == 'jdk.VirtualThreadSubmitFailed' for x in events)}
        assert summary['jfr']['monitorSleepEvents'] >= 6 and summary['jfr']['lockSleepEvents'] == 0
    except BaseException as e:
        failures.append(repr(e))
    for name, obj in [('observations.json', observations), ('sql-observations.json', sql_observations)]:
        try:
            save(name, obj)
        except BaseException as e:
            failures.append(repr(e))
    if failures:
        summary['status'] = 'FAIL'
        summary['cleanupErrors'] = failures
    save('summary.json', summary)
    if failures:
        raise RuntimeError(failures)
print(json.dumps(summary, indent=2))
