import java.util.concurrent.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class VirtualTest {
    @Test public void virtualFactoryCreatesVirtualThread() throws Exception {
        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            assertTrue(executor.submit(() -> Thread.currentThread().isVirtual()).get());
        }
    }
    @Test public void responseTimeoutDoesNotReleaseBusinessAdmission() throws Exception {
        Semaphore permit = new Semaphore(1);
        CountDownLatch entered = new CountDownLatch(1);
        CountDownLatch release = new CountDownLatch(1);
        CompletableFuture<String> response = new CompletableFuture<>();
        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            assertTrue(permit.tryAcquire());
            executor.execute(() -> {
                entered.countDown();
                try { release.await(); response.complete("commit"); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                finally { permit.release(); }
            });
            try {
                assertTrue(entered.await(2, TimeUnit.SECONDS));
                assertTrue(response.complete("504"));
                assertEquals(0, permit.availablePermits());
            } finally { release.countDown(); }
        }
        assertEquals(1, permit.availablePermits());
        assertEquals("504", response.join());
    }
}
