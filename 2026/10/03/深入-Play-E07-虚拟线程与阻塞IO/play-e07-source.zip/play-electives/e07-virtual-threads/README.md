# Play E07: virtual threads and blocking JDBC

Independent local-only Play 3.0.6 experiment. Requires JDK 21, sbt 1.10.7, Python 3.9+, PostgreSQL 17.6 and Podman CLI for independent SQL observations. Fixed dependencies: HikariCP 5.0.1, PostgreSQL JDBC 42.7.5, Scala 2.13.15. This deliberately small fixture has a synthetic secret, no authentication, and state-changing GET routes; bind to loopback and do not deploy it as an application.

Run from `examples/play-electives/e07-virtual-threads`. Set public local paths and the identity of an already running disposable PostgreSQL container. The helper neither starts nor stops the database. It creates only its own timestamped `vt_*` schema and retains synthetic rows as evidence.

```sh
export JAVA_HOME=/path/to/jdk-21
export PLAY_LAB_SBT_LAUNCHER=/path/to/sbt-launch-1.10.7.jar
export VT_JDBC_URL='jdbc:postgresql://127.0.0.1:5432/play_lab?connectTimeout=3&socketTimeout=5'
export VT_DB_USER=postgres
export VT_DB_PASSWORD=lab-only-password
export VT_DB_CONTAINER=your-disposable-postgres-container
bash sbtw test stage
python3 verify.py evidence/run-new
```

The container's database must be `play_lab`, with `postgres` as the SQL verification user; `VT_DB_USER` controls the application connection only. `PODMAN` optionally names the CLI executable. Use a new evidence directory for every invocation. The helper starts an owned stage process on a random loopback port and runs 12 finite comparison cells (3 rounds × 2 modes × concurrency 1/8, 24 requests each), one bounded 48-task burst, a late SQL commit after HTTP 504, and monitor/ReentrantLock JFR contrasts. Each success is checked against independent SQL. The order is platform then virtual in every cell; there is no dedicated warmup. Results show this fixture's waiting and rejection behavior, not a calibrated performance ranking.

Both modes acquire the same four-permit admission gate before submitting. Platform mode uses two workers plus a two-slot queue; virtual mode creates a named virtual thread per task. The Hikari pool always has two connections. `/burst` intentionally bypasses admission for exactly 48 tasks per invocation; only the helper should call it, once per run. This is a finite demonstration of pool waiting, not a safe public endpoint.

JFR enables `jdk.VirtualThreadPinned` at 20 ms. `/recording` stops, dumps and closes the recording before SIGTERM. Keeping recording finalization outside competing JVM shutdown hooks prevents a second `Recording.stop` from failing and skipping other resources. Play's lifecycle drains both executors, stops the sampling clock and closes Hikari. `cleanup.json`, the closed TCP listener, and `pg_stat_activity=0` are separate observations. A failure still writes the available HTTP/SQL evidence and a FAIL summary.

`cells.json` contains successful-response p50/p95, rejected counts, executor/pool wait, total JVM allocated bytes, heap usage and GC snapshots. `getTotalThreadAllocatedBytes` is a process-wide approximation, not per-virtual-thread attribution; framework/JFR/HTTP overhead is included. `threads.json` is an actual JDK 21 JSON thread dump during the 48-task burst. `pinned-events.json` and `runtime.jfr` preserve actual stacks. Zero events for a path only means none crossed the configured threshold in this recording.

The standalone article example compiles and runs on JDK 21:

```sh
mkdir -p evidence/example-classes
"$JAVA_HOME/bin/javac" -d evidence/example-classes AdmissionExample.java
"$JAVA_HOME/bin/java" -cp evidence/example-classes AdmissionExample
```
