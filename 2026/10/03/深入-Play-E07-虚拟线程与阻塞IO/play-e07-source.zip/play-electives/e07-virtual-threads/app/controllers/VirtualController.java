package controllers;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.concurrent.locks.ReentrantLock;
import jdk.jfr.Recording;
import play.inject.ApplicationLifecycle;
import play.libs.Json;
import play.mvc.*;

@Singleton
public final class VirtualController extends Controller {
    private static final Object PIN_MONITOR = new Object();
    private final HikariDataSource pool;
    private final ThreadPoolExecutor platform = new ThreadPoolExecutor(2, 2, 0, TimeUnit.SECONDS,
        new ArrayBlockingQueue<>(2), Thread.ofPlatform().name("vt-platform-", 0).factory());
    private final ExecutorService virtual = Executors.newThreadPerTaskExecutor(
        Thread.ofVirtual().name("vt-business-", 0).factory());
    private final ScheduledExecutorService clock = Executors.newSingleThreadScheduledExecutor(
        Thread.ofPlatform().name("vt-clock").factory());
    private final Semaphore admission = new Semaphore(4);
    private final AtomicInteger running = new AtomicInteger();
    private final AtomicInteger peakRunning = new AtomicInteger();
    private final AtomicInteger peakPoolActive = new AtomicInteger();
    private final AtomicInteger peakPoolWait = new AtomicInteger();
    private final AtomicInteger rejected = new AtomicInteger();
    private final AtomicInteger finished = new AtomicInteger();
    private final AtomicBoolean closing = new AtomicBoolean();
    private final AtomicBoolean recordingClosed = new AtomicBoolean();
    private final Recording recording = new Recording();
    private final Path output;
    private final String schema;

    @Inject
    public VirtualController(ApplicationLifecycle lifecycle) throws Exception {
        output = Path.of(System.getProperty("vt.evidence", "evidence/run")).toAbsolutePath();
        Files.createDirectories(output);
        schema = System.getProperty("vt.schema", "vt_lab");
        if (!schema.matches("vt_[a-z0-9_]+")) throw new IllegalArgumentException("own vt_ schema required");
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(System.getenv().getOrDefault("VT_JDBC_URL",
            "jdbc:postgresql://127.0.0.1:35711/play_lab?connectTimeout=3&socketTimeout=5"));
        config.setUsername(System.getenv().getOrDefault("VT_DB_USER", "postgres"));
        config.setPassword(System.getenv().getOrDefault("VT_DB_PASSWORD", "lab-only-password"));
        config.setMaximumPoolSize(2);
        config.setMinimumIdle(2);
        config.setConnectionTimeout(5000);
        config.setPoolName("vt-pool");
        config.addDataSourceProperty("ApplicationName", schema);
        pool = new HikariDataSource(config);
        try (Connection c = pool.getConnection(); var s = c.createStatement()) {
            s.execute("CREATE SCHEMA IF NOT EXISTS " + schema);
            s.execute("CREATE TABLE IF NOT EXISTS " + schema + ".writes(id text PRIMARY KEY)");
        }
        recording.enable("jdk.VirtualThreadPinned").withThreshold(Duration.ofMillis(20)).withStackTrace();
        recording.enable("jdk.VirtualThreadStart");
        recording.enable("jdk.VirtualThreadEnd");
        recording.enable("jdk.VirtualThreadSubmitFailed");
        recording.enable("jdk.GarbageCollection");
        recording.start();
        clock.scheduleAtFixedRate(this::sample, 0, 2, TimeUnit.MILLISECONDS);
        lifecycle.addStopHook(() -> {
            closing.set(true);
            platform.shutdown();
            virtual.shutdown();
            try {
                boolean p = platform.awaitTermination(8, TimeUnit.SECONDS);
                boolean v = virtual.awaitTermination(8, TimeUnit.SECONDS);
                if (!p || !v) throw new IllegalStateException("workers failed to drain");
                clock.shutdown();
                boolean t = clock.awaitTermination(2, TimeUnit.SECONDS);
                pool.close();
                Files.writeString(output.resolve("cleanup.json"), Json.stringify(Json.toJson(Map.of(
                    "platformTerminated", p, "virtualTerminated", v, "clockTerminated", t,
                    "poolClosed", pool.isClosed(), "recordingClosed", recordingClosed.get(), "permits", admission.availablePermits(),
                    "running", running.get(), "finished", finished.get()))));
                return CompletableFuture.completedFuture(null);
            } catch (Exception e) {
                return CompletableFuture.failedFuture(e);
            } finally {
                clock.shutdownNow();
                pool.close();
            }
        });
    }

    public synchronized Result finishRecording() throws Exception {
        if (!recordingClosed.get()) {
            recording.stop();
            recording.dump(output.resolve("runtime.jfr"));
            recording.close();
            recordingClosed.set(true);
        }
        return ok("recording archived and closed");
    }

    private void sample() {
        peakRunning.accumulateAndGet(running.get(), Math::max);
        peakPoolActive.accumulateAndGet(pool.getHikariPoolMXBean().getActiveConnections(), Math::max);
        peakPoolWait.accumulateAndGet(pool.getHikariPoolMXBean().getThreadsAwaitingConnection(), Math::max);
    }

    public Result stats() {
        ObjectNode n = Json.newObject();
        n.put("pid", ProcessHandle.current().pid());
        n.put("schema", schema);
        n.put("running", running.get());
        n.put("peakRunning", peakRunning.get());
        n.put("platformQueued", platform.getQueue().size());
        n.put("permits", admission.availablePermits());
        n.put("poolActive", pool.getHikariPoolMXBean().getActiveConnections());
        n.put("poolWait", pool.getHikariPoolMXBean().getThreadsAwaitingConnection());
        n.put("peakPoolActive", peakPoolActive.get());
        n.put("peakPoolWait", peakPoolWait.get());
        n.put("rejected", rejected.get());
        n.put("finished", finished.get());
        var bean = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
        n.put("totalAllocatedBytes", bean.getTotalThreadAllocatedBytes());
        n.put("heapUsed", ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed());
        n.put("gcCount", ManagementFactory.getGarbageCollectorMXBeans().stream()
            .mapToLong(g -> Math.max(0, g.getCollectionCount())).sum());
        n.put("gcMillis", ManagementFactory.getGarbageCollectorMXBeans().stream()
            .mapToLong(g -> Math.max(0, g.getCollectionTime())).sum());
        return ok(n);
    }

    public CompletionStage<Result> work(String mode, String id, int millis, int budget) {
        if ((!mode.equals("platform") && !mode.equals("virtual")) || !id.matches("[a-zA-Z0-9_-]{1,80}")
            || millis < 30 || millis > 100 || budget < 0 || budget > 1000) {
            return CompletableFuture.completedFuture(badRequest("invalid bounded input"));
        }
        if (closing.get() || !admission.tryAcquire()) {
            rejected.incrementAndGet();
            return CompletableFuture.completedFuture(status(503, "admission full"));
        }
        CompletableFuture<Result> response = new CompletableFuture<>();
        long submitted = System.nanoTime();
        try {
            (mode.equals("platform") ? platform : virtual).execute(() -> {
                try { response.complete(ok(query(id, millis, submitted))); }
                catch (Exception e) { response.complete(internalServerError(e.getClass().getSimpleName())); }
                finally { admission.release(); }
            });
        } catch (RejectedExecutionException e) {
            admission.release();
            rejected.incrementAndGet();
            response.complete(status(503, "executor full"));
        }
        if (budget > 0) {
            ScheduledFuture<?> timer = clock.schedule(() -> response.complete(status(504, "response budget")),
                budget, TimeUnit.MILLISECONDS);
            response.whenComplete((r, e) -> timer.cancel(false));
        }
        return response;
    }

    private ObjectNode query(String id, int millis, long submitted) throws Exception {
        long start = System.nanoTime();
        running.incrementAndGet();
        sample();
        try (Connection c = pool.getConnection()) {
            long acquired = System.nanoTime();
            c.setAutoCommit(false);
            try (var sleep = c.prepareStatement("SELECT pg_sleep(?)");
                 var write = c.prepareStatement("INSERT INTO " + schema + ".writes(id) VALUES (?)")) {
                sleep.setDouble(1, millis / 1000.0);
                sleep.execute();
                write.setString(1, id);
                write.executeUpdate();
                c.commit();
            } catch (Exception e) { c.rollback(); throw e; }
            finished.incrementAndGet();
            ObjectNode n = Json.newObject();
            n.put("id", id);
            n.put("virtual", Thread.currentThread().isVirtual());
            n.put("thread", Thread.currentThread().getName());
            n.put("queueMillis", (start - submitted) / 1_000_000.0);
            n.put("poolWaitMillis", (acquired - start) / 1_000_000.0);
            n.put("committed", true);
            return n;
        } finally { running.decrementAndGet(); }
    }

    public CompletionStage<Result> burst() {
        List<CompletableFuture<ObjectNode>> tasks = new ArrayList<>();
        String prefix = "burst_" + System.nanoTime() + "_";
        for (int i = 0; i < 48; i++) {
            String id = prefix + i;
            tasks.add(CompletableFuture.supplyAsync(() -> {
                try { return query(id, 50, System.nanoTime()); }
                catch (Exception e) { throw new CompletionException(e); }
            }, virtual));
        }
        return CompletableFuture.allOf(tasks.toArray(CompletableFuture[]::new))
            .thenApply(ignored -> ok(Json.toJson(tasks.stream().map(CompletableFuture::join).toList())));
    }

    public CompletionStage<Result> pin(String kind) {
        if (!kind.equals("monitor") && !kind.equals("lock"))
            return CompletableFuture.completedFuture(badRequest("monitor or lock"));
        return CompletableFuture.supplyAsync(() -> {
            try {
                for (int i = 0; i < 6; i++) {
                    if (kind.equals("monitor")) monitorSleep(); else lockSleep();
                }
                return ok(Json.toJson(Map.of("kind", kind, "virtual", Thread.currentThread().isVirtual())));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return internalServerError("interrupted");
            }
        }, virtual);
    }

    public static void monitorSleep() throws InterruptedException {
        synchronized (PIN_MONITOR) { Thread.sleep(60); }
    }

    public static void lockSleep() throws InterruptedException {
        ReentrantLock lock = new ReentrantLock();
        lock.lock();
        try { Thread.sleep(60); } finally { lock.unlock(); }
    }
}
