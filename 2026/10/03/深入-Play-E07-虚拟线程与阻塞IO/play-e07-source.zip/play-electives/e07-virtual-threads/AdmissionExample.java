import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public final class AdmissionExample implements AutoCloseable {
    private final Semaphore permits = new Semaphore(4);
    private final ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();

    public CompletableFuture<String> submit() {
        if (!permits.tryAcquire()) {
            return CompletableFuture.failedFuture(new RejectedExecutionException("full"));
        }
        CompletableFuture<String> response = new CompletableFuture<>();
        try {
            executor.execute(() -> {
                try {
                    Thread.sleep(100);
                    response.complete("business finished");
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    response.completeExceptionally(e);
                } finally {
                    permits.release();
                }
            });
        } catch (RejectedExecutionException e) {
            permits.release();
            response.completeExceptionally(e);
        }
        return response;
    }

    @Override
    public void close() {
        executor.close();
    }

    public static void main(String[] args) throws Exception {
        try (AdmissionExample service = new AdmissionExample()) {
            CompletableFuture<String> response = service.submit();
            String value = response.completeOnTimeout("response timeout", 10, TimeUnit.MILLISECONDS).get();
            System.out.println(value);
        }
        System.out.println("executor drained");
    }
}
