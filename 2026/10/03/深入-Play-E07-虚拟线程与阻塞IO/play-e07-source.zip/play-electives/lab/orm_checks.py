import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import urllib.request

kind = sys.argv[1]
assert kind in ("ebean", "hibernate")
base = Path(__file__).resolve().parents[1] / ("e03-" + kind)
evidence = Path(sys.argv[2]).resolve()
evidence.mkdir(parents=True, exist_ok=True)
with socket.socket() as listener:
    listener.bind(("127.0.0.1", 0))
    port = listener.getsockname()[1]
env = os.environ.copy()
assert Path(env["JAVA_HOME"], "bin/java").is_file()
command = ["bash", str(base / "target/universal/stage/bin" / ("e03-" + kind)),
           "-Dhttp.address=127.0.0.1", "-Dhttp.port=" + str(port), "-Dpidfile.path=/dev/null"]
if env.get("E03_JDBC_URL"):
    command.append("-Ddb.default.url=" + env["E03_JDBC_URL"])
out = {"command": command, "port": port, "requests": []}
with (evidence / "http-server.log").open("w") as log:
    process = subprocess.Popen(command, cwd=base, env=env, stdout=log, stderr=subprocess.STDOUT,
                               start_new_session=True)
    try:
        deadline = time.monotonic() + 40
        while True:
            if process.poll() is not None:
                raise RuntimeError("server exited during startup: " + str(process.returncode))
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=0.3):
                    break
            except OSError:
                if time.monotonic() > deadline:
                    raise TimeoutError("server startup")
                time.sleep(0.1)
        for i in range(2):
            with urllib.request.urlopen("http://127.0.0.1:" + str(port) + "/orm", timeout=20) as response:
                data = json.load(response)
                assert response.status == 200
            assert data["committedRows"] == 1 and data["rolledBackRows"] == 0
            assert data["earlyRowsBeforeRelease"] == 1 and not data["stageDoneAfterActionReturns"]
            assert data["lateStageOutcome"] == "failed" and data["earlyRowsAfterStageFailure"] == 1
            assert data["lateRowsAfterStageFailure"] == (1 if kind == "ebean" else 0)
            assert data["correctRowsBeforeRelease"] == 0 and data["correctRowsAfterCompletion"] == 1
            assert data["workerTerminated"] and data["entityEnhanced"] == (kind == "ebean")
            out["requests"].append({"status": 200, "body": data})
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
        try:
            out["exitCode"] = process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=5)
            out["forcedKill"] = True
        out["processTerminated"] = process.poll() is not None
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.3):
                out["listenerClosed"] = False
        except OSError:
            out["listenerClosed"] = True
        (evidence / "http-observations.json").write_text(json.dumps(out, indent=2) + "\n")
assert out["processTerminated"] and out["listenerClosed"] and not out.get("forcedKill", False)
print(json.dumps({"result": "PASS", "kind": kind, "requests": len(out["requests"]),
                  "processTerminated": True, "listenerClosed": True}))
