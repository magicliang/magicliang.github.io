#!/usr/bin/env python3
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BLOG = ROOT.parents[1]
EXCLUDED = {"target", ".tools", ".bsp", ".metals", ".settings", "__pycache__", ".git"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--directory", action="append", required=True)
    parser.add_argument("--evidence", required=True)
    parser.add_argument("--post", required=True)
    arguments = parser.parse_args()
    posts = list((BLOG / "source/_posts").glob("*Play-" + arguments.post + "-*.md"))
    assert len(posts) == 1, posts
    assets = posts[0].with_suffix("")
    assets.mkdir(parents=True, exist_ok=True)
    archive = assets / ("play-" + arguments.post.lower() + "-source.zip")
    roots = [ROOT / name for name in arguments.directory]
    roots += [ROOT / "lab", ROOT / "evidence" / arguments.evidence]
    files = sorted({path for root in roots for path in root.rglob("*")
                    if path.is_file() and not EXCLUDED.intersection(path.relative_to(ROOT).parts)
                    and path.name not in {"RUNNING_PID", ".classpath", ".project"}
                    and path.suffix != ".class"})
    assert files
    hashes = {}
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as output:
        for path in files:
            name = "play-electives/" + path.relative_to(ROOT).as_posix()
            content = path.read_bytes()
            entry = zipfile.ZipInfo(name, date_time=(2026, 10, 3, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o644 << 16
            output.writestr(entry, content)
            hashes[name] = hashlib.sha256(content).hexdigest()
    with zipfile.ZipFile(archive) as package:
        assert package.testzip() is None
        for name, digest in hashes.items():
            assert hashlib.sha256(package.read(name)).hexdigest() == digest
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    (assets / "SHA256SUMS").write_text(digest + "  " + archive.name + "\n")
    print(json.dumps({"result": "PASS", "files": len(files), "archive": str(archive), "sha256": digest}))


if __name__ == "__main__":
    main()
