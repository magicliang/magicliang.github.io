# 39 原始证据

JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn；JDK21 strict --release21 -Xlint:all -Werror；独立入口 bash examples/software-modeling/labs/39/run.sh。

|场景|调用|二元观察|工件|
|---|---|---|---|
|完整实验|run.sh|27断言，exit0|run.txt / run.exit|
|明确拒绝反例|run.sh unsupported|异常拒绝，exit1|negative.txt / negative.exit|
|独立目录|/private/tmp下绝对路径run.sh|全部场景，exit0|standalone.txt / standalone.exit|
|冻结基线|临时copy中bash labs/27/run.sh|00基线48与27应用36，exit0|baseline-copy.txt / baseline-copy.exit|

baseline-copy是37–39共同依赖的一次真实临时复制回归，此处保存同次原始输出，并未声称执行三次。原章节evidence不变。具体语义边界见models/39/contracts.md。

static-checks.json验证稿件相等、两图、现有链接及退出码；source-hashes.sha256包含源码、模型、正文和所有实际编译依赖。无ZIP/Hexo/browser验收或提交。
