# 13 验证索引

公开入口：`bash examples/software-modeling/labs/13/run.sh`。原始stdout/stderr：`output.txt`，退出码：`exit-code.txt`（0）。记录环境以output首行为准。

| 场景/成功标准 | 二元可观察结果 | 原始证据 |
|---|---|---|
| 事实登记与入账分开，6组事务分别平衡 | fee_fact_does_not_post、six_balanced_journals、every_journal_two_legs_zero PASS | output.txt |
| 冲正保留原记录、折扣与退款中间/最终余额 | reversal_preserves_original、discount_is_not_cash_refund、final_balances_minor PASS | output.txt |
| 不平衡/跨币种/单条/错误金额/重复/覆盖被拒绝且无副作用 | 指定REJECT与rejections_preserve_entries PASS | output.txt |
| 超出精度、长尾小数、极小数、NaN不得变成合法金额 | 四项金额REJECT | output.txt |
| 写一条后异常，DB回滚整组；绕过应用仍可提交不平衡组 | mid_write_failure REJECT、database_rollback_* PASS、db_commit_can_be_unbalanced=10000 | output.txt |

语法、模型图与正文一致、前章链接存在、正文摘录来自输出、稿件哈希一致检查见`static-checks.txt`。同入口从临时目录执行见`standalone-output.txt`/`standalone-exit-code.txt`。主动把不平衡调用交给未捕获CLI执行，见`negative-unbalanced.txt`/`negative-unbalanced-exit-code.txt`（非零）。

扫描的draft SHA与实际文章一致，见`source-hashes.sha256`。正文来源版本核对见`SOURCES.md`。LSP basedpyright未安装且用户已拒绝安装；使用实际Python运行与AST解析，不声称LSP已过。

本切片未执行Hexo构建、浏览器验图或zip重打包，交由root集成；未修改共享core/runner/README，未提交。
