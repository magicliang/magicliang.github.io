# 32 证据

最终运行使用PYTHON_BINARY=/opt/homebrew/opt/python@3.14/bin/python3.14，从/private/tmp调用公开run.sh绝对路径。

| 场景 | 入口/操作 | 可观察结果 | 工件 |
|---|---|---|---|
| 分层、业务及数据约束 | labs/32/run.sh | 38项PASS、exit0 | run.txt、run.exit |
| 错误业务策略实际执行 | step连续执行retire、approveInspection | INSPECTION_REQUIRED→RETIRED→ACTIVE | run.txt OBSERVED |
| 结构/FSM通过但设备合同失败 | run.sh models/32/wrong-policy.json | 前两层PASS、设备FAIL、exit1 | negative.txt、negative.exit、audit-wrong-policy.json |
| UTC租期/引用/重叠 | validate_reservations实际数据 | 相邻通过，反向/零长度/未知引用/重叠/错误类型拒绝 | run.txt PASS/REJECTED |
| 累计30 | 临时副本的原run.sh | 23项pass=true、exit0 | chapter30-regression.txt、chapter30-regression.exit |

实际机制是Python；无OCL引擎，无数据库和并发保障。ZIP、Hexo构建、浏览器仍由根代理验收。
