# Chapter 07 verification

Command: `bash examples/software-modeling/labs/07/run.sh` with JAVA_HOME selecting Amazon Corretto 21.0.11. Exact invocation in command.txt, runtime in environment.txt. Scenario checks use explicit AssertionError / expected-exception checks, not disabled JVM assertions.

| Criterion | Scenario / binary marker | Observable | Artifact |
|---|---|---|---|
| Half-open rental intervals using shared core | `adjacent_half_open; one_nanosecond_overlap; zero_length; reverse_interval` | Adjacency false, nanosecond overlap true; invalid periods reject | `output.txt`, `exit-code.txt` |
| Calendar/instant/zone boundary | `calendar_day_is_23_hours; plus_24_hours_misses_midnight; date_needs_zone` | Calendar difference 1; elapsed hours 23; tzdb 2026a recorded | `output.txt`, `exit-code.txt` |
| Currency and rounding | `money_normalizes_scale; same_currency_sum; cross_currency; implicit_rounding; explicit_rounding; bigdecimal_equality_boundary` | Mixed currencies rejected; scale canonicalized; HALF_UP=10.01, HALF_EVEN=10.00 asserted | `output.txt`, `exit-code.txt` |
| Quantity units | `same_unit_sum; mixed_units` | Same units sum; hour+piece rejected | `output.txt`, `exit-code.txt` |
| Identity and historical revisions | `same_identity_different_revision; same_label_different_identity; history_keeps_old_label` | Same ID and changed revision differ; equal labels with distinct IDs differ; old label retained | `output.txt`, `exit-code.txt` |
| Standalone download | Extract chapter-07.zip into empty temporary directory; run same command from extraction root | Exit 0 and all PASS markers | archive-output.txt, archive-exit-code.txt |

Source/model mapping: models/07/semantics.md; sources.md. Reader archive contains repository-relative paths and no dependency on checkout. source-sha256.txt identifies delivered input files and archive.

Limits: local synchronous teaching tests only. No production, database persistence, concurrent execution or service integration verified. The leader owns combined Hexo generation, navigation and real browser checks; those are not claimed by this per-chapter lab evidence.
