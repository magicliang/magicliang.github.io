# 25 执行证据

环境：Amazon Corretto JDK21.0.11，JAVA_HOME=/Users/magicliang/.sdkman/candidates/java/21.0.11-amzn。公开 run.sh 从 /private/tmp 调用绝对脚本路径，验证脚本不依赖调用工作目录；读者使用 models/25/README.md 中仓库相对命令。

| 场景 | 调用 | 二值可观察结果 | 原始工件 |
|---|---|---|---|
| 编译与旧基线 | run.sh | 严格编译成功、48项PASS | run.txt、run.exit=0 |
| 双线程先查后写 | run.sh | 两次conflict=false、两次CONFIRMED、active=2 | run.txt中TRACE broken/OBSERVED broken |
| 同一日历临界区 | run.sh | 一次CONFIRMED一次OVERLAP_REJECTED、active=1 | run.txt中TRACE guarded/OBSERVED guarded |
| 回执/取消/快照/跨边界限制 | run.sh | 本章26项PASS（含上述并发断言） | run.txt |
| 要求错误候选安全 | run.sh require-broken-safe | AssertionError: at most one confirmation，退出1 | negative.txt、negative.exit |

source-hashes.sha256记录实际源码/依赖/稿件；static-checks.txt记录链接与图数等静态检查。

未执行：数据库事务/跨进程并发/吞吐公平性、ZIP解包、Hexo构建、浏览器渲染；后三项由根代理集成验收。
