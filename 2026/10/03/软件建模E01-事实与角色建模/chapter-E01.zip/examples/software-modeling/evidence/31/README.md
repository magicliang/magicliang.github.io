# 31 证据

最终运行解释器：`/opt/homebrew/opt/python@3.14/bin/python3.14`（Python3.14.4）。通过PYTHON_BINARY设置，从/private/tmp调用绝对run.sh路径。

| 场景 | 入口/操作 | 可观察结果 | 工件 |
|---|---|---|---|
| 真实转换及执行 | labs/31/run.sh | 26项PASS、exit0 | run.txt、run.exit |
| CIM→PIM→PSM→代码 | transform读取requirements.json | 生成5文件，PIM等于30设备样本；执行4步轨迹与9对输入 | generated/、run.txt |
| 映射与损失 | 变更授权文字后再转换 | PIM不变，账本改变；最终9项损失含平台信息 | generated/mapping.json、loss-ledger.json、run.txt |
| 未知动作 | run.sh unsupported-term | MappingError指出$.rules[0].action、exit1 | negative.txt、negative.exit |
| 累计30 | 临时复制labs/30与models/30后原run.sh | 23个JSON场景pass=true、exit0 | chapter30-regression.txt、chapter30-regression.exit |

persona记录保留first_landing_sha256及最终稿SHA。图源/稿/正文一致与链接检查见static-checks.txt；source-hashes.sha256覆盖实际源码和依赖。

终端cwd改变会选到系统Python3.9.6；入口现先检查>=3.10并支持PYTHON_BINARY，最终证据固定解释器。不安装额外依赖。未验收ZIP解包/Hexo/browser；无自然语言推理、MOF符合性、持久化、并发或反向转换保证。
