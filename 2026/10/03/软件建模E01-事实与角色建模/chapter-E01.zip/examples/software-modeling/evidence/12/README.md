# Chapter 12 evidence

Primary invocation: `bash examples/software-modeling/labs/12/run.sh`. Python 3.14.4, standard library only; no environment-specific absolute paths are in reader commands. The model JSON is read relative to the script, not the caller's working directory. command.txt and environment.txt capture invocation/runtime. checks use explicit AssertionError and expected exceptions.

| Criterion | Exact scenario | Binary observable | Captured artifact |
|---|---|---|---|
| Two-dimensional historical queries | `as-known-before-correction`; `first-retroactive-correction`; `second-retroactive-correction`; `old-perspective-survives-new-records` | Fixed valid date returns 10000, 8000, 9000 at different record cutoffs; earlier perspective retained. | `output.txt`, `exit-code.txt` |
| Valid-axis half-open boundaries | `before-valid-boundary`; `at-valid-boundary`; `valid-domain-end-is-excluded`; `valid-domain-start-is-included`; `outside-valid-domain-is-unknown` | Boundary changes 10000 to 9000; end/outside return None; start included. | `output.txt`, `exit-code.txt` |
| Record-axis boundary and unknown knowledge | `before-record-boundary`; `at-record-boundary`; `before-first-record-is-unknown` | One microsecond before correction=10000; exact correction=8000; before initial record=None. | `output.txt`, `exit-code.txt` |
| Invalid temporal models | `empty-valid-interval`; `reverse-valid-interval`; `overlapping-valid-segments`; `gap-in-valid-segments`; `duplicate-record-time`; `backdated-record-insertion`; `naive-record-query` | Each malformed model/query rejects with ValueError. | `output.txt`, `exit-code.txt` |
| No accidental overwrite and simpler alternative | `overwrite-old-snapshot`; `failed-writes-leave-history-intact`; `latest-only-cannot-reproduce-old-price` | Frozen snapshot rejects normal assignment; failed append leaves 3 snapshots; latest-only dictionary differs from old query. | `output.txt`, `exit-code.txt` |
| Independent execution | Copy only labs/12 and models/12 under examples/software-modeling/ in a fresh temporary directory; run same invocation at extraction root | Exit 0 and 22 passing scenario records | isolated-output.txt, isolated-exit-code.txt |

Primary references and verified sections: sources.md. Executable fixture and documented assumption boundary: models/12/. Source hashes: source-sha256.txt. Artifact existence, counts and whitespace validation: artifact-check.json.

ZIP creation, final extraction tests, complete Hexo generation and browser checks are owned by the parent agent. The isolated-copy check is not represented as a ZIP/browser test.

Limits: local synchronous semantic experiments only; no persistent store, concurrency, global identity uniqueness, production integration or tamper-resistant audit guarantee. Detailed per-model omissions are in models/12/semantics.md.
