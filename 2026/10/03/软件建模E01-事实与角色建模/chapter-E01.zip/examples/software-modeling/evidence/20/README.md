# 20 验证索引

实际命令：`bash examples/software-modeling/labs/20/run.sh`。输出`output.txt`，退出码`exit-code.txt`（0）；18项检查。

| 成功标准 | 实际二元可观察结果 | 原始证据 |
|---|---|---|
| 合成命令真正执行形成时间线 | 7输入命令+1政策命令，6条EVENT，timeline断言通过 | output.txt |
| 政策条件与结果分开 | 有收款取消开启核查；unpaid_cancel_no_review仅确认/取消；无退款完成 | output.txt |
| 回放与取消语义保持 | 仅F活跃、A未复活、B仍拒绝、回放不新增事件 | output.txt |
| 错误时间线/政策/热点被拒绝 | 删除核查、倒序、伪退款、错误原因、空问题、事件充当命令、变载荷、缺UTC的REJECT | output.txt |
| 问题保持未决 | 两条HOTSPOT仍OPEN；跨目录exit0，未捕获缺政策结果exit1 | output.txt、standalone-*、negative-* |

静态核对在`static-checks.txt`，实际调用在`commands.txt`，源哈希在`source-hashes.sha256`。资料核对与未获取样章的边界见`SOURCES.md`。校验器只检查声明子集及局部一致性，不证明完整业务发现或整个真实流程正确。

稿件与文章SHA相同，两图及输出摘录一致。无虚构访谈/参与者/生产案例。

root负责ZIP、共享入口、Hexo、浏览器与提交，本切片不宣称这些集成项完成。
