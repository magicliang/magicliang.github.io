# 34：受限演化合同

Python >= 3.10 标准库。labs/34/evolution.py依赖30toolkit；check.py另依赖33build/custom_policy及其30–32依赖。不是通用round-trip工具或数据库迁移工具。

`overwrite_if_unchanged(path, new_source, expected_digest)` 比较现有文本SHA256，漂移抛GENERATED_ARTIFACT_MODIFIED且不写；无锁、无原子替换。

`reverse_table(source, original)` 仅用AST提取顶层字面量INITIAL/TRANSITIONS，补入original声明后调用30parse_model。拒绝重复/缺失表；不执行源码，也不理解函数体。手改函数的禁退役规则会丢失，此损失由真实运行两条路径证明。不得声称任意Python无损回到模型。

`merge_cell(base, model_side, code_side)` 只比较单个迁移目标：双方均变且不同抛ROUND_TRIP_CONFLICT，否则选变化值。无整体一致性检查；示例双边候选通用FSM合法但不代表24领域合同修改获准。

`restore(snapshot, model, revision)` 检查exact keys equipment_id/model_revision/state、revision严格int且匹配、state属于model；返回副本。设备编号来自可信教学输入，不是外部数据完整验证器。

`migrate_v1_to_v2(snapshot,target)` 只接受修订1，将ACTIVE映射READY，其余已知状态保持；保持设备编号并设置修订2；未知修订/状态拒绝。DSL格式version仍1，领域修订是独立概念。revision2模型不满足冻结24合同，33严格构建拒绝；后续只为明确教学改版调用30通用生成器。无事务、在线兼容或迁移日志。

run.sh实际20场景：覆盖前后行为、哈希保护、表格反读损失、双边目标真实执行与精确冲突码、单边合并、独立政策保持、严格合同拒绝新模型、旧快照/状态拒绝、显式迁移/保ID/运行、默认重置丢失审批、未知状态与修订、原输入不变。输入revision2.json与snapshot-v1.json；证据在evidence/34。

最小运行依赖：本章labs/models；labs/33/build.py、custom_policy.py；labs/30/toolkit.py、labs/31/pipeline.py、labs/32/constraints.py；models/30/equipment.json。若包中同时提供33回归，应包含完整33labs/models及其unknown-target负例。依赖回归在临时复制树运行。
