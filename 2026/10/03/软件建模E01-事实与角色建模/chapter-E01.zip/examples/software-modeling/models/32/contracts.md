# 32：分层校验API（供33/34使用）

实现 labs/32/constraints.py，Python>=3.10标准库；依赖冻结30 toolkit。将labs/32加入sys.path后导入。

- `validate_structure(text:str) -> None`：完整扫描JSON语法/重复键/常量、字段集合、版本、标识符格式、数组/边形状，失败抛toolkit.ModelError。故意不检查唯一名字、引用、确定性、可达性、终态出边；这些交给30 parse_model。重复结构规则是为完整分阶段诊断；30 v1格式变更后必须同步并回归，非第二套通用解析器。
- `audit_model(text:str) -> dict`：依次validate_structure→30 parse_model→30 validate_equipment_contract。结果固定键syntax_structure/generic_fsm/equipment_contract各为PASS/FAIL/NOT_RUN，failure为None或{code,path}。首个失败之后不运行后续阶段；不自动修复模型。
- 命令行 `python3 examples/software-modeling/labs/32/constraints.py <model.json>` 打印JSON；通过exit0，模型拒绝exit1；读文件错误正常传播。
- models/32/wrong-policy.json是专门新增的反例：去掉terminal标记并添加RETIRED/approveInspection→ACTIVE。JSON/结构和通用FSM合法，实际运行先退役再审批得到ACTIVE，设备合同拒绝。不同于30/wrong-policy.json的审批/退役目标交换；两者均受测试。

## 独立预留数据约束

`validate_reservations(rows:list[dict], equipment_ids:set[str]) -> None`。这是当前数据集上的纯Python约束检查，不是修改后的FSM元模型，不是调用Java核心，也不是OCL解释器。

每行精确含request_id、equipment_id、start、end、active。身份为非空白字符串；active严格bool。时间只支持UTC整秒格式YYYY-MM-DDTHH:MM:SSZ，真实日历日期、start<end、半开区间；这比Java Instant输入范围更窄，不接受小数秒/本地时间。所有记录请求ID唯一、设备引用存在；同设备active区间不得重叠，inactive不占用；不同设备允许同时间。

失败抛ReservationError(ValueError)，有code/path：SHAPE、DUPLICATE_REQUEST、UNKNOWN_EQUIPMENT、UTC_SECONDS_REQUIRED、INVALID_TIME、INVALID_PERIOD、OVERLAP。只报首错、不改输入；不会验证设备在役/维修、请求回执合法历史、跨调用并发、授权与时间区间以外的政策。未知设备即使inactive也拒绝，因为引用完整性与当前占用是不同约束。

`labs/32/run.sh`无参数运行完整检查；带路径运行单模型audit（相对路径按调用cwd）。入口先检查Python>=3.10；可用PYTHON_BINARY=/path/to/python3指定解释器，默认python3。普通包需要完整models/30（含invalid-cases/invalid）、labs/30/toolkit.py和本章目录。独立累计30回归在临时副本执行原30入口，不修改冻结依赖。OCL只在正文说明约束用途，没有运行任何OCL引擎。
