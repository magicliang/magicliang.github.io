# 32：分层校验

API见contracts.md。wrong-policy.json是删除终态声明并允许退役后恢复的教学反例；不是30目录中交换审批/退役目标的旧样本。reservations.json为UTC整秒半开区间的合成输入。

运行：`examples/software-modeling/labs/32/run.sh`。需要Python>=3.10；可设置PYTHON_BINARY指定解释器。

负例：`examples/software-modeling/labs/32/run.sh examples/software-modeling/models/32/wrong-policy.json`，预期JSON/结构PASS、FSM PASS、设备合同FAIL且exit1。

包保留examples/software-modeling前缀，包含labs/30/toolkit.py、完整models/30（错误样本回归依赖）、本章labs/models/evidence。若复跑30原入口，需要完整labs/30。OCL没有运行；实际机制是Python结构、集合、可达性及区间检查。
