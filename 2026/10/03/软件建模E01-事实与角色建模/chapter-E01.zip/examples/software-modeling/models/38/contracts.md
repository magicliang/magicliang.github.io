# 38 架构候选与运行范围

Java21标准库；ArchitectureCheck内部UseCase接口有Script、Domain、Module三实际候选。Script集中维护active/receipts/totals并复用26时间和报价函数；Domain调用冻结27；Module包裹Domain并验证/翻译受限请求号。Module是类门面，不是JPMS模块、服务或独立部署。

比较9操作与最终View：确认、重叠、相邻、取消、晚时钟旧确认重放、旧拒绝重放、未知设备、无效租期、同ID异设备拒绝；View含active数量、完整回执和历史金额。Script固定设备初态与维修放行；未实现完整27生命周期、维修技术故障、提交/发布边界；不宣称全契约等价。

HTTP实际监听127.0.0.1临时端口，Client与Server同JVM，domain/maintenance/publisher/memory仓储同进程。POST body仅请求号，正则[a-z0-9-]{1,30}；设备E1、时间与费率固定fixture，非通用API。成功业务结果正文，格式或方法错误400；没有认证、超时/重试策略、稳定全错误协议、外部服务或可靠消息。trace使用CopyOnWriteArrayList；客户端通过真实网络栈调用。finally stop关闭监听。

10断言；run.sh默认及standalone exit0；追加invalid在HTTP完整实验后触发Module拒绝，exit1。需要本机监听许可；沙箱不允许bind时不能跳过HTTP宣称通过。

未决项：持久化回执/草案/占用的同事务、多个Repository协调、维修时效与故障、可靠消息与响应丢失、传输授权；E09/E10/企业应用架构姊妹系列继续，E11跨应用企业架构范围另列，未生成不存在的post_link。
