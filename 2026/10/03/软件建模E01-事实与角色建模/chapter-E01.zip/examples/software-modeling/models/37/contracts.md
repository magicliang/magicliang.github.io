# 37 遗留样本与增量翻译合同

合成CSV不是实际厂商协议。六字段code/ready/busy/inspection/retired/note；可信fixture只有不含逗号/换行的六列字符串，不是通用CSV或任意外部数据验证器。

旧谓词实际代码：ready=Y且busy=N。教学领域约定ready是维修侧放行；busy缺少租期与请求身份，Y时不能重建承诺而隔离；inspection只认识PASS/PENDING；retired=Y优先RETIRED，否则PASS→ACTIVE、PENDING→INSPECTION_REQUIRED；ready=N仍单独翻译成维修BLOCKED，不改变生命周期。note只原样留存。

ID映射legacy:code。migrate(State,List<Row>)按输入批返回不可变新State和隔离原因；复制equipment/imported/maintenance映射，保留原calendar/receipts/contracts。批内重复ID两行均隔离，目标碰撞拒绝；原行重复导入跳过，原行变化要求对账不覆盖。已知行允许部分进度，因此整批不是全有全无。领域导入快照与真实27用例分开执行。

仅离线可信快照、单写者设备资料迁移。没有线上分流、双写、一致性屏障、持久化、来源版本或自动补偿。27基线只读不改。真实执行两个批次和3设备新预订：旧谓词均true，新返回CONFIRMED/INELIGIBLE/INELIGIBLE，未知检验码隔离；17断言。unknown参数末尾抛IllegalArgumentException exit1。
