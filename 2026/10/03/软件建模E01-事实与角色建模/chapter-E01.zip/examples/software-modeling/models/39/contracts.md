# 39 三变化卡与27-v1外置增量

源码基线ed5a420a0189945118b8b0211f6da39e989a453d，实际rental-application及25未改。Amendments是独立教学状态层，不是27已有能力。package rental.review；API apply(Change,Instant)->String，read()->State，effectiveTotal(RequestId)->Money；构造接受可信27 Snapshot迁移或可信本层State恢复。没有外部文件导入/持久化协议。

State(version=2,baseline,changes,adjustments,successors)保留原快照，另加3集合。Change sealed Replacement/Reprice；全操作号命名空间历史包含完整命令；同号同负载历史返回、同号不同负载拒绝。技术/形状错误不消费操作号；业务预订拒绝记忆在变化层，不将失败候选写入baseline。

EXTEND：原活动请求、同设备、同开始、结束延后、同约定费率、新RequestId。SWAP：原活动请求、同租期、不同设备、同约定费率、新RequestId。在独立候选MemoryRepository取消旧请求、27 reserve新请求；成功才替换外层baseline并记录successor，失败保留整份旧baseline。单实例同步，外部事件不发布，维修固定RELEASED。仅开始前修改（受原minimumLead规则），固定同类两台设备；非跨类型替代政策。

REPRICE：保留原合同，按原租期及新同币种费率算目标金额，delta=目标-当前有效总额，追加带目标/费率/原因的Adjustment；有效总額=原合同+全部delta。不是复式会计、支付、退款或通用事件溯源；不含发生/记录双时间。跨币种拒绝；调价后再替换明确拒绝等待规则，不随意选择新报价基数。

卡及观察：
- 延期10–11到12:10冲突，整个v1保留；到12:00相邻成功，新2h草案25.00，旧12.50保留。
- 换E1为被占用E2冲突保留；独立快照先释放E2后新实例接受。不是旧失败操作重新成功。
- 原1h12.50→20追加+7.50；20→10追加-10.00；2调整、2回执，重复不追加。

迁移成本实际观察：新3集合，v1事实改写0（按值相等，不表示Java对象没有复制）；完整v2恢复保留调整及操作历史；旧核心只读baseline会丢失新语义，不是安全降级。候选及27事务存在整份快照复制，未测性能，不声称O(1)。27断言；unsupported CLI最后触发调价后延期未决政策exit1。
