# 35 实验合同
Java21 package rental.functional；FunctionalModel.create(ReserveRequest, HourlyRate, RentalPeriodSpecification, Instant) -> sealed Creation(Created/Rejected)，复用24 Money及26 RentalContract.Snapshot的运行不变量。FunctionalModel.transition(Equipment.Snapshot,Action) -> sealed Change(Changed/Refused)；输入不变，调用者承担提交。

实际边界：Create针对相同租期、费率、规则、now确定；没有系统时钟或外部写入。Created不等于预订成功或付款；返回快照不附带25的锁/回执事务。null与报价跨字段不变量仍是运行校验。record并不保证任意成员深度不可变。

对象候选编译真实24 Equipment和26 Factory/Specification/Pricing，未改其文件。44项运行断言：6租期输入15项、9生命周期组合23项、空结果3项、显式时间2项、错误报价1项。2份独立编译负例：IncompleteSwitch遗漏Rejected；UnexpectedVariant未被permits许可。默认入口期待javac返回1；negative子命令原样返回失败码。

公共入口：JAVA_HOME指定JDK21后 bash examples/software-modeling/labs/35/run.sh。负例：追加 negative IncompleteSwitch 或 negative UnexpectedVariant。仅标准库，--release21 -Xlint:all -Werror。下载须含rental-core/RentalDesk.java、labs/24的Money/Equipment/EquipmentDescription、labs/26的PricingService/RentalPeriodSpecification/RentalContract。
