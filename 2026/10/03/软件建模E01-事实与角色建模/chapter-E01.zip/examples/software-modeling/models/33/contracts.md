# 33：生成与手写扩展合同

Python >= 3.10 标准库。实现 labs/33/build.py；依赖稳定 labs/30/toolkit.py、labs/31/pipeline.py、labs/32/constraints.py，不修改依赖。

`render(text: str, variant='baseline') -> str` 顺序调用32 audit_model、30 parse_model、31 pim_to_psm/psm_to_python；拒绝模型抛BuildError(ValueError)，内容为code/path JSON。仅三个生成逻辑变体：baseline直接使用31生成结果；diagnostic增加错误信息包装；faulty故意将禁止操作改成返回原状态，用于反例。faulty不是合格替代实现。

`write_runtime(text, output: Path, variant='baseline') -> None` 先render+compile再写文件。模型失败保留旧输出；没有原子写或多文件发布协议。命令行 `python3 examples/software-modeling/labs/33/build.py MODEL OUTPUT --variant diagnostic`，模型失败exit1；I/O失败正常传播。构建器不内置行为验收，run.sh另测合同。

`custom_policy.apply(runtime_step, state, operation, reason='') -> str` 对retire要求非空白字符串理由，再委派生成函数。是新增教学规则，无审计、身份权限或持久化。采用函数组合，非Generation Gap继承实现。

contract-cases.json独立列出3×3全部9对状态/操作；手写分支、解释器、基线生成、诊断生成比较同一合同。19场景记录包含确定性、诊断、故障模板5个拒绝语义偏差、政策3例、非法模型子进程exit1/path/原文件不变。只有该有限生命周期子集等价，无Java实体整体等价声明。

run.sh依赖models/30/equipment.json和models/30/invalid/unknown-target.json。独立打包需本章labs/models及上述30–32三个工具文件和两个输入。运行依赖章节自身回归时需完整30–32 labs/models，应复制到临时树运行，避免改写别人的evidence。
