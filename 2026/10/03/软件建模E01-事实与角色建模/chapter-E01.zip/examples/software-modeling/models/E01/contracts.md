# E01事实样本合同

Object-Role Modeling概念教学，不是Object-Relational Mapping，也没有使用NORMA或通用ORM2解释器。Python标准库，输入为可信population.json及测试内构造的变体。

三个类型的有限编号集合；requested_by、for_equipment、approved_by均为(预留,参与对象)二元事实集合。请求人和设备各要求每项预留恰好一个；请求人可对应多项预留；审批可多值可缺；confirmed必须属于已审批预留投影；同预留提交/审批人不得同一人。上述确认与自审批规则是租赁教学假设，不是ORM语言自带规则。

validate检查有限总体，不搜索所有可能世界、不处理通用文本语法和任意外部输入。rows生成ER风格记录，未实现SQL持久化；完全重复事实按集合语义去重，不是事件去重方案。额外三元领取事实投影为三个二元关系再连接，实际产生一条虚假事实，证明该具体无附加依赖样本分解有损。

run.sh执行13场景，无其他章节依赖。输出output.txt/er-rows.json/decomposition.json。无时间区间、审批有效期、并发或事务；图为教学流程图而非完整ORM2图形语法。
