#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
java_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}java
javac_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}javac
"$java_cmd" -version
"$javac_cmd" -version
build=$(mktemp -d)
trap 'rm -rf "$build"' EXIT
"$javac_cmd" --release 21 -Xlint:all -Werror -d "$build" "$root/rental-core/RentalDesk.java" "$root/labs/24/Money.java" "$root/labs/24/EquipmentDescription.java" "$root/labs/24/Equipment.java" "$root/labs/26/PricingService.java" "$root/labs/26/RentalPeriodSpecification.java" "$root/labs/26/RentalContract.java" "$root/labs/35/FunctionalModel.java" "$root/labs/35/FunctionalCheck.java"
if [[ ${1:-} == negative ]]; then
    fixture=${2:?fixture required}
    case "$fixture" in IncompleteSwitch|UnexpectedVariant) ;; *) exit 2 ;; esac
    cp "$root/models/35/$fixture.java.txt" "$build/$fixture.java"
    "$javac_cmd" --release 21 -Xlint:all -Werror -cp "$build" -d "$build" "$build/$fixture.java"
    exit 0
fi
"$java_cmd" -ea -cp "$build" rental.functional.FunctionalCheck
for fixture in IncompleteSwitch UnexpectedVariant; do
    cp "$root/models/35/$fixture.java.txt" "$build/$fixture.java"
    set +e
    "$javac_cmd" --release 21 -Xlint:all -Werror -cp "$build" -d "$build" "$build/$fixture.java"
    status=$?
    set -e
    [[ "$status" -eq 1 ]]
    printf 'PASS compile-negative=%s exit=%s\n' "$fixture" "$status"
done
