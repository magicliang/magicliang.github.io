#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
python_cmd=${PYTHON_BINARY:-python3}
"$python_cmd" --version
"$python_cmd" "$root/labs/36/compare.py" "$@"
