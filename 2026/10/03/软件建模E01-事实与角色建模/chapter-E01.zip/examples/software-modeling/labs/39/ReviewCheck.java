package rental.review;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.HashMap;
import java.util.Map;
import rental.RentalDesk.EquipmentId;
import rental.RentalDesk.RequestId;
import rental.application.ApplicationCheck;
import rental.application.RentalApplication;
import rental.application.RentalApplication.Command;
import rental.application.RentalApplication.MemoryRepository;
import rental.application.RentalApplication.Snapshot;
import rental.application.RentalApplication.Status;
import rental.domain.Equipment;
import rental.domain.Money;
import rental.domain.PricingService.HourlyRate;
import static rental.review.Amendments.*;

public final class ReviewCheck {
    private static int checks;
    private static void check(boolean value, String label) {
        if (!value) throw new AssertionError(label);
        checks++; System.out.println("PASS " + label);
    }
    private static void rejects(Runnable action, String label) {
        try { action.run(); } catch (IllegalArgumentException expected) { check(true, label); return; }
        throw new AssertionError(label);
    }
    static Snapshot seeded() {
        Snapshot first = ApplicationCheck.initial();
        Map<EquipmentId, Equipment.Snapshot> equipment = new HashMap<>(first.equipment());
        EquipmentId second = new EquipmentId("E2");
        equipment.put(second, new Equipment.Snapshot(second, first.equipment().get(ApplicationCheck.E1).description(), Equipment.State.ACTIVE));
        Snapshot two = new Snapshot(equipment, first.calendar(), first.receipts(), first.contracts());
        MemoryRepository repository = new MemoryRepository(two, ApplicationCheck.NONE);
        RentalApplication app = new RentalApplication(repository, id -> RentalApplication.Maintenance.RELEASED,
                event -> { }, ApplicationCheck.NONE, new RentalApplication.InlineAdmission(), ApplicationCheck.SPEC);
        if (app.reserve(ApplicationCheck.command("original", "E1", 7200, 10800), ApplicationCheck.NOW) != Status.CONFIRMED) throw new AssertionError();
        if (app.reserve(ApplicationCheck.command("later", "E1", 14400, 18000), ApplicationCheck.NOW) != Status.CONFIRMED) throw new AssertionError();
        if (app.reserve(ApplicationCheck.command("other", "E2", 9000, 12000), ApplicationCheck.NOW) != Status.CONFIRMED) throw new AssertionError();
        return repository.read();
    }
    public static void main(String[] args) {
        Snapshot v1 = seeded();
        RequestId original = new RequestId("original");
        Amendments extension = new Amendments(v1);
        check(extension.read().baseline().equals(v1) && extension.read().changes().isEmpty(), "v1 migration preserves baseline and creates empty overlay");
        Replacement bad = new Replacement("extend-conflict", original, Kind.EXTEND, ApplicationCheck.command("revision-bad", "E1", 7200, 15000));
        check(extension.apply(bad, ApplicationCheck.NOW).equals("OVERLAP_REJECTED"), "extension overlap refused");
        check(extension.read().baseline().equals(v1), "failed extension keeps old commitment and contract intact");
        check(extension.apply(bad, ApplicationCheck.NOW).equals("OVERLAP_REJECTED") && extension.read().changes().size() == 1, "failed change replay retained");
        Replacement good = new Replacement("extend-ok", original, Kind.EXTEND, ApplicationCheck.command("revision-1", "E1", 7200, 14400));
        check(extension.apply(good, ApplicationCheck.NOW).equals("CONFIRMED"), "extension adjacent to next rental accepted");
        check(extension.read().baseline().contracts().get(original).equals(v1.contracts().get(original)), "extension retains original quote");
        check(extension.effectiveTotal(new RequestId("revision-1")).amount().equals(new BigDecimal("25.00")), "new two-hour revision quoted");
        State once = extension.read();
        check(extension.apply(good, ApplicationCheck.NOW.plusSeconds(99999)).equals("CONFIRMED") && extension.read().equals(once), "successful change replay skips new clock and writes");
        check(extension.read().successors().get(original).equals(new RequestId("revision-1")), "old to new identity trace");
        check(extension.read().baseline().calendar().receipts().stream().noneMatch(r -> r.active() && r.request().requestId().equals(original)), "old commitment released only on successful replacement");
        rejects(() -> extension.apply(new Replacement("extend-ok", original, Kind.EXTEND,
                ApplicationCheck.command("different", "E1", 7200, 18000)), ApplicationCheck.NOW), "same operation changed payload rejected");

        Amendments swap = new Amendments(v1);
        Replacement occupied = new Replacement("swap-conflict", original, Kind.SWAP, ApplicationCheck.command("swap-r1", "E2", 7200, 10800));
        check(swap.apply(occupied, ApplicationCheck.NOW).equals("OVERLAP_REJECTED"), "occupied substitute refused");
        check(swap.read().baseline().equals(v1), "failed swap preserves original equipment");
        MemoryRepository freed = new MemoryRepository(v1, ApplicationCheck.NONE);
        RentalApplication app = new RentalApplication(freed, id -> RentalApplication.Maintenance.RELEASED, event -> { },
                ApplicationCheck.NONE, new RentalApplication.InlineAdmission(), ApplicationCheck.SPEC);
        app.cancel(new RequestId("other"));
        Amendments availableSwap = new Amendments(freed.read());
        check(availableSwap.apply(occupied, ApplicationCheck.NOW).equals("CONFIRMED"), "fresh overlay with released substitute accepts swap");
        check(availableSwap.read().baseline().contracts().get(new RequestId("swap-r1")).request().equipmentId().equals(new EquipmentId("E2")), "new contract names substitute");
        check(availableSwap.read().baseline().contracts().get(original).request().equipmentId().equals(new EquipmentId("E1")), "old contract still names original equipment");

        Amendments pricing = new Amendments(v1);
        HourlyRate rate2 = new HourlyRate("rate-v2", new Money(new BigDecimal("20.00"), Currency.getInstance("CNY")));
        Reprice reprice = new Reprice("reprice-1", original, rate2, "teaching correction");
        check(pricing.apply(reprice, ApplicationCheck.NOW).equals("ADJUSTED:7.50"), "retroactive price stored as delta");
        check(pricing.read().baseline().equals(v1), "price adjustment does not overwrite v1 records");
        check(pricing.effectiveTotal(original).amount().equals(new BigDecimal("20.00")), "effective total includes adjustment");
        check(pricing.apply(reprice, ApplicationCheck.NOW).equals("ADJUSTED:7.50") && pricing.read().adjustments().size() == 1, "price replay appends no duplicate");
        HourlyRate rate3 = new HourlyRate("rate-v3", new Money(new BigDecimal("10.00"), Currency.getInstance("CNY")));
        check(pricing.apply(new Reprice("reprice-2", original, rate3, "second correction"), ApplicationCheck.NOW).equals("ADJUSTED:-10.00"), "second adjustment measured from effective total");
        check(pricing.read().adjustments().size() == 2 && pricing.effectiveTotal(original).amount().equals(new BigDecimal("10.00")), "signed adjustments retain prior records");
        rejects(() -> pricing.apply(new Reprice("usd", original, new HourlyRate("usd", new Money(BigDecimal.ONE, Currency.getInstance("USD"))),
                "currency switch"), ApplicationCheck.NOW), "cross currency reprice rejected");
        rejects(() -> pricing.apply(good, ApplicationCheck.NOW), "replacement after reprice explicit policy gap");
        check(new MemoryRepository(pricing.read().baseline(), ApplicationCheck.NONE).read().equals(v1), "old core reads baseline but cannot retain overlay semantics");
        Amendments restored = new Amendments(pricing.read());
        check(restored.read().equals(pricing.read()) && restored.effectiveTotal(original).equals(pricing.effectiveTotal(original)),
                "trusted v2 snapshot preserves adjustment history on restore");
        check(restored.apply(reprice, ApplicationCheck.NOW).equals("ADJUSTED:7.50") && restored.read().adjustments().size() == 2,
                "restored overlay still recognizes original correction replay");
        System.out.println("COST version=2 rewritten-v1-facts=0 new-change-receipts=" + pricing.read().changes().size()
                + " adjustment-rows=" + pricing.read().adjustments().size() + " original-total=" + v1.contracts().get(original).total()
                + " effective-total=" + pricing.effectiveTotal(original));
        if (args.length > 0) pricing.apply(good, ApplicationCheck.NOW);
        System.out.println("RESULT chapter39 checks=" + checks);
    }
}
