package rental.functional;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.Currency;
import java.util.List;
import rental.RentalDesk.EquipmentId;
import rental.RentalDesk.Period;
import rental.RentalDesk.RequestId;
import rental.RentalDesk.ReserveRequest;
import rental.domain.Equipment;
import rental.domain.EquipmentDescription;
import rental.domain.Money;
import rental.domain.PricingService;
import rental.domain.PricingService.HourlyRate;
import rental.domain.RentalContract;
import rental.domain.RentalPeriodSpecification;
import static rental.functional.FunctionalModel.*;

public final class FunctionalCheck {
    private static int checks;
    private static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
        System.out.println("PASS " + label);
    }
    private static void rejects(Runnable action, Class<? extends RuntimeException> type, String label) {
        try { action.run(); } catch (RuntimeException error) {
            check(type.isInstance(error), label); return;
        }
        throw new AssertionError(label);
    }
    public static void main(String[] args) {
        Instant now = Instant.parse("2026-10-03T00:00:00Z");
        RentalPeriodSpecification policy = new RentalPeriodSpecification(Duration.ofHours(1), Duration.ofHours(48));
        RentalContract.Factory factory = new RentalContract.Factory(policy, new PricingService());
        HourlyRate rate = new HourlyRate("rate-v1", new Money(new BigDecimal("12.50"), Currency.getInstance("CNY")));
        long[][] cases = {{3600,3600},{3600,3601},{3600,172800},{3600,172801},{3599,3600},{3599,172801}};
        for (int i = 0; i < cases.length; i++) {
            Period period = new Period(now.plusSeconds(cases[i][0]), now.plusSeconds(cases[i][0] + cases[i][1]));
            ReserveRequest request = new ReserveRequest(new RequestId("r" + i), new EquipmentId("camera"), period);
            Creation functional = create(request, rate, policy, now);
            if (functional instanceof Created created) {
                check(created.draft().equals(factory.create(request, rate, now).snapshot()), "object/function same draft case=" + i);
            } else {
                Rejected rejected = (Rejected) functional;
                check(rejected.reason().name().equals(policy.evaluate(period, now).name()), "same refusal priority case=" + i);
                rejects(() -> factory.create(request, rate, now), IllegalArgumentException.class, "object factory rejects case=" + i);
            }
            check(functional.equals(create(request, rate, policy, now)), "equal inputs equal output case=" + i);
            System.out.println("RESULT case=" + i + " " + describe(functional));
        }
        EquipmentDescription description = new EquipmentDescription("camera", List.of("HD"));
        for (Equipment.State state : Equipment.State.values()) for (Action action : Action.values()) {
            Equipment.Snapshot before = new Equipment.Snapshot(new EquipmentId("camera"), description, state);
            Equipment object = Equipment.restore(before);
            Change functional = transition(before, action);
            Runnable operation = switch (action) {
                case APPROVE -> object::approveInspection;
                case INSPECT -> object::requireInspection;
                case RETIRE -> object::retire;
            };
            if (functional instanceof Changed changed) {
                operation.run();
                check(object.snapshot().equals(changed.next()), "same transition " + state + "/" + action);
            } else {
                rejects(operation, IllegalStateException.class, "same rejection " + state + "/" + action);
                check(object.snapshot().equals(before), "object unchanged after failure " + state + "/" + action);
            }
            check(before.state() == state, "pure input retained " + state + "/" + action);
        }
        rejects(() -> new Created(null), NullPointerException.class, "null success rejected at runtime");
        rejects(() -> new Rejected(null), NullPointerException.class, "null failure rejected at runtime");
        rejects(() -> describe(null), NullPointerException.class, "null result still expressible in Java");
        ReserveRequest request = new ReserveRequest(new RequestId("bad-price"), new EquipmentId("camera"),
                new Period(now.plusSeconds(3600), now.plusSeconds(7200)));
        check(create(request, rate, policy, now) instanceof Created, "explicit earlier now accepts");
        check(create(request, rate, policy, now.plusSeconds(1)).equals(new Rejected(Reason.TOO_SOON)),
                "explicit later now rejects without clock read");
        rejects(() -> new RentalContract.Snapshot(request, rate, new Money(BigDecimal.ZERO, Currency.getInstance("CNY"))),
                IllegalArgumentException.class, "mismatched quote rejected at runtime");
        System.out.println("PASS FunctionalCheck checks=" + checks);
    }
}
