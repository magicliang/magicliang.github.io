import json
from pathlib import Path
import sys
import tempfile
from evolution import BASE, merge_cell, migrate_v1_to_v2, overwrite_if_unchanged, restore, reverse_table, source_digest
sys.path.insert(0,str(BASE/'labs/33'))
from build import render, BuildError
from custom_policy import apply
from toolkit import generate_python, parse_model, step


def check(name,actual,expected):
    passed=actual==expected
    print(json.dumps({'scenario':name,'actual':actual,'expected':expected,'pass':passed}))
    if not passed:raise AssertionError(name)


def runtime(source):
    ns={};exec(compile(source,'<generated>','exec'),ns);return ns['step']


def outcome(action):
    try:return action()
    except ValueError:return 'REJECT'


def rejection_code(action):
    try:action()
    except ValueError as error:return str(error)
    return 'NOT_REJECTED'


def main():
    text=(BASE/'models/30/equipment.json').read_text();original=json.loads(text)
    evidence=BASE/'evidence/34';evidence.mkdir(parents=True,exist_ok=True)
    base_source=render(text)
    patch="\n_base = step\ndef step(state, operation):\n    if state == 'ACTIVE' and operation == 'retire':\n        raise ValueError('LOCAL_PATCH_DENY_RETIRE')\n    return _base(state, operation)\n"
    edited=base_source+patch
    (evidence/'hand-edited.py').write_text(edited)
    check('manual-output-edit-changes-runtime',outcome(lambda:runtime(edited)('ACTIVE','retire')),'REJECT')
    with tempfile.TemporaryDirectory() as temp:
        path=Path(temp)/'runtime.py';path.write_text(edited)
        check('guard-detects-edited-output',rejection_code(lambda:overwrite_if_unchanged(path,base_source,source_digest(base_source))),'GENERATED_ARTIFACT_MODIFIED')
        check('guard-preserves-edited-file',path.read_text()==edited,True)
        path.write_text(render(text))
        check('naive-regeneration-overwrites-manual-behavior',runtime(path.read_text())('ACTIVE','retire'),'RETIRED')
    recovered=reverse_table(edited,original)
    (evidence/'reverse-table.json').write_text(json.dumps(recovered,indent=2)+'\n')
    check('table-only-reverse-loses-manual-function-rule',step(parse_model(json.dumps(recovered)),'ACTIVE','retire'),'RETIRED')
    model_side=json.loads(text)
    for edge in model_side['transitions']:
        if edge['from']=='ACTIVE' and edge['operation']=='retire':edge['to']='INSPECTION_REQUIRED'
    changed_source=generate_python(parse_model(json.dumps(model_side)))
    code_side=base_source.replace("('ACTIVE', 'retire'): 'RETIRED'","('ACTIVE', 'retire'): 'ACTIVE'")
    (evidence/'model-edited-runtime.py').write_text(changed_source)
    (evidence/'code-table-edited.py').write_text(code_side)
    (evidence/'model-side.json').write_text(json.dumps(model_side,indent=2)+'\n')
    recovered_code=reverse_table(code_side,original)
    code_target=next(e['to'] for e in recovered_code['transitions'] if e['from']=='ACTIVE' and e['operation']=='retire')
    check('model-edit-executes-new-target',runtime(changed_source)('ACTIVE','retire'),'INSPECTION_REQUIRED')
    check('code-table-edit-executes-different-target',runtime(code_side)('ACTIVE','retire'),'ACTIVE')
    check('two-sided-roundtrip-conflict-rejected',rejection_code(lambda:merge_cell('RETIRED','INSPECTION_REQUIRED',code_target)),'ROUND_TRIP_CONFLICT')
    check('one-sided-change-merges',merge_cell('RETIRED','INSPECTION_REQUIRED','RETIRED'),'INSPECTION_REQUIRED')
    (evidence/'conflict.json').write_text(json.dumps({'cell':['ACTIVE','retire'],'base':'RETIRED','model_side':'INSPECTION_REQUIRED','code_side':code_target,'result':'ROUND_TRIP_CONFLICT'},indent=2)+'\n')
    check('separate-policy-survives-regeneration',outcome(lambda:apply(runtime(render(text)),'ACTIVE','retire')),'REJECT')
    check('separate-policy-allows-reasoned-retire',apply(runtime(render(text)),'ACTIVE','retire','damaged'),'RETIRED')
    v2text=(BASE/'models/34/revision2.json').read_text();v2=parse_model(v2text)
    check('renamed-model-needs-explicit-contract-change',outcome(lambda:render(v2text)),'REJECT')
    v2source=generate_python(v2);(evidence/'revision2-runtime.py').write_text(v2source)
    snapshot=json.loads((BASE/'models/34/snapshot-v1.json').read_text())
    check('old-snapshot-rejected-by-new-revision',outcome(lambda:restore(snapshot,v2,2)),'REJECT')
    check('old-state-cannot-run-new-model',outcome(lambda:runtime(v2source)(snapshot['state'],'requireInspection')),'REJECT')
    migrated=migrate_v1_to_v2(snapshot,v2)
    check('explicit-migration-preserves-identity',migrated,{'equipment_id':'E1','model_revision':2,'state':'READY'})
    check('migrated-state-runs-new-model',runtime(v2source)(migrated['state'],'requireInspection'),'INSPECTION_REQUIRED')
    fallback={'equipment_id':'E1','model_revision':2,'state':v2.initial}
    check('naive-reset-loses-prior-approval',outcome(lambda:runtime(v2source)(fallback['state'],'requireInspection')),'REJECT')
    check('unknown-old-state-rejected',outcome(lambda:migrate_v1_to_v2(dict(snapshot,state='LOST'),v2)),'REJECT')
    check('unknown-old-revision-rejected',outcome(lambda:migrate_v1_to_v2(dict(snapshot,model_revision=0),v2)),'REJECT')
    check('migration-does-not-mutate-original',snapshot,{'equipment_id':'E1','model_revision':1,'state':'ACTIVE'})
    (evidence/'migrated-snapshot.json').write_text(json.dumps(migrated,indent=2)+'\n')


if __name__=='__main__':main()
