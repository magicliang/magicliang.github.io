import argparse
from datetime import datetime
import json
from pathlib import Path
import re
import sys

BASE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(BASE / 'labs/30'))
from toolkit import ModelError, parse_model, validate_equipment_contract


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ModelError('DUPLICATE_KEY', '$', key)
        result[key] = value
    return result


def _constant(value):
    raise ModelError('JSON_SYNTAX', '$', value)


def _fields(value, fields, path):
    if not isinstance(value, dict) or set(value) != set(fields):
        raise ModelError('SHAPE', path, 'exact fields required')


def _identifier(value, path):
    if not isinstance(value, str) or re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', value) is None:
        raise ModelError('SHAPE', path, 'ASCII identifier required')


def validate_structure(text):
    try:
        raw = json.loads(text, object_pairs_hook=_pairs, parse_constant=_constant)
    except json.JSONDecodeError as error:
        raise ModelError('JSON_SYNTAX', f'line:{error.lineno}:column:{error.colno}', error.msg) from error
    _fields(raw, ['version', 'name', 'states', 'initial', 'terminal', 'operations', 'transitions'], '$')
    if type(raw['version']) is not int or raw['version'] != 1:
        raise ModelError('VERSION', '$.version', 'only integer 1 supported')
    for key in ['name', 'initial']:
        _identifier(raw[key], '$.' + key)
    for key in ['states', 'terminal', 'operations']:
        if not isinstance(raw[key], list) or (key != 'terminal' and not raw[key]):
            raise ModelError('SHAPE', '$.' + key, 'array required')
        for index, name in enumerate(raw[key]):
            _identifier(name, f'$.{key}[{index}]')
    if not isinstance(raw['transitions'], list):
        raise ModelError('SHAPE', '$.transitions', 'array required')
    for index, edge in enumerate(raw['transitions']):
        path = f'$.transitions[{index}]'
        _fields(edge, ['from', 'operation', 'to'], path)
        for key in ['from', 'operation', 'to']:
            _identifier(edge[key], path + '.' + key)


def audit_model(text):
    report = {'syntax_structure': 'NOT_RUN', 'generic_fsm': 'NOT_RUN', 'equipment_contract': 'NOT_RUN', 'failure': None}
    stage = 'syntax_structure'
    try:
        validate_structure(text)
        report[stage] = 'PASS'
        stage = 'generic_fsm'
        model = parse_model(text)
        report[stage] = 'PASS'
        stage = 'equipment_contract'
        validate_equipment_contract(model)
        report[stage] = 'PASS'
    except ModelError as error:
        report[stage] = 'FAIL'
        report['failure'] = {'code': error.code, 'path': error.path}
    return report


class ReservationError(ValueError):
    def __init__(self, code, path):
        self.code, self.path = code, path
        super().__init__(f'{code} at {path}')


def validate_reservations(rows, equipment_ids):
    if not isinstance(rows, list) or not isinstance(equipment_ids, set):
        raise ReservationError('SHAPE', '$')
    if any(not isinstance(identity, str) or not identity.strip() for identity in equipment_ids):
        raise ReservationError('SHAPE', '$.equipment_ids')
    seen, intervals = set(), []
    for index, row in enumerate(rows):
        path = f'$[{index}]'
        if not isinstance(row, dict) or set(row) != {'request_id', 'equipment_id', 'start', 'end', 'active'}:
            raise ReservationError('SHAPE', path)
        for key in ['request_id', 'equipment_id']:
            if not isinstance(row[key], str) or not row[key].strip():
                raise ReservationError('SHAPE', path + '.' + key)
        if type(row['active']) is not bool:
            raise ReservationError('SHAPE', path + '.active')
        if row['request_id'] in seen:
            raise ReservationError('DUPLICATE_REQUEST', path + '.request_id')
        seen.add(row['request_id'])
        if row['equipment_id'] not in equipment_ids:
            raise ReservationError('UNKNOWN_EQUIPMENT', path + '.equipment_id')
        times = []
        for key in ['start', 'end']:
            value = row[key]
            if not isinstance(value, str) or re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z', value) is None:
                raise ReservationError('UTC_SECONDS_REQUIRED', path + '.' + key)
            try:
                times.append(datetime.fromisoformat(value.replace('Z', '+00:00')))
            except ValueError as error:
                raise ReservationError('INVALID_TIME', path + '.' + key) from error
        start, end = times
        if start >= end:
            raise ReservationError('INVALID_PERIOD', path)
        if row['active']:
            if any(equipment == row['equipment_id'] and start < old_end and old_start < end
                   for equipment, old_start, old_end in intervals):
                raise ReservationError('OVERLAP', path)
            intervals.append((row['equipment_id'], start, end))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('model', type=Path)
    args = parser.parse_args()
    report = audit_model(args.model.read_text(encoding='utf-8'))
    print(json.dumps(report, ensure_ascii=False, sort_keys=True))
    raise SystemExit(1 if report['failure'] else 0)
