"""Handwritten extension: lifecycle remains delegated to the generated function."""
def apply(runtime_step, state: str, operation: str, reason: str = '') -> str:
    if operation == 'retire' and (not isinstance(reason,str) or not reason.strip()):
        raise ValueError('RETIRE_REASON_REQUIRED')
    return runtime_step(state, operation)
