"""Local generator variants; validated input via chapters30/32 and PSM via31."""
import argparse
import json
from pathlib import Path
import sys
BASE = Path(__file__).resolve().parents[2]
for chapter in ('30','31','32'):
    sys.path.insert(0,str(BASE/'labs'/chapter))
from toolkit import parse_model
from pipeline import pim_to_psm, psm_to_python
from constraints import audit_model


class BuildError(ValueError):
    pass


def render(text: str, variant: str = 'baseline') -> str:
    report = audit_model(text)
    if report['failure'] is not None:
        raise BuildError(json.dumps(report['failure'],sort_keys=True))
    source = psm_to_python(pim_to_psm(parse_model(text)))
    if variant == 'baseline':
        return source
    if variant == 'diagnostic':
        return source + '''\n_base_step = step

def step(state: str, operation: str) -> str:
    try:
        return _base_step(state, operation)
    except ValueError as error:
        raise ValueError(f'OPERATION_NOT_ALLOWED:{state}/{operation}') from error
'''
    if variant == 'faulty':
        return source + '''\ndef step(state: str, operation: str) -> str:
    return TRANSITIONS.get((state, operation), state)
'''
    raise BuildError('unknown generator variant')


def write_runtime(text: str, output: Path, variant: str = 'baseline') -> None:
    source = render(text,variant)
    compile(source,'<generated>','exec')
    output.write_text(source,encoding='utf-8')


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('model',type=Path)
    parser.add_argument('output',type=Path)
    parser.add_argument('--variant',choices=['baseline','diagnostic','faulty'],default='baseline')
    args=parser.parse_args()
    try:
        write_runtime(args.model.read_text(),args.output,args.variant)
    except BuildError as error:
        print(str(error),file=sys.stderr)
        raise SystemExit(1)
