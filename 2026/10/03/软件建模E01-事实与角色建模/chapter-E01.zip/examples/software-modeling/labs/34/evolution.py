"""Restricted table reverse-reading and explicit snapshot migration, not round-trip tooling."""
import ast
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
BASE=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(BASE/'labs/30'))
from toolkit import parse_model


def source_digest(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def overwrite_if_unchanged(path: Path, new_source: str, expected_digest: str) -> None:
    if source_digest(path.read_text())!=expected_digest:
        raise ValueError('GENERATED_ARTIFACT_MODIFIED')
    path.write_text(new_source)


def reverse_table(source: str, original: dict) -> dict:
    """Read only literal top-level INITIAL/TRANSITIONS; function bodies are deliberately lost."""
    values={}
    for node in ast.parse(source).body:
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
            name=node.targets[0].id
            if name in {'INITIAL','TRANSITIONS'}:
                if name in values:raise ValueError('duplicate table assignment')
                values[name]=ast.literal_eval(node.value)
    if set(values)!={'INITIAL','TRANSITIONS'}:raise ValueError('missing literal tables')
    raw=deepcopy(original);raw['initial']=values['INITIAL']
    raw['transitions']=[{'from':s,'operation':o,'to':target} for (s,o),target in values['TRANSITIONS'].items()]
    return parse_model(json.dumps(raw)).as_dict()


def merge_cell(base: str, model_side: str, code_side: str) -> str:
    if model_side!=base and code_side!=base and model_side!=code_side:
        raise ValueError('ROUND_TRIP_CONFLICT')
    return code_side if code_side!=base else model_side


def restore(snapshot: dict, model, revision: int) -> dict:
    if set(snapshot)!={'equipment_id','model_revision','state'} or type(snapshot['model_revision']) is not int:
        raise ValueError('SNAPSHOT_SHAPE')
    if snapshot['model_revision']!=revision or snapshot['state'] not in model.states:
        raise ValueError('SNAPSHOT_MODEL_MISMATCH')
    return dict(snapshot)


def migrate_v1_to_v2(snapshot: dict, target) -> dict:
    if set(snapshot)!={'equipment_id','model_revision','state'} or type(snapshot['model_revision']) is not int or snapshot['model_revision']!=1:
        raise ValueError('UNKNOWN_SOURCE_REVISION')
    mapping={'INSPECTION_REQUIRED':'INSPECTION_REQUIRED','ACTIVE':'READY','RETIRED':'RETIRED'}
    if snapshot['state'] not in mapping:raise ValueError('UNKNOWN_LEGACY_STATE')
    return restore({'equipment_id':snapshot['equipment_id'],'model_revision':2,'state':mapping[snapshot['state']]},target,2)
