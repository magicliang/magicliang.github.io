"""Finite fact-population checks, not an ORM2 tool or object-relational mapper."""
from copy import deepcopy
import itertools,json
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]

def validate(p):
    reservations=set(p['reservations']);parties=set(p['parties']);equipment=set(p['equipment'])
    relations={name:set(map(tuple,p[name])) for name in ('requested_by','for_equipment','approved_by')}
    for name,target in [('requested_by',parties),('for_equipment',equipment),('approved_by',parties)]:
        if any(len(row)!=2 or row[0] not in reservations or row[1] not in target for row in relations[name]):raise ValueError('ROLE_TYPE_OR_REFERENCE')
    for name in ('requested_by','for_equipment'):
        for reservation in reservations:
            count=sum(r==reservation for r,_ in relations[name])
            if count==0:raise ValueError('MANDATORY:'+name)
            if count>1:raise ValueError('UNIQUE:'+name)
    if set(p['confirmed'])-reservations:raise ValueError('UNKNOWN_CONFIRMED')
    if set(p['confirmed'])-{r for r,_ in relations['approved_by']}:raise ValueError('CONFIRMED_SUBSET_APPROVED')
    if relations['requested_by'] & relations['approved_by']:raise ValueError('REQUESTER_APPROVER_EXCLUSION')
    return relations

def rows(p):
    r=validate(p)
    return [{'id':x,'requester':next(person for reservation,person in r['requested_by'] if reservation==x),'equipment':next(eq for reservation,eq in r['for_equipment'] if reservation==x),'approvers':sorted(person for reservation,person in r['approved_by'] if reservation==x),'confirmed':x in p['confirmed']} for x in sorted(p['reservations'])]

def check(name,actual,expected):
    passed=actual==expected;print(json.dumps({'scenario':name,'actual':actual,'expected':expected,'pass':passed}))
    if not passed:raise AssertionError(name)

def rejected(p):
    try:validate(p)
    except ValueError as error:return str(error)
    return 'ACCEPT'

def main():
    p=json.loads((BASE/'models/E01/population.json').read_text());validate(p)
    check('valid-population',rejected(p),'ACCEPT')
    q=deepcopy(p);q['requested_by'].append(['R1','P2']);check('reservation-requester-uniqueness',rejected(q),'UNIQUE:requested_by')
    q=deepcopy(p);q['requested_by']=[['R1','P1']];check('requester-mandatory',rejected(q),'MANDATORY:requested_by')
    q=deepcopy(p);q['for_equipment']=[['R1','E1']];check('equipment-mandatory',rejected(q),'MANDATORY:for_equipment')
    q=deepcopy(p);q['approved_by'].append(['R2','P9']);check('unknown-party-role-rejected',rejected(q),'ROLE_TYPE_OR_REFERENCE')
    q=deepcopy(p);q['confirmed'].append('R2');check('confirmation-needs-approval',rejected(q),'CONFIRMED_SUBSET_APPROVED')
    q=deepcopy(p);q['approved_by'].append(['R1','P1']);check('self-approval-rejected',rejected(q),'REQUESTER_APPROVER_EXCLUSION')
    q=deepcopy(p);q['approved_by'].append(['R1','P3']);check('multiple-independent-approvers-allowed',rejected(q),'ACCEPT')
    q=deepcopy(p);q['approved_by'].append(['R2','P2']);check('approval-does-not-imply-confirmation',rejected(q),'ACCEPT')
    q=deepcopy(p);q['requested_by'].append(['R1','P1']);check('duplicate-whole-fact-is-idempotent',rows(q),rows(p))
    check('same-person-requests-many-reservations',[r['requester'] for r in rows(p)],['P1','P1'])
    check('optional-approval-survives-er-mapping',[r['approvers'] for r in rows(p)],[['P2'],[]])
    triples={('P1','E1','D1'),('P1','E2','D2'),('P2','E1','D2')}
    pe={(p,e) for p,e,d in triples};pd={(p,d) for p,e,d in triples};ed={(e,d) for p,e,d in triples}
    joined={(p,e,d) for p,e,d in itertools.product({'P1','P2'},{'E1','E2'},{'D1','D2'}) if (p,e) in pe and (p,d) in pd and (e,d) in ed}
    check('binary-decomposition-adds-false-ternary-fact',sorted(joined-triples),[('P1','E1','D2')])
    ev=BASE/'evidence/E01';ev.mkdir(parents=True,exist_ok=True)
    (ev/'er-rows.json').write_text(json.dumps(rows(p),indent=2)+'\n')
    (ev/'decomposition.json').write_text(json.dumps({'original':sorted(triples),'joined':sorted(joined),'spurious':sorted(joined-triples)},indent=2)+'\n')

if __name__=='__main__':main()
