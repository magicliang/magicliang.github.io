package rental.legacy;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import rental.RentalDesk.EquipmentId;
import rental.application.ApplicationCheck;
import rental.application.RentalApplication;
import rental.application.RentalApplication.MemoryRepository;
import rental.application.RentalApplication.Snapshot;
import rental.application.RentalApplication.Status;
import rental.domain.Equipment;
import rental.domain.ReservationCalendar;
import static rental.legacy.LegacyMigration.*;

public final class MigrationCheck {
    private static int checks;
    private static void check(boolean value, String label) {
        if (!value) throw new AssertionError(label);
        checks++;
        System.out.println("PASS " + label);
    }
    public static void main(String[] args) throws Exception {
        List<String> lines = Files.readAllLines(Path.of(args[0]));
        List<Row> rows = lines.subList(1, lines.size()).stream().map(line -> {
            String[] values = line.split(",", -1);
            if (values.length != 6) throw new IllegalArgumentException("fixture requires six columns");
            return new Row(values[0], values[1], values[2], values[3], values[4], values[5]);
        }).toList();
        Snapshot empty = new Snapshot(Map.of(), new ReservationCalendar("legacy-migration").snapshot(), Map.of(), Map.of());
        State initial = new State(empty, Map.of(), Map.of());
        Batch first = migrate(initial, rows.subList(0, 1));
        check(first.next().application().equipment().size() == 1, "batch1 imports one identity");
        check(initial.application().equipment().isEmpty(), "source snapshot retained");
        Batch second = migrate(first.next(), rows.subList(1, 4));
        check(second.next().application().equipment().size() == 3, "batch2 preserves first and adds two known rows");
        check(second.quarantine().keySet().equals(java.util.Set.of("L-D")), "unknown inspection quarantined");
        check(migrate(second.next(), rows).next().equals(second.next()), "repeated import does not duplicate");
        MemoryRepository repository = new MemoryRepository(second.next().application(), ApplicationCheck.NONE);
        RentalApplication application = new RentalApplication(repository, id -> second.next().maintenance().get(id),
                event -> { }, ApplicationCheck.NONE, new RentalApplication.InlineAdmission(), ApplicationCheck.SPEC);
        for (int i = 0; i < 3; i++) {
            Row row = rows.get(i);
            Status status = application.reserve(ApplicationCheck.command("request-" + i, "legacy:" + row.code(), 7200, 10800), ApplicationCheck.NOW);
            Status expected = i == 0 ? Status.CONFIRMED : Status.INELIGIBLE;
            check(status == expected, "translated 27-v1 status " + row.code() + "=" + status);
            check(legacyAvailable(row), "legacy predicate accepts " + row.code());
            System.out.println("SHADOW code=" + row.code() + " legacy=true target=" + status);
        }
        Row changed = new Row("L-A", "Y", "N", "PENDING", "N", "changed-after-import");
        Batch conflict = migrate(second.next(), List.of(changed));
        check(conflict.next().equals(second.next()) && conflict.quarantine().containsKey("L-A"), "source revision change not silently overwritten");
        Row busy = new Row("L-E", "Y", "Y", "PASS", "N", "missing-time-window");
        check(migrate(second.next(), List.of(busy)).quarantine().containsKey("L-E"), "busy cannot become fabricated reservation");
        Batch duplicate = migrate(initial, List.of(rows.get(0), rows.get(0)));
        check(duplicate.next().equals(initial) && duplicate.quarantine().containsKey("L-A"), "duplicate batch identity imports neither row");
        State occupiedIdentity = new State(second.next().application(), Map.of(), Map.of());
        check(migrate(occupiedIdentity, List.of(rows.get(0))).quarantine().containsKey("L-A"), "target collision rejected");
        check(second.next().application().equipment().get(new EquipmentId("legacy:L-C")).state() == Equipment.State.RETIRED,
                "retirement marker overrides passed inspection");
        check(second.next().imported().get("L-A").note().equals("old-main-camera"), "raw note retained without invented meaning");
        if (args.length > 1 && args[1].equals("unknown")) translate(rows.get(3));
        System.out.println("RESULT chapter37 checks=" + checks + " imported=3 quarantine=1");
    }
}
