package rental.legacy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import rental.RentalDesk.EquipmentId;
import rental.application.RentalApplication.Maintenance;
import rental.application.RentalApplication.Snapshot;
import rental.domain.Equipment;
import rental.domain.EquipmentDescription;

public final class LegacyMigration {
    private LegacyMigration() {}
    public record Row(String code, String ready, String busy, String inspection, String retired, String note) {}
    public record Translation(Equipment.Snapshot equipment, Maintenance maintenance, Row source) {}
    public record State(Snapshot application, Map<String, Row> imported, Map<EquipmentId, Maintenance> maintenance) {
        public State {
            Objects.requireNonNull(application);
            imported = Map.copyOf(imported);
            maintenance = Map.copyOf(maintenance);
        }
    }
    public record Batch(State next, Map<String, String> quarantine) {
        public Batch { quarantine = Map.copyOf(quarantine); }
    }
    public static boolean legacyAvailable(Row row) {
        return row.ready().equals("Y") && row.busy().equals("N");
    }
    public static Translation translate(Row row) {
        Objects.requireNonNull(row);
        if (row.code() == null || row.code().isBlank()) throw new IllegalArgumentException("missing code");
        for (String flag : List.of(row.ready(), row.busy(), row.retired())) {
            if (!List.of("Y", "N").contains(flag)) throw new IllegalArgumentException("unknown flag");
        }
        if (!List.of("PASS", "PENDING").contains(row.inspection())) {
            throw new IllegalArgumentException("unknown inspection code; manual decision required");
        }
        if (row.busy().equals("Y")) throw new IllegalArgumentException("busy has no period; cannot reconstruct commitment");
        Equipment.State state = row.retired().equals("Y") ? Equipment.State.RETIRED
                : row.inspection().equals("PASS") ? Equipment.State.ACTIVE : Equipment.State.INSPECTION_REQUIRED;
        EquipmentId id = new EquipmentId("legacy:" + row.code());
        Equipment.Snapshot equipment = new Equipment.Snapshot(id, new EquipmentDescription("legacy-camera", List.of()), state);
        return new Translation(equipment, row.ready().equals("Y") ? Maintenance.RELEASED : Maintenance.BLOCKED, row);
    }
    public static Batch migrate(State before, List<Row> rows) {
        Map<EquipmentId, Equipment.Snapshot> equipment = new HashMap<>(before.application().equipment());
        Map<String, Row> imported = new HashMap<>(before.imported());
        Map<EquipmentId, Maintenance> maintenance = new HashMap<>(before.maintenance());
        Map<String, String> quarantine = new HashMap<>();
        Map<String, Long> counts = rows.stream().collect(java.util.stream.Collectors.groupingBy(Row::code,
                java.util.stream.Collectors.counting()));
        for (Row row : rows) {
            if (counts.get(row.code()) != 1) {
                quarantine.put(row.code(), "duplicate source identity in batch");
                continue;
            }
            try {
                Translation translated = translate(row);
                Row old = imported.get(row.code());
                if (old != null) {
                    if (!old.equals(row)) throw new IllegalArgumentException("source changed; reconciliation required");
                    continue;
                }
                EquipmentId id = translated.equipment().id();
                if (equipment.containsKey(id)) throw new IllegalArgumentException("target identity collision");
                equipment.put(id, translated.equipment());
                imported.put(row.code(), row);
                maintenance.put(id, translated.maintenance());
            } catch (IllegalArgumentException error) {
                quarantine.put(row.code(), error.getMessage());
            }
        }
        Snapshot old = before.application();
        Snapshot next = new Snapshot(equipment, old.calendar(), old.receipts(), old.contracts());
        return new Batch(new State(next, imported, maintenance), quarantine);
    }
}
