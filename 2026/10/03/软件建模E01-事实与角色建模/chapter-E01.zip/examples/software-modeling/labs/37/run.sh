#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
java_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}java
javac_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}javac
"$java_cmd" -version
"$javac_cmd" -version
build=$(mktemp -d)
trap 'rm -rf "$build"' EXIT
"$javac_cmd" --release 21 -Xlint:all -Werror -d "$build" "$root/rental-core/RentalDesk.java" "$root/labs/24/Equipment.java" "$root/labs/24/EquipmentDescription.java" "$root/labs/24/Money.java" "$root/labs/25/ReservationCalendar.java" "$root/labs/26/PricingService.java" "$root/labs/26/RentalPeriodSpecification.java" "$root/labs/26/RentalContract.java" "$root/rental-application/RentalApplication.java" "$root/labs/27/ApplicationCheck.java" "$root/labs/37/LegacyMigration.java" "$root/labs/37/MigrationCheck.java"
"$java_cmd" -ea -cp "$build" rental.legacy.MigrationCheck "$root/models/37/legacy.csv" "$@"
