package rental.review;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import rental.RentalDesk.RequestId;
import rental.application.ApplicationCheck;
import rental.application.RentalApplication;
import rental.application.RentalApplication.Command;
import rental.application.RentalApplication.MemoryRepository;
import rental.application.RentalApplication.Snapshot;
import rental.application.RentalApplication.Status;
import rental.domain.Money;
import rental.domain.PricingService;
import rental.domain.PricingService.HourlyRate;

public final class Amendments {
    public enum Kind { EXTEND, SWAP }
    public sealed interface Change permits Replacement, Reprice {
        String operationId();
        RequestId target();
    }
    public record Replacement(String operationId, RequestId target, Kind kind, Command replacement) implements Change {
        public Replacement {
            validId(operationId); Objects.requireNonNull(target); Objects.requireNonNull(kind); Objects.requireNonNull(replacement);
        }
    }
    public record Reprice(String operationId, RequestId target, HourlyRate newRate, String reason) implements Change {
        public Reprice {
            validId(operationId); Objects.requireNonNull(target); Objects.requireNonNull(newRate);
            if (reason == null || reason.isBlank()) throw new IllegalArgumentException("reason required");
        }
    }
    public record Adjustment(RequestId target, HourlyRate newRate, Money delta, String reason) {}
    public record Receipt(Change change, String outcome) {}
    public record State(int version, Snapshot baseline, Map<String, Receipt> changes,
                        List<Adjustment> adjustments, Map<RequestId, RequestId> successors) {
        public State {
            if (version != 2) throw new IllegalArgumentException("overlay version");
            Objects.requireNonNull(baseline);
            changes = Map.copyOf(changes);
            adjustments = List.copyOf(adjustments);
            successors = Map.copyOf(successors);
        }
    }
    private State state;
    public Amendments(Snapshot v1) {
        Snapshot restored = new MemoryRepository(v1, ApplicationCheck.NONE).read();
        state = new State(2, restored, Map.of(), List.of(), Map.of());
    }
    public Amendments(State trustedSnapshot) {
        Objects.requireNonNull(trustedSnapshot);
        state = new State(trustedSnapshot.version(), new MemoryRepository(trustedSnapshot.baseline(), ApplicationCheck.NONE).read(),
                trustedSnapshot.changes(), trustedSnapshot.adjustments(), trustedSnapshot.successors());
    }
    private static void validId(String id) {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("operation id required");
    }
    public synchronized State read() { return state; }
    public synchronized Money effectiveTotal(RequestId target) {
        var contract = state.baseline().contracts().get(target);
        if (contract == null) throw new IllegalArgumentException("unknown contract");
        Money total = contract.total();
        for (Adjustment adjustment : state.adjustments()) if (adjustment.target().equals(target)) total = total.add(adjustment.delta());
        return total;
    }
    public synchronized String apply(Change change, Instant now) {
        Objects.requireNonNull(change); Objects.requireNonNull(now);
        Receipt prior = state.changes().get(change.operationId());
        if (prior != null) {
            if (!prior.change().equals(change)) throw new IllegalArgumentException("operation id changed payload");
            return prior.outcome();
        }
        var contract = state.baseline().contracts().get(change.target());
        if (contract == null) throw new IllegalArgumentException("unknown contract");
        Snapshot next = state.baseline();
        List<Adjustment> adjustments = new ArrayList<>(state.adjustments());
        Map<RequestId, RequestId> successors = new HashMap<>(state.successors());
        String outcome;
        if (change instanceof Reprice reprice) {
            if (!contract.total().currency().equals(reprice.newRate().price().currency())) throw new IllegalArgumentException("currency change forbidden");
            Money target = new PricingService().quote(contract.request().period(), reprice.newRate());
            Money current = effectiveTotal(change.target());
            Money delta = new Money(target.amount().subtract(current.amount()), target.currency());
            adjustments.add(new Adjustment(change.target(), reprice.newRate(), delta, reprice.reason()));
            outcome = "ADJUSTED:" + delta.amount();
        } else {
            Replacement replacement = (Replacement) change;
            boolean active = state.baseline().calendar().receipts().stream()
                    .anyMatch(receipt -> receipt.active() && receipt.request().requestId().equals(change.target()));
            if (!active) throw new IllegalArgumentException("target not active");
            if (state.adjustments().stream().anyMatch(a -> a.target().equals(change.target()))) {
                throw new IllegalArgumentException("replacement after reprice requires new policy");
            }
            Command command = replacement.replacement();
            if (state.baseline().receipts().containsKey(command.request().requestId())) throw new IllegalArgumentException("fresh request id required");
            if (!command.rate().equals(contract.rate())) throw new IllegalArgumentException("replacement must retain agreed rate");
            var old = contract.request();
            var revised = command.request();
            if (replacement.kind() == Kind.EXTEND) {
                if (!old.equipmentId().equals(revised.equipmentId()) || !old.period().start().equals(revised.period().start())
                        || !revised.period().end().isAfter(old.period().end())) throw new IllegalArgumentException("invalid extension shape");
            } else if (old.equipmentId().equals(revised.equipmentId()) || !old.period().equals(revised.period())) {
                throw new IllegalArgumentException("invalid swap shape");
            }
            MemoryRepository candidate = new MemoryRepository(state.baseline(), ApplicationCheck.NONE);
            RentalApplication application = new RentalApplication(candidate, id -> RentalApplication.Maintenance.RELEASED,
                    event -> { }, ApplicationCheck.NONE, new RentalApplication.InlineAdmission(), ApplicationCheck.SPEC);
            if (!application.cancel(change.target())) throw new AssertionError("active target disappeared");
            Status result = application.reserve(command, now);
            outcome = result.name();
            if (result == Status.CONFIRMED) {
                next = candidate.read();
                successors.put(change.target(), command.request().requestId());
            }
        }
        Map<String, Receipt> receipts = new HashMap<>(state.changes());
        receipts.put(change.operationId(), new Receipt(change, outcome));
        state = new State(2, next, receipts, adjustments, successors);
        return outcome;
    }
}
