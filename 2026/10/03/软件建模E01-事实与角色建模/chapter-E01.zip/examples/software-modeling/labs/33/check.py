import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from build import BASE, render, write_runtime
from custom_policy import apply
from toolkit import parse_model, step


def check(name,actual,expected):
    passed=actual==expected
    print(json.dumps({'scenario':name,'actual':actual,'expected':expected,'pass':passed}))
    if not passed:raise AssertionError(name)


def load(source):
    ns={};exec(compile(source,'<generated>','exec'),ns);return ns['step']


def outcome(fn,state,operation):
    try:return fn(state,operation)
    except ValueError:return 'REJECT'


def manual(state,operation):
    if state=='INSPECTION_REQUIRED':
        if operation=='approveInspection':return 'ACTIVE'
        if operation=='retire':return 'RETIRED'
    if state=='ACTIVE':
        if operation=='requireInspection':return 'INSPECTION_REQUIRED'
        if operation=='retire':return 'RETIRED'
    raise ValueError('not allowed')


def main():
    text=(BASE/'models/30/equipment.json').read_text();model=parse_model(text)
    evidence=BASE/'evidence/33';evidence.mkdir(parents=True,exist_ok=True)
    sources={name:render(text,name) for name in ('baseline','diagnostic','faulty')}
    for name,source in sources.items():(evidence/f'{name}.py').write_text(source)
    runtimes={name:load((evidence/f'{name}.py').read_text()) for name in sources}
    cases=json.loads((BASE/'models/33/contract-cases.json').read_text())
    for state,operation,expected in cases:
        actual=[outcome(fn,state,operation) for fn in (manual,lambda s,o:step(model,s,o),runtimes['baseline'],runtimes['diagnostic'])]
        check(f'matrix:{state}:{operation}',actual,[expected]*4)
    check('same-model-same-generator-deterministic',render(text,'diagnostic')==sources['diagnostic'],True)
    check('template-change-alters-output-bytes',sources['baseline']!=sources['diagnostic'],True)
    try:runtimes['diagnostic']('RETIRED','retire')
    except ValueError as error:message=str(error)
    check('diagnostic-template-identifies-failed-operation',message,'OPERATION_NOT_ALLOWED:RETIRED/retire')
    mismatches=[f'{s}/{o}' for s,o,expected in cases if outcome(runtimes['faulty'],s,o)!=expected]
    check('faulty-template-fails-five-negative-contracts',mismatches,[f'{s}/{o}' for s,o,e in cases if e=='REJECT'])
    check('custom-policy-rejects-missing-reason',outcome(lambda s,o:apply(runtimes['diagnostic'],s,o),'ACTIVE','retire'),'REJECT')
    check('custom-policy-delegates-valid-retirement',apply(runtimes['diagnostic'],'ACTIVE','retire','damaged'),'RETIRED')
    check('custom-policy-cannot-revive-retired',outcome(lambda s,o:apply(runtimes['diagnostic'],s,o,'repair'),'RETIRED','approveInspection'),'REJECT')
    with tempfile.TemporaryDirectory() as temp:
        output=Path(temp)/'runtime.py';output.write_text(sources['baseline'])
        run=subprocess.run([sys.executable,str(Path(__file__).with_name('build.py')),str(BASE/'models/30/invalid/unknown-target.json'),str(output)],capture_output=True,text=True)
        (evidence/'invalid-build-output.txt').write_text(run.stdout+run.stderr);(evidence/'invalid-build-exit.txt').write_text(str(run.returncode)+'\n')
        check('invalid-build-process-exit',run.returncode,1)
        check('invalid-build-reports-input-path',json.loads(run.stderr),{'code':'UNKNOWN_STATE','path':'$.transitions[0].to'})
        check('invalid-build-preserves-prior-artifact',output.read_text(),sources['baseline'])
    (evidence/'generator-hashes.json').write_text(json.dumps({name:hashlib.sha256(source.encode()).hexdigest() for name,source in sources.items()},indent=2)+'\n')


if __name__=='__main__':main()
