package rental.functional;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.Objects;
import rental.RentalDesk.ReserveRequest;
import rental.domain.Equipment;
import rental.domain.Money;
import rental.domain.PricingService.HourlyRate;
import rental.domain.RentalContract;
import rental.domain.RentalPeriodSpecification;

public final class FunctionalModel {
    private FunctionalModel() {}
    public enum Reason { TOO_SOON, TOO_LONG }
    public sealed interface Creation permits Created, Rejected {}
    public record Created(RentalContract.Snapshot draft) implements Creation {
        public Created { Objects.requireNonNull(draft, "draft"); }
    }
    public record Rejected(Reason reason) implements Creation {
        public Rejected { Objects.requireNonNull(reason, "reason"); }
    }
    public enum Action { APPROVE, INSPECT, RETIRE }
    public sealed interface Change permits Changed, Refused {}
    public record Changed(Equipment.Snapshot next) implements Change {
        public Changed { Objects.requireNonNull(next, "next"); }
    }
    public record Refused(Equipment.State state, Action action) implements Change {
        public Refused {
            Objects.requireNonNull(state, "state");
            Objects.requireNonNull(action, "action");
        }
    }

    public static Creation create(ReserveRequest request, HourlyRate rate,
                                  RentalPeriodSpecification policy, Instant now) {
        Objects.requireNonNull(request, "request");
        Objects.requireNonNull(rate, "rate");
        Objects.requireNonNull(policy, "policy");
        Objects.requireNonNull(now, "now");
        if (Duration.between(now, request.period().start()).compareTo(policy.minimumLead()) < 0) {
            return new Rejected(Reason.TOO_SOON);
        }
        Duration duration = Duration.between(request.period().start(), request.period().end());
        if (duration.compareTo(policy.maximumDuration()) > 0) return new Rejected(Reason.TOO_LONG);
        long hours = duration.getSeconds() / 3600;
        if (duration.getSeconds() % 3600 != 0 || duration.getNano() != 0) hours++;
        Money total = new Money(rate.price().amount().multiply(BigDecimal.valueOf(hours)), rate.price().currency());
        return new Created(new RentalContract.Snapshot(request, rate, total));
    }

    public static Change transition(Equipment.Snapshot before, Action action) {
        Objects.requireNonNull(before, "before");
        Objects.requireNonNull(action, "action");
        Equipment.State next = switch (action) {
            case APPROVE -> before.state() == Equipment.State.INSPECTION_REQUIRED ? Equipment.State.ACTIVE : null;
            case INSPECT -> before.state() == Equipment.State.ACTIVE ? Equipment.State.INSPECTION_REQUIRED : null;
            case RETIRE -> before.state() != Equipment.State.RETIRED ? Equipment.State.RETIRED : null;
        };
        if (next == null) return new Refused(before.state(), action);
        return new Changed(new Equipment.Snapshot(before.id(), before.description(), next));
    }

    public static String describe(Creation result) {
        Objects.requireNonNull(result, "result");
        return switch (result) {
            case Created created -> "CREATED:" + created.draft().total().amount();
            case Rejected rejected -> rejected.reason().name();
        };
    }
}
