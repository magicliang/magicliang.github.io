import copy
import json
from pathlib import Path

from constraints import BASE, ReservationError, audit_model, validate_reservations
from toolkit import load_model, step

COUNT = 0


def check(name, condition):
    global COUNT
    if not condition:
        raise AssertionError(name)
    COUNT += 1
    print('PASS', name)


def failure(name, text, stage, code):
    report = audit_model(text)
    check(name, report[stage] == 'FAIL' and report['failure']['code'] == code)
    print('OBSERVED', name, json.dumps(report, sort_keys=True))
    return report


def reject_rows(name, rows, expected):
    try:
        validate_reservations(rows, {'E1', 'E2'})
    except ReservationError as error:
        check(name, error.code == expected)
        print('REJECTED', error)
        return
    raise AssertionError('expected rejection: ' + name)


def main():
    valid_text = (BASE / 'models/30/equipment.json').read_text()
    valid = json.loads(valid_text)
    check('valid equipment passes three layers', all(value == 'PASS' for key, value in audit_model(valid_text).items() if key != 'failure'))
    syntax = failure('JSON syntax rejected', '{', 'syntax_structure', 'JSON_SYNTAX')
    check('later stages not run on malformed JSON', syntax['generic_fsm'] == syntax['equipment_contract'] == 'NOT_RUN')
    bad_type = copy.deepcopy(valid)
    bad_type['states'] = 'ACTIVE'
    failure('JSON legal but shape wrong', json.dumps(bad_type), 'syntax_structure', 'SHAPE')
    unknown = copy.deepcopy(valid)
    unknown['transitions'][0]['to'] = 'GHOST'
    refs = failure('unknown state is semantic error', json.dumps(unknown), 'generic_fsm', 'UNKNOWN_STATE')
    check('structure passed before semantic failure', refs['syntax_structure'] == 'PASS' and refs['equipment_contract'] == 'NOT_RUN')
    mixed = copy.deepcopy(unknown)
    mixed['transitions'][1]['to'] = 123
    failure('complete structure gate precedes semantic gate', json.dumps(mixed), 'syntax_structure', 'SHAPE')
    nondeterministic = copy.deepcopy(valid)
    nondeterministic['transitions'].append(copy.deepcopy(valid['transitions'][0]))
    failure('duplicate dispatch key rejected', json.dumps(nondeterministic), 'generic_fsm', 'NONDETERMINISTIC')
    terminal_exit = copy.deepcopy(valid)
    terminal_exit['transitions'].append({'from': 'RETIRED', 'operation': 'approveInspection', 'to': 'ACTIVE'})
    failure('declared terminal cannot exit', json.dumps(terminal_exit), 'generic_fsm', 'TERMINAL_OUTGOING')
    wrong_text = (BASE / 'models/32/wrong-policy.json').read_text()
    wrong = load_model(BASE / 'models/32/wrong-policy.json')
    state = step(wrong, wrong.initial, 'retire')
    revived = step(wrong, state, 'approveInspection')
    check('wrong policy actually revives retired equipment', state == 'RETIRED' and revived == 'ACTIVE')
    print('OBSERVED wrong-policy trace=' + json.dumps([wrong.initial, state, revived]))
    report = failure('domain contract blocks generic-valid wrong policy', wrong_text, 'equipment_contract', 'EQUIPMENT_CONTRACT')
    check('wrong policy passes first two gates', report['syntax_structure'] == report['generic_fsm'] == 'PASS')
    (BASE / 'evidence/32/audit-wrong-policy.json').write_text(json.dumps(report, indent=2) + '\n')
    previous_wrong = audit_model((BASE / 'models/30/wrong-policy.json').read_text())
    check('chapter30 approval policy counterexample still rejected', previous_wrong['failure']['code'] == 'EQUIPMENT_CONTRACT')
    for case in json.loads((BASE / 'models/30/invalid-cases.json').read_text()):
        audit = audit_model((BASE / 'models/30/invalid' / case['file']).read_text())
        check('chapter30 fixture ' + case['name'], audit['failure']['code'] == case['code'])
    rows = json.loads((BASE / 'models/32/reservations.json').read_text())
    before = copy.deepcopy(rows)
    validate_reservations(rows, {'E1', 'E2'})
    check('adjacent UTC half-open periods accepted without mutation', rows == before)
    for label, key, value, code in [
        ('zero length period', 'end', rows[0]['start'], 'INVALID_PERIOD'),
        ('reverse period', 'end', '2026-10-03T09:00:00Z', 'INVALID_PERIOD'),
        ('unknown equipment reference', 'equipment_id', 'GHOST', 'UNKNOWN_EQUIPMENT'),
        ('missing timezone', 'start', '2026-10-03T10:00:00', 'UTC_SECONDS_REQUIRED'),
        ('invalid calendar date', 'start', '2026-02-30T10:00:00Z', 'INVALID_TIME'),
        ('boolean is not string identity', 'equipment_id', True, 'SHAPE'),
        ('number is not active flag', 'active', 1, 'SHAPE')]:
        changed = copy.deepcopy(rows)
        changed[0][key] = value
        reject_rows(label, changed, code)
    overlap = copy.deepcopy(rows)
    overlap[1]['start'] = '2026-10-03T11:00:00Z'
    reject_rows('same equipment active overlap', overlap, 'OVERLAP')
    overlap[1]['active'] = False
    validate_reservations(overlap, {'E1', 'E2'})
    check('inactive history does not occupy', True)
    overlap[1]['active'] = True
    overlap[1]['equipment_id'] = 'E2'
    validate_reservations(overlap, {'E1', 'E2'})
    check('different equipment can overlap', True)
    duplicated = copy.deepcopy(rows)
    duplicated[1]['request_id'] = 'R1'
    reject_rows('duplicate reservation identity', duplicated, 'DUPLICATE_REQUEST')
    print(f'PASS chapter32 checks={COUNT}')


if __name__ == '__main__':
    main()
