from dataclasses import dataclass, replace
from datetime import datetime
from decimal import Decimal
import json
import sys


@dataclass(frozen=True)
class Request:
    id: str
    equipment: str
    start: str
    end: str
    requester: str
    payer: str

    def __post_init__(self):
        for value in (self.start, self.end):
            if not value.endswith("Z"):
                raise ValueError("UTC required")
            datetime.fromisoformat(value.replace("Z", "+00:00"))
        if self.start >= self.end:
            raise ValueError("positive period required")


@dataclass(frozen=True)
class Rate:
    revision: str
    hourly: Decimal


def overlaps(left, right):
    return left.equipment == right.equipment and left.start < right.end and right.start < left.end


def quote(request, rate):
    duration = datetime.fromisoformat(request.end.replace("Z", "+00:00")) - datetime.fromisoformat(request.start.replace("Z", "+00:00"))
    hours = (int(duration.total_seconds()) + 3599) // 3600
    return rate.hourly * hours


class Flat:
    def __init__(self):
        self.active = {}
        self.catalog = Rate("v1", Decimal("10.00"))

    def reserve(self, request):
        if any(overlaps(request, old) for old in self.active.values()):
            return "OVERLAP_REJECTED"
        self.active[request.id] = request
        return "CONFIRMED"

    def plan(self, request):
        self.reserve(request)

    def cancel(self, request_id):
        return self.active.pop(request_id, None) is not None

    def price(self, request):
        return quote(request, self.catalog)

    def roles(self, request):
        return {"customer": request.requester}


class Semantic(Flat):
    def __init__(self):
        super().__init__()
        self.proposals = {}
        self.agreed_rates = {}

    def plan(self, request):
        self.proposals[request.id] = request

    def reserve(self, request):
        outcome = super().reserve(request)
        if outcome == "CONFIRMED":
            self.agreed_rates[request.id] = self.catalog
        return outcome

    def price(self, request):
        return quote(request, self.agreed_rates[request.id])

    def roles(self, request):
        return {"requester": request.requester, "payer": request.payer}


class Bounded(Semantic):
    def __init__(self):
        super().__init__()
        self.receipts = {}

    def reserve(self, request):
        if request.id in self.receipts:
            old, outcome = self.receipts[request.id]
            if old != request:
                raise ValueError("request id reused with different payload")
            return outcome
        outcome = super().reserve(request)
        self.receipts[request.id] = (request, outcome)
        return outcome


REQUEST = Request("r1", "camera-A", "2026-10-03T10:00:00Z", "2026-10-03T12:00:00Z", "party-A", "party-B")
SCENARIOS = ("plan_is_not_commitment", "overlap_rejected", "adjacent_allowed",
             "cancel_retry_no_reoccupy", "failed_retry_stays_failed", "separate_roles",
             "old_rate_pinned", "changed_id_payload_rejected")
EXPECTED = {
    "flat": [False, True, True, False, False, False, False, False],
    "semantic": [True, True, True, False, False, True, True, False],
    "bounded": [True] * 8,
}


def evaluate(candidate):
    results = {}
    model = candidate()
    model.plan(replace(REQUEST, id="proposal"))
    results["plan_is_not_commitment"] = model.reserve(REQUEST) == "CONFIRMED" and len(model.active) == 1
    model = candidate()
    model.reserve(REQUEST)
    results["overlap_rejected"] = model.reserve(replace(REQUEST, id="r2")) == "OVERLAP_REJECTED"
    results["adjacent_allowed"] = model.reserve(replace(REQUEST, id="r3", start=REQUEST.end, end="2026-10-03T13:00:00Z")) == "CONFIRMED"
    model = candidate()
    model.reserve(REQUEST)
    model.cancel(REQUEST.id)
    replay = model.reserve(REQUEST)
    results["cancel_retry_no_reoccupy"] = replay == "CONFIRMED" and not model.active
    model = candidate()
    model.reserve(REQUEST)
    failed = replace(REQUEST, id="failed")
    assert model.reserve(failed) == "OVERLAP_REJECTED"
    model.cancel(REQUEST.id)
    results["failed_retry_stays_failed"] = model.reserve(failed) == "OVERLAP_REJECTED" and not model.active
    model = candidate()
    model.reserve(REQUEST)
    results["separate_roles"] = model.roles(REQUEST) == {"requester": "party-A", "payer": "party-B"}
    before = model.price(REQUEST)
    model.catalog = Rate("v2", Decimal("15.00"))
    after = model.price(REQUEST)
    new = replace(REQUEST, id="new", equipment="camera-B")
    model.reserve(new)
    new_price = model.price(new)
    results["old_rate_pinned"] = (before, after, new_price) == (Decimal("20"), Decimal("20"), Decimal("30"))
    model.cancel(REQUEST.id)
    try:
        model.reserve(replace(REQUEST, equipment="camera-B"))
        results["changed_id_payload_rejected"] = False
    except ValueError:
        results["changed_id_payload_rejected"] = True
    return results, {"before": str(before), "old_after_change": str(after), "new_after_change": str(new_price)}


def main():
    report = {"scope": "sequential synthetic candidates; not method certification", "candidates": {}}
    for name, candidate in (("flat", Flat), ("semantic", Semantic), ("bounded", Bounded)):
        results, change = evaluate(candidate)
        assert list(results) == list(SCENARIOS)
        assert list(results.values()) == EXPECTED[name], (name, results)
        report["candidates"][name] = {"scenarios": results, "catalog_change": change}
    features = {
        "F01-confirm-rental": list(SCENARIOS[:3]),
        "F02-cancel-and-replay": list(SCENARIOS[3:5]) + [SCENARIOS[7]],
        "F03-preserve-roles-and-price": list(SCENARIOS[5:7]),
    }
    report["feature_gate"] = {
        candidate: {feature: all(value["scenarios"][scenario] for scenario in scenarios)
                    for feature, scenarios in features.items()}
        for candidate, value in report["candidates"].items()
    }
    assert not all(report["feature_gate"]["flat"].values())
    assert all(report["feature_gate"]["bounded"].values())
    report["features"] = features
    report["checks"] = 26
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if len(sys.argv) > 1:
        selected = sys.argv[1]
        if selected not in report["feature_gate"]:
            raise ValueError("unknown candidate")
        if not all(report["feature_gate"][selected].values()):
            raise SystemExit(1)


if __name__ == "__main__":
    main()
