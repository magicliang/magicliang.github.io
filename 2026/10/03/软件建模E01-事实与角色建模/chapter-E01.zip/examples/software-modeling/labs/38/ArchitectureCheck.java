package rental.architecture;

import com.sun.net.httpserver.HttpServer;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import rental.RentalDesk.RequestId;
import rental.application.ApplicationCheck;
import rental.application.RentalApplication;
import rental.application.RentalApplication.Command;
import rental.application.RentalApplication.Event;
import rental.application.RentalApplication.MemoryRepository;
import rental.application.RentalApplication.Receipt;
import rental.application.RentalApplication.Repository;
import rental.application.RentalApplication.Session;
import rental.application.RentalApplication.Snapshot;
import rental.application.RentalApplication.Status;
import rental.domain.Equipment;
import rental.domain.PricingService;

public final class ArchitectureCheck {
    record View(int active, Map<RequestId, Receipt> receipts, Map<RequestId, BigDecimal> totals) {
        View { receipts = Map.copyOf(receipts); totals = Map.copyOf(totals); }
    }
    interface UseCase {
        Status reserve(Command command, Instant now);
        boolean cancel(RequestId id);
        View view();
    }
    static final class Script implements UseCase {
        private final Map<RequestId, Command> active = new HashMap<>();
        private final Map<RequestId, Receipt> receipts = new HashMap<>();
        private final Map<RequestId, BigDecimal> totals = new HashMap<>();
        @Override public synchronized Status reserve(Command command, Instant now) {
            RequestId id = command.request().requestId();
            Receipt old = receipts.get(id);
            if (old != null) {
                if (!old.command().equals(command)) throw new IllegalArgumentException("changed payload");
                return old.status();
            }
            var equipment = ApplicationCheck.initial().equipment().get(command.request().equipmentId());
            Status status;
            if (equipment == null) status = Status.UNKNOWN_EQUIPMENT;
            else if (equipment.state() != Equipment.State.ACTIVE) status = Status.INELIGIBLE;
            else if (!ApplicationCheck.SPEC.isSatisfiedBy(command.request().period(), now)) status = Status.INVALID_PERIOD;
            else if (active.values().stream().anyMatch(other -> other.request().equipmentId().equals(command.request().equipmentId())
                    && other.request().period().overlaps(command.request().period()))) status = Status.OVERLAP_REJECTED;
            else status = Status.CONFIRMED;
            if (status == Status.CONFIRMED) {
                BigDecimal total = new PricingService().quote(command.request().period(), command.rate()).amount();
                active.put(id, command);
                totals.put(id, total);
            }
            receipts.put(id, new Receipt(command, status));
            return status;
        }
        @Override public synchronized boolean cancel(RequestId id) { return active.remove(id) != null; }
        @Override public synchronized View view() { return new View(active.size(), receipts, totals); }
    }
    static final class Domain implements UseCase {
        private final MemoryRepository memory = new MemoryRepository(ApplicationCheck.initial(), ApplicationCheck.NONE);
        private final RentalApplication application;
        private final List<String> trace;
        Domain(List<String> trace) {
            this.trace = trace;
            Repository logged = new Repository() {
                @Override public Snapshot read() { return memory.read(); }
                @Override public <T> T transact(Function<Session, T> operation) {
                    trace.add("repository.begin");
                    T result = memory.transact(operation);
                    trace.add("repository.commit");
                    return result;
                }
            };
            application = new RentalApplication(logged, id -> {
                trace.add("maintenance.read");
                return RentalApplication.Maintenance.RELEASED;
            }, event -> trace.add("publisher." + event.kind()), ApplicationCheck.NONE,
                    new RentalApplication.InlineAdmission(), ApplicationCheck.SPEC);
        }
        @Override public Status reserve(Command command, Instant now) {
            trace.add("application.reserve");
            return application.reserve(command, now);
        }
        @Override public boolean cancel(RequestId id) { return application.cancel(id); }
        @Override public View view() {
            Snapshot state = memory.read();
            Map<RequestId, BigDecimal> totals = new HashMap<>();
            state.contracts().forEach((id, contract) -> totals.put(id, contract.total().amount()));
            return new View((int) state.calendar().receipts().stream().filter(rental.domain.ReservationCalendar.Receipt::active).count(),
                    state.receipts(), totals);
        }
    }
    static final class Module implements UseCase {
        private final UseCase delegate;
        private final List<String> trace;
        Module(UseCase delegate, List<String> trace) { this.delegate = delegate; this.trace = trace; }
        @Override public Status reserve(Command command, Instant now) {
            trace.add("module.reserve");
            return delegate.reserve(command, now);
        }
        @Override public boolean cancel(RequestId id) { return delegate.cancel(id); }
        @Override public View view() { return delegate.view(); }
        Status submit(String requestId) {
            if (!requestId.matches("[a-z0-9-]{1,30}")) throw new IllegalArgumentException("invalid id");
            trace.add("module.translate");
            return reserve(ApplicationCheck.command(requestId, "E1", 7200, 10800), ApplicationCheck.NOW);
        }
    }
    private static int checks;
    private static void check(boolean value, String label) {
        if (!value) throw new AssertionError(label);
        checks++;
        System.out.println("PASS " + label);
    }
    static List<Object> scenario(UseCase useCase) {
        List<Object> results = new ArrayList<>();
        Command first = ApplicationCheck.command("r1", "E1", 7200, 10800);
        Command overlapping = ApplicationCheck.command("r2", "E1", 9000, 12000);
        results.add(useCase.reserve(first, ApplicationCheck.NOW));
        results.add(useCase.reserve(overlapping, ApplicationCheck.NOW));
        results.add(useCase.reserve(ApplicationCheck.command("adjacent", "E1", 10800, 14400), ApplicationCheck.NOW));
        results.add(useCase.cancel(first.request().requestId()));
        results.add(useCase.reserve(first, ApplicationCheck.NOW.plusSeconds(99999)));
        results.add(useCase.reserve(overlapping, ApplicationCheck.NOW));
        results.add(useCase.reserve(ApplicationCheck.command("unknown", "E9", 7200, 10800), ApplicationCheck.NOW));
        results.add(useCase.reserve(ApplicationCheck.command("soon", "E1", 1, 10), ApplicationCheck.NOW));
        try {
            useCase.reserve(ApplicationCheck.command("r1", "E2", 7200, 10800), ApplicationCheck.NOW);
            throw new AssertionError("changed identity accepted");
        } catch (IllegalArgumentException expected) { results.add("PAYLOAD_REJECTED"); }
        results.add(useCase.view());
        return results;
    }
    public static void main(String[] args) throws Exception {
        List<Object> script = scenario(new Script());
        List<Object> domain = scenario(new Domain(new ArrayList<>()));
        List<Object> module = scenario(new Module(new Domain(new ArrayList<>()), new ArrayList<>()));
        check(script.equals(domain), "script and domain same nine operations plus retained state");
        check(module.equals(domain), "module wrapper preserves observations");
        check(domain.subList(0, 9).equals(List.of(Status.CONFIRMED, Status.OVERLAP_REJECTED, Status.CONFIRMED,
                true, Status.CONFIRMED, Status.OVERLAP_REJECTED, Status.UNKNOWN_EQUIPMENT, Status.INVALID_PERIOD, "PAYLOAD_REJECTED")),
                "expected baseline operation sequence");
        check(((View) domain.get(9)).active() == 1, "only adjacent commitment remains");
        List<String> trace = new java.util.concurrent.CopyOnWriteArrayList<>();
        Module endpoint = new Module(new Domain(trace), trace);
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/reserve", exchange -> {
            trace.add("http.request");
            int status = 200;
            String response;
            try {
                if (!exchange.getRequestMethod().equals("POST")) throw new IllegalArgumentException("POST required");
                response = endpoint.submit(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8)).name();
            } catch (IllegalArgumentException failure) {
                status = 400;
                response = "INVALID_INPUT";
            }
            byte[] body = response.getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(status, body.length);
            exchange.getResponseBody().write(body);
            exchange.close();
            trace.add("http.response");
        });
        server.start();
        try (HttpClient client = HttpClient.newHttpClient()) {
            URI uri = URI.create("http://127.0.0.1:" + server.getAddress().getPort() + "/reserve");
            HttpRequest request = HttpRequest.newBuilder(uri).POST(HttpRequest.BodyPublishers.ofString("http-r1")).build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            check(response.statusCode() == 200 && response.body().equals("CONFIRMED"), "real loopback POST returns confirmed");
            check(endpoint.view().active() == 1, "HTTP call changes real 27-v1 repository");
            HttpResponse<String> replay = client.send(request, HttpResponse.BodyHandlers.ofString());
            check(replay.body().equals("CONFIRMED") && endpoint.view().active() == 1, "HTTP replay does not duplicate");
            View before = endpoint.view();
            HttpResponse<String> bad = client.send(HttpRequest.newBuilder(uri).POST(HttpRequest.BodyPublishers.ofString("!")).build(),
                    HttpResponse.BodyHandlers.ofString());
            check(bad.statusCode() == 400 && endpoint.view().equals(before), "bad transport input leaves domain unchanged");
            check(trace.stream().filter(s -> s.equals("publisher.ReservationConfirmed")).count() == 1, "only actual transition published");
            check(trace.indexOf("repository.commit") < trace.indexOf("publisher.ReservationConfirmed"), "observed commit precedes publish");
            System.out.println("DEPLOYMENT loopback=" + uri + " client-and-server=same-JVM storage=memory maintenance=in-process");
            System.out.println("TRACE " + trace);
        } finally { server.stop(0); }
        if (args.length > 0) new Module(new Domain(new ArrayList<>()), new ArrayList<>()).submit("!");
        System.out.println("RESULT chapter38 checks=" + checks);
    }
}
