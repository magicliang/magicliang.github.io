import static org.junit.Assert.*;
import static play.test.Helpers.*;
import java.nio.file.Files;
import org.junit.Test;
import play.inject.guice.GuiceApplicationBuilder;
import play.libs.Json;
import play.mvc.Http;
public final class BackendTest {
    @Test public void jsonParserAndFiniteBody() throws Exception {
        var dir=Files.createTempDirectory("backend-test");
        var app=new GuiceApplicationBuilder().configure("lab.workdir",dir.toString()).build();
        running(app,()->{
            var json=route(app,new Http.RequestBuilder().method("POST").uri("/json").bodyJson(Json.parse("{\"a\":1}")));
            assertEquals(200,json.status());
            assertEquals("{\"a\":1}",contentAsString(json));
            var stream=route(app,new Http.RequestBuilder().uri("/data?id=test&chunks=2&known=true"));
            assertEquals(32768,contentAsBytes(stream,app.asScala().materializer()).length());
        });
        assertEquals("stop-hook\n",Files.readString(dir.resolve("journal")));
        Files.delete(dir.resolve("journal")); Files.delete(dir);
    }
    @Test public void invalidFiniteInputRejected() {
        var app=new GuiceApplicationBuilder().build();
        running(app,()->assertEquals(400,route(app,new Http.RequestBuilder().uri("/data?id=bad&chunks=0")).status()));
    }
}
