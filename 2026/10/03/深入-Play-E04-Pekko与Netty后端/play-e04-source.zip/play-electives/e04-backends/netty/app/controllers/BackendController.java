package controllers;
import com.typesafe.config.Config;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.time.Duration;
import java.util.Optional;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.pekko.actor.ActorSystem;
import org.apache.pekko.stream.javadsl.Flow;
import org.apache.pekko.stream.javadsl.Source;
import org.apache.pekko.util.ByteString;
import play.api.mvc.request.RequestAttrKey;
import play.http.HttpEntity;
import play.inject.ApplicationLifecycle;
import play.libs.F;
import play.libs.Json;
import play.mvc.*;
@Singleton
public final class BackendController extends Controller {
    private final Config config;
    private final ActorSystem system;
    private final ConcurrentHashMap<String, Entry> entries = new ConcurrentHashMap<>();
    private final Path directory;
    @Inject public BackendController(Config config, ActorSystem system, ApplicationLifecycle lifecycle) {
        this.config=config; this.system=system;
        try { directory=Files.createDirectories(Path.of(config.getString("lab.workdir"))); }
        catch (Exception error) { throw new IllegalStateException(error); }
        lifecycle.addStopHook(() -> {
            for (Entry e: entries.values()) e.close(null);
            event("stop-hook");
            return CompletableFuture.completedFuture(null);
        });
    }
    private void event(String value) {
        try { Files.writeString(directory.resolve("journal"), value+"\n", StandardOpenOption.CREATE, StandardOpenOption.APPEND); }
        catch (Exception error) { throw new IllegalStateException(error); }
    }
    private final class Entry {
        final AtomicInteger produced=new AtomicInteger();
        final FileChannel file;
        final Path path;
        volatile boolean closed;
        volatile String failure="";
        Entry(String id) throws Exception {
            path=directory.resolve(id+".resource");
            file=FileChannel.open(path,StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE);
        }
        synchronized void close(Throwable error) {
            if (closed) return;
            if (error!=null) failure=error.getClass().getSimpleName();
            try { file.close(); Files.deleteIfExists(path); closed=true; }
            catch (Exception cleanup) { throw new IllegalStateException(cleanup); }
        }
    }
    private synchronized Entry open(String id) {
        if (!id.matches("[a-z0-9_]{1,32}") || entries.containsKey(id) || entries.size()>=32) throw new IllegalArgumentException("finite unique id required");
        try { Entry e=new Entry(id); entries.put(id,e); return e; }
        catch (Exception error) { throw new IllegalStateException(error); }
    }
    public Result health(Http.Request request) {
        return ok(Json.newObject().put("provider",config.getString("play.server.provider"))
                .put("serverAttribute",request.attrs().getOptional(RequestAttrKey.Server().asJava()).orElse("absent"))
                .put("classOrigin",getClass().getProtectionDomain().getCodeSource().getLocation().toString()));
    }
    @BodyParser.Of(BodyParser.Json.class)
    public Result json(Http.Request request) { return ok(request.body().asJson()); }
    public Result state(String id) {
        Entry e=entries.get(id); if(e==null) return notFound();
        return ok(Json.newObject().put("produced",e.produced.get()).put("closed",e.closed).put("fileOpen",e.file.isOpen()).put("fileExists",Files.exists(e.path)).put("failure",e.failure));
    }
    public Result data(String id, int chunks, boolean known, int failAt, boolean chunked) {
        if (chunks<1 || chunks>128) return badRequest();
        Entry e=open(id);
        Source<ByteString,?> source=Source.range(0,chunks-1).throttle(1,Duration.ofMillis(30)).map(i -> {
            if(i==failAt) throw new IllegalStateException("synthetic-stream-failure");
            e.produced.incrementAndGet(); return ByteString.fromArray(new byte[16384]);
        }).watchTermination((mat,done)->{done.whenComplete((v,x)->e.close(x));return mat;});
        if (chunked) return ok().chunked(source).as("application/octet-stream");
        return ok().sendEntity(new HttpEntity.Streamed(source,known?Optional.of(chunks*16384L):Optional.empty(),Optional.of("application/octet-stream")));
    }
    public Result sse(String id) {
        Entry e=open(id);
        Source<ByteString,?> source=Source.range(1,40).throttle(1,Duration.ofMillis(40)).map(i -> {
            e.produced.incrementAndGet(); return ByteString.fromString("id: "+i+"\ndata: value-"+i+"\n\n");
        }).watchTermination((mat,done)->{done.whenComplete((v,x)->e.close(x));return mat;});
        return ok().chunked(source).as("text/event-stream");
    }
    public WebSocket ws(String id) {
        return WebSocket.Text.acceptOrResult(request -> {
            if(!"http://localhost".equals(request.header("Origin").orElse(""))) return CompletableFuture.completedFuture(F.Either.Left(forbidden()));
            Entry e=open(id);
            Flow<String,String,?> flow=Flow.of(String.class).map(text->{e.produced.incrementAndGet();return "echo:"+text;})
                    .completionTimeout(Duration.ofSeconds(8)).watchTermination((mat,done)->{done.whenComplete((v,x)->e.close(x));return mat;});
            return CompletableFuture.completedFuture(F.Either.Right(flow));
        });
    }
    public CompletionStage<Result> work() {
        CompletableFuture<Result> result=new CompletableFuture<>();
        event("work-start");
        system.scheduler().scheduleOnce(Duration.ofMillis(800),()->{event("work-complete");result.complete(ok("completed"));},system.dispatcher());
        return result;
    }
}
