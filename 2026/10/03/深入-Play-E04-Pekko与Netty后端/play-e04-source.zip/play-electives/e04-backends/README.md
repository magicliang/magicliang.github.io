# E04: Play 3.0.6 backend comparison

Two standalone projects use byte-identical controller, routes, parser configuration and JUnit tests. Only the server plugin and application name differ. Requires Python 3 and JDK 21. Set JAVA_HOME to your own JDK installation.

Download the fixed sbt launcher from Maven Central:

```sh
mkdir -p .tools
curl -fL https://repo.maven.apache.org/maven2/org/scala-sbt/sbt-launch/1.10.7/sbt-launch-1.10.7.jar -o .tools/sbt-launch-1.10.7.jar
shasum -a 256 .tools/sbt-launch-1.10.7.jar
export PLAY_LAB_SBT_LAUNCHER="$PWD/.tools/sbt-launch-1.10.7.jar"
python3 build_checks.py --evidence evidence/build
python3 http_checks.py --evidence evidence/run
```

Expected launcher SHA-256: `3cca02818047327a83efde776103a1ef92f76f72c062badbbb062499a3270c07`. The run directory must not already exist. Build logs record clean/test/stage; HTTP checks run the resulting production scripts with a generated ephemeral secret, ephemeral loopback ports and owned work directories. Both JVMs are stopped even on assertion failure. No database or container is required.

The finite matrix checks selected provider and actual request attribute; JSON success/malformed/type/size errors; known, unknown and explicitly chunked streams; TCP cancellation; upstream failure after HTTP headers; SSE cancellation; rejected Origin; masked WebSocket echo and Close 1000; an unmasked protocol violation; and SIGTERM during an 800 ms asynchronous request. It verifies actual FileChannel closure, deletion and a stop-hook journal.

The expected differences are intentional. In this fixed configuration Pekko returns Close 1002 for the invalid frame, while Netty closes TCP without a Close frame. Pekko finishes the in-flight HTTP response before shutdown; Netty closes the client connection although the scheduled business callback and lifecycle hook both run. A passing matrix preserves those observations rather than claiming interchangeable transport behavior.

The test is local HTTP/1.1, not a throughput, TLS, HTTP/2, reverse-proxy or cluster benchmark. Stream element counts after cancellation depend on bounded buffering and scheduling. Evidence historical failures remain alongside the final run in the article delivery.

