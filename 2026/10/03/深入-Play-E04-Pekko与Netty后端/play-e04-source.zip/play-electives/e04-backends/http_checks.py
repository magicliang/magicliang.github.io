import argparse
import base64
import concurrent.futures
import hashlib
import http.client
import json
import os
from pathlib import Path
import secrets
import socket
import struct
import subprocess
import time


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--evidence',type=Path,required=True)
    args=parser.parse_args()
    evidence=args.evidence.resolve(); evidence.mkdir(parents=True,exist_ok=False)
    root=Path(__file__).resolve().parent
    java_home=os.environ['JAVA_HOME']
    records=[]; servers=[]; summary={'status':'FAIL'}

    def exact(sock,n):
        data=bytearray()
        while len(data)<n:
            part=sock.recv(n-len(data))
            if not part: raise EOFError('TCP closed')
            data.extend(part)
        return bytes(data)

    def send_frame(sock,data,opcode=1,masked=True):
        data=data.encode() if isinstance(data,str) else data
        assert len(data)<126
        header=bytes([128|opcode,(128 if masked else 0)|len(data)])
        mask=b'lab!'
        sock.sendall(header+(mask+bytes(b^mask[i%4] for i,b in enumerate(data)) if masked else data))

    def recv_frame(sock):
        a,b=exact(sock,2); size=b&127
        if size==126: size=struct.unpack('!H',exact(sock,2))[0]
        if size==127: size=struct.unpack('!Q',exact(sock,8))[0]
        assert size<65536 and not b&128
        return a&15,exact(sock,size)

    class Server:
        def __init__(self,kind):
            self.kind=kind
            with socket.socket() as s: s.bind(('127.0.0.1',0)); self.port=s.getsockname()[1]
            self.directory=evidence/kind; self.directory.mkdir()
            self.resources=self.directory/'resources'
            self.log=(self.directory/'server.log').open('w')
            stage=root/kind/'target/universal/stage'
            script=next(p for p in (stage/'bin').iterdir() if not p.name.endswith('.bat'))
            cmd=['bash',str(script),'-J-Xms64m','-J-Xmx256m','-Dhttp.address=127.0.0.1','-Dhttp.port='+str(self.port),'-Dpidfile.path='+str(self.directory/'running.pid'),'-Dlab.workdir='+str(self.resources)]
            self.process=subprocess.Popen(cmd,cwd=stage,env={**os.environ,'JAVA_HOME':java_home,'APPLICATION_SECRET':secrets.token_hex(32)},stdout=self.log,stderr=subprocess.STDOUT)
            servers.append(self)
            deadline=time.monotonic()+40
            while time.monotonic()<deadline:
                assert self.process.poll() is None, kind+' failed to start'
                try:
                    status,_,body=self.get('/health')
                    if status==200: break
                except (OSError,http.client.HTTPException): pass
                time.sleep(.02)
            else: raise AssertionError('startup timeout')
            state=json.loads(body)
            expected='NettyServerProvider' if kind=='netty' else 'PekkoHttpServerProvider'
            assert state['provider'].endswith(expected) and str(stage) in state['classOrigin']
            assert state['serverAttribute']==('netty' if kind=='netty' else 'absent')
            self.record('startup',**state)

        def record(self,name,**data): records.append({'backend':self.kind,'scenario':name,**data})
        def connection(self): return http.client.HTTPConnection('127.0.0.1',self.port,timeout=10)
        def get(self,path,method='GET',body=None,headers=None):
            c=self.connection()
            try:
                c.request(method,path,body=body,headers=headers or {})
                r=c.getresponse(); return r.status,{k.lower():v for k,v in r.getheaders()},r.read()
            finally: c.close()
        def terminal(self,id):
            deadline=time.monotonic()+8
            while time.monotonic()<deadline:
                status,_,body=self.get('/state?id='+id)
                value=json.loads(body) if status==200 else {}
                if value.get('closed'):
                    assert not value['fileOpen'] and not value['fileExists']
                    return value
                time.sleep(.03)
            raise AssertionError(('stream not terminal',id,value))
        def handshake(self,id,origin='http://localhost'):
            sock=socket.create_connection(('127.0.0.1',self.port),timeout=10)
            key=base64.b64encode(b'0123456789abcdef').decode()
            sock.sendall((f'GET /ws?id={id} HTTP/1.1\r\nHost: localhost\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\nOrigin: {origin}\r\n\r\n').encode())
            data=bytearray()
            while not data.endswith(b'\r\n\r\n'):
                data.extend(exact(sock,1)); assert len(data)<16384
            code=int(data.split(b' ')[1])
            if code==101:
                accept=base64.b64encode(hashlib.sha1((key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest())
                assert accept.lower() in bytes(data).lower()
            return sock,code
        def stop(self):
            if self.process.poll() is None:
                start=time.monotonic(); self.process.terminate()
                try: code=self.process.wait(timeout=12)
                except BaseException:
                    self.process.kill(); self.process.wait(timeout=5); raise
                assert code in (143,-15)
                self.record('exit',code=code,seconds=time.monotonic()-start)
            self.log.close()
            with socket.socket() as s: assert s.connect_ex(('127.0.0.1',self.port))!=0

    try:
        for name in ['app/controllers/BackendController.java','conf/routes','conf/application.conf','test/BackendTest.java']:
            assert (root/'pekko'/name).read_bytes()==(root/'netty'/name).read_bytes()
        artifacts={}
        for kind in ['pekko','netty']:
            jars=sorted((root/kind/'target/universal/stage/lib').glob('*.jar'))
            artifacts[kind]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in jars}
            assert any(('play-netty-server' if kind=='netty' else 'play-pekko-http-server') in p.name for p in jars)
            assert not any(('play-pekko-http-server' if kind=='netty' else 'play-netty-server') in p.name for p in jars)
        (evidence/'artifacts.json').write_text(json.dumps(artifacts,indent=2))
        for kind in ['pekko','netty']:
            s=Server(kind)
            for name,payload,content,expected in [('valid','{"a":1}','application/json',200),('syntax','{','application/json',400),('type','x','text/plain',415),('size','{"s":"'+'x'*2048+'"}','application/json',413)]:
                status,headers,body=s.get('/json','POST',payload,{'Content-Type':content})
                assert status==expected,(kind,name,status)
                s.record('json-'+name,status=status,bytes=len(body))
            for known,chunked in [(True,False),(False,False),(False,True)]:
                id='full_'+str(known).lower()+'_'+str(chunked).lower()
                status,headers,body=s.get('/data?id='+id+'&chunks=4&known='+str(known).lower()+'&chunked='+str(chunked).lower())
                assert status==200 and body==bytes(65536)
                assert headers.get('content-length')==('65536' if known else None)
                if chunked: assert headers.get('transfer-encoding')=='chunked'
                s.record('complete-stream',known=known,chunked=chunked,status=status,headers=headers,sha256=hashlib.sha256(body).hexdigest(),terminal=s.terminal(id))
            for known,chunked in [(True,False),(False,False),(False,True)]:
                id='cancel_'+str(known).lower()+'_'+str(chunked).lower(); c=s.connection()
                c.request('GET','/data?id='+id+'&known='+str(known).lower()+'&chunked='+str(chunked).lower()); r=c.getresponse()
                assert len(r.read(16384))==16384
                r.close(); c.close(); terminal=s.terminal(id)
                assert terminal['produced']<128
                s.record('tcp-cancel',known=known,chunked=chunked,readBytes=16384,terminal=terminal)
            c=s.connection(); c.request('GET','/data?id=fail&chunks=10&known=true&failAt=3'); r=c.getresponse(); error=None
            try: r.read()
            except (http.client.IncompleteRead,OSError) as ex: error=type(ex).__name__
            finally: r.close(); c.close()
            assert r.status==200 and error
            s.record('upstream-failure',status=r.status,readError=error,terminal=s.terminal('fail'))
            c=s.connection(); c.request('GET','/sse?id=sse'); r=c.getresponse(); lines=[]
            while len([x for x in lines if x.startswith('id:')])<3:
                line=r.readline().decode().strip(); assert line or lines; lines.append(line)
            assert [x for x in lines if x.startswith('id:')]==['id: 1','id: 2','id: 3']
            assert r.getheader('Content-Type').startswith('text/event-stream')
            r.close(); c.close(); s.record('sse-cancel',ids=[1,2,3],terminal=s.terminal('sse'))
            sock,code=s.handshake('rejected','http://untrusted.invalid'); sock.close(); assert code==403
            assert s.get('/state?id=rejected')[0]==404
            s.record('ws-origin-rejected',status=code,allocated=False)
            sock,code=s.handshake('ws'); assert code==101
            try:
                send_frame(sock,'hello'); opcode,body=recv_frame(sock); assert opcode==1 and body==b'echo:hello'
                send_frame(sock,struct.pack('!H',1000),8); opcode,body=recv_frame(sock)
                assert opcode==8 and len(body)>=2; close=struct.unpack('!H',body[:2])[0]; assert close==1000
            finally: sock.close()
            s.record('ws-normal-close',handshake=code,closeCode=close,terminal=s.terminal('ws'))
            sock,code=s.handshake('protocol'); assert code==101
            close=None; protocol_error=None
            try:
                send_frame(sock,'invalid',masked=False); opcode,body=recv_frame(sock)
                assert opcode==8 and len(body)>=2; close=struct.unpack('!H',body[:2])[0]; assert close==1002
            except EOFError as error: protocol_error=type(error).__name__
            finally: sock.close()
            assert (close==1002 and protocol_error is None) if kind=='pekko' else (close is None and protocol_error=='EOFError')
            s.record('ws-unmasked-protocol-error',closeCode=close,clientError=protocol_error,terminal=s.terminal('protocol'))
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                pending=pool.submit(s.get,'/work'); journal=s.resources/'journal'
                deadline=time.monotonic()+3
                while time.monotonic()<deadline and (not journal.exists() or 'work-start' not in journal.read_text()): time.sleep(.01)
                assert 'work-start' in journal.read_text()
                s.stop(); status=None; body=b''; client_error=None
                try: status,_,body=pending.result(timeout=2)
                except (OSError,http.client.HTTPException) as error: client_error=type(error).__name__
                if kind=='pekko': assert status==200 and body==b'completed' and client_error is None
                else: assert status is None and client_error is not None
                events=journal.read_text().splitlines()
                assert events==['work-start','work-complete','stop-hook'] and not list(s.resources.glob('*.resource'))
                s.record('sigterm-inflight',status=status,body=body.decode(),clientError=client_error,events=events,remainingResourceFiles=0,listenerClosed=True)
        summary.update(status='PASS',scenarios=len(records))
    finally:
        errors=[]
        for server in servers:
            try: server.stop()
            except BaseException as error: errors.append(repr(error))
        if errors: summary.update(status='FAIL',cleanupErrors=errors)
        for name,data in [('summary.json',summary),('observations.json',records)]: (evidence/name).write_text(json.dumps(data,indent=2))
        if errors: raise RuntimeError(errors)
    print(json.dumps(summary))


if __name__=='__main__': main()
