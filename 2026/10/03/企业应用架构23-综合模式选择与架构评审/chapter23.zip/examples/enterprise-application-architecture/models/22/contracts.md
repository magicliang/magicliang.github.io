# 22 业务契约与质量情景

- backfill-process-exit:真实退出73
- checkpoint-restart-idempotent:检查点2
- difference-report:2项一分钱差异
- shadow-no-effects:计数不变
- dispatch:A:new/B:old/A:old
- rollback-preserves-committed-data:375/450,effects=3

输入为合成数据。场景刺激、响应、度量对应上述原始断言；没有性能SLO测量。SQLite单文件，兼容改造后的旧写入，只有CNY；effects为本地持久记录。真实网关、并发回填、外部副作用、跨机迁移NOT_RUN。


Repair regression: idempotency-payload-conflict rejects target3 amount350 and target1 amount351; conflict-no-effects=PASS original=350 other=175 effects=2; rollback remains375/450 effects3. Captured in normal.stdout.txt.
