# Sources 22

2026-10-03已读取官方/原作者页面；网页只支持模式/API背景，实测数字由源码日志支撑。

- https://martinfowler.com/bliki/StranglerFigApplication.html
- https://martinfowler.com/bliki/BranchByAbstraction.html
- https://www.sqlite.org/lang_transaction.html

在线文档滚动更新。具体Python、SQLite构建见environment.txt；H2固定2.1.214。
