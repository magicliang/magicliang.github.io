# 22 RUN

2026-10-03 独立场景 VERIFIED_LOCAL；累计门槛待root集成，不表示所有章验收已完成。

命令：`bash examples/enterprise-application-architecture/labs/22/run.sh`。实际调用与退出码见normal.command.json、normal.exit.txt；环境见environment.txt，源码散列source-sha256.json，输入inputs.json。

| 场景/二值可观察量 | 产物 |
|---|---|
| backfill-process-exit:真实退出73 | normal.stdout.txt |
| checkpoint-restart-idempotent:检查点2 | normal.stdout.txt |
| difference-report:2项一分钱差异 | normal.stdout.txt |
| shadow-no-effects:计数不变 | normal.stdout.txt |
| dispatch:A:new/B:old/A:old | normal.stdout.txt |
| rollback-preserves-committed-data:375/450,effects=3 | normal.stdout.txt |


正常退出0。stderr空仅代表无异常，不作成功证据。SQLite单文件，兼容改造后的旧写入，只有CNY；effects为本地持久记录。真实网关、并发回填、外部副作用、跨机迁移NOT_RUN。



Repair regression: idempotency-payload-conflict rejects target3 amount350 and target1 amount351; conflict-no-effects=PASS original=350 other=175 effects=2; rollback remains375/450 effects3. Captured in normal.stdout.txt.
