# 23 RUN

2026-10-03 独立场景 VERIFIED_LOCAL；累计门槛待root集成，不表示所有章验收已完成。

命令：`bash examples/enterprise-application-architecture/labs/23/run.sh`。实际调用与退出码见normal.command.json、normal.exit.txt；环境见environment.txt，源码散列source-sha256.json，输入inputs.json。

| 场景/二值可观察量 | 产物 |
|---|---|
| commit-before-publish-crash:退出74 | normal.stdout.txt |
| 并发重复:独立连接Barrier,refunded=300 | normal.stdout.txt |
| 越权/超额/同键异额拒绝 | normal.stdout.txt |
| 接收方提交确认前退出75 | normal.stdout.txt |
| recovery-and-no-invalid-effects:300/300/pending=0/B=0 | normal.stdout.txt |

额外命令：同入口加 --mutant-no-idempotency，预期退出1且observed-refunded=900，stderr含duplicate-refund，原始文件mutant-no-idempotency.{stdout,stderr,exit}.txt。加 --with-facade 预期退出0并经过全套故障恢复，产物with-facade.{stdout,stderr,exit}.txt。

正常退出0。stderr空仅代表无异常，不作成功证据。两SQLite文件、本地投递、真实进程退出。真实支付、broker、公网、页面和灾难恢复NOT_RUN。00–23累计回归待root集成。
