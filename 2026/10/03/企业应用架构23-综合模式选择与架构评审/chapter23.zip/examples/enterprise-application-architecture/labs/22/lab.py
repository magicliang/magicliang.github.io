import json
import os
import pathlib
import sqlite3
import subprocess
import sys
import tempfile


def connect(path):
    c = sqlite3.connect(path)
    c.set_trace_callback(lambda sql: print("SQL " + sql, flush=True))
    return c


def backfill(path, crash=False):
    with connect(path) as c:
        last = c.execute("select last_id from checkpoint").fetchone()[0]
        for ident, amount in c.execute("select id, cents from contracts where id>? order by id", (last,)).fetchall():
            c.execute("update contracts set amount_minor=?, currency='CNY' where id=?", (amount, ident))
            c.execute("update checkpoint set last_id=?", (ident,))
            c.commit()
            print("checkpoint=" + str(ident), flush=True)
            if crash:
                os._exit(73)


def read(c, version, ident, mutant=False):
    columns = "cents, 'CNY'" if version == "old" else "coalesce(amount_minor,cents), coalesce(currency,'CNY')"
    amount, currency = c.execute("select " + columns + " from contracts where id=?", (ident,)).fetchone()
    return (amount + (1 if mutant else 0), currency)


def write(c, tenant, ident, amount, key):
    if c.execute("select tenant from contracts where id=?", (ident,)).fetchone()[0] != tenant:
        raise ValueError("tenant mismatch")
    existing = c.execute("select contract_id, amount from effects where tenant=? and key=?", (tenant, key)).fetchone()
    if existing:
        if existing != (ident, amount):
            raise ValueError("conflicting retry")
        return
    with c:
        version = c.execute("select version from route where tenant=?", (tenant,)).fetchone()[0]
        print("dispatch=" + tenant + ":" + version)
        if version == "old":
            c.execute("update contracts set cents=?,amount_minor=?,currency='CNY' where id=?", (amount, amount, ident))
        elif version == "new":
            c.execute("update contracts set amount_minor=?,currency='CNY',cents=? where id=?", (amount, amount, ident))
        else:
            raise ValueError("unknown route")
        c.execute("insert into effects values(?,?,?,?)", (tenant, key, ident, amount))


def main():
    if len(sys.argv) > 1:
        backfill(sys.argv[1], len(sys.argv) > 2)
        return
    with tempfile.TemporaryDirectory() as tmp:
        path = pathlib.Path(tmp) / "migration.sqlite"
        with connect(path) as c:
            c.executescript("CREATE TABLE contracts(id integer primary key,tenant text,cents integer,amount_minor integer,currency text);CREATE TABLE checkpoint(last_id integer);INSERT INTO checkpoint VALUES(0);CREATE TABLE effects(tenant text,key text,contract_id integer,amount integer,primary key(tenant,key));CREATE TABLE route(tenant text primary key,version text);INSERT INTO route VALUES('A','old'),('B','old');INSERT INTO contracts VALUES(1,'A',100,NULL,NULL),(2,'B',200,NULL,NULL);")
        killed = subprocess.run([sys.executable, __file__, str(path), "crash"])
        assert killed.returncode == 73
        print("backfill-process-exit=PASS exit=73")
        subprocess.run([sys.executable, __file__, str(path)], check=True)
        subprocess.run([sys.executable, __file__, str(path)], check=True)
        with connect(path) as c:
            assert c.execute("select last_id from checkpoint").fetchone()[0] == 2
            print("checkpoint-restart-idempotent=PASS")
            before = c.execute("select count(*) from effects").fetchone()[0]
            differences = []
            for ident in (1, 2):
                assert read(c, "old", ident) == read(c, "new", ident)
                bad = read(c, "new", ident, mutant=True)
                if bad != read(c, "old", ident):
                    differences.append({"id": ident, "old": read(c, "old", ident), "candidate": bad})
            assert len(differences) == 2
            print("difference-report=" + json.dumps(differences))
            assert c.execute("select count(*) from effects").fetchone()[0] == before
            print("shadow-no-effects=PASS")
            c.execute("update route set version='new' where tenant='A'")
            c.commit()
            assert c.execute("select version from route where tenant='B'").fetchone()[0] == "old"
            for tenant, ident, amount in [("A", 1, 350), ("B", 2, 450)]:
                write(c, tenant, ident, amount, "change-1")
                write(c, tenant, ident, amount, "change-1")
            c.execute("insert into contracts values(3,'A',175,175,'CNY')")
            c.commit()
            before_collision = [read(c, "old", ident) for ident in (1, 3)]
            for ident, amount in [(3, 350), (1, 351)]:
                try:
                    write(c, "A", ident, amount, "change-1")
                except ValueError as failure:
                    assert str(failure) == "conflicting retry"
                    print("idempotency-payload-conflict=PASS target=" + str(ident) + " amount=" + str(amount))
                else:
                    raise AssertionError("changed target or amount accepted")
                assert [read(c, "old", target) for target in (1, 3)] == before_collision
                assert c.execute("select count(*) from effects").fetchone()[0] == 2
            print("conflict-no-effects=PASS original=350 other=175 effects=2")
            c.execute("update route set version='old'")
            c.commit()
            write(c, "A", 1, 375, "after-rollback")
        with connect(path) as restarted:
            assert read(restarted, "old", 1) == read(restarted, "new", 1) == (375, "CNY")
            assert read(restarted, "old", 2) == (450, "CNY")
            assert restarted.execute("select count(*) from effects").fetchone()[0] == 3
            print("rollback-preserves-committed-data=PASS amounts=375,450 effects=3")
        print("PASS chapter22")


if __name__ == "__main__":
    main()
