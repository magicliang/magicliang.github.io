import concurrent.futures
import json
import os
import pathlib
import sqlite3
import subprocess
import sys
import tempfile
import threading


def connect(path):
    c = sqlite3.connect(path, timeout=10)
    c.set_trace_callback(lambda sql: print("SQL " + sql, flush=True))
    return c


def refund(path, actor, tenant, key, cents, mutant=False, crash=False):
    if {"alice": "A", "bob": "B"}.get(actor) != tenant:
        raise ValueError("tenant")
    c = connect(path)
    try:
        c.execute("BEGIN IMMEDIATE")
        old = c.execute("select cents from refunds where tenant=? and key=?", (tenant, key)).fetchone()
        if old and not mutant:
            if old[0] != cents:
                raise ValueError("conflicting idempotency payload")
            c.rollback()
            return
        affected = c.execute("update contracts set refunded=refunded+? where tenant=? and id=1 and refunded+?<=paid", (cents, tenant, cents)).rowcount
        if cents <= 0 or affected != 1:
            raise ValueError("refund bound")
        c.execute("insert or replace into refunds values(?,?,?)", (tenant, key, cents))
        c.execute("insert into outbox(tenant,key,cents) values(?,?,?)", (tenant, key, cents))
        c.commit()
        print("committed refund " + tenant + ":" + key, flush=True)
        if crash:
            os._exit(74)
    finally:
        c.close()


def deliver(source, receiver, crash=False):
    with connect(source) as c:
        rows = c.execute("select id,tenant,key,cents from outbox where sent=0 order by id").fetchall()
    for ident, tenant, key, cents in rows:
        with connect(receiver) as r:
            r.execute("begin immediate")
            inserted = r.execute("insert or ignore into inbox values(?,?,?)", (tenant, key, cents)).rowcount
            if inserted:
                r.execute("update ledger set cents=cents+? where tenant=?", (cents, tenant))
            r.commit()
        if crash:
            print("receiver committed, acknowledgement absent", flush=True)
            os._exit(75)
        with connect(source) as c:
            c.execute("update outbox set sent=1 where id=?", (ident,))


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "refund-crash":
        refund(sys.argv[2], "alice", "A", "r1", 300, crash=True)
        return
    if len(sys.argv) > 1 and sys.argv[1] == "deliver-crash":
        deliver(sys.argv[2], sys.argv[3], crash=True)
        return
    mutant = "--mutant-no-idempotency" in sys.argv
    class RefundFacade:
        def execute(self, *args, **kwargs):
            return refund(*args, **kwargs)
    execute = RefundFacade().execute if "--with-facade" in sys.argv else refund
    print("facade=" + str("--with-facade" in sys.argv))
    with tempfile.TemporaryDirectory() as tmp:
        source, receiver = pathlib.Path(tmp) / "rental.sqlite", pathlib.Path(tmp) / "settlement.sqlite"
        with connect(source) as c:
            c.executescript("CREATE TABLE contracts(tenant text,id integer,paid integer,refunded integer,primary key(tenant,id));INSERT INTO contracts VALUES('A',1,1000,0),('B',1,1000,0);CREATE TABLE refunds(tenant text,key text,cents integer,primary key(tenant,key));CREATE TABLE outbox(id integer primary key,tenant text,key text,cents integer,sent integer default 0);")
        with connect(receiver) as c:
            c.executescript("CREATE TABLE inbox(tenant text,key text,cents integer,primary key(tenant,key));CREATE TABLE ledger(tenant text primary key,cents integer);INSERT INTO ledger VALUES('A',0),('B',0);")
        result = subprocess.run([sys.executable, __file__, "refund-crash", str(source)])
        assert result.returncode == 74
        print("commit-before-publish-crash=PASS exit=74")
        barrier = threading.Barrier(2)
        def retry():
            barrier.wait()
            execute(source, "alice", "A", "r1", 300, mutant=mutant)
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            futures = [pool.submit(retry) for _ in range(2)]
            for f in futures:
                f.result()
        with connect(source) as c:
            amount = c.execute("select refunded from contracts where tenant='A'").fetchone()[0]
            print("observed-refunded=" + str(amount))
            assert amount == 300, "duplicate-refund"
        for actor, tenant, key, cents in [("alice", "B", "x", 100), ("alice", "A", "r2", 800), ("alice", "A", "r1", 301)]:
            try:
                refund(source, actor, tenant, key, cents)
            except ValueError:
                print("rejected=" + json.dumps([actor, tenant, key, cents]))
            else:
                raise AssertionError("invalid refund accepted")
        result = subprocess.run([sys.executable, __file__, "deliver-crash", str(source), str(receiver)])
        assert result.returncode == 75
        deliver(source, receiver)
        deliver(source, receiver)
        with connect(receiver) as c:
            assert c.execute("select cents from ledger where tenant='A'").fetchone()[0] == 300
            assert c.execute("select cents from ledger where tenant='B'").fetchone()[0] == 0
        with connect(source) as c:
            assert c.execute("select count(*) from outbox where sent=0").fetchone()[0] == 0
            assert c.execute("select refunded from contracts where tenant='B'").fetchone()[0] == 0
            assert c.execute("select count(*) from refunds").fetchone()[0] == 1
        print("recovery-and-no-invalid-effects=PASS refunded=300 ledger=300 pending=0 B=0")
        print("PASS chapter23")


if __name__ == "__main__":
    main()
