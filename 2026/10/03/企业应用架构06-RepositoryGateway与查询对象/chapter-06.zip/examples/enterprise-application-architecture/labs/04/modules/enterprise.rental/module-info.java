module enterprise.rental {
    requires rental.legacy;
    requires transitive enterprise.maintenance;
    exports enterprise.rental.api;
}
