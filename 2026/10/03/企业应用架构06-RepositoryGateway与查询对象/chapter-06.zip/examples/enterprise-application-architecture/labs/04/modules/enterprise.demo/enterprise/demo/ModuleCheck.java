package enterprise.demo;

import java.time.Instant;
import enterprise.maintenance.api.RepairApi;
import enterprise.maintenance.api.RepairService;
import enterprise.rental.api.RentalApi;
import enterprise.settlement.api.SettlementView;

public final class ModuleCheck {
    private static int checks;
    private ModuleCheck() { }
    public static void main(String[] args) {
        var now = Instant.parse("2026-10-03T08:00:00Z");
        var start = now.plusSeconds(7200);
        var end = start.plusSeconds(5400);
        var repair = new RepairService();
        repair.report("E1", RepairApi.Result.WORKING);
        var rental = new RentalApi(repair);
        check("repair owner blocks rental", rental.reserve("blocked", "E1", start, end, now).status().equals("MAINTENANCE_RESTRICTED"));
        repair.report("E1", RepairApi.Result.RETURNED_AFTER_PASS);
        check("old rejection remains history", rental.reserve("blocked", "E1", start, end, now).status().equals("MAINTENANCE_RESTRICTED"));
        var confirmed = rental.reserve("new", "E1", start, end, now);
        check("new request consumes translated repair result", confirmed.status().equals("CONFIRMED"));
        check("settlement reads published result", SettlementView.describe(confirmed).equals("25.00 CNY"));
        check("rental owns overlap rejection", rental.reserve("conflict", "E1", start, end, now).status().equals("OVERLAP_REJECTED"));
        check("cancellation uses rental command", rental.cancel("new"));
        check("cancel preserves quote history", rental.reserve("new", "E1", start, end, now).equals(confirmed));
        System.out.println("RESULT enterprise04 checks=" + checks);
    }
    private static void check(String label, boolean pass) {
        if (!pass) throw new AssertionError(label);
        checks++; System.out.println("PASS " + label);
    }
}
