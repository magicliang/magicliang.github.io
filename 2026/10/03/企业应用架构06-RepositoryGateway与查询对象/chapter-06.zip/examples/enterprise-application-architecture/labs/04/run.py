import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

project = Path(__file__).resolve().parents[2]
lab = Path(__file__).resolve().parent
jdk = Path(os.environ['JAVA_HOME']) / 'bin' if 'JAVA_HOME' in os.environ else None
javac = str(jdk/'javac') if jdk else 'javac'
java = str(jdk/'java') if jdk else 'java'
mode = sys.argv[1] if len(sys.argv) > 1 else 'normal'
if mode not in ('normal','--state-write','--settlement-read','--device-write','--cycle'):
    raise SystemExit('unknown mode')
with tempfile.TemporaryDirectory(prefix='enterprise-modules-') as directory:
    work = Path(directory)
    source = work/'src'
    shutil.copytree(lab/'modules',source)
    for path in (project/'rental-core/frozen-27').rglob('*.java'):
        package = re.search(r'^package ([\w.]+);',path.read_text(),re.M).group(1)
        target=source/'rental.legacy'/package.replace('.','/')/path.name
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(path,target)
    def compile_into(target):
        command=[javac,'--release','21','-Xlint:all','-Werror','--module-source-path',str(source),'-d',str(target)]
        command += [str(path) for path in sorted(source.rglob('*.java'))]
        print('COMPILE strict JPMS',mode,flush=True)
        return subprocess.run(command).returncode
    result=compile_into(work/'good')
    if result: raise SystemExit(result)
    print('PASS clean module graph compiles',flush=True)
    if mode=='normal':
        for entry in ('rental.legacy/rental.BaselineCheck','rental.legacy/rental.application.ApplicationCheck','enterprise.demo/enterprise.demo.ModuleCheck'):
            result=subprocess.run([java,'-ea','--module-path',str(work/'good'),'-m',entry]).returncode
            if result: raise SystemExit(result)
    else:
        if mode=='--cycle':
            (source/'enterprise.maintenance/module-info.java').write_text('module enterprise.maintenance { requires enterprise.rental; exports enterprise.maintenance.api; }\n')
        elif mode=='--settlement-read':
            (source/'enterprise.settlement/enterprise/settlement/api/Leak.java').write_text('package enterprise.settlement.api; import enterprise.rental.internal.RentalState; final class Leak { RentalState value; }\n')
        elif mode=='--state-write':
            (source/'enterprise.maintenance/enterprise/maintenance/api/Leak.java').write_text('package enterprise.maintenance.api; import enterprise.rental.internal.RentalState; final class Leak { void retire(RentalState state) { state.repository(); } }\n')
        else:
            (source/'enterprise.maintenance/enterprise/maintenance/api/Leak.java').write_text('package enterprise.maintenance.api; import rental.domain.Equipment; final class Leak { void retire(Equipment equipment) { equipment.retire(); } }\n')
        result=compile_into(work/'bad')
        if result==0: raise AssertionError('illegal dependency compiled')
        raise SystemExit(result)
