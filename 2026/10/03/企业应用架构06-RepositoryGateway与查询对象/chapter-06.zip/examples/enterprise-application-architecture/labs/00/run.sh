#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
java_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}java
javac_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}javac
java_version=$("$java_cmd" -version 2>&1)
javac_version=$("$javac_cmd" -version 2>&1)
printf '%s\n%s\n' "$java_version" "$javac_version"
if [[ ! "$java_version" =~ version\ \"21[.\"] || ! "$javac_version" =~ ^javac\ 21[.\ ] ]]; then
  echo 'JDK 21 required; set JAVA_HOME.' >&2
  exit 2
fi
python3 "$root/labs/00/verify-baseline.py"
frozen="$root/rental-core/frozen-27"
build=$(mktemp -d)
trap 'rm -rf "$build"' EXIT
"$javac_cmd" --release 21 -Xlint:all -Werror -d "$build" "$frozen"/rental-core/*.java "$frozen"/labs/00/*.java "$frozen"/labs/24/*.java "$frozen"/labs/25/*.java "$frozen"/labs/26/*.java "$frozen"/rental-application/*.java "$frozen"/labs/27/*.java "$root/labs/00/EnterpriseBaseline.java"
"$java_cmd" -ea -cp "$build" rental.BaselineCheck
"$java_cmd" -ea -cp "$build" rental.application.ApplicationCheck
"$java_cmd" -ea -cp "$build" enterprise.baseline.EnterpriseBaseline "$@"
