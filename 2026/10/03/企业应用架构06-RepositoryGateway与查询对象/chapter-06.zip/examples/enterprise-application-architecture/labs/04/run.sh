#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
java_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}java
javac_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}javac
java_version=$("$java_cmd" -version 2>&1)
javac_version=$("$javac_cmd" -version 2>&1)
printf '%s\n%s\n' "$java_version" "$javac_version"
if [[ ! "$java_version" =~ version\ \"21[.\"] || ! "$javac_version" =~ ^javac\ 21[.\ ] ]]; then
  echo 'JDK 21 required; set JAVA_HOME.' >&2
  exit 2
fi
python3 "$root/labs/00/verify-baseline.py"
python3 "$root/labs/04/run.py" "$@"
