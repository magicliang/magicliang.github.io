package enterprise.maintenance.api;

public interface RepairApi {
    enum Result { WORKING, INSPECTION_FAILED, RETURNED_AFTER_PASS }
    Result assess(String equipment);
}
