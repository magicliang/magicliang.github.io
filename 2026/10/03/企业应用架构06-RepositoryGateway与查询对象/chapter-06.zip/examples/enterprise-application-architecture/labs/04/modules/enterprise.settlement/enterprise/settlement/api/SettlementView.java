package enterprise.settlement.api;

import enterprise.rental.api.RentalApi;

public final class SettlementView {
    private SettlementView() { }
    public static String describe(RentalApi.Result receipt) {
        return receipt.amount() == null ? "no quote" : receipt.amount().toPlainString() + " " + receipt.currency();
    }
}
