import hashlib
import json
import subprocess
import sys
from pathlib import Path

repository = Path(__file__).resolve().parents[4]
project = Path(__file__).resolve().parents[2]
revision = sys.argv[1]
resolved = subprocess.check_output(['git', 'rev-parse', revision], cwd=repository, text=True).strip()
if revision != resolved:
    raise SystemExit('use the full commit SHA')
source = repository / 'examples/software-modeling'
files = json.loads((source / 'evidence/27/standalone.json').read_text())['copied']
files += ['models/23/contracts.md', 'models/24/contracts.md', 'models/25/contracts.md', 'models/26/contracts.md',
          'models/27/ARCHITECTURE-BASELINE.md', 'evidence/27/run.txt', 'evidence/27/run.exit']
manifest = {'source_commit': revision, 'source_prefix': 'examples/software-modeling/', 'baseline': '27-v1', 'files': []}
for relative in files:
    upstream = source / relative
    blob = subprocess.check_output(['git', 'show', f'{revision}:examples/software-modeling/{relative}'], cwd=repository)
    if upstream.read_bytes() != blob:
        raise SystemExit(f'working file differs from frozen commit: {relative}')
    target = project / 'rental-core/frozen-27' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(blob)
    manifest['files'].append({'source': f'examples/software-modeling/{relative}',
                              'copy': str(target.relative_to(project)), 'sha256': hashlib.sha256(blob).hexdigest()})
    print('PASS identical copy', relative)
(project / 'models/00/baseline-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
print('FROZEN', revision, 'files', len(files))
