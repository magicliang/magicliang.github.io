module enterprise.settlement {
    requires transitive enterprise.rental;
    exports enterprise.settlement.api;
}
