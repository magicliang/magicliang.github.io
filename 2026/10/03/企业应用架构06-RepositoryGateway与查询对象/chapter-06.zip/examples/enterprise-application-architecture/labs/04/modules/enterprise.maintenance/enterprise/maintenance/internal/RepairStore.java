package enterprise.maintenance.internal;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import enterprise.maintenance.api.RepairApi;

public final class RepairStore {
    private final Map<String, RepairApi.Result> records = new HashMap<>();
    public void record(String id, RepairApi.Result result) { records.put(Objects.requireNonNull(id), Objects.requireNonNull(result)); }
    public RepairApi.Result get(String id) {
        RepairApi.Result result = records.get(id);
        if (result == null) throw new IllegalArgumentException("unknown repair assessment");
        return result;
    }
}
