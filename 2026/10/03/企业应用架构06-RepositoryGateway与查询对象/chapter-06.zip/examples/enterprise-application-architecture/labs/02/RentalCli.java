package enterprise.service;

import java.util.ArrayList;
import rental.application.ApplicationCheck;
import rental.application.RentalApplication.Event;
import rental.application.RentalApplication.Maintenance;
import rental.application.RentalApplication.MemoryRepository;

public final class RentalCli {
    private RentalCli() { }
    public static void main(String[] args) {
        if (args.length != 5) throw new IllegalArgumentException("requestId equipment startSeconds durationSeconds maintenance");
        long start = Long.parseLong(args[2]);
        long end = Math.addExact(start, Long.parseLong(args[3]));
        Maintenance maintenance = Maintenance.valueOf(args[4]);
        var events = new ArrayList<Event>();
        var repository = new MemoryRepository(ApplicationCheck.initial(), ApplicationCheck.NONE);
        var service = new RentalService(repository, id -> maintenance, events::add, ApplicationCheck.SPEC);
        var result = service.apply(ApplicationCheck.command(args[0], args[1], start, end), ApplicationCheck.NOW);
        System.out.println("CLI result=" + result + " receipts=" + repository.read().receipts().size() + " events=" + events.size());
    }
}
