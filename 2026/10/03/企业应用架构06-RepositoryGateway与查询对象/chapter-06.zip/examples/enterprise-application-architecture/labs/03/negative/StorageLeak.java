package enterprise.hexagon.core;
import enterprise.hexagon.adapter.FileMaintenance;
final class StorageLeak { private FileMaintenance storage; }
