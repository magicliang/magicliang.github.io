package enterprise.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Currency;
import java.util.function.Function;
import rental.application.ApplicationCheck;
import rental.application.RentalApplication.Event;
import rental.application.RentalApplication.Maintenance;
import rental.application.RentalApplication.MemoryRepository;
import rental.application.RentalApplication.Repository;
import rental.application.RentalApplication.Session;
import rental.application.RentalApplication.Snapshot;
import rental.application.RentalApplication.Status;
import rental.domain.Money;
import rental.domain.ReservationCalendar;

public final class ServiceCheck {
    private static int checks;
    private ServiceCheck() { }
    private static final class AfterCalculationFailure implements Repository {
        private final MemoryRepository backing = new MemoryRepository(ApplicationCheck.initial(), ApplicationCheck.NONE);
        private int calculated;
        @Override public Snapshot read() { return backing.read(); }
        @Override public <T> T transact(Function<Session,T> operation) {
            return backing.transact(session -> {
                operation.apply(session);
                calculated++;
                throw new IllegalStateException("after use-case calculation, before save");
            });
        }
    }
    public static void main(String[] args) {
        if (args.length != 0) throw new IllegalArgumentException("unknown arguments");
        var events = new ArrayList<Event>();
        var repository = new MemoryRepository(ApplicationCheck.initial(), ApplicationCheck.NONE);
        var service = new RentalService(repository, id -> Maintenance.RELEASED, events::add, ApplicationCheck.SPEC);
        var request = ApplicationCheck.command("service", "E1", 7200, 12600);
        var result = service.apply(request, ApplicationCheck.NOW);
        check("service coordinates quote and reservation", result.status() == Status.CONFIRMED
                && result.quoted().equals(new Money(new BigDecimal("25.00"), Currency.getInstance("CNY"))));
        check("service saves receipt contract and event", repository.read().receipts().size() == 1
                && repository.read().contracts().size() == 1 && events.size() == 1);
        check("same service repeat returns same result", service.apply(request, ApplicationCheck.NOW).equals(result) && events.size() == 1);
        check("service cancellation", service.cancel(request.request().requestId()));
        check("cancel preserves quote and history", service.apply(request, ApplicationCheck.NOW).equals(result)
                && repository.read().calendar().receipts().stream().noneMatch(ReservationCalendar.Receipt::active));
        var failing = new AfterCalculationFailure();
        var unpublished = new ArrayList<Event>();
        try {
            new RentalService(failing, id -> Maintenance.RELEASED, unpublished::add, ApplicationCheck.SPEC).apply(request, ApplicationCheck.NOW);
            throw new AssertionError("failure not injected");
        } catch (IllegalStateException expected) { System.out.println("OBSERVED " + expected.getMessage()); }
        check("calculation actually completed", failing.calculated == 1);
        check("save failure leaves exact original state", failing.read().equals(ApplicationCheck.initial()));
        check("no notification before save", unpublished.isEmpty());
        var retired = new MemoryRepository(ApplicationCheck.initial(), ApplicationCheck.NONE);
        retired.transact(session -> { session.equipment(ApplicationCheck.E1).retire(); return null; });
        var guarded = new RentalService(retired, id -> Maintenance.BLOCKED, unpublished::add, ApplicationCheck.SPEC);
        var bypassRequest = ApplicationCheck.command("bypass", "E1", 1, 3600);
        check("service refuses retired equipment", guarded.apply(bypassRequest, ApplicationCheck.NOW).status() == Status.INELIGIBLE);
        var bypass = new ReservationCalendar("bypass");
        check("bypass calendar accepts without lifecycle repair and lead checks",
                bypass.reserve(bypassRequest.request()) == rental.RentalDesk.Outcome.CONFIRMED);
        check("bypass created no contract or receipt in application", retired.read().contracts().isEmpty()
                && retired.read().receipts().get(bypassRequest.request().requestId()).status() == Status.INELIGIBLE);
        System.out.println("RESULT enterprise02 checks=" + checks);
    }
    private static void check(String label, boolean condition) {
        if (!condition) throw new AssertionError(label);
        checks++; System.out.println("PASS " + label);
    }
}
