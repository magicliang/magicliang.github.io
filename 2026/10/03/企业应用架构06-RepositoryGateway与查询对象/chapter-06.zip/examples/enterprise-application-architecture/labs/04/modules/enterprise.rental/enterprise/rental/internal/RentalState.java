package enterprise.rental.internal;

import java.util.List;
import java.util.Map;
import rental.RentalDesk.EquipmentId;
import rental.application.RentalApplication.MemoryRepository;
import rental.application.RentalApplication.Snapshot;
import rental.domain.Equipment;
import rental.domain.EquipmentDescription;
import rental.domain.ReservationCalendar;

public final class RentalState {
    private final MemoryRepository repository;
    public RentalState() {
        var equipment = new Equipment(new EquipmentId("E1"), new EquipmentDescription("drill", List.of("portable")));
        equipment.approveInspection();
        repository = new MemoryRepository(new Snapshot(Map.of(equipment.id(), equipment.snapshot()),
                new ReservationCalendar("shop-A").snapshot(), Map.of(), Map.of()), point -> { });
    }
    public MemoryRepository repository() { return repository; }
}
