import hashlib
import json
from pathlib import Path

project = Path(__file__).resolve().parents[2]
manifest = json.loads((project / 'models/00/baseline-manifest.json').read_text())
assert len(manifest['source_commit']) == 40
for entry in manifest['files']:
    assert hashlib.sha256((project / entry['copy']).read_bytes()).hexdigest() == entry['sha256'], entry['copy']
print('PASS frozen source integrity', manifest['source_commit'], len(manifest['files']))
