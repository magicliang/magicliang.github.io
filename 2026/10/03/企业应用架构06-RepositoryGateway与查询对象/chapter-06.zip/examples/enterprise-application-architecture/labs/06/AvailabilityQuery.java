package enterprise.chapter06;

import java.util.Objects;
import java.util.List;
import rental.RentalDesk.Period;

public record AvailabilityQuery(String tenant, String category, Period period, Sort sort) {
    public enum Sort { ID_ASC, ID_DESC }
    public AvailabilityQuery {
        if (tenant == null || tenant.isBlank() || category == null || category.isBlank()) throw new IllegalArgumentException("tenant and category are mandatory");
        Objects.requireNonNull(period, "period");
        Objects.requireNonNull(sort, "sort");
    }
    public record Plan(String sql, List<Object> parameters) {
        public Plan { parameters = List.copyOf(parameters); }
    }
    public Plan compile() {
        String order = sort == Sort.ID_ASC ? "ASC" : "DESC";
        return new Plan("SELECT e.equipment_id FROM equipment e WHERE e.tenant_id=? AND e.category=? AND e.state='ACTIVE' "
                + "AND NOT EXISTS (SELECT 1 FROM rental_contract c WHERE c.tenant_id=e.tenant_id AND c.equipment_id=e.equipment_id "
                + "AND c.status='RESERVED' AND c.starts_at<? AND ?<c.ends_at) ORDER BY e.equipment_id " + order,
                List.of(tenant, category, period.end(), period.start()));
    }
    public static Sort sort(String input) {
        return switch (input) { case "id" -> Sort.ID_ASC; case "-id" -> Sort.ID_DESC; default -> throw new IllegalArgumentException("sort not allowed"); };
    }
}
