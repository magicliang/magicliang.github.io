package enterprise.chapter06;

import java.sql.SQLException;
import enterprise.sql.Sql;

public interface InventoryGateway {
    int stock(String warehouse, String category) throws SQLException;
    final class Jdbc implements InventoryGateway {
        private final String url;
        public Jdbc(String url) { this.url = url; }
        @Override public int stock(String warehouse, String category) throws SQLException {
            try (Sql external = Sql.open(url)) {
                var rows = external.query("SELECT units FROM external_stock WHERE warehouse=? AND category=?", row -> row.getInt(1), warehouse, category);
                if (rows.size() != 1) throw new IllegalArgumentException("external stock not found");
                return rows.getFirst();
            }
        }
    }
}
