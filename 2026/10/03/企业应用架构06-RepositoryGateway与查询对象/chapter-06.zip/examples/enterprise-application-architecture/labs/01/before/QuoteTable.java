package enterprise.pricing;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import rental.domain.Money;
import enterprise.pricing.PricingData.RateRow;
import enterprise.pricing.PricingData.Span;

public final class QuoteTable implements PricingData.Quotes {
    private final List<RateRow> rateTable;
    private final Map<String, Span> rentalTable;
    public QuoteTable(List<RateRow> rates, Map<String, Span> rentals) {
        rateTable = PricingData.rates(rates); rentalTable = Map.copyOf(rentals);
    }
    public Money quoteRow(String id) { return quote(rentalTable.get(id)); }
    @Override public Money quote(Span period) {
        for (RateRow row : rateTable) {
            if (!period.start().isBefore(row.valid().start()) && period.start().isBefore(row.valid().end())) {
                long days = java.time.temporal.ChronoUnit.DAYS.between(period.start(), period.end());
                return new Money(row.daily().amount().multiply(BigDecimal.valueOf(days)), row.daily().currency());
            }
        }
        throw new IllegalArgumentException("rate gap");
    }
    @Override public Money extend(Span old, LocalDate newEnd) { return quote(PricingData.extended(old, newEnd)); }
    public Money extendRow(String id, LocalDate newEnd) { return extend(rentalTable.get(id), newEnd); }
}
