package enterprise.pricing;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import rental.domain.Money;
import enterprise.pricing.PricingData.RateRow;
import enterprise.pricing.PricingData.Span;

public final class QuoteScript implements PricingData.Quotes {
    private final List<RateRow> rows;
    public QuoteScript(List<RateRow> rows) { this.rows = PricingData.rates(rows); }
    @Override public Money quote(Span period) {
        for (RateRow row : rows) {
            if (!period.start().isBefore(row.valid().start()) && period.start().isBefore(row.valid().end())) {
                long days = java.time.temporal.ChronoUnit.DAYS.between(period.start(), period.end());
                return new Money(row.daily().amount().multiply(BigDecimal.valueOf(days)), row.daily().currency());
            }
        }
        throw new IllegalArgumentException("rate gap");
    }
    @Override public Money extend(Span old, LocalDate newEnd) { return quote(PricingData.extended(old, newEnd)); }
}
