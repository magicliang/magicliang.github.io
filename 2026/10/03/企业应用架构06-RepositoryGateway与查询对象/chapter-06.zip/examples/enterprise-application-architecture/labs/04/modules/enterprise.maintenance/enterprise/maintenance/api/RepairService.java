package enterprise.maintenance.api;

import enterprise.maintenance.internal.RepairStore;

public final class RepairService implements RepairApi {
    private final RepairStore store = new RepairStore();
    public RepairService() { }
    public void report(String equipment, Result result) { store.record(equipment, result); }
    @Override public Result assess(String equipment) { return store.get(equipment); }
}
