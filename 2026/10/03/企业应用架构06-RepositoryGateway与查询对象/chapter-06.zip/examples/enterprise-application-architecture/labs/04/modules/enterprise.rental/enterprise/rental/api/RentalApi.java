package enterprise.rental.api;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.Currency;
import java.util.Objects;
import enterprise.maintenance.api.RepairApi;
import enterprise.rental.internal.RentalState;
import rental.RentalDesk.EquipmentId;
import rental.RentalDesk.Period;
import rental.RentalDesk.RequestId;
import rental.RentalDesk.ReserveRequest;
import rental.application.RentalApplication;
import rental.application.RentalApplication.Command;
import rental.application.RentalApplication.Maintenance;
import rental.domain.Money;
import rental.domain.PricingService.HourlyRate;
import rental.domain.RentalPeriodSpecification;

public final class RentalApi {
    public record Result(String status, BigDecimal amount, String currency) { }
    private final RentalState state = new RentalState();
    private final RentalApplication application;
    public RentalApi(RepairApi repair) {
        Objects.requireNonNull(repair);
        application = new RentalApplication(state.repository(), id -> switch (repair.assess(id.value())) {
            case RETURNED_AFTER_PASS -> Maintenance.RELEASED;
            case WORKING, INSPECTION_FAILED -> Maintenance.BLOCKED;
        }, event -> { }, point -> { }, new RentalApplication.InlineAdmission(),
                new RentalPeriodSpecification(Duration.ofHours(1), Duration.ofHours(48)));
    }
    public Result reserve(String requestId, String equipmentId, Instant start, Instant end, Instant now) {
        var command = new Command(new ReserveRequest(new RequestId(requestId), new EquipmentId(equipmentId), new Period(start, end)),
                new HourlyRate("rate-v1", new Money(new BigDecimal("12.50"), Currency.getInstance("CNY"))));
        var status = application.reserve(command, now);
        var stored = state.repository().read().contracts().get(command.request().requestId());
        return new Result(status.name(), stored == null ? null : stored.total().amount(), stored == null ? null : stored.total().currency().getCurrencyCode());
    }
    public boolean cancel(String requestId) { return application.cancel(new RequestId(requestId)); }
}
