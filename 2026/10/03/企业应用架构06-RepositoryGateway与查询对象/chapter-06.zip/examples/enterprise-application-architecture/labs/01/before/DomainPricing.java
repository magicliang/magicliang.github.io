package enterprise.pricing;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import rental.domain.Money;
import enterprise.pricing.PricingData.RateRow;
import enterprise.pricing.PricingData.Span;

public final class DomainPricing implements PricingData.Quotes {
    private record StartDatePrice(List<RateRow> rows) {
        Money priceAt(LocalDate date) {
            for (RateRow row : rows) if (!date.isBefore(row.valid().start()) && date.isBefore(row.valid().end())) return row.daily();
            throw new IllegalArgumentException("rate gap");
        }
    }
    private final StartDatePrice prices;
    public DomainPricing(List<RateRow> rows) { prices = new StartDatePrice(PricingData.rates(rows)); }
    @Override public Money quote(Span period) {
        Money rate = prices.priceAt(period.start());
        return new Money(rate.amount().multiply(BigDecimal.valueOf(ChronoUnit.DAYS.between(period.start(), period.end()))), rate.currency());
    }
    @Override public Money extend(Span old, LocalDate newEnd) { return quote(PricingData.extended(old, newEnd)); }
}
