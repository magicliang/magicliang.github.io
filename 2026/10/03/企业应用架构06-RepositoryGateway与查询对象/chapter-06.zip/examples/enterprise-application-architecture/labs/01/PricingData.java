package enterprise.pricing;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import rental.domain.Money;

public final class PricingData {
    private PricingData() { }
    public record Span(LocalDate start, LocalDate end) {
        public Span {
            Objects.requireNonNull(start); Objects.requireNonNull(end);
            if (!start.isBefore(end)) throw new IllegalArgumentException("non-positive rental period");
        }
    }
    public record RateRow(Span valid, Money daily) {
        public RateRow {
            Objects.requireNonNull(valid); Objects.requireNonNull(daily);
            if (daily.amount().signum() < 0) throw new IllegalArgumentException("negative rate");
        }
    }
    public static List<RateRow> rates(List<RateRow> input) {
        List<RateRow> result = List.copyOf(input);
        if (result.isEmpty()) throw new IllegalArgumentException("empty price schedule");
        for (int i = 0; i < result.size(); i++) {
            if (!result.get(i).daily().currency().equals(result.getFirst().daily().currency())) throw new IllegalArgumentException("mixed currency");
            for (int j = i + 1; j < result.size(); j++) {
                Span one = result.get(i).valid(); Span two = result.get(j).valid();
                if (one.start().isBefore(two.end()) && two.start().isBefore(one.end())) throw new IllegalArgumentException("overlapping rates");
            }
        }
        return result;
    }
    public static Span extended(Span old, LocalDate end) {
        if (!end.isAfter(old.end())) throw new IllegalArgumentException("extension must increase end");
        return new Span(old.start(), end);
    }
    public interface Quotes {
        Money quote(Span period);
        Money extend(Span old, LocalDate newEnd);
    }
}
