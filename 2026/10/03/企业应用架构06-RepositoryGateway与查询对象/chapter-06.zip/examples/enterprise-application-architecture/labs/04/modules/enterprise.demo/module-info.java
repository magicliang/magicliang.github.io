module enterprise.demo {
    requires enterprise.rental;
    requires enterprise.settlement;
}
