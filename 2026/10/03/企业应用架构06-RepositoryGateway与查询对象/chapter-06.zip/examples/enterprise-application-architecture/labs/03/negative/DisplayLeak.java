package enterprise.hexagon.core;
import enterprise.hexagon.adapter.DisplayDto;
final class DisplayLeak { private DisplayDto display; }
