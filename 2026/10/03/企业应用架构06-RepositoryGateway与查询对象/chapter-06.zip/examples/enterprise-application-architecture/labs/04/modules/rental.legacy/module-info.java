module rental.legacy {
    exports rental to enterprise.rental;
    exports rental.domain to enterprise.rental;
    exports rental.application to enterprise.rental;
}
