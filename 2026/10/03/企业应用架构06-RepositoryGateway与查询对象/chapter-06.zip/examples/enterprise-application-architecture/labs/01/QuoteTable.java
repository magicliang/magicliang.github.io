package enterprise.pricing;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import rental.domain.Money;
import enterprise.pricing.PricingData.RateRow;
import enterprise.pricing.PricingData.Span;

public final class QuoteTable implements PricingData.Quotes {
    private final List<RateRow> rateTable;
    private final Map<String, Span> rentalTable;
    public QuoteTable(List<RateRow> rates, Map<String, Span> rentals) {
        rateTable = PricingData.rates(rates); rentalTable = Map.copyOf(rentals);
    }
    public Money quoteRow(String id) { return quote(rentalTable.get(id)); }
    @Override public Money quote(Span period) {
        BigDecimal total = BigDecimal.ZERO;
        long days = 0;
        for (RateRow row : rateTable) {
            LocalDate from = period.start().isAfter(row.valid().start()) ? period.start() : row.valid().start();
            LocalDate until = period.end().isBefore(row.valid().end()) ? period.end() : row.valid().end();
            if (from.isBefore(until)) {
                long count = ChronoUnit.DAYS.between(from, until);
                days += count; total = total.add(row.daily().amount().multiply(BigDecimal.valueOf(count)));
            }
        }
        if (days != ChronoUnit.DAYS.between(period.start(), period.end())) throw new IllegalArgumentException("rate gap");
        return new Money(total, rateTable.getFirst().daily().currency());
    }
    @Override public Money extend(Span old, LocalDate newEnd) { return quote(PricingData.extended(old, newEnd)); }
    public Money extendRow(String id, LocalDate newEnd) { return extend(rentalTable.get(id), newEnd); }
}
