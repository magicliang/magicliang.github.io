package enterprise.pricing;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import rental.domain.Money;
import enterprise.pricing.PricingData.RateRow;
import enterprise.pricing.PricingData.Span;

public final class QuoteScript implements PricingData.Quotes {
    private final List<RateRow> rows;
    public QuoteScript(List<RateRow> rows) { this.rows = PricingData.rates(rows); }
    @Override public Money quote(Span period) {
        BigDecimal total = BigDecimal.ZERO;
        for (LocalDate day = period.start(); day.isBefore(period.end()); day = day.plusDays(1)) {
            RateRow selected = null;
            for (RateRow row : rows) if (!day.isBefore(row.valid().start()) && day.isBefore(row.valid().end())) selected = row;
            if (selected == null) throw new IllegalArgumentException("rate gap");
            total = total.add(selected.daily().amount());
        }
        return new Money(total, rows.getFirst().daily().currency());
    }
    @Override public Money extend(Span old, LocalDate newEnd) { return quote(PricingData.extended(old, newEnd)); }
}
