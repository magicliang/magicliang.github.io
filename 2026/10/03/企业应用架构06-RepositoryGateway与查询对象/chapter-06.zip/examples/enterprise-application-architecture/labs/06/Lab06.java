package enterprise.chapter06;

import java.nio.file.Path;
import java.util.List;
import enterprise.chapter05.ContractMapper;
import enterprise.chapter05.Lab05;
import enterprise.sql.Check;
import enterprise.sql.Contract;
import enterprise.sql.Sql;
import rental.RentalDesk.EquipmentId;
import rental.RentalDesk.Period;

public final class Lab06 {
    private Lab06() { }
    public static void main(String[] args) throws Exception {
        String url = "jdbc:h2:" + Path.of(args[0]).toAbsolutePath();
        Sql.migrate(url, Path.of(args[1]));
        var sample = Lab05.sample("busy", "E1");
        try (Sql db = Sql.open(url)) {
            for (String id : List.of("E1", "E2", "E3", "E4")) db.update("INSERT INTO equipment(tenant_id,equipment_id,category,state) VALUES(?,?,?,?)", "T1", id, "camera", id.equals("E4") ? "RETIRED" : "ACTIVE");
            db.update("INSERT INTO equipment(tenant_id,equipment_id,category,state) VALUES(?,?,?,?)", "T2", "OTHER", "camera", "ACTIVE");
            db.update("INSERT INTO equipment(tenant_id,equipment_id,category,state) VALUES(?,?,?,?)", "T1", "QUOTE", "camera' OR '1'='1", "ACTIVE");
            var mapper = new ContractMapper();
            mapper.insert(db,sample);
            for (String id : List.of("old-1", "old-2")) mapper.insert(db,Lab05.sample(id,"E2").cancel());
            mapper.insert(db,new Contract("T1","adjacent",new EquipmentId("E3"),new Period(sample.period().end(),sample.period().end().plusSeconds(3600)),sample.total(),Contract.State.RESERVED,0));
            db.commit();
        }
        var query = new AvailabilityQuery("T1","camera",sample.period(),AvailabilityQuery.Sort.ID_ASC);
        try (Sql db = Sql.open(url)) {
            var repo = new EquipmentRepository(db);
            var wanted = List.of(new EquipmentId("E2"),new EquipmentId("E3"));
            var found = repo.available(query);
            Check.that("tenant, category, ACTIVE, half-open occupancy exact set",found.equals(wanted));
            Check.that("cancelled history does not duplicate rows",found.stream().distinct().count()==found.size());
            Check.that("allowlisted descending order",repo.available(new AvailabilityQuery("T1","camera",sample.period(),AvailabilityQuery.Sort.ID_DESC)).equals(wanted.reversed()));
            Check.that("quote input stays bound data",repo.available(new AvailabilityQuery("T1","camera' OR '1'='1",sample.period(),AvailabilityQuery.Sort.ID_ASC)).equals(List.of(new EquipmentId("QUOTE"))));
            Check.that("statements and results closed after queries",db.resources()==0);
            if (args.length>2) {
                List<EquipmentId> broken = switch(args[2]) {
                    case "--omit-tenant" -> db.query("SELECT e.equipment_id FROM equipment e WHERE e.category=? AND e.state='ACTIVE' AND NOT EXISTS (SELECT 1 FROM rental_contract c WHERE c.tenant_id=e.tenant_id AND c.equipment_id=e.equipment_id AND c.status='RESERVED' AND c.starts_at<? AND ?<c.ends_at) ORDER BY e.equipment_id", row->new EquipmentId(row.getString(1)),"camera",sample.period().end(),sample.period().start());
                    case "--omit-time" -> db.query("SELECT e.equipment_id FROM equipment e WHERE e.tenant_id=? AND e.category=? AND e.state='ACTIVE' AND NOT EXISTS (SELECT 1 FROM rental_contract c WHERE c.tenant_id=e.tenant_id AND c.equipment_id=e.equipment_id AND c.status='RESERVED') ORDER BY e.equipment_id",row->new EquipmentId(row.getString(1)),"T1","camera");
                    case "--duplicate" -> db.query("SELECT e.equipment_id FROM equipment e LEFT JOIN rental_contract old ON old.tenant_id=e.tenant_id AND old.equipment_id=e.equipment_id AND old.status='CANCELLED' WHERE e.tenant_id=? AND e.category=? AND e.state='ACTIVE' AND NOT EXISTS (SELECT 1 FROM rental_contract c WHERE c.tenant_id=e.tenant_id AND c.equipment_id=e.equipment_id AND c.status='RESERVED' AND c.starts_at<? AND ?<c.ends_at) ORDER BY e.equipment_id",row->new EquipmentId(row.getString(1)),"T1","camera",sample.period().end(),sample.period().start());
                    default -> throw new IllegalArgumentException("mode");
                };
                Check.that("mutant must preserve exact availability set: actual="+broken,broken.equals(wanted));
            }
        }
        int rejected=0;
        try { new AvailabilityQuery("","camera",sample.period(),AvailabilityQuery.Sort.ID_ASC); } catch(IllegalArgumentException expected) { rejected++; }
        try { new AvailabilityQuery("T1","",sample.period(),AvailabilityQuery.Sort.ID_ASC); } catch(IllegalArgumentException expected) { rejected++; }
        try { AvailabilityQuery.sort("id; DROP TABLE equipment"); } catch(IllegalArgumentException expected) { rejected++; }
        try { new AvailabilityQuery("T1","camera",null,AvailabilityQuery.Sort.ID_ASC); } catch(NullPointerException expected) { rejected++; }
        Check.that("empty tenant/category, missing period, illegal sort rejected",rejected==4);
        String external=url+"-inventory";
        try(Sql db=Sql.open(external)) {
            db.update("CREATE TABLE external_stock(warehouse VARCHAR(30), category VARCHAR(80), units INT CHECK(units>=0), PRIMARY KEY(warehouse,category))");
            db.update("INSERT INTO external_stock VALUES(?,?,?)","W1","camera",3); db.commit();
        }
        InventoryGateway gateway=new InventoryGateway.Jdbc(external);
        Check.that("gateway reads actual separate inventory database",gateway.stock("W1","camera")==3);
        try(Sql db=Sql.open(url)) { Check.that("rental database remains six equipment rows",db.count("equipment")==6); }
        Check.result("06");
    }
}
