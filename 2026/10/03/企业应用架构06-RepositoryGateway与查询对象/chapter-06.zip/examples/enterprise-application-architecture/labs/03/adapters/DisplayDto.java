package enterprise.hexagon.adapter;

public record DisplayDto(String text) { }
