#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
java_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}java
javac_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}javac
java_version=$("$java_cmd" -version 2>&1)
javac_version=$("$javac_cmd" -version 2>&1)
printf '%s\n%s\n' "$java_version" "$javac_version"
if [[ ! "$java_version" =~ version\ \"21[.\"] || ! "$javac_version" =~ ^javac\ 21[.\ ] ]]; then
  echo 'JDK 21 required; set JAVA_HOME.' >&2
  exit 2
fi
python3 "$root/labs/00/verify-baseline.py"
frozen="$root/rental-core/frozen-27"
build=$(mktemp -d)
trap 'rm -rf "$build"' EXIT
mkdir "$build/before" "$build/after"
"$javac_cmd" --release 21 -Xlint:all -Werror -d "$build/before" "$frozen/labs/24/Money.java" "$root/labs/01/PricingData.java" "$root/labs/01/PricingCheck.java" "$root/labs/01/before/"*.java
"$javac_cmd" --release 21 -Xlint:all -Werror -d "$build/after" "$frozen/labs/24/Money.java" "$root/labs/01/"*.java
if [[ "${1:-}" == --old-contract ]]; then
  "$java_cmd" -ea -cp "$build/before" enterprise.pricing.PricingCheck
else
  "$java_cmd" -ea -cp "$build/before" enterprise.pricing.PricingCheck --flat
  "$java_cmd" -ea -cp "$build/after" enterprise.pricing.PricingCheck "$@"
fi
