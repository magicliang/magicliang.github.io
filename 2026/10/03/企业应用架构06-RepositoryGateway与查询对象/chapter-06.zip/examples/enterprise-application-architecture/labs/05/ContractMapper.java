package enterprise.chapter05;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.OffsetDateTime;
import java.util.Currency;
import enterprise.sql.Contract;
import enterprise.sql.Sql;
import rental.RentalDesk.EquipmentId;
import rental.RentalDesk.Period;
import rental.domain.Money;

public final class ContractMapper {
    public void insert(Sql db, Contract contract) throws SQLException {
        db.update("INSERT INTO rental_contract(tenant_id,contract_id,equipment_id,starts_at,ends_at,amount,currency,status,version) VALUES(?,?,?,?,?,?,?,?,?)",
                contract.tenant(), contract.id(), contract.equipment().value(), contract.period().start(), contract.period().end(),
                contract.total().amount(), contract.total().currency().getCurrencyCode(), contract.state().name(), contract.version());
    }
    public void saveState(Sql db, Contract value) throws SQLException {
        int rows = db.update("UPDATE rental_contract SET status=? WHERE tenant_id=? AND contract_id=?", value.state().name(), value.tenant(), value.id());
        if (rows != 1) throw new IllegalStateException("contract missing");
    }
    public Contract find(Sql db, String tenant, String id) throws SQLException {
        var rows = db.query("SELECT * FROM rental_contract WHERE tenant_id=? AND contract_id=?", ContractMapper::read, tenant, id);
        if (rows.size() != 1) throw new IllegalArgumentException("contract not found");
        return rows.getFirst();
    }
    public static Contract read(ResultSet row) throws SQLException {
        return new Contract(row.getString("tenant_id"), row.getString("contract_id"), new EquipmentId(row.getString("equipment_id")),
                new Period(row.getObject("starts_at", OffsetDateTime.class).toInstant(), row.getObject("ends_at", OffsetDateTime.class).toInstant()),
                new Money(row.getBigDecimal("amount"), Currency.getInstance(row.getString("currency"))),
                Contract.State.valueOf(row.getString("status")), row.getLong("version"));
    }
}
