package enterprise.hexagon.core;

import java.time.Instant;
import rental.application.RentalApplication.Command;
import rental.application.RentalApplication.MaintenancePort;
import rental.application.RentalApplication.Publisher;
import rental.application.RentalApplication.Repository;
import rental.domain.RentalPeriodSpecification;
import enterprise.service.RentalService;

public final class RentalUseCase {
    private final RentalService service;
    public RentalUseCase(Repository repository, MaintenancePort maintenance, Publisher publisher,
                         RentalPeriodSpecification specification) {
        service = new RentalService(repository, maintenance, publisher, specification);
    }
    public RentalService.Result apply(Command command, Instant now) { return service.apply(command, now); }
}
