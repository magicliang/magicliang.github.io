package enterprise.baseline;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Currency;
import java.util.HashMap;
import java.util.Map;
import rental.RentalDesk.RequestId;
import rental.application.ApplicationCheck;
import rental.application.RentalApplication;
import rental.application.RentalApplication.Command;
import rental.application.RentalApplication.Maintenance;
import rental.application.RentalApplication.MemoryRepository;
import rental.application.RentalApplication.Status;
import rental.domain.Money;
import rental.domain.PricingService;
import rental.domain.RentalContract;

public final class EnterpriseBaseline {
    private record DirectReceipt(Command command, Status status) { }
    private static final class Direct {
        private final Map<RequestId, DirectReceipt> history = new HashMap<>();
        private final Map<RequestId, Command> active = new HashMap<>();
        private Status reserve(Command command, Maintenance maintenance, boolean mutant) {
            var previous = history.get(command.request().requestId());
            if (previous != null) {
                if (!previous.command().equals(command)) throw new IllegalArgumentException("changed payload");
                return previous.status();
            }
            Status status;
            if (!command.request().equipmentId().equals(ApplicationCheck.E1)) status = Status.UNKNOWN_EQUIPMENT;
            else if (maintenance != Maintenance.RELEASED) status = Status.MAINTENANCE_RESTRICTED;
            else if (!ApplicationCheck.SPEC.isSatisfiedBy(command.request().period(), ApplicationCheck.NOW)) status = Status.INVALID_PERIOD;
            else if (!mutant && active.values().stream().anyMatch(old -> old.request().equipmentId().equals(command.request().equipmentId())
                    && old.request().period().overlaps(command.request().period()))) status = Status.OVERLAP_REJECTED;
            else status = Status.CONFIRMED;
            history.put(command.request().requestId(), new DirectReceipt(command, status));
            if (status == Status.CONFIRMED) active.put(command.request().requestId(), command);
            return status;
        }
        private boolean cancel(RequestId id) { return active.remove(id) != null; }
    }
    private static int checks;
    private EnterpriseBaseline() { }
    public static void main(String[] args) {
        boolean mutant = args.length == 1 && args[0].equals("--mutant");
        if (args.length > 0 && !mutant) throw new IllegalArgumentException("unknown argument");
        var repository = new MemoryRepository(ApplicationCheck.initial(), ApplicationCheck.NONE);
        var events = new ArrayList<RentalApplication.Event>();
        var app = new RentalApplication(repository, id -> Maintenance.RELEASED, events::add, ApplicationCheck.NONE,
                new RentalApplication.InlineAdmission(), ApplicationCheck.SPEC);
        var direct = new Direct();
        var first = ApplicationCheck.command("first", "E1", 7200, 10800);
        var overlap = ApplicationCheck.command("overlap", "E1", 9000, 12000);
        compare("E00-01 reserve", app.reserve(first, ApplicationCheck.NOW), direct.reserve(first, Maintenance.RELEASED, mutant));
        compare("E00-02 overlap", app.reserve(overlap, ApplicationCheck.NOW), direct.reserve(overlap, Maintenance.RELEASED, mutant));
        compare("E00-03 repeat", app.reserve(first, ApplicationCheck.NOW), direct.reserve(first, Maintenance.RELEASED, mutant));
        compare("E00-04 cancellation", app.cancel(first.request().requestId()), direct.cancel(first.request().requestId()));
        compare("E00-05 cancelled replay", app.reserve(first, ApplicationCheck.NOW), direct.reserve(first, Maintenance.RELEASED, mutant));
        compare("E00-06 rejected replay", app.reserve(overlap, ApplicationCheck.NOW), direct.reserve(overlap, Maintenance.RELEASED, mutant));
        var fresh = ApplicationCheck.command("fresh", "E1", 9000, 12000);
        compare("E00-07 new intent", app.reserve(fresh, ApplicationCheck.NOW), direct.reserve(fresh, Maintenance.RELEASED, mutant));
        var quote = new PricingService().quote(first.request().period(), first.rate());
        compare("E00-08 quote", repository.read().contracts().get(first.request().requestId()).total(), quote);
        var maintenanceApp = new RentalApplication(repository, id -> Maintenance.BLOCKED, events::add, ApplicationCheck.NONE,
                new RentalApplication.InlineAdmission(), ApplicationCheck.SPEC);
        var restricted = ApplicationCheck.command("repair", "E1", 14000, 18000);
        compare("E00-09 repair blocked", maintenanceApp.reserve(restricted, ApplicationCheck.NOW), direct.reserve(restricted, Maintenance.BLOCKED, mutant));
        var contract = RentalContract.restore(repository.read().contracts().get(first.request().requestId()));
        reject("E00-10 currency mismatch", () -> contract.covers(new Money(new BigDecimal("12.50"), Currency.getInstance("USD"))));
        reject("E00-11 payload mismatch", () -> app.reserve(ApplicationCheck.command("first", "E2", 7200, 10800), ApplicationCheck.NOW));
        compare("E00-12 direct active count", repository.read().calendar().receipts().stream().filter(r -> r.active()).count(), (long) direct.active.size());
        System.out.println("RESULT enterprise00 checks=" + checks + " quote=" + quote + " events=" + events.size());
    }
    private static void compare(String name, Object expected, Object actual) {
        if (!expected.equals(actual)) throw new AssertionError(name + " expected=" + expected + " actual=" + actual);
        checks++; System.out.println("PASS " + name + " -> " + actual);
    }
    private static void reject(String name, Runnable action) {
        try { action.run(); } catch (IllegalArgumentException expected) { checks++; System.out.println("PASS " + name); return; }
        throw new AssertionError(name);
    }
}
