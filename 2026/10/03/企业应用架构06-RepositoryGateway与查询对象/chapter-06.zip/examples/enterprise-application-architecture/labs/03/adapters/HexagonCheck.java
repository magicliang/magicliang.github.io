package enterprise.hexagon.adapter;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import rental.application.ApplicationCheck;
import rental.application.RentalApplication.Event;
import rental.application.RentalApplication.Maintenance;
import rental.application.RentalApplication.MemoryRepository;
import rental.application.RentalApplication.Status;
import enterprise.hexagon.core.RentalUseCase;

public final class HexagonCheck {
    private static int checks;
    private HexagonCheck() { }
    public static void main(String[] args) throws Exception {
        if (args.length != 1) throw new IllegalArgumentException("fixture path required");
        Path fixture = Path.of(args[0]);
        var memory = new MemoryRepository(ApplicationCheck.initial(), ApplicationCheck.NONE);
        var file = new MemoryRepository(ApplicationCheck.initial(), ApplicationCheck.NONE);
        var memoryEvents = new ArrayList<Event>();
        var fileEvents = new ArrayList<Event>();
        var inner = new RentalUseCase(memory, id -> Maintenance.RELEASED, memoryEvents::add, ApplicationCheck.SPEC);
        var external = new RentalUseCase(file, new FileMaintenance(fixture), fileEvents::add, ApplicationCheck.SPEC);
        var command = ApplicationCheck.command("ports", "E1", 7200, 12600);
        check("memory and file adapters same result", inner.apply(command, ApplicationCheck.NOW).equals(external.apply(command, ApplicationCheck.NOW)));
        check("same final snapshot", memory.read().equals(file.read()));
        check("same events", memoryEvents.equals(fileEvents));
        Files.writeString(fixture, "E1=BLOCKED\n");
        check("external file actually re-read", external.apply(ApplicationCheck.command("blocked", "E1", 14000, 18000), ApplicationCheck.NOW).status() == Status.MAINTENANCE_RESTRICTED);
        Files.writeString(fixture, "E1=UNKNOWN_VENDOR_VALUE\n");
        var before = file.read();
        try {
            external.apply(ApplicationCheck.command("unknown", "E1", 14000, 18000), ApplicationCheck.NOW);
            throw new AssertionError("unknown maintenance accepted");
        } catch (IllegalArgumentException expected) { check("unknown adapter value fails without state change", file.read().equals(before)); }
        Files.delete(fixture);
        check("historical replay avoids missing external file", external.apply(command, ApplicationCheck.NOW).status() == Status.CONFIRMED);
        System.out.println("RESULT enterprise03 checks=" + checks);
    }
    private static void check(String label, boolean result) {
        if (!result) throw new AssertionError(label);
        checks++; System.out.println("PASS " + label);
    }
}
