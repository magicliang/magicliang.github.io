package enterprise.pricing;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Currency;
import java.util.List;
import java.util.Map;
import rental.domain.Money;
import enterprise.pricing.PricingData.Quotes;
import enterprise.pricing.PricingData.RateRow;
import enterprise.pricing.PricingData.Span;

public final class PricingCheck {
    private static int checks;
    private PricingCheck() { }
    public static LocalDate day(int value) { return LocalDate.of(2026, 10, value); }
    public static Span span(int start, int end) { return new Span(day(start), day(end)); }
    public static Money money(String amount) { return new Money(new BigDecimal(amount), Currency.getInstance("CNY")); }
    public static List<RateRow> rates() { return List.of(new RateRow(span(1, 5), money("100")), new RateRow(span(5, 10), money("150"))); }
    public static void main(String[] args) {
        boolean flat = args.length == 1 && args[0].equals("--flat");
        boolean omit = args.length == 1 && args[0].equals("--omit-extension");
        if (args.length > 0 && !flat && !omit) throw new IllegalArgumentException("unknown arguments");
        var script = new QuoteScript(rates());
        var domain = new DomainPricing(rates());
        var table = new QuoteTable(rates(), Map.of("r1", span(3, 5), "r2", span(5, 7)));
        for (Quotes version : List.of(script, domain, table)) {
            String name = version.getClass().getSimpleName();
            check(name + " same-rate", version.quote(span(3, 5)).equals(money("200")));
            check(name + " boundary starts new rate", version.quote(span(5, 6)).equals(money("150")));
            check(name + " cross effective date", version.quote(span(3, 6)).equals(money(flat ? "300" : "350")));
            Money extension = omit && version == script ? staleExtension(span(3, 5), day(7)) : version.extend(span(3, 5), day(7));
            check(name + " extension total", extension.equals(money(flat ? "400" : "500")));
            reject(name + " negative period", () -> version.quote(span(6, 3)));
            reject(name + " zero period", () -> version.quote(span(5, 5)));
            reject(name + " shortening not extension", () -> version.extend(span(3, 5), day(4)));
            if (!flat) reject(name + " missing validity coverage", () -> version.quote(span(9, 11)));
        }
        check("table handles two rows in one module", table.quoteRow("r1").equals(money("200")) && table.quoteRow("r2").equals(money("300")));
        check("table row extension", table.extendRow("r1", day(7)).equals(money(flat ? "400" : "500")));
        reject("overlapping effective prices", () -> new QuoteScript(List.of(new RateRow(span(1, 6), money("100")), new RateRow(span(5, 10), money("150")))));
        reject("mixed currency schedule", () -> new DomainPricing(List.of(new RateRow(span(1, 5), money("100")),
                new RateRow(span(5, 10), new Money(BigDecimal.ONE, Currency.getInstance("USD"))))));
        System.out.println("RESULT enterprise01 checks=" + checks + " rule=" + (flat ? "start-date rate" : "segmented effective rates"));
    }
    private static Money staleExtension(Span old, LocalDate newEnd) {
        Span extended = PricingData.extended(old, newEnd);
        for (RateRow row : rates()) {
            if (!extended.start().isBefore(row.valid().start()) && extended.start().isBefore(row.valid().end())) {
                long days = java.time.temporal.ChronoUnit.DAYS.between(extended.start(), extended.end());
                return new Money(row.daily().amount().multiply(BigDecimal.valueOf(days)), row.daily().currency());
            }
        }
        throw new IllegalArgumentException("rate gap");
    }
    private static void check(String label, boolean pass) {
        if (!pass) throw new AssertionError(label);
        checks++; System.out.println("PASS " + label);
    }
    private static void reject(String label, Runnable action) {
        try { action.run(); } catch (IllegalArgumentException expected) { check(label, true); return; }
        throw new AssertionError(label);
    }
}
