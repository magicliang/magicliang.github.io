package enterprise.chapter06;

import java.sql.SQLException;
import java.util.List;
import enterprise.sql.Sql;
import rental.RentalDesk.EquipmentId;

public final class EquipmentRepository {
    private final Sql session;
    public EquipmentRepository(Sql session) { this.session = session; }
    public List<EquipmentId> available(AvailabilityQuery query) throws SQLException {
        var plan = query.compile();
        return session.query(plan.sql(), row -> new EquipmentId(row.getString(1)), plan.parameters().toArray());
    }
}
