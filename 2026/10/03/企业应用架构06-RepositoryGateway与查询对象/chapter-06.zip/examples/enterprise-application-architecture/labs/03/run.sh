#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
java_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}java
javac_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}javac
java_version=$("$java_cmd" -version 2>&1)
javac_version=$("$javac_cmd" -version 2>&1)
printf '%s\n%s\n' "$java_version" "$javac_version"
if [[ ! "$java_version" =~ version\ \"21[.\"] || ! "$javac_version" =~ ^javac\ 21[.\ ] ]]; then
  echo 'JDK 21 required; set JAVA_HOME.' >&2
  exit 2
fi
python3 "$root/labs/00/verify-baseline.py"
frozen="$root/rental-core/frozen-27"
build=$(mktemp -d)
trap 'rm -rf "$build"' EXIT
mkdir "$build/core" "$build/adapters"
"$javac_cmd" --release 21 -Xlint:all -Werror -d "$build/core" "$frozen"/rental-core/*.java "$frozen"/labs/00/*.java "$frozen"/labs/24/*.java "$frozen"/labs/25/*.java "$frozen"/labs/26/*.java "$frozen"/rental-application/*.java "$frozen"/labs/27/*.java "$root/labs/02/RentalService.java" "$root/labs/03/core/"*.java
"$javac_cmd" --release 21 -Xlint:all -Werror -cp "$build/core" -d "$build/adapters" "$root/labs/03/adapters/"*.java
if [[ "${1:-}" == --storage-leak || "${1:-}" == --display-leak ]]; then
  leak=StorageLeak
  [[ "$1" == --display-leak ]] && leak=DisplayLeak
  "$javac_cmd" --release 21 -Xlint:all -Werror -cp "$build/core" -d "$build/core" "$root/labs/03/negative/$leak.java"
else
  "$java_cmd" -ea -cp "$build/core" rental.BaselineCheck
  "$java_cmd" -ea -cp "$build/core" rental.application.ApplicationCheck
  printf 'E1=RELEASED\n' > "$build/maintenance.properties"
  "$java_cmd" -ea -cp "$build/core:$build/adapters" enterprise.hexagon.adapter.HexagonCheck "$build/maintenance.properties"
fi
