package enterprise.chapter05;

import java.sql.SQLException;
import enterprise.sql.Contract;
import enterprise.sql.Sql;

public final class ActiveContract {
    private Contract value;
    public ActiveContract(Contract value) { this.value = value; }
    public Contract value() { return value; }
    public void cancel() { value = value.cancel(); }
    public void insert(Sql db) throws SQLException {
        db.update("INSERT INTO rental_contract(tenant_id,contract_id,equipment_id,starts_at,ends_at,amount,currency,status,version) VALUES(?,?,?,?,?,?,?,?,?)",
                value.tenant(), value.id(), value.equipment().value(), value.period().start(), value.period().end(),
                value.total().amount(), value.total().currency().getCurrencyCode(), value.state().name(), value.version());
    }
    public void saveState(Sql db) throws SQLException {
        int rows = db.update("UPDATE rental_contract SET status=? WHERE tenant_id=? AND contract_id=?", value.state().name(), value.tenant(), value.id());
        if (rows != 1) throw new IllegalStateException("contract missing");
    }
    public static ActiveContract find(Sql db, String tenant, String id) throws SQLException {
        var rows = db.query("SELECT * FROM rental_contract WHERE tenant_id=? AND contract_id=?", ContractMapper::read, tenant, id);
        if (rows.size() != 1) throw new IllegalArgumentException("contract not found");
        return new ActiveContract(rows.getFirst());
    }
}
