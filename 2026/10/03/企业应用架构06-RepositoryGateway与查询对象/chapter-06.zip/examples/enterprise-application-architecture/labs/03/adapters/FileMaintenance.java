package enterprise.hexagon.adapter;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import rental.RentalDesk.EquipmentId;
import rental.application.RentalApplication.Maintenance;
import rental.application.RentalApplication.MaintenancePort;

public final class FileMaintenance implements MaintenancePort {
    private final Path path;
    public FileMaintenance(Path path) { this.path = path; }
    @Override public Maintenance assess(EquipmentId id) {
        var entries = new Properties();
        try (Reader reader = Files.newBufferedReader(path)) { entries.load(reader); }
        catch (IOException failure) { throw new UncheckedIOException(failure); }
        String value = entries.getProperty(id.value());
        if (value == null) throw new IllegalArgumentException("missing equipment maintenance result");
        return Maintenance.valueOf(value);
    }
}
