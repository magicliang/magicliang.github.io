package enterprise.service;

import java.time.Instant;
import java.util.Objects;
import rental.RentalDesk.RequestId;
import rental.domain.RentalPeriodSpecification;
import rental.application.RentalApplication;
import rental.application.RentalApplication.Command;
import rental.application.RentalApplication.MaintenancePort;
import rental.application.RentalApplication.Publisher;
import rental.application.RentalApplication.Repository;
import rental.application.RentalApplication.Status;
import rental.domain.Money;

public final class RentalService {
    public record Result(Status status, Money quoted) { }
    private final Repository repository;
    private final RentalApplication application;
    public RentalService(Repository repository, MaintenancePort maintenance, Publisher publisher, RentalPeriodSpecification specification) {
        this.repository = Objects.requireNonNull(repository);
        application = new RentalApplication(repository, maintenance, publisher, point -> { },
                new RentalApplication.InlineAdmission(), specification);
    }
    public Result apply(Command command, Instant now) {
        Status status = application.reserve(command, now);
        var stored = repository.read().contracts().get(command.request().requestId());
        return new Result(status, stored == null ? null : stored.total());
    }
    public boolean cancel(RequestId requestId) { return application.cancel(requestId); }
}
