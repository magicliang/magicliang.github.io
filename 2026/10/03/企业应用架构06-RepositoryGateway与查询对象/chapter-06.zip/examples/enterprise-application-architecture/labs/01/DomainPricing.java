package enterprise.pricing;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import rental.domain.Money;
import enterprise.pricing.PricingData.RateRow;
import enterprise.pricing.PricingData.Span;

public final class DomainPricing implements PricingData.Quotes {
    private record Segment(RateRow row) {
        long coveredDays(Span rental) {
            LocalDate from = rental.start().isAfter(row.valid().start()) ? rental.start() : row.valid().start();
            LocalDate until = rental.end().isBefore(row.valid().end()) ? rental.end() : row.valid().end();
            return from.isBefore(until) ? ChronoUnit.DAYS.between(from, until) : 0;
        }
        Money charge(Span rental) { return new Money(row.daily().amount().multiply(BigDecimal.valueOf(coveredDays(rental))), row.daily().currency()); }
    }
    private final List<Segment> segments;
    public DomainPricing(List<RateRow> rows) { segments = PricingData.rates(rows).stream().map(Segment::new).toList(); }
    @Override public Money quote(Span period) {
        if (segments.stream().mapToLong(segment -> segment.coveredDays(period)).sum() != ChronoUnit.DAYS.between(period.start(), period.end())) {
            throw new IllegalArgumentException("rate gap");
        }
        return segments.stream().map(segment -> segment.charge(period)).reduce(Money::add).orElseThrow();
    }
    @Override public Money extend(Span old, LocalDate newEnd) { return quote(PricingData.extended(old, newEnd)); }
}
