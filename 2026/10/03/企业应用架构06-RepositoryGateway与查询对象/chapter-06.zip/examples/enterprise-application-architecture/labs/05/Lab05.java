package enterprise.chapter05;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.SQLException;
import java.time.Instant;
import java.util.Currency;
import enterprise.sql.Check;
import enterprise.sql.Contract;
import enterprise.sql.Sql;
import rental.RentalDesk.EquipmentId;
import rental.RentalDesk.Period;
import rental.domain.Money;

public final class Lab05 {
    private Lab05() { }
    public static Contract sample(String id, String equipment) {
        return new Contract("T1", id, new EquipmentId(equipment), new Period(Instant.parse("2026-10-03T10:00:00.123456789Z"), Instant.parse("2026-10-03T11:30:00.123456789Z")),
                new Money(new BigDecimal("25.00"), Currency.getInstance("CNY")), Contract.State.RESERVED, 0);
    }
    public static void main(String[] args) throws Exception {
        String url = "jdbc:h2:" + Path.of(args[0]).toAbsolutePath();
        Sql.migrate(url, Path.of(args[1]));
        var mapper = new ContractMapper();
        int writeConnection;
        try (Sql db = Sql.open(url)) {
            writeConnection = db.id();
            db.update("INSERT INTO equipment(tenant_id,equipment_id,category,state) VALUES(?,?,?,?)", "T1", "E1", "camera", "ACTIVE");
            new ActiveContract(sample("AR", "E1")).insert(db);
            mapper.insert(db, sample("DM", "E1"));
            db.commit();
            Check.that("one explicit data commit", db.commits() == 1);
        }
        try (Sql fresh = Sql.open(url)) {
            Check.that("read uses new JDBC connection", fresh.id() != writeConnection);
            Check.that("Active Record nanosecond/time/money/identity roundtrip", ActiveContract.find(fresh, "T1", "AR").value().equals(sample("AR", "E1")));
            Check.that("Data Mapper nanosecond/time/money/identity roundtrip", mapper.find(fresh, "T1", "DM").equals(sample("DM", "E1")));
            var ar = ActiveContract.find(fresh, "T1", "AR");
            ar.cancel(); ar.saveState(fresh);
            mapper.saveState(fresh, mapper.find(fresh,"T1","DM").cancel());
            fresh.commit();
        }
        try (Sql fresh = Sql.open(url)) {
            Check.that("both paths cancel and retain history", fresh.count("rental_contract") == 2
                    && ActiveContract.find(fresh,"T1","AR").value().state() == Contract.State.CANCELLED
                    && mapper.find(fresh,"T1","DM").state() == Contract.State.CANCELLED);
        }
        for (String style : new String[]{"AR", "DM"}) {
            try (Sql db = Sql.open(url)) {
                db.update("INSERT INTO equipment(tenant_id,equipment_id,category,state) VALUES(?,?,?,?)", "T1", "staged-" + style, "camera", "ACTIVE");
                try {
                    if (style.equals("AR")) new ActiveContract(sample("bad-AR", "missing")).insert(db);
                    else mapper.insert(db, sample("bad-DM", "missing"));
                    throw new AssertionError("invalid FK accepted");
                } catch (SQLException failure) {
                    Check.that(style + " invalid association rejected SQLSTATE23506", failure.getSQLState().equals("23506"));
                    db.rollback();
                }
            }
            try (Sql fresh = Sql.open(url)) { Check.that(style + " rollback removes staged equipment and contract", fresh.count("equipment") == 1 && fresh.count("rental_contract") == 2); }
        }
        try {
            var valid = sample("bad-money", "E1");
            new Contract(valid.tenant(), valid.id(), valid.equipment(), valid.period(), new Money(new BigDecimal("-0.01"), Currency.getInstance("CNY")), valid.state(), 0);
            throw new AssertionError("negative total accepted");
        } catch (IllegalArgumentException expected) { Check.that("domain refuses negative persisted total", true); }
        try (Sql db = Sql.open(url)) {
            mapper.insert(db, sample("before-check-failure", "E1"));
            try {
                db.update("UPDATE rental_contract SET amount=-1 WHERE tenant_id=? AND contract_id=?", "T1", "before-check-failure");
                throw new AssertionError("negative database amount accepted");
            } catch (SQLException failure) {
                Check.that("database CHECK rejects bypass SQLSTATE23513", failure.getSQLState().equals("23513"));
                db.rollback();
            }
        }
        try (Sql fresh = Sql.open(url)) {
            Check.that("CHECK failure rollback leaves no partial contract", fresh.count("rental_contract") == 2 && fresh.count("contract_line") == 0);
            Check.that("JDBC statements and result sets closed", fresh.resources() == 0);
        }
        Check.result("05");
    }
}
