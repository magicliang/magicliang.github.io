# 企业应用架构00：冻结语义与追踪

来源提交：ed5a420a0189945118b8b0211f6da39e989a453d，冻结标识27-v1。来源examples/software-modeling；副本rental-core/frozen-27。19个源文件、完整来源/副本路径及SHA-256见baseline-manifest.json。逐字节核对实际提交及当前上游文件后复制，不能编辑副本或静默升级。import-baseline.py为维护脚本，需要原仓库；下载运行仅需verify-baseline.py，不访问上游或git。

## 已确认与未决语义

|范围|冻结内容|证据/限制|
|---|---|---|
|设备身份|EquipmentId非空白，Equipment按ID相等；ACTIVE出租，退役不可恢复|24原实体和27用例；非全局设备注册证明|
|金额币种|CNY/USD，scale2精确、不自动舍入；混币加法及报价覆盖比较拒绝|Money、E00-10；非换汇/付款|
|租期|Instant非空半开区间；相邻不冲突；提前1h/最长48h|原BaselineCheck及ApplicationCheck|
|价格有效期|费率修订与金额随命令和草案保存；27没有有效期价格表|不能伪填有效起止；01分段日价是隔离的新教学规则|
|维修禁租|可信翻译后的BLOCKED/REVIEW_REQUIRED拒绝，RELEASED只解除限制|E00-09及原应用；不联网、不持久维修状态|
|请求|一个仓储状态全局RequestId；相同完整负载回历史、变负载拒绝|E00-03/05/06/11；rate/revision参与负载|
|合同状态|不可变草案，无签署/履约状态机|不能用设备状态冒充合同生命周期|
|取消/退款|取消活跃承诺，保留草案和历史；退款未实现|E00-04/05，原应用故障测试|
|事务/消息|单实例内存快照替换；提交后发布可丢失，重放不补发|原ApplicationCheck故障断言；无可靠消息|

## 本章场景映射

EnterpriseBaseline的E00-01至E00-12分别为确认、重叠拒绝、重试、取消、取消后重放、历史拒绝、换ID新意图、报价、维修限制、混币、变负载、活跃数。调用冻结应用与Direct受限直接过程，比较共同子集的返回/最终活跃数；报价还与冻结PricingService结果比较。Direct只模拟固定ACTIVE的E1，不代表对上游全部状态的等价证明。上游48+36断言原封不动复跑，覆盖更广的生命周期和故障边界。

`run.sh --mutant`故意跳过Direct占用检查，E00-02 expected=OVERLAP_REJECTED actual=CONFIRMED，必须退出1；正常run.sh退出0。币种错误经真实RentalContract.covers抛异常，不比较单独的货币字符串。
