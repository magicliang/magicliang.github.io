# 05 contract

Same file DB/schema-v1 and same sample contract values for ActiveContract and ContractMapper. Shared immutable Contract delegates frozen Money/Period/EquipmentId; Contract adds nonnegative and DECIMAL(19,2) range. Business cancel preserves quote and interval. ActiveContract owns writes/find/state save; Mapper separates SQL from Contract. Shared row decoder is explicit constrained comparison.

New physical JDBC connections read and compare full values including 9 fractional second digits, currency, identity and status. Both styles fail actual FK23506 after a staged equipment insert and rollback; new connection finds only original1 equipment/2 contracts. Direct SQL negative amount produces CHECK23513 after valid contract insert; explicit rollback removes it. Domain negative total separately rejected. 13 assertions.

Boundary: no full application Repository adapter, idempotency/request history/event outbox persistence, SQL overlap exclusion, optimistic version check or restart proof. DDL is outside data transaction. H2 version/runtime/schema/hash in sql-support/v1 and evidence. No old frozen core bytes changed.
