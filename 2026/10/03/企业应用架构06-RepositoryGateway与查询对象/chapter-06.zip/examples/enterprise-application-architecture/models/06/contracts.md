# 06 contract

EquipmentRepository.available returns immutable candidate EquipmentId list. Mandatory tenant/category/Period and allowlisted ID_ASC/ID_DESC. AvailabilityQuery.compile interprets those values into SQL Plan(sql,immutable bound parameters); no raw field or arbitrary SQL support. Predicate is ACTIVE/no RESERVED overlap using half-open strict comparisons, NOT EXISTS avoids duplicate equipment. Does not check repair, advance notice, maximum duration or lock candidates; final reservation must revalidate.

Known data: T1 E1 busy; E2 two cancelled histories; E3 adjacent interval; E4 RETIRED. T2 OTHER, quoted category QUOTE. Exact expected E2,E3. 8 checks; empty inputs/sort rejected, quote treated as bound value, descending exact. Three actual SQL mutants each expected exit1/AssertionError: omit tenant=>E2,E3,OTHER; omit time=>E2; join cancelled=>E2,E2,E3. sql-support closes JDBC resources.

InventoryGateway reads separate actual H2 file DB external_stock by warehouse/category, returns3, rentalDB stays6 equipment. Missing external row errors; not HTTP/network/auth/retry/distributed transaction. No complete tenant security proof or full application persistent Repository.
