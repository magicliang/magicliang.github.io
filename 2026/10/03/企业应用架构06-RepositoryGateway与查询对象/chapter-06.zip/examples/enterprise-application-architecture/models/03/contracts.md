# 03：端口与适配器编译契约

实际采用 Hexagonal 的内外边界。`RentalUseCase` 仅使用冻结27应用端口及02服务；内层先编译，classpath无新适配器；文件适配器随后依赖内层编译。冻结27原有MemoryRepository仍在原文件，未宣称整个旧应用完成物理分层。

输入：与02相同Command/Instant；输出与存储历史遵守27-v1。可替换点为MaintenancePort，文件协议是已译成租赁语言的 `E1=RELEASED` 或 `BLOCKED`，不是任意供应商维修DTO。每次新请求实际读文件；未知值抛IllegalArgumentException，缺文件抛UncheckedIOException；异常不提交快照。历史请求先回放，因此无需文件可用。

正例：内存/文件结果、最终快照、事件序列相同；文件变更生效；未知值状态不变；删除文件后旧请求回放成功，共6断言，加原48+36。

负例：StorageLeak与DisplayLeak两个真实Java文件分别导入文件实现与显示DTO；仅有内层classpath时javac退出1。正常外层先成功编译，失败原因是规定依赖集拒绝外层类型，不是缺源文件。该检查只约束执行此构建的代码，不是运行期安全沙箱。

命令：`bash examples/enterprise-application-architecture/labs/03/run.sh`；后附 `--storage-leak`、`--display-leak` 是预期失败入口。无SQL、网络、重启持久性或性能证明。
