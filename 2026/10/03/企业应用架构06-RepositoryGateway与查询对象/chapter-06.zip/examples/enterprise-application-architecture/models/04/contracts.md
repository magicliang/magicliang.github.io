# 04：同进程模块契约

实际Java21 JPMS模块：enterprise.maintenance拥有RepairStore，仅导出api；enterprise.rental拥有RentalState/MemoryRepository，仅导出api；enterprise.settlement只接收RentalApi.Result；enterprise.demo为组装/测试入口。rental.legacy临时封装冻结27的原字节Java源码，只向enterprise.rental限定导出rental/domain/application；不改冻结源码。

维修命令RepairService.report(String,Result)仅修改本模块内存事实。Result的WORKING/INSPECTION_FAILED译成租赁BLOCKED，RETURNED_AFTER_PASS译成RELEASED，仅解除维修限制。租赁仍自行检查ACTIVE、提前量/租期、占用；全局RequestId回放优先。RentalApi.reserve返回immutable Result(status,amount,currency)；cancel保留历史。SettlementView仅格式化公开结果，没有账本、收款或退款功能。

依赖：demo→rental/settlement；settlement→rental；rental→maintenance/legacy。public API含另一模块类型的边以requires transitive表达。维修不读租赁；结算不导入内部仓储。四个负例临时注入跨模块日历仓储访问、设备修改、结算读取内部状态、maintenance→rental成环；每次先成功编译干净模块图，再拒绝非法源码。

事务：repair.report与后续reserve是两个同步调用，不存在跨模块原子事务。租赁一次命令由27内存快照事务决定提交；维修读取是同步输入，并发维修变化未锁定。演示publisher为空回调，不增加可靠消息保证；原27断点检查另随基线运行。缺维修事实抛异常，不默认放行。

边界：同JVM、内存状态、可信调用者、无鉴权。JPMS编译限制可被显式add-exports等启动参数改变，不是租户隔离。模块划分是教学选择，不宣称与真实组织限界上下文一一对应，不证明独立部署或进程故障隔离。
