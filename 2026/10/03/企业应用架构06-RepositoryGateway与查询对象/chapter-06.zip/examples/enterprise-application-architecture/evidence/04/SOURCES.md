# 实际核验的一手资料

2026-10-03 使用web打开以下原文。

- Fowler https://martinfowler.com/bliki/MonolithFirst.html ：单体起步讨论，明确API/数据模块性重要，不保证任意单体容易拆微服务。
- Evans https://www.domainlanguage.com/wp-content/uploads/2016/05/DDD_Reference_2015-03.pdf ：Bounded Context，印刷页2/PDF第9页，明确模型适用范围及边界；不等同Java包或部署单元。
- JLS21 https://docs.oracle.com/javase/specs/jls/se21/html/jls-7.html ：§7.7.1 requires/transitive，直接或间接依赖自身导致解析编译失败；§7.7.2 exports/opens，qualified exports仅指定模块可访问。原始网页行568–582/646–658实际读到。§7.7.3是Service Consumption，未误引作exports章节。
- Java21 https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/lang/module/ModuleDescriptor.html ：显式/自动模块、qualified/unqualified export声明模型。

JPMS只是本章执行访问约束的技术选择；同JVM、空publisher、结算视图、可信调用者等均为本章教学限制，不归于Fowler或Evans原文。
