# 正文预落盘扫描

入口blog-editor，草稿先写article-draft.md。anti-ai-tone tech检查0errors/0warnings，随后anti-persona-fabrication词项与人工通读，再写正式源文。顺序、时间、散列见两个扫描JSON及publication.json。正文2435汉字，2张Mermaid图；链接目标存在。

人工检查未见虚构第一人称经历、访谈、拟人化、说书人口吻。原作者概念与本章Java教学设计明确区分；依赖编译、同进程内存事务、SQL持久化、部署能力没有混用证据。内存与真实文件适配器：结果/快照/事件相等；文件变更生效；未知值无状态变化；删文件后历史回放，共6项。两个负例分别导入FileMaintenance/DisplayDto，内层classpath拒绝。

正式稿SHA256：66ef437e9cf1df38b0c7957a5bd02fe3a9b06d2f782b9c682d2cf95e8d07ff26。站点与ZIP独立验证由root执行。
