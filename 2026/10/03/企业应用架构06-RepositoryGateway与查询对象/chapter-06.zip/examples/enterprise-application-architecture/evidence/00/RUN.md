# 00 原始实验

依赖：JDK21（实测Corretto21.0.11）、Bash、Python3标准库；无第三方Java依赖。实际环境见environment.txt；编译 --release 21 -Xlint:all -Werror。

入口：`bash examples/enterprise-application-architecture/run-lab.sh 00`。具体每个场景的参数保存在*.command.json；输出分别为*.stdout.txt/*.stderr.txt，真实退出码为*.exit.txt。

normal退出0：原48+36和本章12项；overlap-mutant退出1，在E00-02真实观察OVERLAP_REJECTED与CONFIRMED不同。输入为EnterpriseBaseline里的请求，均复用固定ApplicationCheck NOW/金额。import.txt/import.exit记录19文件与实际提交逐字节一致。

脱离checkout复跑：.omo/evidence/enterprise-00-04/portable.py复制rental-core/labs/models/run-lab.sh至新临时目录，切换cwd后执行本章入口。standalone.json给出退出码，原始输出为standalone.stdout.txt/standalone.stderr.txt。不需要上游checkout或git。

仅内存业务实验；没有SQL、进程持久化恢复、真实维修网络、支付或消息runtime。01的日价规则不修改00冻结应用，02仍小时计费。站点/ZIP/浏览器验收由主任务另记。stdout.txt/stderr.txt/exit.txt若存在，为初次开发运行；本次正式场景以normal.*和source-sha256.json为准。
