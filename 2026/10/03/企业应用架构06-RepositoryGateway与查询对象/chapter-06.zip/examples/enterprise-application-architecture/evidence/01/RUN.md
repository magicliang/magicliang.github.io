# 01 原始实验

依赖：JDK21（实测Corretto21.0.11）、Bash、Python3标准库；无第三方Java依赖。实际环境见environment.txt；编译 --release 21 -Xlint:all -Werror。

入口：`bash examples/enterprise-application-architecture/run-lab.sh 01`。具体每个场景的参数保存在*.command.json；输出分别为*.stdout.txt/*.stderr.txt，真实退出码为*.exit.txt。

normal退出0：before旧规则25项、新规则28项；old-contract退出1在cross effective date；omitted-extension退出1在extension total。输入为PricingCheck.rates/span及models/01/contracts.md的日期与金额；延期漏改执行真实旧算法。三个.diff为实际源文件比较。

脱离checkout复跑：.omo/evidence/enterprise-00-04/portable.py复制rental-core/labs/models/run-lab.sh至新临时目录，切换cwd后执行本章入口。standalone.json给出退出码，原始输出为standalone.stdout.txt/standalone.stderr.txt。不需要上游checkout或git。

仅内存业务实验；没有SQL、进程持久化恢复、真实维修网络、支付或消息runtime。01的日价规则不修改00冻结应用，02仍小时计费。站点/ZIP/浏览器验收由主任务另记。stdout.txt/stderr.txt/exit.txt若存在，为初次开发运行；本次正式场景以normal.*和source-sha256.json为准。
