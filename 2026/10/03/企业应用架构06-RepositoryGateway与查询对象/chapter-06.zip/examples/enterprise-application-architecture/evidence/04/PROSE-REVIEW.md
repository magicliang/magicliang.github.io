# 正文预落盘扫描

入口blog-editor，草稿先写article-draft.md。anti-ai-tone tech检查0errors/0warnings，随后anti-persona-fabrication词项与人工通读，再写正式源文。顺序、时间、散列见两个扫描JSON及publication.json。正文2504汉字，2张Mermaid图；链接目标存在。

人工检查未见虚构第一人称经历、访谈、拟人化、说书人口吻。原作者概念与本章Java教学设计明确区分；依赖编译、同进程内存事务、SQL持久化、部署能力没有混用证据。实际JPMS模块7项业务轨迹；四个负例先编译干净图，再注入非法依赖，分别触发仓储/设备/结算内部包不可见与模块循环。

正式稿SHA256：de2f0e58fe4752d9d99bffed7e476e79cc3d2443468a09ba1cfb55a3613702d1。站点与ZIP独立验证由root执行。
