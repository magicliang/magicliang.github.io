# 原始来源

2026-10-03通过web实际打开并读取，正文只使用公开摘要，不声称取得付费章节全文。

- https://martinfowler.com/eaaCatalog/
  Fowler原作者目录，2003-03-05，实际读取领域逻辑、数据源、对象关系行为、展示等分类；摘要入口不替代全书。

- https://www.domainlanguage.com/wp-content/uploads/2016/05/DDD_Reference_2015-03.pdf
  Evans 2015 DDD Reference，实际读取印刷页17 Repository；仅用于领域访问隔离，不推导本实验事务保证。

业务参数和实验结果由本章代码产生，不归于模式作者。
