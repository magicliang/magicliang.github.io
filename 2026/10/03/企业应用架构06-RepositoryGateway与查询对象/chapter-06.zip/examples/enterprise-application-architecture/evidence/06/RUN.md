# Run 06

`bash examples/enterprise-application-architecture/labs/06/run.sh`；JDK21/Python3、首次下载需MavenCentral。sql-support/v1/h2.json冻结版本/URL/SHA，H2_JAR或ARCHITECTURE_TOOL_CACHE/MODELING_TOOL_CACHE覆盖仍校验SHA。jar不入包。

normal.command.json/stdout.txt/stderr.txt/exit.txt记录真实调用/SQL/结果；environment.txt保存环境。standalone.*在独立临时根用已验证外部工具缓存运行，创建新文件DB，无源checkout依赖。source-sha256.json绑定源码和SQL支持。

models/06/contracts.md为范围与限制。原始SQL追踪来自JDBC执行前、实际affected行数和commit/rollback调用后；故障SQLSTATE来自SQLException。不是示意日志，不证明进程重启或生产数据库行为。
