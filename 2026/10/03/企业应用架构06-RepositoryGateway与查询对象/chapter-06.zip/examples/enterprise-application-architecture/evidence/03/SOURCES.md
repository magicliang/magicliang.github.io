# 实际核验的一手资料

2026-10-03 使用web打开全文后撰写，未把搜索摘要当规范。

- Cockburn https://alistair.cockburn.us/hexagonal-architecture/ ：页面标original2005 article/HaT Technical Report 2005.02；inside/outside、端口的有意义交互、多适配器、六边形不要求六端口。文件适配是本章实现，不宣称原文指定本例结构。
- Evans https://www.domainlanguage.com/wp-content/uploads/2016/05/DDD_Reference_2015-03.pdf ：Layered Architecture，印刷页10/PDF第17页；分离领域、UI、应用协调、基础设施；可用Hexagonal实现隔离。正文用此一手分层说明，PoEAA整体来源继承00。
- Palermo https://jeffreypalermo.com/2008/07/the-onion-architecture-part-1/ ：2008-07-29，领域模型中心，接口内侧、基础设施外圈、向内依赖。
- Martin https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html ：2012-08-13 Dependency Rule，源码向内，外侧格式不进入内侧；控制流与源码依赖分开。

正文对四种方式作关注点比较，仅实际采用Hexagonal新增边界；没有宣称完整迁移旧核心或四种框架同时实现。
