# 实际运行记录

环境与版本：environment.txt；JDK21严格 --release 21 -Xlint:all -Werror；Python3仅stdlib；没有新Java依赖。

正常命令：`bash examples/enterprise-application-architecture/labs/04/run.sh`。normal.command.json逐字记录参数；normal.stdout.txt、normal.stderr.txt、normal.exit.txt保存原始结果。正常exit0，含原48+36和本章7项。

实际JPMS模块7项业务轨迹；四个负例先编译干净图，再注入非法依赖，分别触发仓储/设备/结算内部包不可见与模块循环。

- `bash examples/enterprise-application-architecture/labs/04/run.sh --state-write`：预期exit1；见state-write.stdout.txt/stderr.txt/exit.txt/command.json；失败来自编译诊断，不是缺文件或脚本异常。
- `bash examples/enterprise-application-architecture/labs/04/run.sh --device-write`：预期exit1；见device-write.stdout.txt/stderr.txt/exit.txt/command.json；失败来自编译诊断，不是缺文件或脚本异常。
- `bash examples/enterprise-application-architecture/labs/04/run.sh --settlement-read`：预期exit1；见settlement-read.stdout.txt/stderr.txt/exit.txt/command.json；失败来自编译诊断，不是缺文件或脚本异常。
- `bash examples/enterprise-application-architecture/labs/04/run.sh --cycle`：预期exit1；见cycle.stdout.txt/stderr.txt/exit.txt/command.json；失败来自编译诊断，不是缺文件或脚本异常。

独立复制后的复跑：standalone.stdout.txt/stderr.txt/json，保留examples/enterprise-application-architecture前缀，无上游checkout或Git依赖。source-sha256.json记录本章源码。

模型/API/边界见models/04/contracts.md。外部文件不是数据库；模块编译不是运行期安全隔离。SQL、跨连接事务、重启持久化、消息runtime均未验证。
