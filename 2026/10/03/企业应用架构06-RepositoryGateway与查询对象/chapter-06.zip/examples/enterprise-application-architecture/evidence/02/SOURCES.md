# 原始来源

2026-10-03通过web实际打开并读取，正文只使用公开摘要，不声称取得付费章节全文。

- https://martinfowler.com/eaaCatalog/serviceLayer.html
  PoEAA原始模式页，署名Randy Stafford，2003-03-05；实际读取统一可用操作和交互协调的定义；不把署名改成Fowler。

业务参数和实验结果由本章代码产生，不归于模式作者。
