# 原始来源

2026-10-03通过web实际打开并读取，正文只使用公开摘要，不声称取得付费章节全文。

- https://martinfowler.com/eaaCatalog/transactionScript.html
  原作者摘要：按请求过程组织，可提取公共子过程。

- https://martinfowler.com/eaaCatalog/domainModel.html
  原作者摘要：数据和行为组成领域对象模型。

- https://martinfowler.com/eaaCatalog/tableModule.html
  原作者摘要：一个模块实例处理表/视图多行；本实现仅内存行集，不声称SQL实验。

业务参数和实验结果由本章代码产生，不归于模式作者。
