# 实际运行记录

环境与版本：environment.txt；JDK21严格 --release 21 -Xlint:all -Werror；Python3仅stdlib；没有新Java依赖。

正常命令：`bash examples/enterprise-application-architecture/labs/03/run.sh`。normal.command.json逐字记录参数；normal.stdout.txt、normal.stderr.txt、normal.exit.txt保存原始结果。正常exit0，含原48+36和本章6项。

内存与真实文件适配器：结果/快照/事件相等；文件变更生效；未知值无状态变化；删文件后历史回放，共6项。两个负例分别导入FileMaintenance/DisplayDto，内层classpath拒绝。

- `bash examples/enterprise-application-architecture/labs/03/run.sh --storage-leak`：预期exit1；见storage-leak.stdout.txt/stderr.txt/exit.txt/command.json；失败来自编译诊断，不是缺文件或脚本异常。
- `bash examples/enterprise-application-architecture/labs/03/run.sh --display-leak`：预期exit1；见display-leak.stdout.txt/stderr.txt/exit.txt/command.json；失败来自编译诊断，不是缺文件或脚本异常。

独立复制后的复跑：standalone.stdout.txt/stderr.txt/json，保留examples/enterprise-application-architecture前缀，无上游checkout或Git依赖。source-sha256.json记录本章源码。

模型/API/边界见models/03/contracts.md。外部文件不是数据库；模块编译不是运行期安全隔离。SQL、跨连接事务、重启持久化、消息runtime均未验证。
