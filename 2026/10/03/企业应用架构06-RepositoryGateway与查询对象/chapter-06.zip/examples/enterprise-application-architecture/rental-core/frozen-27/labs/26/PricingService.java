package rental.domain;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.Objects;
import rental.RentalDesk.Period;

public final class PricingService {
    public record HourlyRate(String revision, Money price) {
        public HourlyRate {
            Objects.requireNonNull(revision, "revision");
            Objects.requireNonNull(price, "price");
            if (revision.isBlank() || price.amount().signum() < 0) {
                throw new IllegalArgumentException("invalid hourly rate");
            }
        }
    }

    public Money quote(Period period, HourlyRate rate) {
        Objects.requireNonNull(period, "period");
        Objects.requireNonNull(rate, "rate");
        Duration duration = Duration.between(period.start(), period.end());
        long hours = duration.getSeconds() / 3600;
        if (duration.getSeconds() % 3600 != 0 || duration.getNano() != 0) hours++;
        return new Money(rate.price().amount().multiply(BigDecimal.valueOf(hours)), rate.price().currency());
    }
}
