package rental.domain;

import java.time.Instant;
import java.util.Objects;
import rental.RentalDesk.ReserveRequest;
import rental.domain.PricingService.HourlyRate;

public final class RentalContract {
    public record Snapshot(ReserveRequest request, HourlyRate rate, Money total) {
        public Snapshot {
            Objects.requireNonNull(request, "request");
            Objects.requireNonNull(rate, "rate");
            Objects.requireNonNull(total, "total");
            if (!new PricingService().quote(request.period(), rate).equals(total)) {
                throw new IllegalArgumentException("quote inconsistent with period and rate");
            }
        }
    }

    private final ReserveRequest request;
    private final HourlyRate rate;
    private final Money total;

    private RentalContract(ReserveRequest request, HourlyRate rate, Money total) {
        Snapshot snapshot = new Snapshot(request, rate, total);
        this.request = snapshot.request();
        this.rate = snapshot.rate();
        this.total = snapshot.total();
    }

    public ReserveRequest request() { return request; }
    public HourlyRate rate() { return rate; }
    public Money total() { return total; }

    public Snapshot snapshot() { return new Snapshot(request, rate, total); }

    public static RentalContract restore(Snapshot snapshot) {
        Objects.requireNonNull(snapshot, "snapshot");
        return new RentalContract(snapshot.request(), snapshot.rate(), snapshot.total());
    }

    public boolean covers(Money offered) {
        Objects.requireNonNull(offered, "offered");
        if (!total.currency().equals(offered.currency())) throw new IllegalArgumentException("currency mismatch");
        return offered.amount().compareTo(total.amount()) >= 0;
    }

    public static final class Factory {
        private final RentalPeriodSpecification specification;
        private final PricingService pricing;

        public Factory(RentalPeriodSpecification specification, PricingService pricing) {
            this.specification = Objects.requireNonNull(specification, "specification");
            this.pricing = Objects.requireNonNull(pricing, "pricing");
        }

        public RentalContract create(ReserveRequest request, HourlyRate rate, Instant now) {
            Objects.requireNonNull(request, "request");
            RentalPeriodSpecification.Result result = specification.evaluate(request.period(), now);
            if (result != RentalPeriodSpecification.Result.SATISFIED) {
                throw new IllegalArgumentException("rental period: " + result);
            }
            return new RentalContract(request, rate, pricing.quote(request.period(), rate));
        }
    }
}
