# 24：供累计应用采用的契约

实现文件为labs/24的rental.domain.Equipment、EquipmentDescription、Money，编译直接复用未改动的rental-core/RentalDesk.java之EquipmentId和Period。run.sh同时编译执行原始labs/00/BaselineCheck.java，严格 --release 21 -Xlint:all -Werror。

## 设备实体

- 身份为RentalDesk.EquipmentId，完全沿用其非空白字符串和record相等语义，不自行trim、大小写折叠或换ID类型。设备ID跨租赁应用的唯一性由未来仓储/导入边界保障，本类不分配全局ID。
- Equipment按同设备ID equals/hashCode，状态/描述不参与；对象引用不同也可表示同一设备。比较状态须比较Snapshot，不得由equals推断版本或并发新旧。
- 新建状态INSPECTION_REQUIRED；approveInspection仅允许INSPECTION_REQUIRED→ACTIVE；requireInspection仅允许ACTIVE→INSPECTION_REQUIRED；retire允许前两态→RETIRED，RETIRED不可恢复；重复审批/退役拒绝。身份无setter；非退役设备允许changeDescription。
- Snapshot不可变，restore从可信快照恢复任一有效状态，不经过新建审批流；restore不是对不可信输入的授权接口。只保证内存往返，无Repository、持久化、锁或乐观版本。
- EquipmentDescription按model与有序tags列表值相等；List.copyOf复制容器，元素String不可变；不承诺任意可变元素的深拷贝。

## 金额与租期

- Money支持CNY/USD，精确规范到2位小数，UNNECESSARY拒绝精度损失；允许正、零、负金额，不代表收款/退款已发生；等值金额须同币种，add混币拒绝，无汇率或自动舍入。
- RentalDesk.Period仍为Instant起止、非空半开区间；区间相邻不重叠。没有新增LocalDate/DST或清洁缓冲规则。

## 后续应用接入义务

24未在RentalDesk.reserve前加入生命周期检查，实验刻意证明RETIRED设备ID仍会被旧核心接受，这是已知集成缺口。后续应用应先按ID取得设备，检查ACTIVE；再结合23的维修翻译结果（RELEASED仅解除维修侧限制）与请求租期占用判断。不要将维修DTO状态直接写成Equipment.State，也不要把ACTIVE直接当作某租期可用。

仓储落地须保证ID唯一并明确快照新旧/并发策略；请求重放仍保持00同ID同负载返回原回执、变负载拒绝、取消保留旧回执。生命周期变化对旧回执重放的优先级需由应用用例显式选择和测试，24不提前改变基线。

四色描述概念角色；Entity/Value Object选择取决于上下文中的身份连续性和相等语义，没有颜色到DDD战术类型的自动转换。此处设备为Entity，描述/金额/租期为VO；规格修订是否需要独立身份必须另定。
