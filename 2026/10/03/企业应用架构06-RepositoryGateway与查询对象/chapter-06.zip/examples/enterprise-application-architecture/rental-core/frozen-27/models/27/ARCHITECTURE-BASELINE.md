# 27：累计应用与架构系列基线

版本：27-v1。源码 `rental-application/RentalApplication.java`，package `rental.application`；Java 21，无第三方库。直接编译 24 Equipment/EquipmentDescription/Money、25 ReservationCalendar、26 PricingService/RentalPeriodSpecification/RentalContract，不复制或修改它们；旧 rental-core/RentalDesk.java 和 labs/00/BaselineCheck.java 保持原样。

## 应用边界

- `Command(ReserveRequest request, HourlyRate rate)` 是完整重放负载；RequestId 在一个 Repository 的整个应用状态内唯一，跨设备也共享。相同 ID / 相同 request 和 rate 返回历史 Status；改变设备、租期、费率值或 revision 抛 IllegalArgumentException。NOW、维修评估是当次环境输入，不参与命令指纹。所谓全局只指这一个 Repository 实例的应用范围，不是全球或跨部署注册表。
- `reserve(Command, Instant now)`：先查应用 receipts，历史回放优先于当前设备、维修端口、时间规则；新请求向 MaintenancePort 取可信翻译结果，检查设备存在、ACTIVE、维修 RELEASED、26 租期规则，然后 Factory 建草案、25 日历原子判断占用；CONFIRMED 保存草案快照，其余业务拒绝只存历史回执。技术异常不消费 ID。
- `Status` 为 CONFIRMED / OVERLAP_REJECTED / UNKNOWN_EQUIPMENT / INELIGIBLE / MAINTENANCE_RESTRICTED / INVALID_PERIOD。后四类新增业务拒绝也记忆；日历只记录到达占用判断的请求。
- `cancel(RequestId)` 对活跃承诺返回 true，其余 false；只解除占用，保留应用和日历历史回执、合同草案。取消后重放旧确认只返回历史，不能重占用。取消不是退款/销毁合同。
- Factory 参数固定 minimumLead=1h / maximumDuration=48h，报价沿用26精确小时向上取整；参数由组装代码注入。草案不是法律签约或付款事实。

## 端口与内存提交

`Repository.read(): Snapshot` 和 `<T> T transact(Function<Session,T>)`；`Snapshot` 保存 equipment map、calendar Snapshot、global receipts map、contracts map。只接受本应用生成的可信完整快照，不是外部导入协议，不认证来源，不全面审计跨 map 对应关系。`Session.equipment(id)` 支持在事务中调用24设备生命周期操作。

`MemoryRepository` 对单实例 transact 加 synchronized，在独立 Session 中恢复对象，操作结束后复制不可变快照，一次替换 committed。返回实体引用不会穿透快照；重新构造仓储后可恢复相同状态。操作/快照构造/BEFORE_COMMIT 抛错时 committed 原样保留；嵌套事务拒绝。锁只覆盖本仓储实例；两个实例或进程不共享锁。不是数据库 Repository、崩溃持久化或分布式事务。事务回调不能包含外部写副作用；本实验只同步读维修端口。

`MaintenancePort.assess(EquipmentId): Maintenance` 由调用方提供已按23防腐层翻译的 RELEASED/BLOCKED/REVIEW_REQUIRED，非原始维修DTO。这里没有运行Python适配器、网络协议、维修状态持久化或新鲜度保障；null/技术异常回滚，不伪装成业务许可。RELEASED只解除维修限制，不能替代ACTIVE或空闲租期。

`AdmissionPolicy.reject(Equipment,Maintenance,Period,Instant,RentalPeriodSpecification)` 返回资格/时间拒绝 Status 或 null；受信的策略扩展点。27 InlineAdmission 固定拒绝优先级：UNKNOWN、INELIGIBLE、MAINTENANCE_RESTRICTED、INVALID_PERIOD；28 可替换等价实现。它不是授权外部代码任意注入规则的安全接口。

## 事件缺口

`Publisher.publish(Event)`；`Event(kind,RequestId)` 为同步内存通知，当前 kind 为 ReservationConfirmed / ReservationCancelled，只在实际成功变化提交后生成发布调用。拒绝、重复 reserve 和重复 cancel 不发布。

`Fault.hit(Point)` 的 BEFORE_COMMIT 位于仓储最终赋值前，AFTER_COMMIT 位于应用提交返回后/Publisher调用前；Publisher也可抛异常。提交后失败不能回滚，重新取仓储仍看到占用、回执和草案。历史重放不补发丢失事件。本实现没有 outbox、事件存储、消息代理、投递回执、去重消费者或可靠消息保证。跨请求的发布顺序也没有锁保证。

## 验证入口

将 JAVA_HOME 指向 JDK21 后执行 `bash examples/software-modeling/labs/27/run.sh`。严格 --release 21 -Xlint:all -Werror；原始基线48项和ApplicationCheck36项。原始输出/退出码位于 evidence/27/run.txt、run.exit。故障点真实抛异常，检查仓储重新读取/恢复后的二元结果，不以日志文本替代断言。

后续架构系列可以替换 Repository、维修端口、Publisher 或组装方式；先保留全局重放、完整命令指纹、取消历史、纯领域构造和明确提交点，再分别验证持久化、并发与发布保证。若引入跨仓储事务、outbox 或规则版本迁移，需要新契约与实验，不能从当前内存结果推导。
