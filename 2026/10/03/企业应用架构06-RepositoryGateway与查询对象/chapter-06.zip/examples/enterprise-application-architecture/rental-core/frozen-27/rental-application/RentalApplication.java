package rental.application;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import rental.RentalDesk.EquipmentId;
import rental.RentalDesk.Outcome;
import rental.RentalDesk.Period;
import rental.RentalDesk.RequestId;
import rental.RentalDesk.ReserveRequest;
import rental.domain.Equipment;
import rental.domain.PricingService;
import rental.domain.PricingService.HourlyRate;
import rental.domain.RentalContract;
import rental.domain.RentalPeriodSpecification;
import rental.domain.ReservationCalendar;

public final class RentalApplication {
    public enum Maintenance { RELEASED, BLOCKED, REVIEW_REQUIRED }
    public enum Status { CONFIRMED, OVERLAP_REJECTED, UNKNOWN_EQUIPMENT, INELIGIBLE, MAINTENANCE_RESTRICTED, INVALID_PERIOD }
    public enum Point { BEFORE_COMMIT, AFTER_COMMIT }
    public record Command(ReserveRequest request, HourlyRate rate) {
        public Command { Objects.requireNonNull(request); Objects.requireNonNull(rate); }
    }
    public record Receipt(Command command, Status status) {
        public Receipt { Objects.requireNonNull(command); Objects.requireNonNull(status); }
    }
    public record Event(String kind, RequestId requestId) {
        public Event { Objects.requireNonNull(kind); Objects.requireNonNull(requestId); }
    }
    public record Snapshot(Map<EquipmentId, Equipment.Snapshot> equipment,
                           ReservationCalendar.Snapshot calendar,
                           Map<RequestId, Receipt> receipts,
                           Map<RequestId, RentalContract.Snapshot> contracts) {
        public Snapshot {
            equipment = Map.copyOf(equipment);
            Objects.requireNonNull(calendar);
            receipts = Map.copyOf(receipts);
            contracts = Map.copyOf(contracts);
        }
    }
    @FunctionalInterface public interface MaintenancePort { Maintenance assess(EquipmentId id); }
    @FunctionalInterface public interface Publisher { void publish(Event event); }
    @FunctionalInterface public interface Fault { void hit(Point point); }
    @FunctionalInterface public interface AdmissionPolicy {
        Status reject(Equipment equipment, Maintenance maintenance, Period period, Instant now,
                      RentalPeriodSpecification specification);
    }
    public interface Repository {
        Snapshot read();
        <T> T transact(Function<Session, T> operation);
    }
    public static final class Session {
        private final Map<EquipmentId, Equipment> equipment = new HashMap<>();
        private final ReservationCalendar calendar;
        private final Map<RequestId, Receipt> receipts;
        private final Map<RequestId, RentalContract> contracts = new HashMap<>();
        private Session(Snapshot source) {
            source.equipment().forEach((id, value) -> equipment.put(id, Equipment.restore(value)));
            calendar = ReservationCalendar.restore(source.calendar());
            receipts = new HashMap<>(source.receipts());
            source.contracts().forEach((id, value) -> contracts.put(id, RentalContract.restore(value)));
        }
        public Equipment equipment(EquipmentId id) { return equipment.get(id); }
        private Snapshot snapshot() {
            Map<EquipmentId, Equipment.Snapshot> equipmentCopies = new HashMap<>();
            equipment.forEach((id, value) -> equipmentCopies.put(id, value.snapshot()));
            Map<RequestId, RentalContract.Snapshot> contractCopies = new HashMap<>();
            contracts.forEach((id, value) -> contractCopies.put(id, value.snapshot()));
            return new Snapshot(equipmentCopies, calendar.snapshot(), receipts, contractCopies);
        }
    }
    public static final class MemoryRepository implements Repository {
        private Snapshot committed;
        private final Fault fault;
        private boolean transactionActive;
        public MemoryRepository(Snapshot initial, Fault fault) {
            this.fault = Objects.requireNonNull(fault);
            committed = new Session(Objects.requireNonNull(initial)).snapshot();
        }
        @Override public synchronized Snapshot read() { return committed; }
        @Override public synchronized <T> T transact(Function<Session, T> operation) {
            if (transactionActive) throw new IllegalStateException("nested transaction unsupported");
            transactionActive = true;
            try {
                Session session = new Session(committed);
                T result = operation.apply(session);
                Snapshot candidate = session.snapshot();
                fault.hit(Point.BEFORE_COMMIT);
                committed = candidate;
                return result;
            } finally {
                transactionActive = false;
            }
        }
    }
    public static final class InlineAdmission implements AdmissionPolicy {
        @Override public Status reject(Equipment equipment, Maintenance maintenance, Period period,
                                       Instant now, RentalPeriodSpecification specification) {
            if (equipment == null) return Status.UNKNOWN_EQUIPMENT;
            if (equipment.state() != Equipment.State.ACTIVE) return Status.INELIGIBLE;
            if (maintenance != Maintenance.RELEASED) return Status.MAINTENANCE_RESTRICTED;
            if (!specification.isSatisfiedBy(period, now)) return Status.INVALID_PERIOD;
            return null;
        }
    }
    private record Change<T>(T value, Event event) { }
    private final Repository repository;
    private final MaintenancePort maintenance;
    private final Publisher publisher;
    private final Fault fault;
    private final AdmissionPolicy admission;
    private final RentalPeriodSpecification specification;
    private final RentalContract.Factory factory;

    public RentalApplication(Repository repository, MaintenancePort maintenance, Publisher publisher,
                             Fault fault, AdmissionPolicy admission, RentalPeriodSpecification specification) {
        this.repository = Objects.requireNonNull(repository);
        this.maintenance = Objects.requireNonNull(maintenance);
        this.publisher = Objects.requireNonNull(publisher);
        this.fault = Objects.requireNonNull(fault);
        this.admission = Objects.requireNonNull(admission);
        this.specification = Objects.requireNonNull(specification);
        factory = new RentalContract.Factory(specification, new PricingService());
    }
    public Status reserve(Command command, Instant now) {
        Objects.requireNonNull(command);
        Objects.requireNonNull(now);
        Change<Status> change = repository.transact(session -> {
            RequestId id = command.request().requestId();
            Receipt old = session.receipts.get(id);
            if (old != null) {
                if (!old.command().equals(command)) throw new IllegalArgumentException("requestId reused with different payload");
                return new Change<>(old.status(), null);
            }
            Maintenance assessment = Objects.requireNonNull(maintenance.assess(command.request().equipmentId()));
            Status rejection = admission.reject(session.equipment(command.request().equipmentId()), assessment,
                    command.request().period(), now, specification);
            if (rejection != null) {
                session.receipts.put(id, new Receipt(command, rejection));
                return new Change<>(rejection, null);
            }
            RentalContract contract = factory.create(command.request(), command.rate(), now);
            Status status = session.calendar.reserve(command.request()) == Outcome.CONFIRMED
                    ? Status.CONFIRMED : Status.OVERLAP_REJECTED;
            if (status == Status.CONFIRMED) session.contracts.put(id, contract);
            session.receipts.put(id, new Receipt(command, status));
            return new Change<>(status, status == Status.CONFIRMED ? new Event("ReservationConfirmed", id) : null);
        });
        publish(change.event());
        return change.value();
    }
    public boolean cancel(RequestId requestId) {
        Objects.requireNonNull(requestId);
        Change<Boolean> change = repository.transact(session -> {
            boolean cancelled = session.calendar.cancel(requestId);
            return new Change<>(cancelled, cancelled ? new Event("ReservationCancelled", requestId) : null);
        });
        publish(change.event());
        return change.value();
    }
    private void publish(Event event) {
        if (event == null) return;
        fault.hit(Point.AFTER_COMMIT);
        publisher.publish(event);
    }
}
