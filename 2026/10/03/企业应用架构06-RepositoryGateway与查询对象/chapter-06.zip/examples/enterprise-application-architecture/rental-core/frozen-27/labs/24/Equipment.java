package rental.domain;

import java.util.Objects;
import rental.RentalDesk.EquipmentId;

public final class Equipment {
    public enum State { INSPECTION_REQUIRED, ACTIVE, RETIRED }

    public record Snapshot(EquipmentId id, EquipmentDescription description, State state) {
        public Snapshot {
            Objects.requireNonNull(id, "id");
            Objects.requireNonNull(description, "description");
            Objects.requireNonNull(state, "state");
        }
    }

    private final EquipmentId id;
    private EquipmentDescription description;
    private State state;

    public Equipment(EquipmentId id, EquipmentDescription description) {
        this(new Snapshot(id, description, State.INSPECTION_REQUIRED));
    }

    private Equipment(Snapshot snapshot) {
        this.id = snapshot.id();
        this.description = snapshot.description();
        this.state = snapshot.state();
    }

    public static Equipment restore(Snapshot snapshot) {
        return new Equipment(Objects.requireNonNull(snapshot, "snapshot"));
    }

    public EquipmentId id() { return id; }
    public EquipmentDescription description() { return description; }
    public State state() { return state; }
    public Snapshot snapshot() { return new Snapshot(id, description, state); }

    public void approveInspection() {
        requireState(State.INSPECTION_REQUIRED);
        state = State.ACTIVE;
    }

    public void requireInspection() {
        requireState(State.ACTIVE);
        state = State.INSPECTION_REQUIRED;
    }

    public void changeDescription(EquipmentDescription next) {
        if (state == State.RETIRED) throw new IllegalStateException("retired equipment");
        description = Objects.requireNonNull(next, "description");
    }

    public void retire() {
        if (state == State.RETIRED) throw new IllegalStateException("already retired");
        state = State.RETIRED;
    }

    private void requireState(State expected) {
        if (state != expected) throw new IllegalStateException("expected " + expected);
    }

    @Override
    public boolean equals(Object other) {
        return this == other || other instanceof Equipment that && id.equals(that.id);
    }

    @Override
    public int hashCode() { return id.hashCode(); }
}
