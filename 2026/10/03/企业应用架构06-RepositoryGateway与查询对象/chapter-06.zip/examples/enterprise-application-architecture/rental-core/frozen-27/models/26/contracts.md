# 26：规则、报价、创建契约

package 均为 `rental.domain`，Java 21，直接编译 labs/24/Money.java；Money 行为保持 24 合同不变。请求/设备身份与 UTC Instant 半开租期复用 RentalDesk 嵌套 records。26 不复制 Money、不修改 24/25/旧核心。

## 可复用 API

- `RentalPeriodSpecification(Duration minimumLead,Duration maximumDuration)`：lead 非负、maximum 严格正。`evaluate(Period,Instant now)` 返回 SATISFIED、TOO_SOON 或 TOO_LONG，优先检查 lead；`isSatisfiedBy` 为同规则布尔查询。时钟必须显式传入，没有持久化、占用检查与副作用。
- `PricingService.HourlyRate(String revision,Money price)`：revision 非空白、单价非负（免费可）；`new PricingService().quote(Period,HourlyRate)` 按时长向上取整到完整小时，任何正的不足一小时时长收费一小时，包括纳秒。BigDecimal 精确乘整数；无汇率、税、日历日计费、优惠。revision 只为报价来源标签，外部目录负责同 revision 内容一致性。
- `new RentalContract.Factory(specification,pricing).create(ReserveRequest,HourlyRate,Instant now)`：租期规则满足后才构造完整不可变草案。私有构造器，无占用/仓储/事件操作；不检查设备 ACTIVE，也不保证可预留。重复创建相同 RequestId 没有幂等职责。
- `RentalContract.request()/rate()/total()` 读取不可变字段。`covers(Money offered)` 比较同币种报价足额；异币种拒绝；不表示付款事实。对象方法承担自身报价有关的判断，服务没有搬走全部行为。
- `snapshot()` 返回 `RentalContract.Snapshot(ReserveRequest request,HourlyRate rate,Money total)`；构造时校验全部非空与 total 等于重新按保留 rate 计算的报价（包括币种）。`static RentalContract.restore(Snapshot)` 恢复既有草案，不重新按当前时间执行新建提前量检查。可信持久化与授权由外部保证。

## 集成注意

草案可以重叠；只有 25 日历 reserve 结果决定占用。Factory 返回不意味着合同已签署、已预留、已收款或外部承诺已发送。新建规则用实验参数 lead=1h/max=48h；27 可选择参数但应明确，并保存价格/规则版本所需的额外应用记录。旧回执重放应先于会随 now 变化的新建检查。

Snapshot 可在仓储中按应用定义的身份保存，requestId 在这里只标识创建请求，未新增独立法律合同身份。恢复验证内部报价一致性，不认证输入来源或原建规则；如需审计原规则版本，应在应用持久化协议中补充，不能由当前对象反推。

独立入口：`JAVA_HOME=/path/to/jdk21 examples/software-modeling/labs/26/run.sh`；附加 `invalid-period` 通过公开 Factory 触发 TOO_SOON、exit 1。独立包依赖 rental-core/RentalDesk.java、labs/00/BaselineCheck.java、labs/24/Money.java、labs/25/ReservationCalendar.java、labs/26/*.java。
