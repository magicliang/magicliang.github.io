# 25：ReservationCalendar 接入契约

代码为 `labs/25/ReservationCalendar.java`，package `rental.domain`。依赖原 `rental-core/RentalDesk.java` 的 EquipmentId、RequestId、Period、ReserveRequest、Outcome，不修改旧核心。无第三方库，Java 21。

- `new ReservationCalendar(String calendarId)`：非空白租赁点日历身份；此身份不提供进程内单例或分布式锁。
- `synchronized Outcome reserve(ReserveRequest)`：单实例内检查回执、重叠及写入不可分割。同设备活跃半开区间不能重叠；不同设备可同时间预留。RequestId 唯一范围是整个日历，不是单个设备。
- 相同 ID / 相同完整 ReserveRequest 返回原 Outcome；改变设备或租期抛 IllegalArgumentException。失败结果也记忆。`synchronized boolean cancel(RequestId)` 仅将活跃承诺置 inactive；未知/重复/已拒绝取消 false；回执仍保留，取消后旧成功请求重放不重新占用。
- `synchronized Snapshot snapshot()` 返回不可变 `Snapshot(String calendarId,List<Receipt>)`，按 RequestId 字符串排序。`Receipt(ReserveRequest request,Outcome outcome,boolean active)`；active 只能对应 CONFIRMED。一个记录同时携带历史回执与当前活跃位，避免两个集合漂移。
- `static ReservationCalendar restore(Snapshot)` 创建独立实例，拒绝重复 RequestId（包括相同记录重复）、活跃重叠；Snapshot/Receipt 构造器拒绝空值、空白根身份、拒绝却活跃。被取消的 CONFIRMED 不活跃是合法状态。没有事件历史，无法审核过去的拒绝当时是否合理；持久化真实性和授权在外部边界。

## 27 接入义务与证据范围

应用按日历身份维护同一可变实例，或实现存储侧版本/事务冲突检测；分别 restore 两份相同身份快照将得到两个独立监视器，均可能接受冲突预留。此处没有数据库、跨进程锁、崩溃恢复、两阶段提交或公平性保证。多设备共一把锁是有意选择的小范围教学边界，单设备分片未实现。

设备 ACTIVE、维修许可、合同草案、报价不是本聚合成员。应用先识别旧请求重放，再决定新请求的设备/规则检查；不能因重放时当前设备退役或 now 改变就隐式改变已有回执。新增价格等命令字段不在 ReserveRequest 中，27 若把它们加入重试身份负载，必须自行保存完整命令指纹。

日历成功后合同保存失败会留下活跃预留，25 已注入异常证明；27 必须声明自己的原子提交或补偿边界，不得将 synchronized 当成数据库事务。同步仅覆盖 reserve/cancel/snapshot 的内存临界区。

独立入口：`JAVA_HOME=/path/to/jdk21 examples/software-modeling/labs/25/run.sh`。反例否定入口加 `require-broken-safe` 应 exit 1；正常入口将实际反例作为期望观察，因此 exit 0。日志记录真实线程名、两次检查和写入。broken 用 CopyOnWriteArrayList 避免容器数据竞争掩盖复合操作的错误。
