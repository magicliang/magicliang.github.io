package rental.domain;

import java.util.List;
import java.util.Objects;

public record EquipmentDescription(String model, List<String> tags) {
    public EquipmentDescription {
        Objects.requireNonNull(model, "model");
        if (model.isBlank()) throw new IllegalArgumentException("nonblank model required");
        tags = List.copyOf(tags);
    }
}
