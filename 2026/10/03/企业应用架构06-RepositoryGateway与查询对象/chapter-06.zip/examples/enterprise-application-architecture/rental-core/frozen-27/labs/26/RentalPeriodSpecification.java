package rental.domain;

import java.time.Duration;
import java.time.Instant;
import java.util.Objects;
import rental.RentalDesk.Period;

public record RentalPeriodSpecification(Duration minimumLead, Duration maximumDuration) {
    public enum Result { SATISFIED, TOO_SOON, TOO_LONG }

    public RentalPeriodSpecification {
        Objects.requireNonNull(minimumLead, "minimumLead");
        Objects.requireNonNull(maximumDuration, "maximumDuration");
        if (minimumLead.isNegative() || maximumDuration.isNegative() || maximumDuration.isZero()) {
            throw new IllegalArgumentException("invalid duration policy");
        }
    }

    public Result evaluate(Period period, Instant now) {
        Objects.requireNonNull(period, "period");
        Objects.requireNonNull(now, "now");
        if (Duration.between(now, period.start()).compareTo(minimumLead) < 0) return Result.TOO_SOON;
        if (Duration.between(period.start(), period.end()).compareTo(maximumDuration) > 0) return Result.TOO_LONG;
        return Result.SATISFIED;
    }

    public boolean isSatisfiedBy(Period period, Instant now) {
        return evaluate(period, now) == Result.SATISFIED;
    }
}
