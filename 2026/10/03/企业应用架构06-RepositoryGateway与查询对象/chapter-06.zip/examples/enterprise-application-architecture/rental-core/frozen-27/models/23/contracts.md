# 冻结的维修适配契约

这是本系列合成供应商协议，不是实际厂商API；Python纯函数实现，未调用网络或变更Java核心。

关系选择：维修供应方是上游；租赁是下游，使用 Anticorruption Layer 保持租赁模型；假设无权要求供应方按租赁需求排期，因此不声称已有Customer/Supplier合作。上游发布接口、状态含义与版本说明；下游拥有适配器、设备ID映射、兼容测试和发布判断。若协商成功使下游优先级进入上游计划，可另建Customer/Supplier关系，不靠画箭头假设协议成立。

v1：version/asset/status/inspection/returned。status为OPEN、IN_PROGRESS、DONE、CANCELLED；inspection为PASS、FAIL、PENDING。
v2：version/asset/phase/disposition/inspection/returned。phase为WORKING或CLOSED；disposition为REPAIRED、NO_FAULT、CANCELLED；inspection为PASSED、FAILED、PENDING。returned必须为真正boolean。

翻译次序冻结：检验失败→BLOCKED；取消→REVIEW_REQUIRED；未完成→BLOCKED；未返还→BLOCKED；检验待定→REVIEW_REQUIRED；完成且通过且返还→RELEASED。v2 CLOSED必须结合disposition才算完成。未知版本、状态、检验结果、设备ID直接抛ValueError，不生成“可用”。

Assessment保留equipment_id、restriction、reason、source_version、source_state、source_inspection、returned。不同维修原因可压缩成相同restriction，但保留来源字段；不可将一个布尔值当作无损翻译。require_released仅接受RELEASED；REVIEW_REQUIRED并不自动驱动人工工单，仍需后续应用用例负责处理。

供后续Java应用接入的语言契约：BLOCKED/RELEASED/REVIEW_REQUIRED应保持区分；RELEASED仅解除维修侧限制，不保证租赁方验收、生命周期、库存或请求租期可用。翻译结果不携带时效/顺序版本；接入事件/仓储前需另补来源标识、观察时间、过期政策、乱序和重放语义，不要把本纯函数扩展成完整同步保证。
