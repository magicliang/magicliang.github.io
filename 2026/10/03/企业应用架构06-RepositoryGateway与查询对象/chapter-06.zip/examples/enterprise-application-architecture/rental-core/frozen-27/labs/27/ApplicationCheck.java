package rental.application;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Currency;
import java.util.List;
import java.util.Map;
import rental.RentalDesk.EquipmentId;
import rental.RentalDesk.Period;
import rental.RentalDesk.RequestId;
import rental.RentalDesk.ReserveRequest;
import rental.application.RentalApplication.Command;
import rental.application.RentalApplication.Event;
import rental.application.RentalApplication.Fault;
import rental.application.RentalApplication.Maintenance;
import rental.application.RentalApplication.MemoryRepository;
import rental.application.RentalApplication.Point;
import rental.application.RentalApplication.Snapshot;
import rental.application.RentalApplication.Status;
import rental.domain.Equipment;
import rental.domain.EquipmentDescription;
import rental.domain.Money;
import rental.domain.PricingService.HourlyRate;
import rental.domain.RentalPeriodSpecification;
import rental.domain.ReservationCalendar;

public final class ApplicationCheck {
    public static final Instant NOW = Instant.parse("2026-10-03T08:00:00Z");
    public static final EquipmentId E1 = new EquipmentId("E1");
    public static final RentalPeriodSpecification SPEC = new RentalPeriodSpecification(Duration.ofHours(1), Duration.ofHours(48));
    public static final Fault NONE = point -> { };
    private static int checks;
    private ApplicationCheck() { }
    public static Command command(String id, String equipment, long start, long end) {
        return new Command(new ReserveRequest(new RequestId(id), new EquipmentId(equipment),
                new Period(NOW.plusSeconds(start), NOW.plusSeconds(end))),
                new HourlyRate("rate-v1", new Money(new BigDecimal("12.50"), Currency.getInstance("CNY"))));
    }
    public static Snapshot initial() {
        Equipment equipment = new Equipment(E1, new EquipmentDescription("drill", List.of("portable")));
        equipment.approveInspection();
        return new Snapshot(Map.of(E1, equipment.snapshot()), new ReservationCalendar("shop-A").snapshot(), Map.of(), Map.of());
    }
    private static RentalApplication app(MemoryRepository repository, List<Event> events, Fault fault) {
        return new RentalApplication(repository, id -> Maintenance.RELEASED, events::add, fault,
                new RentalApplication.InlineAdmission(), SPEC);
    }
    public static void main(String[] args) {
        if (args.length > 0) throw new IllegalArgumentException("unknown arguments");
        var events = new ArrayList<Event>();
        var repository = new MemoryRepository(initial(), NONE);
        var application = app(repository, events, NONE);
        Command first = command("r1", "E1", 7200, 10800);
        check("reserve confirmed", application.reserve(first, NOW) == Status.CONFIRMED);
        check("factory quote persisted", repository.read().contracts().get(first.request().requestId()).total()
                .equals(new Money(new BigDecimal("12.50"), Currency.getInstance("CNY"))));
        check("snapshot restore round trip", new MemoryRepository(repository.read(), NONE).read().equals(repository.read()));
        Equipment escaped = repository.transact(session -> session.equipment(E1));
        escaped.retire();
        check("escaped entity cannot mutate committed snapshot", repository.read().equipment().get(E1).state() == Equipment.State.ACTIVE);
        repository.transact(session -> { session.equipment(E1).retire(); return null; });
        check("reload observes committed retirement", new MemoryRepository(repository.read(), NONE).read().equipment().get(E1).state() == Equipment.State.RETIRED);
        var unavailablePort = new RentalApplication(repository, id -> { throw new AssertionError("replay called maintenance"); },
                events::add, NONE, new RentalApplication.InlineAdmission(), SPEC);
        check("global replay precedes current eligibility clock and maintenance", unavailablePort.reserve(first, NOW.plusSeconds(99999)) == Status.CONFIRMED);
        fail("changed equipment under same id", IllegalArgumentException.class,
                () -> unavailablePort.reserve(command("r1", "E2", 7200, 10800), NOW));
        Command newRate = new Command(first.request(), new HourlyRate("rate-v2", first.rate().price()));
        fail("changed price revision under same id", IllegalArgumentException.class, () -> unavailablePort.reserve(newRate, NOW));
        check("retired denies new request", application.reserve(command("retired", "E1", 10800, 14400), NOW) == Status.INELIGIBLE);
        check("cancel confirmed", application.cancel(first.request().requestId()));
        check("repeat cancel false", !application.cancel(first.request().requestId()));
        check("unknown cancel false", !application.cancel(new RequestId("unknown")));
        check("cancel preserves contract and confirmed history", repository.read().contracts().containsKey(first.request().requestId())
                && unavailablePort.reserve(first, NOW) == Status.CONFIRMED
                && repository.read().calendar().receipts().stream().noneMatch(ReservationCalendar.Receipt::active));
        check("only actual reserve and cancel publish", events.size() == 2);

        var r2 = new MemoryRepository(initial(), NONE);
        var e2 = new ArrayList<Event>();
        var a2 = app(r2, e2, NONE);
        check("fresh confirmation", a2.reserve(first, NOW) == Status.CONFIRMED);
        Command overlap = command("r2", "E1", 9000, 12000);
        check("overlap rejected", a2.reserve(overlap, NOW) == Status.OVERLAP_REJECTED);
        a2.cancel(first.request().requestId());
        check("rejected history survives release", a2.reserve(overlap, NOW) == Status.OVERLAP_REJECTED);
        check("new identity uses released interval", a2.reserve(command("r3", "E1", 9000, 12000), NOW) == Status.CONFIRMED);
        check("half-open adjacent accepted", a2.reserve(command("r4", "E1", 12000, 14400), NOW) == Status.CONFIRMED);
        check("invalid period stored", a2.reserve(command("soon", "E1", 1, 10), NOW) == Status.INVALID_PERIOD);
        check("unknown equipment stored", a2.reserve(command("missing", "E9", 7200, 10800), NOW) == Status.UNKNOWN_EQUIPMENT);
        for (Maintenance value : List.of(Maintenance.BLOCKED, Maintenance.REVIEW_REQUIRED)) {
            var restricted = new RentalApplication(r2, id -> value, e2::add, NONE, new RentalApplication.InlineAdmission(), SPEC);
            check("maintenance restriction " + value, restricted.reserve(command(value.name(), "E1", 15000, 16000), NOW) == Status.MAINTENANCE_RESTRICTED);
        }
        fail("maintenance technical failure does not consume request", IllegalStateException.class,
                () -> new RentalApplication(r2, id -> { throw new IllegalStateException("port unavailable"); }, e2::add, NONE,
                        new RentalApplication.InlineAdmission(), SPEC).reserve(command("port-fail", "E1", 15000, 16000), NOW));
        check("port failure leaves no receipt", !r2.read().receipts().containsKey(new RequestId("port-fail")));

        var failing = new MemoryRepository(initial(), point -> { throw new IllegalStateException("before commit"); });
        var noEvents = new ArrayList<Event>();
        fail("before commit failure", IllegalStateException.class, () -> app(failing, noEvents, NONE).reserve(first, NOW));
        check("rollback covers calendar receipt contract", failing.read().equals(initial()) && noEvents.isEmpty());
        var reloaded = new MemoryRepository(failing.read(), NONE);
        check("fresh repository can retry rolled-back request", app(reloaded, noEvents, NONE).reserve(first, NOW) == Status.CONFIRMED);
        Snapshot beforeCancel = reloaded.read();
        var cancelFailure = new MemoryRepository(beforeCancel, point -> { throw new IllegalStateException("cancel before commit"); });
        fail("cancel commit failure", IllegalStateException.class, () -> app(cancelFailure, noEvents, NONE).cancel(first.request().requestId()));
        check("cancel rollback retains active commitment", cancelFailure.read().equals(beforeCancel));

        var gap = new MemoryRepository(initial(), NONE);
        var lost = new ArrayList<Event>();
        fail("after commit before publish failure", IllegalStateException.class, () -> app(gap, lost,
                point -> { if (point == Point.AFTER_COMMIT) throw new IllegalStateException("after commit"); }).reserve(first, NOW));
        check("commit survives publication gap", gap.read().contracts().containsKey(first.request().requestId()) && lost.isEmpty());
        check("history replay does not repair lost event", app(new MemoryRepository(gap.read(), NONE), lost, NONE).reserve(first, NOW) == Status.CONFIRMED && lost.isEmpty());
        var publisherFailure = new MemoryRepository(initial(), NONE);
        fail("publisher exception", IllegalStateException.class, () -> new RentalApplication(publisherFailure, id -> Maintenance.RELEASED,
                event -> { throw new IllegalStateException("publisher unavailable"); }, NONE, new RentalApplication.InlineAdmission(), SPEC).reserve(first, NOW));
        check("publisher failure also retains committed state", publisherFailure.read().contracts().containsKey(first.request().requestId()));
        fail("nested transaction rejected", IllegalStateException.class,
                () -> reloaded.transact(session -> reloaded.transact(inner -> null)));
        System.out.println("TRACE reserve=CONFIRMED cancel=true history=CONFIRMED active=false events=" + events);
        System.out.println("RESULT chapter27 checks=" + checks);
    }
    private static void fail(String label, Class<? extends RuntimeException> expected, Runnable action) {
        try { action.run(); } catch (RuntimeException failure) {
            if (!expected.isInstance(failure)) throw failure;
            System.out.println("OBSERVED " + label + ": " + failure.getMessage());
            check(label, true); return;
        }
        throw new AssertionError(label);
    }
    private static void check(String label, boolean condition) {
        if (!condition) throw new AssertionError(label);
        checks++;
        System.out.println("PASS " + label);
    }
}
