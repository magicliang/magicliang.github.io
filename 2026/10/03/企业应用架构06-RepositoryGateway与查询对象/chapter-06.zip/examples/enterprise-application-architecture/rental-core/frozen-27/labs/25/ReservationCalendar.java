package rental.domain;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import rental.RentalDesk.Outcome;
import rental.RentalDesk.RequestId;
import rental.RentalDesk.ReserveRequest;

public final class ReservationCalendar {
    public record Receipt(ReserveRequest request, Outcome outcome, boolean active) {
        public Receipt {
            Objects.requireNonNull(request, "request");
            Objects.requireNonNull(outcome, "outcome");
            if (active && outcome != Outcome.CONFIRMED) {
                throw new IllegalArgumentException("rejected receipt cannot be active");
            }
        }
    }

    public record Snapshot(String calendarId, List<Receipt> receipts) {
        public Snapshot {
            Objects.requireNonNull(calendarId, "calendarId");
            if (calendarId.isBlank()) throw new IllegalArgumentException("blank calendarId");
            receipts = List.copyOf(receipts);
        }
    }

    private final String calendarId;
    private final Map<RequestId, Receipt> receipts = new LinkedHashMap<>();

    public ReservationCalendar(String calendarId) {
        this.calendarId = new Snapshot(calendarId, List.of()).calendarId();
    }

    public synchronized Outcome reserve(ReserveRequest request) {
        Objects.requireNonNull(request, "request");
        Receipt previous = receipts.get(request.requestId());
        if (previous != null) {
            if (!previous.request().equals(request)) {
                throw new IllegalArgumentException("requestId reused with different payload");
            }
            return previous.outcome();
        }
        Outcome outcome = conflicts(request) ? Outcome.OVERLAP_REJECTED : Outcome.CONFIRMED;
        receipts.put(request.requestId(), new Receipt(request, outcome, outcome == Outcome.CONFIRMED));
        return outcome;
    }

    public synchronized boolean cancel(RequestId requestId) {
        Objects.requireNonNull(requestId, "requestId");
        Receipt previous = receipts.get(requestId);
        if (previous == null || !previous.active()) return false;
        receipts.put(requestId, new Receipt(previous.request(), previous.outcome(), false));
        return true;
    }

    public synchronized Snapshot snapshot() {
        return new Snapshot(calendarId, receipts.values().stream()
                .sorted(Comparator.comparing(r -> r.request().requestId().value())).toList());
    }

    public static ReservationCalendar restore(Snapshot snapshot) {
        Objects.requireNonNull(snapshot, "snapshot");
        ReservationCalendar result = new ReservationCalendar(snapshot.calendarId());
        for (Receipt receipt : snapshot.receipts()) {
            if (result.receipts.containsKey(receipt.request().requestId())) {
                throw new IllegalArgumentException("duplicate requestId in snapshot");
            }
            if (receipt.active() && result.conflicts(receipt.request())) {
                throw new IllegalArgumentException("overlapping active reservations in snapshot");
            }
            result.receipts.put(receipt.request().requestId(), receipt);
        }
        return result;
    }

    private boolean conflicts(ReserveRequest request) {
        return receipts.values().stream().filter(Receipt::active).map(Receipt::request)
                .anyMatch(old -> old.equipmentId().equals(request.equipmentId())
                        && old.period().overlaps(request.period()));
    }
}
