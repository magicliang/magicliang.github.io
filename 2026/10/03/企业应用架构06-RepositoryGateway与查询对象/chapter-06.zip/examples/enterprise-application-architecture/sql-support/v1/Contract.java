package enterprise.sql;

import java.util.Objects;
import rental.RentalDesk.EquipmentId;
import rental.RentalDesk.Period;
import rental.domain.Money;

public record Contract(String tenant, String id, EquipmentId equipment, Period period, Money total, State state, long version) {
    public enum State { RESERVED, CANCELLED }
    public Contract {
        if (tenant == null || tenant.isBlank() || id == null || id.isBlank()) throw new IllegalArgumentException("identity");
        Objects.requireNonNull(equipment);
        Objects.requireNonNull(period);
        Objects.requireNonNull(total);
        Objects.requireNonNull(state);
        if (total.amount().signum() < 0 || total.amount().precision() > 19) throw new IllegalArgumentException("persisted total range");
        if (version < 0) throw new IllegalArgumentException("version");
    }
    public Contract cancel() { return new Contract(tenant, id, equipment, period, total, State.CANCELLED, version); }
}
