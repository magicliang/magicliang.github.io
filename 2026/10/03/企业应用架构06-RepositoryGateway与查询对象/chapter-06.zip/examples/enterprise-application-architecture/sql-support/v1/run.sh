#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
chapter=${1:?chapter required}
shift
java_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}java
javac_cmd=${JAVA_HOME:+$JAVA_HOME/bin/}javac
java_version=$("$java_cmd" -version 2>&1)
javac_version=$("$javac_cmd" -version 2>&1)
printf '%s\n%s\n' "$java_version" "$javac_version"
if [[ ! "$java_version" =~ version\ \"21[.\"] || ! "$javac_version" =~ ^javac\ 21[.\ ] ]]; then echo 'JDK 21 required; set JAVA_HOME.' >&2; exit 2; fi
python3 "$root/labs/00/verify-baseline.py"
jar=$(python3 "$root/sql-support/v1/resolve-h2.py")
python3 - "$jar" <<'PY'
import hashlib,sys
from pathlib import Path
print('H2 version=2.1.214 SHA256='+hashlib.sha256(Path(sys.argv[1]).read_bytes()).hexdigest())
PY
build=$(mktemp -d)
trap 'rm -rf "$build"' EXIT
frozen="$root/rental-core/frozen-27"
sources=("$frozen"/rental-core/*.java "$frozen"/labs/00/*.java "$frozen"/labs/24/*.java "$frozen"/labs/25/*.java "$frozen"/labs/26/*.java "$frozen"/rental-application/*.java "$frozen"/labs/27/*.java "$root"/sql-support/v1/*.java)
for ((part=5; part<=10#$chapter; part++)); do printf -v label '%02d' "$part"; for file in "$root/labs/$label/"*.java; do [[ ! -f "$file" ]] || sources+=("$file"); done; done
"$javac_cmd" --release 21 -Xlint:all -Werror -d "$build/classes" "${sources[@]}"
"$java_cmd" -ea -cp "$build/classes:$jar" "enterprise.chapter${chapter}.Lab${chapter}" "$build/database" "$root/sql-support/v1/schema.sql" "$@"
