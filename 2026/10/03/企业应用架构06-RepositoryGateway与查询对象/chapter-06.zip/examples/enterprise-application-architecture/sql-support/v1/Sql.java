package enterprise.sql;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public final class Sql implements AutoCloseable {
    @FunctionalInterface public interface Row<T> { T read(ResultSet result) throws SQLException; }
    private static final AtomicInteger IDS = new AtomicInteger();
    private final Connection connection;
    private final int id = IDS.incrementAndGet();
    private int queries;
    private int commits;
    private int rollbacks;
    private int resources;
    private boolean closed;
    private Sql(Connection connection) throws SQLException {
        this.connection = connection;
        connection.setAutoCommit(false);
        connection.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
        System.out.println("OPEN connection=" + id + " isolation=" + connection.getTransactionIsolation());
    }
    public static Sql open(String url) throws SQLException { return new Sql(DriverManager.getConnection(url, "sa", "")); }
    public static void migrate(String url, Path schema) throws Exception {
        try (Sql db = open(url)) {
            for (String statement : Files.readString(schema).split(";")) if (!statement.isBlank()) db.update(statement.strip());
            db.commit();
            String version = db.query("SELECT H2VERSION()", row -> row.getString(1)).getFirst();
            if (!version.equals("2.1.214")) throw new AssertionError(version);
            System.out.println("DATABASE H2=" + version + " schema=v1");
        }
    }
    private void bind(PreparedStatement statement, Object[] values) throws SQLException {
        for (int i = 0; i < values.length; i++) {
            Object value = values[i] instanceof Instant instant ? instant.atOffset(ZoneOffset.UTC) : values[i];
            statement.setObject(i + 1, value);
        }
    }
    private void trace(String sql, Object[] values) {
        if (closed) throw new IllegalStateException("session closed");
        System.out.println("SQL connection=" + id + " thread=" + Thread.currentThread().getName() + " text=" + sql.replace('\n', ' ') + " binds=" + Arrays.toString(values));
    }
    public int update(String sql, Object... values) throws SQLException {
        trace(sql, values);
        resources++;
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            bind(statement, values);
            int rows = statement.executeUpdate();
            System.out.println("ROWS connection=" + id + " affected=" + rows);
            return rows;
        } catch (SQLException failure) {
            System.out.println("SQL_FAILURE connection=" + id + " state=" + failure.getSQLState() + " code=" + failure.getErrorCode());
            throw failure;
        } finally { resources--; }
    }
    public <T> List<T> query(String sql, Row<T> mapper, Object... values) throws SQLException {
        trace(sql, values);
        queries++;
        resources++;
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            bind(statement, values);
            try (ResultSet result = statement.executeQuery()) {
                var list = new ArrayList<T>();
                while (result.next()) list.add(mapper.read(result));
                return List.copyOf(list);
            }
        } catch (SQLException failure) {
            System.out.println("SQL_FAILURE connection=" + id + " state=" + failure.getSQLState() + " code=" + failure.getErrorCode());
            throw failure;
        } finally { resources--; }
    }
    public int count(String table) throws SQLException {
        if (!List.of("equipment", "rental_contract", "contract_line").contains(table)) throw new IllegalArgumentException("table");
        return query("SELECT COUNT(*) FROM " + table, row -> row.getInt(1)).getFirst();
    }
    public void commit() throws SQLException { connection.commit(); commits++; System.out.println("COMMIT connection=" + id + " count=" + commits); }
    public void rollback() throws SQLException { connection.rollback(); rollbacks++; System.out.println("ROLLBACK connection=" + id + " count=" + rollbacks); }
    public int queries() { return queries; }
    public int commits() { return commits; }
    public int rollbacks() { return rollbacks; }
    public int resources() { return resources; }
    public int id() { return id; }
    public boolean closed() { return closed; }
    @Override public void close() throws SQLException {
        try { connection.close(); } finally { closed = true; System.out.println("CLOSE connection=" + id + " openStatements=" + resources); }
    }
}
