# SQL support v1

Frozen coordinate com.h2database:h2:2.1.214; h2.json pins Maven Central URL and SHA256. resolve-h2.py supports H2_JAR (explicit missing/mismatched file fails), ARCHITECTURE_TOOL_CACHE, then MODELING_TOOL_CACHE, then ~/.cache/enterprise-architecture-tools. Absent cache downloads to a temporary file, verifies hash, then moves into cache. Never commit jars.

JDK21 only; --release21 -Xlint:all -Werror. H2 is runtime-only on the classpath; Java sources depend on java.sql. Driver uses real file databases in a disposable directory. No PostgreSQL compatibility mode. Sql tracks executed prepared statements, bind values, connection IDs, update counts, commit/rollback and SQLSTATE; no invented SQL traces.

schema.sql is initial schema v1, not an upgrade migration. DDL runs before business transactions: H2 2.1.214 documents most DDL commits current transaction. All sessions explicitly set READ_COMMITTED. Source/tag documentation: https://github.com/h2database/h2database/blob/version-2.1.214/h2/src/docsrc/html/advanced.html (Transaction Isolation, MVCC, Lock Timeout); release https://github.com/h2database/h2database/releases/tag/version-2.1.214 . This version was chosen for reproducible experiments, not a recommendation to deploy an old database.

Contract is a limited persistence teaching model using frozen27 Money/EquipmentId/Period; not a SQL implementation of the complete frozen27 Repository. Nonnegative amount and precision <=19 are Contract constraints, not changes to Money. SQL TIMESTAMP(9) WITH TIME ZONE round-trips Instant via UTC OffsetDateTime. Half-open intervals, cancellation history remain; no overlap exclusion constraint or replay persistence is claimed.

Chapter runners invoke this versioned helper; root run-lab.sh dispatches unchanged. Packages must include sql-support/v1, frozen-27, models/00 manifest, labs/00 verifier, and preceding chapter Java dependencies.
