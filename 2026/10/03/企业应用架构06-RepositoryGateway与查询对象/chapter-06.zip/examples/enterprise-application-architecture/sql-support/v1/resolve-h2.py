import hashlib
import json
import os
import tempfile
import urllib.request
from pathlib import Path

manifest = json.loads(Path(__file__).with_name('h2.json').read_text())
override = os.environ.get('H2_JAR')
cache = Path(os.environ.get('ARCHITECTURE_TOOL_CACHE', os.environ.get('MODELING_TOOL_CACHE', str(Path.home()/'.cache/enterprise-architecture-tools'))))
target = Path(override).expanduser() if override else cache / 'h2-2.1.214.jar'
def valid(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() == manifest['sha256']
if not target.exists():
    if override:
        raise SystemExit('H2_JAR does not exist')
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as stream:
        temporary = Path(stream.name)
        try:
            with urllib.request.urlopen(manifest['url'], timeout=60) as response:
                stream.write(response.read())
            stream.flush()
            if not valid(temporary):
                raise SystemExit('download SHA256 mismatch')
            temporary.replace(target)
        finally:
            temporary.unlink(missing_ok=True)
if not valid(target):
    raise SystemExit('H2 SHA256 mismatch; refusing to execute jar')
print(target.resolve())
