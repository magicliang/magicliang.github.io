package enterprise.sql;

public final class Check {
    private static int count;
    private Check() { }
    public static void that(String label, boolean condition) {
        if (!condition) throw new AssertionError(label);
        count++;
        System.out.println("PASS " + label);
    }
    public static void result(String chapter) { System.out.println("RESULT enterprise" + chapter + " checks=" + count); }
}
