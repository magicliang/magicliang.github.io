CREATE TABLE equipment (
 tenant_id VARCHAR(40) NOT NULL,
 equipment_id VARCHAR(80) NOT NULL,
 category VARCHAR(80) NOT NULL,
 state VARCHAR(30) NOT NULL CHECK (state IN ('ACTIVE','RETIRED','INSPECTION_REQUIRED')),
 version BIGINT NOT NULL DEFAULT 0,
 PRIMARY KEY(tenant_id,equipment_id)
);
CREATE TABLE rental_contract (
 tenant_id VARCHAR(40) NOT NULL,
 contract_id VARCHAR(80) NOT NULL,
 equipment_id VARCHAR(80) NOT NULL,
 starts_at TIMESTAMP(9) WITH TIME ZONE NOT NULL,
 ends_at TIMESTAMP(9) WITH TIME ZONE NOT NULL,
 amount DECIMAL(19,2) NOT NULL CHECK (amount >= 0),
 currency VARCHAR(3) NOT NULL CHECK (currency IN ('CNY','USD')),
 status VARCHAR(16) NOT NULL CHECK (status IN ('RESERVED','CANCELLED')),
 version BIGINT NOT NULL DEFAULT 0,
 PRIMARY KEY(tenant_id,contract_id),
 FOREIGN KEY(tenant_id,equipment_id) REFERENCES equipment(tenant_id,equipment_id),
 CHECK (starts_at < ends_at)
);
CREATE TABLE contract_line (
 tenant_id VARCHAR(40) NOT NULL,
 contract_id VARCHAR(80) NOT NULL,
 line_no INT NOT NULL,
 description VARCHAR(120) NOT NULL,
 amount DECIMAL(19,2) NOT NULL CHECK (amount >= 0),
 PRIMARY KEY(tenant_id,contract_id,line_no),
 FOREIGN KEY(tenant_id,contract_id) REFERENCES rental_contract(tenant_id,contract_id)
);
