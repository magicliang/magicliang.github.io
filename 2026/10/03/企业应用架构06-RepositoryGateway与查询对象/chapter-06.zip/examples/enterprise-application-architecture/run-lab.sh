#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
chapter=${1:?usage: run-lab.sh NN or all}
shift
if [[ "$chapter" == all ]]; then
  for runner in "$root"/labs/[0-9][0-9]/run.sh; do bash "$runner"; done
elif [[ "$chapter" =~ ^[0-9][0-9]$ && -f "$root/labs/$chapter/run.sh" ]]; then
  bash "$root/labs/$chapter/run.sh" "$@"
else
  echo 'unknown chapter' >&2
  exit 2
fi
