# S006：同期货运数据的获取边界

- 任务B01–02：寻找当年运河统计，区分货物重量和船舶登记吨位。
- 来源：United Nations, *Economic Developments in the Middle East 1956–1957*, New York,1958，E/3116, ST/ECA/55，Table XXIII，印刷p154。
- [馆藏PDF](https://digitallibrary.un.org/record/3903374/files/E_3116--ST_ECA_55-EN.pdf)；[1959续编的相同历史序列](https://digitallibrary.un.org/nanna/record/3903606/files/1959_WESS_MiddleEast.pdf?registerDownload=1&version=1&withMetadata=0&withWatermark=0)。
- 实际阅读：仅读到搜索引擎对原PDF的表格文字索引，PDF未完整取得。web403、旧UN存档IAB404、馆藏页IAB空白、curl所得0字节，均不计成功。2026-10-22。
- 已见索引：1955年14666次船舶通过；货运107.5百万公吨，南向20.1、北向87.4，其中北向石油66.9。1956年仅1–10月数据，不能写成年量；船数与货物量、净登记吨位不得互换。
- 采用边界：主文若采用须明确来自联合国表格可检索文本、尚未核原页图像；为避免核心数字落在薄证上，可优先使用S011b有明确性质的同期净收益估计，另将流量放资料说明，不据此精算各国能源依赖百分比。
- 不支持：不能称全年1956货运，也不证明逐月经营效率或全部轮船均获准通过。
