# S007：世界银行与阿斯旺项目

- 任务：B10，核查融资与发展动机，防止单因叙事。
- 调查者：主代理；2026-10-22。
- 来源：[The World Bank’s Role as Mediator in the 1950s](https://www.worldbank.org/en/archive/history/exhibits/The-World-Banks-Role-as-Mediator-in-the-1950s)，世行档案展；相关“Funding the Aswan Dam”节全文已读。
- 转述：1954–1956年Eugene Black参与埃、美、英融资磋商；目标为灌溉和发电，政治与冷战纠葛使方案未成；建设后来由苏联支持。档案展引用Mason/Asher1973年书，不等于调查者读过该书。
- 支持：这是多年发展融资谈判，不是1956年7月临时起意；美国拒绝与纳赛尔国有化演说的联系另有FRUS XVI doc.1同期讲话编者引述。
- 局限：此短展不足以独立证明美国撤回条件的全部内部原因与分国精确金额；这些命题需另补同期档案。
- 使用：B10；E008。
