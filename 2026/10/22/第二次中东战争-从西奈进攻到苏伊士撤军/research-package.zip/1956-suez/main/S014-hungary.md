# S014：联合国对匈牙利的同期决议

任务S014；主代理，2026-10-22。实际读联合国Mandate Registry所列1004(ES-II)八项执行段：https://mandates.un.org/mandate/A/RES/1004(ES-II)?end_year=1956&start_year=1956 。页面明示OCR可能错误，未声称核对PDF原页；并读联合国紧急特别会议索引 https://research.un.org/en/docs/ga/quick/emergency 及1956安理会行动表 https://www.un.org/depts/dhl/resguide/scact1956_table_en.html 的相关记录。

1956年11月4日决议要求苏联停止武力攻击和干预匈牙利、停止增兵并撤出，确认匈牙利人选择符合民族愿望政府的权利，要求观察和救济。安理会同日苏联否决实质决议后，120号程序决议交紧急大会。与10月30日英法否决苏伊士决议、31日119号交大会构成可比制度行为。支持同一非干预标准下评价两次用武与否决，不证明苏伊士导致苏联进攻决定。10月23日起义日期未从这份执行段独证，不据此增加该日期细节。
