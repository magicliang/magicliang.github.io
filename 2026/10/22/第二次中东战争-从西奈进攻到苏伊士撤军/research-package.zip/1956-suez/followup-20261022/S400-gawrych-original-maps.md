# S400：高里奇1990年原版扫描中的1956年局部地图

任务：M02艾布奥盖拉；核验日期2026-10-22。作者George W. Gawrych，*Key to the Sinai: The Battles for Abu Ageila in the 1956 and 1967 Arab-Israeli Wars*，Combat Studies Institute，Research Survey No.7，1990。

## 获取与实际阅读

- [Google Books原版扫描](https://books.google.com/books?id=GL-5V0LKNmcC)。书目显示原藏Indiana University、2019-04-17数字化。数字化日期不是制图日期。封面与第ii页CIP均核到Research Survey No.7及1990书目记录，未以网页混列的Diane版ISBN判定版本。
- [第16页、图4](https://books.google.com/books?id=GL-5V0LKNmcC&pg=PA16)：Egyptian deployments at Abu Ageila and surrounding area。
- [第55页、图12](https://books.google.com/books?id=GL-5V0LKNmcC&pg=PA55)：Israeli plan of attack, 31 October–1 November。
- 实际逐图查看完整像素；另读第ii页权利说明、第v页地图目录、第viii页资料说明。浏览器第53页照片亦见，但不采用该第三方照片。没有通读原版1956章或逐项校正旧S100的重排页码。

官方Army University Press PDF本轮仍HTTP403；Google Books整本PDF下载转验证码，未继续。公开阅读器正常显示原页，页图URL由实际DOM读取，下载后再次用view_image核验。没有越过验证码取得整本文件。浏览使用Codex内部浏览器，后台进行。

## 读图结论

图4处于1956年准备章节、在第31页1956战斗章节之前；目录把1967年埃军部署图另列为第15、16图（第82、84页）。图4显示中央公路、库塞马通道、戴卡隘口、乌姆卡特夫、乌姆希汉及鲁阿法水坝周围的防御配置；有北箭头、0–20公里线尺、道路类型和双方单位填色图例。地图标题未给某一天的快照时刻，采用时称“1956年战前部署复原”，不补造精确时刻。

图12有北箭头、0–10公里线尺、双方单位图例、道路及干河道。第10旅及104、105营的攻击方向与西侧82营等部队围绕路口／水坝的配置可读。图题明确是**攻击计划**，不是所有箭头都已完成的实绩图；更不能读作1956年一举攻破乌姆卡特夫。原图横置在书页中，保留全页、页码、图题和数字化署名；正文只用CSS旋转显示，资产字节不改。

## 权利采用依据及边界

这是一部CSI机构研究出版物。第ii页特别说明“where noted”的获准使用第三方材料不得无许可复制；所采用的图4、图12及地图目录未见此类第三方版权／转载标记。第53页照片则明确另注Courtesy来源，不把整书一概当成没有第三方内容。

独立审阅指出，仅凭机构出版身份不足以确定职务作品，且初稿把美国法条包S211误写成英国版权包S208。为补此环节，本轮实际读取[原书末尾未编号的作者与CSI职责页（Google页码PT2）](https://books.google.com/books?id=GL-5V0LKNmcC&pg=PT2)：作者自1984年7月起任USACGSC教员、属于CSI；同页第3项把相关历史研究及向现役、预备役出版成果列为CSI职责。这是原书对任职和研究任务的直接说明，另存完整像素为`suez-gawrych-pt2.png`，不是由出版单位名称推断雇佣身份。

据作者职务研究身份、CSI研究系列性质、单图无外来权利标记，结合[S211所核17 USC105](https://www.govinfo.gov/content/pkg/USCODE-2023-title17/pdf/USCODE-2023-title17-chap1-sec105.pdf)，将两张未另署第三方来源的研究图作为机构职务研究成果采用。2026-10-22亦复核[§101职务作品定义及§105现行文本](https://www.copyright.gov/title17/92chap1.html#105)。本书1990年出版，早于2019年加入的军校文职教师特定学术作品例外；该后增条款不直接给本书建立私人版权。保留作者、机构、书页、Google数字化署名及原页链接。此判断没有取得逐图制作合同或授权函，不声称美国政府网站上任何材料都自动公有，也不把美国法下的规则扩大为全球权利保证。

该判断不延伸到本书的另署名照片、2014商业重排版或其他书的图件。第viii页还说明以方访谈距战斗约20–30年、埃方官方简报来源匿名记作OEMS；这使地图属于战后研究复原，不能冒充1956年现场作战命令附图，也不能代替缺失的埃军撤令原件。

## 对旧缺口的更新

M02的艾布奥盖拉部分已取得可读、可定位到原书的1956年部署与攻击计划图；米特拉战术图仍未补齐，所以M02整项继续受限。S100旧文字摘录的来源等级不随两张地图取得而自动升级。M03、M04、M05不由这两张图代替。

原始下载证据存于`.omo/evidence/suez-followup-gawrych/`；本地资产的尺寸与SHA256另见maps/README.md及本轮验收记录。
