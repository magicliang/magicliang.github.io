# S412｜Maarachot 124：原始刊物定位，正文与像素未取得

- 任务：M02、D06、D16；日期：2026-10-22。
- 官方过刊索引：https://www.idf.il/אתרי-יחידות/מערכות/גיליונות-מן-העבר/
- 索引实际读取到第 124 期标为 1959 年 11 月；其链接：https://www.maarachot.idf.il/1959/גיליונות/מערכות-124/
- 搜索定位到新版原刊 PDF：https://www.maarachot.idf.il/media/xqrcv424/124.pdf
- 旧版候选：http://maarachot.idf.il/PDF/FILES/6/106746.pdf

## 访问与阅读边界

官方索引已读；刊期页面和新版 PDF 的 web 读取返回 403。shell 对刊期页面一次超时；对新版 PDF 一次连接失败，HTTP 000、0 bytes。日志在 `.omo/evidence/suez-followup-20261022-mitla/download-maarachot.log` 和 `download-maarachot-pdf.log`。旧版 Internet Archive 路由返回 Cache miss。

搜索线索将 Shraga Gafni 的米特拉战斗叙述指向此期第 5—55 页，并把第 55 页列为图源；本轮没有拿到这些页的原图或正文。该页码是待核验线索，不能填写 READ，不能据此摘录战斗事实。

关联通信兵协会的以下两个更新附件也返回 404：

- https://www.amutakesher.org.il/_Uploads/dbsAttachedFiles/Dan_Shalit_and_Mitle_Pass_Battle_1956_1.02.pdf
- https://www.amutakesher.org.il/_Uploads/dbsAttachedFiles/Presentation_Dan_Shalit_and_Mitle_Pass_Battle_1956_1.00.pdf

原 S103 的 1.01 版也仅复核一次仍为 404，没有将同一失败循环记为新来源阅读。搜索摘要声称附录有地图，不能替代像素查看。

## 裁决

这是比通用战役地图更贴近问题的原刊定位增量，但不是已取得的图件。作者／制作日期／战况日期／图号／比例尺／图例／权利均须等实际页面到手再核查。官方域名及 1959 年刊期不能单独推出其中每幅图已属公版。

不新增伤亡数、埃军编制位置或撤退时刻；M02、D06、D16 均未因此关闭。
