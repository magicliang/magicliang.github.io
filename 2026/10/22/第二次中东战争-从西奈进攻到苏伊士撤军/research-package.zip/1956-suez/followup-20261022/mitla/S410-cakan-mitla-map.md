# S410｜Çakan 2024：已见像素的米特拉局部地形图

- 任务：M02；检索、读取日期：2026-10-22。
- 作者：Mehmet Çakan；题名：*Planning and Conduct of Multinational Military Operations: The Case of 1956 Suez Operation*；Marmara University 硕士论文，Istanbul，2024。
- 原件：https://katalog.marmara.edu.tr/veriler/yordambt/cokluortam/2D/6791fa33076f8.pdf#page=91
- 实际阅读范围：封面 PDF 第 1 页；PDF 第 91 页／印刷第 80 页地图与脚注 210；PDF 第 106 页／印刷第 95 页 Kyle 书目项。未声称通读 109 页论文。
- 本地完整 PDF：`.omo/evidence/suez-followup-20261022-mitla/marmara-cakan-2024.pdf`，pypdf 成功解析 109 页。
- 像素证据：同目录 `cakan-mitla.png`（从第 91 页内嵌 JP2 无内容改动转 PNG），以及 `cakan-pdf91.png` 整页；已用 view_image 实际查看局部地图。

## 图件身份与读图结果

论文图号 Figure 19，题注为 Mitla Pass, 1956。图内标题为 MITLA PASS (29 October–31 October)，右下角 Map Number 3。2024 是论文制作年，1956 年 10 月 29—31 日是图所指战况日期；原图制图年代、制图者仍不明。

图上能直接读出西面的 Mitla Defile、中央 The Saucer、东面的 Heitan Defile／Heitan Ridge、Jebel Heitan、Parker Memorial、Caves、Airstrip，以及通往 Nakhl、Bir Hassana 的道路。运河、苏伊士和小苦湖在西侧。比例尺单位 miles，零点在尺段内，左端 5、右侧 5／10；无经纬网，未见指北针或独立图例。

图中没有伞降点标识、埃军／以军部署符号、攻击路线箭头、分阶段战斗时间。道路、山体晕滃与 Tents 等地物不能当作部队战斗位置。因此它是真正涉及 1956 米特拉的局部地形图，但不满足 M02 的战术态势图验收。

## 来源与权利边界

脚注 210 将 Figure 19—21 合并归给 Kyle，书目指向 2011 年 I.B.Tauris 版。S411 对该版出版社预览的目录核查未能印证此图；不能把论文脚注提升为已经闭合的原图出处，也不能断言原图作者就是 Kyle。

未取得此图开放许可、原作者授权或公版依据。大学库公开访问不等于允许转载；保留研究证据及原页链接，不放入博客素材目录，不直接嵌入正文。此图也不提供地图坐标，不能凭视觉描摹制造带精确坐标的“复原图”。

## 支持与反证

- 支持：局部地形确有区分西段 Mitla 与东段 Heitan 的图示线索；可用来定位下一轮史料检索。
- 反证／限制：图题有战役日期并不意味着具备部署或时序信息；出处与权利尚未闭合。
- 可写正文增量：本轮不建议新增战斗事实。若正文解释东口局部地形，须配合既有可靠文字史料；本图单独不足以确认伞降地点、伏击点或部队精确位置。
