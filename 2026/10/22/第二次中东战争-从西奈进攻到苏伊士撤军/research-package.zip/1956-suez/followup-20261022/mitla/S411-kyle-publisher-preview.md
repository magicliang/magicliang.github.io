# S411｜Kyle 出版社预览：原图归属复核

- 任务：复核 S410 的脚注 210；读取日期：2026-10-22。
- 来源：Keith Kyle，*Suez: Britain's End of Empire in the Middle East*，2011 年新版，I.B.Tauris。
- 出版发行预览：https://api.pageplace.de/preview/DT0400.9780857719676_A24413373/preview-9780857719676_A24413373.pdf
- 实际阅读：web PDF 第 5 页版权页、第 6 页章节目录、第 8 页地图目录；预览共 72 页。没有读到第 18 章米特拉空降的正文（目录所列书页 332）。

## 可观察事实

版权页标示 Susan Kyle 的 1991、2003、2011 年版权及 all rights reserved。地图目录仅列 Musketeer（未执行计划）、Sinai Campaign、Port Said and Port Fuad, 1956 三项；没有单列 Mitla Pass 或 Sharm el Sheikh。

这与 S410 把局部米特拉图、沙姆沙伊赫图等统一归于 Kyle 的脚注存在待解释差异。目录缺项不能逻辑上证明正文绝不含任何未列图，但足以阻止将该脚注当作完成了原图归属核验。

## 支持／不支持

- 支持：2011 版版权未开放；三项地图目录可用于排查转引链。
- 不支持：未见具体米特拉地图原页；没有取得其制图者、原版制作年和许可；没有核实米特拉伤亡或撤令正文。
- 结论：不将 S410 图件标为“Keith Kyle 原图”，不据此转载。

本地下载及完整性结果见本目录 `verification.md`。网络后续一次 web 重开返回 UnexpectedStatusCode；此前已读取的版权／目录证据不因此扩充为全书阅读。
