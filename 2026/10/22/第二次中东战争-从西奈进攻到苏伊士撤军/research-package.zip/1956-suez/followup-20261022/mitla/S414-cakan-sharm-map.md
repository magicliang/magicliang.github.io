# S414｜沙姆沙伊赫 1956 年 11 月 5 日图：本地像素核查

任务：M03。执行日期：2026-10-22。仅检查已下载 PDF，未访问浏览器，未改正文。

## 原页与实际阅读

- 容器作者／时间：Mehmet Çakan，Marmara University 硕士论文，2024；完整书名见 S410。
- 原页：https://katalog.marmara.edu.tr/veriler/yordambt/cokluortam/2D/6791fa33076f8.pdf#page=91
- 位置：PDF 第 91 页／印刷第 80 页，下半页 Figure 20；论文题注为 Israeli Troops, Sharm-El Sheik, 1956。
- 图内标题：SHARM al-SHEIKH (5 November 1956)；左上角 Map Number 6。日期在图像本身可直接读到，明确是 1956 年而非 1967 年。
- 阅读范围：本地 pypdf 读取 PDF 第 90—92 页的图题、脚注上下文；用 view_image 实际查看从第 91 页提取的 Image617，未声称通读论文。

像素产物：`.omo/evidence/suez-followup-20261022-mitla/cakan-pdf91-image2-Image617.png`，1259 × 817 像素，163,176 bytes，SHA-256 `fb8e4940f62bf5626cee6275d07e943cc150d33a6fd22e0f3c49900b26e1048e`。原页全图 `cakan-pdf91.png` 可同时核对 Figure 19／20 和脚注关系；完整 PDF 的完整性与哈希见 verification.md。

## 图中确实有什么

图例明确区分实线 Israeli Forces 与点线 Egyptian Forces。以军粗实线箭头分别从 Road from Dahab 经 Naqb 沿东岸向南，以及从 Road from al-Tor 由西向东，汇向 Sharm al-Sheikh 周围。埃军点线由 Jebel Aida 一带及 Ras Nasrani 沿岸炮位方向向沙姆周界收缩；图内文字说明是在以军进攻前收缩。海岸、Tiran、Sanafir、Ras Muhammad、机场均有标注。

比例尺为 miles，零点左侧延伸至 5，右侧刻度 5、10。没有经纬网，未见指北针；粗箭头表示运动方向，不能按线宽推算兵力或攻击正面。

## 能支持与不能支持的范围

这幅图比 S410 米特拉地形图更接近战术态势图：包含两条以军接近路线、埃军回缩方向及图例，并将战况明确限定在 1956 年 11 月 5 日。若原图出处与使用权最终核实，可用于说明南端地理、东西两路接近及埃军向据点收缩的关系。

图上没有旅／营番号、逐小时阶段、各部人数、炮位数量、进攻开始或投降时刻，也不能单独说明各路是否同时到达、哪一路先接战。它是概略运动示意，不能支持精确单位时序或伤亡结论。

## 图源链与许可缺口

同页脚注 210 将 Figure 19—21 一并归于 Kyle 的 *Suez: Britain's End of Empire in the Middle East*；论文书目为 I.B.Tauris 2011 版。图内未见制图者署名或独立版权行，原图制作年不明；不得把战况年份 1956 当作制图年份。

本地 Kyle 出版社预览第 8 页地图目录只有 Musketeer、Sinai Campaign、Port Said and Port Fuad, 1956 三项。它未列沙姆沙伊赫图，因此脚注归属还须验证；目录缺项本身也不足以证明原书绝无未列图。

与 ports 代理互校：其对本地 Marmara Figure 11（印刷第 62 页）和 KCL PDF 第 162 页的比较仅能确认 Port Said／Fuad 图的构图一致，Kyle 预览目录也有同题条目；该预览未包含对应地图原页，更无 Map Number 6 像素。因此港口图的联系不能外推为沙姆图的 Kyle 归属。此项代理复核没有提供新的沙姆原图，未提升本图出处置信度。

未获得图件开放许可或原著作权人授权。大学库公开下载、论文收录以及描绘 1956 战况均不构成转载权依据。M03 获得一个内容合适的真实图件候选，但“原出处确认＋可合法内嵌”仍未完成；目前仅可给原页链接，不移入博客图片目录。

## 复核场景

调用 `view_image` 打开上述 PNG，二值结果：图内可见 5 November 1956、Map Number 6、双方图例与方向箭头。调用 `pypdf.PdfReader` 提取原 PDF 第 91 页文字，二值结果：Figure 20 与共享脚注 210 同页。调用 pypdf 重读 Kyle 预览第 8 页，二值结果：地图目录未列 Sharm；未把这种负面目录证据升级为确定的原图作者判断。
