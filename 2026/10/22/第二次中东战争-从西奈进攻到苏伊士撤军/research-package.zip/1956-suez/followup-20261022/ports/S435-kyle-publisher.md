# S435：Kyle出版者预览与地图权利

- Keith Kyle，*Suez: Britain's End of Empire in the Middle East*，I.B.Tauris，2011版，ISBN9781848855335。
- 官方分销预览：https://api.pageplace.de/preview/DT0400.9780857719676_A24413373/preview-9780857719676_A24413373.pdf 。web.open解析72页；本轮已读PDF第5页版权、第8页地图目录。捕获定位见captured/S435-publisher-observed.txt。
- 版权页：Susan Kyle持有1991、2003、2011各版版权，书中除短评引文外的复制需出版者书面许可。没有读到地图开放许可。不能将其套入Crown期限规则。
- 地图目录有三项：未执行的Musketeer计划、西奈战役、Port Said and Port Fuad1956。最后一项与KCL/S436图题一致；S436也将地图组归Kyle2011。这是目前具体的商业出版来源指向。
- 阅读限制：当前web解析未给Port Said地图所在的Kyle正文页码；尚未在出版者预览中实际看到该图像素或个人制图署名。不能把“同图题＋晚出论文组注”写成已经取得1991初版原图。KCL与Marmara之间的像素同构已经另行实核。
- 采用判断：现有证据足以否定“已证明这张KCL图可按论文CC随意转载”的说法；不足以认定原图公版。建议保留原PDF页链接，并以Kyle出版者为具体权利确认方向。

补充实核：米特拉代理下载完整72页预览后，本代理独立以pypdf验证可打开，并逐像素读版权页、致谢PDF10–13与末尾PDF70–72。预览终点为正文51页，尚未进入登陆章节；致谢未见地图作者署名。版权页截图为captured/S435-kyle-p5.png，其他读取页同前缀。此次没有把未包含的港口图说成已从Kyle预览取得。
