# S436：Marmara Figure11像素比对

- 作者：Mehmet Çakan，*Planning and Conduct of Multinational Military Operations: The Case of 1956 Suez Operation*，Marmara University硕士论文，2024年。
- 原入口：https://katalog.marmara.edu.tr/veriler/yordambt/cokluortam/2D/6791fa33076f8.pdf#page=73 。PDF第73页、印刷62页Figure11；第70页、印刷59页脚注149引用Keith Kyle2011。
- 读取方式：另一代理下载的完整109页PDF位于`.omo/evidence/suez-followup-20261022-mitla/marmara-cakan-2024.pdf`；本代理用pypdfium2渲染第70、73页，并实际view_image第73页。图像捕获captured/S436-marmara-p70.png及S436-marmara-p73.png。
- 与S430比对：海岸弯曲、Gamil机场形状、左下Raswa局部插图、两种线尺、相同登陆和空降单位组、SU100和墓地标注一致。S430横置影印较黑；本图横向正置。可以判断是同一制图构图的再现，不是两张独立证据。
- 细节与限制：此图同样无个人制图署名、制图日期或单图开放许可；页码62不等于Kyle书的页码；前文注149仅是地图组来源，不能直接宣称已经核到Kyle原页。学校公开PDF不构成转载授权。
- 支持/反证：支持KCL图并非独有的原创版式、支持继续追Kyle出版物；反对将两份学位论文当作两份独立历史证据。不得把2024年论文当1956年战场原图。
