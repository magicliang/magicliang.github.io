# S433末次有界核验：原图仍不可读，网站托管条款的适用边界

日期：2026-10-22。承接S433，不新增来源编号；不改正文，不提交。

## 结果

Map 3329.2 Rev.1仍没有可解码的本地原文件。**M05不能标为已取得或已视觉核验。** 已停止重试；未以自动图像描述或另一版地图替代原图。

## 此次实际入口与结果

|入口|实际操作|结果|
|---|---|---|
|[单图官方PDF](https://digitallibrary.un.org/record/685699/files/3329-2_Rev-_1.pdf?ln=en)|独立Chrome会话“🔎 UNEF原图核验”，新标签1681805848；创建导航及选择该标签|导航超时，随后Page.getFrameTree超时；未看到图面。未操作父代理Google Books tab3|
|[1990年《蓝盔》书目](https://digitallibrary.un.org/record/105742?ln=es)|web.open|Cache miss|
|[该书另一官方附件](https://digitallibrary.un.org/record/105742/files/%5EST_%5EDPI_1065--DPI_1065-EN.pdf)|curl -L --max-time 35，输出到/private/tmp/s433-blue-helmets-1990.pdf|HTTP 202，0 bytes；不是有效PDF，不能作为图件交付|
|[UN Geospatial public页](https://www.un.org/geospatial/content/public)|web.open及一次curl|HTTP 403；/private/tmp/s433-un-public.html为919字节错误页，不是许可正文存档|
|Geospatial mapsgeo及精确文件名/图号检索|web.open；检索3329-2_Rev-_1.pdf、3329.2与官方Geospatial路径|未得到另一可读的官方原图入口；无第三方转存替代|

上述是一次不同官方附件和独立浏览器的有界补查，没有反复请求同一空响应。图像缺口是下载/渲染未成功，不是已证明档案不存在。

## 网站托管条款是否涵盖本图

[联合国Geospatial许可说明](https://www.un.org/geospatial/es/node/741)的官方搜索索引返回完整段落；直接页面访问403，因此以下是**索引可见条文**，不冒称取得了当前网页正文快照。

网站托管段原文中的条件为：“If, however, it is necessary to host a copy of the map”。同段随后要求注明产品/服务来自联合国Geospatial Information Section，并链接www.un.org/geospatial。总则另含：“and the United Nations is advised”。此处合计引用18个英文词，其余为释义。

适用判断：该页说明联合国地图归联合国所有，并明确许多旧地图可在Dag Hammarskjöld Digital Library取得；S433官方书目把3329.2 Rev.1作者列为UN Geospatial Information Section。因此，**本图属于这份地图政策的对象，博客本地保存副本属于其网站托管段讨论的使用方式**。这是由政策对象和馆藏作者信息作出的适用推断，不是单图另附的开放许可证。

不能从该段推出“公版”“CC授权”或“无条件允许转载”。同页区分未修改地图的出版转载许可申请和网站托管说明；网站托管可以按该段的署名与链接条件处理，但不能忽略总则的告知要求。本次没有向联合国发邮件，也未获得单图书面许可；因此不把“允许托管这一类使用”写成“本次所有条件已经满足”。

如果未来成功取得原图，图注应保留联合国归属、原图号和版次、制图年月1990年6月、态势日期1957年8月，并链接官方地图及Geospatial站点；还需核对图上是否另有第三方权利标注、实际图例与地名，并落实政策要求的告知。此处只登记条件，没有执行外部通知。

## 可交付边界

当前可交付的是官方馆藏链接和准确版次/时间信息；不能交付可用原图。/private/tmp下两份响应只是访问失败证据。若继续推进，所需新增证据是非空、可解码的官方3329.2 Rev.1文件及许可条件落实记录；本轮到此停止。
