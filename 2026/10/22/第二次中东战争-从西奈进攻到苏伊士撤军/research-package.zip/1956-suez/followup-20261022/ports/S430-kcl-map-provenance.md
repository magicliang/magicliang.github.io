# S430：KCL第162页港口战术图溯源

- 论文：Ian Andrew Speller，*The Role of Amphibious Warfare in British Defence Policy, 1945–1964*，King's College London博士论文，1996。
- 原入口：https://kclpure.kcl.ac.uk/ws/portalfiles/portal/2925352/244039.pdf#page=162 。本轮shell无法重新下载，读取旧下载文件并重新解析305页、独立渲染第162页。文件captured/S430-speller.pdf、文本S430-speller.txt、图像S430-map162.png。
- 阅读状态：实际读PDF封面、致谢、图目录、地图前后页、相关书目，并实际view_image图页。不是仅重复旧报告。封面默认CC BY-NC-ND4.0，致谢没有制图者；图目录把Map One列在印刷152页前。地图自身无制图人和另行版权声明。
- 图题：Map One. Port Said and Port Faud, 1956。图内拼作Fuad，外加论文标题拼Faud。制图日期未标，论文1996年不等于制图年；战况标的是11月5日和6日。
- 图面信息：0–2000米、0–1英里线尺；左下Raswa堤道放大插图另有1000米/1000码尺。用文字和实心箭头标示空降、海上登陆、直升机登陆，没有完整军事符号图例。Gamil Airfield、Raswa bridges、Water works、Port Said、Port Fuad、Manzala Canal、Suez Canal、de Lesseps Statue、Fishing harbour等清楚可见。
- 支持M04：3 PARA于5日在Gamil空降，法军2RPC于5日在Raswa和福阿德港方向空降，40/42海军陆战突击队及6RTR于6日海上登陆，45突击队于6日直升机登陆，1REP于6日登陆东岸。这是局部作战图，非纯地形图。它没有逐小时推进线，箭头不证明街区何时肃清。
- 新溯源进展：论文书目明确收Kyle《Suez》1992版；S435出版者预览列出同名图，S436的Figure11呈现与本图相同海岸线、同一堤道插图、相同七组战术标注和SU100/墓地细节。S436前文注149将相邻地图组指向Kyle2011。**这使商业书图成为具体、有图面支撑的来源线索，不再只是抽象“版权不明”。** 但晚出论文的组注仍不能代替1991/1992书页的逐像素核对，更不能证明最初制图者身份。
- 权利结论：KCL封面CC不是第三方地图的独立授权。Kyle2011版权页写Susan Kyle 1991/2003/2011、所有权利保留（S435）；当前不可把该图当Crown旧图或美国政府图转载。可引用KCL原PDF页链接，保留第三方权利说明；本地研究图不等于可发布资产。
