# S451：1955年运河流量原表的替代入口仍未取回

- 任务：B02；核验日期：2026-10-22。
- 目标：United Nations, *Economic Developments in the Middle East, 1956–1957*, E/3116、ST/ECA/55，1958，Table XXIII，印刷页154。
- 替代官方URL：https://www.un.org/development/desa/dpad/wp-content/uploads/sites/45/PDFs/WESS/1957_1956wes_middleeast.pdf
- UN数字馆URL：https://digitallibrary.un.org/record/3903374/files/E_3116--ST_ECA_55-EN.pdf
- 阅读状态：原表未读。DESA入口返回919字节HTML拒绝页；数字馆返回HTTP 202、0字节，未取得PDF。证据：[下载结果](artifacts/download-results.json)、[拒绝页](artifacts/S451-traffic-denied.html)。空文件已移除，避免被误认为有效PDF。

本轮所得是两个入口的实际响应，不是新的1955统计证据。旧S006的搜索索引数字仍未由表头、单位、脚注及1955行共同核实。不能把船舶登记吨位、实际货物重量、油品北向货量混成同一口径，也不能据107.5及66.9等索引数值计算占比后写成已核结果。

状态建议：继续受限。缺少的材料是该报告第154页可读影像，连同表头、单位和脚注；取得以后才能核1955行及油量范围。避免再次仅抓相同索引来宣称原表核验完成。
