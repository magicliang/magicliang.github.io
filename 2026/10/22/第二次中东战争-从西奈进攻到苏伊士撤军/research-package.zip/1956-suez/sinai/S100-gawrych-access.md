# S100 Gawrych：有限预览及访问失败记录

- 原书：George W. Gawrych, Key to the Sinai, CSI Research Survey 7, 1990，147页正文。
- 官方URL：https://www.armyupress.army.mil/Portals/7/combat-studies-institute/csi-books/key-to-the-sinai.pdf
- 结果：web.open及curl均403。IU馆藏https://iucat.iu.edu/iuk/6138950提供https://purl.fdlp.gov/GPO/LPS58749，重定向webharvest.gov历史CGSC页，DNS失败。不是已读PDF。
- 实际可读版本：https://www.everand.com/book/871605558/Key-To-The-Sinai-The-Battles-For-Abu-Agelia-In-The-1956-And-1967-Arab-Israeli-Wars-Illustrated-Edition
- 阅读范围：2014重印本公开预览的目录、序言、导言、A Note on Sources。未读第二章战役全文；不得把重印电子页码与1990印刷页码混用。
- 有限可用判断：导言指出1956以军在艾布奥盖拉有严重困难，埃军撤退与英法轰炸有关；1967的合成突破不能倒灌1956。史料说明坦言以方不开放档案但允许访谈，埃方军史人员据档案做简报、要求匿名；因此即使拿到原书，也须说明这种证据不对称。
- 搜索结果显示的第二章段落只作定位，不计正式已读来源；检索中提到第10旅长Goder和第37旅长Golinka，须防二手网页把两人混为一人。
