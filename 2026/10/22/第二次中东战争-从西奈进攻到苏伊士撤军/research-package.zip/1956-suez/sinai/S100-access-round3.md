# S100：Gawrych 正规公开全文入口第三轮有界核验

日期：2026-10-22。沿用 S100；S111 已用于 IDF 米特拉教育册，避免重复编号。本轮任务是寻找政府原版全文以降低对 S110 的依赖，不是重新认定已经读过战役章。

## 检索及实际结果

|入口|实际请求与结果|结论边界|
|---|---|---|
|Internet Archive 题名检索|`https://archive.org/advancedsearch.php?q=title%3A%28Key%20to%20the%20Sinai%29&output=json&rows=10`，HTTP 200，4285 字节；2 个命中均为 John Erskine 神学著作|没有定位到本书；不能据此断言整个 IA 无扫描|
|Internet Archive 作者检索|`https://archive.org/advancedsearch.php?q=creator%3AGawrych&output=json&rows=50`，HTTP 200，12591 字节，7 条；包括作者的 1973 战争书、青年阿塔图尔克和奥斯曼史，但没有本题名|作者检索也未补出本书；1973 书不能替代 1956 章|
|CGSC CONTENTdm|`https://cgsc.contentdm.oclc.org/digital/api/search/searchterm/Key%20to%20the%20Sinai/field/all/mode/all/conn/and/maxRecords/20` 返回 HTTP 504；将 searchterm 改为 Gawrych 后仍 HTTP 504|未取得馆藏记录或正确下载 ID；不猜 ID 对应书名|
|UNT Digital Library|`https://digital.library.unt.edu/search/?q=%22Key%20to%20the%20Sinai%22&t=fulltext` HTTP 200，3703 字节，但内容是 DAM/ALTCHA 验证页|HTTP 成功不是书目查询成功，未读取搜索结果|
|DTIC|`https://discover.dtic.mil/results/?q=%22Key%20to%20the%20Sinai%22` HTTP 200，390659 字节，但为 WordPress 搜索界面模板，无本书题名记录或报告号|未定位可用全文；不能声称检索库零命中|
|网页索引复核|查询带 CGSC、IA、DTIC 限定的作者题名及排除 ArmyUPress 的 PDF；返回 CGSC 书目及引用本书的论文、Google Books 目录、商业重印预览|引用书目的 PDF 不冒充原书全文，未增加已读战役章|

## 当前可用范围

本轮没有取得 Gawrych 政府原版全文。S100 仍只包括前轮公开预览实读的序言、导言和史料说明，不升级为“已读 1956 战役章”。ArmyUPress 原 PDF 前轮 403、FDLP 历史链接 DNS 失败详见 S100-gawrych-access.md。停止对相同入口无限重试。

战役事实继续以 S107、S108 与 S110 的精确已读范围互证；正文应限制 S110 的派生内容，并保留其争议与漏记，不能把失败获取当作支持任何历史判断的证据。

## 运行证据

本轮实际网络命令及返回记录：`.omo/evidence/suez-sinai-20261022/gawrych-round3-network.txt`；文件及请求结果的重新读取核验：`.omo/evidence/suez-sinai-20261022/verification-round3.txt`。原响应临时缓存位于 `/private/tmp/suez-sinai/*-round3.txt`，临时缓存不构成长久引用。
