# 战术地图缺口最终有界核查

2026-10-22。负责地图研究，不改正文。以下为阅读前登记：西奈局部最多三项，塞得港登陆最多三项；若无法取得图面和权利证据，不据总图推造局部战况。

|编号|候选|要核查的具体问题|状态|
|---|---|---|---|
|MG1|Gawrych，CSI原版PDF，https://www.armyupress.army.mil/Portals/7/combat-studies-institute/csi-books/key-to-the-sinai.pdf|原版1956局部图、图号、第三方制图版权|待重试原版|
|MG2|同书正规电子版预览，https://www.perlego.com/book/3020676/key-to-the-sinai-the-battles-for-abu-agelia-in-the-1956-and-1967-arab-israeli-wars-illustrated-edition-pdf|预览能否取得1956图而非1967图、图注与许可|待看|
|MG3|OpenLibrary1990版馆藏入口，https://openlibrary.org/books/OL8150329M/Key_to_the_Sinai|是否指向原版可读扫描|待看|
|MP1|Keightley官方报告，London Gazette41172，及其导航页https://www.naval-history.net/WXLG-Suez.htm|原版是否含战况附图；区别网站后配1936地形图|待看原版链接|
|MP2|KCL博士论文扫描https://kclpure.kcl.ac.uk/ws/portalfiles/portal/2925352/244039.pdf|MapOne PortSaid1956图的来源、版权及图面|待看|
|MP3|Herbert官方损失报告的公开转录https://militaryimages.net/threads/british-official-report-of-damage-in-port-said-1956.10661/|附图GSGS8011是否有实际扫描、能否支持登陆细节|待看|

## 实际结果

**MG1：未取得。** 原版PDF本轮web打开仍为403。原址确有官方检索索引，不能据此声称实际读到图。此前下载的21页论坛重排文字没有图片，也无原版版权页。保留原址为优先补图入口，不能从缺图文本重新构图冒充史料。

**MG2：预览未提供所需战术图。** 实际读取Perlego页面95–144行，出版者Tannenberg Publishing，2014年，ISBN9781782895794，目录宣传含21幅地图；可见的是Map1，1949–67地缘战略概览。未取得1956艾布奥盖拉局部图，不能猜测电子书图片URL或把总图作为局部图。合法阅读入口可保留，预览也没有给图件开放转载许可。

**MG3：馆藏记录，无公开扫描入口。** 实际读取OpenLibrary1994版记录及1990版列表（311–339行），均为Locate；没有Read/Borrow扫描链接。此结论限定当前读取页面，不断言此书不存在其他数字本。

**MP1：核到报告原始首面，未核到战况附图。** 原始页：https://www.thegazette.co.uk/London/issue/41172/supplement/5327/data.pdf ，实际读到1957年9月12日增刊首面（页5327），并非9月10日正文发表日期。文字称详细组织战术技术建议另送。来源导航页配的1936地图是后添地形背景，不属于报告附图。尝试5336/5337页链接工具返回不可访问，因此不能据此断言整份增刊无附图；当前只是未取得可用战况图。

**MP2：取得真实登陆细节图，但第三方权利链尚缺，暂不建议嵌入。** 已下载Ian Andrew Speller，1996年King's College London博士论文The Role of Amphibious Warfare in British Defence Policy,1945–1964，305页，`/private/tmp/suez-maps/kcl-port-said.pdf`。PDF第162页（插在印刷151页与152页间）为Map One,Port Said and Port Faud,1956。以pdftoppm渲染并实际view_image，截图`/private/tmp/suez-maps/kcl-map162.png`，1273×1800；原图横置。它明确标示5日3PARA在Gamil空降、法军Raswa水厂/桥空降与福阿德港空降、6日40/42Cdo海上登陆和45Cdo直升机登陆、法军1REP海上登陆，并有水厂桥梁局部插图、0–2000米/0–1英里尺。可满足战况内容，不是地形图。

论文封面声明默认CC BY-NC-ND4.0、作者保留版权并要求致谢；但图面无制图署名，图前后未给可识别的单独图源。论文第153页注45说明战斗叙述主要依据Madoc ADM202/455、Richmond ADM116/6209、Keightley DEFE7/1081，不等于证明该图为作者原创。因此**不能把论文整体CC声明自动传递给可能转载的商业书图**。若只引用链接，建议直接指向原PDF第162页；若将来取得图原创确认，可按非商业、署名、保持原图完整的条件再评估。此轮不裁切、不转正到博客资产。

**MP3：访问被挑战页阻挡。** web读取失败；curl取得5617字节HTML，实际解析标题/正文是“Just a moment / Enable JavaScript and cookies”。检索摘要指出报告附GSGS8011两张城镇图，但未取得附件扫描，无法确认是否标了毁损而非登陆路线，也未确认出版日期能否使用Crown期限规则。不能把摘要或论坛声称的“official”当成完成原件核验。

## 交付判断

可公开阅读的地图所在页：[Speller博士论文，PDF第162页](https://kclpure.kcl.ac.uk/ws/portalfiles/portal/2925352/244039.pdf#page=162)。这是图像实际所在的馆藏扫描页链接，不是对该图原创出处或转载许可的确认。西奈原版入口：[CSI《Key to the Sinai》](https://www.armyupress.army.mil/Portals/7/combat-studies-institute/csi-books/key-to-the-sinai.pdf)，由于未取得图面，不能编造具体页码锚点。

本轮每类恰好三项，未找到同时满足“1956战术局部内容、实际原图可看、转载权利链可核”的新增可嵌入图。最有价值后续线索是KCL第162页真实登陆图，但缺单图作者/原出处与权利链；西奈优先保留CSI原版链接。现有USMA全局两图仍只能承担战役尺度，NARA港口图仍只能承担地形尺度。博客若先交付，应明确两类局部战术图未能补齐，不把它们列为完成项。
