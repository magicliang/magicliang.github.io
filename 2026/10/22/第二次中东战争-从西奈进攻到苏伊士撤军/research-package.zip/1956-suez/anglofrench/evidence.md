# 英法/地图研究证据交接

完成范围：S200–S211逐来源包（含访问失败的诚实标注）、F001–F012八字段事件候选、法语S205实际文章阅读、英语S209战报及S210专题段实读。地图完成三张实际下载查看：NARA同期地形图、USMA1956整体两阶段图。**米特拉/阿布奥盖拉战术局部、独立南端局部、塞得港登陆战况原图尚缺；USMA正式转载权利尚有待核项。不得把本包表述为全部地图要求已满足。**

|验收情景|实际调用|二元观察结果|证据路径|
|---|---|---|---|
|NARA历史地图不是缩略图/现代图|curl原件→view_image→PIL读尺寸|PASS：2500×1895，图面8-56、NH36-2、1:250000|captured/port-said-1956-nara-original.jpg；S202-nara-map.md|
|USMA图区分1956与1967|原站目录读取→逐图view_image|PASS：图39标题29–31Oct1956，图40标题1–5Nov1956|captured/usma-sinai-1956-opening.jpg；captured/usma-sinai-1956-conquest.jpg|
|版权不由政府域名推定|读取NARA图面、单件权利、TNA第7节、USMA原站|PASS：保留Crown声明、官方期限说明及USMA重印联系要求；未武断宣布所有图PD|captured/nara-page.html；captured/crown-rights.html；captured/usma-atlas.html|
|战报事件有原文可追溯|web分段open345–705行→curl保存转录|PASS：报告独立于网页左栏作者概述；8字段12事件有节/行定位|captured/keightley-transcript.html；S209-keightley.md；events.md|
|法语实际阅读|web PDF文本2630–2782行|PASS：S205文章全文及档案脚注已读；S203未读全文明确降为线索|S205-cols-bleus.md；S203-mousquetaire-access.md|
|原始图片完整性|Python pathlib/stat+PIL+SHA256|PASS：三个JPEG能解码，以下摘要实测|本表下方|

原件完整性：

- port-said-1956-nara-original.jpg：530797字节；SHA256 d088128bfe27a4705acacce4ebf6fe43313c984f01494f342e2fc08fcc0aab96。
- usma-sinai-1956-opening.jpg：134041字节；SHA256 85152e16a51834a789d8200f83fd5f9487a8657f96d54598aaa8515552d44808。
- usma-sinai-1956-conquest.jpg：135033字节；SHA256 d5b431a141374c7a3e7f492c8d9b2040b6d27cf96cdc14a19bf11381308b5958。
- keightley-transcript.html：262945字节；SHA256 d6d295bd0a1283d016cd700861c16e91efec101ad1f7ca852bcdfdb72c59f0b2。
- crown-rights.html：76114字节；SHA256 fecd42bc626b3028e02217cb754a1abb95e9624b23bdd2ea66e1049dc3ba30e5。

所有captured路径相对此目录；这些副本用于本地研究，主代理决定哪些进入提交，不能把含版权正文的采集文件当博文素材整体公开。
# 2026-10-22补充交付

- 三张地图及完整元数据/采用判断：`../maps/README.md`、`../maps/assets/`。原站图40再下载后SHA256与镜像一致，740×918，可解码且实际view_image。其余两图亦已实际查看；目录三文件Pillow尺寸/hash重新验证通过。
- 伤亡口径：S212议会全文实际读取（vol564 cc201–210），已保存`captured/hansard-casualties.html`（34651字节）；S213阿拉伯语采访正文102–106行实际读取。650是军民合计；1700是2023采访回忆，不是已核实埃官方平民数字。
- 尚缺1956艾布奥盖拉战术图及塞得港详细登陆战况图。取得的Gawrych21页论坛重排文本没有图片，已交西奈研究员阅读，不把这一突破冒称地图完成。
