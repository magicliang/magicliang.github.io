# S203：Opération Mousquetaire访问状态

- 作者：Lieutenant (R) Rémi Mazauric；Soldats de France16，2021年4月，印刷13–14页（先前搜索估14–15不准确，以返回页脚13/14为准）。法语军史综述。
- 原URL：https://www.cheminsdememoire.gouv.fr/sites/default/files/2021-07/mousquetaire.pdf
- 实际读取：搜索索引返回13/14页部分文字和图注，原PDF反复502/DNS，国防部整期镜像503；**未读PDF全文，不作为已完成法语全文来源**。法语实际全文采用S205。
- 已看到的内容：31日空袭，5日Château-Jobert的487人、15时第二批Fossey-François的506人。数字不同于S209战报约500/460，未经原页核对不把精确数放正文。
- 图像：图注明确来源Jacques Massu《La vérité sur Suez:1956》，第三方著作。不能因被法国政府刊物转载而当公有领域，未嵌入图。
- 支持范围：为法国军队叙述与兵力口径的后续追查提供线索；不支持声称已通读、独立史料确证。
