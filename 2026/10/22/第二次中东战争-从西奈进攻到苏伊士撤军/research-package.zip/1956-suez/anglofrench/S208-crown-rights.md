# S208：NARA地图的英国Crown底图

- 机构：The National Archives（英国国家档案馆）；官方版权说明，无明确发布日期，2026-10-22读取。
- URL：https://www.nationalarchives.gov.uk/terms-and-conditions/copyright/copyright-and-related-rights/
- 性质：官方政策解释，非地图自身版权声明。
- 实读：curl取得76114字节HTML并用BeautifulSoup读取第7节全文（不只是搜索摘要）。捕获`/private/tmp/suez-maps/crown-rights.html`。
- 内容：1957年6月1日前由Crown出版的作品，其Crown版权现已届满；通常已发表作品期限自出版年终起50年，未发表档案规则不同。该说明只讲英国法。
- 对S202支持：1956年已印刷、单张地图来自已出版地图系列，图面Crown声明不是今天仍在保护期的证明；NARA本件另明确PD，无需假设所有美国托管材料都PD。
- 限制：不把此规则推广到Massu私人著作、1987 RAF史或USMA地图；不以出版年份推断所有未发表军令图均到期。
