# S202：1956年塞得港地形图

- 问题：M05登陆地区实图、历史地理；不能回答部队推进路线。
- 原件：US Army Map Service, Corps of Engineers，AMS P502 / GSGS 2版，NH36-2，Port Said。
- 原件时间：图面右下印刷日期8-56；地理编绘还使用更早资料，不能将全图信息说成1956年现场测绘。NARA元数据1956年8月。
- 档案：RG77, Published Topographic Maps 1942–1972，NAID596269。
- URL：https://docsteach.org/document/map-port-said-egypt/
- 原图：https://docsteach.org/wp-content/uploads/documents/596269/orig_596269_1065.jpg
- 实际读取：2026-10-22读取单件网页、公开查看器附件API，下载2500×1895图像并调用view_image实际查看。下载文件530797字节（API标原件531262字节，传输版本略有差异）；未伪称看过战况图。
- 文件：`/private/tmp/suez-maps/port-said-1956-nara-original.jpg`；元数据 `/private/tmp/suez-maps/nara-api.json`；网页 `/private/tmp/suez-maps/nara-page.html`。
- 比例尺：1:250000；底边英里、公里、海里三条线性尺；北向在图顶；经纬及Egyptian Red Grid；图例含城市规模、铁路、道路等级、边界、机场、盐沼。
- 可识别地名：Port Said（塞得港）、Port Fuad（福阿德港）、El Gamil（杰米勒一带）、Damietta（达米埃塔）、Lake Manzala（曼宰莱湖）、El Tina Bay（提纳湾）。大部分画面是地中海，港区只占小部分，不能用来说明街区战术。
- 权利审查：DocsTeach本件明确写Public Domain / Free of Known Copyright Restrictions；但实际图面左下写British Crown Copyright Reserved / reproduced with permission of HMSO。故不是因为美国网站托管而推定PD；需要S208英国官方旧Crown期限材料联合解释。印刷美国陆军对英国底图再版，不把全部原始制图归于美国。
- 支持范围：历史港口、湖泊、陆路限制，作为历史地形底图；没有登陆箭头、单位或战况日期，不得称作1956年11月登陆作战图。
- 反证/限制：DocsTeach的简化权利标签不能遮盖图面第三方权利。地图并非整个西奈，也不满足米特拉/阿布奥盖拉局部或蒂朗海峡需求。
- 推荐图注：图：塞得港及曼宰莱湖周边地形（AMS P502，NH36-2，1956年8月印刷，1:250000）。原图由美国国家档案馆保存；无战况标注。
