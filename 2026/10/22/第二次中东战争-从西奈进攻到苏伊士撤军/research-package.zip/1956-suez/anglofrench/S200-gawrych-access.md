# S200：Gawrych访问状态

George W. Gawrych, Key to the Sinai: The Battles for Abu Ageila in the 1956 and 1967 Arab-Israeli Wars，CSI Research Survey7，US Army CGSC，1990，150页。

原站：https://www.armyupress.army.mil/Books/CSI-Press-Publications/Israeli-Conflicts/；PDF：https://www.armyupress.army.mil/Portals/7/combat-studies-institute/csi-books/key-to-the-sinai.pdf 。任务先登记，实际读到官方简介、IU馆藏记录与搜索中的前言/版权提示，**未读取1956章节**。原站PDF web403、shell失败、IAB net::ERR_NAME_NOT_RESOLVED；GPO永久链接跳转webharvest旧站失败；CGSC contentdm公开检索接口504；Internet Archive作者/题名检索返回0。商业重印预览仅目录，不能替代原书。

版权提示显示书中某些材料获第三方许可，不可由“美国陆军出版”推定全书图像PD。无法取得原页时，未采用该书的局部图。米特拉/阿布奥盖拉1956局部地图仍是开放缺口；没有拿1967攻击图充数。

馆藏 https://iucat.iu.edu/iuk/6138950 ；永久链接 https://purl.fdlp.gov/GPO/LPS58749 。Google Books id GL-5V0LKNmcC仅书目索引，未读取扫描正文。
# 后续取得1956章节重排文字（2026-10-22）

公开论坛https://warmap.org/forum.php?mobile=1&mod=viewthread&tid=27 的附件“1956 The Battle of Abu Ageila.pdf”已curl下载，613KB、21页，存`/private/tmp/suez-maps/gawrych-extract.pdf`。pypdf验证标题为The Battle of Abu Ageila,1956，重排页码1–21，每页无内嵌图。不是原书扫描，没有原书页码与版权页，不能用于地图版权核查。正文阅读已交sinai_evidence研究员；本包只确认取得及结构，不声称本研究员读完该章节。
