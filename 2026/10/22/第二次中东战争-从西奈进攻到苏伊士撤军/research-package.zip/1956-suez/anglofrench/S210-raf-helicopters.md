# S210：皇家空军直升机官方史

- 作者：Wing Commander J. R. Dowling，RAF退役军官；Air Historical Branch，Ministry of Defence，1987。
- 题名：RAF Helicopters: The First Twenty Years，Part1。
- URL：https://www.raf.mod.uk/what-we-do/our-history/air-historical-branch/regional-studies-post-coldwar-narratives/raf-helicopters-the-first-twenty-years-pt-1-by-wg-cdr-j-r-dowling/
- 实读：封面/目录、印刷163–164页（PDF索引183–184），web文本5996–6042；未通读全书。
- 问题：6日直升机投送与规模口径。
- 转述：Ocean与Theseus从马耳他出发；45 Commando在近岸投送，着陆区容量限制波次。文本给两单位共415人、25吨、约2.5小时，其中人员、武器和弹药85分钟，其他装备再1小时；与Keightley粗略400人/23吨/90分钟的统计对象、四舍五入或资料源不同，不宜拼成一个“精确”数。
- 作者写0610起降时刻但片段未说明时区，不强行与GMT或埃及本地时间合并。
- 限制：官方军种史着重解释直升机价值；“首次”限定大型舰岸突击，作者自己承认1953马来亚已有小规模战术直升机运用。不得写人类第一次战斗直升机使用。
