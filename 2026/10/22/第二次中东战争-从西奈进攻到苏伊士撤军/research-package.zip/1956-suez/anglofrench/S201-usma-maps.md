# S201：USMA历史图集，图39与图40

- 原机构：US Military Academy，Department of History；原站https://dhc.westpoint.edu/atlases/。实际读取原站概述与Arab-Israeli Wars目录，下载两图并逐图view_image。
- 原出处：Department of History历史教学图集，制作于当代回顾历史时，不是1956战地即时图。原站网页迁移路径2025/01不是制作日期；Commons2005上传也不是制作日期。
- 制图者：图面右下签名F. J. Krasnoborski；原站概述列出本部门现任/前任制图师Edward J. Krasnoborski、Frank Martini、Raymond Hrinko、Jeff Goldberg。签名首字母与站点列名不直接一致，不擅自补全个人身份；可稳妥署USMA历史系。
- 图39原URL：https://dhc.westpoint.edu/wp-content/uploads/sites/6/2025/01/arab20map2039.jpg 。文件`/private/tmp/suez-maps/usma-sinai-1956-opening.jpg`，740×918。标题SINAI / Campaign in Sinai / Opening Phase,29–31 October,1956。覆盖整个西奈、以色列南部、埃及运河。蓝为以军、红为埃军及行动，军事符号表示单位；图注米特拉东侧29日1700空降、30日地面会合，条纹箭头注明提前发动第二阶段。高程英尺色阶、底边0–50英里线尺与北向箭头，格网A–E/1–4；不是地理经纬。
- 图40原URL：https://dhc.westpoint.edu/wp-content/uploads/sites/6/2025/01/arab20map2040.jpg 。实际镜像https://upload.wikimedia.org/wikipedia/commons/9/96/1956_Suez_war_-_conquest_of_Sinai.jpg ，文件`/private/tmp/suez-maps/usma-sinai-1956-conquest.jpg`，740×918。标题Conquest of Sinai,1–5 November,1956。图例/地形与图39一致。南部第9旅沿亚喀巴湾、另一支沿苏伊士湾，注2日202旅两连空降、4日会合、5日沙姆结束。运河边以军2日停在10英里线；英法注5日空降6日登陆，停火前停在Qantara以北。可说明M01西奈整体与M04南部方向，但不能替代战术局部图。
- 地名：Abu Ageila=阿布奥盖拉，Umm Katef/Qatef=乌姆卡特夫，Quseima=库塞马，Mitla Pass=米特拉隘口，Sharm el Sheikh=沙姆沙伊赫，Tiran Island=蒂朗岛，Tor=图尔。
- 具体阅读发现：两个日期区间明确属于1956；当前图集旁边也列1967图41/42，未混用。整幅图只概括路线，不能拿缩略符号证明局部阵地夺取战术。
- 版权证据：Commons单件写美国陆军职务作品PD；原站证实图集是本系制作并以国防印刷机构数字版为基础，同时请求重印联系Jeff Goldberg。后续综合机构作者声明、图40在2005年已经存在、两图无第三方标记，建议作为美国政府职务作品采用；这不是取得授权函，境外保护及图39单件确切年代仍须保留边界。完整判断已更新于`../maps/README.md`，不要仅凭Commons标签。
- 捕获：`/private/tmp/suez-maps/usma-atlas.html`与`commons-search.json`保留原站和单件元数据。
