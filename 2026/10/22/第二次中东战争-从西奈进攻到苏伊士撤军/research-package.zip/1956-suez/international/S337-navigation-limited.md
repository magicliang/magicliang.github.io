# S337：Kern Hills到港候选，未取得可核正文

- 任务：navigation-tasks.md阅读前登记，拟为实际商业航行提供船舶实例。
- 来源：Keesing’s Contemporary Archives，1957年5月4–11日，p15528，Stanford托管单页PDF：https://web.stanford.edu/group/tomzgroup/pmwiki/uploads/1013-1957-1958-K-JS.pdf
- 性质：同期新闻资料汇编，不是联合国或FRUS内部文件；检索文本给Kern Hills于4月6日到埃拉特的说法。
- 阅读状态：**只取得检索文本，未取得可核页图或全文**。web打开确认单页PDF却无抽取正文，截图返回Cache miss；curl返回DNS解析失败。不能将检索文本标为读完。
- 支持/不能支持：可作为未来定位线索；本轮不据此给正文添加船名、吨位、4月6日日期或“第一艘”断言。实际航运核心问题已由S336同期会谈正文满足，无需以摘要填补精确日期。
- 局限：资料编纂者未在可得摘要中明确，无法核查页内原始新闻出处。无新增引用建议。
