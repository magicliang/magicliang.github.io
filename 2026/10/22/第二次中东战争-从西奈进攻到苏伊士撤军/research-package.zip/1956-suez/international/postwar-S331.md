# S331：法国核计划的战前基础与战后推进

URL：https://www.cea.fr/multimedia/Documents/publications/ouvrages/LIVRE-Les-essais-nucleaires-en-Polynesie-francaise.pdf

作者：CEA机构出版，序作者Vincenzo Salvetti（军用部门主任）；《Les essais nucléaires en Polynésie française: Pourquoi, comment, et avec quelles conséquences?》。本次未核版权页出版年，不从搜索抓取时间补造年份。

性质：法国核机构的后出专业说明，带机构自辩背景；不是1954/56原始法令。阅读状态：实际读第一章印刷pp12—13（PDF索引11—12），及目录、标题；未读全140页。法语实读，2026-10-22。

准确转述：1952五年原子能计划构成基础；1954年底孟戴斯-弗朗斯政府决定开展核军备/海军推进方向，BEG在1954年12月底建立。1956年11月军方与CEA分工协议、12月CAMEA成立，1957年3月筹备试验工作组，7月决定建撒哈拉试验中心。

支持：法国核武路线并非1956战争后凭空产生，1956—57组织和试验准备继续推进。不能支持：每个决定由苏伊士引发，或苏联信件直接导致造弹。正文只需1954基础和1957推进两点，不必延伸试验史。脚注所列Mongin/Pô专著没有实际读取，不能作为新独立证据引用。
