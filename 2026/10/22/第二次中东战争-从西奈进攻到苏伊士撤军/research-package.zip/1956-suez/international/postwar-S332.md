# S332：埃及经济控制扩大的分期

URL：https://documents1.worldbank.org/curated/en/800031468248700768/pdf/multi-page.pdf

作者/日期：World Bank, EMENA Region, *Arab Republic of Egypt: Issues of Trade Strategy and Investment Planning*, Report4136-EGT，1983-01-14。报告封面原有限制分发文字，但现公开PDF有Public Disclosure Authorized标记。

性质：世行经济政策专业报告的历史回顾，非1957政府命令；对市场/国家绩效有机构政策视角。

阅读：web因超过10MB失败，curl完整下载26.8MB至/private/tmp/suez-egypt-economy.pdf，pypdf确认507页；实际读封面及印刷pp213—215（PDF274—276）7.2节。未声称读全报告。

转述：报告将1952—60描述为仍以私人企业为背景的工业化。战争后征管英法经济利益，设Economic Organization管理相关企业，并开展1957工业计划；政府控制逐渐增加，但私人、外资活动仍存在。1960米斯尔银行集团国有化与1961—63大规模国有化另属后续阶段。

支持：苏伊士加快国家接管英法资产及工业投资，不应把1956直接写成已经全面社会主义化。反证：1958仍批准外资制药合资，是“立即排除全部外资”的明确反例。不能支持：所有外国居民资产处理均合法、具体个人补偿已完成、经济扩张带来净福利必然上升。与S009居民遭遇必须分层。
