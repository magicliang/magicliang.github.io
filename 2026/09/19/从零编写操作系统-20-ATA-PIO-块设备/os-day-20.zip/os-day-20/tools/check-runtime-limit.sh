#!/bin/sh
set -eu
GDB=${GDB:-gdb-multiarch}

file_size=$(wc -c < build/kernel-memory-cap.bin)
test "$file_size" -le "$PAYLOAD_MAX_BYTES"
memory_size=$(od -An -tu4 -j12 -N4 build/kernel-memory-cap-header.bin | tr -d ' ')
test "$memory_size" -eq "$KERNEL_MEMORY_MAX_BYTES"

objects='build/kernel-entry.o build/kernel-main.o build/kernel-runtime.o build/kernel-console.o build/kernel-exceptions.o build/kernel-isr.o build/kernel-timer.o build/kernel-keyboard.o build/kernel-memory.o build/kernel-paging.o build/kernel-paging-probes.o build/kernel-heap.o build/kernel-task.o build/kernel-switch.o build/kernel-user.o build/kernel-syscall.o build/kernel-elf.o build/kernel-user-entry.o build/kernel-day18-elf-blob.o'
if i686-elf-ld -m elf_i386 --defsym=__kernel_file_max="$PAYLOAD_MAX_BYTES" \
    --defsym=__kernel_memory_max="$KERNEL_MEMORY_MAX_BYTES" \
    --defsym=__kernel_forced_end=0x120001 -z noexecstack \
    -T kernel/linker.ld $objects -o build/kernel-memory-over.elf \
    > build/runtime-link-over.txt 2>&1; then
    echo 'FAIL: 131073-byte runtime image unexpectedly linked' >&2
    exit 1
fi
grep -Fq 'kernel memory exceeds loader bound' build/runtime-link-over.txt

"$QEMU" $QEMU_COMMON -snapshot \
    -drive file=build/mbr-memory-cap.img,format=raw,if=ide \
    -display none -serial file:build/runtime-cap-serial.txt -monitor none \
    -S -gdb tcp:127.0.0.1:1236 > build/runtime-cap-qemu.txt 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
timeout -k 5 180 "$GDB" -q -nx -batch \
    -ex 'set architecture i386' \
    -ex 'set tcp connect-timeout 5' \
    -ex 'set tcp auto-retry on' \
    -ex 'file build/kernel-memory-cap.elf' \
    -ex 'target remote 127.0.0.1:1236' \
    -ex 'hbreak *_start' \
    -ex 'continue' \
    -ex 'python import gdb; m=gdb.selected_inferior(); a=int(gdb.parse_and_eval("&__bss_start")); b=int(gdb.parse_and_eval("&__bss_end")); assert b>0x110000 and bytes(m.read_memory(a,b-a))==bytes([0xa5])*(b-a); print("PASS: stage2 dirtied BSS beyond old 64 KiB runtime limit")' \
    -ex 'hbreak kernel_main' \
    -ex 'continue' \
    -ex 'python import gdb; m=gdb.selected_inferior(); a=int(gdb.parse_and_eval("&__bss_start")); b=int(gdb.parse_and_eval("&__bss_end")); assert bytes(m.read_memory(a,b-a))==bytes(b-a); assert int(gdb.parse_and_eval("&__kernel_end"))-0x100000==131072; print("PASS: entry cleared full BSS and exact 128 KiB runtime image entered C")' \
    -ex 'hbreak elf_demo_done' \
    -ex 'continue' \
    -ex 'python import gdb; assert int(gdb.parse_and_eval("elf_passed"))==1; assert int(gdb.parse_and_eval("free_pages"))==int(gdb.parse_and_eval("elf_initial_pages")); print("PASS: exact-cap image completed allocator, user, syscall and ELF regressions")' \
    -ex 'disconnect' > build/runtime-cap-gdb.txt 2>&1
grep -Fq 'PASS: stage2 dirtied BSS beyond old 64 KiB runtime limit' build/runtime-cap-gdb.txt
grep -Fq 'PASS: entry cleared full BSS and exact 128 KiB runtime image entered C' build/runtime-cap-gdb.txt
grep -Fq 'PASS: exact-cap image completed allocator, user, syscall and ELF regressions' build/runtime-cap-gdb.txt

timeout 8 "$QEMU" $QEMU_COMMON -snapshot \
    -drive file=build/mbr-oversized-memory.img,format=raw,if=ide \
    -display none -serial file:build/runtime-over-serial.txt -monitor none \
    > build/runtime-over-qemu.txt 2>&1 || true
grep -Fq 'D03 HEADER FAIL' build/runtime-over-serial.txt
if grep -Fq 'D03 PAYLOAD OK' build/runtime-over-serial.txt; then
    echo 'FAIL: oversized runtime header reached payload copy' >&2
    exit 1
fi

cat build/runtime-cap-gdb.txt
