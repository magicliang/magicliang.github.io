#!/bin/sh
set -eu
GDB=${GDB:-gdb-multiarch}

test "$(wc -c < build/mbr.img)" -eq $((4096 * 512))
test "$(wc -c < build/block-pattern-2047.bin)" -eq 512
test "$(wc -c < build/block-pattern-4095.bin)" -eq 512
dd if=build/mbr.img of=build/block-readback-2047.bin bs=512 skip=2047 count=1 status=none
dd if=build/mbr.img of=build/block-readback-4095.bin bs=512 skip=4095 count=1 status=none
cmp build/block-pattern-2047.bin build/block-readback-2047.bin
cmp build/block-pattern-4095.bin build/block-readback-4095.bin
test "$(wc -c < build/kernel.bin)" -le 65536

"$QEMU" $QEMU_COMMON -snapshot -drive file=build/mbr.img,format=raw,if=ide \
    -display none -serial file:build/day20-block-serial.txt -monitor stdio \
    -S -gdb tcp:127.0.0.1:1240 > build/day20-block-qemu.txt 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
timeout -k 5 180 "$GDB" -q -nx -batch \
    -ex 'set architecture i386' \
    -ex 'set tcp connect-timeout 5' \
    -ex 'set tcp auto-retry on' \
    -ex 'file build/kernel.elf' \
    -ex 'target remote 127.0.0.1:1240' \
    -ex 'hbreak block_demo_done' \
    -ex 'continue' \
    -ex 'python import gdb; v=lambda e:int(gdb.parse_and_eval(e)); assert v("block_passed")==1 and v("block_result")==0 and v("block_capacity")==4096; assert v("block_reads")==3 and v("block_range_rejects")==3 and v("block_channel_failed")==0; assert v("block_hash_middle")==v("block_expected_middle") and v("block_hash_last")==v("block_expected_last"); print("PASS: IDENTIFY, MBR, two patterned sectors and range rejection verified")' \
    -ex 'monitor screendump build/day20-screen.png -f png' \
    -ex 'hbreak keyboard_ready' \
    -ex 'continue' \
    -ex 'printf "PASS: block demo reaches original blocking keyboard consumer\n"' \
    -ex 'disconnect' > build/day20-block-gdb.txt 2>&1
kill "$pid" 2>/dev/null || true
wait "$pid" 2>/dev/null || true
trap - EXIT HUP INT TERM

run_failure()
{
    name=$1
    image=$2
    elf=$3
    port=$4
    assertion=$5
    "$QEMU" $QEMU_COMMON -snapshot -drive file="$image",format=raw,if=ide \
        -display none -serial file:"build/day20-$name-serial.txt" -monitor stdio \
        -S -gdb tcp:127.0.0.1:"$port" > "build/day20-$name-qemu.txt" 2>&1 &
    pid=$!
    trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
    timeout -k 5 180 "$GDB" -q -nx -batch \
        -ex 'set architecture i386' \
        -ex 'set tcp connect-timeout 5' \
        -ex 'set tcp auto-retry on' \
        -ex "file $elf" \
        -ex "target remote 127.0.0.1:$port" \
        -ex 'hbreak block_demo_done' \
        -ex 'continue' \
        -ex "python import gdb; v=lambda e:int(gdb.parse_and_eval(e)); $assertion; print('PASS: $name failure is diagnosed and channel fails closed')" \
        -ex 'disconnect' > "build/day20-$name-gdb.txt" 2>&1
    kill "$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
    trap - EXIT HUP INT TERM
}

run_failure timeout build/mbr-block-timeout.img build/kernel-block-timeout.elf 1241 \
    'assert v("block_passed")==1 and v("block_result")==-5 and v("block_followup_result")==-7; assert v("block_last_stage")==3 and v("block_last_status")==0x80 and v("block_tick_delta")>=3; assert v("block_channel_failed")==1'
run_failure nodrq build/mbr-block-nodrq.img build/kernel-block-nodrq.elf 1242 \
    'assert v("block_passed")==1 and v("block_result")==-5 and v("block_followup_result")==-7; assert v("block_last_stage")==3 and v("block_last_status")==0x40 and v("block_tick_delta")>=3; assert v("block_channel_failed")==1'
run_failure error build/mbr-block-error.img build/kernel-block-error.elf 1243 \
    'assert v("block_passed")==1 and v("block_result")==-6 and v("block_followup_result")==-7; assert v("block_last_lba")==v("block_capacity") and (v("block_last_status")&1)==1 and v("block_last_error")==4; assert v("block_channel_failed")==1'

grep -Fq 'D20 ATA primary master LBA28 sectors=4096 reads=3' build/day20-block-serial.txt
grep -Fq 'BLOCK OK mode=0 result=0 followup=0 failed=0' build/day20-block-serial.txt
grep -Fq 'D20 FAIL busy-timeout stage=3 status=80 error=0' build/day20-timeout-serial.txt
grep -Fq 'BLOCK OK mode=1 result=-5 followup=-7 failed=1' build/day20-timeout-serial.txt
grep -Fq 'D20 FAIL missing-drq stage=3 status=40 error=0' build/day20-nodrq-serial.txt
grep -Fq 'BLOCK OK mode=3 result=-5 followup=-7 failed=1' build/day20-nodrq-serial.txt
grep -Fq 'D20 FAIL device-error lba=4096 status=41 error=4' build/day20-error-serial.txt
grep -Fq 'BLOCK OK mode=2 result=-6 followup=-7 failed=1' build/day20-error-serial.txt
sed -n '/PASS:/p' build/day20-block-gdb.txt
sed -n '/PASS:/p' build/day20-timeout-gdb.txt
sed -n '/PASS:/p' build/day20-nodrq-gdb.txt
sed -n '/PASS:/p' build/day20-error-gdb.txt
