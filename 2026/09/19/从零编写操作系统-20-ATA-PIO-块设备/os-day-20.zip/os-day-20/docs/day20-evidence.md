# 第 20 篇：ATA PIO 块设备实测

日期：2026-09-19。本记录对应第 20 篇累计源码，只记录实际构建和启动所得结果。冻结 ZIP 的哈希由正文与续写状态记录，避免源码包自引用。

## 环境与范围

实际工具为 i686-elf GCC 13.3.0、Binutils 2.42、NASM 2.16.01、QEMU 8.2.2 和 GDB multiarch 15.1。客体固定为 `pc-i440fx-7.2`、`qemu32`、TCG、1 CPU、64 MiB，固件为云端工具目录中的 SeaBIOS。磁盘以 IDE primary master 接入；所有测试使用 `-snapshot`，宿主镜像未被客体写入。

本篇只实现 ATA PIO、28 位 LBA、一次一扇区的只读接口。没有实现 PCI 枚举、LBA48、DMA、ATAPI、写盘、IRQ14 请求完成通知、软件复位或真实硬件兼容层。

## 构建与容量

普通 `kernel.bin` 为 64,976 字节，SHA-256 为 `03d2fd01ce2f3a6b61fdce5170c5c558c785d23f34ae9e15c3f128da148c4172`；距离既有 65,536 字节文件上限还剩 560 字节。`mbr.img` 为 2,097,152 字节（4096 个扇区），SHA-256 为 `bec257864af410eb64a9b30230538e91c0dc525f2e14f9d03107a48842442541`。本篇没有扩大文件上限、运行内存上限或实模式装载窗口。

宿主工具分别为 LBA 2047 和 4095 生成 512 字节确定性模式，SHA-256 为 `57f40a03ff5d13b14534cac2a960c703ba05ac6af114d2b87a9e68ad797823a5` 与 `1aa12e05d1500268ccba4613c68cf1534edb7562643b1b80d92a2fca494eabd3`。检查脚本在启动前又从最终镜像读回并逐字节 `cmp`，排除“生成了模式但没有写入启动盘”的假阳性。

## 正常读取

`make check-block` 实际启动普通镜像。驱动先发送 IDENTIFY DEVICE，确认 LBA 能力位并从 words 60–61 得到 4096 个扇区；随后读取 LBA 0、2047 和 4095。LBA 0 的结尾必须为 `55 aa`，另两扇区在客体内按 FNV-1a 计算并与同一模式公式的独立期望值比较。串口结果为：

```text
D20 ATA primary master LBA28 sectors=4096 reads=3
D20 hashes mbr=17b4a429 lba2047=c748f45 lba4095=ce0d7bc5 range=3
BLOCK OK mode=0 result=0 followup=0 failed=0 ticks=0
```

公共接口拒绝 `lba == 4096`、`lba == 0x10000000` 和空缓冲区，共三次参数拒绝；这些错误发生在发命令前，因此没有污染通道。GDB 检查容量、三次成功读取、三次拒绝、两个模式哈希和 `block_channel_failed==0`，之后继续到原有 `keyboard_ready`，证明块设备演示没有截断累计启动链。

## 三条故障路径

超时镜像只改客体读取状态的测试分支，不改正常镜像。第一条在 READ 命令发出后持续返回 BSY，第二条返回 DRDY 但不出现 DRQ。两条都由真实 PIT tick 推进 3 tick deadline，而不是宿主等待时间冒充客体超时：

```text
D20 FAIL busy-timeout stage=3 status=80 error=0 ticks=3 polls=4
BLOCK OK mode=1 result=-5 followup=-7 failed=1 ticks=3
D20 FAIL missing-drq stage=3 status=40 error=0 ticks=3 polls=4
BLOCK OK mode=3 result=-5 followup=-7 failed=1 ticks=3
```

第三条没有伪造 ATA 状态。它绕过公共容量检查，向 QEMU 的实际 IDE 设备发送 LBA 4096。固定 QEMU 返回 status `0x41`（DRDY|ERR）与 error `0x04`（ABRT）：

```text
D20 FAIL device-error lba=4096 status=41 error=4
BLOCK OK mode=2 result=-6 followup=-7 failed=1 ticks=0
```

三条路径都在命令已经发出后把通道标记为 FAILED，下一次合法读取返回 `BLOCK_ECHANNEL`。本篇没有把“返回了错误码”写成“设备已经恢复”，也没有继续发送可能与上一命令数据阶段串包的新命令。

## 累计回归

在同一源码上执行并退出 0：

```text
make build
make check-block
make check-process
make check-syscall
make check-elf
make check-memory
make check-runtime-limit
```

第 19 篇的中间 GDB 观察点原先可能在 COUNT 首次递增前触发，却又断言其进度大于零。新增块代码改变二进制布局后实际撞到了这个调度时序。累计源码将观察条件收紧为“COUNT 已至少递增一次”再停下；资源回收、进程结果和用户 ABI 未改变。修正后 `check-process` 的正常与分配失败镜像均退出 0。

累计普通镜像从 BIOS 依次输出 Day 10–19 的成功标记，再进入块设备演示并回到阻塞键盘消费者。`check-memory` 记录 `kernel_end=0x1161f0`，`check-runtime-limit` 仍验证精确 128 KiB 运行镜像及旧 64 KiB 以上 BSS 清零。本轮没有把已知 GDB 15.1 控制问题的旧 `check-user` 重新标成通过。

随后把源码复制到一个不存在 `build/` 的空目录，重新执行上述七个目标，全部退出 0。重建的 `kernel.bin`、`mbr.img` 和 `day19-user.elf` 哈希与主工作区完全一致；完整构建与检查输出保存为 `docs/day20-standalone.txt`。

## 持久证据

| 文件 | SHA-256 |
| --- | --- |
| `docs/day20-block-gdb.txt` | `d13a465c4d0041be596e2d55105ed11ff93b1cb50906a2e800fc504a1725ec93` |
| `docs/day20-block-serial.txt` | `e50ef046c7583abbc5b922cc584a646c867550af1a0d949116369d8042ffd309` |
| `docs/day20-timeout-gdb.txt` | `f6a1fbf74d293b558d874b94800fd2a59a366bbb67ac03df3d629d24c22f1061` |
| `docs/day20-timeout-serial.txt` | `0cd7300024f2b9d34106f8f716fa7b6f366b6a3560310704e395034582ef9852` |
| `docs/day20-nodrq-gdb.txt` | `8e2e562f2f33b2aed18cef5e2a5f4f516d8f060ec7636a759f841183e5b51dd3` |
| `docs/day20-nodrq-serial.txt` | `d9205695f13b04ddf0511c5d45335c7b36045e3049561b948f1c09e45da6e816` |
| `docs/day20-error-gdb.txt` | `2bf5c6edd25652f312954c00e954088da52d7913b300600197f69ad1990d69a1` |
| `docs/day20-error-serial.txt` | `bb7fd3fbba9f32c2de6ebe49a3832f9e6420a9a2ffa066373f780a0d0dda0a7c` |
| `docs/day20-screen.png` | `a88980adf4b34301e31a37534ed5edbcc524a141bb87422932dc81ef4b90f3c0` |
| `docs/day20-standalone.txt` | `c1ea45e0847806e89053ebb6cdb3fc29581c3d28af1ef58f881da3ddccbc340e` |

四个 QEMU 日志都只包含监视器启动和受控终止，SHA-256 同为 `6acfa70e7a1b54bd8fc6453522272cb3ef6135a5a0a446a7ceab314a87b7ddff`。源码、日志和截图均在 `writing-plans/` 内，不依赖 `/tmp` 作为唯一副本。

## 验证边界

- 超时注入验证了驱动的 tick deadline 与 fail-closed 分支，没有证明真实磁盘恰好会以同样状态卡死。
- ERR/ABRT 是 QEMU 8.2.2 对本镜像容量外 LBA 的观察，不外推为所有 ATA 设备的相同 error 值。
- 轮询等待在 IF=1 时用 `hlt` 让 PIT 推进；IF=0 时只有轮询预算兜底。本篇没有并发 I/O 请求队列，也没有证明任务持有请求期间退出时的所有权转移。
- 四次 alternate-status 读取作为保守选择/命令延迟序列使用，没有在真实硬件上测量 400 ns。
- 未验证 IRQ14、软件复位、热插拔、secondary channel、slave、LBA48、DMA、ATAPI、写盘、真实硬件和其他 QEMU machine type。
