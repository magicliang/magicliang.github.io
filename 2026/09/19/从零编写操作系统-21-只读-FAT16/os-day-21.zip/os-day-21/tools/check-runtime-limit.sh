#!/bin/sh
set -eu
GDB=${GDB:-gdb-multiarch}

file_size=$(wc -c < build/kernel-memory-cap.bin)
test "$file_size" -le "$PAYLOAD_MAX_BYTES"
memory_size=$(od -An -tu4 -j12 -N4 build/kernel-memory-cap-header.bin | tr -d ' ')
test "$memory_size" -eq "$KERNEL_MEMORY_MAX_BYTES"

test "$(wc -c < build/kernel-file-cap.bin)" -eq "$PAYLOAD_MAX_BYTES"
file_cap_header_size=$(od -An -tu4 -j8 -N4 build/kernel-file-cap-header.bin | tr -d ' ')
test "$file_cap_header_size" -eq "$PAYLOAD_MAX_BYTES"

if build/mkpayload build/kernel-file-cap.bin build/rejected-file-cap-header.bin \
    build/rejected-file-cap-badmagic.bin build/rejected-file-cap-oversized.bin \
    build/rejected-file-cap-memory.bin "$((PAYLOAD_MAX_BYTES + 1))" \
    "$PAYLOAD_MAX_BYTES" "$KERNEL_MEMORY_MAX_BYTES" 0x334f5342 \
    "$((PAYLOAD_MAX_BYTES + 1))" 0 > build/file-cap-over.txt 2>&1; then
    echo 'FAIL: 131073-byte file declaration unexpectedly accepted' >&2
    exit 1
fi
grep -Fq "payload size $((PAYLOAD_MAX_BYTES + 1)) outside 64..$PAYLOAD_MAX_BYTES" \
    build/file-cap-over.txt

timeout 8 "$QEMU" $QEMU_COMMON -snapshot \
    -drive file=build/mbr-oversized-header.img,format=raw,if=ide \
    -display none -serial file:build/file-over-serial.txt -monitor none \
    > build/file-over-qemu.txt 2>&1 || true
grep -Fq 'D03 HEADER FAIL' build/file-over-serial.txt
if grep -Fq 'D03 PAYLOAD OK' build/file-over-serial.txt; then
    echo 'FAIL: oversized file header reached payload copy' >&2
    exit 1
fi

objects='build/kernel-entry.o build/kernel-main.o build/kernel-runtime.o build/kernel-console.o build/kernel-exceptions.o build/kernel-isr.o build/kernel-timer.o build/kernel-keyboard.o build/kernel-memory.o build/kernel-paging.o build/kernel-paging-probes.o build/kernel-heap.o build/kernel-task.o build/kernel-switch.o build/kernel-user.o build/kernel-syscall.o build/kernel-elf.o build/kernel-block.o build/kernel-fat.o build/kernel-user-entry.o build/kernel-day18-elf-blob.o build/kernel-day19-elf-blob.o'
if i686-elf-ld -m elf_i386 --defsym=__kernel_file_max="$PAYLOAD_MAX_BYTES" \
    --defsym=__kernel_memory_max="$KERNEL_MEMORY_MAX_BYTES" \
    --defsym=__kernel_forced_end=0x140001 -z noexecstack \
    -T kernel/linker.ld $objects -o build/kernel-memory-over.elf \
    > build/runtime-link-over.txt 2>&1; then
    echo 'FAIL: 262145-byte runtime image unexpectedly linked' >&2
    exit 1
fi
grep -Fq 'kernel memory exceeds loader bound' build/runtime-link-over.txt

"$QEMU" $QEMU_COMMON -snapshot \
    -drive file=build/mbr-memory-cap.img,format=raw,if=ide \
    -display none -serial file:build/runtime-cap-serial.txt -monitor none \
    -S -gdb tcp:127.0.0.1:1236 > build/runtime-cap-qemu.txt 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
timeout -k 5 180 "$GDB" -q -nx -batch \
    -ex 'set architecture i386' \
    -ex 'set tcp connect-timeout 5' \
    -ex 'set tcp auto-retry on' \
    -ex 'file build/kernel-memory-cap.elf' \
    -ex 'target remote 127.0.0.1:1236' \
    -ex 'hbreak *_start' \
    -ex 'continue' \
    -ex 'python import gdb; m=gdb.selected_inferior(); a=int(gdb.parse_and_eval("&__bss_start")); b=int(gdb.parse_and_eval("&__bss_end")); assert b>0x110000 and bytes(m.read_memory(a,b-a))==bytes([0xa5])*(b-a); print("PASS: stage2 dirtied BSS beyond old 64 KiB runtime limit")' \
    -ex 'hbreak kernel_main' \
    -ex 'continue' \
    -ex 'python import gdb; m=gdb.selected_inferior(); a=int(gdb.parse_and_eval("&__bss_start")); b=int(gdb.parse_and_eval("&__bss_end")); assert bytes(m.read_memory(a,b-a))==bytes(b-a); assert int(gdb.parse_and_eval("&__kernel_end"))-0x100000==262144; print("PASS: entry cleared full BSS and exact 256 KiB runtime image entered C")' \
    -ex 'hbreak elf_demo_done' \
    -ex 'continue' \
    -ex 'python import gdb; assert int(gdb.parse_and_eval("elf_passed"))==1; assert int(gdb.parse_and_eval("free_pages"))==int(gdb.parse_and_eval("elf_initial_pages")); print("PASS: exact-cap image completed allocator, user, syscall and ELF regressions")' \
    -ex 'disconnect' > build/runtime-cap-gdb.txt 2>&1
grep -Fq 'PASS: stage2 dirtied BSS beyond old 64 KiB runtime limit' build/runtime-cap-gdb.txt
grep -Fq 'PASS: entry cleared full BSS and exact 256 KiB runtime image entered C' build/runtime-cap-gdb.txt
grep -Fq 'PASS: exact-cap image completed allocator, user, syscall and ELF regressions' build/runtime-cap-gdb.txt

"$QEMU" $QEMU_COMMON -snapshot \
    -drive file=build/mbr-file-cap.img,format=raw,if=ide \
    -display none -serial file:build/file-cap-serial.txt -monitor none \
    -S -gdb tcp:127.0.0.1:1237 > build/file-cap-qemu.txt 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
timeout -k 5 180 "$GDB" -q -nx -batch \
    -ex 'set architecture i386' \
    -ex 'set tcp connect-timeout 5' \
    -ex 'set tcp auto-retry on' \
    -ex 'file build/kernel.elf' \
    -ex 'target remote 127.0.0.1:1237' \
    -ex 'hbreak *_start' \
    -ex 'continue' \
    -ex "python import gdb; p=open('build/kernel-file-cap.bin','rb').read(); assert len(p)==$PAYLOAD_MAX_BYTES; assert bytes(gdb.selected_inferior().read_memory(0x100000,len(p)))==p; print('PASS: exact 128 KiB file crossed real-mode segments, checksum and protected-mode copy')" \
    -ex 'disconnect' > build/file-cap-gdb.txt 2>&1
kill "$pid" 2>/dev/null || true
wait "$pid" 2>/dev/null || true
trap - EXIT HUP INT TERM
grep -Fq 'PASS: exact 128 KiB file crossed real-mode segments' build/file-cap-gdb.txt

timeout 8 "$QEMU" $QEMU_COMMON -snapshot \
    -drive file=build/mbr-oversized-memory.img,format=raw,if=ide \
    -display none -serial file:build/runtime-over-serial.txt -monitor none \
    > build/runtime-over-qemu.txt 2>&1 || true
grep -Fq 'D03 HEADER FAIL' build/runtime-over-serial.txt
if grep -Fq 'D03 PAYLOAD OK' build/runtime-over-serial.txt; then
    echo 'FAIL: oversized runtime header reached payload copy' >&2
    exit 1
fi

cat build/runtime-cap-gdb.txt
cat build/file-cap-gdb.txt
printf '%s\n' 'PASS: oversized file and memory headers rejected before payload copy'
