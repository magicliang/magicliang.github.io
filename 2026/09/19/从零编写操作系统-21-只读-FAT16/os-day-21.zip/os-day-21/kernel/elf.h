#ifndef ELF_H
#define ELF_H

#include <stdint.h>
#include "user.h"

enum elf_result {
    ELF_OK = 0,
    ELF_ERR_SHORT = -1,
    ELF_ERR_IDENT = -2,
    ELF_ERR_HEADER = -3,
    ELF_ERR_PHDR_TABLE = -4,
    ELF_ERR_PHDR_TYPE = -5,
    ELF_ERR_SEGMENT_SIZE = -6,
    ELF_ERR_FILE_RANGE = -7,
    ELF_ERR_ALIGN = -8,
    ELF_ERR_VADDR = -9,
    ELF_ERR_ORDER = -10,
    ELF_ERR_OVERLAP = -11,
    ELF_ERR_PAGE_LIMIT = -12,
    ELF_ERR_ENTRY = -13,
    ELF_ERR_NOMEM = -14,
    ELF_ERR_FLAGS = -15,
    ELF_ERR_OUTPUT = -16
};

extern volatile unsigned elf_fail_after;
extern volatile unsigned elf_last_allocations;
int elf_load(const void *bytes, uint32_t size, struct user_space *out);
void elf_negative_tests(void);
extern volatile unsigned elf_negative_passes;

#endif
