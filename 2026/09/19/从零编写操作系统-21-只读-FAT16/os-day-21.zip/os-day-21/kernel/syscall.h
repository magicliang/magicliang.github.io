#ifndef SYSCALL_H
#define SYSCALL_H

#include <stddef.h>
#include <stdint.h>
#include "exceptions.h"

#define SYS_WRITE 1u
#define SYS_YIELD 2u
#define SYS_SPAWN 3u
#define SYS_EXIT 4u
#define SYS_WAIT 5u
#define SYSCALL_WRITE_MAX 256u

int user_range_ok(uint32_t cr3, uintptr_t address, size_t length,
                  int write_access);
int copy_from_user(void *destination, uintptr_t address, size_t length);
int copy_to_user(uintptr_t address, const void *source, size_t length);
void syscall_dispatch(struct trap_frame *frame);

extern volatile uint32_t syscall_count;
extern volatile uint32_t syscall_write_count;
extern volatile uint32_t syscall_yield_count;
extern volatile uint32_t syscall_error_count;
extern volatile uint32_t syscall_irq_ticks;

#endif
