#ifndef TASK_H
#define TASK_H
#include <stdint.h>
/* One CPU, ordinary call boundaries only; never yield while holding a lock. */
int task_create(void (*entry)(void *), void *arg);
void task_yield(void);
_Noreturn void task_exit(void);
void task_demo(unsigned starve);
void task_trap_enter(void);
void task_trap_leave(unsigned interrupted_if);
void task_tick(void);
void preempt_disable(void);
void preempt_enable(void);
void preempt_demo(unsigned diagnostic);
uint32_t irq_save(void);
void irq_restore(uint32_t flags);
struct wait_queue { unsigned mask; }; /* ponytail: fixed-slot set; FIFO links if wake order matters. */
void task_block_locked(struct wait_queue *q);
int wake_one_locked(struct wait_queue *q);
void sleep_ticks(uint32_t ticks);
void wait_demo(unsigned broken);
void task_keyboard_start(void);
void task_request_reschedule(void);
void syscall_demo(void);
void elf_demo(void);
void process_demo(unsigned failure_mode);
int32_t task_spawn_process(const char *name, unsigned io_map);
void task_request_exit(uint32_t status);
int32_t task_wait_process(int32_t pid, uintptr_t status_address);
void task_note_wait_fault(void);
extern volatile uint32_t syscall_yield_before;
extern volatile uint32_t syscall_yield_after;
extern volatile uint32_t syscall_yield_switched;
#endif
