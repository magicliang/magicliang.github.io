#ifndef USER_H
#define USER_H
#include <stdint.h>
#include "exceptions.h"
#define USER_CODE 0x40000000u
#define USER_DATA 0x40001000u
#define USER_STACK 0x80000000u
#define USER_LOAD_END 0x40400000u
#define USER_SPACE_PAGES 12u
enum user_space_kind { USER_SPACE_NONE, USER_SPACE_BLOB, USER_SPACE_ELF };
struct user_space {
    uint32_t pages[USER_SPACE_PAGES]; /* PD, two PTs, code/data, stack at 5, extra LOAD pages. */
    uint32_t entry, stack_top;
    unsigned page_count, kind;
};
extern uint32_t user_kernel_cr3;
extern volatile unsigned user_fail_after;
void user_init(void);
int user_space_create(struct user_space *space, unsigned mode, uint32_t sentinel);
void user_space_destroy(struct user_space *space);
int user_space_physical(const struct user_space *space, uint32_t address,
                        int write_access, uint32_t *physical);
void user_switch(uint32_t pd, uint32_t stack_top);
_Noreturn void enter_user(uint32_t ip, uint32_t sp);
void user_demo(void);
int task_user_trap(struct trap_frame *frame, uint32_t address);
#endif
