#include "elf.h"
#include "console.h"
#include "memory.h"
#include "runtime.h"

#define PT_NULL 0u
#define PT_LOAD 1u
#define PF_X 1u
#define PF_W 2u
#define PF_R 4u
#define LOAD_PAGE_LIMIT 8u
#define PAGE_MASK 0xfffff000u

struct elf32_ehdr {
    uint8_t ident[16];
    uint16_t type, machine;
    uint32_t version, entry, phoff, shoff, flags;
    uint16_t ehsize, phentsize, phnum, shentsize, shnum, shstrndx;
} __attribute__((packed));

struct elf32_phdr {
    uint32_t type, offset, vaddr, paddr, filesz, memsz, flags, align;
} __attribute__((packed));

struct load_plan {
    struct elf32_phdr ph;
    uint32_t first_page, end_page;
};

volatile unsigned elf_fail_after = UINT32_MAX;
volatile unsigned elf_last_allocations;
volatile unsigned elf_negative_passes;

_Static_assert(sizeof(struct elf32_ehdr) == 52, "ELF32 header size");
_Static_assert(sizeof(struct elf32_phdr) == 32, "ELF32 program header size");

static int alloc_page(struct user_space *space, unsigned slot)
{
    if (elf_last_allocations == elf_fail_after) return 0;
    uint32_t page = page_alloc();
    if (!page) return 0;
    space->pages[slot] = page;
    ++space->page_count;
    ++elf_last_allocations;
    memset((void *)page, 0, PAGE_BYTES);
    return 1;
}

static int validate(const uint8_t *bytes, uint32_t size,
                    struct elf32_ehdr *header, struct load_plan plans[8],
                    unsigned *load_count, unsigned *page_count)
{
    if (size < sizeof(*header)) return ELF_ERR_SHORT;
    memcpy(header, bytes, sizeof(*header));
    if (header->ident[0] != 0x7f || header->ident[1] != 'E' ||
        header->ident[2] != 'L' || header->ident[3] != 'F' ||
        header->ident[4] != 1 || header->ident[5] != 1 ||
        header->ident[6] != 1 || header->ident[7] != 0 ||
        header->ident[8] != 0)
        return ELF_ERR_IDENT;
    if (header->type != 2 || header->machine != 3 || header->version != 1 ||
        header->flags != 0 || header->ehsize != sizeof(*header) ||
        header->phentsize != sizeof(struct elf32_phdr) ||
        !header->phnum || header->phnum > 8)
        return ELF_ERR_HEADER;
    if (header->phoff > size ||
        header->phnum > (size - header->phoff) / header->phentsize)
        return ELF_ERR_PHDR_TABLE;

    *load_count = 0;
    *page_count = 0;
    uint32_t previous_vaddr = 0;
    uint32_t previous_end_page = 0;
    for (unsigned i = 0; i < header->phnum; ++i) {
        struct elf32_phdr ph;
        memcpy(&ph, bytes + header->phoff + i * header->phentsize,
               sizeof(ph));
        if (ph.type == PT_NULL) continue;
        if (ph.type != PT_LOAD) return ELF_ERR_PHDR_TYPE;
        if ((ph.flags & ~(PF_R | PF_W | PF_X)) ||
            !(ph.flags & (PF_R | PF_W | PF_X)))
            return ELF_ERR_FLAGS;
        if (!ph.memsz || ph.filesz > ph.memsz) return ELF_ERR_SEGMENT_SIZE;
        if (ph.offset > size || ph.filesz > size - ph.offset)
            return ELF_ERR_FILE_RANGE;
        if (ph.align > 1 && (ph.align & (ph.align - 1)))
            return ELF_ERR_ALIGN;
        if (ph.align > 1 && ph.vaddr % ph.align != ph.offset % ph.align)
            return ELF_ERR_ALIGN;
        if ((ph.vaddr & (PAGE_BYTES - 1)) !=
            (ph.offset & (PAGE_BYTES - 1)))
            return ELF_ERR_ALIGN;
        if (ph.vaddr < USER_CODE || ph.vaddr >= USER_LOAD_END ||
            ph.memsz > USER_LOAD_END - ph.vaddr)
            return ELF_ERR_VADDR;

        uint32_t end = ph.vaddr + ph.memsz;
        uint32_t first_page = ph.vaddr & PAGE_MASK;
        uint32_t end_page = (end + PAGE_BYTES - 1) & PAGE_MASK;
        if (end_page < end) return ELF_ERR_VADDR;
        if (*load_count && ph.vaddr < previous_vaddr) return ELF_ERR_ORDER;
        if (*load_count && first_page < previous_end_page)
            return ELF_ERR_OVERLAP;
        unsigned pages = (end_page - first_page) / PAGE_BYTES;
        if (pages > LOAD_PAGE_LIMIT - *page_count)
            return ELF_ERR_PAGE_LIMIT;
        plans[*load_count] = (struct load_plan){ph, first_page, end_page};
        ++*load_count;
        *page_count += pages;
        previous_vaddr = ph.vaddr;
        previous_end_page = end_page;
    }
    if (!*load_count) return ELF_ERR_HEADER;

    for (unsigned i = 0; i < *load_count; ++i) {
        const struct elf32_phdr *ph = &plans[i].ph;
        if ((ph->flags & PF_X) && header->entry >= ph->vaddr &&
            header->entry - ph->vaddr < ph->memsz)
            return ELF_OK;
    }
    return ELF_ERR_ENTRY;
}

int elf_load(const void *image, uint32_t size, struct user_space *out)
{
    const uint8_t *bytes = image;
    struct elf32_ehdr header;
    struct load_plan plans[8];
    unsigned load_count, load_pages;
    for (unsigned i = 0; i < USER_SPACE_PAGES; ++i)
        if (out->pages[i]) return ELF_ERR_OUTPUT;
    if (out->entry || out->stack_top || out->page_count || out->kind)
        return ELF_ERR_OUTPUT;
    elf_last_allocations = 0;
    int result = validate(bytes, size, &header, plans, &load_count,
                          &load_pages);
    if (result != ELF_OK) return result;

    if (!alloc_page(out, 0) || !alloc_page(out, 1) ||
        !alloc_page(out, 2))
        goto no_memory;
    uint32_t *pd = (uint32_t *)out->pages[0];
    memcpy(pd, (const void *)user_kernel_cr3, 16 * sizeof(uint32_t));
    pd[USER_CODE >> 22] = out->pages[1] | 7;
    pd[(USER_STACK - PAGE_BYTES) >> 22] = out->pages[2] | 7;

    static const uint8_t slots[LOAD_PAGE_LIMIT] = {3, 4, 6, 7, 8, 9, 10, 11};
    unsigned owned = 0;
    uint32_t *load_pt = (uint32_t *)out->pages[1];
    for (unsigned i = 0; i < load_count; ++i) {
        const struct elf32_phdr *ph = &plans[i].ph;
        uint32_t file_end = ph->vaddr + ph->filesz;
        for (uint32_t va = plans[i].first_page; va < plans[i].end_page;
             va += PAGE_BYTES) {
            unsigned slot = slots[owned++];
            if (!alloc_page(out, slot)) goto no_memory;
            load_pt[(va - USER_CODE) / PAGE_BYTES] =
                out->pages[slot] | 5u | ((ph->flags & PF_W) ? 2u : 0u);
            uint32_t copy_start = va > ph->vaddr ? va : ph->vaddr;
            uint32_t page_end = va + PAGE_BYTES;
            uint32_t copy_end = page_end < file_end ? page_end : file_end;
            if (copy_start < copy_end)
                memcpy((void *)(out->pages[slot] + copy_start - va),
                       bytes + ph->offset + copy_start - ph->vaddr,
                       copy_end - copy_start);
        }
    }
    if (!alloc_page(out, 5)) goto no_memory;
    ((uint32_t *)out->pages[2])[1023] = out->pages[5] | 7;
    out->entry = header.entry;
    out->stack_top = USER_STACK;
    out->kind = USER_SPACE_ELF;
    return ELF_OK;

no_memory:
    user_space_destroy(out);
    return ELF_ERR_NOMEM;
}

static void fixture(uint8_t image[256], unsigned phnum)
{
    memset(image, 0, 256);
    struct elf32_ehdr *h = (struct elf32_ehdr *)image;
    h->ident[0] = 0x7f; h->ident[1] = 'E'; h->ident[2] = 'L'; h->ident[3] = 'F';
    h->ident[4] = h->ident[5] = h->ident[6] = 1;
    h->type = 2; h->machine = 3; h->version = 1;
    h->phoff = sizeof(*h); h->ehsize = sizeof(*h);
    h->phentsize = sizeof(struct elf32_phdr); h->phnum = phnum;
    struct elf32_phdr *p = (struct elf32_phdr *)(image + h->phoff);
    for (unsigned i = 0; i < phnum; ++i) {
        p[i].type = PT_LOAD;
        p[i].offset = 128 + i;
        p[i].vaddr = USER_CODE + i * PAGE_BYTES + p[i].offset;
        p[i].filesz = p[i].memsz = 1;
        p[i].flags = PF_R | PF_X;
        p[i].align = 1;
        image[p[i].offset] = 0x90;
    }
    h->entry = p[0].vaddr;
}

static void rejected(uint8_t image[256], uint32_t size, int expected)
{
    struct user_space space = {0};
    uint32_t before = page_free_count();
    KASSERT(elf_load(image, size, &space) == expected);
    KASSERT(!space.pages[0] && !elf_last_allocations &&
            page_free_count() == before);
    ++elf_negative_passes;
}

void elf_negative_tests(void)
{
    uint8_t image[256];
    struct elf32_ehdr *h = (struct elf32_ehdr *)image;
    struct elf32_phdr *p = (struct elf32_phdr *)(image + sizeof(*h));
#define RESET() do { fixture(image, 1); h = (void *)image; p = (void *)(image + sizeof(*h)); } while (0)
    RESET(); rejected(image, 51, ELF_ERR_SHORT);
    RESET(); h->ident[0] = 0; rejected(image, 129, ELF_ERR_IDENT);
    RESET(); h->ident[4] = 2; rejected(image, 129, ELF_ERR_IDENT);
    RESET(); h->ident[5] = 2; rejected(image, 129, ELF_ERR_IDENT);
    RESET(); h->ident[6] = 0; rejected(image, 129, ELF_ERR_IDENT);
    RESET(); h->ident[7] = 3; rejected(image, 129, ELF_ERR_IDENT);
    RESET(); h->ident[8] = 1; rejected(image, 129, ELF_ERR_IDENT);
    RESET(); h->type = 3; rejected(image, 129, ELF_ERR_HEADER);
    RESET(); h->machine = 62; rejected(image, 129, ELF_ERR_HEADER);
    RESET(); h->version = 0; rejected(image, 129, ELF_ERR_HEADER);
    RESET(); h->flags = 1; rejected(image, 129, ELF_ERR_HEADER);
    RESET(); h->ehsize = 51; rejected(image, 129, ELF_ERR_HEADER);
    RESET(); h->phentsize = 31; rejected(image, 129, ELF_ERR_HEADER);
    RESET(); h->phnum = 0; rejected(image, 129, ELF_ERR_HEADER);
    RESET(); h->phnum = 9; rejected(image, 129, ELF_ERR_HEADER);
    RESET(); h->phoff = 120; rejected(image, 129, ELF_ERR_PHDR_TABLE);
    RESET(); rejected(image, sizeof(*h) + sizeof(*p) - 1,
                      ELF_ERR_PHDR_TABLE);
    RESET(); h->phoff = UINT32_MAX; rejected(image, 129, ELF_ERR_PHDR_TABLE);
    RESET(); p->type = 2; rejected(image, 129, ELF_ERR_PHDR_TYPE);
    RESET(); p->flags = 8; rejected(image, 129, ELF_ERR_FLAGS);
    RESET(); p->flags = 0; rejected(image, 129, ELF_ERR_FLAGS);
    RESET(); p->filesz = 2; p->memsz = 1; rejected(image, 130, ELF_ERR_SEGMENT_SIZE);
    RESET(); p->offset = 255; p->filesz = 2; p->memsz = 2; rejected(image, 256, ELF_ERR_FILE_RANGE);
    RESET(); p->align = 3; rejected(image, 129, ELF_ERR_ALIGN);
    RESET(); p->offset = 129; rejected(image, 130, ELF_ERR_ALIGN);
    RESET(); p->vaddr = USER_CODE - PAGE_BYTES + p->offset;
    rejected(image, 129, ELF_ERR_VADDR);
    RESET(); p->vaddr = USER_LOAD_END + p->offset;
    rejected(image, 129, ELF_ERR_VADDR);
    RESET(); p->vaddr = 0xfffff080u; p->memsz = PAGE_BYTES;
    rejected(image, 129, ELF_ERR_VADDR);
    fixture(image, 2); h = (void *)image; p = (void *)(image + sizeof(*h));
    p[0].vaddr = USER_CODE + PAGE_BYTES + p[0].offset;
    p[1].vaddr = USER_CODE + p[1].offset;
    h->entry = p[0].vaddr;
    rejected(image, 130, ELF_ERR_ORDER);
    fixture(image, 2); h = (void *)image; p = (void *)(image + sizeof(*h));
    p[1].vaddr = USER_CODE + p[1].offset;
    rejected(image, 130, ELF_ERR_OVERLAP);
    RESET(); p->memsz = 9 * PAGE_BYTES; rejected(image, 129, ELF_ERR_PAGE_LIMIT);
    RESET(); h->entry = p->vaddr + 1; rejected(image, 129, ELF_ERR_ENTRY);
    RESET(); p->flags = PF_R | PF_W; rejected(image, 129, ELF_ERR_ENTRY);
    RESET(); p->memsz = 0; rejected(image, 129, ELF_ERR_SEGMENT_SIZE);
#undef RESET
}
