# 第 21 篇：只读 FAT16 实测

日期：2026-09-19。本记录对应第 21 篇累计源码，只记录实际构建、QEMU 启动和 GDB 观察所得结果。

## 环境与源码

- i686-elf GCC 13.3.0，Binutils 2.42，NASM 2.16.01，GDB multiarch 15.1。
- QEMU 8.2.2（Debian `1:8.2.2+ds-0ubuntu1.18`），`pc-i440fx-7.2`、`qemu32`、TCG、1 CPU、64 MiB、`-snapshot`。
- SeaBIOS 1.16.3-debian-1.16.3-2；`bios-256k.bin` SHA-256 `1a9ea4f17bcfb27bda5728e2c21d9fa074cf7947b9b4910bb28213a735c96735`。
- 普通 `kernel.bin` 69088 字节，SHA-256 `25ed99534413e374e072b97041a993838f477499589a410388529c9e92469fe2`。
- `mbr.img` 8388608 字节，SHA-256 `2ae85b34a1dccc8da63e33757de183cdec1ead35bfdbee721ccbb74b2f11e261`。
- `kernel/fat.c` SHA-256 `8533ea610493798194be0db3a0a6c2a3ab697f296a3644b5a2b84a51d6c73d0d`。

## 镜像几何

磁盘为 16384 扇区，FAT16 分区从 LBA 2048 开始，长 14336 扇区。宿主脚本从成品中读回 BPB 和 FAT 项，得到：

```text
bytes/sector=512  sectors/cluster=1  reserved=1  FATs=2
root entries=512  sectors/FAT=56  root sectors=32
first data sector=145  cluster count=14191
VBR=2048  FAT1=2049  FAT2=2105  root=2161  data=2193
```

`README.TXT` 为 1479 字节，SHA-256 `25fc6f4ce8493714e7056d2896c47e6a9f4c4db91a4b860dd474035542804798`，实际链是 `2 -> 9 -> 4 -> EOC`。

## 正常读取

`make check-fat` 启动普通镜像，在 `fat_demo_done` 检查分区、簇数、根目录过滤、文件长度、链长和三类偏移读取，再导出客体的 1479 字节与宿主文件执行 `cmp`。

```text
D20 ATA primary master LBA28 sectors=16384 reads=3
D21 FAT mode=0 result=1479 part=2048+14336 clusters=14191 file=1479 read=1479 hash=f34dc752 steps=3 slices=3 bad=0 lba=2195
FAT OK mode=0
PASS: FAT16 geometry, root filtering, offset reads and non-contiguous 2->9->4 chain verified
PASS: FAT demo reaches original blocking keyboard consumer
```

三个 slice 分别覆盖扇区内非零偏移、跨 512 字节/簇边界、超过 EOF 的截短；另检查 `offset == file_size` 返回 0。流程继续到旧 `keyboard_ready`，没有用中途断点代替累计启动链。

## 11 类损坏卷

| mode | 变异 | 实际结果 |
| ---: | --- | --- |
| 1 | `2 -> 9 -> 2` 循环 | `FAT_ECHAIN`，`steps=2`，`bad=2` |
| 2 | `2 -> 9 -> EOC`，长度仍需三簇 | `FAT_ECHAIN`，`steps=2`，`bad=ffff` |
| 3 | sectors-per-cluster 为 0 | `FAT_ENOTSUP`，停在 VBR LBA 2048 |
| 4 | FAT2 的 cluster 9 与 FAT1 不同 | `FAT_EMIRROR`，`bad=9` |
| 5 | `RootEntCnt=1`，匹配项位于第 5 项 | `FAT_ENOENT`，不扫描填充区 |
| 6 | `DIR_FstClusHI=1` | `FAT_ECORRUPT` |
| 7 | 零长文件的首簇为 3 | `FAT_ECHAIN` |
| 8 | next 为 `0xfff7` | `FAT_ECHAIN`，`bad=fff7` |
| 9 | next 为 `0xfff0` | `FAT_ECHAIN`，`bad=fff0` |
| 10 | next 为 `0x4000` | `FAT_ECHAIN`，`bad=4000` |
| 11 | file size 为 `0xffffffff` | 在数据读取前 `FAT_ECHAIN`，`steps=0` |

每个故障镜像都先输出 Day 20 `BLOCK OK`，再到 `fat_demo_done`。GDB 对错误码、链步数和坏簇号作独立断言；串口/GDB 日志均保存在 `docs/day21-*-{serial,gdb}.txt`。

## loader 容量边界

加入 FAT 后，使用旧 65536 字节文件上限链接时真实失败：

```text
i686-elf-ld: kernel file exceeds loader bound
```

扩容后，stage2 把精确 131072 字节载荷拆为 8 次、每次 32 扇区的 AH=42 请求；每次请求都不跨物理 64 KiB，文件整体跨两个 64 KiB 窗口。GDB 在 `_start` 逐字节比较 `0x100000` 处的 131072 字节与宿主文件：

```text
PASS: exact 128 KiB file crossed real-mode segments, checksum and protected-mode copy
```

131073 字节声明既被 `mkpayload` 拒绝，也用超限头镜像真实启动到：

```text
D03 STAGE2 OK
D03 HEADER FAIL
```

串口中没有 `D03 PAYLOAD OK`。运行内存边界的精确 262144 字节镜像进入 C 并完成 allocator/user/syscall/ELF 回归，262145 字节被链接断言拒绝。注意该边界指链接运行区和 BSS；该镜像的文件仍只有 69088 字节。

## 累计回归

在同一源码和工具环境中依次执行：

```text
make build
make check-fat
make check-block
make check-process
make check-syscall
make check-elf
make check-memory
make check-runtime-limit
```

八个目标均退出 0，共保存 36 条 `PASS:` 断言。完整输出为 `docs/day21-cumulative.txt`。

## 验证边界

- FAT 只读，未验证写入、分配、崩溃恢复或缓存一致性。
- 仅支持固定根目录和 ASCII 8.3 子集；LFN、子目录、卷标、`0x05` 转义名不作可打开对象。
- 双 FAT 只比较已访问项；冲突即拒绝是项目策略，不是规范规定的修复算法。
- 只在 QEMU 8.2.2/SeaBIOS 1.16.3 的固定 8 MiB 镜像上实验，未验证真实磁盘、其他 BIOS、扩展分区或多分区枚举。
- 128 KiB 证据不表示单次 BIOS 请求跨 64 KiB，也不外推为任意 BIOS 的通用上限。
