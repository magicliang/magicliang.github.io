#include <stddef.h>
#include <stdint.h>
#include "console.h"
#include "fat.h"
#include "file.h"
#include "keyboard.h"
#include "runtime.h"
#include "task.h"

enum file_type { FILE_FREE, FILE_FAT, FILE_TERMINAL_IN, FILE_TERMINAL_OUT };

struct open_file {
    enum file_type type;
    uint32_t refs;
    uint32_t offset;
    unsigned readable, writable;
    struct fat_file fat;
};

static struct open_file files[OPEN_FILE_MAX];
volatile uint32_t file_allocations, file_releases, file_peak_live;
volatile uint32_t file_reads, file_writes, file_short_reads;

static struct open_file *file_alloc(enum file_type type, unsigned readable,
                                    unsigned writable)
{
    uint32_t flags = irq_save();
    for (unsigned i = 0; i < OPEN_FILE_MAX; ++i) {
        if (files[i].type != FILE_FREE || files[i].refs) continue;
        files[i] = (struct open_file){.type=type, .refs=1,
                                     .readable=readable, .writable=writable};
        ++file_allocations;
        unsigned live = file_live_count();
        if (live > file_peak_live) file_peak_live = live;
        irq_restore(flags);
        return &files[i];
    }
    irq_restore(flags);
    return 0;
}

static int fat_error(int error)
{
    if (error == FAT_ENOENT) return -FILE_ENOENT;
    if (error == FAT_ENAME) return -FILE_ENAMETOOLONG;
    if (error == FAT_EINVAL) return -FILE_EINVAL;
    return -FILE_EIO;
}

int file_open(const char *path, unsigned flags, struct open_file **result)
{
    if (!result || flags) return -FILE_EINVAL;
    struct fat_file fat;
    preempt_disable();
    __asm__ volatile("sti" ::: "memory");
    int opened = fat_open(path, &fat);
    __asm__ volatile("cli" ::: "memory");
    preempt_enable();
    if (opened != FAT_OK) return fat_error(opened);
    struct open_file *file = file_alloc(FILE_FAT, 1, 0);
    if (!file) return -FILE_ENFILE;
    file->fat = fat;
    *result = file;
    return 0;
}

int file_open_terminal(int input, struct open_file **result)
{
    if (!result) return -FILE_EINVAL;
    struct open_file *file = file_alloc(input ? FILE_TERMINAL_IN :
                                        FILE_TERMINAL_OUT, input, !input);
    if (!file) return -FILE_ENFILE;
    *result = file;
    return 0;
}

int file_get(struct open_file *file)
{
    uint32_t flags = irq_save();
    if (!file || file < files || file >= files + OPEN_FILE_MAX ||
        file->type == FILE_FREE || !file->refs || file->refs == UINT32_MAX) {
        irq_restore(flags);
        return 0;
    }
    ++file->refs;
    irq_restore(flags);
    return 1;
}

void file_put(struct open_file *file)
{
    uint32_t flags = irq_save();
    KASSERT(file && file >= files && file < files + OPEN_FILE_MAX &&
            file->type != FILE_FREE && file->refs);
    if (--file->refs == 0) {
        *file = (struct open_file){0};
        ++file_releases;
    }
    irq_restore(flags);
}

int file_read(struct open_file *file, void *buffer, uint32_t length)
{
    if (!file || (!buffer && length) || length > FILE_IO_MAX)
        return -FILE_EINVAL;
    if (!file->readable) return -FILE_EBADF;
    if (!length) return 0;
    int result;
    if (file->type == FILE_FAT) {
        preempt_disable();
        __asm__ volatile("sti" ::: "memory");
        result = fat_read_at(&file->fat, file->offset, buffer, length);
        __asm__ volatile("cli" ::: "memory");
        if (result > 0) file->offset += (uint32_t)result;
        preempt_enable();
        if (result < 0) return fat_error(result);
        if ((uint32_t)result < length) ++file_short_reads;
    } else if (file->type == FILE_TERMINAL_IN) {
        int byte = keyboard_read_char();
        if (byte < 0) return -FILE_EIO;
        *(uint8_t *)buffer = (uint8_t)byte;
        result = 1;
        ++file_short_reads;
    } else {
        return -FILE_EBADF;
    }
    ++file_reads;
    return result;
}

int file_write(struct open_file *file, const void *buffer, uint32_t length)
{
    if (!file || (!buffer && length) || length > FILE_IO_MAX)
        return -FILE_EINVAL;
    if (file->type == FILE_FAT) return -FILE_EROFS;
    if (!file->writable || file->type != FILE_TERMINAL_OUT)
        return -FILE_EBADF;
    const uint8_t *bytes = buffer;
    for (uint32_t i = 0; i < length; ++i) console_putc((char)bytes[i]);
    ++file_writes;
    return (int)length;
}

unsigned file_live_count(void)
{
    unsigned count = 0;
    for (unsigned i = 0; i < OPEN_FILE_MAX; ++i)
        if (files[i].type != FILE_FREE) ++count;
    return count;
}

unsigned file_total_refs(void)
{
    unsigned count = 0;
    for (unsigned i = 0; i < OPEN_FILE_MAX; ++i) count += files[i].refs;
    return count;
}

uint32_t file_offset(const struct open_file *file)
{ return file ? file->offset : 0; }
