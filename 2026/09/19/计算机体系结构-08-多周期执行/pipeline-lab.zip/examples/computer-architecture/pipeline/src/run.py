import argparse
import json
from pathlib import Path
from core import Config, run
from multicycle import run_multicycle


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('program', type=Path)
    parser.add_argument('--single-port', action='store_true')
    parser.add_argument('--interlocked', action='store_true')
    parser.add_argument('--broken-raw', action='store_true')
    parser.add_argument('--two-bit', action='store_true')
    parser.add_argument('--multicycle', action='store_true')
    parser.add_argument('--memory-cycles', type=int, default=1)
    parser.add_argument('--cycles', type=Path)
    args = parser.parse_args()
    if args.memory_cycles < 1:
        parser.error('--memory-cycles must be positive')
    config = Config(forwarding=not (args.interlocked or args.broken_raw), interlocks=not args.broken_raw, single_port=args.single_port, predictor='two_bit' if args.two_bit else 'static', memory_latency=lambda access: args.memory_cycles)
    result = (run_multicycle if args.multicycle else run)(args.program, config)
    for event in result.events:
        print(json.dumps(event, ensure_ascii=False))
    if args.cycles:
        args.cycles.write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in result.cycles))
    if 'error' in result.events[-1]:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
