from pathlib import Path
from typing import Literal, assert_never
from core import Config, MemoryAccess, Result
from isa import Packet, Program, decode, u32

State = Literal['IF', 'ID', 'EX', 'MEM', 'WB']


def run_multicycle(path: Path, config: Config = Config()) -> Result:
    program, result, registers = Program.load(path), Result(), [0] * 32
    pc, state, packet, remaining = 0, 'IF', None, 0
    for cycle in range(1, config.max_cycles + 1):
        if state == 'IF' and pc == program.text_size:
            result.events.append({'halt': 'pc_at_end', 'steps': len(result.events), 'x0': 0, 'x1': registers[1], 'x3': registers[3], 'mem148': program.word(148), 'mem160': program.word(160)})
            return result
        result.cycles.append({'cycle': cycle, 'step': len(result.events), 'pc': pc, 'state': state})
        complete = False
        match state:
            case 'IF':
                raw = program.word(pc)
                packet = Packet(len(result.events), pc, raw, decode(raw), u32(pc + 4))
                state = 'ID'
            case 'ID':
                assert packet is not None
                packet.a, packet.b = registers[packet.insn.rs1], registers[packet.insn.rs2]
                state = 'EX'
            case 'EX':
                assert packet is not None
                packet.execute()
                if packet.insn.branch:
                    if packet.next_pc % 4 or packet.next_pc > program.text_size:
                        packet.fault = 'branch_target_out_of_text'
                    complete = True
                elif packet.fault:
                    complete = True
                elif packet.insn.memory:
                    remaining = config.memory_latency(MemoryAccess(packet.sequence, pc, packet.address, packet.insn.op == 'sw'))
                    if remaining < 1:
                        raise ValueError('memory latency must be at least one cycle')
                    state = 'MEM'
                else:
                    state = 'WB'
            case 'MEM':
                assert packet is not None
                remaining -= 1
                if remaining:
                    continue
                address, write = packet.address, packet.insn.op == 'sw'
                if address % 4:
                    packet.fault = f'misaligned_{packet.insn.op}'
                elif address > 4092:
                    packet.fault = 'store_out_of_bounds' if write else 'load_out_of_bounds'
                elif write and address < program.text_size:
                    packet.fault = 'store_to_text'
                elif write:
                    program.memory[address:address + 4] = packet.b.to_bytes(4, 'little')
                else:
                    packet.value = program.word(address)
                complete = write or bool(packet.fault)
                state = 'WB'
            case 'WB':
                assert packet is not None
                if packet.insn.rd:
                    registers[packet.insn.rd] = packet.value
                complete = True
            case unreachable:
                assert_never(unreachable)
        if complete:
            assert packet is not None
            result.events.append(packet.event(len(result.events)))
            if packet.fault:
                return result
            pc, state = packet.next_pc, 'IF'
            if len(result.events) == 1000:
                result.events.append({'step': 1000, 'pc': pc, 'inst': '0x00000000', 'error': 'step_limit'})
                return result
    raise RuntimeError('multicycle cycle limit reached')
