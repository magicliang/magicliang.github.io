from dataclasses import dataclass
from pathlib import Path
from typing import Literal, TypedDict, assert_never

Op = Literal['add', 'sub', 'and', 'or', 'addi', 'andi', 'ori', 'lw', 'sw', 'beq', 'bne', 'blt', 'bge', 'fault']


class Event(TypedDict, total=False):
    step: int
    pc: int
    inst: str
    op: str
    rd: int
    value: int
    imm: int
    addr: int
    taken: bool
    target: int
    next_pc: int
    x0: int
    error: str
    halt: str
    steps: int
    x1: int
    x3: int
    mem148: int
    mem160: int


def u32(value: int) -> int:
    return value & 0xffffffff


def signed(value: int, bits: int = 32) -> int:
    return (value & ((1 << bits) - 1)) - ((value >> (bits - 1) & 1) << bits)


@dataclass(frozen=True, slots=True)
class Decoded:
    op: Op
    rd: int = 0
    rs1: int = 0
    rs2: int = 0
    imm: int = 0
    error: str = ''

    @property
    def sources(self) -> tuple[int, ...]:
        if self.op in ('add', 'sub', 'and', 'or', 'sw', 'beq', 'bne', 'blt', 'bge'):
            return self.rs1, self.rs2
        if self.op in ('addi', 'andi', 'ori', 'lw'):
            return (self.rs1,)
        return ()

    @property
    def branch(self) -> bool:
        return self.op in ('beq', 'bne', 'blt', 'bge')

    @property
    def memory(self) -> bool:
        return self.op in ('lw', 'sw')


def decode(raw: int) -> Decoded:
    opcode, f3, f7 = raw & 127, raw >> 12 & 7, raw >> 25
    rd, r1, r2 = raw >> 7 & 31, raw >> 15 & 31, raw >> 20 & 31
    imm = signed(raw >> 20, 12)
    ops: dict[tuple[int, int], Op] = {(0, 0): 'add', (0, 32): 'sub', (7, 0): 'and', (6, 0): 'or'}
    iops: dict[int, Op] = {0: 'addi', 7: 'andi', 6: 'ori'}
    bops: dict[int, Op] = {0: 'beq', 1: 'bne', 4: 'blt', 5: 'bge'}
    if opcode == 0x33:
        return Decoded(ops.get((f3, f7), 'fault'), rd, r1, r2, error='unsupported_r_type')
    if opcode == 0x13:
        return Decoded(iops.get(f3, 'fault'), rd, r1, imm=imm, error='unsupported_i_type')
    if opcode == 3:
        return Decoded('lw' if f3 == 2 else 'fault', rd, r1, imm=imm, error='unsupported_load')
    if opcode == 0x23:
        imm = signed((raw >> 25 << 5) | (raw >> 7 & 31), 12)
        return Decoded('sw' if f3 == 2 else 'fault', rs1=r1, rs2=r2, imm=imm, error='unsupported_store')
    if opcode == 0x63:
        imm = signed((raw >> 31 << 12) | ((raw >> 7 & 1) << 11) | ((raw >> 25 & 63) << 5) | ((raw >> 8 & 15) << 1), 13)
        return Decoded(bops.get(f3, 'fault'), rs1=r1, rs2=r2, imm=imm, error='unsupported_branch')
    return Decoded('fault', error='unsupported_opcode')


@dataclass(slots=True)
class Program:
    text_size: int
    memory: bytearray

    @classmethod
    def load(cls, path: Path) -> 'Program':
        memory, words, data = bytearray(4096), 0, False
        for line in path.read_text().splitlines():
            line = line.split('#')[0].split(';')[0].strip()
            if not line:
                continue
            if line in ('.text', '.data'):
                data = line == '.data'
                continue
            values = [int(part, 0) for part in line.split()]
            if len(values) != (2 if data else 1):
                raise ValueError(f'invalid field count: {line}')
            if data:
                address, value = values
                if address < words * 4:
                    raise ValueError(f'data overlaps text: {line}')
            else:
                address, value = words * 4, values[0]
                words += 1
            if not 0 <= address <= 4092 or address % 4 or not 0 <= value <= 0xffffffff or words > 256:
                raise ValueError(f'invalid program line: {line}')
            memory[address:address + 4] = value.to_bytes(4, 'little')
        return cls(words * 4, memory)

    def word(self, address: int) -> int:
        return int.from_bytes(self.memory[address:address + 4], 'little')


@dataclass(slots=True)
class Packet:
    sequence: int
    pc: int
    raw: int
    insn: Decoded
    prediction: int
    a: int = 0
    b: int = 0
    value: int = 0
    address: int = 0
    next_pc: int = 0
    taken: bool = False
    fault: str = ''
    remaining: int | None = None

    def execute(self) -> None:
        d = self.insn
        self.next_pc = u32(self.pc + 4)
        match d.op:
            case 'add': self.value = u32(self.a + self.b)
            case 'sub': self.value = u32(self.a - self.b)
            case 'and': self.value = self.a & self.b
            case 'or': self.value = self.a | self.b
            case 'addi': self.value = u32(self.a + d.imm)
            case 'andi': self.value = self.a & u32(d.imm)
            case 'ori': self.value = self.a | u32(d.imm)
            case 'lw' | 'sw': self.address = u32(self.a + d.imm)
            case 'beq': self.taken = self.a == self.b
            case 'bne': self.taken = self.a != self.b
            case 'blt': self.taken = signed(self.a) < signed(self.b)
            case 'bge': self.taken = signed(self.a) >= signed(self.b)
            case 'fault': self.fault = d.error
            case unreachable: assert_never(unreachable)
        if self.taken:
            self.next_pc = u32(self.pc + d.imm)

    def event(self, step: int) -> Event:
        event: Event = {'step': step, 'pc': self.pc, 'inst': f'0x{self.raw:08x}'}
        if self.fault:
            event['error'] = self.fault
            return event
        d = self.insn
        event.update(op=d.op, next_pc=self.next_pc, x0=0)
        if d.branch:
            event.update(taken=self.taken, target=self.next_pc)
        elif d.op == 'sw':
            event.update(addr=self.address, value=self.b)
        else:
            event.update(rd=d.rd, value=self.value if d.rd else 0)
            if d.op == 'lw':
                event['addr'] = self.address
            elif d.op in ('addi', 'andi', 'ori'):
                event['imm'] = d.imm
        return event
