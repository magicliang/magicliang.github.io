from dataclasses import dataclass, field
from typing import Literal


@dataclass(slots=True)
class Predictor:
    mode: Literal['static', 'two_bit'] = 'static'
    counters: dict[int, int] = field(default_factory=dict)
    observations: list[dict[str, int | bool]] = field(default_factory=list)

    def predict(self, pc: int) -> bool:
        return self.mode == 'two_bit' and self.counters.get(pc, 1) >= 2

    def update(self, pc: int, taken: bool) -> None:
        before = self.counters.get(pc, 1)
        after = min(3, before + 1) if taken else max(0, before - 1)
        self.observations.append({'pc': pc, 'before': before, 'predicted': self.predict(pc), 'taken': taken, 'after': after})
        self.counters[pc] = after
