import hashlib
import json
from pathlib import Path
import platform
import subprocess
from core import Config, MemoryAccess, Result, run
from isa import Program
from fixtures import materialize, randomized
from predictor import Predictor
from multicycle import run_multicycle

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent / 'base'
OUT = ROOT / 'outputs'


def jsonl(path: Path, records: list) -> None:
    path.write_text(''.join(json.dumps(row, ensure_ascii=False, sort_keys=True) + '\n' for row in records))


def save(name: str, result: Result) -> None:
    jsonl(OUT / f'{name}.commit.jsonl', result.events)
    jsonl(OUT / f'{name}.cycles.jsonl', result.cycles)
    (OUT / f'{name}.stages.md').write_text('| cycle | IF | ID | EX | MEM | WB | action |\n|---:|---|---|---|---|---|---|\n' + ''.join('| ' + ' | '.join(str(row[key]) for key in ('cycle', 'IF', 'ID', 'EX', 'MEM', 'WB', 'action')) + ' |\n' for row in result.cycles))


def delayed(access: MemoryAccess) -> int:
    return 4 if access.address == 128 else 2


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    build = ROOT / 'build'
    build.mkdir(exist_ok=True)
    binary = build / 'rv32i_ref'
    subprocess.run(['cc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', str(BASE / 'src/rv32i_ref.c'), '-o', str(binary)], check=True)
    own = materialize(ROOT / 'programs')
    programs = sorted((BASE / 'programs').glob('*.hex')) + own + randomized(ROOT / 'programs')
    configs = {'forward': Config(), 'interlocked': Config(forwarding=False), 'single_port': Config(single_port=True), 'two_bit': Config(predictor='two_bit'), 'delayed': Config(memory_latency=delayed), 'combined': Config(memory_latency=delayed, single_port=True, predictor='two_bit'), 'delayed_interlocked': Config(memory_latency=delayed, forwarding=False)}
    summary = []
    parser_rejections = []
    multicycle_cases = []
    for path in programs:
        reference = subprocess.run([str(binary), str(path)], capture_output=True, text=True, check=False)
        expected = [json.loads(line) for line in reference.stdout.splitlines()]
        if reference.returncode == 2:
            try:
                Program.load(path)
            except ValueError:
                parser_rejections.append(path.name)
                continue
            raise AssertionError(f'parser accepted invalid input: {path}')
        assert expected, (path, reference.stderr)
        if not path.stem.startswith('random_'):
            jsonl(OUT / f'{path.stem}.reference.jsonl', expected)
        sequential = run_multicycle(path)
        assert sequential.events == expected, (path.name, 'multicycle')
        if not path.stem.startswith('random_'):
            jsonl(OUT / f'{path.stem}.multicycle.states.jsonl', sequential.cycles)
        multicycle_cases.append({'case': path.stem, 'cycles': len(sequential.cycles), 'reference_equal': True})
        for label, config in configs.items():
            result = run(path, config)
            assert result.events == expected, (path.name, label, result.events, expected)
            name = f'{path.stem}.{label}'
            if (label == 'forward' and path.stem in ('sum', 'fill_drain', 'raw_chain', 'load_use', 'store_sources', 'load_store_data', 'newest_writer', 'flush_store', 'flush_fault', 'x0_load', 'ports')) or (path.stem == 'sum' and label in ('interlocked', 'single_port', 'two_bit', 'delayed', 'combined')):
                save(name, result)
            summary.append({'case': path.stem, 'configuration': label, 'commits': len(result.events) - 1, 'cycles': len(result.cycles), 'counts': result.counts, 'reference_equal': True, 'input_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    broken = run(ROOT / 'programs/raw_chain.hex', Config(forwarding=False, interlocks=False))
    repaired = run(ROOT / 'programs/raw_chain.hex')
    assert broken.events != repaired.events
    assert broken.events[1]['value'] == 0 and repaired.events[1]['value'] == 14
    save('raw_chain.broken', broken)
    fill = run(ROOT / 'programs/fill_drain.hex')
    assert len(fill.cycles) == 6 + 4
    assert fill.cycles[0]['WB'] == '-' and fill.cycles[4]['WB'] == '0@0:addi'
    assert run(ROOT / 'programs/load_use.hex').counts['load_use'] == 1
    assert run(ROOT / 'programs/x0_load.hex').counts['load_use'] == 0
    assert run(ROOT / 'programs/flush_store.hex').events[-1]['mem160'] == 123
    assert run(ROOT / 'programs/flush_fault.hex').events[-1]['x3'] == 7
    normal = run(ROOT / 'programs/ports.hex')
    unified = run(ROOT / 'programs/ports.hex', Config(single_port=True))
    assert len(unified.cycles) > len(normal.cycles)
    predictions = []
    for mode in ('static', 'two_bit'):
        predictor = Predictor(mode)
        for taken in (True, True, True, False, True, True, True, False):
            predictor.update(28, taken)
        misses = sum(row['taken'] != row['predicted'] for row in predictor.observations)
        predictions.append({'mode': mode, 'misses': misses, 'transitions': predictor.observations})
    assert [row['misses'] for row in predictions] == [6, 3]
    report = {'evidence': 'teaching_timing_model', 'python': platform.python_version(), 'host': platform.platform(), 'compiler': subprocess.run(['cc', '--version'], capture_output=True, text=True, check=True).stdout.splitlines()[0], 'reference_source_sha256': hashlib.sha256((BASE / 'src/rv32i_ref.c').read_bytes()).hexdigest(), 'differential_cases': summary, 'parser_rejections': parser_rejections, 'multicycle_cases': multicycle_cases, 'negative_raw': {'broken_x2': broken.events[1]['value'], 'repaired_x2': repaired.events[1]['value']}, 'fill_drain': {'instructions': 6, 'cycles': 10, 'first_commit_cycle': 5, 'fill_overhead_cycles': 4, 'drain_cycles_after_last_fetch': 4}, 'prediction_sequence': predictions}
    for mode in ([], ['--multicycle']):
        cli = subprocess.run(['python3', str(ROOT / 'src/run.py'), str(BASE / 'programs/sum.hex'), *mode], capture_output=True, text=True, check=True)
        assert [json.loads(line) for line in cli.stdout.splitlines()] == run(BASE / 'programs/sum.hex').events
    report['cli_cases'] = ['pipeline_sum', 'multicycle_sum']
    (OUT / 'verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'differential_runs': len(summary), 'reference_equal': True, 'negative_raw_detected': True, 'fill_drain_cycles': 10, 'prediction_misses': [6, 3]}, indent=2))


if __name__ == '__main__':
    main()
