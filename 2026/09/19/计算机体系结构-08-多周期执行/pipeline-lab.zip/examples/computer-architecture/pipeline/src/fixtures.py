from pathlib import Path
from random import Random


def imm(rd: int, rs: int, value: int) -> int:
    return ((value & 4095) << 20) | rs << 15 | rd << 7 | 0x13


def reg(rd: int, sources: tuple[int, int], selector: tuple[int, int] = (0, 0)) -> int:
    r1, r2 = sources
    f3, f7 = selector
    return f7 << 25 | r2 << 20 | r1 << 15 | f3 << 12 | rd << 7 | 0x33


def load(rd: int, rs: int, offset: int = 0) -> int:
    return (offset & 4095) << 20 | rs << 15 | 2 << 12 | rd << 7 | 3


def store(sources: tuple[int, int], offset: int = 0) -> int:
    r1, r2 = sources
    value = offset & 4095
    return (value >> 5) << 25 | r2 << 20 | r1 << 15 | 2 << 12 | (value & 31) << 7 | 0x23


def branch(sources: tuple[int, int], offset: int, f3: int = 0) -> int:
    r1, r2 = sources
    value = offset & 8191
    return (value >> 12) << 31 | ((value >> 5) & 63) << 25 | r2 << 20 | r1 << 15 | f3 << 12 | ((value >> 1) & 15) << 8 | ((value >> 11) & 1) << 7 | 0x63


def materialize(folder: Path) -> list[Path]:
    cases = {
        'fill_drain': [imm(n, 0, n) for n in range(1, 7)],
        'raw_chain': [imm(1, 0, 7), reg(2, (1, 1)), reg(3, (2, 1)), store((0, 3), 160)],
        'load_use': [imm(1, 0, 128), load(2, 1), reg(3, (2, 2)), store((0, 3), 160)],
        'store_sources': [imm(1, 0, 160), imm(2, 0, 37), store((1, 2)), load(3, 1)],
        'load_store_data': [load(2, 0, 128), store((0, 2), 160), load(3, 0, 160)],
        'newest_writer': [imm(1, 0, 1), imm(1, 0, 9), reg(3, (1, 1))],
        'flush_store': [imm(1, 0, 9), branch((1, 1), 12), store((0, 1), 160), imm(3, 0, 99), imm(3, 0, 7)],
        'flush_fault': [branch((0, 0), 8), 0xffffffff, imm(3, 0, 7)],
        'x0_load': [load(0, 0, 128), reg(3, (0, 0)), imm(0, 0, 9), imm(3, 0, 1)],
        'alu_signed': [imm(1, 0, -3), imm(2, 0, 2), reg(3, (1, 2), (0, 32)), reg(4, (1, 2), (7, 0)), reg(5, (1, 2), (6, 0)), imm(6, 1, -1) | 7 << 12, imm(7, 2, 8) | 6 << 12, branch((1, 2), 8, 4), imm(3, 0, 0), branch((2, 1), 8, 5), imm(3, 0, 0)],
        'ports': [load(1, 0, 128), load(2, 0, 132), imm(3, 0, 5), imm(4, 0, 6), store((0, 3), 160), imm(5, 0, 8), imm(6, 0, 9)],
        'fault_store_suppressed': [load(1, 0, 1), store((0, 0), 160)],
    }
    folder.mkdir(parents=True, exist_ok=True)
    paths = []
    for name, instructions in cases.items():
        path = folder / f'{name}.hex'
        path.write_text('.text\n' + ''.join(f'0x{word:08x}\n' for word in instructions) + '.data\n128 13\n132 17\n160 123\n')
        paths.append(path)
    return paths


def randomized(folder: Path) -> list[Path]:
    paths = []
    for seed in range(20):
        random = Random(seed)
        words = []
        for index in range(24):
            rd, r1, r2 = (random.randrange(8) for _ in range(3))
            choices = [imm(rd, r1, random.randrange(-32, 32)), reg(rd, (r1, r2), random.choice(((0, 0), (0, 32), (6, 0), (7, 0)))), load(rd, 0, random.choice((128, 132, 160))), store((0, r2), 160)]
            if index < 22:
                choices.append(branch((r1, r2), 8, random.choice((0, 1, 4, 5))))
            words.append(random.choice(choices))
        path = folder / f'random_{seed:02d}.hex'
        path.write_text('.text\n' + ''.join(f'0x{word:08x}\n' for word in words) + '.data\n128 13\n132 17\n160 123\n')
        paths.append(path)
    return paths
