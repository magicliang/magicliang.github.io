# 五级流水线与多周期教学执行器

证据等级：**教学时序模型**。Python 执行器直接读取与 `../base/src/rv32i_ref.c` 相同的 `.hex`，独立完成译码、取操作数、执行、读写内存和提交。C 的 JSONL 仅在运行结束后参与差分，不作为 Python 的执行输入。此目录没有 gem5 或真机时序测量。

## 运行

在仓库根目录执行，Python 3.10+ 标准库及 C11 编译器即可，无第三方包：

```bash
python3 examples/computer-architecture/pipeline/src/verify.py
python3 examples/computer-architecture/pipeline/src/run.py examples/computer-architecture/base/programs/sum.hex --cycles /tmp/sum-cycles.jsonl
python3 examples/computer-architecture/pipeline/src/run.py examples/computer-architecture/base/programs/sum.hex --multicycle --cycles /tmp/sum-multicycle.jsonl
python3 examples/computer-architecture/pipeline/src/run.py examples/computer-architecture/pipeline/programs/raw_chain.hex --broken-raw
```

`--broken-raw` 是故意关闭前递和 RAW 互锁的错误模式。`--interlocked` 关闭前递但保留互锁；`--single-port` 让 MEM 数据访问和 IF 争用一个端口；`--two-bit` 启用按分支 PC 索引、初始弱不跳转的标准两位饱和计数器；`--memory-cycles 4` 指定每次数据访问占用四拍 MEM。CLI stdout 只输出提交 JSONL，错误执行退出码为 1。

## 支持与边界

支持 `add/sub/and/or/addi/andi/ori/lw/sw/beq/bne/blt/bge`，32 位模运算、符号比较、小端序、4096 字节内存、四字节对齐取指/访存，`x0=0`。完整 RV32I、系统调用、CSR、中断、页表、非对齐访存、自修改代码均不支持。store 写入指令区报 `store_to_text`，与本系列 C 参考一致。两者是教学子集，不是 RISC-V 合规实现；错误字符串属于系列接口，不是 ISA 的异常编码。

`.text` 每行一个十进制或 `0x` 十六进制指令字，最多 256 条；`.data` 每行 `<字节地址> <32位字>`，不允许覆盖文本。字段数量、32 位范围与地址约束在读入时检查。实验输入采用此规范化格式，不声称复现 C `strtoul` 对所有非规范数字写法的行为。

## 五级时序契约

周期表记录当拍 IF/ID/EX/MEM/WB 正在处理的 `动态序号@字节PC:操作`。当拍 WB 写寄存器发生在 ID 读寄存器之前；EX 优先选择较新的 EX/MEM ALU 结果，再选择 MEM/WB 结果。MEM 的 load 结果当拍不能回送 EX；相邻 load-use 插入一个气泡。store 的地址和数据都在 EX 获取正确来源，因此 load→store 数据相关也采用一个气泡。没有另设 MEM 阶段 store-data 旁路。

分支在 EX 比较，错误预测取消 ID 中较年轻指令及当拍 IF 机会，下一拍从正确 PC 取指。`flushed` 计实际取消的 ID 包数量；IF 没有生成动态包，因此不计入该数字。预测器在 EX 更新，目标由 IF 直接解码分支立即数得到，不模拟 BTB、预测表容量冲突或历史预测。单端口只模拟取指和数据访存端口争用；它不模拟缓存 bank。

MEM 等待时冻结上游与 MEM，已有 WB 可完成；冻结中的 EX 操作数仍接收较老 WB 的前递并保留，避免生产者退出后丢失值。store 在 MEM 实际写内存，在 WB 产生提交记录。错误包延迟到 WB 报错，使错误路径上的无效指令可先被取消；较老错误阻止较年轻 store 到达可生效的 MEM 拍。

六条独立指令实测 10 个模型周期，首条 WB 在第 5 拍，最后 IF 后还有四拍排空。`N+4` 中的四拍是总附加周期；“首条填充四拍”和“末尾排空四拍”是观察流水线的两个位置，不能再相加成 `N+8`。

## 多周期时序契约

`src/multicycle.py` 每次循环只推进一个状态；IF 取指、ID 读取寄存器、EX 运算/判分支、MEM 读写数据、WB 写寄存器。ALU 指令四拍，load 五拍，store 四拍，分支三拍；访存延迟可扩展 MEM。模型保留跨周期 Packet 中的操作数、结果和地址，但不做门级传播延迟仿真。`sum.hex` 的 29 条动态指令得到 116 拍；该周期长度不等同于五级模型周期长度，不能只按周期数宣称真实速度提升。

## 后续缓存接入接口

```python
from core import Config, MemoryAccess, run

def latency(access: MemoryAccess) -> int:
    return 4 if access.address == 128 else 1

result = run(program_path, Config(memory_latency=latency))
```

回调对每条有效地址的数据访问调用一次。`MemoryAccess` 为不可变记录：`sequence, pc, address, write, size=4`；返回值是总 MEM 占用拍数（至少 1），不是额外罚时。回调可更新自己的 cache 状态并返回命中/未命中延迟；实际内存数值仍由处理器维护。此接口是阻塞式单请求模型，不支持 MSHR、多请求并行、带宽排队、抢占或错误路径数据请求。若未来模拟这些机制，需要另行改契约及回归。

## 验证产物

`outputs/verification.json` 记录源文件 SHA-256、输入 SHA-256、主机/Python 版本、287 次五级差分与 41 次多周期差分。包括 20 个固定随机种子的短程序和七种配置；另有三份非法输入被解析器拒绝。代表性案例保留 C reference、Python commit、每拍 JSONL 和 Markdown 阶段表；随机案例保留输入与完整验收汇总，运行命令可重放。`raw_chain.broken.*` 是明确标注的错误反例，不应当作正确基准。

检查覆盖 RAW 前递优先级、无前递互锁、load-use、`x0`、store 两个源、错误路径 store/非法指令取消、单端口争用、延迟背压、符号比较与报错。标准 `TTTNTTTN` 分支串静态不跳转为 6 次错，两位计数器为 3 次错；这不是任意负载的预测率。未安装 basedpyright/ruff，未声明静态类型或风格检查通过；已执行标准库编译检查、CLI 与差分回归。

## 一手依据

- [CS61C 流水线总结](https://notes.cs61c.org/content/pipeline/summary/)：填充、排空与吞吐口径。
- [CS61C 数据冒险](https://notes.cs61c.org/content/pipeline-hazards/data-hazards/)：写后读、EX/MEM 与 MEM/WB 前递、load-use 约束。
- [Berkeley CS152 多周期数据通路](https://people.eecs.berkeley.edu/~kubitron/courses/cs152-S01/lectures/lec09-multicycle.pdf)：控制状态和跨周期寄存器。讲义使用 MIPS；本目录的 RISC-V 教学子集及具体控制拍数是显式模型选择。
- [BOOM 分支预测](https://docs.boom-core.org/en/latest/sections/branch-prediction/backing-predictor.html)：预测方向与后备预测器机制；BOOM 为 SRAM 优化修改部分弱状态转移，本目录的标准饱和状态机不等同于 BOOM 实现。
