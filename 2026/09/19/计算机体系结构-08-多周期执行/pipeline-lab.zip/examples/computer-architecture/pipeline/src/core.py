from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Literal
from isa import Decoded, Event, Packet, Program, decode, u32
from predictor import Predictor


@dataclass(frozen=True, slots=True)
class MemoryAccess:
    sequence: int
    pc: int
    address: int
    write: bool
    size: int = 4


def one_cycle(access: MemoryAccess) -> int:
    return 1


@dataclass(frozen=True, slots=True)
class Config:
    forwarding: bool = True
    interlocks: bool = True
    single_port: bool = False
    predictor: Literal['static', 'two_bit'] = 'static'
    memory_latency: Callable[[MemoryAccess], int] = one_cycle
    max_cycles: int = 10000


@dataclass(slots=True)
class Result:
    events: list[Event] = field(default_factory=list)
    cycles: list[dict[str, int | str]] = field(default_factory=list)
    counts: dict[str, int] = field(default_factory=lambda: {'load_use': 0, 'raw_stall': 0, 'port_stall': 0, 'memory_wait': 0, 'redirect': 0, 'flushed': 0})
    branches: list[dict[str, int | bool]] = field(default_factory=list)


def run(path: Path, config: Config = Config()) -> Result:
    machine = Pipeline(Program.load(path), config)
    return machine.run()


class Pipeline:
    def __init__(self, program: Program, config: Config) -> None:
        self.program, self.config = program, config
        self.registers = [0] * 32
        self.pc, self.sequence = 0, 0
        self.d: Packet | None = None
        self.x: Packet | None = None
        self.m: Packet | None = None
        self.w: Packet | None = None
        self.predictor = Predictor(config.predictor)
        self.result = Result()

    def operand(self, register: int, captured: int) -> int:
        if register == 0:
            return 0
        if self.config.forwarding:
            for producer in (self.m, self.w):
                if producer is not None and producer.insn.rd == register and not producer.fault:
                    if producer is self.m and producer.insn.op == 'lw':
                        continue
                    return producer.value
        return captured

    def memory(self, packet: Packet) -> bool:
        if packet.fault or not packet.insn.memory:
            return True
        op, address = packet.insn.op, packet.address
        if address % 4:
            packet.fault = f'misaligned_{op}'
            return True
        if address > 4092:
            packet.fault = 'load_out_of_bounds' if op == 'lw' else 'store_out_of_bounds'
            return True
        if packet.remaining is None:
            access = MemoryAccess(packet.sequence, packet.pc, address, op == 'sw')
            packet.remaining = self.config.memory_latency(access)
            if packet.remaining < 1:
                raise ValueError('memory latency must be at least one cycle')
        packet.remaining -= 1
        if packet.remaining:
            return False
        if op == 'lw':
            packet.value = self.program.word(address)
        else:
            if address < self.program.text_size:
                packet.fault = 'store_to_text'
                return True
            self.program.memory[address:address + 4] = packet.b.to_bytes(4, 'little')
        return True

    def fetch(self) -> Packet | None:
        if self.pc == self.program.text_size:
            return None
        pc = self.pc
        if pc % 4 or not 0 <= pc < self.program.text_size:
            raw, insn = 0, Decoded('fault', error='pc_out_of_text')
        else:
            raw = self.program.word(pc)
            insn = decode(raw)
        prediction = u32(pc + (insn.imm if insn.branch and self.predictor.predict(pc) else 4))
        packet = Packet(self.sequence, pc, raw, insn, prediction)
        self.sequence += 1
        self.pc = prediction
        return packet

    def hazard(self) -> str:
        if self.d is None or not self.config.interlocks:
            return ''
        sources = set(self.d.insn.sources) - {0}
        if self.config.forwarding:
            if self.x is not None and self.x.insn.op == 'lw' and self.x.insn.rd in sources:
                return 'load_use'
        else:
            for producer in (self.x, self.m):
                if producer is not None and producer.insn.rd in sources:
                    return 'raw_stall'
        return ''

    def run(self) -> Result:
        for cycle in range(1, self.config.max_cycles + 1):
            if self.pc == self.program.text_size and all(p is None for p in (self.d, self.x, self.m, self.w)):
                self.result.events.append({'halt': 'pc_at_end', 'steps': len(self.result.events), 'x0': 0, 'x1': self.registers[1], 'x3': self.registers[3], 'mem148': self.program.word(148), 'mem160': self.program.word(160)})
                break
            row: dict[str, int | str] = {'cycle': cycle, 'IF': '-', 'ID': '-', 'EX': '-', 'MEM': '-', 'WB': '-', 'action': ''}
            for stage, packet in zip(('ID', 'EX', 'MEM', 'WB'), (self.d, self.x, self.m, self.w)):
                if packet is not None:
                    row[stage] = f'{packet.sequence}@{packet.pc}:{packet.insn.op}'
            self.result.cycles.append(row)
            if self.w is not None:
                self.result.events.append(self.w.event(len(self.result.events)))
                if self.w.fault:
                    break
                if self.w.insn.rd:
                    self.registers[self.w.insn.rd] = self.w.value
                if len(self.result.events) == 1000:
                    self.result.events.append({'step': 1000, 'pc': self.w.next_pc, 'inst': '0x00000000', 'error': 'step_limit'})
                    break
            if self.x is not None:
                self.x.a = self.operand(self.x.insn.rs1, self.x.a)
                self.x.b = self.operand(self.x.insn.rs2, self.x.b)
            port_busy = self.m is not None and self.m.insn.memory
            ready = self.m is None or self.memory(self.m)
            if not ready:
                self.w = None
                self.result.counts['memory_wait'] += 1
                row['action'] = 'memory_wait'
                continue
            redirect = False
            if self.x is not None:
                self.x.execute()
                if self.x.insn.branch:
                    if self.x.next_pc % 4 or self.x.next_pc > self.program.text_size:
                        self.x.fault = 'branch_target_out_of_text'
                    self.predictor.update(self.x.pc, self.x.taken)
                    redirect = self.x.next_pc != self.x.prediction
            hazard = self.hazard()
            fetched: Packet | None = None
            next_x: Packet | None = None
            if redirect:
                assert self.x is not None
                self.pc = self.x.next_pc
                self.result.counts['redirect'] += 1
                self.result.counts['flushed'] += int(self.d is not None)
                self.d = None
                row['action'] = 'redirect; cancel ID and IF'
            elif hazard:
                self.result.counts[hazard] += 1
                row['action'] = hazard
            else:
                next_x = self.d
                if next_x is not None:
                    next_x.a = self.registers[next_x.insn.rs1]
                    next_x.b = self.registers[next_x.insn.rs2]
                if self.config.single_port and port_busy and self.pc != self.program.text_size:
                    self.result.counts['port_stall'] += 1
                    row['action'] = 'port_stall'
                else:
                    fetched = self.fetch()
                    if fetched is not None:
                        row['IF'] = f'{fetched.sequence}@{fetched.pc}:{fetched.insn.op}'
                self.d = fetched
            self.w, self.m, self.x = self.m, self.x, next_x
        else:
            raise RuntimeError('pipeline cycle limit reached')
        self.result.branches = self.predictor.observations
        return self.result
