#!/usr/bin/env python3
MASK32 = 0xFFFFFFFF


def u32(value: int) -> int:
    return value & MASK32


def s32(value: int) -> int:
    value &= MASK32
    return value - (1 << 32) if value & (1 << 31) else value


def ripple_add(a: int, b: int) -> tuple[int, list[tuple[int, int, int]]]:
    carry = 0
    rows = []
    out = 0
    for bit in range(32):
        abit = (a >> bit) & 1
        bbit = (b >> bit) & 1
        total = abit ^ bbit ^ carry
        carry_out = (abit & bbit) | (abit & carry) | (bbit & carry)
        out |= total << bit
        rows.append((bit, total, carry_out))
        carry = carry_out
    return u32(out), rows


def main() -> None:
    examples = [
        ("wrap_add", 0xFFFFFFFF, 1),
        ("positive", 17, 25),
        ("negative_view", 0xFFFFFFFE, 3),
    ]
    for name, a, b in examples:
        value, rows = ripple_add(a, b)
        print(
            f"{name}: 0x{a:08x}+0x{b:08x}=0x{value:08x} "
            f"u32={value} s32={s32(value)} final_carry={rows[-1][2]}"
        )


if __name__ == "__main__":
    main()
