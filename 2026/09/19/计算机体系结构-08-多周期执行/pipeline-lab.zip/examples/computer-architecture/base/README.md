# Computer Architecture Base Experiments

This directory is the shared base for the first computer architecture articles.

The stable contract is deliberately small:

- Input programs are text files under `programs/`.
- `.text` contains one 32-bit instruction word per line, written in hexadecimal or decimal.
- `.data` contains `<byte-address> <32-bit-word>` pairs. Words are stored little-endian.
- `src/rv32i_ref.c` reads one program and writes one JSONL commit trace to stdout.
- A successful run ends with `{"halt":"pc_at_end","steps":...,"x0":...,"x1":...,"x3":...,"mem148":...,"mem160":...}` when `pc == text_size`.
- An unsupported instruction, misaligned word access, out-of-bounds access, or bad PC emits one JSON error record and exits non-zero.
- `.data` may not overlap `.text`; stores into the text region fail with `store_to_text`. Self-modifying code is deliberately outside this teaching contract.

Current RV32I teaching subset:

- R-type: `add`, `sub`, `and`, `or`
- I-type: `addi`, `andi`, `ori`
- Word memory: `lw`, `sw`
- Branches: `beq`, `bne`, `blt`, `bge`
- Register `x0` is forced back to zero after every instruction.
- Taken branch targets are checked on the branch instruction itself. Targets must be 4-byte aligned and may point to the byte just after `.text` for normal halt.
- `programs/signed_compare.hex` checks signed `blt` across the sign boundary: `-1 < 1` must take the branch and end with `x3=7`.

Evidence boundary:

- `outputs/*.jsonl` is functional execution evidence for the teaching subset.
- `outputs/environment.txt` records the host compiler and OS used for the C11 executable.
- `outputs/abi_sample_aarch64.s` and `outputs/abi_sample_aarch64_objdump.txt` are local AArch64 compile/disassembly evidence for the ABI article.
- This is not an ISA compliance suite, not a timing model, and not a hardware measurement.

Run:

```bash
bash examples/computer-architecture/base/scripts/run_all.sh
```
