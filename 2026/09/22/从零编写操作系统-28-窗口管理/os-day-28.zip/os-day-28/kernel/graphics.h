#ifndef GRAPHICS_H
#define GRAPHICS_H

struct bootinfo;
_Noreturn void graphics_demo(const struct bootinfo *info);
_Noreturn void graphics_text_demo(const struct bootinfo *info);
_Noreturn void graphics_mouse_demo(const struct bootinfo *info,
                                   unsigned eoi_mode);
_Noreturn void graphics_window_demo(const struct bootinfo *info);

#endif
