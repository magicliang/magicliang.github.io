#!/bin/sh
set -eu
for variant in normal masked; do
    elf=build/kernel.elf disk=build/mbr.img
    if [ "$variant" = masked ]; then elf=build/kernel-preempt-mask.elf; disk=build/mbr-preempt-mask.img; fi
    "$QEMU" $QEMU_COMMON -drive file="$disk",format=raw,if=ide -display none -serial file:build/preempt-$variant-serial.txt -monitor none -S -gdb tcp:127.0.0.1:1234 > build/preempt-$variant-qemu.txt 2>&1 &
    pid=$!
    trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
    cat > build/preempt.gdb <<GDB
set architecture i386
set tcp connect-timeout 5
set tcp auto-retry on
file $elf
target remote 127.0.0.1:1234
python
import gdb, struct, time
m = gdb.selected_inferior()
v = lambda e: int(gdb.parse_and_eval(e))
end
hbreak preempt_demo
continue
delete breakpoints
set var preempt_work_release = 0
GDB
    if [ "$variant" = masked ]; then
        cat >> build/preempt.gdb <<'GDB'
hbreak preempt_mask_sample
continue
delete breakpoints
python
assert v('current') == 1 and v('preempt_counts[1]') == 0
assert v('preempt_mask_actual') == 1
tick, switches = v('timer_ticks'), v('preempt_switches')
gdb.execute('detach')
time.sleep(0.3)
gdb.execute('target remote 127.0.0.1:1234')
a = v('preempt_counts[0]')
assert a > 0 and v('preempt_counts[1]') == 0
gdb.execute('detach')
time.sleep(0.3)
gdb.execute('target remote 127.0.0.1:1234')
b = v('preempt_counts[0]')
assert b > a and v('preempt_counts[1]') == 0
assert v('$eflags') & 0x200
assert v('timer_ticks') == tick and v('preempt_switches') == switches
assert v('tasks[2].state') == 1
print('PASS: IRQ0 masked, two 0.3s free-run samples A=%d -> %d B=0 ticks=%d switches=%d' % (a,b,tick,switches))
end
monitor screendump build/day14-masked.png -f png
set var preempt_mask_requested = 0
GDB
    fi
    cat >> build/preempt.gdb <<'GDB'
hbreak preempt_cli_sample
continue
delete breakpoints
python
assert v('preempt_critical_ticks') >= 3 and v('preempt_deferred') >= 3
assert v('preempt_nested_ok') == v('preempt_enable_ok') == v('preempt_if0_ok') == 1
assert not v('$eflags') & 0x200
assert v('tasks[0].preempt_count') == 0 and v('need_resched') == 1
switches, ticks = v('preempt_switches'), v('timer_ticks')
gdb.execute('set var preempt_cli_release = 0')
gdb.execute('detach')
time.sleep(0.2)
gdb.execute('target remote 127.0.0.1:1234')
assert v('timer_ticks') == ticks and v('preempt_switches') == switches
assert not v('$eflags') & 0x200
print('PASS: IF=1 disabled preemption accumulated %d ticks; nested/outer enable and original IF=0 respected; 0.2s CLI window ticks=%d switches=%d unchanged' % (v('preempt_critical_ticks'), ticks, switches))
gdb.execute('set var preempt_cli_release = 1')
end
hbreak preempt_progress_sample
continue
delete breakpoints
python
gdb.execute('detach')
time.sleep(0.3)
gdb.execute('target remote 127.0.0.1:1234')
a, b, tick1 = v('preempt_counts[0]'), v('preempt_counts[1]'), v('timer_ticks')
gdb.execute('detach')
time.sleep(0.3)
gdb.execute('target remote 127.0.0.1:1234')
a2, b2, tick2 = v('preempt_counts[0]'), v('preempt_counts[1]'), v('timer_ticks')
assert a2 > a > 0 and b2 > b > 0 and tick2 > tick1
print('PASS: two 0.3s free-run busy samples A=%d -> %d B=%d -> %d ticks=%d -> %d, neither worker calls yield' % (a,a2,b,b2,tick1,tick2))
gdb.execute('set var preempt_work_release = 1')
end
hbreak *preempt_probe_wait
continue
delete breakpoints
python
owner, before = v('current'), v('preempt_switches')
assert owner in (1,2)
assert v('$eflags') & 0x600 == 0x600
assert [v('$'+r) for r in ['eax','ecx','edx','ebx','ebp','esi','edi']] == [0x11111111*i + owner for i in range(1,8)]
gdb.execute('set $owner = %d' % owner)
end
hbreak switch_context
continue
delete breakpoints
python
# schedule_locked has selected a different task; the live stack is still owner's.
assert v('current') != owner
page = v('tasks[%d].kernel_stack' % owner)
f = gdb.newest_frame()
while f and f.name() != 'trap_dispatch': f = f.older()
assert f is not None
frame = f.read_var('frame')
assert page < int(frame) and int(frame)+68 < page+4096
assert int(frame['vector']) == 32 and int(frame['eflags']) & 0x600 == 0x600
assert [int(frame[r]) for r in ['eax','ecx','edx','ebx','ebp','esi','edi']] == [0x11111111*i + owner for i in range(1,8)]
assert v('tasks[%d].trap_depth' % owner) == 0
print('PASS: outgoing task %d owns full IRQ0 frame at %s; new current=%d; tail depth=0' % (owner,hex(int(frame)),v('current')))
end
hbreak *preempt_probe_restored if current == $owner
continue
delete breakpoints
python
r = struct.unpack('<9I',bytes(m.read_memory(v('$esp'),36)))
assert [r[i] for i in [7,6,5,4,2,1,0]] == [0x11111111*i + owner for i in range(1,8)]
assert r[8] & 0xed5 == 0x645
assert v('current') == owner and v('preempt_switches') > before
print('PASS: same task %d returned through IRET after switches %d -> %d; seven GPR and arithmetic flags/IF/DF preserved' % (owner,before,v('preempt_switches')))
end
hbreak preempt_demo_done
continue
delete breakpoints
python
assert v('preempt_passed') == 1 and v('preempt_probe_passes') == 8
assert v('preempt_counts[0]') >= 200000 and v('preempt_counts[1]') >= 200000
assert v('preempt_reaped') == 2 and v('free_pages') == v('preempt_initial_pages')
assert v('task_passed') == 1 and v('task_switches') == 387
for i in [1,2]:
    assert v('tasks[%d].kernel_stack' % i) == 0 and v('tasks[%d].state' % i) == 0
    assert 0 < v('preempt_stack_used[%d]' % (i-1)) < 3840
print('PASS: busy counters A=%d B=%d; probes=8 switches=%d stack_used=%d,%d pages=%d reaped=2; D13 switches still 387' % (v('preempt_counts[0]'),v('preempt_counts[1]'),v('preempt_switches'),v('preempt_stack_used[0]'),v('preempt_stack_used[1]'),v('free_pages')))
end
python
name = 'day14-recovered' if v('preempt_diagnostic') else 'day14-screen'
gdb.execute('monitor screendump build/%s.png -f png' % name)
end
hbreak keyboard_ready
continue
printf "PASS: preemption demo reaches keyboard_ready\n"
disconnect
GDB
    timeout -k 5 120 gdb-multiarch -q -nx -batch -x build/preempt.gdb > build/preempt-$variant-gdb.txt 2>&1
    cat build/preempt-$variant-gdb.txt
    kill "$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
    trap - EXIT HUP INT TERM
done
