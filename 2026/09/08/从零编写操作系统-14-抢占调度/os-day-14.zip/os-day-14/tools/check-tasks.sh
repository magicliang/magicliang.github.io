#!/bin/sh
set -eu
for variant in normal starvation; do
    elf=build/kernel.elf disk=build/mbr.img
    if [ "$variant" = starvation ]; then elf=build/kernel-taskstarve.elf; disk=build/mbr-taskstarve.img; fi
    "$QEMU" $QEMU_COMMON -drive file="$disk",format=raw,if=ide -display none -serial file:build/tasks-$variant-serial.txt -monitor none -S -gdb tcp:127.0.0.1:1234 > build/tasks-$variant-qemu.txt 2>&1 &
    pid=$!
    trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
    cat > build/tasks.gdb <<GDB
set architecture i386
set tcp connect-timeout 5
set tcp auto-retry on
file $elf
target remote 127.0.0.1:1234
hbreak *task_start
continue
python
import gdb, struct, time
from pathlib import Path
m = gdb.selected_inferior()
v = lambda e: int(gdb.parse_and_eval(e))
assert (v('\$esp') + 4) % 16 == 0
assert not v('\$eflags') & 0x600
assert v('current') == 1
assert v('free_pages') == v('task_initial_pages') - 2
p1, p2 = v('tasks[1].kernel_stack'), v('tasks[2].kernel_stack')
assert p1 != p2 and p1 % 4096 == p2 % 4096 == 0
assert p1 < v('\$esp') < p1 + 4096
print('PASS: first C entry aligned, DF=0 IF=0; independent pages', hex(p1), hex(p2))
end
delete breakpoints
GDB
    if [ "$variant" = normal ]; then
        cat >> build/tasks.gdb <<'GDB'
hbreak *task_start
continue
python
assert v('current') == 2 and (v('$esp') + 4) % 16 == 0
assert not v('$eflags') & 0x600
assert p2 < v('$esp') < p2 + 4096
end
delete breakpoints
hbreak task_sample
continue
python
assert v('current') == 2
assert v('task_counts[0]') == v('task_counts[1]') == 1
for i, page in enumerate([p1,p2]):
    address = v('task_local_address[%d]' % i)
    assert page < address and address + 32 < page + 4096
    assert struct.unpack('<8I',bytes(m.read_memory(address,32))) == tuple(0x1000*(i+1)+j for j in range(8))
print('PASS: two live local arrays on distinct stacks; A=1 B=1')
end
delete breakpoints
hbreak task_demo_done
continue
python
assert v('task_passed') == 1
assert v('task_counts[0]') == v('task_counts[1]') == 128
assert v('task_reaped') == 2 and v('task_switches') == 387
assert v('free_pages') == v('task_initial_pages')
for i in [1,2]:
    assert v('tasks[%d].state' % i) == 0 and v('tasks[%d].kernel_stack' % i) == 0
    assert 0 < v('task_stack_used[%d]' % (i-1)) < 3840
assert v('current') == 0
print('PASS: 128 rounds/task, callee-register probes, IF=0/1 restoration; switches=387 reaped=2 free_pages=%d stack_used=%d,%d' % (v('free_pages'),v('task_stack_used[0]'),v('task_stack_used[1]')))
end
monitor screendump build/day13-screen.png -f png
delete breakpoints
hbreak keyboard_ready
continue
printf "PASS: task demo reaches keyboard_ready\n"
GDB
    else
        cat >> build/tasks.gdb <<'GDB'
hbreak task_starving
continue
delete breakpoints
python
assert v('current') == 1 and v('task_counts[1]') == 0
# QEMU runs freely between samples: detach, wait, reattach; no step/breakpoint loop.
gdb.execute('detach')
time.sleep(1)
gdb.execute('target remote 127.0.0.1:1234')
a1 = v('task_counts[0]')
assert a1 > 0 and v('task_counts[1]') == 0 and v('current') == 1
gdb.execute('detach')
time.sleep(1)
gdb.execute('target remote 127.0.0.1:1234')
a2 = v('task_counts[0]')
assert a2 > a1 and v('task_counts[1]') == 0 and v('current') == 1
assert v('tasks[2].state') == 1 and v('task_switches') == 1 and v('task_reaped') == 0
print('PASS: two 1-second free-run windows: A=%d -> %d; B=0 RUNNABLE; no preemption' % (a1,a2))
end
monitor screendump build/day13-starvation.png -f png
GDB
    fi
    printf 'disconnect\n' >> build/tasks.gdb
    timeout -k 5 120 gdb-multiarch -q -nx -batch -x build/tasks.gdb > build/tasks-$variant-gdb.txt 2>&1
    cat build/tasks-$variant-gdb.txt
    kill "$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
    trap - EXIT HUP INT TERM
done
