#ifndef TIMER_H
#define TIMER_H
#include <stdint.h>
extern volatile uint32_t timer_ticks;
void timer_start(void);
void timer_mask(unsigned masked);
void timer_irq(void);
void timer_demo(unsigned mode);
#endif
