#include <stddef.h>
#include "exceptions.h"
#include "console.h"
#include "timer.h"
#include "keyboard.h"
#include "paging.h"
#include "task.h"

struct idt_gate { uint16_t low, selector; uint8_t zero, flags; uint16_t high; } __attribute__((packed));
struct idt_pointer { uint16_t limit; uint32_t base; } __attribute__((packed));
static struct idt_gate idt[256];
static struct idt_pointer idtr;
extern void (*exception_stubs[34])(void);
extern char probe_resume;
volatile unsigned breakpoint_count;
_Static_assert(sizeof(struct trap_frame) == 68, "same-CPL frame size");
_Static_assert(offsetof(struct trap_frame, vector) == 48, "assembly vector offset");
_Static_assert(offsetof(struct trap_frame, eflags) == 64, "assembly flags offset");

void exceptions_init(void)
{
    for (unsigned i = 0; i < 34; ++i) {
        uint32_t address = (uint32_t)exception_stubs[i];
        idt[i] = (struct idt_gate){address, 0x08, 0, 0x8e, address >> 16};
    }
    /* IRQ0 and IRQ1 share the existing interrupt frame. */
    idtr = (struct idt_pointer){sizeof(idt) - 1, (uint32_t)idt};
    __asm__ volatile("lidt %0" : : "m"(idtr) : "memory");
}

static void trap_handle(struct trap_frame *frame)
{
    uint32_t fault_address;
    __asm__ volatile("mov %%cr2,%0" : "=r"(fault_address));
    if (frame->vector == 14) { paging_fault(frame, fault_address); return; }
    if (frame->vector == 33) { keyboard_irq(); return; }
    if (frame->vector == 32) { timer_irq(); return; }
    uint32_t flags;
    __asm__ volatile("pushfl; popl %0" : "=r"(flags));
    KASSERT((flags & 0x600) == 0); /* C requires DF=0; interrupt gate keeps IF=0. */
    kprintf("EXCEPTION vector=%u error=%x eip=%p cs=%x flags=%x\n",
            frame->vector, frame->error, (void *)frame->eip, frame->cs, frame->eflags);
    kprintf("EAX=%x EBX=%x ECX=%x EDX=%x\n", frame->eax, frame->ebx, frame->ecx, frame->edx);
    kprintf("ESI=%x EDI=%x EBP=%x PUSHAD_ESP=%x\n", frame->esi, frame->edi, frame->ebp, frame->pushad_esp);
    kprintf("DS=%x ES=%x FS=%x GS=%x\n", frame->ds, frame->es, frame->fs, frame->gs);
    if (frame->vector == 3 && frame->eip == (uint32_t)&probe_resume) {
        KASSERT(frame->error == 0 && frame->cs == 8);
        KASSERT((frame->eflags & 0x600) == 0x400);
        KASSERT(frame->eax == 0x11111111 && frame->ecx == 0x22222222);
        KASSERT(frame->edx == 0x33333333 && frame->ebx == 0x44444444);
        KASSERT(frame->ebp == 0x55555555 && frame->esi == 0x66666666);
        KASSERT(frame->edi == 0x77777777);
        KASSERT(frame->ds == 0x10 && frame->es == 0x10);
        KASSERT(frame->fs == 0x10 && frame->gs == 0x10);
        ++breakpoint_count;
        return;
    }
    panic(__FILE__, __LINE__, "unhandled CPU exception");
}

void trap_dispatch(struct trap_frame *frame)
{
    task_trap_enter();
    trap_handle(frame); /* Device EOI completes before a scheduling decision. */
    task_trap_leave(frame->eflags & 0x200);
}
