#include "task.h"
#include "memory.h"
#include "runtime.h"
#include "console.h"
#include "timer.h"
#define SLOTS 3u
#define CANARY 0x51accafeu
enum task_state { DEAD, RUNNABLE, RUNNING };
struct task {
    uint32_t *saved_sp;
    uint32_t kernel_stack;
    enum task_state state;
    void (*entry)(void *);
    void *arg;
    unsigned trap_depth, preempt_count;
};
static struct task tasks[SLOTS];
static unsigned current;
volatile uint32_t task_counts[2], task_local_address[2], task_stack_used[2];
volatile uint32_t task_switches, task_reaped, task_passed, task_initial_pages;
static unsigned starvation;
static unsigned preempt_active;
volatile unsigned need_resched;
volatile uint32_t preempt_switches, preempt_deferred;
extern void switch_context(uint32_t **old_sp, uint32_t *new_sp);
extern void task_trampoline(void);
extern int task_register_probe(unsigned seed);
static uint32_t irq_save(void)
{
    uint32_t flags;
    __asm__ volatile("pushfl; popl %0; cli" : "=r"(flags) : : "memory");
    return flags;
}
static void irq_restore(uint32_t flags)
{ __asm__ volatile("pushl %0; popfl" : : "r"(flags) : "memory", "cc"); }
/* A suspended scheduler returns with IF=0; its caller restores its own flags. */
static void schedule_locked(void)
{
    uint32_t flags;
    __asm__ volatile("pushfl; popl %0" : "=r"(flags));
    KASSERT(!(flags & 0x200));
    KASSERT(!tasks[current].trap_depth && !tasks[current].preempt_count);
    unsigned old = current;
    need_resched = 0; /* Consume before switching; a new task may request again. */
    for (unsigned n = 1; n <= SLOTS; ++n) {
        unsigned next = (old + n) % SLOTS;
        if (tasks[next].state != RUNNABLE) continue;
        current = next;
        tasks[next].state = RUNNING;
        if (next != old) {
            if (preempt_active) ++preempt_switches;
            else ++task_switches;
            switch_context(&tasks[old].saved_sp, tasks[next].saved_sp);
        }
        return;
    }
    panic(__FILE__, __LINE__, "no runnable bootstrap");
}
int task_create(void (*entry)(void *), void *arg)
{
    uint32_t flags = irq_save();
    if (!entry) { irq_restore(flags); return 0; }
    for (unsigned i = 1; i < SLOTS; ++i) {
        struct task *t = &tasks[i];
        if (t->state != DEAD || t->kernel_stack) continue;
        uint32_t page = page_alloc();
        if (!page) { irq_restore(flags); return 0; }
        memset((void *)page, 0xa5, PAGE_BYTES);
        *(uint32_t *)page = CANARY;
        uint32_t *sp = (uint32_t *)(page + PAGE_BYTES);
        *--sp = (uint32_t)task_trampoline;
        *--sp = 0; /* EBP */
        *--sp = 0; /* EBX */
        *--sp = 0; /* ESI */
        *--sp = 0; /* EDI */
        *t = (struct task){sp, page, RUNNABLE, entry, arg, 0, 0};
        irq_restore(flags);
        return 1;
    }
    irq_restore(flags);
    return 0;
}
void task_yield(void)
{
    uint32_t flags = irq_save();
    tasks[current].state = RUNNABLE;
    schedule_locked();
    irq_restore(flags);
}
_Noreturn void task_exit(void)
{
    (void)irq_save();
    KASSERT(current != 0);
    tasks[current].state = DEAD;
    schedule_locked();
    panic(__FILE__, __LINE__, "dead task resumed");
}
void task_start(void)
{
    /* D13 retains IF=0; only the separately initialized D14 PIT permits STI. */
    if (preempt_active) __asm__ volatile("sti" ::: "memory");
    tasks[current].entry(tasks[current].arg);
}
void task_sample(void) { __asm__ volatile("" ::: "memory"); }
void task_starving(void) { __asm__ volatile("" ::: "memory"); }
void task_demo_done(void) { __asm__ volatile("" ::: "memory"); }
static void counter(void *arg)
{
    unsigned id = (uintptr_t)arg;
    volatile uint32_t local[8];
    for (unsigned j = 0; j < 8; ++j) local[j] = 0x1000u * (id + 1) + j;
    task_local_address[id] = (uintptr_t)local;
    if (starvation && id == 0) {
        kprintf("D13 NO-YIELD A running; B=0 (cooperative only)\n");
        task_starving();
        for (;;) ++task_counts[0];
    }
    if (id == 1) __asm__ volatile("sti" ::: "memory"); /* PIC remains fully masked. */
    for (unsigned i = 0; i < 128; ++i) {
        KASSERT(task_counts[id] == i);
        KASSERT(task_counts[1 - id] == i + id);
        ++task_counts[id];
        task_sample();
        KASSERT(task_register_probe(id + 1));
        uint32_t observed = irq_save();
        KASSERT(!!(observed & 0x200) == id);
        irq_restore(observed);
        for (unsigned j = 0; j < 8; ++j)
            KASSERT(local[j] == 0x1000u * (id + 1) + j);
    }
}
void task_demo(unsigned starve)
{
    uint32_t flags = irq_save();
    starvation = starve;
    task_initial_pages = page_free_count();
    tasks[0].state = RUNNING;
    KASSERT(task_create(counter, (void *)0));
    KASSERT(task_create(counter, (void *)1));
    KASSERT(!task_create(counter, 0));
    KASSERT(page_free_count() == task_initial_pages - 2);
    while (tasks[1].state != DEAD || tasks[2].state != DEAD) task_yield();
    for (unsigned i = 1; i < SLOTS; ++i) {
        uint32_t page = tasks[i].kernel_stack;
        KASSERT(*(uint32_t *)page == CANARY);
        unsigned untouched = 4;
        while (untouched < PAGE_BYTES && *(uint8_t *)(page + untouched) == 0xa5) ++untouched;
        task_stack_used[i - 1] = PAGE_BYTES - untouched;
        KASSERT(task_stack_used[i - 1] < PAGE_BYTES - 256);
        KASSERT(page_free(page));
        tasks[i].kernel_stack = 0;
        ++task_reaped;
    }
    KASSERT(task_counts[0] == 128 && task_counts[1] == 128);
    KASSERT(page_free_count() == task_initial_pages);
    /* Exercise an IF=1 continuation with PIC masks still 0xff, no live IRQs. */
    __asm__ volatile("sti" ::: "memory");
    task_yield();
    uint32_t restored = irq_save();
    KASSERT(restored & 0x200);
    task_yield();
    restored = irq_save();
    KASSERT(!(restored & 0x200));
    task_passed = 1;
    kprintf("D13 TASKS A=%u B=%u switches=%u reaped=%u\n", task_counts[0], task_counts[1], task_switches, task_reaped);
    kprintf("D13 stack used A=%u B=%u of 4096; locals/registers OK\n", task_stack_used[0], task_stack_used[1]);
    kprintf("TASKS OK pages recovered; IF=0/1 preserved\n");
    task_demo_done();
    irq_restore(flags);
}

/* No nested IRQ enable in handlers; depth is nevertheless owned by each task. */
void task_trap_enter(void) { ++tasks[current].trap_depth; }
void task_tick(void) { if (preempt_active) need_resched = 1; }
static void preempt_pending(void)
{
    if (!preempt_active || !need_resched || tasks[current].trap_depth) return;
    if (tasks[current].preempt_count) { ++preempt_deferred; return; }
    tasks[current].state = RUNNABLE;
    schedule_locked();
}
void task_trap_leave(unsigned interrupted_if)
{
    KASSERT(tasks[current].trap_depth);
    --tasks[current].trap_depth;
    if (interrupted_if) preempt_pending();
}
void preempt_disable(void)
{
    uint32_t flags = irq_save();
    ++tasks[current].preempt_count;
    irq_restore(flags);
}
void preempt_enable(void)
{
    uint32_t flags = irq_save();
    KASSERT(tasks[current].preempt_count);
    --tasks[current].preempt_count;
    /* Original IF=0 belongs to the caller: defer until a later safe IRQ exit. */
    if (flags & 0x200) preempt_pending();
    irq_restore(flags);
}

volatile uint32_t preempt_counts[2], preempt_probe_passes, preempt_stack_used[2];
volatile uint32_t preempt_passed, preempt_initial_pages, preempt_reaped;
volatile uint32_t preempt_critical_ticks, preempt_nested_ok, preempt_if0_ok, preempt_enable_ok;
volatile unsigned preempt_cli_release = 1, preempt_work_release = 1;
volatile uint32_t preempt_cli_ticks, preempt_cli_switches;
volatile unsigned preempt_mask_requested, preempt_mask_actual;
static unsigned preempt_diagnostic;
extern void preempt_register_probe(unsigned seed);
void preempt_progress_sample(void) { __asm__ volatile("" ::: "memory"); }
void preempt_cli_sample(void) { __asm__ volatile("" ::: "memory"); }
void preempt_mask_sample(void) { __asm__ volatile("" ::: "memory"); }
void preempt_demo_done(void) { __asm__ volatile("" ::: "memory"); }
void preempt_probe_check(const uint32_t *r)
{
    uint32_t flags = irq_save();
    /* PUSHAD: EDI ESI EBP ESP EBX EDX ECX EAX, then PUSHFD. */
    KASSERT(r[0] == 0x77777777u + current && r[1] == 0x66666666u + current);
    KASSERT(r[2] == 0x55555555u + current && r[4] == 0x44444444u + current);
    KASSERT(r[5] == 0x33333333u + current && r[6] == 0x22222222u + current && r[7] == 0x11111111u + current);
    KASSERT((r[8] & 0xed5) == 0x645 && (r[8] & 0x200));
    ++preempt_probe_passes;
    irq_restore(flags);
}
static void busy_counter(void *arg)
{
    unsigned id = (uintptr_t)arg;
    if (preempt_diagnostic && id == 0) {
        uint32_t flags = irq_save();
        timer_mask(1);
        preempt_mask_requested = preempt_mask_actual = 1;
        kprintf("D14 IRQ0 masked: A busy, B stalled; GDB releases mask\n");
        preempt_mask_sample();
        irq_restore(flags);
        while (preempt_mask_requested) ++preempt_counts[id];
        timer_mask(0);
        preempt_mask_actual = 0;
    }
    /* Independent CPU work. No yield/HLT/calls inside this progress loop. */
    while (!preempt_work_release || preempt_counts[0] < 200000 || preempt_counts[1] < 200000)
        ++preempt_counts[id];
    for (unsigned n = 0; n < 4; ++n) {
        uint32_t switches = preempt_switches;
        preempt_register_probe(id + 1);
        KASSERT(preempt_switches > switches);
    }
}
void preempt_demo(unsigned diagnostic)
{
    uint32_t original = irq_save();
    preempt_diagnostic = diagnostic;
    preempt_initial_pages = page_free_count();
    KASSERT(task_create(busy_counter, (void *)0));
    KASSERT(task_create(busy_counter, (void *)1));
    preempt_active = 1;
    timer_start();
    preempt_disable();
    preempt_disable();
    __asm__ volatile("sti" ::: "memory");
    uint32_t start = timer_ticks;
    while (timer_ticks - start < 3) __asm__ volatile("" ::: "memory");
    KASSERT(preempt_switches == 0 && need_resched);
    preempt_critical_ticks = timer_ticks - start;
    preempt_enable();
    KASSERT(preempt_switches == 0 && tasks[0].preempt_count == 1);
    preempt_nested_ok = 1;
    preempt_enable();
    KASSERT(preempt_switches > 0);
    preempt_enable_ok = 1;
    preempt_disable();
    start = timer_ticks;
    while (timer_ticks - start < 2) __asm__ volatile("" ::: "memory");
    uint32_t enabled = irq_save();
    uint32_t held_switches = preempt_switches;
    preempt_enable();
    KASSERT(preempt_switches == held_switches && need_resched);
    uint32_t observed = irq_save();
    KASSERT(!(observed & 0x200));
    preempt_if0_ok = 1;
    preempt_cli_ticks = timer_ticks;
    preempt_cli_switches = preempt_switches;
    preempt_cli_sample();
    while (!preempt_cli_release) __asm__ volatile("" ::: "memory");
    /* Bounded real CLI window, separate from the IRQ-enabled deferred test. */
    for (volatile unsigned n = 0; n < 2000000; ++n) { }
    KASSERT(timer_ticks == preempt_cli_ticks && preempt_switches == preempt_cli_switches);
    irq_restore(enabled);
    preempt_progress_sample();
    while (tasks[1].state != DEAD || tasks[2].state != DEAD)
        __asm__ volatile("hlt" ::: "memory");
    (void)irq_save();
    timer_mask(1);
    preempt_active = 0;
    need_resched = 0;
    for (unsigned i = 1; i < SLOTS; ++i) {
        uint32_t page = tasks[i].kernel_stack;
        KASSERT(*(uint32_t *)page == CANARY);
        KASSERT(tasks[i].trap_depth == 0 && tasks[i].preempt_count == 0);
        unsigned untouched = 4;
        while (untouched < PAGE_BYTES && *(uint8_t *)(page + untouched) == 0xa5) ++untouched;
        preempt_stack_used[i - 1] = PAGE_BYTES - untouched;
        KASSERT(preempt_stack_used[i - 1] < PAGE_BYTES - 256);
        KASSERT(page_free(page));
        tasks[i].kernel_stack = 0;
        ++preempt_reaped;
    }
    KASSERT(preempt_counts[0] >= 200000 && preempt_counts[1] >= 200000);
    KASSERT(preempt_probe_passes == 8 && preempt_deferred >= 3);
    KASSERT(page_free_count() == preempt_initial_pages);
    preempt_passed = 1;
    kprintf("D14 PREEMPT A=%u B=%u switches=%u\n", preempt_counts[0], preempt_counts[1], preempt_switches);
    kprintf("D14 seven-GPR/flags/DF probes=%u; deferred ticks=%u\n", preempt_probe_passes, preempt_critical_ticks);
    kprintf("D14 nested/IF0/CLI OK; stacks=%u,%u reaped=%u\n", preempt_stack_used[0], preempt_stack_used[1], preempt_reaped);
    kprintf("PREEMPT OK pages recovered; returning to keyboard\n");
    preempt_demo_done();
    irq_restore(original);
}
