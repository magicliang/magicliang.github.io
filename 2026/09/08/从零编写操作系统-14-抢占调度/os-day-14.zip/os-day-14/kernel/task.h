#ifndef TASK_H
#define TASK_H
#include <stdint.h>
/* One CPU, ordinary call boundaries only; never yield while holding a lock. */
int task_create(void (*entry)(void *), void *arg);
void task_yield(void);
_Noreturn void task_exit(void);
void task_demo(unsigned starve);
void task_trap_enter(void);
void task_trap_leave(unsigned interrupted_if);
void task_tick(void);
void preempt_disable(void);
void preempt_enable(void);
void preempt_demo(unsigned diagnostic);
#endif
