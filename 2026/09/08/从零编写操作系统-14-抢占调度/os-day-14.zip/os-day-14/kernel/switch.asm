bits 32
section .text
global switch_context, task_trampoline, task_register_probe
extern task_start, task_exit, task_yield
; saved_sp points at EDI, ESI, EBX, EBP, followed by the call return address.
switch_context:
    push ebp
    push ebx
    push esi
    push edi
    mov eax, [esp+20]
    mov edx, [esp+24]
    mov [eax], esp
    mov esp, edx
    pop edi
    pop esi
    pop ebx
    pop ebp
    ret
; RET here consumed the synthetic continuation. Establish a real C CALL.
task_trampoline:
    cld
    and esp, -16
    call task_start
    call task_exit
    ud2
; Test all four callee-saved registers across an actual scheduling round.
task_register_probe:
    push ebp
    push ebx
    push esi
    push edi
    sub esp, 12
    mov edx, [esp+32]
    mov ebp, 0x13579bdf
    add ebp, edx
    mov ebx, 0x2468ace0
    add ebx, edx
    mov esi, 0x11223344
    add esi, edx
    mov edi, 0x55667788
    add edi, edx
    call task_yield
    mov edx, [esp+32]
    lea ecx, [edx+0x13579bdf]
    xor eax, eax
    cmp ebp, ecx
    jne .done
    lea ecx, [edx+0x2468ace0]
    cmp ebx, ecx
    jne .done
    lea ecx, [edx+0x11223344]
    cmp esi, ecx
    jne .done
    lea ecx, [edx+0x55667788]
    cmp edi, ecx
    jne .done
    inc eax
.done:
    add esp, 12
    pop edi
    pop esi
    pop ebx
    pop ebp
    ret

; Separate from CPU-bound counters: a real IRQ wakes HLT and switches tasks.
; Capture flags before any arithmetic, clear DF before calling C.
global preempt_register_probe, preempt_probe_wait, preempt_probe_restored
extern preempt_probe_check
preempt_register_probe:
    pushfd
    pushad
    mov edx, [esp+40]
    mov eax, 0x11111111
    add eax, edx
    mov ecx, 0x22222222
    add ecx, edx
    mov ebx, 0x44444444
    add ebx, edx
    mov ebp, 0x55555555
    add ebp, edx
    mov esi, 0x66666666
    add esi, edx
    mov edi, 0x77777777
    add edi, edx
    add edx, 0x33333333
    cli
    push dword 0x647
    popfd
preempt_probe_wait:
    hlt
    pushfd
    pushad
preempt_probe_restored:
    cld
    mov ebx, esp
    and esp, -16
    sub esp, 12
    push ebx
    call preempt_probe_check
    mov esp, ebx
    add esp, 36
    popad
    popfd
    ret
