# 第 14 篇：PIT 抢占实测

日期：2026-09-08。前置第 13 篇冻结源码 `2bc725e0e33f08f79e1c0ef6f648a012f867344a`。复用已有 `localhost/build-an-os:day01` 默认架构镜像与其 i686 交叉工具链，未重建镜像；独立 Podman 容器执行 QEMU TCG、`pc-i440fx-7.2`、qemu32、单 CPU、64 MiB、SeaBIOS 和 IDE raw。

## 重跑和证据

在 `examples/build-an-os` 下执行：

```sh
podman run --rm -v "$PWD:/work" -w /work localhost/build-an-os:day01 make check-preempt
podman run --rm -v "$PWD:/work" -w /work localhost/build-an-os:day01 make check screenshot help
```

两条命令本次均退出 0。最后完整日志为宿主 `/private/tmp/day14-all.log`；先前定向日志为 `/private/tmp/day14-target.log`。最后 screenshot 轮会更新 `build/preempt-{normal,masked}-{gdb,serial,qemu}.txt`，本页数字取这最后一轮。检查使用 GDB 自带 Python，容器不需要独立 python3。每个 GDB 实例有 `timeout -k 5 120` 宿主上限，QEMU 总会被脚本清理；无须在既有容器中另开检查进程争用 1234 端口。

最后一轮正常镜像：两次各 0.3 秒自由运行采样中，A 从 23700735 增到 45216100，B 从 24763327 增到 48848681，tick 从 40 增到 70。两个计数循环无 yield、HLT 或函数调用。为避免机器过快导致观察前已经完成，GDB 临时清零默认值为 1 的 `preempt_work_release`，采样后置回 1；这个门只延长忙循环，不执行调度。最后 A=45216101、B=48848682，switches=81。

独立 `mbr-preempt-mask.img` 先在 A 中屏蔽 IRQ0。两次各 0.3 秒自由运行采样中，A 从 78017139 增到 155147236，B=0 且 RUNNABLE；客体 IF=1，ticks=3、switches=1 均不变。GDB 置 `preempt_mask_requested=0` 后，A 解除 IRQ0 屏蔽。后续两个自由运行窗口中 A 从 183917886 增到 208824573，B 从 30392869 增到 62818276，tick 从 40 增到 71。最后 A=208824574、B=62818277，switches=81。截图上的静态文字不构成停滞证据，以上结论由实际内存/寄存器采样支撑。

两种镜像都完成 8 次汇编寄存器探针。最后正常轮 GDB 先记录 task 1 的七个哨兵，接着在 `switch_context` 看到 current 已选为 2，旧 task 1 的 IRQ0 frame 仍在 0x11ff44，属于其栈页；该帧包含七个原值及 IF/DF，调度时旧任务 trap_depth=0。随后回到同一个 task 1 的 `preempt_probe_restored`，实读 PUSHFD/PUSHAD 快照，switches 从 67 增到 70，七 GPR 与算术标志/IF/DF 一致。哨兵为基础值加任务槽号，不会因两个任务使用相同值而掩盖错栈恢复。

每个任务的四次探针都由内核断言验证切换计数确实增长。这些探针使用 HLT 等待 IRQ，是独立的恢复测试，不当作 CPU 忙循环进展证据。PUSHFD 在任何改变算术标志的操作之前取样；CLD 后才进入 C 验值函数；共享探针计数的读改写受 CLI 保护。

## 临界区结果

bootstrap 先嵌套两次 `preempt_disable`，保留 IF=1。实际收到至少 3 个 tick，need_resched=1，但 switches=0；第一次 enable 后计数仍为 1，不能切换，最后一次 enable 在原 IF=1 时立即兑现延期请求。随后又在禁抢占且 IF=1 的区域收到两次 tick，再 CLI 并执行 enable：即使 preempt_count 已降为 0，原 IF=0 的调用方仍保持 IF=0，不能跨越其临界区切走。

最后一轮两镜像的 CLI 检查均在 ticks=7、switches=3。GDB 暂时清零 `preempt_cli_release`，detach 自由运行 0.2 秒后重新采样；IF仍为0，tick/切换数均不变。再置回1继续。这里是 IRQ 尚未进入，区别于上一段 IRQ 已处理、调度请求被延期的情况。正常镜像不依赖 GDB 放行，两个 release 门的默认值都是1。

## 累计回归与边界

完整 `make check screenshot help` 退出0；保留前序 ELF/装载/故障注入、异常现场、PIT/EOI、键盘、物理页、分页、堆和第13篇全部断言。第13篇仍是A=B=128、switches=387、reaped=2，栈扫描各260字节。第14篇两个栈扫描各340字节，canary完整，退出后由bootstrap归还2页，空闲页恢复16065，两种镜像均到达 `keyboard_ready`。本次内核文件27916字节，仍满足原链接装载上限。空闲页值与第13冻结版不同来自累计内核大小，不要求跨版本空闲页绝对值相同；检查的是本轮创建前后恢复相等。

`build/day14-screen.png`、`build/day14-masked.png`、`build/day14-recovered.png` 均由实际 QEMU monitor screendump 取得。已查看正常和屏蔽截图，文字完整，无裁切。

单CPU、三个固定槽、CPL0、原有no-FPU/SIMD约束不变。完整trap frame在任务栈上，saved_sp仍指向四callee-saved寄存器与普通RET续点，不将两者互相转换。设备EOI先完成，`task_trap_leave` 再降低每任务深度并判断调度；请求在切出前消费，避免旧continuation恢复后清掉新请求。handler没有STI，不在IRQ中分配、打印或阻塞。深度字段为每任务状态，但本次没有开启可嵌套IRQ去证明复杂嵌套中断模型。

演示关闭后才回到已有键盘入口，尚未实现IRQ0/IRQ1并用的通用调度生命周期、等待队列、阻塞、优先级、SMP或用户态。栈底canary和填充值扫描是有限诊断，不是guard page，也不是最坏栈深度证明。计数和切换总数受宿主速度及采样影响，不能解释为调度公平性或性能基准。
