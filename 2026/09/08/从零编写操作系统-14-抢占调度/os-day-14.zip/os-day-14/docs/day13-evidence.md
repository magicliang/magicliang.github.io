# 第 13 篇：协作式任务实测

日期：2026-09-08（重新执行验证）。前置冻结源码 `62894e1b7459dd28dfd84d8528aacbcd99ccae55`。复用已有 `localhost/build-an-os:day01` 镜像，未安装或重建工具链。QEMU 沿用 `pc-i440fx-7.2`、TCG、qemu32、单 CPU、64 MiB、SeaBIOS 和 IDE raw。

## 重跑

在 `examples/build-an-os` 下依次运行：

```sh
podman run --rm -v "$PWD:/work" -w /work localhost/build-an-os:day01 make build check-tasks
podman run --rm -v "$PWD:/work" -w /work localhost/build-an-os:day01 make check screenshot help
```

GDB 自带 Python 验证真实客体内存与寄存器，无独立 python3 依赖。Makefile 串行检查，共用容器 loopback 1234。正常和不让出 CPU 的镜像分别为 `mbr.img`、`mbr-taskstarve.img`；后者不会修改前者。日志为 `build/tasks-{normal,starvation}-{serial,gdb,qemu}.txt`。截图为 `build/day13-screen.png` 和 `build/day13-starvation.png`，由真实 QEMU monitor screendump 取得。

## 实现边界

任务表三个槽包含 bootstrap。两份独立页由 `page_alloc()` 分配，通过已有低 64 MiB identity 映射访问；每份栈恰好 4096 字节，无需假设多页连续，也不超过第 12 篇堆的单对象容量。`task_create` 对空入口、槽满和页分配失败返回 0，失败不会发布 RUNNABLE；演示实际检查槽满拒绝和页数不多减。

`switch_context` 保存 EBP/EBX/ESI/EDI；saved_sp 指向 EDI，随后依次是 ESI、EBX、EBP 和普通 call 的返回地址。恢复后 RET 回调用续点。初始栈使用同一布局，RET 进入汇编 trampoline，CLD、AND ESP,-16、CALL task_start，因此 C 入口满足 `(ESP+4)%16=0`。C task_start 返回后由 trampoline 调用 task_exit；退出者只标 DEAD 并切走，不释放正在使用的栈。

每次 yield 的保存 flags 是各自 C 栈中的局部变量；调度器运行时 IF=0，换回后恢复对应 continuation 的 flags。新任务 IF=0；演示 B 显式 IF=1，A 保持 IF=0，每次实际跨任务恢复后核对其 IF。此时第 08 篇演示已将主从 PIC mask 设为 0xff，B 不会开启未知设备 IRQ。普通 yield 禁止用于持锁区和任意 IRQ handler。CLI 不排除 NMI、异常或其他 CPU。

两个任务各执行 128 轮，每轮先检查另一计数应处于的精确阶段，再增加自身计数、yield 并验证八个不同局部值。汇编 probe 使用与任务 id 相关的不同 EBP/EBX/ESI/EDI 哨兵，避免两边同值掩盖错误恢复。GDB 在两任务首次 C 入口检查栈对齐、DF/IF 和页内 ESP；在两计数均为 1 时直接读取两份活跃局部数组，确认不同栈范围与全部八个值。

bootstrap 最后核对 DEAD、底部 canary、填充值边界，才归还页；GDB 核对两次回收和页计数恢复。填充值扫描只是本次执行修改字节的诊断，不能证明最坏栈深度；相同字节、临时 ESP 下移而未写入等情况可能不被计入。底部 canary 不是 guard page，也不能保证任意未来调用链适合 4 KiB。

不让出 CPU 的镜像中，A 进入真实无限递增循环，B 已是 RUNNABLE。GDB detach 后运行一秒再 attach 采样，重复一次；检查 A 增长、B 始终 0、current=1、switches=1、reaped=0。观察窗口由宿主计时，不是客体时间片；截图只展示模式，停滞结论来自两次内存采样。该版本没有抢占能力。

未来第 14 篇可在完整 trap frame 留于各任务栈时，从 IRQ 返回尾部挂起普通调用续点；本篇没有实现 IRQ 调度，也没有把 callee-saved 布局冒充 trap frame。现有 no-SSE/no-MMX/soft-float 标志不变。

## 本次验证结果

2026-09-08 执行 `make build check-tasks check screenshot help`，退出码 0。正常任务 A=B=128，switches=387，reaped=2；空闲页恢复为 16066。两份栈位于 0x11e000 与 0x11f000，填充值扫描各为 260 字节。最后一轮不让出实验两次采样 A=352221837、697965053，B=0 且 RUNNABLE。前序启动、异常、PIT、键盘、物理页、分页、堆的累计检查全部通过。完整宿主日志 `/private/tmp/day13-current-check.log`；可复核脚本与客体日志路径见上文。
