#ifndef TASK_H
#define TASK_H
#include <stdint.h>
/* One CPU, ordinary call boundaries only; never yield while holding a lock. */
int task_create(void (*entry)(void *), void *arg);
void task_yield(void);
_Noreturn void task_exit(void);
void task_demo(unsigned starve);
void task_trap_enter(void);
void task_trap_leave(unsigned interrupted_if);
void task_tick(void);
void preempt_disable(void);
void preempt_enable(void);
void preempt_demo(unsigned diagnostic);
uint32_t irq_save(void);
void irq_restore(uint32_t flags);
struct wait_queue { unsigned mask; }; /* ponytail: fixed-slot set; FIFO links if wake order matters. */
void task_block_locked(struct wait_queue *q);
int wake_one_locked(struct wait_queue *q);
void sleep_ticks(uint32_t ticks);
void wait_demo(unsigned broken);
#endif
