#include "user.h"
#include "memory.h"
#include "runtime.h"
#include "console.h"
#include <stddef.h>
struct tss32 { uint32_t words[25]; uint16_t trap, iomap; } __attribute__((packed));
static struct tss32 user_tss;
static uint64_t user_gdt[6];
static struct { uint16_t limit; uint32_t base; } __attribute__((packed)) user_gdtr;
uint32_t user_kernel_cr3;
volatile unsigned user_fail_after = 7;
extern char __stack_top, user_blob_start, user_blob_end;
_Static_assert(sizeof(struct tss32) == 104 && offsetof(struct tss32, iomap) == 102, "32-bit TSS layout");
void user_init(void)
{
    __asm__ volatile("mov %%cr3,%0" : "=r"(user_kernel_cr3));
    user_gdt[1] = 0x00cf9a000000ffffull;
    user_gdt[2] = 0x00cf92000000ffffull;
    user_gdt[3] = 0x00cffa000000ffffull;
    user_gdt[4] = 0x00cff2000000ffffull;
    uint32_t base = (uint32_t)&user_tss;
    user_gdt[5] = 103ull | ((uint64_t)(base & 0xffffff) << 16) |
                  (0x89ull << 40) | ((uint64_t)(base >> 24) << 56);
    user_tss.words[1] = (uint32_t)&__stack_top;
    user_tss.words[2] = 0x10;
    user_tss.iomap = sizeof(user_tss); /* Beyond limit: no user I/O bitmap permission. */
    user_gdtr.limit = sizeof(user_gdt) - 1;
    user_gdtr.base = (uint32_t)user_gdt;
    __asm__ volatile("lgdt %0; ltr %1" : : "m"(user_gdtr), "r"((uint16_t)0x28) : "memory");
}
void user_switch(uint32_t pd, uint32_t stack_top)
{
    if (!user_kernel_cr3) return; /* Earlier demonstrations retain their CR3. */
    user_tss.words[1] = stack_top > PAGE_BYTES ? stack_top : (uint32_t)&__stack_top;
    if (!pd) pd = user_kernel_cr3;
    __asm__ volatile("mov %0,%%cr3" : : "r"(pd) : "memory");
}
void user_space_destroy(struct user_space *space)
{
    uint32_t cr3;
    __asm__ volatile("mov %%cr3,%0" : "=r"(cr3));
    KASSERT(!space->pages[0] || cr3 != space->pages[0]);
    for (unsigned i = 0; i < 6; ++i) {
        if (space->pages[i]) KASSERT(page_free(space->pages[i]));
        space->pages[i] = 0;
    }
}
int user_space_create(struct user_space *space, unsigned mode, uint32_t sentinel)
{
    *space = (struct user_space){0};
    for (unsigned i = 0; i < 6; ++i) {
        if (i == user_fail_after || !(space->pages[i] = page_alloc())) {
            user_space_destroy(space);
            return 0;
        }
        memset((void *)space->pages[i], 0, PAGE_BYTES);
    }
    uint32_t *pd = (uint32_t *)space->pages[0];
    memcpy(pd, (void *)user_kernel_cr3, 16 * sizeof(uint32_t));
    /* The earlier D11 alias PDE 256 is deliberately not inherited. */
    pd[USER_CODE >> 22] = space->pages[1] | 7;
    pd[(USER_STACK - PAGE_BYTES) >> 22] = space->pages[2] | 7;
    uint32_t *code_pt = (uint32_t *)space->pages[1];
    uint32_t *stack_pt = (uint32_t *)space->pages[2];
    code_pt[0] = space->pages[3] | 5; /* Present + user; read-only. */
    code_pt[1] = space->pages[4] | 7;
    stack_pt[1023] = space->pages[5] | 7;
    size_t bytes = (uintptr_t)&user_blob_end - (uintptr_t)&user_blob_start;
    KASSERT(bytes <= PAGE_BYTES);
    memcpy((void *)space->pages[3], &user_blob_start, bytes);
    uint32_t *data = (uint32_t *)space->pages[4];
    data[1] = mode;
    data[3] = 1; /* Host may temporarily extend observation; default boot finishes. */
    data[4] = sentinel;
    return 1;
}
