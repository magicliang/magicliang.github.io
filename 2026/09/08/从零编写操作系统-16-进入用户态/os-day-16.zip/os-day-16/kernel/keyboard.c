#include "keyboard.h"
#ifndef KEYBOARD_HOST_TEST
#include "console.h"
#include "task.h"
#endif

/* US set 1 only; zero entries deliberately ignore unsupported keys. */
int keyboard_parse(struct key_parser *p, uint8_t byte)
{
    static const uint8_t pause_tail[] = {0x1d, 0x45, 0xe1, 0x9d, 0xc5};
    static const char plain[128] = {
        [2]='1',[3]='2',[4]='3',[5]='4',[6]='5',[7]='6',[8]='7',[9]='8',[10]='9',[11]='0',
        [12]='-',[13]='=',[14]='\b',[16]='q',[17]='w',[18]='e',[19]='r',[20]='t',[21]='y',
        [22]='u',[23]='i',[24]='o',[25]='p',[26]='[',[27]=']',[28]='\n',
        [30]='a',[31]='s',[32]='d',[33]='f',[34]='g',[35]='h',[36]='j',[37]='k',[38]='l',
        [39]=';',[40]='\'',[41]='`',[43]='\\',[44]='z',[45]='x',[46]='c',[47]='v',
        [48]='b',[49]='n',[50]='m',[51]=',',[52]='.',[53]='/',[57]=' '
    };
    static const char shifted[128] = {
        [2]='!',[3]='@',[4]='#',[5]='$',[6]='%',[7]='^',[8]='&',[9]='*',[10]='(',[11]=')',
        [12]='_',[13]='+',[26]='{',[27]='}',[39]=':',[40]='"',[41]='~',[43]='|',
        [51]='<',[52]='>',[53]='?'
    };
    if (p->pause) {
        if (byte == pause_tail[p->pause - 1]) {
            if (++p->pause == 6) p->pause = 0;
            return 0;
        }
        /* Mismatch drops the partial Pause; reconsider this byte once. */
        p->pause = 0;
    }
    if (byte == 0xe1) { p->pause = 1; p->extended = 0; return 0; }
    if (byte == 0xe0) { p->extended = 1; return 0; }
    if (p->extended) { p->extended = 0; return 0; } /* Includes PrintScreen fake shifts. */
    unsigned code = byte & 0x7f, down = !(byte & 0x80);
    if (code == 42) { p->left = down; return 0; }
    if (code == 54) { p->right = down; return 0; }
    if (code == 58) {
        if (down && !p->caps_down) p->caps ^= 1;
        p->caps_down = down;
        return 0;
    }
    if (!down) return 0;
    char c = plain[code];
    unsigned shift = p->left || p->right;
    if (c >= 'a' && c <= 'z') { if (shift ^ p->caps) c -= 'a' - 'A'; }
    else if (shift && shifted[code]) c = shifted[code];
    return c;
}

#ifndef KEYBOARD_HOST_TEST
#define QUEUE_SIZE 64
static volatile uint8_t raw[QUEUE_SIZE];
static volatile unsigned head, tail;
volatile uint32_t keyboard_dropped, keyboard_irqs, keyboard_resets;
volatile unsigned keyboard_consumer_paused; /* GDB diagnostic: producer continues. */
volatile unsigned keyboard_line_length;
char keyboard_line[64];
static struct key_parser parser;
static struct wait_queue keyboard_waiters;
volatile uint32_t keyboard_blocks, keyboard_wakes, keyboard_bytes;
static uint8_t inb(uint16_t port) { uint8_t v; __asm__ volatile("inb %1,%0":"=a"(v):"Nd"(port):"memory"); return v; }
static void outb(uint16_t port, uint8_t v) { __asm__ volatile("outb %0,%1"::"a"(v),"Nd"(port):"memory"); }
static int write_port(uint16_t port, uint8_t byte)
{
    for (unsigned n = 0; n < 100000; ++n)
        if (!(inb(0x64) & 2)) { outb(port, byte); return 1; }
    return 0;
}
static int read_byte(void)
{
    for (unsigned n = 0; n < 100000; ++n) {
        uint8_t status = inb(0x64);
        if (status & 1) {
            uint8_t byte = inb(0x60);
            if (!(status & 0xe0)) return byte;
            return -1;
        }
    }
    return -1;
}
static int command(uint8_t byte) { return write_port(0x60, byte) && read_byte() == 0xfa; }
static int keyboard_init(void)
{
    /* timer_demo already remapped PIC; IRQ1 remains masked throughout ACK polling. */
    if (!write_port(0x64, 0xad) || !write_port(0x64, 0xa7)) return 0;
    unsigned n;
    for (n = 0; n < 256 && (inb(0x64) & 1); ++n) (void)inb(0x60);
    if (inb(0x64) & 1) return 0;
    if (!write_port(0x64, 0x20)) return 0;
    int mode = read_byte();
    if (mode < 0 || !write_port(0x64, 0x60) ||
        !write_port(0x60, (mode & ~0x53) | 0x20) || !write_port(0x64, 0xae)) return 0;
    if (!command(0xf5) || !command(0xf0) || !command(1) || !command(0xf4)) return 0;
    if (!write_port(0x64, 0x60) || !write_port(0x60, (mode & ~0x52) | 0x21)) return 0;
    outb(0x21, inb(0x21) & ~2u); /* Preserve the PIT's mask bit. */
    return 1;
}
void keyboard_irq(void)
{
    ++keyboard_irqs;
    uint8_t status = inb(0x64);
    if (status & 1) {
        uint8_t byte = inb(0x60);
        if (!(status & 0xe0)) {
            unsigned next = (head + 1) % QUEUE_SIZE;
            if (next == tail) ++keyboard_dropped;
            else { raw[head] = byte; head = next; }
        } else ++keyboard_dropped;
        keyboard_wakes += wake_one_locked(&keyboard_waiters);
    }
    outb(0x20, 0x20);
}
void keyboard_ready(void) { __asm__ volatile("" ::: "memory"); }
void keyboard_loop(void)
{
    (void)irq_save();
    if (!keyboard_init()) { kprintf("KEYBOARD INIT FAIL\n"); return; }
    console_init();
    kprintf("D09 PS/2 IRQ1 raw set1 translation=off\nRelease all keys after overflow; retry your line.\n> ");
    uint32_t seen_dropped = 0;
    keyboard_ready();
    for (;;) {
        __asm__ volatile("cli" ::: "memory");
        if (!keyboard_consumer_paused && seen_dropped != keyboard_dropped) {
            seen_dropped = keyboard_dropped;
            tail = head;
            parser = (struct key_parser){0};
            keyboard_line_length = 0; keyboard_line[0] = 0;
            ++keyboard_resets;
            __asm__ volatile("sti" ::: "memory");
            kprintf("\nOVERFLOW dropped=%u: release ALL keys, retry line\n> ", seen_dropped);
            continue;
        }
        if (keyboard_consumer_paused || tail == head) {
            ++keyboard_blocks;
            task_block_locked(&keyboard_waiters);
            continue;
        }
        uint8_t byte = raw[tail]; tail = (tail + 1) % QUEUE_SIZE;
        ++keyboard_bytes;
        __asm__ volatile("sti" ::: "memory");
        int c = keyboard_parse(&parser, byte);
        if (c == '\n') {
            kprintf("\nLINE: %s\n> ", keyboard_line);
            keyboard_line_length = 0; keyboard_line[0] = 0;
        } else if (c == '\b') {
            if (keyboard_line_length) { keyboard_line[--keyboard_line_length] = 0; console_putc('\b'); }
        } else if (c && keyboard_line_length < sizeof(keyboard_line) - 1) {
            keyboard_line[keyboard_line_length++] = c;
            keyboard_line[keyboard_line_length] = 0; console_putc(c);
        }
    }
}
#endif
