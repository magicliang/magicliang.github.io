#include <stdint.h>
#include "timer.h"
#include "console.h"
#include "task.h"

/* Single CPU: volatile makes observations visible; CLI protects snapshots. */
volatile uint32_t timer_ticks;
volatile uint8_t timer_mask_requested, timer_mask_actual, timer_isr;
static unsigned timer_mode;

static void timer_outb(uint16_t port, uint8_t value)
{
    __asm__ volatile("outb %0, %1" : : "a"(value), "Nd"(port) : "memory");
}

static uint8_t timer_inb(uint16_t port)
{
    uint8_t value;
    __asm__ volatile("inb %1, %0" : "=a"(value) : "Nd"(port) : "memory");
    return value;
}

static void pic_write(uint16_t port, uint8_t value)
{
    timer_outb(port, value);
    timer_outb(0x80, 0); /* Legacy PC I/O delay between PIC commands. */
}

void timer_irq(void)
{
    ++timer_ticks;
    task_tick();
    if (timer_mode != 2) timer_outb(0x20, 0x20); /* IRQ0: master EOI only. */
}

/* GDB/screenshot checkpoint, called in the foreground with IF=0. */
void timer_observed(void) { __asm__ volatile("" : : : "memory"); }

void timer_start(void)
{
    __asm__ volatile("cli" : : : "memory");
    timer_mode = 0;
    timer_ticks = 0;
    pic_write(0x20, 0x11); pic_write(0xa0, 0x11);
    pic_write(0x21, 0x20); pic_write(0xa1, 0x28);
    pic_write(0x21, 0x04); pic_write(0xa1, 0x02);
    pic_write(0x21, 0x01); pic_write(0xa1, 0x01);
    pic_write(0x21, 0xff); pic_write(0xa1, 0xff);
    timer_outb(0x43, 0x34); /* Channel 0, low/high bytes, mode 2, binary. */
    timer_outb(0x40, 11932 & 0xff);
    timer_outb(0x40, 11932 >> 8);
    timer_mask_requested = timer_mask_actual = 0xfe;
    pic_write(0x21, 0xfe);
}

void timer_mask(unsigned masked)
{
    uint32_t flags = irq_save();
    uint8_t mask = timer_inb(0x21);
    pic_write(0x21, masked ? mask | 1 : mask & ~1u);
    irq_restore(flags);
}
unsigned timer_pending(void)
{
    /* 8259A OCW3: RR=1, RIS=0 selects IRR; reading does not acknowledge. */
    pic_write(0x20, 0x0a);
    return timer_inb(0x20) & 1;
}

void timer_demo(unsigned mode)
{
    timer_start();
    timer_mode = mode;
    kprintf("D08 PIT divisor=11932 IRQ0 vector=32\n");
    uint32_t printed = 0;
    for (;;) {
        __asm__ volatile("cli" : : : "memory");
        uint32_t now = timer_ticks;
        if (now >= printed + 10) {
            printed = now;
            kprintf("TIMER ticks=%u\n", now); /* Never print inside IRQ. */
            timer_observed();
        }
        if (mode == 0 && now >= 20) break;
        if (mode != 0) {
            /* Diagnostic images poll even while masked: IRQ0 cannot wake HLT. */
            timer_outb(0x21, timer_mask_requested);
            timer_mask_actual = timer_inb(0x21);
            timer_outb(0x20, 0x0b);
            timer_isr = timer_inb(0x20);
            __asm__ volatile("sti" : : : "memory");
        } else {
            /* IF=0 covered the check; STI and HLT must remain adjacent. */
            __asm__ volatile("sti; hlt" : : : "memory");
        }
    }
    pic_write(0x21, 0xff); pic_write(0xa1, 0xff);
    kprintf("TIMER OK - IRQ disabled for console regression\n");
}
