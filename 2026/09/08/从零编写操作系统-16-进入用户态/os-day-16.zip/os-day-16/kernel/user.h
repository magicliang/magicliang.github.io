#ifndef USER_H
#define USER_H
#include <stdint.h>
#include "exceptions.h"
#define USER_CODE 0x40000000u
#define USER_DATA 0x40001000u
#define USER_STACK 0x80000000u
struct user_space { uint32_t pages[6]; }; /* PD, two PTs, code, data, stack. */
extern uint32_t user_kernel_cr3;
extern volatile unsigned user_fail_after;
void user_init(void);
int user_space_create(struct user_space *space, unsigned mode, uint32_t sentinel);
void user_space_destroy(struct user_space *space);
void user_switch(uint32_t pd, uint32_t stack_top);
_Noreturn void enter_user(uint32_t ip, uint32_t sp);
void user_demo(void);
int task_user_trap(struct trap_frame *frame, uint32_t address);
#endif
