bits 32
section .text
global enter_user
enter_user:
    cli
    mov ecx, [esp+4]
    mov edx, [esp+8]
    mov ax, 0x23
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    push dword 0x23
    push edx
    push dword 0x202
    push dword 0x1b
    push ecx
    iretd

section .rodata
global user_blob_start, user_blob_end, user_write_fault, user_cli_fault, user_out_fault
user_blob_start:
user_blob_loop:
    inc dword [0x40001000]
    cmp dword [0x40001000], 200000
    jb user_blob_loop
    cmp dword [0x4000100c], 0
    je user_blob_loop
    cmp dword [0x40001014], 0
    je user_blob_loop
    mov dword [0x40001008], 1
    mov eax, [0x40001004]
    cmp eax, 1
    je user_blob_write
    cmp eax, 2
    je user_blob_cli
    cmp eax, 3
    je user_blob_out
    jmp user_blob_loop
user_blob_write:
    mov edi, [0x40001010]
user_write_fault:
    mov dword [edi], 0xbadbad00
    jmp user_blob_loop
user_blob_cli:
user_cli_fault:
    cli
    jmp user_blob_loop
user_blob_out:
    mov al, 0x55
user_out_fault:
    out 0x80, al
    jmp user_blob_loop
user_blob_end:
