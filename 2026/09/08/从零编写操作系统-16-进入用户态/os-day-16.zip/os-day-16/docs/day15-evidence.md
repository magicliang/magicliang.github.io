# 第 15 篇实测记录：等待与唤醒

日期：2026-09-08。累计代码前置版本为第 14 篇代码提交 `eeacce13e89cc6347645364095ecbafc7f4f2b1c`；本文件记录第 15 篇待冻结工作区的同轮实测，不把后续文章提交号当成已运行的源码版本。

## 执行环境与命令

使用既有 `localhost/build-an-os:day01`，每轮创建新的 ARM64 容器，未使用 `--platform linux/amd64`，未复用其他任务的容器。目标仍为单 CPU `qemu32`、TCG、`pc-i440fx-7.2`、64 MiB 内存和已有 SeaBIOS。工具链基线见 [environment.md](environment.md)。

从仓库根目录执行的目标检查：

```sh
podman run --rm -v "$PWD/examples/build-an-os:/work" -w /work localhost/build-an-os:day01 make check-wait check-keyboard check-tasks check-preempt
```

随后完整检查与实际截图：

```sh
podman run --rm -v "$PWD/examples/build-an-os:/work" -w /work localhost/build-an-os:day01 sh -c 'make check > build/day15-full-check.txt 2>&1 && make screenshot > build/day15-screenshot-check.txt 2>&1 && make help > build/day15-help.txt'
```

上述两轮命令均退出 0。另以 `sh -n tools/check-wait.sh` 检查 shell 语法。宿主 ARM LSP 对 x86 内联汇编约束的提示不作为目标编译证据；实际 i686 GCC 的 `-Wall -Wextra -Werror` 编译及完整链接通过，未新增依赖。

## 运行结果

| 观察点 | 本轮实际结果 | 证据 |
|---|---|---|
| 正常受保护窗口 | GDB 读到 PIC `irr=01 imr=fe isr=00`，IF=0，producer 仍只执行了前一阶段的一次；当前事件尚未生产、等待集合为空 | `build/wait-normal-gdb.txt` |
| 错误窗口 | 真实 IRQ0 producer 已执行，条件为 1，消费者状态为 BLOCKED，集合位图为 2，唤醒数为 0；断点时救援次数仍为 0 | `build/wait-lost-gdb.txt` |
| 三种事件顺序 | 正常 produced=3、consumed=3、woken=0/1/1；错误版为 0/0/1，lost=1、rescued=1 | 两个 `wait-*-serial.txt` 与 `wait-*-gdb.txt` |
| 定时任务 | 两镜像均完成 8 次 `sleep_ticks(3)`，每次恢复 tick 差不少于 3；0 tick 返回，模运算跨回绕边界断言通过 | 客体断言及 `wait_sleep_passes=8` |
| 栈与页 | 两镜像的两个自检任务栈使用诊断为 372、196 字节；reaped=2，空闲页回到该轮初始值 16064，等待集合与归属清空 | `wait_demo_done` 断点 |
| 无输入 | 新键盘任务 BLOCKED；0.2 秒自由运行中 PIT tick 增长，但 `keyboard_blocks` 和 `keyboard_bytes` 不变；bootstrap 为 current=0，QEMU 报 HLT=1 | 两个 `wait-*-gdb.txt` |
| 真实输入 | HMP 在 VM 运行态注入 `h`、`i`、回车，得到 `LINE: hi`；本轮 IRQ=6、wakes=6、bytes=6，最终再次阻塞；主 PIC 为 `imr=fc isr=00` | 两个 `wait-*-serial.txt` 与 `wait-*-gdb.txt` |

最后一次 `make screenshot` 的正常自检 idle 计数为 24，错误版为 22；这类计数受宿主与调试停顿影响，不要求下次完全相同。两张 720×400 截图分别为 `build/day15-screen.png`（11570 字节）和 `build/day15-lost.png`（11569 字节），已实际打开检查。错误版截图是诊断救援完成后的汇总；真正“条件为真却阻塞”的现场由救援前 GDB 断点证明，不能把汇总截图当成当时寄存器现场。

当前正常 `kernel.bin` 为 33228 字节，占 65 个有效载荷扇区，仍在 128 扇区保留区内；链接器继续强制包括 BSS/启动栈在内的内核运行区不超过 64 KiB。

## 为什么这是真实丢失唤醒实验

`event_consumer` 先在 `while (!wait_event)` 读到条件为假。错误版本在登记前恢复 IF，等下一次真实 PIT IRQ 设置条件并尝试唤醒，然后重新 CLI 并错误地直接登记 BLOCKED。后续 IRQ 发现该矛盾状态并记录，3 tick 后才执行一次明确标记的诊断救援。

正常版本在同一位置保持 CLI，以最多 1000000 次 I/O 读取确认主 PIC IRR0 已挂起，并断言 tick 与 producer 次数未改变；随后登记 BLOCKED、切到 idle，开中断后由真实 handler 完成唤醒。这里没有从前台直接调用 producer、`timer_irq` 或 `task_tick`。IRQ 退出仍通过原有 EOI 后最外层调度点。

8259A 的 OCW3 位布局、IRR/ISR 读取和 IMR 每位屏蔽语义已在本轮核查：[Intel 8259A 数据手册](https://pdos.csail.mit.edu/6.828/2010/readings/hardware/8259A.pdf)，印刷页 13、16–17。`0x0a` 选择 RR=1、RIS=0、P=0，因此是 IRR 状态读取，不是会确认中断的 Poll 命令；不发送 EOI，也不手工生产事件。

最初检查器在 GDB 暂停 VM 时发 `monitor sendkey`，本轮实际得到 IRQ=0，不能算输入证明；修正为 detach 后通过独立 HMP socket 在运行态输入，真实 IRQ 与 `LINE: hi` 验证才通过。内核没有为该检查器问题添加模拟事件。

## 累计回归与边界

完整 `make check` 包含此前镜像布局/损坏/截短、保护模式、运行时、console、异常、PIT、真实键盘编辑和溢出、物理页、分页、堆、协作式任务、抢占及第 15 篇检查。第 13 篇仍为 128 次/任务、387 次切换；第 14 篇七 GPR/flags/DF、延期调度、屏蔽 IRQ0 后停滞/恢复等断言未削弱。旧键盘检查仅将最终主片屏蔽字的预期从 `0xfd` 更新为 `0xfc`，匹配现已同时开放的 IRQ0/IRQ1；原输入和溢出断言保留。

两份自检栈的回收发生在创建持久键盘任务之前。正常交互最终保留一页键盘栈，空闲页是 16063；不能把它称为“运行时所有任务栈全部回收”。等待集合只有三个固定槽，不保证 FIFO 或公平性；没有超时取消、通用同步锁、用户态或 SMP 支持。栈填充/canary 只是有限诊断，不是 guard page。定时使用 PIT tick 而非精确墙钟，正常 idle 会周期性被 PIT 唤醒。

每个 QEMU 检查由宿主 `timeout -k 5 120` 限制 GDB 生命周期，HMP socket 读上限为 2 秒，测试进程退出时关闭自己启动的 QEMU。保护窗口内的 IRR 轮询另有迭代上限；它只用于诊断，不进入实际键盘等待路径。日志和截图均位于忽略的 `build/`，需要时可用上述命令再生成。
