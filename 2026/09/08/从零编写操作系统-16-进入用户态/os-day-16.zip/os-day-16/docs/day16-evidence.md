# 第 16 篇：用户态与地址空间实测

日期：2026-09-08。前置冻结源码 `f9979c5bc8710264161f927e5854736fa08b5b39`。复用已有 `localhost/build-an-os:day01` 默认ARM64宿主镜像及i686交叉编译器，未重建镜像、未改变64KiB装载上限。QEMU参数沿用TCG、pc-i440fx-7.2、qemu32、单CPU、64MiB、SeaBIOS及IDE raw。

## 重跑

在 `examples/build-an-os` 下执行：

```sh
podman run --rm -v "$PWD:/work" -w /work localhost/build-an-os:day01 make check-user
podman run --rm -v "$PWD:/work" -w /work localhost/build-an-os:day01 make check screenshot help
```

定向检查和最后完整检查均退出0。完整日志为宿主 `/private/tmp/day16-all.log`，包含最新故障EIP核对；前期定向日志 `/private/tmp/day16-target.log` 早于EIP补充。最后screenshot轮的客体证据为 `build/user-gdb.txt`、`build/user-serial.txt`、`build/user-qemu.txt`，以下数字取这一轮。GDB使用自身Python，无独立python3依赖；脚本以 `timeout -k 5 120` 限制一次检查，并清理QEMU。`build/day16-screen.png` 由真实monitor screendump生成，已查看：三种fault、精确EIP、幸存者增量和最终USER OK文字完整。

## 真实用户态与隔离

每任务分配六个私有页：PD、两张PT、代码、数据、栈，再加一页内核栈。GDB逐项读取两个任务共12个不同物理页，核对PD中的低16个PDE与kernel PD一致且U位为0；PDE256与511指向自己的用户PT。代码PTE权限5（P/U、只读），数据与栈PTE权限7（P/W/U）；未继承第11篇的supervisor测试别名PDE256。

用户VA固定为代码 `0x40000000`、数据 `0x40001000`、栈页 `0x7ffff000`，初始ESP为 `0x80000000`。两次各0.3秒自由运行采样中，A从27709051增到51195437，B从21856827增到46478524。随后在真实用户指令地址停下，实读CS=0x1b、SS=0x23、当前CR3为该任务的私有PD；通过用户数据VA读取的计数与其私有物理页相等。

观察窗口内数据页偏移12临时置0，延长两个任务的计数循环；默认值为1，因此普通启动不依赖GDB。这个门不产生调度。bootstrap也参与轮询，宿主定时采样可能落在其CPL0代码中；检查不假设任意时刻CPU必在用户态，而是另外用用户指令硬件断点验证CS/SS与当前CR3。

实际IRQ0样本属于task1：原用户CS=0x1b、SS=0x23、ESP=0x80000000；处理中CPU的CS=8、SS=0x10。76字节frame在 `0x127fb4`，恰好结束于该任务内核栈顶 `0x128000`，TSS.esp0也为 `0x128000`，当前CR3=`0x121000`。公共frame仍是68字节，仅CS低两位为3时读取额外ESP/SS。每个任务首次真实IRQ0将其私有页偏移20置1，错误任务等到这个标记才执行危险指令，避免只证明异常切栈却没有证明其用户IRQ路径。

GDT保留内核0x08/0x10，增加用户0x1b/0x23、TSS0x28。GDB核对GDTR limit47、TSS ss0=0x10、iomap104；编译期核对TSS大小104和iomap偏移102，描述符limit103。用户EFLAGS从0x202开始，IOPL=0；I/O位图起点超过TSS界限。代码以IRET降权，未使用硬件任务切换。

## 三类故障

每轮task1正常计数，task2执行一种错误操作。CPL3的#PF/#GP只设置当前任务的终止请求与诊断字段；`task_trap_leave` 将深度从1减到0，再进入已有 `task_exit`，不会在IRQ深度非零时切换，也不会经过普通延期调度路径重新发布DEAD任务。内核同类fault仍走原修复条件或panic。

| 错误操作 | 实测vector/error | 实测用户EIP | 错误任务退出后正常计数增加 |
| --- | --- | --- | --- |
| 写低地址内核哨兵 | #PF / 7 | 0x4000004a | 2042584 |
| CLI | #GP / 0 | 0x40000052 | 2135467 |
| OUT 0x80, AL | #GP / 0 | 0x40000057 | 2244561 |

EIP并非根据vector猜测：C和GDB分别将三条汇编指令标签减去 `user_blob_start`，再加用户代码VA，逐项比对实际frame->eip。第一次#PF还核对CR2为内核哨兵地址，错误任务DEAD、trap_depth=0，bootstrap已恢复kernel CR3，哨兵仍为0x51a7cafe。

这里没有exit系统调用。用户在私有数据页写完成标记后仍继续计数；bootstrap等待错误任务退出及正常任务完成标记，再让正常任务运行至少4个tick，核对计数增加，然后设置正常任务的终止请求。请求只在后续IRQ安全尾部兑现。这是有限实验的监督收尾，不是用户进程生命周期API。两任务的完成标记没有先后保证，检查不会要求错误任务fault时另一任务已经运行过放行后的指令。

## 资源与累计回归

逐一在六个地址空间页及最后内核栈的七处分配点注入失败，均返回失败、未发布RUNNABLE，页数恢复；正常创建每对任务恰好减少14页。三轮共6个任务结束，累计回收36个私有地址空间页和6个内核栈页。共享的16张identity PT和原kernel PD未被释放。回收从bootstrap的kernel CR3、另一份栈进行，销毁函数也拒绝释放当前正在使用的PD。

最后两份栈填充值扫描各228字节，canary完整，所有任务私有页和kernel_stack字段清零，空闲页恢复16063。栈扫描和canary是有限诊断，不是guard page或最坏调用深度证明。数据页和用户栈页的权限与映射经过检查；用户程序没有完整C调用栈或ELF装载流程。

最终 `make check screenshot help` 退出0：保留启动、异常/PIT、物理页、分页、堆、协作、抢占、等待/丢唤醒诊断和原键盘编辑/溢出检查。D13仍为A=B=128、switches387；D14探针8次；D15事件3、睡眠8、正常pending1/lost0/rescued0。`check-wait`仍实际输入hi与回车、验证IRQ0/IRQ1同时开放和消费后重新阻塞；用户态结束后也到达原 `keyboard_ready`。

第15篇有限 `wait_demo` 现返回到用户态演示，最后由独立 `task_keyboard_start` 启动持久键盘/idle阶段。当前kernel文件37140字节，镜像头记录内存61008字节，距65536上限尚余4528字节。页表运行时按页分配，无BSS大页表数组；新增user.c单独以-Os编译，原有章节编译选项和loader界限保持不变。

本章仅覆盖单CPU、CPL0/3、固定两个用户任务、手写用户代码和已分类#PF/#GP。没有syscall、ELF、copy_from_user、通用退出/父子关系、FPU/SIMD或多核隔离保证。计数受宿主执行速度与观察窗口影响，不是性能或公平性基准。
