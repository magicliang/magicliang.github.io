#!/bin/sh
set -eu
for variant in normal lost; do
    elf=build/kernel.elf disk=build/mbr.img
    if [ "$variant" = lost ]; then elf=build/kernel-wait-lost.elf; disk=build/mbr-wait-lost.img; fi
    rm -f build/wait-monitor.sock
    "$QEMU" $QEMU_COMMON -drive file="$disk",format=raw,if=ide -display none -serial file:build/wait-$variant-serial.txt -monitor unix:build/wait-monitor.sock,server=on,wait=off -S -gdb tcp:127.0.0.1:1234 > build/wait-$variant-qemu.txt 2>&1 &
    pid=$!
    trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
    cat > build/wait.gdb <<GDB
set architecture i386
set tcp connect-timeout 5
set tcp auto-retry on
file $elf
target remote 127.0.0.1:1234
python
import gdb, time, socket
def v(expression): return int(gdb.parse_and_eval(expression))
s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
s.connect('build/wait-monitor.sock')
s.settimeout(2)
s.recv(8192)
def hmp(command):
    s.sendall((command+'\n').encode())
    data = b''
    while b'(qemu)' not in data: data += s.recv(8192)
    return data.decode(errors='replace')
end
GDB
    if [ "$variant" = lost ]; then
        cat >> build/wait.gdb <<'GDB'
hbreak wait_lost_observed
continue
delete breakpoints
python
assert v('wait_event') == 1 and v('wait_woken[1]') == 0
assert v('tasks[1].state') == 3 and v('event_waiters.mask') == 2
assert v('tasks[current].trap_depth') == 1 and not v('$eflags') & 0x200
assert v('wait_produced') == 2 and v('wait_consumed') == 1
assert v('wait_rescued') == 0
print('PASS: actual IRQ0 producer ran before enqueue; condition=1 consumer=BLOCKED waiters=2 wakes=0; rescue not yet run')
end
GDB
    else
        cat >> build/wait.gdb <<'GDB'
hbreak wait_pending_observed
continue
delete breakpoints
python
assert v('current') == 1 and not v('$eflags') & 0x200
assert v('wait_pending_seen') == 1 and v('wait_event') == 0
assert v('wait_armed') == 1 and v('event_waiters.mask') == 0
assert v('wait_produced') == 1 and v('wait_consumed') == 1
pic = gdb.execute('monitor info pic', to_string=True)
assert 'irr=01 imr=fe isr=00' in pic, pic
print('PASS: real PIC IRR0 pending with IF=0 before enqueue; producer has not run')
end
GDB
    fi
    cat >> build/wait.gdb <<'GDB'
hbreak wait_demo_done
continue
delete breakpoints
python
broken = v('wait_broken')
assert v('wait_passed') == 1 and v('wait_sleep_passes') == 8
assert v('wait_produced') == v('wait_consumed') == 3
assert [v('wait_woken[%d]' % i) for i in range(3)] == [0,1-broken,1]
assert v('wait_lost') == v('wait_rescued') == broken
assert v('wait_pending_seen') == 1-broken
assert v('wait_reaped') == 2 and v('free_pages') == v('wait_initial_pages')
assert v('event_waiters.mask') == 0 and v('wait_idle_halts') >= 8
assert v('task_switches') == 387 and v('task_passed') == v('preempt_passed') == 1
for i in [1,2]:
    assert v('tasks[%d].state' % i) == 0 and v('tasks[%d].kernel_stack' % i) == 0
    assert v('tasks[%d].waiting_on' % i) == v('tasks[%d].sleeping' % i) == 0
    assert 0 < v('wait_stack_used[%d]' % (i-1)) < 3840
print('PASS: three event orders; sleeps=8; idle=%d; lost=%d rescued=%d; stacks=%d,%d reaped=2 pages=%d; D13/D14 passed' % (v('wait_idle_halts'),broken,broken,v('wait_stack_used[0]'),v('wait_stack_used[1]'),v('free_pages')))
name = 'day15-lost' if broken else 'day15-screen'
gdb.execute('monitor screendump build/%s.png -f png' % name)
end
hbreak keyboard_ready
continue
delete breakpoints
python
assert v('current') == 1 and not v('$eflags') & 0x200
assert v('free_pages') == v('wait_initial_pages') - 1
end
hbreak wait_idle_observed if keyboard_blocks > 0
continue
delete breakpoints
python
assert v('current') == 0 and v('tasks[1].state') == 3
assert v('keyboard_waiters.mask') == 2 and v('tasks[1].waiting_on') != 0
count, blocks, tick = v('keyboard_bytes'), v('keyboard_blocks'), v('timer_ticks')
gdb.execute('detach')
time.sleep(.2)
gdb.execute('target remote 127.0.0.1:1234')
assert v('keyboard_bytes') == count and v('keyboard_blocks') == blocks
assert v('tasks[1].state') == 3 and v('timer_ticks') > tick
registers = gdb.execute('monitor info registers', to_string=True)
assert 'HLT=1' in registers and v('current') == 0, registers
print('PASS: consumer BLOCKED through 0.2s of real PIT ticks; no repeated polling; idle HLT=1; one live keyboard stack retained')
end
python
gdb.execute('detach')
for key in ['h', 'i', 'ret']:
    hmp('sendkey '+key+' 20')
    time.sleep(.1)
gdb.execute('target remote 127.0.0.1:1234')
print('INPUT counters IRQ=%d wakes=%d bytes=%d blocks=%d line=%d' % (v('keyboard_irqs'),v('keyboard_wakes'),v('keyboard_bytes'),v('keyboard_blocks'),v('keyboard_line_length')))
assert v('keyboard_irqs') >= 6 and v('keyboard_wakes') >= 3
assert v('keyboard_bytes') >= 6 and v('keyboard_line_length') == 0
assert v('tasks[1].state') == 3 and v('keyboard_waiters.mask') == 2
assert v('keyboard_dropped') == 0
pic = gdb.execute('monitor info pic', to_string=True)
assert 'imr=fc isr=00' in pic, pic
print('PASS: real IRQ1 woke consumer, consumed hi + Enter and blocked again; IRQ0/1 both unmasked')
s.close()
end
disconnect
GDB
    timeout -k 5 120 gdb-multiarch -q -nx -batch -x build/wait.gdb > build/wait-$variant-gdb.txt 2>&1
    cat build/wait-$variant-gdb.txt
    grep -q 'LINE: hi' build/wait-$variant-serial.txt
    kill "$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
    trap - EXIT HUP INT TERM
done
