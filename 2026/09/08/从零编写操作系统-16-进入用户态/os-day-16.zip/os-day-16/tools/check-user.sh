#!/bin/sh
set -eu
"$QEMU" $QEMU_COMMON -drive file=build/mbr.img,format=raw,if=ide -display none -serial file:build/user-serial.txt -monitor none -S -gdb tcp:127.0.0.1:1234 > build/user-qemu.txt 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
cat > build/user.gdb <<'GDB'
set architecture i386
set tcp connect-timeout 5
set tcp auto-retry on
file build/kernel.elf
target remote 127.0.0.1:1234
python
import gdb, struct, time
m = gdb.selected_inferior()
def v(e): return int(gdb.parse_and_eval(e))
def words(address, n): return struct.unpack('<%dI'%n, bytes(m.read_memory(address,4*n)))
def free_run(seconds):
    gdb.execute('detach')
    time.sleep(seconds)
    gdb.execute('target remote 127.0.0.1:1234')
end
hbreak user_round_ready
continue
delete breakpoints
python
assert v('user_round') == 0 and v('user_rollback_passes') == 7
assert v('free_pages') == v('user_initial_pages') - 14
assert v('$cr3') == v('user_kernel_cr3')
assert v('user_tss.iomap') == 104 and v('user_tss.words[2]') == 0x10
assert v('user_gdtr.limit') == 47
print('PASS: six-page address spaces plus kernel stacks; rollback at all 7 allocations; TSS size=104 iomap=104 GDT limit=47')
pages = [[v('tasks[%d].user.pages[%d]'%(i,j)) for j in range(6)] for i in [1,2]]
assert len(set(pages[0]+pages[1])) == 12
for row in pages:
    pd, pt, spt, code, data, stack = row
    assert words(pd,16) == words(v('user_kernel_cr3'),16)
    assert all(not x & 4 for x in words(pd,16))
    assert words(pd+4*256,1)[0] == pt|7
    assert words(pd+4*511,1)[0] == spt|7
    assert words(pt,2) == (code|5,data|7)
    assert words(spt+4*1023,1)[0] == stack|7
    # Code and data share this user PT; the D11 supervisor alias is not inherited.
    assert (words(v('user_kernel_cr3')+4*256,1)[0] & ~4095) != pt
    m.write_memory(data+12,struct.pack('<I',0))
print('PASS: identical user VAs map to 12 distinct owned physical pages; low 64MiB supervisor shared; user code read-only')
end
hbreak *task_user_trap
continue
delete breakpoints
python
owner = v('current')
faddr = words(v('$esp')+4,1)[0]
f = words(faddr,19)
assert owner in [1,2] and f[12] == 32
assert f[15] == 0x1b and f[17] == 0x80000000 and f[18] == 0x23
assert f[16] & 0x3200 == 0x200
assert v('$cs') == 8 and v('$ss') == 0x10
page = v('tasks[%d].kernel_stack'%owner)
assert page < v('$esp') < faddr and faddr+76 == page+4096
assert v('user_tss.words[1]') == page+4096
assert v('$cr3') == pages[owner-1][0]
print('PASS: real ring3 IRQ0 frame task=%d CS=1b SS=23 userESP=80000000; kernel CS=8 SS=10 frame=%s TSS.esp0=%s CR3=%s' % (owner,hex(faddr),hex(page+4096),hex(v('$cr3'))))
end
python
free_run(.3)
a1,b1 = words(pages[0][4],1)[0], words(pages[1][4],1)[0]
free_run(.3)
a2,b2 = words(pages[0][4],1)[0], words(pages[1][4],1)[0]
assert a2>a1>0 and b2>b1>0
# Bootstrap also receives round-robin turns; stop at a real user instruction.
gdb.execute('thbreak *0x40000000')
gdb.execute('continue')
assert v('$cs') == 0x1b and v('$ss') == 0x23
owner = v('current')
assert v('$cr3') == pages[owner-1][0]
assert words(0x40001000,1)[0] == words(pages[owner-1][4],1)[0]
assert v('user_irq_frames[0]') and v('user_irq_frames[1]')
print('PASS: two .3s free-run ring3 samples A=%d -> %d B=%d -> %d; same VA reads current private data; CPL3 and private CR3 observed' % (a1,a2,b1,b2))
for row in pages: m.write_memory(row[4]+12,struct.pack('<I',1))
end
hbreak user_fault_observed
continue
delete breakpoints
python
assert v('user_round') == 0 and v('tasks[2].state') == 0
assert v('tasks[2].trap_depth') == 0
assert v('user_fault_vectors[0]') == 14 and v('user_fault_errors[0]') == 7
assert v('user_sentinel') == 0x51a7cafe
assert v('$cr3') == v('user_kernel_cr3')
print('PASS: user kernel-write #PF(error=7), offender DEAD only after trap depth=0; kernel sentinel unchanged; bootstrap kernel CR3 restored')
end
hbreak user_demo_done
continue
delete breakpoints
python
assert v('user_passed') == 1 and v('user_reaped') == 6
assert [v('user_fault_vectors[%d]'%i) for i in range(3)] == [14,13,13]
assert [v('user_fault_errors[%d]'%i) for i in range(3)] == [7,0,0]
expected = [0x40000000+v('&'+name)-v('&user_blob_start') for name in ['user_write_fault','user_cli_fault','user_out_fault']]
assert [v('user_fault_eips[%d]'%i) for i in range(3)] == expected
print('PASS: fault EIPs match exact bad-write/CLI/OUT instruction offsets: %s' % [hex(x) for x in expected])
assert all(v('user_survivor_growth[%d]'%i)>0 for i in range(3))
assert v('free_pages') == v('user_initial_pages')
assert v('current') == 0 and v('$cr3') == v('user_kernel_cr3')
assert v('user_sentinel') == 0x51a7cafe
for i in [1,2]:
    assert v('tasks[%d].state'%i) == 0 and v('tasks[%d].kernel_stack'%i) == 0
    assert all(v('tasks[%d].user.pages[%d]'%(i,j)) == 0 for j in range(6))
    assert 0 < v('user_stack_used[%d]'%(i-1)) < 3840
print('PASS: #PF7, CLI #GP0, OUT #GP0 isolated; survivor growth=%s; 6 tasks/42 private pages reclaimed; free=%d stacks=%d,%d' % ([v('user_survivor_growth[%d]'%i) for i in range(3)],v('free_pages'),v('user_stack_used[0]'),v('user_stack_used[1]')))
assert v('task_switches') == 387 and v('wait_passed') == v('preempt_passed') == 1
end
monitor screendump build/day16-screen.png -f png
hbreak keyboard_ready
continue
printf "PASS: ring3 demo reaches original blocking keyboard consumer\n"
disconnect
GDB
timeout -k 5 120 gdb-multiarch -q -nx -batch -x build/user.gdb > build/user-gdb.txt 2>&1
cat build/user-gdb.txt
