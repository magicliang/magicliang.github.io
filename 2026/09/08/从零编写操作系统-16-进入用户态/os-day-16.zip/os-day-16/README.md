# 从零编写操作系统：第 16 篇配套实验

当前启动路径执行真实 C 内核：交叉编译生成 `kernel.elf`，`objcopy` 提取可装载字节；stage2 沿用镜像头和 checksum，暂存于 `0x10000`，完成 E820、A20 与保护模式切换后复制到 `0x100000`。内核入口清 BSS、建立 16 KiB 栈，并按 cdecl 传入 BootInfo。完成物理页自检后开启 32 位非 PAE 分页，再运行页支持的可变大小堆、协作式任务、PIT 抢占、等待唤醒与 Ring 3 用户态演示；启动器仍不解析通用 ELF。

## 运行

在本目录执行，宿主已有启动的 Podman Linux 环境：

```sh
podman run --rm -it -v "$PWD:/work" -w /work localhost/build-an-os:day01 sh
```

容器中执行：

```sh
make build
make check
make run
make screenshot
```

首次没有工具链镜像时才运行 `podman build -t localhost/build-an-os:day01 .`。现有镜像不需要重建。

正常串口保留启动、时钟和 `CONSOLE OK`，再运行第 10 篇物理页检查并输出 `MEMORY OK`，接着运行第 11 篇分页与页故障恢复检查，输出 `PAGING OK`，再执行第 12 篇堆自检并输出 `HEAP OK`、第 13 篇协作式任务自检和第 14 篇抢占自检，随后完成第 15 篇等待/定时唤醒自检并输出 `WAIT OK`，再完成第 16 篇三轮用户故障隔离并输出 `USER OK`，最后 VGA 清屏进入 `D09 PS/2 IRQ1` 输入界面。`make run` 可输入 US 字母、数字和常用标点，支持两侧 Shift、Caps Lock、退格与回车；回车输出 `LINE:`。`make check-keyboard` 通过真实 QEMU `sendkey` 验证输入和队列满，保存 `build/day09-screen.png`。`make check-heap` 验证堆并分别保存 `build/day12-screen.png` 与 `build/day12-heapfault.png`。

`make check-console` 检查真实 COM1/VGA、80 列换行、滚屏、格式化边界、串口持续不就绪和独立 `mbr-panic.img` 的断言停机；`make check-pm` 保留第 04 篇保护模式和故障实验；`make check-kernel` 验证第 05 篇入口、装载边界、C ABI、运行时函数与坏 BSS；`make check` 同时跑此前 ELF、读盘、坏头、损坏、截短和坏签名回归。检查共用容器内 GDB 1234 端口，不要另开调试实例同时运行。

## 手动调试

同一容器内执行：

```sh
make debug &
gdb-multiarch build/kernel.elf
```

GDB 中执行：

```text
target remote 127.0.0.1:1234
hbreak *kernel_main
continue
info registers esp cr0
x/wx $esp+4
p/x initialized
p/x zeroed
p/x &__stack_top
monitor quit
quit
```

必须用 `hbreak *kernel_main` 才停在函数第一条指令、尚未执行 C 序言的位置；此时 `ESP % 16 = 12`，返回地址后面的参数是 `0x5000`。`call` 之前 ESP 为 16 字节对齐。`monitor quit` 会关闭远程连接。

## 文件与契约

- `kernel/`：C 内核、入口、链接脚本与四个最小内存函数；`sample/` 仍保留第 01 篇独立链接样例。
- `boot/`：累计 MBR、stage2 和 BootInfo v1。BootInfo 仍为 40 字节，payload 字段仍表示低端暂存位置及文件长度；最终内核地址由链接契约固定。
- `tools/kernel-header.sh`：从 ELF 符号与入口提取 memory/entry，核对 binary 文件长度；`mkpayload.c` 读取实际 binary，生成校验和与坏头，不再制造确定性载荷。
- `tools/check-kernel.sh`：GDB 比较装载字节、清零前后 BSS、参数、栈和已初始化数据，并检查正常、跳过清零和单扇区分批读取镜像。
- [第 05 篇实测记录](docs/day05-evidence.md)：地址、命令、结果和运行边界；此前的 [01](docs/day01-evidence.md)、[02](docs/day02-evidence.md)、[03](docs/day03-evidence.md)、[04](docs/day04-evidence.md) 记录对应当时快照。

所有产物写入忽略的 `build/`。当前工具链没有目标 libc/libgcc；最终 ELF 的未定义符号必须为空，编译禁止 SSE、MMX 和硬件浮点。本篇安装 256 项 IDT，其中 0–31 项是 present 的 CPU 异常入口，32 项是 IRQ0；33–255 项保持 non-present。该段第 07 篇入口说明属于历史阶段；当前版本在后续演示中开放 IRQ1，并增加物理页分配与分页。

## Console 与 panic 契约

初始化顺序是 stage2 完成 BIOS/E820/A20 → 保护模式复制内核 → entry 清 BSS、建栈 → `console_init` 配置 UART 并清 VGA → BootInfo/data/BSS/runtime 自检 → 格式化与滚屏演示。坏 BSS 镜像会在输出模块显式重置自身状态后继续报告 `KERNEL BSS FAIL`。

COM1 为 115200、8N1、无中断轮询。单次发送最多读取 LSR 100000 次；超限后停用串口，后续 VGA 仍可用。这是迭代上限，不是毫秒期限。VGA 固定 `0xb8000`、80×25、白字黑底，换行归零列并下移、回车归零列、退格擦除前一格（可跨行），最底行继续输出时向上搬移 24 行。

`kprintf` 仅支持 `%s %c %d %u %x %p %%`；`%p` 是带 `0x` 的不补零 32 位十六进制，`%s` 空指针输出 `(null)`。不支持宽度、精度、长度修饰、浮点或 UTF-8 排版；未知转换原样输出且不消费参数，末尾孤立 `%` 原样输出。格式串和非空字符串指针必须有效，参数类型需匹配。串口把 LF 转成 CRLF，CR/BS 直接发送；VGA 的退格擦除不等同于所有串口终端的显示策略。

`KASSERT` 失败先 `cli`，再把文件、行号和表达式同时写往两端，最后在 `panic_halt` 的 `hlt/jmp` 循环停机。它保留当前栈供 GDB 查看，不是任意 CPU 异常的寄存器捕获器。当前仅单核 IRQ0，handler 不调用输出；前台时钟输出在 IF=0 的临界区，不提供可重入或多核输出锁。

[第 06 篇实测记录](docs/day06-evidence.md) 包含可重跑命令、真实输出、故障注入方式与证据路径。`build/mbr-panic.img` 只替换 C 内核，不修改正常镜像。

## CPU 异常入口（第 07 篇）

`make check-exceptions` 构建并检查正常 INT3 恢复，以及独立的 `mbr-divide.img`、`mbr-ud2.img`、`mbr-gp.img`。正常启动先运行真实 INT3，经 IRETD 返回，再清屏运行第 06 篇 console 演示；串口保留 `EXCEPTION RETURN OK`，最终 VGA 布局不变。坏 BSS 在安装 IDT 前退出。`make check` 包含这项检查。

`kernel/exceptions.asm` 将 CPU 错误码与软件补零统一，保存全部 GPR 和 DS/ES/FS/GS；进入 C 前加载数据段、CLD 并动态对齐栈，返回时恢复现场、清理 vector/error 后 IRETD。68 字节 frame 仅适用于当前 ring 0 同级入口，没有 CPU 未压入的旧 SS/ESP；`pushad_esp` 是 PUSHAD 前的 ESP。

本例采用固定 `qemu32` 目标的经典错误码集合 8、10、11、12、13、14、17，该异常入口的第 07 篇阶段未启用分页/CET 等扩展，不是所有现代 x86 异常的完整分类。CPU 异常不是外部硬件 IRQ；第 07 篇冻结快照的 IF 始终为 0；当前累计代码在异常探针结束后增加第 08 篇 PIC/PIT 演示。真实 #GP 用超出 GDT 的 selector 0x18 装载 DS；`int 13` 不产生 CPU 错误码，不能用来测试 #GP 的错误码入口。

[第 07 篇实测记录](docs/day07-evidence.md) 给出 trap frame、C ABI、DF/GPR 恢复和停机证据。`build/day07-screen.png` 是 INT3 返回点截图，`build/day07-{divide,ud2,gp}.png` 是异常诊断截图。普通同栈 #DF 入口不能保证从损坏栈中恢复；未测试的异常入口不宣称已完成运行覆盖。

## 时钟 IRQ（第 08 篇）

`make check-timer` 验证 IRQ0 真实 frame、正常镜像 10→20 tick，以及两个独立诊断镜像：`mbr-timer-monitor.img` 在 GDB 两次采样之间真正运行一秒，展示 count 增长、屏蔽稳定、恢复增长；`mbr-timer-noeoi.img` 故意漏主 PIC EOI，count 始终为 1，ISR0 为 1，恢复 IMR 后仍不增长。GDB 只写诊断 mask 请求，从不写 tick。两个诊断镜像持续运行，使用忙轮询保证 IRQ0 被屏蔽后仍能处理恢复请求。

正常镜像在 `timer_demo(0)` 中完成约 0.2 秒的有限演示，20 tick 后保持 IF=0、屏蔽主从全部 IRQ，再运行原 console 演示，到达 `console_demo_done` 后进入键盘输入循环。`make check-timer` 仍在清屏前生成第 08 篇时钟截图；第 09 篇截图由 `make check-keyboard` 生成；当前 `make screenshot` 生成第 12 篇堆截图。`make check` 保留全部早期检查并加入时钟检查。

PIC 主从按 ICW1–4 重映射到 0x20/0x28，仅主 IRQ0 解除屏蔽。PIT channel 0 使用 Mode 2、低字节后高字节写 divisor=11932；按 QEMU 输入常量计算约 99.99849 Hz，不保证真实墙钟精度。IRQ0 复用 68 字节 frame，只递增 `timer_ticks` 并发主片 EOI；打印在前台，未实现任务切换。单核共享数据使用 CLI 临界快照；volatile 仅保证访问可见，不能替代同步。正常等待从 CLI 检查开始，然后在同一 asm 中紧邻 STI/HLT。

[第 08 篇实测记录](docs/day08-evidence.md) 给出本次实际样本、产物和边界。


## 第 09 篇：IRQ1 与键盘输入

`make check-keyboard` 使用镜像内已有的 GDB Python 运行宿主解析器检查与真实 QEMU IRQ1 注入。IRQ1 共用异常汇编入口，只读取状态/数据、入 64 槽原始字节队列（可用 63）并向主 PIC 发送 EOI；前台负责 set1、行编辑与输出。初始化在 IF=0、IRQ1 屏蔽时关闭 translation、显式配置键盘 set1，并有界等待 ACK，成功后只开放 IRQ1。

输入行最多 63 字符，满行忽略新增字符但退格、回车仍有效。Pause 序列与 E0 扩展键被消费而不输出，PrintScreen 的伪 Shift 不改变两侧 Shift 状态。Caps 仅在新的按下时切换；重复按下不会反复翻转，不同步键盘 LED。未实现布局切换、方向键、USB 或运行时键盘命令。

原始队列满丢新字节并累加 `keyboard_dropped`。前台短暂 CLI 清队列、解析状态、修饰键和当前行，再提示释放全部键后重试；无法重建仍物理按住的键。`keyboard_consumer_paused` 仅供 GDB 暂停消费，不屏蔽 IRQ1；恢复标志后仍需一次 IRQ 唤醒暂停中的 HLT。VGA 退格会擦除单元格，串口只发送 BS，不保证终端视觉擦除。证据与重跑命令见 [day09-evidence.md](docs/day09-evidence.md)。

## 第 10 篇物理页

`kernel/memory.c` 从 BootInfo 的规范化 24 字节 E820 项建立两个各 2048 字节位图。仅 type=1、attributes=1 的完整 4 KiB 页可用；其余描述符覆盖的页向外保留，覆盖关系与记录顺序无关。64 位区间加法先验证再截到 64 MiB；零长度和溢出使初始化失败。保留低于 1 MiB 以及内核完整运行区（含 BSS、位图和栈）。

`page_alloc()` 返回物理页地址，耗尽返回 0；`page_free()` 只接受对齐、可分配且当前已分配的页，失败返回 0；`page_free_count()` 返回快照。每次位图更新保存并恢复 IF，适用于本实验单 CPU。分配不清零；第 11 篇以此分配页表，第 12 篇以此建立堆；没有多核锁或 DMA 区分类。首次适配从最低候选页扫描，释放时降低候选位置，避免连续耗尽测试反复扫描已占用前缀；仍未引入空闲链表。

`make check-memory` 在真实客体中执行普通分配、全页写入与验证、耗尽、单页重分配和计数恢复，随后由 GDB 检查位图、保留区、CR0 与内核边界，并继续到键盘入口。输出 `build/memory-{serial,gdb,vga}.txt` 和 `build/day10-screen.png`；截图在键盘清屏之前截取。合成 E820 输入检查与真实固件输入使用同一解析算法，但不把合成异常图声称为固件实测。

详见 [第 10 篇实测记录](docs/day10-evidence.md)。


## 第 11 篇分页

`kernel/paging.c` 在 `memory_demo` 完成后从现有分配器取得 18 个物理页：页目录 1、低 64 MiB identity 页表 16、高地址测试页表 1。表项为 32 位，地址拆成 10/10/12 位；CR3 使用物理页目录地址，CR4.PAE/PSE/PGE 清零，CR0.PG/WP 置位。低地址窗口全部 supervisor RW，覆盖代码、数据、原 C 栈、IDT、VGA、页表自身；并不提供内核代码只读保护，也不把映射范围当作可分配 RAM。非 PAE 没有 NX。

测试在 `0x40000000` 映射分配器给出的 A/B 数据页，先读 A，再改映射并 `INVLPG` 后读到 B；随后清除 PTE 并失效产生真实 read #PF error=0，恢复映射后重试原指令。将 PTE 改成 present readonly 后，WP 使 supervisor write 产生 error=3，恢复 RW 后重试写入。handler 只允许已武装阶段、固定地址、固定汇编 EIP 和精确错误码组合，无分配，也不跳过故障指令。CR2 在异常分派输出前读取；其他 #PF 打印 CR2、错误码和现场后 panic。

演示结束清除高地址 PTE、失效 TLB，再释放 A/B；18 个活跃页表页保留。分配器不能在此之后重新初始化。`make check-paging` 检查硬件寄存器、全部低地址 PTE 权限、同一个 C 栈、两个真实 fault/retry、分配位图和键盘入口。独立 `mbr-pagefault.img` 在未武装恢复时再次读未映射地址，验证 panic 及实际 `HLT=1`。单 CPU 不实现远程 TLB shootdown、进程地址空间、ring 3、通用虚拟内存或页表回收。详见 [第 11 篇实测记录](docs/day11-evidence.md)。


## 第 12 篇内核堆

`kmalloc(n)` 最多管理四个各 4096 字节的独立物理页 arena；页来自已有 `page_alloc()`，通过第 11 篇低 64 MiB identity 映射访问。首次需要时取得页，页耗尽返回空指针，已有块保持不变。每页按块边界隐式遍历，采用 first fit，不要求不同页连续，也不跨页合并。返回地址按 16 字节对齐；头部 16 字节，尾诊断 4 字节，单次最大请求 4076 字节。0 和超过上限的请求失败；加法与向上对齐先检查溢出。

头部保存实际 span、请求字节数、使用状态和校验 tag。分裂余量至少 32 字节，否则吸收余量；4 字节 canary 紧跟请求末端，以字节拷贝读写，所以 17 字节对象写第 18 字节即可被检查发现。`kfree(p)` 先验证各页全部块边界、元数据及 canary，再匹配准确 payload 地址，不直接解引用未知 `p - 16`；拒绝返回 0。释放后合并同页右侧与左侧空闲块。分配和释放保存/恢复调用者 IF；单 CPU 的 CLI 区间内不输出、不分配其他堆对象、不调度。

`make check-heap` 覆盖不同尺寸读写、首个空闲块复用、最小分裂、余量不足不分裂、双向合并、整数溢出、非法/重复释放、尾字节和头部破坏、真实物理页耗尽后的失败恢复、512 个最小对象耗尽及四个最大对象恢复。演示结束逐页验证完整空闲块后归还 arena，GDB 核对 allocated 位图仍恰有 18 个活跃页表页。它不会重新初始化物理页分配器。独立 `mbr-heapfault.img` 破坏 17 字节对象的第一个尾字节，确认拒绝后主动 panic，正常镜像继续到键盘入口。

当前 raw-pointer API 不识别同地址复用后的陈旧指针（ABA），tag/canary 也不能证明没有所有形式的越界或伪造。空闲块合并后再次释放可能归类为无效地址；未提供通用 realloc、自动缩容、多核锁或虚拟地址管理。空页通常保留以便复用，演示内部 `release()` 只在全部块空闲时归还。本实验依赖 i686 GCC freestanding、32 位地址与既有 identity 映射：物理页上的类型化访问不是跨平台 ISO C 分配器承诺。未来任务栈可直接使用独立物理页，不需要扩大这份字节堆。详见 [第 12 篇实测记录](docs/day12-evidence.md)。

每次分配/释放先整堆验证；其他对象损坏也会使当前操作失败，必须修复诊断注入或停机处理，不能绕过检查继续分配。头部 XOR tag 不是安全校验，不能抵抗蓄意伪造；canary 在后续分配/释放检查时发现变化，不是在越界写发生的瞬间触发 CPU 异常。

## 第 13 篇协作式任务

`task.c` 使用三个固定槽：bootstrap 和两个任务。每个新任务从 `page_alloc()` 取得一个独立 4096 字节物理页，在既有 identity 映射中作内核栈；不依赖页之间连续，也不向最大 4076 字节的堆请求 4096 字节。底部 canary 与填充值扫描是诊断，不是 guard page。

`switch_context` 在普通 C 调用边界保存 EBP/EBX/ESI/EDI 和 ESP，换栈后由 RET 返回各自的调用续点；EAX/ECX/EDX 遵守 caller-saved 规则。首次 RET 进入汇编 trampoline，清 DF、对齐 ESP 后 CALL C，返回后 CALL `task_exit`。退出只置 DEAD 并切走；bootstrap 恢复后检查并释放两份栈。第 13 篇阶段没有抢占或用户态；累计版本的后续演示见下文，仍不支持 FPU/SIMD 或多核。

`task_yield` 保存 EFLAGS、CLI、轮询 RUNNABLE 槽、切换，再恢复本续点的 EFLAGS。新任务 IF=0；测试中 B 的 IF=1，但此前主从 PIC 仍全部屏蔽，绝不在切换器无条件 STI。禁止在持锁区、任意 IRQ handler 或普通临界区调用 yield。未来 IRQ 尾部若复用切换器，完整 trap frame 仍应留在任务栈中，不能把 callee-saved context 当作 trap frame。

`make check-tasks` 检查两个任务各 128 次交替、不同局部数组、不同 callee-saved 寄存器哨兵、独立 IF、C 首次入口对齐、栈归还与键盘入口。独立 `mbr-taskstarve.img` 让 A 忙循环且不 yield，GDB 两次 detach 后各自由运行一秒，核对 A 增长且 B=0/RUNNABLE。`make check-tasks` 保存 `build/day13-screen.png` 和 `build/day13-starvation.png`；历史检查与断言保留。详见 [第 13 篇实测记录](docs/day13-evidence.md)。


## 第 14 篇 PIT 抢占

`task_demo(0)` 仍先执行第 13 篇的 128 轮/任务、387 次切换和 IF=0/1 检查。随后 `preempt_demo(0)` 使用同一三个槽、同一 `switch_context` 和两份重新分配的 4 KiB 栈。`timer_start` 沿用 PIT/PIC 配置并保持 IF=0，只有第 14 篇任务入口显式 STI。IRQ 入口完整保存七个通用寄存器、段寄存器与硬件返回帧，CLD 后调用 C；设备 EOI 完成后，最外层 `task_trap_leave` 才检查延期请求。`saved_sp` 仍是普通调用续点，完整 trap frame 留在各自任务栈上，经 C 返回链和 IRET 恢复。

两个工作任务直接执行无 yield、无 HLT 的计数循环。独立的汇编 HLT 探针等待真实 IRQ，使用每任务不同的七 GPR 哨兵和算术标志、IF、DF，回到原任务后验证。`preempt_disable` 允许 IRQ/tick 进入，但阻止切换；嵌套 `enable` 只有降到零且原 IF=1 才兑现请求。原 IF=0 的调用方临界区继续等待后续允许的 IRQ 退出点。CLI 测试则证明 IRQ 尚未进入，不能混称为已收到 IRQ 的延期调度。

`make check-preempt` 运行正常及独立 `mbr-preempt-mask.img`。GDB 每次自由运行 0.3 秒，连续采样两次，证明两忙循环均增长；诊断镜像先屏蔽 IRQ0，证明 IF=1 时 A 增长、B=0、tick/切换不变，再解除屏蔽恢复两任务。`preempt_work_release` 与 `preempt_cli_release` 默认 1，只由检查脚本临时清零延长观察窗口；它们不产生调度。所有检查有 120 秒宿主上限。

截图为 `build/day14-screen.png`（正常）、`build/day14-masked.png`（屏蔽时）与 `build/day14-recovered.png`（恢复后）；日志为 `build/preempt-{normal,masked}-{serial,gdb,qemu}.txt`。两个任务结束后由 bootstrap 在 CLI 下检查 canary、填充值边界并归还栈页，关闭抢占演示后继续到 `keyboard_ready`。本实现仅覆盖单 CPU、CPL0、无 FPU/SIMD，未增加锁、等待队列、用户态、优先级或多核语义。实测数字与边界见 [第 14 篇实测记录](docs/day14-evidence.md)。

## 第 15 篇等待与唤醒

`wait_demo` 接在第 14 篇之后，复用三个任务槽和 `switch_context`。槽 0 成为专用 idle；动态任务全部阻塞时执行相邻 `sti; hlt`。工作任务优先于 idle，等待状态为 `BLOCKED`。固定容量的 `wait_queue` 用任务位图登记，不保证 FIFO；`task_block_locked` 要求 IF=0、非 IRQ、未禁抢占且不持有其他短临界区锁。条件检查和登记之间持续 CLI，唤醒只改变可运行状态，消费者恢复后循环复查条件。

`sleep_ticks` 通过同一调度器阻塞，IRQ0 扫描两个动态槽并唤醒到期任务。0 tick 直接返回，最大时长为 `0x7fffffff` tick；期限比较使用有界的 32 位模运算。定时等待与设备等待互斥，没有引入定时器堆、通用取消或多核锁。

正常自检覆盖事件先于检查、IRQ pending 位于受保护窗口、事件晚于阻塞三个顺序，以及 8 次至少 3 tick 的定时等待。两任务退出后由 bootstrap 回收栈。当前有限 `wait_demo` 返回给后续用户态演示；所有自检完成后，`task_keyboard_start` 再创建持久键盘消费任务。最终输入状态保留一页键盘栈；无输入时该任务阻塞，PIT 继续唤醒 idle，但不会让键盘消费者反复检查空队列。IRQ1 更新原始队列或溢出计数后唤醒消费者，解析、行编辑与打印仍在任务上下文完成。PIC 屏蔽改为保留另一路状态，交互时 IRQ0/IRQ1 同时开放，主片 IMR 为 `0xfc`。

`make check-wait` 运行正常与独立 `mbr-wait-lost.img`。错误镜像在读到条件为假后故意开中断，等真实 PIT producer 执行，再错误登记阻塞；检查先记录条件为真而任务 BLOCKED 的现场，3 tick 后诊断 watchdog 才救援。正常镜像用 8259A IRR0 证明 IRQ 已 pending，但 CLI 区间内 producer 尚未执行；登记并切到 idle 后再由真实 IRQ 唤醒。没有同步调用 producer 冒充硬件 IRQ。

`make check-wait` 生成 `build/day15-screen.png` 和 `build/day15-lost.png`；`make check-preempt` 继续生成历史第 14 篇截图。第 15 篇检查还通过运行态 HMP 输入 `hi` 与回车，验证实际 `LINE: hi` 和重新阻塞；旧键盘编辑/溢出、协作式任务与抢占检查保留。实测命令、计数和资料见 [第 15 篇实测记录](docs/day15-evidence.md)。


## 第 16 篇用户态与独立地址空间

`user_demo` 使用同一任务表、PIT 与 IRQ 返回调度。`user_init` 保留内核段 0x08/0x10，增加用户代码 0x1b、数据 0x23 和 TSS 0x28。TSS 长104字节、limit=103、ss0=0x10、iomap=104，用户 IOPL=0；I/O 位图偏移在段界限之外，用户 OUT 不获得权限。调度器在 CLI 下切换 CR3、更新目标内核栈顶 TSS.esp0，再换普通调用续点。首次 `enter_user` 用 IRET 装入 CS/SS/ESP/EIP 和 EFLAGS=0x202。

每个用户任务拥有六个页：页目录、两张用户页表、代码、数据、栈；另有一页内核栈。页目录只复制低64MiB的16个supervisor PDE，不复制第11篇测试别名；用户代码 `0x40000000` 为只读，数据 `0x40001000` 和栈 `0x7ffff000` 为可写，初始 ESP=`0x80000000`。两个任务相同VA指向不同物理页。完整分配并填充后才发布RUNNABLE；检查逐一注入七处分配失败，确认无任务发布、页数恢复。

公共 `trap_frame` 仍为68字节。只有 CS低两位为3才访问额外用户ESP/SS，总计76字节；实际IRQ0由TSS切到对应任务的内核栈。CPL3的#PF/#GP仅记录该任务的vector/error/EIP和退出请求，统一返回尾部将trap_depth降为0之后再退出。内核的异常修复和panic路径不变。回收发生在bootstrap的kernel CR3与另一份栈上，只归还六个私有页和任务内核栈，保留共享页表。

演示连续三轮，每轮一个正常计数任务配一个错误任务：写低地址内核哨兵得到#PF(error=7)，CLI和OUT各得到#GP(error=0)。检查把故障EIP与对应机器指令的用户地址逐项对照，同时确认哨兵不变、正常任务继续增长。本篇没有syscall、ELF或用户exit：用户在私有数据页写完成标记并继续计数，bootstrap观察后请求在下一次安全IRQ尾部终止正常任务，作为有限实验收尾。

`make check-user` 和当前 `make screenshot` 使用真实QEMU/GDB验证用户CS/SS、私有CR3、TSS切栈、七处分配失败回滚、两次0.3秒自由运行的独立计数进展，以及三种故障的精确指令EIP、幸存任务增长与全量回收。数据页偏移12的观察门默认1；GDB仅暂时置0延长计数窗口，再置1，普通启动无需调试器。偏移20由该任务第一次真实IRQ0置1，保证错误任务在触发故障前已实际经过用户到内核的中断路径。

截图为 `build/day16-screen.png`，日志为 `build/user-{gdb,serial,qemu}.txt`。全部历史断言、阻塞键盘输入和单CPU/no-FPU约束保留。详细实测与有限证明范围见 [第 16 篇记录](docs/day16-evidence.md)。
