bits 32
section .text
global switch_context, task_trampoline, task_register_probe
extern task_start, task_exit, task_yield
; saved_sp points at EDI, ESI, EBX, EBP, followed by the call return address.
switch_context:
    push ebp
    push ebx
    push esi
    push edi
    mov eax, [esp+20]
    mov edx, [esp+24]
    mov [eax], esp
    mov esp, edx
    pop edi
    pop esi
    pop ebx
    pop ebp
    ret
; RET here consumed the synthetic continuation. Establish a real C CALL.
task_trampoline:
    cld
    and esp, -16
    call task_start
    call task_exit
    ud2
; Test all four callee-saved registers across an actual scheduling round.
task_register_probe:
    push ebp
    push ebx
    push esi
    push edi
    sub esp, 12
    mov edx, [esp+32]
    mov ebp, 0x13579bdf
    add ebp, edx
    mov ebx, 0x2468ace0
    add ebx, edx
    mov esi, 0x11223344
    add esi, edx
    mov edi, 0x55667788
    add edi, edx
    call task_yield
    mov edx, [esp+32]
    lea ecx, [edx+0x13579bdf]
    xor eax, eax
    cmp ebp, ecx
    jne .done
    lea ecx, [edx+0x2468ace0]
    cmp ebx, ecx
    jne .done
    lea ecx, [edx+0x11223344]
    cmp esi, ecx
    jne .done
    lea ecx, [edx+0x55667788]
    cmp edi, ecx
    jne .done
    inc eax
.done:
    add esp, 12
    pop edi
    pop esi
    pop ebx
    pop ebp
    ret
