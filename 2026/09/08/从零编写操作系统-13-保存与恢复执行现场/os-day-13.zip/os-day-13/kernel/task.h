#ifndef TASK_H
#define TASK_H
#include <stdint.h>
/* One CPU, ordinary call boundaries only; never yield while holding a lock. */
int task_create(void (*entry)(void *), void *arg);
void task_yield(void);
_Noreturn void task_exit(void);
void task_demo(unsigned starve);
#endif
