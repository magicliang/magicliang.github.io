#include "task.h"
#include "memory.h"
#include "runtime.h"
#include "console.h"
#define SLOTS 3u
#define CANARY 0x51accafeu
enum task_state { DEAD, RUNNABLE, RUNNING };
struct task {
    uint32_t *saved_sp;
    uint32_t kernel_stack;
    enum task_state state;
    void (*entry)(void *);
    void *arg;
};
static struct task tasks[SLOTS];
static unsigned current;
volatile uint32_t task_counts[2], task_local_address[2], task_stack_used[2];
volatile uint32_t task_switches, task_reaped, task_passed, task_initial_pages;
static unsigned starvation;
extern void switch_context(uint32_t **old_sp, uint32_t *new_sp);
extern void task_trampoline(void);
extern int task_register_probe(unsigned seed);
static uint32_t irq_save(void)
{
    uint32_t flags;
    __asm__ volatile("pushfl; popl %0; cli" : "=r"(flags) : : "memory");
    return flags;
}
static void irq_restore(uint32_t flags)
{ __asm__ volatile("pushl %0; popfl" : : "r"(flags) : "memory", "cc"); }
/* A suspended scheduler returns with IF=0; its caller restores its own flags. */
static void schedule_locked(void)
{
    unsigned old = current;
    for (unsigned n = 1; n <= SLOTS; ++n) {
        unsigned next = (old + n) % SLOTS;
        if (tasks[next].state != RUNNABLE) continue;
        current = next;
        tasks[next].state = RUNNING;
        if (next != old) {
            ++task_switches;
            switch_context(&tasks[old].saved_sp, tasks[next].saved_sp);
        }
        return;
    }
    panic(__FILE__, __LINE__, "no runnable bootstrap");
}
int task_create(void (*entry)(void *), void *arg)
{
    uint32_t flags = irq_save();
    if (!entry) { irq_restore(flags); return 0; }
    for (unsigned i = 1; i < SLOTS; ++i) {
        struct task *t = &tasks[i];
        if (t->state != DEAD || t->kernel_stack) continue;
        uint32_t page = page_alloc();
        if (!page) { irq_restore(flags); return 0; }
        memset((void *)page, 0xa5, PAGE_BYTES);
        *(uint32_t *)page = CANARY;
        uint32_t *sp = (uint32_t *)(page + PAGE_BYTES);
        *--sp = (uint32_t)task_trampoline;
        *--sp = 0; /* EBP */
        *--sp = 0; /* EBX */
        *--sp = 0; /* ESI */
        *--sp = 0; /* EDI */
        *t = (struct task){sp, page, RUNNABLE, entry, arg};
        irq_restore(flags);
        return 1;
    }
    irq_restore(flags);
    return 0;
}
void task_yield(void)
{
    uint32_t flags = irq_save();
    tasks[current].state = RUNNABLE;
    schedule_locked();
    irq_restore(flags);
}
_Noreturn void task_exit(void)
{
    (void)irq_save();
    KASSERT(current != 0);
    tasks[current].state = DEAD;
    schedule_locked();
    panic(__FILE__, __LINE__, "dead task resumed");
}
void task_start(void)
{
    /* Fresh tasks start with IF=0. No unknown IRQ is enabled here. */
    tasks[current].entry(tasks[current].arg);
}
void task_sample(void) { __asm__ volatile("" ::: "memory"); }
void task_starving(void) { __asm__ volatile("" ::: "memory"); }
void task_demo_done(void) { __asm__ volatile("" ::: "memory"); }
static void counter(void *arg)
{
    unsigned id = (uintptr_t)arg;
    volatile uint32_t local[8];
    for (unsigned j = 0; j < 8; ++j) local[j] = 0x1000u * (id + 1) + j;
    task_local_address[id] = (uintptr_t)local;
    if (starvation && id == 0) {
        kprintf("D13 NO-YIELD A running; B=0 (cooperative only)\n");
        task_starving();
        for (;;) ++task_counts[0];
    }
    if (id == 1) __asm__ volatile("sti" ::: "memory"); /* PIC remains fully masked. */
    for (unsigned i = 0; i < 128; ++i) {
        KASSERT(task_counts[id] == i);
        KASSERT(task_counts[1 - id] == i + id);
        ++task_counts[id];
        task_sample();
        KASSERT(task_register_probe(id + 1));
        uint32_t observed = irq_save();
        KASSERT(!!(observed & 0x200) == id);
        irq_restore(observed);
        for (unsigned j = 0; j < 8; ++j)
            KASSERT(local[j] == 0x1000u * (id + 1) + j);
    }
}
void task_demo(unsigned starve)
{
    uint32_t flags = irq_save();
    starvation = starve;
    task_initial_pages = page_free_count();
    tasks[0].state = RUNNING;
    KASSERT(task_create(counter, (void *)0));
    KASSERT(task_create(counter, (void *)1));
    KASSERT(!task_create(counter, 0));
    KASSERT(page_free_count() == task_initial_pages - 2);
    while (tasks[1].state != DEAD || tasks[2].state != DEAD) task_yield();
    for (unsigned i = 1; i < SLOTS; ++i) {
        uint32_t page = tasks[i].kernel_stack;
        KASSERT(*(uint32_t *)page == CANARY);
        unsigned untouched = 4;
        while (untouched < PAGE_BYTES && *(uint8_t *)(page + untouched) == 0xa5) ++untouched;
        task_stack_used[i - 1] = PAGE_BYTES - untouched;
        KASSERT(task_stack_used[i - 1] < PAGE_BYTES - 256);
        KASSERT(page_free(page));
        tasks[i].kernel_stack = 0;
        ++task_reaped;
    }
    KASSERT(task_counts[0] == 128 && task_counts[1] == 128);
    KASSERT(page_free_count() == task_initial_pages);
    /* Exercise an IF=1 continuation with PIC masks still 0xff, no live IRQs. */
    __asm__ volatile("sti" ::: "memory");
    task_yield();
    uint32_t restored = irq_save();
    KASSERT(restored & 0x200);
    task_yield();
    restored = irq_save();
    KASSERT(!(restored & 0x200));
    task_passed = 1;
    kprintf("D13 TASKS A=%u B=%u switches=%u reaped=%u\n", task_counts[0], task_counts[1], task_switches, task_reaped);
    kprintf("D13 stack used A=%u B=%u of 4096; locals/registers OK\n", task_stack_used[0], task_stack_used[1]);
    kprintf("TASKS OK pages recovered; IF=0/1 preserved\n");
    task_demo_done();
    irq_restore(flags);
}
