#include <stddef.h>
#include <stdint.h>

#define SYS_EXIT 4u
#define SYS_WAIT 5u
#define SYS_OPEN 6u
#define SYS_READ 7u
#define SYS_FD_WRITE 8u
#define SYS_CLOSE 9u
#define SYS_SPAWN_FILE 10u
#define ERR_ENOENT 2
#define ERR_E2BIG 7
#define ERR_ENOEXEC 8
#define ERR_ENAMETOOLONG 36
#define MAX_ARGC 8u
#define MAX_ARG_LEN 31u
#define LINE_MAX 95u
#define FD_MAP3(a,b,c) (0xd2200000u | ((a)+1u) | (((b)+1u)<<4) | (((c)+1u)<<8))

static int32_t call2(uint32_t number, uintptr_t first, uintptr_t second)
{
    int32_t result;
    __asm__ volatile("int $0x80" : "=a"(result)
                     : "a"(number), "b"(first), "c"(second)
                     : "memory", "cc");
    return result;
}

static int32_t call3(uint32_t number, uintptr_t first, uintptr_t second,
                     uintptr_t third)
{
    int32_t result;
    __asm__ volatile("int $0x80" : "=a"(result)
                     : "a"(number), "b"(first), "c"(second), "d"(third)
                     : "memory", "cc");
    return result;
}

static int32_t spawn_file(const char *path, char **argv, unsigned argc)
{
    int32_t result;
    register uint32_t map __asm__("esi") = FD_MAP3(0, 1, 2);
    __asm__ volatile("int $0x80" : "=a"(result)
                     : "a"(SYS_SPAWN_FILE), "b"(path), "c"(argv),
                       "d"(argc), "S"(map)
                     : "memory", "cc");
    return result;
}

static int32_t read_fd(int fd, void *buffer, uint32_t length)
{ return call3(SYS_READ, (uintptr_t)fd, (uintptr_t)buffer, length); }
static int32_t write_fd(int fd, const void *buffer, uint32_t length)
{ return call3(SYS_FD_WRITE, (uintptr_t)fd, (uintptr_t)buffer, length); }
static int32_t open_file(const char *path)
{ return call2(SYS_OPEN, (uintptr_t)path, 0); }
static int32_t close_file(int fd)
{ return call2(SYS_CLOSE, (uintptr_t)fd, 0); }
static int32_t wait_pid(int32_t pid, uint32_t *status)
{ return call2(SYS_WAIT, (uintptr_t)pid, (uintptr_t)status); }

static size_t text_length(const char *text)
{ size_t n = 0; while (text[n]) ++n; return n; }

static int write_all(int fd, const void *data, uint32_t length)
{
    const uint8_t *bytes = data;
    uint32_t done = 0;
    while (done < length) {
        int32_t n = write_fd(fd, bytes + done, length - done);
        if (n <= 0) return -1;
        done += (uint32_t)n;
    }
    return 0;
}

static void say(int fd, const char *text)
{ (void)write_all(fd, text, (uint32_t)text_length(text)); }

static int equal_fold(const char *left, const char *right)
{
    for (;;) {
        char a = *left++, b = *right++;
        if (a >= 'a' && a <= 'z') a -= 'a' - 'A';
        if (b >= 'a' && b <= 'z') b -= 'a' - 'A';
        if (a != b) return 0;
        if (!a) return 1;
    }
}

static int make_executable_name(const char *input, char output[13])
{
    unsigned base = 0, ext = 0, dotted = 0, out = 0;
    for (; *input; ++input) {
        char ch = *input;
        if (ch == '.') {
            if (dotted || !base) return 0;
            dotted = 1; output[out++] = '.'; continue;
        }
        if (ch >= 'a' && ch <= 'z') ch -= 'a' - 'A';
        if (!((ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') ||
              ch == '_' || ch == '-')) return 0;
        if ((!dotted && base == 8) || (dotted && ext == 3)) return 0;
        output[out++] = ch;
        if (dotted) ++ext; else ++base;
    }
    if (!base) return 0;
    if (!dotted) {
        output[out++] = '.'; output[out++] = 'E';
        output[out++] = 'X'; output[out++] = 'E';
    } else if (!ext) return 0;
    output[out] = 0;
    return 1;
}

static int run_cat(int argc, char **argv)
{
    if (argc != 2) { say(2, "cat: usage: cat FILE\n"); return 2; }
    int32_t fd = open_file(argv[1]);
    if (fd < 0) { say(2, "cat: cannot open file\n"); return 3; }
    uint8_t buffer[256];
    for (;;) {
        int32_t n = read_fd(fd, buffer, sizeof(buffer));
        if (n < 0) { say(2, "cat: input/output error\n"); close_file(fd); return 4; }
        if (!n) break;
        if (write_all(1, buffer, (uint32_t)n)) { close_file(fd); return 5; }
    }
    return close_file(fd) < 0 ? 6 : 0;
}

static int run_echo(int argc, char **argv)
{
    for (int i = 1; i < argc; ++i) {
        if (i > 1 && write_all(1, " ", 1)) return 2;
        if (write_all(1, argv[i], (uint32_t)text_length(argv[i]))) return 2;
    }
    return write_all(1, "\n", 1) ? 2 : 0;
}

static int run_argtest(int argc, char **argv)
{
    if (argc != 3 || !argv[0] || !argv[1] || !argv[2] || argv[3] ||
        !equal_fold(argv[1], "ONE") || !equal_fold(argv[2], "TWO")) {
        say(2, "argtest: bad initial stack\n"); return 2;
    }
    say(1, "ARGUMENT STACK OK\n");
    return 0;
}

static int run_shell(void)
{
    char line[LINE_MAX + 1], *args[MAX_ARGC];
    for (;;) {
        unsigned length = 0, overflow = 0;
        say(2, "# ");
        for (;;) {
            char ch;
            int32_t n = read_fd(0, &ch, 1);
            if (n != 1) { say(2, "\nshell: input/output error\n"); return 2; }
            if (ch == '\n') { say(2, "\n"); break; }
            if (ch == '\b') {
                if (!overflow && length) { --length; say(2, "\b"); }
                continue;
            }
            if (overflow) continue;
            if (length == LINE_MAX) { overflow = 1; continue; }
            line[length++] = ch;
            write_all(2, &ch, 1);
        }
        if (overflow) { say(2, "shell: line too long\n"); continue; }
        line[length] = 0;
        unsigned argc = 0, bad_token = 0, pipe = 0;
        char *p = line;
        while (*p) {
            while (*p == ' ') ++p;
            if (!*p) break;
            if (argc == MAX_ARGC) { bad_token = ERR_E2BIG; break; }
            args[argc++] = p;
            unsigned token = 0;
            while (*p && *p != ' ') {
                if (*p == '|' || *p == '\'' || *p == '"' ||
                    *p == '\\' || *p == '\t' || *p == ';' ||
                    *p == '&' || *p == '<' || *p == '>')
                    pipe = 1;
                if (++token > MAX_ARG_LEN) bad_token = ERR_ENAMETOOLONG;
                ++p;
            }
            if (*p) *p++ = 0;
            if (bad_token) break;
        }
        if (!argc) continue;
        if (pipe) { say(2, "shell: syntax is not supported\n"); continue; }
        if (bad_token == ERR_E2BIG) { say(2, "shell: too many arguments\n"); continue; }
        if (bad_token) { say(2, "shell: argument too long\n"); continue; }
        if (equal_fold(args[0], "EXIT")) return 0;
        char path[13];
        if (!make_executable_name(args[0], path)) {
            say(2, "shell: invalid command name\n"); continue;
        }
        int32_t pid = spawn_file(path, args, argc);
        if (pid < 0) {
            if (pid == -ERR_ENOENT) say(2, "shell: command not found\n");
            else if (pid == -ERR_ENOEXEC) say(2, "shell: invalid executable\n");
            else say(2, "shell: spawn failed\n");
            continue;
        }
        uint32_t status;
        if (wait_pid(pid, &status) != pid) {
            say(2, "shell: wait failed\n"); continue;
        }
        if (status) say(2, "shell: child failed\n");
    }
}

int day23_main(int argc, char **argv)
{
    if (argc < 1 || !argv || !argv[0]) return 0x7f;
    if (equal_fold(argv[0], "SHELL.EXE")) return run_shell();
    if (equal_fold(argv[0], "CAT") || equal_fold(argv[0], "CAT.EXE"))
        return run_cat(argc, argv);
    if (equal_fold(argv[0], "ECHO") || equal_fold(argv[0], "ECHO.EXE"))
        return run_echo(argc, argv);
    if (equal_fold(argv[0], "ARGTEST") || equal_fold(argv[0], "ARGTEST.EXE"))
        return run_argtest(argc, argv);
    if (equal_fold(argv[0], "FAULT") || equal_fold(argv[0], "FAULT.EXE")) {
        *(volatile uint32_t *)0x1000 = 1;
        return 0;
    }
    say(2, "program: unknown invocation name\n");
    return 0x7e;
}
