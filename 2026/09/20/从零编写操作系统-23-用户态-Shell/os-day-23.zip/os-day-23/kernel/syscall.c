#include "syscall.h"
#include "console.h"
#include "memory.h"
#include "runtime.h"
#include "task.h"
#include "timer.h"
#include "user.h"
#include "file.h"

#define PAGE_MASK 0xfffff000u
#define PAGE_OFFSET 0x00000fffu
#define PAGE_PRESENT 0x001u
#define PAGE_WRITE 0x002u
#define PAGE_USER 0x004u

#define ERR_EFAULT 14
#define ERR_EINVAL 22
#define ERR_ENAMETOOLONG 36
#define ERR_E2BIG 7
#define ERR_ENOSYS 38

volatile uint32_t syscall_count;
volatile uint32_t syscall_write_count;
volatile uint32_t syscall_yield_count;
volatile uint32_t syscall_error_count;
volatile uint32_t syscall_irq_ticks;
volatile unsigned syscall_wait_for_irq;
volatile uint32_t fd_open_calls, fd_read_calls, fd_write_calls, fd_close_calls;
volatile uint32_t fd_pointer_faults;

static int user_page_ok(uint32_t cr3, uintptr_t address, int write_access,
                        uint32_t *physical)
{
    uint32_t *directory = (uint32_t *)(cr3 & PAGE_MASK);
    uint32_t pde = directory[address >> 22];
    uint32_t required = PAGE_PRESENT | PAGE_USER;
    if ((pde & required) != required || (write_access && !(pde & PAGE_WRITE)))
        return 0;
    uint32_t *table = (uint32_t *)(pde & PAGE_MASK);
    uint32_t pte = table[(address >> 12) & 1023u];
    if ((pte & required) != required || (write_access && !(pte & PAGE_WRITE)))
        return 0;
    if (physical) *physical = (pte & PAGE_MASK) | (address & PAGE_OFFSET);
    return 1;
}

int user_range_ok(uint32_t cr3, uintptr_t address, size_t length,
                  int write_access)
{
    if (!length) return 1;
    if (address < USER_CODE || address >= USER_STACK) return 0;
    if (length > (size_t)(USER_STACK - address)) return 0;
    uintptr_t last = address + length - 1;
    uintptr_t page = address & PAGE_MASK;
    uintptr_t last_page = last & PAGE_MASK;
    for (;;) {
        if (!user_page_ok(cr3, page, write_access, 0)) return 0;
        if (page == last_page) return 1;
        page += PAGE_BYTES;
    }
}

static uint32_t current_cr3(void)
{
    uint32_t cr3;
    __asm__ volatile("mov %%cr3,%0" : "=r"(cr3));
    return cr3;
}

int copy_from_user(void *destination, uintptr_t address, size_t length)
{
    uint32_t cr3 = current_cr3();
    if (!user_range_ok(cr3, address, length, 0)) return 0;
    uint8_t *out = destination;
    while (length) {
        uint32_t physical;
        KASSERT(user_page_ok(cr3, address, 0, &physical));
        size_t chunk = PAGE_BYTES - (address & PAGE_OFFSET);
        if (chunk > length) chunk = length;
        memcpy(out, (const void *)physical, chunk);
        out += chunk;
        address += chunk;
        length -= chunk;
    }
    return 1;
}

int copy_to_user(uintptr_t address, const void *source, size_t length)
{
    uint32_t cr3 = current_cr3();
    if (!user_range_ok(cr3, address, length, 1)) return 0;
    const uint8_t *in = source;
    while (length) {
        uint32_t physical;
        KASSERT(user_page_ok(cr3, address, 1, &physical));
        size_t chunk = PAGE_BYTES - (address & PAGE_OFFSET);
        if (chunk > length) chunk = length;
        memcpy((void *)physical, in, chunk);
        in += chunk;
        address += chunk;
        length -= chunk;
    }
    return 1;
}

static int32_t syscall_write(uintptr_t address, size_t length)
{
    char bytes[SYSCALL_WRITE_MAX];
    if (length > sizeof(bytes)) return -ERR_EINVAL;
    if (!length) return 0;
    if (!copy_from_user(bytes, address, length)) return -ERR_EFAULT;

    uint32_t before = timer_ticks;
    __asm__ volatile("sti" ::: "memory");
    if (syscall_wait_for_irq) {
        while (timer_ticks == before) __asm__ volatile("pause");
        syscall_irq_ticks = timer_ticks - before;
        syscall_wait_for_irq = 0;
    }
    for (size_t i = 0; i < length; ++i) console_putc(bytes[i]);
    __asm__ volatile("cli" ::: "memory");
    ++syscall_write_count;
    return (int32_t)length;
}

static int32_t syscall_spawn(uintptr_t name_address, unsigned io_map)
{
    char name[16];
    for (unsigned i = 0; i < sizeof(name); ++i) {
        if (!copy_from_user(&name[i], name_address + i, 1))
            return -ERR_EFAULT;
        if (!name[i]) return task_spawn_process(name, io_map);
    }
    return -ERR_ENAMETOOLONG;
}

static int32_t syscall_spawn_file(uintptr_t name_address,
                                  uintptr_t argv_address, unsigned argc,
                                  unsigned io_map)
{
    char name[16];
    unsigned terminated = 0;
    for (unsigned i = 0; i < sizeof(name); ++i) {
        if (!copy_from_user(&name[i], name_address + i, 1))
            return -ERR_EFAULT;
        if (!name[i]) { terminated = 1; break; }
    }
    if (!terminated) return -ERR_ENAMETOOLONG;
    if (!argc || argc > PROCESS_ARG_MAX) return -ERR_E2BIG;
    struct process_args args = {.argc=argc};
    for (unsigned i = 0; i < argc; ++i) {
        if (argv_address > UINT32_MAX - i * sizeof(uint32_t))
            return -ERR_EFAULT;
        uint32_t address;
        if (!copy_from_user(&address,
                            argv_address + i * sizeof(uint32_t),
                            sizeof(address)) || !address)
            return -ERR_EFAULT;
        terminated = 0;
        for (unsigned j = 0; j <= PROCESS_ARG_LEN; ++j) {
            if (!copy_from_user(&args.values[i][j], address + j, 1))
                return -ERR_EFAULT;
            if (!args.values[i][j]) { terminated = 1; break; }
        }
        if (!terminated) return -ERR_ENAMETOOLONG;
    }
    return task_spawn_file(name, io_map, &args);
}

static int32_t syscall_wait(int32_t pid, uintptr_t status_address)
{
    if (!user_range_ok(current_cr3(), status_address, sizeof(uint32_t), 1)) {
        task_note_wait_fault();
        return -ERR_EFAULT;
    }
    return task_wait_process(pid, status_address);
}

static int32_t syscall_open(uintptr_t path_address, unsigned flags)
{
    char path[16];
    for (unsigned i = 0; i < sizeof(path); ++i) {
        if (!copy_from_user(&path[i], path_address + i, 1))
            return -ERR_EFAULT;
        if (!path[i]) {
            if (!task_fd_has_free_current()) return -FILE_EMFILE;
            struct open_file *file;
            int result = file_open(path, flags, &file);
            if (result) return result;
            int fd = task_fd_install_current(file);
            if (fd < 0) file_put(file);
            else ++fd_open_calls;
            return fd;
        }
    }
    return -ERR_ENAMETOOLONG;
}

static int32_t syscall_read(int fd, uintptr_t address, uint32_t length)
{
    struct open_file *file = task_fd_acquire_current(fd);
    if (!file) return -FILE_EBADF;
    if (!length) { file_put(file); return 0; }
    if (length > FILE_IO_MAX) { file_put(file); return -ERR_EINVAL; }
    if (!user_range_ok(current_cr3(), address, length, 1)) {
        ++fd_pointer_faults;
        file_put(file);
        return -ERR_EFAULT;
    }
    uint8_t bytes[FILE_IO_MAX];
    int result = file_read(file, bytes, length);
    if (result > 0) KASSERT(copy_to_user(address, bytes, (size_t)result));
    file_put(file);
    if (result >= 0) ++fd_read_calls;
    return result;
}

static int32_t syscall_fd_write(int fd, uintptr_t address, uint32_t length)
{
    struct open_file *file = task_fd_acquire_current(fd);
    if (!file) return -FILE_EBADF;
    if (!length) { file_put(file); return 0; }
    if (length > FILE_IO_MAX) { file_put(file); return -ERR_EINVAL; }
    uint8_t bytes[FILE_IO_MAX];
    if (!copy_from_user(bytes, address, length)) {
        ++fd_pointer_faults;
        file_put(file);
        return -ERR_EFAULT;
    }
    int result = file_write(file, bytes, length);
    file_put(file);
    if (result == (int)length) task_note_write(bytes, length);
    if (result >= 0) ++fd_write_calls;
    return result;
}

static int32_t syscall_close(int fd)
{
    int result = task_fd_close_current(fd);
    if (!result) ++fd_close_calls;
    return result;
}

void syscall_dispatch(struct trap_frame *frame)
{
    KASSERT((frame->cs & 3) == 3 && frame->vector == 128 && frame->error == 0);
    ++syscall_count;
    int32_t result;
    if (frame->eax == SYS_WRITE)
        result = syscall_write(frame->ebx, frame->ecx);
    else if (frame->eax == SYS_YIELD) {
        ++syscall_yield_count;
        task_request_reschedule();
        result = 0;
    } else if (frame->eax == SYS_SPAWN)
        result = syscall_spawn(frame->ebx, frame->ecx);
    else if (frame->eax == SYS_EXIT) {
        task_request_exit(frame->ebx);
        result = 0;
    } else if (frame->eax == SYS_WAIT)
        result = syscall_wait((int32_t)frame->ebx, frame->ecx);
    else if (frame->eax == SYS_OPEN)
        result = syscall_open(frame->ebx, frame->ecx);
    else if (frame->eax == SYS_READ)
        result = syscall_read((int32_t)frame->ebx, frame->ecx, frame->edx);
    else if (frame->eax == SYS_FD_WRITE)
        result = syscall_fd_write((int32_t)frame->ebx, frame->ecx, frame->edx);
    else if (frame->eax == SYS_CLOSE)
        result = syscall_close((int32_t)frame->ebx);
    else if (frame->eax == SYS_SPAWN_FILE)
        result = syscall_spawn_file(frame->ebx, frame->ecx, frame->edx,
                                    frame->esi);
    else
        result = -ERR_ENOSYS;
    if (result < 0) ++syscall_error_count;
    frame->eax = (uint32_t)result;
}
