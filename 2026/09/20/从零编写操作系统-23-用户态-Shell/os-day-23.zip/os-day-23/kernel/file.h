#ifndef FILE_H
#define FILE_H

#include <stdint.h>

#define FD_MAX 8u
#define OPEN_FILE_MAX 7u
#define FILE_IO_MAX 256u

#define FILE_EIO 5
#define FILE_EBADF 9
#define FILE_EINVAL 22
#define FILE_ENFILE 23
#define FILE_EMFILE 24
#define FILE_EROFS 30
#define FILE_ENAMETOOLONG 36
#define FILE_ENOENT 2

struct open_file;

int file_open(const char *path, unsigned flags, struct open_file **result);
int file_open_terminal(int input, struct open_file **result);
int file_get(struct open_file *file);
void file_put(struct open_file *file);
int file_read(struct open_file *file, void *buffer, uint32_t length);
int file_write(struct open_file *file, const void *buffer, uint32_t length);
int file_pread(struct open_file *file, uint32_t offset, void *buffer,
               uint32_t length);
uint32_t file_size(const struct open_file *file);

unsigned file_live_count(void);
unsigned file_total_refs(void);
uint32_t file_offset(const struct open_file *file);

extern volatile uint32_t file_allocations, file_releases, file_peak_live;
extern volatile uint32_t file_reads, file_writes, file_short_reads;

#endif
