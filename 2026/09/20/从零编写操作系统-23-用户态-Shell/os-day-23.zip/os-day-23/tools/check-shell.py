#!/usr/bin/env python3
import hashlib
import os
import shlex
import socket
import subprocess
import time
from pathlib import Path

BUILD = Path("build")
SERIAL = BUILD / "day23-shell-serial.txt"
QEMU_LOG = BUILD / "day23-shell-qemu.txt"
MONITOR = BUILD / "day23-shell-monitor.sock"
INPUT_LOG = BUILD / "day23-shell-input.txt"
SCREEN = BUILD / "day23-shell-screen.png"


def wait_for(predicate, timeout=150):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if predicate():
            return
        time.sleep(0.05)
    raise RuntimeError("timed out waiting for guest output")


def serial_bytes():
    return SERIAL.read_bytes() if SERIAL.exists() else b""


def hmp(sock, command):
    sock.sendall((command + "\n").encode())
    data = b""
    while b"(qemu)" not in data:
        data += sock.recv(8192)
    return data


def key_name(ch):
    if ch == " ":
        return "spc"
    if ch == ".":
        return "dot"
    if ch == "|":
        return "shift-backslash"
    if "a" <= ch <= "z" or "0" <= ch <= "9" or ch == "-":
        return ch
    raise ValueError("unsupported test key: %r" % ch)


def send_line(sock, line, inputs):
    before = serial_bytes().count(b"# ")
    inputs.append(line)
    for ch in line:
        hmp(sock, "sendkey %s 15" % key_name(ch))
        time.sleep(0.025)
    hmp(sock, "sendkey ret 15")
    wait_for(lambda: serial_bytes().count(b"# ") > before)


def fat_files():
    image = (BUILD / "fat16-shell.bin").read_bytes()
    bps = int.from_bytes(image[11:13], "little")
    reserved = int.from_bytes(image[14:16], "little")
    fats = image[16]
    roots = int.from_bytes(image[17:19], "little")
    fat_sectors = int.from_bytes(image[22:24], "little")
    root_start = (reserved + fats * fat_sectors) * bps
    data_sector = reserved + fats * fat_sectors + (roots * 32 + bps - 1) // bps
    fat = image[reserved * bps:(reserved + fat_sectors) * bps]
    result = {}
    for offset in range(root_start, root_start + roots * 32, 32):
        entry = image[offset:offset + 32]
        if entry[0] == 0:
            break
        if entry[0] in (0x05, 0xE5) or entry[11] == 0x0F or entry[11] & 0x18:
            continue
        base = entry[:8].decode().rstrip()
        ext = entry[8:11].decode().rstrip()
        name = base + (("." + ext) if ext else "")
        cluster = int.from_bytes(entry[26:28], "little")
        size = int.from_bytes(entry[28:32], "little")
        data = bytearray()
        chain = []
        while len(data) < size:
            chain.append(cluster)
            start = (data_sector + cluster - 2) * bps
            data += image[start:start + bps]
            cluster = int.from_bytes(fat[cluster * 2:cluster * 2 + 2], "little")
        result[name] = (bytes(data[:size]), chain)
    return result


def run_gdb_evidence(command):
    serial = BUILD / "day23-shell-gdb-serial.txt"
    qlog = BUILD / "day23-shell-gdb-qemu.txt"
    for path in (MONITOR, serial, qlog):
        try:
            path.unlink()
        except FileNotFoundError:
            pass
    with qlog.open("wb") as output:
        proc = subprocess.Popen(command + [
            "-snapshot", "-drive", "file=build/mbr-shell.img,format=raw,if=ide",
            "-display", "none", "-serial", "file:" + str(serial),
            "-monitor", "none", "-S", "-gdb", "tcp:127.0.0.1:1264"
        ], stdout=output, stderr=subprocess.STDOUT)
    try:
        time.sleep(1)
        gdb = os.environ.get("GDB", "gdb-multiarch")
        script = [
            gdb, "-q", "-nx", "-batch",
            "-ex", "set architecture i386",
            "-ex", "set tcp connect-timeout 5",
            "-ex", "set tcp auto-retry on",
            "-ex", "file build/kernel-shell.elf",
            "-ex", "target remote 127.0.0.1:1264",
            "-ex", "hbreak disk_spawn_published",
            "-ex", "continue",
            "-ex", "python v=lambda e:int(gdb.parse_and_eval(e)); sp=v('tasks[1].user.stack_top'); base=v('tasks[1].user.pages[5]'); p=base+sp-0x7ffff000; av=v('*(unsigned*)(%d+4)'%p); print('STATE sp=%x argc=%d argv0=%x reads=%d lba=%d live=%d refs=%d'%(sp,v('*(unsigned*)%d'%p),av,v('disk_exec_reads'),v('fat_last_lba'),v('file_live_count()'),v('file_total_refs()'))); assert sp%16==0 and v('*(unsigned*)%d'%p)==1; assert 0x7ffff000<=av<0x80000000; assert v('disk_exec_reads')>=3; assert v('file_live_count()')==2 and v('file_total_refs()')==6; print('PASS: FAT source, non-embedded ELF, argc/argv stack and staged descriptor refs verified')",
            "-ex", "disconnect"
        ]
        result = subprocess.run(script, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=150,
                                check=True)
        (BUILD / "day23-shell-gdb.txt").write_bytes(result.stdout)
        if b"PASS: FAT source" not in result.stdout:
            raise RuntimeError("GDB evidence assertions failed")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()


def main():
    files = fat_files()
    good = (BUILD / "day23-user.elf").read_bytes()
    for name in ("SHELL.EXE", "CAT.EXE", "ECHO.EXE", "ARGTEST.EXE", "FAULT.EXE"):
        assert files[name][0] == good
    assert files["BADMAGIC.EXE"][0][0] == 0 and files["BADMAGIC.EXE"][0][1:] == good[1:]
    chain = files["SHELL.EXE"][1]
    assert len(chain) > 1 and any(chain[i + 1] != chain[i] + 1 for i in range(len(chain) - 1))

    qemu = os.environ.get("QEMU", "qemu-system-i386")
    common = shlex.split(os.environ["QEMU_COMMON"])
    command = [qemu] + common
    run_gdb_evidence(command)
    for path in (SERIAL, QEMU_LOG, MONITOR, INPUT_LOG, SCREEN):
        try:
            path.unlink()
        except FileNotFoundError:
            pass
    with QEMU_LOG.open("wb") as output:
        proc = subprocess.Popen(command + [
            "-snapshot", "-drive", "file=build/mbr-shell.img,format=raw,if=ide",
            "-display", "none", "-serial", "file:" + str(SERIAL),
            "-monitor", "unix:" + str(MONITOR) + ",server=on,wait=off"
        ], stdout=output, stderr=subprocess.STDOUT)
    inputs = []
    try:
        wait_for(MONITOR.exists, 10)
        monitor = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        monitor.connect(str(MONITOR))
        monitor.settimeout(5)
        monitor.recv(8192)
        wait_for(lambda: serial_bytes().endswith(b"# "))
        for line in (
            "", "   ", "echo hello", "echo hello world",
            "cat readme.txt", "nosuch", "echo recovered",
            "argtest one two", "badmagic", "echo afterbad",
            "fault", "echo afterfault", "echo 1 2 3 4 5 6 7",
            "echo 1 2 3 4 5 6 7 8", "echo " + "a" * 31,
            "echo " + "b" * 32, "echo x | wc", "echo " + "z" * 91,
            "echo final"
        ):
            send_line(monitor, line, inputs)
        hmp(monitor, "screendump %s -f png" % SCREEN)
        inputs.append("exit")
        for ch in "exit":
            hmp(monitor, "sendkey %s 15" % ch)
            time.sleep(0.025)
        hmp(monitor, "sendkey ret 15")
        wait_for(lambda: b"SHELL OK" in serial_bytes())
        monitor.close()
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
    INPUT_LOG.write_text("\n".join(inputs) + "\n", encoding="utf-8")
    serial = serial_bytes().replace(b"\r\n", b"\n")
    assert b"# echo hello\nhello\n" in serial
    assert b"# echo hello world\nhello world\n" in serial
    marker = b"# cat readme.txt\n"
    start = serial.index(marker) + len(marker)
    readme = Path("disk/README.TXT").read_bytes()
    assert serial[start:start + len(readme)] == readme
    assert hashlib.sha256(readme).hexdigest() == "25fc6f4ce8493714e7056d2896c47e6a9f4c4db91a4b860dd474035542804798"
    assert b"shell: command not found\n" in serial
    assert b"# echo recovered\nrecovered\n" in serial
    assert b"ARGUMENT STACK OK\n" in serial
    assert b"shell: invalid executable\n" in serial
    assert b"# echo afterbad\nafterbad\n" in serial
    assert b"shell: child failed\n# echo afterfault\nafterfault\n" in serial
    assert b"1 2 3 4 5 6 7\n" in serial
    assert b"shell: too many arguments\n" in serial
    assert (b"a" * 31 + b"\n") in serial
    assert b"shell: argument too long\n" in serial
    assert b"shell: syntax is not supported\n" in serial
    assert b"shell: line too long\n" in serial
    assert b"# echo final\nfinal\n" in serial
    assert b"SHELL OK" in serial and b"PANIC" not in serial
    assert SCREEN.exists() and SCREEN.stat().st_size > 1000
    print("PASS: Day23 Shell normal, parser boundaries, bad ELF, child fault and recovery")


if __name__ == "__main__":
    main()
