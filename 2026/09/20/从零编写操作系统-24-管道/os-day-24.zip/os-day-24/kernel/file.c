#include <stddef.h>
#include <stdint.h>
#include "console.h"
#include "fat.h"
#include "file.h"
#include "keyboard.h"
#include "runtime.h"
#include "task.h"

enum file_type {
    FILE_FREE, FILE_FAT, FILE_TERMINAL_IN, FILE_TERMINAL_OUT,
    FILE_PIPE_READ, FILE_PIPE_WRITE
};

struct pipe {
    unsigned used, read_at, write_at;
    unsigned readers, writers;
    struct wait_queue read_waiters, write_waiters;
    uint8_t bytes[PIPE_CAPACITY];
};

struct open_file {
    enum file_type type;
    uint32_t refs;
    uint32_t offset;
    unsigned readable, writable;
    struct fat_file fat;
    struct pipe *pipe;
};

static struct open_file files[OPEN_FILE_MAX];
static struct pipe pipe_slot;
volatile uint32_t file_allocations, file_releases, file_peak_live;
volatile uint32_t file_reads, file_writes, file_short_reads;
volatile uint32_t pipe_creates, pipe_releases;
volatile uint32_t pipe_read_blocks, pipe_write_blocks;
volatile uint32_t pipe_eofs, pipe_broken_writes;
volatile uint32_t pipe_bytes_read, pipe_bytes_written;

static struct open_file *file_alloc(enum file_type type, unsigned readable,
                                    unsigned writable)
{
    uint32_t flags = irq_save();
    for (unsigned i = 0; i < OPEN_FILE_MAX; ++i) {
        if (files[i].type != FILE_FREE || files[i].refs) continue;
        files[i] = (struct open_file){.type=type, .refs=1,
                                     .readable=readable, .writable=writable};
        ++file_allocations;
        unsigned live = file_live_count();
        if (live > file_peak_live) file_peak_live = live;
        irq_restore(flags);
        return &files[i];
    }
    irq_restore(flags);
    return 0;
}

static int fat_error(int error)
{
    if (error == FAT_ENOENT) return -FILE_ENOENT;
    if (error == FAT_ENAME) return -FILE_ENAMETOOLONG;
    if (error == FAT_EINVAL) return -FILE_EINVAL;
    return -FILE_EIO;
}

int file_open(const char *path, unsigned flags, struct open_file **result)
{
    if (!result || flags) return -FILE_EINVAL;
    struct fat_file fat;
    preempt_disable();
    __asm__ volatile("sti" ::: "memory");
    int opened = fat_open(path, &fat);
    __asm__ volatile("cli" ::: "memory");
    preempt_enable();
    if (opened != FAT_OK) return fat_error(opened);
    struct open_file *file = file_alloc(FILE_FAT, 1, 0);
    if (!file) return -FILE_ENFILE;
    file->fat = fat;
    *result = file;
    return 0;
}

int file_open_terminal(int input, struct open_file **result)
{
    if (!result) return -FILE_EINVAL;
    struct open_file *file = file_alloc(input ? FILE_TERMINAL_IN :
                                        FILE_TERMINAL_OUT, input, !input);
    if (!file) return -FILE_ENFILE;
    *result = file;
    return 0;
}

int file_pipe_create(struct open_file **read_end,
                     struct open_file **write_end)
{
    if (!read_end || !write_end) return -FILE_EINVAL;
    uint32_t flags = irq_save();
    if (pipe_slot.readers || pipe_slot.writers) {
        irq_restore(flags);
        return -FILE_ENFILE;
    }
    int slots[2] = {-1, -1};
    for (unsigned i = 0; i < OPEN_FILE_MAX; ++i) {
        if (files[i].type != FILE_FREE || files[i].refs) continue;
        if (slots[0] < 0) slots[0] = (int)i;
        else { slots[1] = (int)i; break; }
    }
    if (slots[1] < 0) { irq_restore(flags); return -FILE_ENFILE; }
    pipe_slot = (struct pipe){.readers=1, .writers=1};
    files[slots[0]] = (struct open_file){
        .type=FILE_PIPE_READ, .refs=1, .readable=1, .pipe=&pipe_slot
    };
    files[slots[1]] = (struct open_file){
        .type=FILE_PIPE_WRITE, .refs=1, .writable=1, .pipe=&pipe_slot
    };
    file_allocations += 2;
    unsigned live = file_live_count();
    if (live > file_peak_live) file_peak_live = live;
    ++pipe_creates;
    *read_end = &files[slots[0]];
    *write_end = &files[slots[1]];
    irq_restore(flags);
    return 0;
}

int file_get(struct open_file *file)
{
    uint32_t flags = irq_save();
    if (!file || file < files || file >= files + OPEN_FILE_MAX ||
        file->type == FILE_FREE || !file->refs || file->refs == UINT32_MAX) {
        irq_restore(flags);
        return 0;
    }
    ++file->refs;
    irq_restore(flags);
    return 1;
}

void file_put(struct open_file *file)
{
    uint32_t flags = irq_save();
    KASSERT(file && file >= files && file < files + OPEN_FILE_MAX &&
            file->type != FILE_FREE && file->refs);
    if (--file->refs == 0) {
        struct pipe *pipe = file->pipe;
        enum file_type type = file->type;
        *file = (struct open_file){0};
        ++file_releases;
        if (type == FILE_PIPE_READ) {
            KASSERT(pipe && pipe->readers == 1);
            pipe->readers = 0;
            (void)wake_all_locked(&pipe->write_waiters);
        } else if (type == FILE_PIPE_WRITE) {
            KASSERT(pipe && pipe->writers == 1);
            pipe->writers = 0;
            (void)wake_all_locked(&pipe->read_waiters);
        }
        if (pipe && !pipe->readers && !pipe->writers) {
            KASSERT(!pipe->read_waiters.mask && !pipe->write_waiters.mask);
            *pipe = (struct pipe){0};
            ++pipe_releases;
        }
    }
    irq_restore(flags);
}

int file_read(struct open_file *file, void *buffer, uint32_t length)
{
    if (!file || (!buffer && length) || length > FILE_IO_MAX)
        return -FILE_EINVAL;
    if (!file->readable) return -FILE_EBADF;
    if (!length) return 0;
    int result;
    if (file->type == FILE_FAT) {
        preempt_disable();
        __asm__ volatile("sti" ::: "memory");
        result = fat_read_at(&file->fat, file->offset, buffer, length);
        __asm__ volatile("cli" ::: "memory");
        if (result > 0) file->offset += (uint32_t)result;
        preempt_enable();
        if (result < 0) return fat_error(result);
        if ((uint32_t)result < length) ++file_short_reads;
    } else if (file->type == FILE_TERMINAL_IN) {
        int byte = keyboard_read_char();
        if (byte < 0) return -FILE_EIO;
        *(uint8_t *)buffer = (uint8_t)byte;
        result = 1;
        ++file_short_reads;
    } else if (file->type == FILE_PIPE_READ) {
        struct pipe *pipe = file->pipe;
        uint32_t flags = irq_save();
        while (!pipe->used && pipe->writers) {
            ++pipe_read_blocks;
            task_block_locked(&pipe->read_waiters);
        }
        if (!pipe->used) {
            ++pipe_eofs;
            irq_restore(flags);
            result = 0;
        } else {
            uint32_t count = length;
            if (count > pipe->used) count = pipe->used;
            for (uint32_t i = 0; i < count; ++i) {
                ((uint8_t *)buffer)[i] = pipe->bytes[pipe->read_at];
                pipe->read_at = (pipe->read_at + 1) % PIPE_CAPACITY;
            }
            pipe->used -= count;
            pipe_bytes_read += count;
            (void)wake_one_locked(&pipe->write_waiters);
            irq_restore(flags);
            result = (int)count;
            if (count < length) ++file_short_reads;
        }
    } else {
        return -FILE_EBADF;
    }
    ++file_reads;
    return result;
}

int file_write(struct open_file *file, const void *buffer, uint32_t length)
{
    if (!file || (!buffer && length) || length > FILE_IO_MAX)
        return -FILE_EINVAL;
    if (file->type == FILE_FAT) return -FILE_EROFS;
    if (!file->writable) return -FILE_EBADF;
    const uint8_t *bytes = buffer;
    if (file->type == FILE_TERMINAL_OUT) {
        for (uint32_t i = 0; i < length; ++i) console_putc((char)bytes[i]);
    } else if (file->type == FILE_PIPE_WRITE) {
        struct pipe *pipe = file->pipe;
        uint32_t flags = irq_save();
        while (pipe->used == PIPE_CAPACITY && pipe->readers) {
            ++pipe_write_blocks;
            task_block_locked(&pipe->write_waiters);
        }
        if (!pipe->readers) {
            ++pipe_broken_writes;
            irq_restore(flags);
            return -FILE_EPIPE;
        }
        uint32_t count = length;
        if (count > PIPE_CAPACITY - pipe->used)
            count = PIPE_CAPACITY - pipe->used;
        for (uint32_t i = 0; i < count; ++i) {
            pipe->bytes[pipe->write_at] = bytes[i];
            pipe->write_at = (pipe->write_at + 1) % PIPE_CAPACITY;
        }
        pipe->used += count;
        pipe_bytes_written += count;
        (void)wake_one_locked(&pipe->read_waiters);
        irq_restore(flags);
        length = count;
    } else {
        return -FILE_EBADF;
    }
    ++file_writes;
    return (int)length;
}

int file_pread(struct open_file *file, uint32_t offset, void *buffer,
               uint32_t length)
{
    if (!file || file->type != FILE_FAT || (!buffer && length))
        return -FILE_EINVAL;
    preempt_disable();
    __asm__ volatile("sti" ::: "memory");
    int result = fat_read_at(&file->fat, offset, buffer, length);
    __asm__ volatile("cli" ::: "memory");
    preempt_enable();
    return result < 0 ? fat_error(result) : result;
}

uint32_t file_size(const struct open_file *file)
{ return file && file->type == FILE_FAT ? file->fat.size : 0; }

unsigned file_live_count(void)
{
    unsigned count = 0;
    for (unsigned i = 0; i < OPEN_FILE_MAX; ++i)
        if (files[i].type != FILE_FREE) ++count;
    return count;
}

unsigned file_total_refs(void)
{
    unsigned count = 0;
    for (unsigned i = 0; i < OPEN_FILE_MAX; ++i) count += files[i].refs;
    return count;
}

uint32_t file_offset(const struct open_file *file)
{ return file ? file->offset : 0; }

unsigned file_pipe_live_count(void)
{ return pipe_slot.readers || pipe_slot.writers; }
