bits 32
section .text
global enter_user
enter_user:
    cli
    mov ecx, [esp+4]
    mov edx, [esp+8]
    mov ax, 0x23
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    push dword 0x23
    push edx
    push dword 0x202
    push dword 0x1b
    push ecx
    iretd

section .rodata
global user_blob_start, user_blob_end, user_write_fault, user_cli_fault, user_out_fault, user_bad_gate_fault
user_blob_start:
    mov eax, [0x40001004]
    cmp eax, 10
    je user_syscall_test
    cmp eax, 11
    je user_syscall_counter
    cmp eax, 12
    je user_bad_gate
user_blob_loop:
    inc dword [0x40001000]
    cmp dword [0x40001000], 200000
    jb user_blob_loop
    cmp dword [0x4000100c], 0
    je user_blob_loop
    cmp dword [0x40001014], 0
    je user_blob_loop
    mov dword [0x40001008], 1
    mov eax, [0x40001004]
    cmp eax, 1
    je user_blob_write
    cmp eax, 2
    je user_blob_cli
    cmp eax, 3
    je user_blob_out
    jmp user_blob_loop
user_blob_write:
    mov edi, [0x40001010]
user_write_fault:
    mov dword [edi], 0xbadbad00
    jmp user_blob_loop
user_blob_cli:
user_cli_fault:
    cli
    jmp user_blob_loop
user_blob_out:
    mov al, 0x55
user_out_fault:
    out 0x80, al
    jmp user_blob_loop

user_syscall_counter:
    inc dword [0x40001000]
    jmp user_syscall_counter

user_bad_gate:
user_bad_gate_fault:
    int 0x20
    jmp user_bad_gate

user_syscall_test:
    mov eax, 1
    mov ebx, 0x40001100
    mov ecx, 19
    mov edx, 0x22334455
    mov esi, 0x66778899
    mov edi, 0xaabbccdd
    mov ebp, 0x13579bdf
    std
    stc
    pushfd
    pop dword [0x40001060]
    int 0x80
user_syscall_return:
    pushfd
    pop dword [0x40001064]
    cld
    mov [0x40001020], eax
    mov dword [0x40001050], 1
    cmp ebx, 0x40001100
    jne user_register_bad
    cmp ecx, 19
    jne user_register_bad
    cmp edx, 0x22334455
    jne user_register_bad
    cmp esi, 0x66778899
    jne user_register_bad
    cmp edi, 0xaabbccdd
    jne user_register_bad
    cmp ebp, 0x13579bdf
    jne user_register_bad
    mov eax, [0x40001060]
    xor eax, [0x40001064]
    test eax, 0x601
    jnz user_register_bad
    jmp user_register_done
user_register_bad:
    mov dword [0x40001050], 0
user_register_done:

    mov eax, 2
    int 0x80
    mov [0x40001024], eax

    mov eax, 99
    int 0x80
    mov [0x40001028], eax

    mov eax, 1
    mov ebx, 0xffffffff
    xor ecx, ecx
    int 0x80
    mov [0x4000102c], eax

    mov eax, 1
    mov ebx, 0x40001100
    mov ecx, 257
    int 0x80
    mov [0x40001030], eax

    mov eax, 1
    mov ebx, 0x00001000
    mov ecx, 4
    int 0x80
    mov [0x40001034], eax

    mov eax, 1
    mov ebx, 0xfffffff0
    mov ecx, 32
    int 0x80
    mov [0x40001038], eax

    mov eax, 1
    mov ebx, 0x7ffffff8
    mov ecx, 16
    int 0x80
    mov [0x4000103c], eax

    mov eax, 1
    mov ebx, 0x40001ff8
    mov ecx, 16
    int 0x80
    mov [0x40001040], eax

    mov eax, 1
    mov ebx, 0x40003000
    mov ecx, 4
    int 0x80
    mov [0x40001044], eax

    mov eax, 1
    mov ebx, 0x40000000 + user_readonly_text - user_blob_start
    mov ecx, user_readonly_text_end - user_readonly_text
    int 0x80
    mov [0x40001048], eax

    mov eax, 1
    mov ebx, 0x40004ff8
    mov ecx, 15
    int 0x80
    mov [0x4000104c], eax

    mov dword [0x40001008], 1
user_syscall_done:
    inc dword [0x40001000]
    jmp user_syscall_done

user_readonly_text:
    db 'D17 READONLY OK', 10
user_readonly_text_end:
user_blob_end:
