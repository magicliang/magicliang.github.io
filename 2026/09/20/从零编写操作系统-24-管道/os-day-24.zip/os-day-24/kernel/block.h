#ifndef BLOCK_H
#define BLOCK_H

#include <stdint.h>

enum block_error {
    BLOCK_OK = 0,
    BLOCK_EINVAL = -1,
    BLOCK_ENODEV = -2,
    BLOCK_ENOTSUP = -3,
    BLOCK_ERANGE = -4,
    BLOCK_ETIMEDOUT = -5,
    BLOCK_EIO = -6,
    BLOCK_ECHANNEL = -7,
    BLOCK_EBUSY = -8,
};

int block_read_sector(uint32_t lba, void *buffer);
uint32_t block_sector_count(void);
void block_demo(unsigned mode);

extern volatile int32_t block_result, block_followup_result;
extern volatile uint32_t block_capacity, block_reads, block_range_rejects;
extern volatile uint32_t block_hash_first, block_hash_middle, block_hash_last;
extern volatile uint32_t block_expected_middle, block_expected_last;
extern volatile uint32_t block_last_lba, block_last_status, block_last_error;
extern volatile uint32_t block_last_stage, block_last_polls, block_tick_delta;
extern volatile uint32_t block_channel_failed, block_passed;

#endif
