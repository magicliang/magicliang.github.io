bits 32
section .rodata
align 4
global day18_elf_start, day18_elf_end
day18_elf_start:
    incbin "build/day18-user.elf"
day18_elf_end:
