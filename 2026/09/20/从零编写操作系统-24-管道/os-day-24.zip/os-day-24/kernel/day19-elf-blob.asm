bits 32
section .rodata
align 4
global day19_elf_start, day19_elf_end
day19_elf_start:
    incbin "build/day19-user.elf"
day19_elf_end:
