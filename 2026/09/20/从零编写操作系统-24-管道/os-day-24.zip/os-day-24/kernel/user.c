#include "user.h"
#include "memory.h"
#include "runtime.h"
#include "console.h"
#include <stddef.h>
struct tss32 { uint32_t words[25]; uint16_t trap, iomap; } __attribute__((packed));
static struct tss32 user_tss;
static uint64_t user_gdt[6];
static struct { uint16_t limit; uint32_t base; } __attribute__((packed)) user_gdtr;
uint32_t user_kernel_cr3;
volatile unsigned user_fail_after = 7;
extern char __stack_top, user_blob_start, user_blob_end;
_Static_assert(sizeof(struct tss32) == 104 && offsetof(struct tss32, iomap) == 102, "32-bit TSS layout");
void user_init(void)
{
    __asm__ volatile("mov %%cr3,%0" : "=r"(user_kernel_cr3));
    user_gdt[1] = 0x00cf9a000000ffffull;
    user_gdt[2] = 0x00cf92000000ffffull;
    user_gdt[3] = 0x00cffa000000ffffull;
    user_gdt[4] = 0x00cff2000000ffffull;
    uint32_t base = (uint32_t)&user_tss;
    user_gdt[5] = 103ull | ((uint64_t)(base & 0xffffff) << 16) |
                  (0x89ull << 40) | ((uint64_t)(base >> 24) << 56);
    user_tss.words[1] = (uint32_t)&__stack_top;
    user_tss.words[2] = 0x10;
    user_tss.iomap = sizeof(user_tss); /* Beyond limit: no user I/O bitmap permission. */
    user_gdtr.limit = sizeof(user_gdt) - 1;
    user_gdtr.base = (uint32_t)user_gdt;
    __asm__ volatile("lgdt %0; ltr %1" : : "m"(user_gdtr), "r"((uint16_t)0x28) : "memory");
}
void user_switch(uint32_t pd, uint32_t stack_top)
{
    if (!user_kernel_cr3) return; /* Earlier demonstrations retain their CR3. */
    user_tss.words[1] = stack_top > PAGE_BYTES ? stack_top : (uint32_t)&__stack_top;
    if (!pd) pd = user_kernel_cr3;
    __asm__ volatile("mov %0,%%cr3" : : "r"(pd) : "memory");
}
void user_space_destroy(struct user_space *space)
{
    uint32_t cr3;
    __asm__ volatile("mov %%cr3,%0" : "=r"(cr3));
    KASSERT(!space->pages[0] || cr3 != space->pages[0]);
    for (unsigned i = 0; i < USER_SPACE_PAGES; ++i) {
        if (space->pages[i]) KASSERT(page_free(space->pages[i]));
        space->pages[i] = 0;
    }
    space->entry = space->stack_top = 0;
    space->page_count = space->kind = 0;
}
int user_space_create(struct user_space *space, unsigned mode, uint32_t sentinel)
{
    *space = (struct user_space){0};
    for (unsigned i = 0; i < 6; ++i) {
        if (i == user_fail_after || !(space->pages[i] = page_alloc())) {
            user_space_destroy(space);
            return 0;
        }
        memset((void *)space->pages[i], 0, PAGE_BYTES);
    }
    uint32_t *pd = (uint32_t *)space->pages[0];
    memcpy(pd, (void *)user_kernel_cr3, 16 * sizeof(uint32_t));
    /* The earlier D11 alias PDE 256 is deliberately not inherited. */
    pd[USER_CODE >> 22] = space->pages[1] | 7;
    pd[(USER_STACK - PAGE_BYTES) >> 22] = space->pages[2] | 7;
    uint32_t *code_pt = (uint32_t *)space->pages[1];
    uint32_t *stack_pt = (uint32_t *)space->pages[2];
    code_pt[0] = space->pages[3] | 5; /* Present + user; read-only. */
    code_pt[1] = space->pages[4] | 7;
    stack_pt[1023] = space->pages[5] | 7;
    size_t bytes = (uintptr_t)&user_blob_end - (uintptr_t)&user_blob_start;
    KASSERT(bytes <= PAGE_BYTES);
    memcpy((void *)space->pages[3], &user_blob_start, bytes);
    uint32_t *data = (uint32_t *)space->pages[4];
    data[1] = mode;
    data[3] = 1; /* Host may temporarily extend observation; default boot finishes. */
    data[4] = sentinel;
    space->entry = USER_CODE;
    space->stack_top = USER_STACK;
    space->page_count = 6;
    space->kind = USER_SPACE_BLOB;
    return 1;
}

int user_space_physical(const struct user_space *space, uint32_t address,
                        int write_access, uint32_t *physical)
{
    if (!space || !space->pages[0]) return 0;
    uint32_t pde = ((uint32_t *)space->pages[0])[address >> 22];
    uint32_t required = 5u | (write_access ? 2u : 0u);
    if ((pde & required) != required) return 0;
    uint32_t pte = ((uint32_t *)(pde & 0xfffff000u))[(address >> 12) & 1023u];
    if ((pte & required) != required) return 0;
    if (physical) *physical = (pte & 0xfffff000u) | (address & 0xfffu);
    return 1;
}

int user_space_build_stack(struct user_space *space,
                           const struct process_args *args)
{
    if (!space || !args || !args->argc || args->argc > PROCESS_ARG_MAX ||
        !space->pages[5])
        return 0;
    uint32_t cursor = USER_STACK;
    uint32_t pointers[PROCESS_ARG_MAX];
    for (unsigned i = args->argc; i > 0; --i) {
        unsigned length = 0;
        while (length <= PROCESS_ARG_LEN && args->values[i - 1][length])
            ++length;
        if (length > PROCESS_ARG_LEN || cursor < length + 1u)
            return 0;
        cursor -= length + 1u;
        if (cursor < USER_STACK - PAGE_BYTES) return 0;
        memcpy((void *)(space->pages[5] + cursor - (USER_STACK - PAGE_BYTES)),
               args->values[i - 1], length + 1u);
        pointers[i - 1] = cursor;
    }
    uint32_t vector_bytes = (args->argc + 1u) * sizeof(uint32_t);
    uint32_t frame_bytes = vector_bytes + sizeof(uint32_t);
    if (cursor < USER_STACK - PAGE_BYTES + frame_bytes)
        return 0;
    cursor = (cursor - frame_bytes) & ~15u;
    if (cursor < USER_STACK - PAGE_BYTES) return 0;
    uint32_t vector_address = cursor + sizeof(uint32_t);
    uint32_t *vector = (uint32_t *)(space->pages[5] + vector_address -
                                    (USER_STACK - PAGE_BYTES));
    for (unsigned i = 0; i < args->argc; ++i) vector[i] = pointers[i];
    vector[args->argc] = 0;
    *(uint32_t *)(space->pages[5] + cursor - (USER_STACK - PAGE_BYTES)) =
        args->argc;
    space->stack_top = cursor;
    return 1;
}
