#ifndef KEYBOARD_H
#define KEYBOARD_H
#include <stdint.h>
struct key_parser { uint8_t left, right, caps, caps_down, extended, pause; };
int keyboard_parse(struct key_parser *p, uint8_t byte);
void keyboard_irq(void);
int keyboard_start(void);
int keyboard_read_char(void);
void keyboard_loop(void);
extern volatile uint32_t keyboard_blocks;
#endif
