bits 32
section .rodata
align 4
global day22_elf_start, day22_elf_end
day22_elf_start:
    incbin "build/day22-user.elf"
day22_elf_end:
