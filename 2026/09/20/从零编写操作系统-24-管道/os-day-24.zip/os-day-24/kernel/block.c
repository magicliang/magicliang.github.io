#include <stddef.h>
#include <stdint.h>
#include "block.h"
#include "console.h"
#include "runtime.h"
#include "task.h"
#include "timer.h"

#define ATA_DATA 0x1f0
#define ATA_ERROR 0x1f1
#define ATA_SECTOR_COUNT 0x1f2
#define ATA_LBA_LOW 0x1f3
#define ATA_LBA_MID 0x1f4
#define ATA_LBA_HIGH 0x1f5
#define ATA_DEVICE 0x1f6
#define ATA_STATUS 0x1f7
#define ATA_COMMAND 0x1f7
#define ATA_ALT_STATUS 0x3f6
#define ATA_DEVICE_CONTROL 0x3f6

#define ATA_SR_ERR 0x01
#define ATA_SR_DRQ 0x08
#define ATA_SR_DF 0x20
#define ATA_SR_DRDY 0x40
#define ATA_SR_BSY 0x80
#define ATA_CMD_READ_SECTORS 0x20
#define ATA_CMD_IDENTIFY 0xec
#define ATA_LBA28_LIMIT 0x10000000u
#define ATA_TIMEOUT_TICKS 3u
#define ATA_POLL_LIMIT 2000000u
#define BLOCK_PATTERN_MIDDLE 2047u
#ifndef BLOCK_PATTERN_LAST
#define BLOCK_PATTERN_LAST 4095u
#endif
#ifndef BLOCK_EXPECTED_SECTORS
#define BLOCK_EXPECTED_SECTORS 4096u
#endif

enum wait_stage { WAIT_NONE, WAIT_IDLE, WAIT_IDENTIFY, WAIT_DRQ, WAIT_COMPLETE };
enum test_mode { TEST_REAL, TEST_STUCK_BUSY, TEST_MISSING_DRQ };

volatile int32_t block_result, block_followup_result;
volatile uint32_t block_capacity, block_reads, block_range_rejects;
volatile uint32_t block_hash_first, block_hash_middle, block_hash_last;
volatile uint32_t block_expected_middle, block_expected_last;
volatile uint32_t block_last_lba, block_last_status, block_last_error;
volatile uint32_t block_last_stage, block_last_polls, block_tick_delta;
volatile uint32_t block_channel_failed, block_passed;

static unsigned initialized, channel_busy, test_mode, command_issued;
static uint16_t identify_words[256];
static uint8_t sector[512];

static void outb(uint16_t port, uint8_t value)
{ __asm__ volatile("outb %0,%1" : : "a"(value), "Nd"(port) : "memory"); }

static uint8_t inb(uint16_t port)
{
    uint8_t value;
    __asm__ volatile("inb %1,%0" : "=a"(value) : "Nd"(port) : "memory");
    return value;
}

static uint16_t inw(uint16_t port)
{
    uint16_t value;
    __asm__ volatile("inw %1,%0" : "=a"(value) : "Nd"(port) : "memory");
    return value;
}

static uint32_t flags_read(void)
{
    uint32_t flags;
    __asm__ volatile("pushfl; popl %0" : "=r"(flags));
    return flags;
}

static uint8_t alternate_status(void)
{
    if (command_issued && test_mode == TEST_STUCK_BUSY) return ATA_SR_BSY;
    if (command_issued && test_mode == TEST_MISSING_DRQ) return ATA_SR_DRDY;
    return inb(ATA_ALT_STATUS);
}

static void select_delay(void)
{
    for (unsigned i = 0; i < 4; ++i) (void)inb(ATA_ALT_STATUS);
}

static int wait_status(enum wait_stage stage, unsigned require_drq)
{
    uint32_t start = timer_ticks;
    unsigned interrupts_enabled = flags_read() & 0x200u;
    for (uint32_t polls = 1; polls <= ATA_POLL_LIMIT; ++polls) {
        uint8_t status = alternate_status();
        block_last_stage = stage;
        block_last_status = status;
        block_last_polls = polls;
        if (!(status & ATA_SR_BSY)) {
            if (status & (ATA_SR_ERR | ATA_SR_DF)) {
                block_last_error = inb(ATA_ERROR);
                (void)inb(ATA_STATUS); /* Acknowledge any pending device IRQ. */
                return BLOCK_EIO;
            }
            if (!!(status & ATA_SR_DRQ) == !!require_drq) return BLOCK_OK;
        }
        if ((uint32_t)(timer_ticks - start) >= ATA_TIMEOUT_TICKS)
            return BLOCK_ETIMEDOUT;
        if (interrupts_enabled) __asm__ volatile("hlt" : : : "memory");
        else __asm__ volatile("pause" : : : "memory");
    }
    return BLOCK_ETIMEDOUT;
}

static int channel_claim(void)
{
    uint32_t flags = irq_save();
    int result = BLOCK_OK;
    if (block_channel_failed) result = BLOCK_ECHANNEL;
    else if (channel_busy) result = BLOCK_EBUSY;
    else channel_busy = 1;
    irq_restore(flags);
    return result;
}

static void channel_release(int result, unsigned issued)
{
    uint32_t flags = irq_save();
    KASSERT(channel_busy);
    if (issued && result != BLOCK_OK) block_channel_failed = 1;
    channel_busy = 0;
    irq_restore(flags);
}

static int identify(void)
{
    int result = channel_claim();
    if (result != BLOCK_OK) return result;
    command_issued = 0;
    outb(ATA_DEVICE_CONTROL, 0x02); /* Polling driver: mask device IRQ delivery. */
    outb(ATA_DEVICE, 0xa0);
    select_delay();
    result = wait_status(WAIT_IDLE, 0);
    if (result != BLOCK_OK) { channel_release(result, 0); return result; }
    outb(ATA_SECTOR_COUNT, 0);
    outb(ATA_LBA_LOW, 0);
    outb(ATA_LBA_MID, 0);
    outb(ATA_LBA_HIGH, 0);
    outb(ATA_COMMAND, ATA_CMD_IDENTIFY);
    command_issued = 1;
    select_delay();
    uint8_t status = alternate_status();
    if (status == 0 || status == 0xff) {
        (void)inb(ATA_STATUS);
        channel_release(BLOCK_ENODEV, 1);
        return BLOCK_ENODEV;
    }
    result = wait_status(WAIT_IDENTIFY, 1);
    if (result != BLOCK_OK) { channel_release(result, 1); return result; }
    if (inb(ATA_LBA_MID) || inb(ATA_LBA_HIGH)) {
        (void)inb(ATA_STATUS);
        channel_release(BLOCK_ENOTSUP, 1);
        return BLOCK_ENOTSUP;
    }
    for (unsigned i = 0; i < 256; ++i) identify_words[i] = inw(ATA_DATA);
    result = wait_status(WAIT_COMPLETE, 0);
    (void)inb(ATA_STATUS);
    if (result == BLOCK_OK && !(identify_words[49] & (1u << 9)))
        result = BLOCK_ENOTSUP;
    if (result == BLOCK_OK) {
        block_capacity = (uint32_t)identify_words[60] |
                         ((uint32_t)identify_words[61] << 16);
        if (!block_capacity || block_capacity > ATA_LBA28_LIMIT)
            result = BLOCK_ENOTSUP;
    }
    channel_release(result, 1);
    if (result == BLOCK_OK) initialized = 1;
    return result;
}

static int read_raw(uint32_t lba, uint8_t *buffer)
{
    int result = channel_claim();
    if (result != BLOCK_OK) return result;
    command_issued = 0;
    block_last_lba = lba;
    block_last_error = 0;
    outb(ATA_DEVICE, 0xe0 | ((lba >> 24) & 0x0f));
    select_delay();
    result = wait_status(WAIT_IDLE, 0);
    if (result != BLOCK_OK) { channel_release(result, 0); return result; }
    outb(ATA_SECTOR_COUNT, 1);
    outb(ATA_LBA_LOW, lba);
    outb(ATA_LBA_MID, lba >> 8);
    outb(ATA_LBA_HIGH, lba >> 16);
    outb(ATA_COMMAND, ATA_CMD_READ_SECTORS);
    command_issued = 1;
    select_delay();
    result = wait_status(WAIT_DRQ, 1);
    if (result != BLOCK_OK) { channel_release(result, 1); return result; }
    for (unsigned i = 0; i < 256; ++i) {
        uint16_t word = inw(ATA_DATA);
        buffer[i * 2] = word;
        buffer[i * 2 + 1] = word >> 8;
    }
    result = wait_status(WAIT_COMPLETE, 0);
    (void)inb(ATA_STATUS);
    channel_release(result, 1);
    if (result == BLOCK_OK) ++block_reads;
    return result;
}

int block_read_sector(uint32_t lba, void *buffer)
{
    if (!buffer) { ++block_range_rejects; return BLOCK_EINVAL; }
    if (!initialized) return BLOCK_ENODEV;
    if (lba >= ATA_LBA28_LIMIT || lba >= block_capacity) {
        ++block_range_rejects;
        return BLOCK_ERANGE;
    }
    return read_raw(lba, buffer);
}

uint32_t block_sector_count(void) { return block_capacity; }

static uint8_t pattern_byte(uint32_t lba, unsigned offset)
{ return (uint8_t)(lba * 13u + (lba >> 8) * 17u + offset * 37u + (offset >> 3)); }

static uint32_t hash_bytes(const uint8_t *bytes)
{
    uint32_t hash = 2166136261u;
    for (unsigned i = 0; i < 512; ++i) hash = (hash ^ bytes[i]) * 16777619u;
    return hash;
}

static uint32_t expected_hash(uint32_t lba)
{
    uint32_t hash = 2166136261u;
    for (unsigned i = 0; i < 512; ++i)
        hash = (hash ^ pattern_byte(lba, i)) * 16777619u;
    return hash;
}

void block_demo_done(void) { __asm__ volatile("nop" ::: "memory"); }

void block_demo(unsigned mode)
{
    block_result = block_followup_result = 0;
    block_capacity = block_reads = block_range_rejects = 0;
    block_hash_first = block_hash_middle = block_hash_last = 0;
    block_last_lba = block_last_status = block_last_error = 0;
    block_last_stage = block_last_polls = block_tick_delta = 0;
    block_channel_failed = block_passed = 0;
    initialized = channel_busy = command_issued = test_mode = 0;
    timer_start();
    __asm__ volatile("sti" ::: "memory");
    block_result = identify();
    KASSERT(block_result == BLOCK_OK && block_capacity == BLOCK_EXPECTED_SECTORS);

    if (mode == 0) {
        KASSERT(block_read_sector(0, sector) == BLOCK_OK);
        KASSERT(sector[510] == 0x55 && sector[511] == 0xaa);
        block_hash_first = hash_bytes(sector);
        KASSERT(block_read_sector(BLOCK_PATTERN_MIDDLE, sector) == BLOCK_OK);
        block_hash_middle = hash_bytes(sector);
        block_expected_middle = expected_hash(BLOCK_PATTERN_MIDDLE);
        KASSERT(block_hash_middle == block_expected_middle);
        KASSERT(block_read_sector(BLOCK_PATTERN_LAST, sector) == BLOCK_OK);
        block_hash_last = hash_bytes(sector);
        block_expected_last = expected_hash(BLOCK_PATTERN_LAST);
        KASSERT(block_hash_last == block_expected_last);
        KASSERT(block_read_sector(block_capacity, sector) == BLOCK_ERANGE);
        KASSERT(block_read_sector(ATA_LBA28_LIMIT, sector) == BLOCK_ERANGE);
        KASSERT(block_read_sector(0, 0) == BLOCK_EINVAL);
        KASSERT(block_range_rejects == 3 && !block_channel_failed);
        block_result = BLOCK_OK;
        kprintf("D20 ATA primary master LBA28 sectors=%u reads=%u\n",
                block_capacity, block_reads);
        kprintf("D20 hashes mbr=%x lba2047=%x lba%u=%x range=%u\n",
                block_hash_first, block_hash_middle, BLOCK_PATTERN_LAST,
                block_hash_last, block_range_rejects);
    } else if (mode == 1 || mode == 3) {
        test_mode = mode == 1 ? TEST_STUCK_BUSY : TEST_MISSING_DRQ;
        uint32_t start = timer_ticks;
        block_result = block_read_sector(BLOCK_PATTERN_MIDDLE, sector);
        block_tick_delta = timer_ticks - start;
        KASSERT(block_result == BLOCK_ETIMEDOUT);
        KASSERT(block_tick_delta >= ATA_TIMEOUT_TICKS && block_channel_failed);
        block_followup_result = block_read_sector(0, sector);
        KASSERT(block_followup_result == BLOCK_ECHANNEL);
        kprintf("D20 FAIL %s stage=%u status=%x error=%x ticks=%u polls=%u\n",
                mode == 1 ? "busy-timeout" : "missing-drq",
                block_last_stage, block_last_status, block_last_error,
                block_tick_delta, block_last_polls);
    } else {
        block_result = read_raw(block_capacity, sector);
        KASSERT(block_result == BLOCK_EIO && (block_last_status & ATA_SR_ERR));
        KASSERT(block_last_error == 0x04 && block_channel_failed);
        block_followup_result = block_read_sector(0, sector);
        KASSERT(block_followup_result == BLOCK_ECHANNEL);
        kprintf("D20 FAIL device-error lba=%u status=%x error=%x\n",
                block_last_lba, block_last_status, block_last_error);
    }

    (void)irq_save();
    timer_mask(1);
    block_passed = 1;
    kprintf("BLOCK OK mode=%u result=%d followup=%d failed=%u ticks=%u\n",
            mode, block_result, block_followup_result,
            block_channel_failed, block_tick_delta);
    block_demo_done();
}
