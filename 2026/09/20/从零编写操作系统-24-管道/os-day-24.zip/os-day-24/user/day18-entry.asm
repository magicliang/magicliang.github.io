bits 32
section .text
global day18_start
extern day18_main
day18_start:
    cld
    xor ebp, ebp
    call day18_main
.idle:
    mov eax, 2
    int 0x80
    jmp .idle

section .day18_result
global day18_result
day18_result:
    dd 0
