bits 32
section .text
global day19_start
extern day19_main
day19_start:
    cld
    xor ebp, ebp
    call day19_main
    mov ebx, 0xff
    mov eax, 4
    int 0x80
    ud2
