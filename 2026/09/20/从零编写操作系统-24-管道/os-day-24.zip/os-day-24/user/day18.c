#include <stddef.h>
#include <stdint.h>

#define SYS_WRITE 1u
#define DAY18_RESULT_OK 0x18c0ffeeu

extern volatile uint32_t day18_result;
static volatile uint32_t initialized = 0x1234abcdu;
static volatile uint8_t zero_area[5000];

static int32_t write_bytes(const char *text, size_t length)
{
    int32_t result;
    __asm__ volatile("int $0x80"
                     : "=a"(result)
                     : "a"(SYS_WRITE), "b"(text), "c"(length)
                     : "memory", "cc");
    return result;
}

void day18_main(void)
{
    volatile uint32_t local[8];
    for (unsigned i = 0; i < 8; ++i) local[i] = 0x1800u + i;
    if (initialized != 0x1234abcdu) return;
    for (unsigned i = 0; i < sizeof(zero_area); ++i)
        if (zero_area[i] != 0) return;
    for (unsigned i = 0; i < 8; ++i)
        if (local[i] != 0x1800u + i) return;
    static const char message[] = "D18 ELF32 data/BSS/stack OK\n";
    if (write_bytes(message, sizeof(message) - 1) != (int32_t)(sizeof(message) - 1))
        return;
    day18_result = DAY18_RESULT_OK;
}
