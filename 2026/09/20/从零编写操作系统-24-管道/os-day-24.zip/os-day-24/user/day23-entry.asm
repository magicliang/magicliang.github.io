bits 32
section .text
global day23_start
extern day23_main
day23_start:
    cld
    xor ebp, ebp
    mov eax, [esp]
    lea ebx, [esp + 4]
    and esp, 0xfffffff0
    sub esp, 8
    push ebx
    push eax
    call day23_main
    mov ebx, eax
    mov eax, 4
    int 0x80
    ud2
