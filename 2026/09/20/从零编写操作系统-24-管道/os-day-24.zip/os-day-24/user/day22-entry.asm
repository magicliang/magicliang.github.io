bits 32
section .text
global day22_start
extern day22_main
day22_start:
    cld
    xor ebp, ebp
    call day22_main
    mov ebx, 0xff
    mov eax, 4
    int 0x80
    ud2
