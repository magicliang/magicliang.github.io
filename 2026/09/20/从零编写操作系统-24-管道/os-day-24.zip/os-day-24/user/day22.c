#include <stddef.h>
#include <stdint.h>

#define SYS_YIELD 2u
#define SYS_SPAWN 3u
#define SYS_EXIT 4u
#define SYS_WAIT 5u
#define SYS_OPEN 6u
#define SYS_READ 7u
#define SYS_FD_WRITE 8u
#define SYS_CLOSE 9u

#define ERR_ENOENT 2
#define ERR_EIO 5
#define ERR_EBADF 9
#define ERR_ECHILD 10
#define ERR_EAGAIN 11
#define ERR_ENOMEM 12
#define ERR_EFAULT 14
#define ERR_EINVAL 22
#define ERR_ENFILE 23
#define ERR_EMFILE 24
#define ERR_EROFS 30
#define ERR_ENAMETOOLONG 36
#define FAULT_STATUS(vector) (0x10000u | (vector))

#define MODE_FDDEMO 6u
#define MODE_FDSHARE 7u
#define MODE_FDBADPTR 8u
#define MODE_FDHOLD 9u
#define MODE_FDFAIL 10u
#define MODE_FDTERM 11u
#define FD_MAP3(a,b,c) (0xd2200000u | ((a)+1u) | (((b)+1u)<<4) | (((c)+1u)<<8))

volatile uint32_t day22_mode __attribute__((section(".day22_mode")));
static uint8_t buffer[256], other[256];
static const char readonly_source[] = "D22 readonly source accepted\n";
void day22_main(void);

static int32_t call0(uint32_t number)
{
    int32_t result;
    __asm__ volatile("int $0x80" : "=a"(result) : "a"(number) : "memory", "cc");
    return result;
}

static int32_t call2(uint32_t number, uintptr_t first, uintptr_t second)
{
    int32_t result;
    __asm__ volatile("int $0x80" : "=a"(result)
                     : "a"(number), "b"(first), "c"(second)
                     : "memory", "cc");
    return result;
}

static int32_t call3(uint32_t number, uintptr_t first, uintptr_t second,
                     uintptr_t third)
{
    int32_t result;
    __asm__ volatile("int $0x80" : "=a"(result)
                     : "a"(number), "b"(first), "c"(second), "d"(third)
                     : "memory", "cc");
    return result;
}

static int32_t open_file(const char *name)
{ return call2(SYS_OPEN, (uintptr_t)name, 0); }
static int32_t read_file(int fd, void *out, uint32_t count)
{ return call3(SYS_READ, (uintptr_t)fd, (uintptr_t)out, count); }
static int32_t write_file(int fd, const void *in, uint32_t count)
{ return call3(SYS_FD_WRITE, (uintptr_t)fd, (uintptr_t)in, count); }
static int32_t close_file(int fd)
{ return call2(SYS_CLOSE, (uintptr_t)fd, 0); }
static int32_t spawn(const char *name, unsigned map)
{ return call2(SYS_SPAWN, (uintptr_t)name, map); }
static int32_t wait_pid(int32_t pid, uint32_t *status)
{ return call2(SYS_WAIT, (uintptr_t)pid, (uintptr_t)status); }
static _Noreturn void exit_process(uint32_t status)
{ call2(SYS_EXIT, status, 0); for (;;) { } }

static size_t text_length(const char *text)
{ size_t n = 0; while (text[n]) ++n; return n; }
static void say(int fd, const char *text)
{
    size_t length = text_length(text);
    if (write_file(fd, text, length) != (int32_t)length) exit_process(0xee);
}
static _Noreturn void fail(uint32_t code)
{ say(2, "D22 USER CHECK FAILED\n"); exit_process(code); }
static int equal(const uint8_t *a, const uint8_t *b, unsigned length)
{
    for (unsigned i = 0; i < length; ++i) if (a[i] != b[i]) return 0;
    return 1;
}

static void shared_program(void)
{
    if (read_file(0, buffer, 19) != 19) fail(0x71);
    say(1, "D22 CHILD shared offset +19\n");
    exit_process(19);
}

static void badptr_program(void)
{
    if (read_file(0, buffer, 11) != 11) fail(0x81);
    say(1, "D22 CHILD fault after shared +11\n");
    *(volatile uint32_t *)0x00100000u = 0xbad22000u;
    fail(0x82);
}

static void hold_program(void)
{
    for (unsigned i = 0; i < 1000; ++i) call0(SYS_YIELD);
    exit_process(0);
}

static void failure_program(void)
{
    int fd = open_file("README.TXT");
    if (fd != 3) fail(0xa1);
    unsigned map = FD_MAP3((unsigned)fd, 1, 2);
    for (unsigned i = 0; i < 7; ++i)
        if (spawn("FDSHARE", map) != -ERR_ENOMEM) fail(0xa2 + i);
    int32_t child = spawn("FDSHARE", map);
    uint32_t status = 0;
    if (child <= 0 || wait_pid(child, &status) != child || status != 19)
        fail(0xab);
    if (close_file(fd) || close_file(fd) != -ERR_EBADF) fail(0xac);
    say(1, "D22 FAIL mapped refs rollback and recovery OK\n");
    exit_process(0);
}

static void terminal_program(void)
{
    say(1, "D22 TERMINAL waiting for ab<Enter>\n");
    uint8_t input[3];
    for (unsigned i = 0; i < 3; ++i)
        if (read_file(0, input + i, 3 - i) != 1) fail(0xb0 + i);
    if (input[0] != 'a' || input[1] != 'b' || input[2] != '\n') fail(0xb4);
    say(1, "D22 TERMINAL read ab\\n one byte at a time\n");
    exit_process(0);
}

static void pointer_checks(void)
{
    int first = open_file("README.TXT");
    int second = open_file("README.TXT");
    if (first < 0 || second < 0) fail(0xc0);
    if (read_file(first, (void *)0x40000080u, 1) != -ERR_EFAULT ||
        read_file(first, buffer, 1) != 1 || read_file(second, other, 1) != 1 ||
        buffer[0] != other[0]) fail(0xc1);
    if (read_file(first, (void *)0x40002ffeu, 4) != -ERR_EFAULT ||
        read_file(first, (void *)0xfffffffdu, 8) != -ERR_EFAULT ||
        read_file(first, buffer, 257) != -ERR_EINVAL ||
        read_file(first, (void *)1, 0) != 0 ||
        read_file(-1, (void *)1, 0) != -ERR_EBADF) fail(0xc2);
    if (write_file(2, (const void *)0x40002ffeu, 4) != -ERR_EFAULT ||
        write_file(2, (const void *)0xfffffffdu, 8) != -ERR_EFAULT ||
        write_file(2, readonly_source, sizeof(readonly_source) - 1) !=
            (int32_t)(sizeof(readonly_source) - 1)) fail(0xc3);
    if (close_file(first) || close_file(second)) fail(0xc4);
}

static void demo_program(void)
{
    say(1, "D22 FD begin\n");
    if (open_file("MISSING.TXT") != -ERR_ENOENT ||
        open_file("TOO-LONG-NAME.TXT") != -ERR_ENAMETOOLONG ||
        call2(SYS_OPEN, (uintptr_t)"README.TXT", 1) != -ERR_EINVAL)
        fail(0xd0);
    if (write_file(0, "x", 1) != -ERR_EBADF ||
        read_file(1, buffer, 1) != -ERR_EBADF) fail(0xd1);

    int a = open_file("README.TXT"), b = open_file("README.TXT");
    if (a != 3 || b != 4 || read_file(a, buffer, 64) != 64 ||
        read_file(b, other, 64) != 64 || !equal(buffer, other, 64) ||
        read_file(a, buffer, 256) != 256) fail(0xd2);
    if (write_file(a, "x", 1) != -ERR_EROFS) fail(0xd3);
    if (close_file(a) || close_file(b)) fail(0xd4);

    int shared = open_file("README.TXT");
    int reference = open_file("README.TXT");
    if (shared != 3 || reference != 4 || read_file(shared, buffer, 37) != 37 ||
        read_file(reference, other, 57) != 57) fail(0xd5);
    int32_t child = spawn("FDSHARE", FD_MAP3((unsigned)shared, 1, 2));
    uint32_t status = 0;
    if (child <= 0 || wait_pid(child, &status) != child || status != 19 ||
        read_file(shared, buffer, 1) != 1 || buffer[0] != other[56]) fail(0xd6);
    if (read_file(reference, other, 12) != 12) fail(0xd7);
    child = spawn("FDBADPTR", FD_MAP3((unsigned)shared, 1, 2));
    if (child <= 0 || wait_pid(child, &status) != child ||
        status != FAULT_STATUS(14) || read_file(shared, buffer, 1) != 1 ||
        buffer[0] != other[11]) fail(0xd8);

    int32_t hold1 = spawn("FDHOLD", FD_MAP3((unsigned)shared, 1, 2));
    int32_t hold2 = spawn("FDHOLD", FD_MAP3((unsigned)shared, 1, 2));
    if (hold1 <= 0 || hold2 <= hold1 ||
        spawn("FDSHARE", FD_MAP3((unsigned)shared, 1, 2)) != -ERR_EAGAIN)
        fail(0xd9);
    if (wait_pid(hold1, &status) != hold1 || status ||
        wait_pid(hold2, &status) != hold2 || status) fail(0xda);
    if (close_file(shared) || close_file(reference)) fail(0xdb);

    pointer_checks();

    int hashfd = open_file("README.TXT");
    uint32_t hash = 2166136261u, total = 0, short_read = 0;
    int32_t got;
    while ((got = read_file(hashfd, buffer, 128)) > 0) {
        if (got < 128) short_read = (uint32_t)got;
        total += (uint32_t)got;
        for (int32_t i = 0; i < got; ++i) hash = (hash ^ buffer[i]) * 16777619u;
    }
    if (got || total != 1479 || short_read != 71 || hash != 0xf34dc752u ||
        read_file(hashfd, buffer, 1) != 0 || close_file(hashfd)) fail(0xdc);
    int empty = open_file("EMPTY.TXT");
    if (empty != 3 || read_file(empty, buffer, 1) != 0 || close_file(empty))
        fail(0xdd);

    int fds[5];
    for (unsigned i = 0; i < 5; ++i)
        if ((fds[i] = open_file("README.TXT")) != (int)(3 + i)) fail(0xe0 + i);
    if (open_file("README.TXT") != -ERR_EMFILE || close_file(1) ||
        open_file("README.TXT") != -ERR_ENFILE || close_file(fds[0])) fail(0xe6);
    int reused = open_file("README.TXT");
    if (reused != 1 || close_file(reused) || close_file(reused) != -ERR_EBADF)
        fail(0xe7);
    for (unsigned i = 1; i < 5; ++i) if (close_file(fds[i])) fail(0xe8);
    if (close_file(-1) != -ERR_EBADF || close_file(8) != -ERR_EBADF)
        fail(0xe9);
    say(2, "D22 FD independent/shared offsets, EOF, errors and limits OK\n");
    exit_process(22);
}

void day22_main(void)
{
    if (day22_mode == MODE_FDDEMO) demo_program();
    if (day22_mode == MODE_FDSHARE) shared_program();
    if (day22_mode == MODE_FDBADPTR) badptr_program();
    if (day22_mode == MODE_FDHOLD) hold_program();
    if (day22_mode == MODE_FDFAIL) failure_program();
    if (day22_mode == MODE_FDTERM) terminal_program();
    fail(0xff);
}
