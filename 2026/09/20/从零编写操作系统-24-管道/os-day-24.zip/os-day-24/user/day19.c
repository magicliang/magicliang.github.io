#include <stddef.h>
#include <stdint.h>

#define SYS_WRITE 1u
#define SYS_YIELD 2u
#define SYS_SPAWN 3u
#define SYS_EXIT 4u
#define SYS_WAIT 5u
#define ERR_ECHILD 10
#define ERR_EAGAIN 11
#define ERR_ENOMEM 12
#define ERR_EFAULT 14
#define ERR_EINVAL 22
#define ERR_ENAMETOOLONG 36
#define ERR_ENOENT 2
#define FAULT_STATUS(vector) (0x10000u | (vector))

enum program_mode { MODE_DEMO = 1, MODE_COUNT, MODE_BADPTR,
                    MODE_ORPHAN, MODE_FAILTEST };

volatile uint32_t day19_mode __attribute__((section(".day19_mode")));
volatile uint32_t day19_progress __attribute__((section(".day19_progress")));
volatile uint32_t day19_release __attribute__((section(".day19_release")));
volatile uint8_t day19_zero_area[5000];

static int32_t syscall0(uint32_t number)
{
    int32_t result;
    __asm__ volatile("int $0x80" : "=a"(result) : "a"(number)
                     : "memory", "cc");
    return result;
}

static int32_t syscall2(uint32_t number, uintptr_t first, uintptr_t second)
{
    int32_t result;
    __asm__ volatile("int $0x80" : "=a"(result)
                     : "a"(number), "b"(first), "c"(second)
                     : "memory", "cc");
    return result;
}

static void write_text(const char *text, size_t size)
{
    if (syscall2(SYS_WRITE, (uintptr_t)text, size) != (int32_t)size)
        syscall2(SYS_EXIT, 0xee, 0);
}

#define WRITE_LITERAL(text) write_text((text), sizeof(text) - 1)

static int32_t spawn(const char *name, unsigned io_map)
{ return syscall2(SYS_SPAWN, (uintptr_t)name, io_map); }

static int32_t wait_pid(int32_t pid, uint32_t *status)
{ return syscall2(SYS_WAIT, (uintptr_t)pid, (uintptr_t)status); }

static _Noreturn void exit_process(uint32_t status)
{
    syscall2(SYS_EXIT, status, 0);
    for (;;) { }
}

static _Noreturn void fail(uint32_t code)
{
    WRITE_LITERAL("D19 USER CHECK FAILED\n");
    exit_process(code);
}

static void count_program(void)
{
    uint32_t status = 0xfeedfaceu;
    if (wait_pid(1, &status) != -ERR_ECHILD || status != 0xfeedfaceu)
        fail(0xc1);
    WRITE_LITERAL("D19 COUNT running\n");
    while (!day19_release) {
        ++day19_progress;
        syscall0(SYS_YIELD);
    }
    WRITE_LITERAL("D19 COUNT exit=7\n");
    exit_process(0x107);
}

static void badptr_program(void)
{
    WRITE_LITERAL("D19 BADPTR faulting\n");
    *(volatile uint32_t *)0x00100000u = 0xbad19badu;
    fail(0xb1);
}

static void check_spawn_errors(void)
{
    static const char long_name[] = "NAME-IS-TOO-LONG";
    if (spawn("UNKNOWN", 0) != -ERR_ENOENT) fail(0xd1);
    if (spawn("COUNT", 1) != -ERR_EINVAL) fail(0xd2);
    if (spawn((const char *)0x1000u, 0) != -ERR_EFAULT) fail(0xd3);
    if (spawn(long_name, 0) != -ERR_ENAMETOOLONG) fail(0xd4);
    volatile char *cross_name = (volatile char *)0x40001ffcu;
    cross_name[0] = 'N'; cross_name[1] = 'O'; cross_name[2] = 'P';
    cross_name[3] = 'E'; cross_name[4] = 0;
    if (spawn((const char *)cross_name, 0) != -ERR_ENOENT) fail(0xd0);
    *(volatile uint8_t *)0x40002ffeu = 'N';
    *(volatile uint8_t *)0x40002fffu = 'O';
    if (spawn((const char *)0x40002ffeu, 0) != -ERR_EFAULT) fail(0xcf);
}

static void check_bad_status(int32_t pid)
{
    static const uint32_t readonly_status = 0x19191919u;
    if (wait_pid(pid, (uint32_t *)0x1000u) != -ERR_EFAULT) fail(0xe1);
    if (wait_pid(pid, (uint32_t *)&readonly_status) != -ERR_EFAULT) fail(0xe2);
    if (wait_pid(pid, (uint32_t *)0x7ffffffeu) != -ERR_EFAULT) fail(0xe3);
    if (wait_pid(pid, (uint32_t *)0xfffffffdu) != -ERR_EFAULT) fail(0xe4);
    if (wait_pid(pid, (uint32_t *)0x40003000u) != -ERR_EFAULT) fail(0xe5);
}

static void demo_program(void)
{
    int32_t old_count = -1;
    check_spawn_errors();
    for (unsigned round = 0; round < 2; ++round) {
        int32_t count = spawn("COUNT", 0);
        int32_t badptr = spawn("BADPTR", 0);
        if (count <= 0 || badptr <= count) fail(0xd5);
        if (spawn("COUNT", 0) != -ERR_EAGAIN) fail(0xd6);
        if (old_count > 0 && count <= old_count) fail(0xd7);

        uint32_t status = 0xfeedfaceu;
        if (!round) {
            if (wait_pid(count, &status) != count || status != 7) fail(0xd8);
            check_bad_status(badptr);
            if (wait_pid(badptr, &status) != badptr ||
                status != FAULT_STATUS(14)) fail(0xd9);
        } else {
            syscall0(SYS_YIELD);
            check_bad_status(badptr);
            if (wait_pid(badptr, &status) != badptr ||
                status != FAULT_STATUS(14)) fail(0xda);
            if (wait_pid(count, &status) != count || status != 7) fail(0xdb);
        }
        if (wait_pid(badptr, &status) != -ERR_ECHILD) fail(0xdc);
        if (wait_pid(0, &status) != -ERR_ECHILD) fail(0xdd);
        if (wait_pid(-1, &status) != -ERR_ECHILD) fail(0xed);
        if (wait_pid(1, &status) != -ERR_ECHILD) fail(0xde);
        if (wait_pid(0x7fffffff, &status) != -ERR_ECHILD) fail(0xdf);
        if (old_count > 0 && wait_pid(old_count, &status) != -ERR_ECHILD)
            fail(0xe0);
        old_count = count;
        WRITE_LITERAL("D19 DEMO round OK\n");
    }
    WRITE_LITERAL("D19 DEMO exit=9\n");
    exit_process(9);
}

static void orphan_program(void)
{
    if (spawn("COUNT", 0) <= 0 || spawn("BADPTR", 0) <= 0) fail(0xf1);
    syscall0(SYS_YIELD);
    WRITE_LITERAL("D19 ORPHAN parent exits\n");
    exit_process(11);
}

static void failure_program(void)
{
    for (unsigned i = 0; i < 8; ++i)
        if (spawn("COUNT", 0) != -ERR_ENOMEM) fail(0xa0 + i);
    int32_t child = spawn("COUNT", 0);
    int32_t badptr = spawn("BADPTR", 0);
    uint32_t status;
    if (child <= 0 || badptr <= child ||
        wait_pid(child, &status) != child || status != 7 ||
        wait_pid(badptr, &status) != badptr || status != FAULT_STATUS(14))
        fail(0xaf);
    WRITE_LITERAL("D19 FAIL rollback and recovery OK\n");
    exit_process(0);
}

void day19_main(void)
{
    if (day19_zero_area[0] || day19_zero_area[4999]) fail(0xf0);
    if (day19_mode == MODE_COUNT) count_program();
    if (day19_mode == MODE_BADPTR) badptr_program();
    if (day19_mode == MODE_DEMO) demo_program();
    if (day19_mode == MODE_ORPHAN) orphan_program();
    if (day19_mode == MODE_FAILTEST) failure_program();
    fail(0xff);
}
