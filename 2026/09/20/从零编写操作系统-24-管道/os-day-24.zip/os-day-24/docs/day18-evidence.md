# 第 18 篇：ELF 加载器与运行内存上限实测

日期：2026-09-18。本记录对应第 18 篇累计源码，只记录当前云端实际构建和启动过的结果。冻结 ZIP 哈希记录在正文与续写状态中，避免源码包内文件自引用附件哈希。

## 环境和命令

实际工具为 i686-elf GCC 13.3.0、Binutils 2.42、NASM 2.16.01、QEMU 8.2.2 和 GDB multiarch 15.1。SeaBIOS `bios-256k.bin` SHA-256 为 `1a9ea4f17bcfb27bda5728e2c21d9fa074cf7947b9b4910bb28213a735c96735`。客体固定为 `pc-i440fx-7.2`、`qemu32`、TCG、1 CPU、64 MiB、IDE raw 镜像。

云端工具位于 `/tmp/build-an-os-tools`。补充该目录的动态库、QEMU 模块、ROM 和 BIOS 路径后，分别执行 `make ... check-syscall`、`check-memory`、`check-elf` 和 `check-runtime-limit`，四个目标均退出 0。完整 QEMU 参数保存在本文附件与检查脚本中。Dockerfile 仍保留课程原定 GCC 13.2/QEMU 7.2/GDB 13.1 基线；本文不把云端较新版本冒充成该镜像版本。

## 容量上限的真实触发

加入加载器和用户 ELF 字节后，先用旧 65,536 字节运行内存上限链接当前对象。命令退出 1，真实输出为：

```text
i686-elf-ld: kernel memory exceeds loader bound
```

这是实际超界后才实施扩容的触发证据。修改后文件上限仍为 65,536 字节，`PAYLOAD_LOAD=0x10000`、LBA 9 头、LBA 10 载荷、128 个保留扇区和实模式文件校验路径未改；只有保护模式目标区、镜像头 memory 校验和链接布局的运行内存上限改为 131,072 字节。

正常 `kernel.bin` 为 51,432 字节，镜像头 file/memory 分别为 51,432/75,632 字节。精确 131,072 字节的专用镜像实际进入 `_start`：GDB 在入口看到 stage2 已将跨过旧 `0x110000` 边界的全部 BSS 填为 `0xa5`，进入 `kernel_main` 前又看到该区间全部清零；随后继续完成分配器、Day 16、Day 17 和 Day 18 回归。

两个负例也已实际执行：131,073 字节链接被 `kernel memory exceeds loader bound` 拒绝；文件长度仍合法但 memory 字段为 131,073 的镜像只输出 `D03 STAGE2 OK` 和 `D03 HEADER FAIL`，没有进入载荷复制。

## 被加载的真实 ELF

`readelf -h -l` 检查的内嵌文件为 4,332 字节，SHA-256 `174395052257b226fbc0f041529be8c2e60d2843d8c26510330e027e2dc2aa35`。它是 ELF32、小端、`ET_EXEC`、Intel 80386，入口 `0x40000080`，有两个 `PT_LOAD`：

| 段 | VA | file size | memory size | flags | 页数 |
| --- | --- | ---: | ---: | --- | ---: |
| 代码 | `0x40000000` | `0x149` | `0x149` | R E | 1 |
| 数据/BSS | `0x40001000` | `0x8` | `0x13a8` | RW | 2 |

加载器为页目录、LOAD 页表、栈页表、3 张 LOAD 页和 1 张用户栈页分配 7 页；创建任务时再分配第 8 页内核栈。

## 正常路径

GDB 在动态入口断住，实测 CS/SS 为 `0x1b/0x23`、ESP 为 `0x80000000`，CR3 为私有页目录。LOAD 区共享的 PDE 为 RWU，代码 PTE 为 RU，数据 PTE 为 RWU。两段共享同一 PDE，所以权限差异由 PTE.W 表达。

在 `day18_main` 入口，`(ESP+4)%16==0`、DF=0；`.data` 哨兵为 `0x1234abcd`，5,000 字节 BSS 全零，局部数组栈读写通过。用户程序通过 Day 17 的自定义 `int 0x80 write` 输出：

```text
D18 ELF32 entry=40000080 image=4332 alloc=7 invalid=34 rollback=8
D18 ELF32 data/BSS/stack OK
ELF OK data/BSS/stack; code=RO data=RW rollback=8 reaped=1 pages=16059
```

内核还检查数据页第六个双字仍为零，证明旧 IRQ 演示标记没有误写 ELF 数据。任务终止后回收 7 张地址空间页和 1 张内核栈页，空闲页数恢复到实验起点。

## 故意失败和回滚

客体内动态构造并拒绝 34 个输入，覆盖：截断头或 PHDR 表；错误 magic/class/endian/version/OSABI/type/machine/尺寸；PHDR 数量和表偏移回绕；未知段类型或权限；`p_flags=0`；文件、内存和虚拟地址范围错误；对齐错误；段乱序、页覆盖、页数超限；入口在段外或非执行段。

这些输入在分配前完成验证，每次拒绝后空闲页数不变。随后把失败点依次放在地址空间的 7 次页分配和第 8 次任务内核栈分配上，8 次均完整回滚。内核栈失败时任务槽仍为 DEAD，没有内核栈、用户地址空间或 RUNNABLE 半成品。

## 累计回归和边界

`check-syscall` 再次验证 Day 17 的 DPL3 `int 0x80`、逐页用户指针、DPL 失败隔离和资源回收。`check-memory` 再次耗尽 16,077 张可分配页，完成写模式和全回收，并确认内核相交页不可分配。`check-elf` 最终到达原键盘阻塞消费者。

当前只支持不变的内嵌 ELF32/i386 `ET_EXEC`，最多 8 个 PHDR 和 8 张 LOAD 页；不支持动态链接、重定位、TLS 或标准 argc/argv/envp/auxv 初始栈。IA-32 非 PAE 没有 NX，`PF_X` 只用于软件入口检查，数据页仍可取指。入口必须位于真实 `PF_X` LOAD 范围是项目的收窄策略，不是 ELF 通则。第 23 篇改为磁盘字节来源时，还需重新处理验证与复制之间的内容变化。

## 持久证据和产物

| 文件 | SHA-256 |
| --- | --- |
| `docs/day18-elf-gdb.txt` | `a28956deb20a0ecefe53f89693e9b5e80ed4a555909e9fe1378c23b995a7feca` |
| `docs/day18-elf-serial.txt` | `c7f73ee66a03f50cfa060c661674626db8da14d996f42dccd9dd316255532a89` |
| `docs/day18-readelf.txt` | `57c473035aba7f9c85d38a90316160f91a72276280af24b21849143ea803f144` |
| `docs/day18-screen.png` | `cb92f9cfea4e711101717067eb3e4343c802b0cd66fcc8e019645e55f9f77ab6` |
| `docs/day18-runtime-cap-gdb.txt` | `ec8cc84b4af4ffe6c5c69eb5ee8f36634e62440bc3a6f8162e593555f56ff542` |
| `docs/day18-runtime-link-over.txt` | `0cbfe1dbb42afe74ed876b35dccd0c9c501c7ed7f1857d6f290c2cfdfa49edc8` |
| `docs/day18-runtime-over-serial.txt` | `67365813975e0208b56a9df1d0ce1a8edbf08e9ed0afa0d68a6135ff59aa9b1d` |

普通构建的 `kernel.bin` SHA-256 为 `985a8f5ca5f973ec04bca5f659f67d94f9705edcbc131ee727bf357e458cb3ce`，`kernel.elf` 为 `3f8e946db7b29a515c02c622a52df7f860c435ec20bac07c0f568ec1688cece7`，`mbr.img` 为 `df4f950f4105c1aa7f36df715f572dcbe0fadce697d64d6e1fe2ba560e3493af`。带 DWARF 的 ELF 会嵌入构建路径，独立解压时不把其哈希当作位级可复现条件。

`build/` 不是唯一证据；主日志、QEMU 日志、累计回归日志和截图已复制到 `docs/`，位于现有 `sync-back.sh` 的 `writing-plans/` 回流范围。

冻结前还从不含 `build/` 的附件候选解压，在新目录重新构建并实际运行 `check-elf` 与 `check-runtime-limit`，两者退出 0。重建的 `kernel.bin`、`mbr.img` 和 `day18-user.elf` 哈希分别仍为 `985a8f...cb3ce`、`df4f950f...493af` 和 `17439505...aa35`。对应日志保存在 `docs/day18-standalone-{gdb,serial,qemu}.txt` 与 `docs/day18-standalone-runtime-gdb.txt`。
