# 第 17 篇：系统调用边界实测

日期：2026-09-17。源码从第 16 篇附件恢复后累计修改，基线 ZIP SHA-256 为 `c9bc978bd1909a1e9b2a61b611085c7cd09719240ae82f1b5478d397eef38331`。第 17 篇冻结附件 SHA-256 为 `cdd1b1653ff29c737e3a38a653580a2995d8725c9d13215a99236a8056f063e8`。本记录只描述当前云端实际执行的结果。

## 环境和命令

实际工具为 Ubuntu 24.04 用户态中的 GCC 13.3.0、Binutils 2.42、NASM 2.16.01、QEMU 8.2.2、GDB multiarch 15.1 和 SeaBIOS 1.16.3。客体参数固定为 `pc-i440fx-7.2`、`qemu32`、TCG、1 CPU、64 MiB、IDE raw 镜像。

云端软件包解压在 `/tmp/build-an-os-tools`，因此本轮使用下列等价命令补充动态库、QEMU 模块、ROM 和 BIOS 路径：

```sh
PATH=/tmp/build-an-os-tools/bin:$PATH \
LD_LIBRARY_PATH=/tmp/build-an-os-tools/root2/usr/lib/x86_64-linux-gnu:/tmp/build-an-os-tools/root2/lib/x86_64-linux-gnu \
QEMU_MODULE_DIR=/tmp/build-an-os-tools/root2/usr/lib/x86_64-linux-gnu/qemu \
GDB=gdb-multiarch \
make QEMU_COMMON='-L /tmp/build-an-os-tools/root2/usr/share/qemu -machine pc-i440fx-7.2 -accel tcg -cpu qemu32 -smp 1 -m 64M -bios /tmp/build-an-os-tools/root2/usr/share/seabios/bios-256k.bin -boot order=c,strict=on -nic none -no-reboot' check-syscall
```

`make check-syscall` 退出 0。`tools/check-syscall.sh` 启动正常镜像、在 1235 端口连接 GDB、截取画面，并在结束时清理 QEMU。标准 Makefile 曾把 GDB 缺省表达式作为带单引号的字面命令传给脚本，复跑时返回 126；现已移除该错误赋值，脚本重新读取调用者提供的 `GDB` 或自身缺省值。失败运行的日志没有用作通过证据。

## 正常入口和 ABI

用户任务从 CPL3 执行 `int 0x80`。GDB 在 `syscall_dispatch` 入口核对 IDT 门属性 `0xee`、当前 CS/SS 为 `0x08/0x10`，完整跨级 frame 为 19 个双字；保存的用户 CS/SS/ESP 为 `0x1b/0x23/0x80000000`。保存 EIP 等于 `int` 后的 `user_syscall_return`，保存的 IF、DF、CF 均为 1，而内核入口 IF 已由 interrupt gate 清零。

自定义 ABI 为 EAX 调用号与返回值，EBX/ECX 传 `write` 地址和长度。第一次调用传入非 NUL 的 19 字节缓冲，包含 `%`，串口精确输出 `D17 WRITE % NO-NUL`，返回 19；GDB 和用户代码共同核对 EBX、ECX、EDX、ESI、EDI、EBP、用户 ESP 和标志位恢复。只读代码页作为输入返回 16，合法跨页返回 15。

`yield` 返回 0，只设置统一延期调度请求。另一个用户任务在调用者返回前已取得执行机会，计数增量非零。`write` 完整复制后短暂开放 IRQ；受控观察点实际收到至少一个 PIT tick。因为外层 `trap_depth` 仍为 1，切换只在统一 trap 退出后兑现，不在 console 输出中发生。

## 指针、长度和失败原子性

动态测试覆盖以下结果：

| 输入 | 实际结果 |
| --- | --- |
| 未知调用号 99 | `-ENOSYS`（-38） |
| 长度 0、地址 `0xffffffff` | 0，不解引用地址 |
| 长度 257 | `-EINVAL`（-22） |
| 低地址 `0x1000` | `-EFAULT`（-14） |
| `0xfffffff0 + 32` 回绕 | `-EFAULT` |
| 从 `0x7ffffff8` 跨用户上界 | `-EFAULT` |
| 第二页缺失 | `-EFAULT`，串口不存在预置的 `LEAKFAIL` 前缀 |
| 用户窗口中的 supervisor 页 | `-EFAULT` |
| 只读用户代码页作为 write 源 | 成功，返回 16 |
| 两张用户页上的合法跨页源 | 成功，返回 15 |

内核侧还在切换到测试地址空间后直接执行 `copy_to_user`：合法跨两页复制完整写入 16 字节；第二页 PTE 去掉 W 后返回失败，第一页预置 guard 保持不变；PDE 去掉 W 同样拒绝；零长度和无效地址组合成功返回且不访问地址。四项检查在客体内完成，GDB 读取 `syscall_copy_checks == 4`。

这套“先检查全部页，再复制”的原子性只适用于当前单 CPU、每进程单线程、没有 unmap 且 IRQ 不修改当前地址空间的实现。未来出现共享地址空间或并发解除映射时，需要重新设计固定页、锁或容错复制。

## 故意失败、隔离和回收

第二组实验让 CPL3 执行 DPL0 的 `int 0x20`。处理器产生 `#GP`，错误码为 `0x102`，保存 EIP 精确指向这条 INT；错误任务终止，配对计数任务在随后四个 tick 中继续增长。本实验没有把软件门权限失败误记成系统调用返回错误。

第一组两个任务和第二组两个任务均从安全的 bootstrap 上下文回收。每任务拥有六张地址空间页和一张内核栈页，共回收 28 张页；两轮结束后 `free_pages` 均恢复到 `syscall_initial_pages`。栈 canary、`trap_depth`、`preempt_count` 与填充值边界同时检查。串口最终输出：

```text
D17 gate DPL #GP error=102 eip=40000077 survivor+=3130860
SYSCALL OK calls=12 writes=3 errors=7 irq_ticks=1 yield_delta=2109425 reaped=4
```

计数增量受 TCG 和宿主调度影响，只证明任务继续取得进展，不是吞吐、公平性或实时性指标。

## 累计回归和产物

同一次正常启动在 Day 17 前依次输出 Day 03–16 的累计通过标志，并在结束后到达原键盘阻塞消费者。最终 GDB 输出三条通过记录：系统调用跨级现场、全部返回与资源检查、到达键盘入口。

本轮未宣称旧 `check-user.sh` 在 GDB 15.1 下再次通过：该旧脚本复跑时出现 `target is running` 控制错误。恢复 Day 16 初期的独立 `check-user` 曾退出 0，Day 17 当前正常镜像也完整输出 `USER OK`。旧 `check-pm` 的 triple-fault 退出码仍受 QEMU 8.2.2 行为差异影响。它们是明确的宿主检查兼容边界，不改写成内核通过结论。

关键产物：

| 文件 | 字节数 | SHA-256 |
| --- | ---: | --- |
| `build/kernel.bin` | 40820 | `6dc48b32623242660bf17b3e83128ea040da5aacb9d78aeeb1cd35061fd81cb4` |
| `build/kernel.elf` | 121852 | `fdf944436fa57815c6981344534c8418f70449af00fe7b108cafcea320f6096f` |
| `build/mbr.img` | 2097152 | `6cea2d081032144809db26189c9d53c137cc9651b15d424dbac00a4589cc022c` |
| `docs/day17-screen.png` | - | `c1a03c4a6b1f22005eb549cf4e5cc3c5ff83c538b36439d577276196c47ad14d` |
| `docs/day17-syscall-serial.txt` | - | `bc05b86acfcead4180e086ea105f8578365c60adea7678aebb3a0c4d8b78420c` |
| `docs/day17-syscall-gdb.txt` | - | `9f8b2904194dc5fdd07202ab954804a9256a6ec6cf07fa7c29881fcea0708168` |

镜像头记录 file size 为 40820 字节，memory size 为 64832 字节，仍低于 65536 字节上限，余量 704 字节。本篇没有扩大加载器、磁盘布局或运行内存上限。后续代码若实际超界，必须同时检查镜像头生产、stage2 分段读取与搬运、链接布局和边界故障镜像。

完整证据保存在 `docs/day17-syscall-{serial,gdb,qemu}.txt` 和 `docs/day17-screen.png`。`build/` 中的同名文件是可再生成产物，不是唯一记录。

冻结 ZIP 另在 `/tmp` 新目录独立解压，从无 `build/` 的源码重新执行同一 `make ... check-syscall`，退出 0。重建得到的 `kernel.bin` 与 `mbr.img` SHA-256 分别仍为 `6dc48b...31fd81cb4`、`6cea2d...ac00a4589cc022c`；带 DWARF 的 `kernel.elf` 因编译目录写入调试信息而哈希不同，不把它误报为位级可复现。独立复验日志保存在 `docs/day17-standalone-{serial,gdb,qemu}.txt`。
