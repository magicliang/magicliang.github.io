# 第 19 篇：创建与回收进程实测

日期：2026-09-18。本记录对应第 19 篇累计源码，只写当前云端真实构建和启动过的结果。冻结 ZIP 的哈希记录在正文和续写状态中，避免源码包自引用。

## 环境

实际工具为 i686-elf GCC 13.3.0、Binutils 2.42、NASM 2.16.01、QEMU 8.2.2 和 GDB multiarch 15.1。客体固定为 `pc-i440fx-7.2`、`qemu32`、TCG、1 CPU、64 MiB，使用云端 `/tmp/build-an-os-tools` 中的 SeaBIOS 和 QEMU 数据文件。Dockerfile 仍保留课程原定工具基线；本文不把云端版本写成容器基线版本。

核心命令为：

```sh
make check-process \
  QEMU=/tmp/build-an-os-tools/bin/qemu-system-i386 \
  GDB=/tmp/build-an-os-tools/bin/gdb-multiarch \
  QEMU_COMMON='-machine pc-i440fx-7.2 -accel tcg -cpu qemu32 \
    -smp 1 -m 64M -bios .../seabios/bios-256k.bin \
    -L .../qemu -boot order=c,strict=on -nic none -no-reboot'
```

该目标先静态检查用户 ELF，再启动正常镜像和创建失败注入镜像。两次 QEMU 都由 GDB 读取客体状态，不以预期串口文本代替状态断言。

## 构建和 ELF

普通 `kernel.bin` 为 61,408 字节，镜像头的 file/memory 字段为 61,408/85,872 字节。文件仍低于 65,536 字节，运行内存仍低于第 18 篇已验证的 131,072 字节；没有再次修改实模式暂存、校验或磁盘保留布局。

剥离后的 `day19-user.elf` 为 4,336 字节，SHA-256 为 `5f217e782f81e7d0c72b08da4e90fefa6be82ec9199605c47a4166d78e65b9fc`。`readelf` 实测它是 ELF32、小端、i386 `ET_EXEC`，入口 `0x40000080`，包含一个 R E LOAD 和一个 RW LOAD。可写段中的 `day19_mode`、`day19_progress`、`day19_release` 分别位于 `0x40001000/004/008`。

五个实验程序没有嵌入五份重复 ELF。`spawn` 仍建立互相隔离的地址空间，只在装载后给每个副本写入不同 mode，由同一 `_start` 分派到 DEMO、COUNT、BADPTR、ORPHAN 或 FAILTEST。这是当前 64 KiB 文件容量下的项目选择，不是进程共享地址空间。

## 正常生命周期

正常镜像完成两轮父子实验：DEMO 各创建一个 COUNT 和一个 BADPTR。第一轮父进程先等待仍运行的 COUNT；第二轮先取得已经退出的 BADPTR，再等待 COUNT。最终串口为：

```text
PROCESS OK mode=normal reaped=8 wait=4 blocks=2 faults=10 rollback=0 survivor+=3 pages=16057
```

GDB 在 BADPTR 已成为 ZOMBIE、COUNT 仍运行时停住，确认：

- 父状态为 BLOCKED，`trap_depth==1`，保存 ESP 位于父自己的 4 KiB 内核栈；
- `waiting_on` 指向指定 COUNT 的退出队列，队列位图只包含父槽；
- BADPTR 状态为 `0x1000e`，其地址空间和内核栈尚未释放；
- COUNT 的用户进度大于 0，随后又增长至少 3，最后 `exit(0x107)` 被父读取为状态 7。

本次持久日志发生两次阻塞返回和两次 zombie 立即返回。时钟抢占可能让合法 wait 发生前子进程已经退出，自动断言因此接受 1–3 次阻塞，但强制要求至少一次阻塞、至少一次立即返回，且四次成功 wait 的分类总数严格相等。`exit` 不在 depth=1 的系统调用栈上销毁当前栈；公共 trap 尾部把深度降为 0 后才发布 ZOMBIE。父进程醒来后从原 `wait` 调用继续，先把状态写进父地址空间，再释放子进程的 7 张地址空间页和 1 张内核栈页。

## 指针、身份和孤儿负例

程序名路径执行了未知名称、`io_map!=0`、低地址、超过 16 字节、合法跨页和跨到缺页的输入。槽满时第三次子创建返回 `-EAGAIN`。等待路径执行 PID 0、负 PID、未知 PID、非直接子、重复 wait 和已经回收的旧 PID；槽位复用后 PID 单调增加，旧 PID 没有命中新进程。

对同一个 BADPTR zombie，父进程依次传入低地址、只读代码页、跨页缺页、32 位高地址溢出和未映射页五种坏状态指针。每次返回 `-EFAULT`，没有消费退出状态；两轮累计 `faults=10`，合法指针随后仍得到 `0x1000e` 并只回收一次。`copy_to_user` 在写入前验证完整 4 字节范围，因此测试没有留下半写前缀。

ORPHAN 父进程退出时，一个 COUNT 仍在运行，一个 BADPTR 已是 ZOMBIE。两者的 `parent_pid` 都改为 0。bootstrap 先回收父和已有 zombie，COUNT 继续运行，后来退出后同样由 PID 0 回收。最后三个用户槽的 PID、内核栈和地址空间首项均为 0，空闲页回到 16057。

## 创建失败回滚

失败镜像让 FAILTEST 连续调用 `spawn("COUNT")`。前 7 次依次使页目录、两张页表、LOAD 页和用户栈中的某次分配失败；第 8 次让地址空间已经成功后，内核栈分配失败。每次都返回 `-ENOMEM`，未发布 RUNNABLE 半成品，随后关闭注入并成功创建 COUNT 和 BADPTR。

最终串口为：

```text
D19 FAIL rollback and recovery OK
PROCESS OK mode=failure reaped=3 wait=2 blocks=1 faults=0 rollback=8 survivor+=1 pages=16057
```

GDB 检查 `process_failure_step==8`、`process_spawn_rollbacks==8`，最终所有用户槽为空且空闲页恢复。正常路径和失败路径均由实际启动镜像得出。

## 累计回归与自动化边界

正常 `check-process` 镜像从 BIOS 连续运行既有 Day 10–18 演示，再进入 Day 19。串口实际包含 `MEMORY OK`、`PAGING OK`、`HEAP OK`、`TASKS OK`、`PREEMPT OK`、`WAIT OK`、`USER OK`、`SYSCALL OK` 和 `ELF OK`，最后回到原键盘阻塞消费者。Day 19 新增第四槽后，旧阶段仍限制为三槽；旧双元素用户观测数组没有访问新槽。

单独重跑 `check-tasks.sh` 时，GDB 15.1 在自由运行的客体上设置后续硬件断点存在控制竞争：串口已经输出 D13–D19 全部成功标记，但 GDB 错过 `task_demo_done` 后等待至超时。这个结果记录为检查脚本控制失败，不写成旧专项退出 0，也不写成内核回归。Day 19 的 `check-process` 使用受控状态条件断点，正常和失败目标均退出 0。

实验末尾保存 `next_pid`，临时设置为 `INT32_MAX+1`，确认 `spawn` 返回 `-EAGAIN` 且页数不变，再恢复原值。它验证了拒绝分支，但没有通过数十亿次自然创建验证长期计数过程。没有验证 SMP、真实硬件或其他 BIOS。第 22 篇增加 FD 后，还必须在 exit 阶段关闭引用，不能把管道端保留到 wait。

## 持久证据

| 文件 | SHA-256 |
| --- | --- |
| `docs/day19-process-gdb.txt` | `e85bc58ffb78154e139a28e0f5a5888b6add3bb586b67830b8b6079e534f2fb6` |
| `docs/day19-process-serial.txt` | `ec5b153e483d9559819fcea12f0eb97eb116d28d855b43f962c3ba00b52b72f8` |
| `docs/day19-process-fail-gdb.txt` | `73120716f6bc174454e7f1ec26077aa0ae03c11908452b050d30b3db27e3a000` |
| `docs/day19-process-fail-serial.txt` | `bb87d9cf77e527b2bb321a884428ae5d6ca7e4a7d2136ae05ea2a744246fb8ed` |
| `docs/day19-readelf.txt` | `3a7d361988919f1aca6e5d7ff5a8004b5c0ad7bf6354a52b9015dd527e0fc78a` |
| `docs/day19-screen.png` | `c3040cebbb2467a875382e9920805b258f68f28beeed9c4487890e6e8e2a511a` |

普通构建的 `kernel.bin`、`kernel.elf` 和 `mbr.img` SHA-256 分别为 `4de2396f...e4bf`、`451cf3d0...1a38` 和 `45bda930...8b59`。带 DWARF 的 ELF 嵌入构建路径，独立解压时不把 `kernel.elf` 位级相同作为通过条件。

证据、源码和检查脚本都位于 `writing-plans/`，不依赖临时目录作为唯一副本。

冻结附件后又在空目录独立解压，从不存在 `build/` 的状态执行 `make build`、`check-process`、`check-syscall`、`check-elf`、`check-memory` 和 `check-runtime-limit`，六项均退出 0。重建的 `kernel.bin`、`mbr.img` 和 `day19-user.elf` 哈希与主工作区一致。构建输出和各项检查记录已复制为 `docs/day19-standalone-*.txt`；附件 SHA-256 由正文与续写状态记录。

独立重跑旧 `check-user` 时，GDB 15.1 报告 `Cannot execute this command while the target is running`，目标最终退出 2。对应串口已输出 `USER OK ring3 CR3/TSS; rollback=7 reaped=6 pages=16057`，但这只能说明客体走到该标记，不能替代 GDB 断言；因此 `check-user` 不记为通过。
