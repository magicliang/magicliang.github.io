# 云端续写环境（2026-09-17）

本记录描述恢复 Day 16 后在当前云端容器中实际使用的工具，不改写 `environment.md` 中历史容器的版本事实。

| 工具 | 实际版本/来源 |
| --- | --- |
| 宿主 | Ubuntu 24.04.4 LTS，x86_64 |
| 编译器 | GCC 13.3.0，`-m32 -ffreestanding`，未链接宿主 libc |
| Binutils | GNU ld/objcopy/readelf/nm/objdump 2.42，目标输出 ELF32/i386 |
| NASM | 2.16.01，Ubuntu noble 包解压到 `/tmp` |
| QEMU | 8.2.2，Ubuntu noble-updates 包解压到 `/tmp` |
| 机器 | `pc-i440fx-7.2`、`qemu32`、TCG、1 CPU、64 MiB |
| SeaBIOS | 1.16.3；`bios-256k.bin` 来自 Ubuntu noble 包 |
| GDB | gdb-multiarch 15.1，Ubuntu noble-updates 包解压到 `/tmp` |

Day 16 原附件使用 QEMU 7.2.22、SeaBIOS 对应 Debian 12 包、GDB 13.1 和 i686-elf GCC 13.2。当前环境没有原 Podman 镜像，也没有容器运行时，因此使用上述本地解压工具重新验证，不能把本次结果记成旧版本结果。

## 恢复与构建

源码来自：

```text
source/_posts/2026-09-08-从零编写操作系统-16-进入用户态/os-day-16.zip
SHA-256 c9bc978bd1909a1e9b2a61b611085c7cd09719240ae82f1b5478d397eef38331
```

解压后的累计源码位于 `writing-plans/从零编写操作系统-续写资料/build-an-os/`。使用宿主 GCC 的 32 位 freestanding 模式构建，生成的关键产物为：

```text
kernel.bin 37140 bytes
kernel memory_size 61008 bytes
kernel.bin SHA-256 f535973edfd6f2bcd8ec6c733c399d4fc6d79e9818c839c957089618d7ab6a95
kernel.elf SHA-256 af03c16d0facf00129d62f0c138df0a1e4c3e7b89af82bd5d7dbf5d5428a2155
mbr.img SHA-256 67e64c298b349a7d38a7ed9acdda8179ec0144bb8da3e2c3a117a34c90230d8e
```

## 运行结果

`docs/day16-cloud-baseline-serial.txt` 是实际启动日志。镜像经过 BIOS、stage2、保护模式、异常、PIT、物理页、分页、堆、协作任务、抢占和等待实验，完成三轮 Ring 3 故障隔离后输出 `USER OK`，最后进入 `D09 PS/2 IRQ1` 输入界面。

`docs/day16-cloud-baseline-user-gdb.txt` 是 `check-user` 的真实 GDB 输出。检查确认 CPL3 的 CS/SS、私有 CR3、TSS.esp0、76 字节跨特权级 trap frame、用户写内核产生 #PF(7)、CLI/OUT 产生 #GP(0)，以及 6 个用户任务和 42 个私有页面被回收。

## 已知差异

旧 `check-pm` 预期 triple fault 后 QEMU 进程在四秒内自行退出。QEMU 8.2.2 在相同 `-no-reboot` 参数下保持运行，超时返回 124，因此旧脚本的退出码断言失败；GDB 的保护模式寄存器和 BootInfo 检查已通过。这是工具版本相关的检查假设，不能记为 Day 16 功能通过，也不能把它误写成内核回归。
