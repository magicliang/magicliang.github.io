bits 16
org 0x8000

%include "build/layout.inc"
%include "boot/bootinfo.inc"
%ifdef ONE_SECTOR_READS
%assign READ_CHUNK_SECTORS 1
%endif
HEADER_SEGMENT equ 0x0900
HEADER_OFFSET equ 0
HEADER_FILE_SIZE equ 8
HEADER_MEMORY_SIZE equ 12
HEADER_ENTRY equ 16
HEADER_CHECKSUM equ 20

start:
    cli
    cld
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7c00
    mov [boot_drive], dl
    call serial_init

    mov ax, 0xb800
    mov es, ax
    mov di, 320
    mov si, stage2_msg
    call write_string
    mov si, stage2_msg
    call serial_write

    call check_edd
    call read_header
    call validate_header
    call read_payload
    call verify_payload
    xor ax, ax
    mov ds, ax
    mov ax, 0xb800
    mov es, ax
    mov di, 480
    mov si, ok_msg
    call write_string
    mov si, ok_msg
    call serial_write
    call prepare_bootinfo
    call collect_e820
    call enable_a20
    cli
    lgdt [gdtr]
    mov eax, cr0
    or eax, 1
    mov cr0, eax
    jmp CODE_SEL:pm_entry

check_edd:
    mov ah, 0x41
    mov bx, 0x55aa
    mov dl, [boot_drive]
    int 0x13
    jc header_error
    cmp bx, 0xaa55
    jne header_error
    test cx, 1
    jz header_error
    ret

read_header:
    mov word [dap_count], 1
    mov word [dap_offset], HEADER_OFFSET
    mov word [dap_segment], HEADER_SEGMENT
    mov dword [dap_lba], HEADER_LBA
    mov dword [dap_lba + 4], 0
    call read_dap
    ret

validate_header:
    mov ax, HEADER_SEGMENT
    mov ds, ax
    cmp dword [HEADER_OFFSET], HEADER_MAGIC
    jne header_error
    cmp dword [HEADER_OFFSET + 4], HEADER_VERSION
    jne header_error
    mov eax, [HEADER_OFFSET + HEADER_FILE_SIZE]
    test eax, eax
    jz header_error
    cmp eax, 64
    jb header_error
    cmp eax, PAYLOAD_MAX_BYTES
    ja header_error
    xor bx, bx
    mov es, bx
    mov [es:file_size], eax
    mov eax, [HEADER_OFFSET + HEADER_MEMORY_SIZE]
    cmp eax, [es:file_size]
    jb header_error
    cmp eax, KERNEL_MEMORY_MAX_BYTES
    ja header_error
    mov [es:memory_size], eax
    mov eax, [HEADER_OFFSET + HEADER_ENTRY]
    cmp eax, [es:file_size]
    jae header_error
    mov [es:entry_offset], eax
    mov ax, [HEADER_OFFSET + HEADER_CHECKSUM]
    mov [es:expected_checksum], ax
    xor ax, ax
    mov ds, ax
    ret

read_payload:
    mov eax, [file_size]
    add eax, 511
    shr eax, 9
    mov [remaining_sectors], ax
    mov word [buffer_segment], PAYLOAD_SEGMENT
    mov dword [next_lba], PAYLOAD_LBA
    mov dword [next_lba + 4], 0

.next:
    mov ax, [remaining_sectors]
    test ax, ax
    jz .done
    cmp ax, READ_CHUNK_SECTORS
    jbe .use_remaining
    mov ax, READ_CHUNK_SECTORS

.use_remaining:
    mov [dap_count], ax
    mov [last_count], ax
    mov word [dap_offset], 0
    mov bx, [buffer_segment]
    mov [dap_segment], bx
    mov eax, [next_lba]
    mov [dap_lba], eax
    mov eax, [next_lba + 4]
    mov [dap_lba + 4], eax
    call read_dap
    mov ax, [last_count]
    sub [remaining_sectors], ax
    movzx eax, ax
    add [next_lba], eax
    adc dword [next_lba + 4], 0
    shl ax, 5
    add [buffer_segment], ax
    jmp .next

.done:
    ret

read_dap:
    xor ax, ax
    mov ds, ax
    mov si, dap
    mov ah, 0x42
    mov dl, [boot_drive]
    int 0x13
    jc read_error
    ret

verify_payload:
    xor ax, ax
    mov es, ax
    mov ax, PAYLOAD_SEGMENT
    mov ds, ax
    call checksum_payload
    cmp ax, [es:expected_checksum]
    jne header_error
    ret

checksum_payload:
    xor ax, ax
    mov es, ax
    mov ax, PAYLOAD_SEGMENT
    mov ds, ax
    xor esi, esi
    mov edx, [es:file_size]
    xor ebx, ebx
.next_segment:
    test edx, edx
    jz .done
    mov ecx, edx
    cmp ecx, 0x10000
    jbe .chunk_ready
    mov ecx, 0x10000
.chunk_ready:
    mov edi, ecx
.next_byte:
    test ecx, ecx
    jz .chunk_done
    xor eax, eax
    mov al, [esi]
    add bx, ax
    inc esi
    dec ecx
    jmp .next_byte
.chunk_done:
    sub edx, edi
    jz .done
    mov ax, ds
    add ax, 0x1000
    mov ds, ax
    xor esi, esi
    jmp .next_segment
.done:
    mov ax, bx
    ret

; BIOS work ends before CR0.PE. Mode 3 defines the display contract.
prepare_bootinfo:
    mov ax, 3
    int 0x10
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov di, BOOTINFO
    mov cx, BI_SIZE / 2
    rep stosw
    mov dword [BOOTINFO + BI_MAGIC], BOOT_MAGIC
    mov word [BOOTINFO + BI_VERSION], 1
    mov word [BOOTINFO + BI_BYTES], BI_SIZE
    mov al, [boot_drive]
    mov [BOOTINFO + BI_DRIVE], al
    mov dword [BOOTINFO + BI_MAP], E820_MAP
    mov word [BOOTINFO + BI_STRIDE], 24
    mov dword [BOOTINFO + BI_PAYLOAD], PAYLOAD_SEGMENT * 16
    mov eax, [file_size]
    mov [BOOTINFO + BI_PAYLOAD_BYTES], eax
    mov dword [BOOTINFO + BI_VIDEO], 0xb8000
    mov word [BOOTINFO + BI_COLUMNS], 80
    mov word [BOOTINFO + BI_ROWS], 25
    mov word [BOOTINFO + BI_PITCH], 160
    mov byte [BOOTINFO + BI_VIDEO_MODE], 3
    mov byte [BOOTINFO + BI_CELL_BYTES], 2
    ret

collect_e820:
    xor ebx, ebx
    mov di, E820_MAP
    mov word [e820_calls], 0
.next:
    cmp word [BOOTINFO + BI_COUNT], E820_CAPACITY
    jae e820_error
    inc word [e820_calls]
    cmp word [e820_calls], 128
    ja e820_error
    mov dword [es:di + 20], 1
    mov eax, 0xe820
    mov edx, 0x534d4150
    mov ecx, 24
    int 0x15
    jc .end_cf
    cmp eax, 0x534d4150
    jne e820_error
    cmp ecx, 20
    jb e820_error
    cmp ecx, 24
    ja e820_error
    ; Normalize a legacy 20-byte reply without reading absent attributes.
    cmp ecx, 24
    je .length
    mov dword [es:di + 20], 1
.length:
    mov eax, [es:di + 8]
    or eax, [es:di + 12]
    jz .continue
    inc word [BOOTINFO + BI_COUNT]
    add di, 24
.continue:
    test ebx, ebx
    jnz .next
    jmp .done
.end_cf:
    ; Some firmware terminates with CF after the last successful entry.
    cmp word [BOOTINFO + BI_COUNT], 0
    je e820_error
.done:
    cmp word [BOOTINFO + BI_COUNT], 0
    je e820_error
    mov si, e820_ok_msg
    call serial_write
    ret

; Compare 0000:0500 and FFFF:0510, preserving both bytes and segments.
a20_test:
    pushf
    cli
    push ds
    push es
    push bx
    xor ax, ax
    mov ds, ax
    dec ax
    mov es, ax
    mov bl, [ds:0x500]
    mov bh, [es:0x510]
    mov byte [ds:0x500], 0
    mov byte [es:0x510], 0xff
    xor ax, ax
    cmp byte [ds:0x500], 0xff
    setne al
    mov [es:0x510], bh
    mov [ds:0x500], bl
    pop bx
    pop es
    pop ds
    popf
%ifdef FORCE_A20_FAIL
    xor ax, ax
%endif
    ret

enable_a20:
%ifdef FORCE_A20_OFF
    in al, 0x92
    and al, 0xfc
    out 0x92, al
%endif
    call a20_test
    test ax, ax
    jnz .ok
    mov si, a20_enable_msg
    call serial_write
    in al, 0x92
    or al, 2
    and al, 0xfe
    out 0x92, al
    call a20_test
    test ax, ax
    jz a20_error
.ok:
    mov si, a20_ok_msg
    call serial_write
    ret

e820_error:
    mov si, e820_err_msg
    jmp setup_error
a20_error:
    mov si, a20_err_msg
setup_error:
    xor ax, ax
    mov ds, ax
    mov ax, 0xb800
    mov es, ax
    mov di, 0
    push si
    call write_string
    pop si
    call serial_write
    jmp halt

serial_init:
    mov dx, 0x3f9
    xor al, al
    out dx, al
    mov dx, 0x3fb
    mov al, 0x80
    out dx, al
    mov dx, 0x3f8
    mov al, 0x03
    out dx, al
    mov dx, 0x3f9
    xor al, al
    out dx, al
    mov dx, 0x3fb
    mov al, 0x03
    out dx, al
    mov dx, 0x3fa
    mov al, 0xc7
    out dx, al
    mov dx, 0x3fc
    mov al, 0x0b
    out dx, al
    ret

header_error:
    xor ax, ax
    mov ds, ax
    mov ax, 0xb800
    mov es, ax
    mov di, 480
    mov si, header_err_msg
    call write_string
    mov si, header_err_msg
    call serial_write
    jmp halt

read_error:
    xor ax, ax
    mov ds, ax
    mov ax, 0xb800
    mov es, ax
    mov di, 480
    mov si, read_err_msg
    call write_string
    mov si, read_err_msg
    call serial_write

halt:
    cli
    hlt
    jmp halt

write_string:
    lodsb
    test al, al
    jz .ret
    mov ah, 0x0e
    stosw
    jmp write_string
.ret:
    ret

serial_write:
    lodsb
    test al, al
    jz .newline
    call serial_putc
    jmp serial_write

.newline:
    mov al, 13
    call serial_putc
    mov al, 10
    call serial_putc
    ret

serial_putc:
    push ax
.wait:
    mov dx, 0x3fd
    in al, dx
    test al, 0x20
    jz .wait
    pop ax
    mov dx, 0x3f8
    out dx, al
    ret

stage2_msg:
    db 'D03 STAGE2 OK', 0
ok_msg:
    db 'D03 PAYLOAD OK', 0
header_err_msg:
    db 'D03 HEADER FAIL', 0
read_err_msg:
    db 'D03 READ FAIL', 0
boot_drive:
    db 0
remaining_sectors:
    dw 0
buffer_segment:
    dw 0
last_count:
    dw 0
next_lba:
    dq 0
memory_size: dd 0
entry_offset: dd 0
file_size:
    dd 0
expected_checksum:
    dw 0

align 4
dap:
    db 0x10
    db 0
dap_count:
    dw 0
dap_offset:
    dw 0
dap_segment:
    dw 0
dap_lba:
    dq 0

e820_calls: dw 0
e820_ok_msg: db 'D04 E820 OK', 0
a20_enable_msg: db 'D04 A20 ENABLE', 0
a20_ok_msg: db 'D04 A20 OK', 0
e820_err_msg: db 'D04 E820 FAIL', 0
a20_err_msg: db 'D04 A20 FAIL', 0
align 8
gdt:
    dq 0
    dq 0x00cf9a000000ffff
    dq 0x00cf92000000ffff
gdt_end:
gdtr:
%ifdef BAD_GDT
    dw 7 ; Selector 0x08 is beyond this deliberate one-entry table.
%else
    dw gdt_end - gdt - 1
%endif
    dd gdt

; A fixed landing address makes the raw binary easy to debug without ELF.
times 0xe00 - ($ - $$) db 0
bits 32
pm_entry:
    mov ax, DATA_SEL
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov esp, 0x7c00
    cld
    mov esi, BOOTINFO
    cmp dword [esi + BI_MAGIC], BOOT_MAGIC
    jne pm_halt
    cmp word [esi + BI_VERSION], 1
    jne pm_halt
    cmp word [esi + BI_BYTES], BI_SIZE
    jne pm_halt
    mov edi, [esi + BI_VIDEO]
    mov ebx, pm_msg
.next:
    mov al, [ebx]
    inc ebx
    test al, al
    jz load_kernel
    cmp al, 13
    je .serial
    cmp al, 10
    je .serial
    mov ah, 0x0e
    stosw
.serial:
    push eax
.wait:
    mov dx, 0x3fd
    in al, dx
    test al, 0x20
    jz .wait
    pop eax
    mov dx, 0x3f8
    out dx, al
    jmp .next
load_kernel:
    ; Dirty the destination first: BSS success must come from entry.asm.
    mov edi, 0x100000
    mov ecx, [memory_size]
    mov al, 0xa5
    rep stosb
    mov esi, PAYLOAD_SEGMENT * 16
    mov edi, 0x100000
    mov ecx, [file_size]
    rep movsb
    mov esi, BOOTINFO
    mov eax, [entry_offset]
    add eax, 0x100000
    jmp eax
pm_halt:
    cli
    hlt
    jmp pm_halt
pm_msg: db 'D04 PM OK - BootInfo v1', 13, 10, 0

times 4096 - ($ - $$) db 0
