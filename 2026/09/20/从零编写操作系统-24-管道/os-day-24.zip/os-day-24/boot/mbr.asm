bits 16
org 0x7c00

%include "build/layout.inc"
STAGE2_LOAD equ 0x8000

start:
    cli
    cld
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7c00
    mov [boot_drive], dl

    mov ax, 0xb800
    mov es, ax
    xor di, di
    mov ax, 0x0720
    mov cx, 80 * 25
    rep stosw
    xor di, di
    mov si, message
    call write_string
    mov al, [boot_drive]
    call write_hex8
%ifdef DAY02_ONLY
    jmp hang
%else
    mov si, loading
    call write_string
    call read_stage2
    mov dl, [boot_drive]
    jmp 0x0000:STAGE2_LOAD
%endif

hang:
    cli
    hlt
    jmp hang

error:
    mov ax, 0xb800
    mov es, ax
    mov di, 160
    mov si, err_msg
    call write_string
    jmp hang

%ifndef DAY02_ONLY
read_stage2:
    mov ah, 0x41
    mov bx, 0x55aa
    mov dl, [boot_drive]
    int 0x13
    jc error
    cmp bx, 0xaa55
    jne error
    test cx, 1
    jz error

    xor ax, ax
    mov ds, ax
    mov es, ax
    mov si, dap
    mov ah, 0x42
    mov dl, [boot_drive]
    int 0x13
    jc error
    ret
%endif

write_string:
    lodsb
    test al, al
    jz .ret
    mov ah, 0x0f
    stosw
    jmp write_string
.ret:
    ret

write_hex8:
    push ax
    shr al, 4
    call write_hex4
    pop ax
    and al, 0x0f
    call write_hex4
    ret

write_hex4:
    cmp al, 10
    jb .digit
    add al, 'A' - 10
    jmp .emit

.digit:
    add al, '0'

.emit:
    mov ah, 0x0f
    stosw
    ret

message:
%ifdef DAY02_ONLY
    db 'OSDAY02 DL=', 0
%else
    db 'OSDAY03 DL=', 0
%endif

%ifndef DAY02_ONLY
loading:
    db ' S1', 0
%endif

err_msg:
    db 'D03 MBR ERR', 0

boot_drive:
    db 0

%ifndef DAY02_ONLY
dap:
    db 0x10
    db 0
    dw STAGE2_SECTORS
    dw STAGE2_LOAD
    dw 0
    dq STAGE2_LBA
%endif

times 446 - ($ - $$) db 0
%ifndef DAY02_ONLY
db 0x00, 0xfe, 0xff, 0xff
db 0x04, 0xfe, 0xff, 0xff
dd FAT16_START_LBA
dd FAT16_SECTORS
times 48 db 0
%else
times 64 db 0
%endif
dw 0xaa55
