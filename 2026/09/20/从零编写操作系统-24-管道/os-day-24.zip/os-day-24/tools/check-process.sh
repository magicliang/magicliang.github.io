#!/bin/sh
set -eu
GDB=${GDB:-gdb-multiarch}
PAYLOAD_MAX_BYTES=${PAYLOAD_MAX_BYTES:-65536}

i686-elf-readelf -h -l build/day19-user.elf > build/day19-readelf.txt
i686-elf-nm -n build/day19-user-debug.elf > build/day19-user-symbols.txt
grep -q 'Class:.*ELF32' build/day19-readelf.txt
grep -q 'Data:.*little endian' build/day19-readelf.txt
grep -q 'Type:.*EXEC' build/day19-readelf.txt
grep -q 'Machine:.*Intel 80386' build/day19-readelf.txt
test "$(grep -c '^  LOAD' build/day19-readelf.txt)" -eq 2
grep -q 'R E' build/day19-readelf.txt
grep -q 'RW ' build/day19-readelf.txt
test "$(i686-elf-readelf -h build/day19-user.elf | awk '/Entry point address:/ {print $4}')" = 0x40000080
test "$(i686-elf-nm -n build/day19-user-debug.elf | awk '$3 == "day19_mode" {print "0x" $1}')" = 0x40001000
test "$(i686-elf-nm -n build/day19-user-debug.elf | awk '$3 == "day19_progress" {print "0x" $1}')" = 0x40001004
test "$(i686-elf-nm -n build/day19-user-debug.elf | awk '$3 == "day19_release" {print "0x" $1}')" = 0x40001008
test "$(wc -c < build/kernel.bin)" -le "$PAYLOAD_MAX_BYTES"

"$QEMU" $QEMU_COMMON -snapshot -drive file=build/mbr.img,format=raw,if=ide \
    -display none -serial file:build/day19-process-serial.txt -monitor stdio \
    -S -gdb tcp:127.0.0.1:1238 > build/day19-process-qemu.txt 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
timeout -k 5 180 "$GDB" -q -nx -batch \
    -ex 'set architecture i386' \
    -ex 'set tcp connect-timeout 5' \
    -ex 'set tcp auto-retry on' \
    -ex 'file build/kernel.elf' \
    -ex 'target remote 127.0.0.1:1238' \
    -ex 'hbreak process_bootstrap_observed if process_zombie_pages != 0' \
    -ex 'continue' \
    -ex 'python import gdb; v=lambda e:int(gdb.parse_and_eval(e)); assert v("current")==0 and v("process_blocked_trap_depth")==1; p=next(i for i in range(1,4) if v("tasks[%d].pid"%i)==v("process_blocked_parent_pid")); c=next(i for i in range(1,4) if v("tasks[%d].pid"%i)==v("process_blocked_target_pid")); b=next(i for i in range(1,4) if v("tasks[%d].program_kind"%i)==3); assert v("tasks[%d].state"%p)==3 and v("tasks[%d].trap_depth"%p)==1; assert v("tasks[%d].state"%b)==4 and v("tasks[%d].exit_status"%b)==0x1000e; assert v("tasks[%d].waiting_on"%p)==v("&tasks[%d].exit_waiters"%c); assert v("tasks[%d].exit_waiters.mask"%c)==1<<p; sp=v("tasks[%d].saved_sp"%p); ks=v("tasks[%d].kernel_stack"%p); assert ks<sp<ks+4096; assert v("*(unsigned int *)(tasks[%d].user.pages[4]+4)"%c)>0; print("PASS: parent blocked inside top-level wait while BADPTR remained zombie and COUNT runnable")' \
    -ex 'delete 1' \
    -ex 'hbreak process_demo_done' \
    -ex 'continue' \
    -ex 'python import gdb; v=lambda e:int(gdb.parse_and_eval(e)); assert v("process_passed")==1 and v("process_reaped")==8 and v("process_wait_reaped")==4; blocks=v("process_wait_blocks"); assert 1<=blocks<=3 and v("process_wait_after_block")==blocks and v("process_wait_immediate")==4-blocks and v("process_wait_immediate")>=1; assert v("process_wait_faults")==10 and v("process_orphan_reparented")==2 and v("process_survivor_growth")>=3; assert v("process_peak_slots")==3 and v("free_pages")==v("process_initial_pages"); assert all(v("tasks[%d].pid"%i)==0 and v("tasks[%d].kernel_stack"%i)==0 and v("tasks[%d].user.pages[0]"%i)==0 for i in range(1,4)); print("PASS: two rounds, bad status retries, PID reuse protection, orphan adoption and complete recovery verified")' \
    -ex 'monitor screendump build/day19-screen.png -f png' \
    -ex 'hbreak keyboard_ready' \
    -ex 'continue' \
    -ex 'printf "PASS: process demo reaches original blocking keyboard consumer\n"' \
    -ex 'disconnect' > build/day19-process-gdb.txt 2>&1
kill "$pid" 2>/dev/null || true
wait "$pid" 2>/dev/null || true
trap - EXIT HUP INT TERM

grep -Fq 'D19 BADPTR faulting' build/day19-process-serial.txt
grep -Fq 'D19 REAP pid=3 status=1000e by=wait' build/day19-process-serial.txt
grep -Fq 'D19 ORPHAN parent exits' build/day19-process-serial.txt
grep -Eq 'PROCESS OK mode=normal reaped=8 wait=4 blocks=[123] faults=10 rollback=0' build/day19-process-serial.txt
grep -Fq 'PASS: parent blocked inside top-level wait' build/day19-process-gdb.txt
grep -Fq 'PASS: two rounds, bad status retries' build/day19-process-gdb.txt
grep -Fq 'PASS: process demo reaches original blocking keyboard consumer' build/day19-process-gdb.txt

"$QEMU" $QEMU_COMMON -snapshot -drive file=build/mbr-process-fail.img,format=raw,if=ide \
    -display none -serial file:build/day19-process-fail-serial.txt -monitor stdio \
    -S -gdb tcp:127.0.0.1:1239 > build/day19-process-fail-qemu.txt 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
timeout -k 5 180 "$GDB" -q -nx -batch \
    -ex 'set architecture i386' \
    -ex 'set tcp connect-timeout 5' \
    -ex 'set tcp auto-retry on' \
    -ex 'file build/kernel-process-fail.elf' \
    -ex 'target remote 127.0.0.1:1239' \
    -ex 'hbreak process_demo_done' \
    -ex 'continue' \
    -ex 'python import gdb; v=lambda e:int(gdb.parse_and_eval(e)); assert v("process_passed")==1 and v("process_failure_passed")==1; assert v("process_failure_step")==8 and v("process_spawn_rollbacks")==8; assert v("process_reaped")==3 and v("process_wait_reaped")==2 and v("free_pages")==v("process_initial_pages"); assert all(v("tasks[%d].pid"%i)==0 and v("tasks[%d].kernel_stack"%i)==0 and v("tasks[%d].user.pages[0]"%i)==0 for i in range(1,4)); print("PASS: seven ELF allocation failures plus kernel-stack failure rolled back, then normal spawn recovered")' \
    -ex 'disconnect' > build/day19-process-fail-gdb.txt 2>&1

grep -Fq 'D19 FAIL rollback and recovery OK' build/day19-process-fail-serial.txt
grep -Fq 'PROCESS OK mode=failure reaped=3 wait=2 blocks=1 faults=0 rollback=8' build/day19-process-fail-serial.txt
grep -Fq 'PASS: seven ELF allocation failures plus kernel-stack failure' build/day19-process-fail-gdb.txt
cat build/day19-process-gdb.txt
cat build/day19-process-fail-gdb.txt
