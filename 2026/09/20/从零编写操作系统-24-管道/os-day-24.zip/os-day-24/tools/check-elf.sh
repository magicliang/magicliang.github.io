#!/bin/sh
set -eu
GDB=${GDB:-gdb-multiarch}

i686-elf-readelf -h -l build/day18-user.elf > build/day18-readelf.txt
i686-elf-nm -n build/day18-user-debug.elf > build/day18-user-symbols.txt
grep -q 'Class:.*ELF32' build/day18-readelf.txt
grep -q 'Data:.*little endian' build/day18-readelf.txt
grep -q 'Type:.*EXEC' build/day18-readelf.txt
grep -q 'Machine:.*Intel 80386' build/day18-readelf.txt
test "$(grep -c '^  LOAD' build/day18-readelf.txt)" -eq 2
grep -q 'R E' build/day18-readelf.txt
grep -q 'RW ' build/day18-readelf.txt
entry=$(i686-elf-readelf -h build/day18-user.elf | awk '/Entry point address:/ {print $4}')
main=$(i686-elf-nm -n build/day18-user-debug.elf | awk '$3 == "day18_main" {print "0x" $1}')
zero=$(i686-elf-nm -n build/day18-user-debug.elf | awk '$3 == "zero_area" {print "0x" $1}')
test "$entry" = 0x40000080
test -n "$main" && test "$zero" = 0x40001020

"$QEMU" $QEMU_COMMON -snapshot -drive file=build/mbr.img,format=raw,if=ide \
    -display none -serial file:build/day18-elf-serial.txt -monitor stdio \
    -S -gdb tcp:127.0.0.1:1237 > build/day18-elf-qemu.txt 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
timeout -k 5 180 "$GDB" -q -nx -batch \
    -ex 'set architecture i386' \
    -ex 'set tcp connect-timeout 5' \
    -ex 'set tcp auto-retry on' \
    -ex 'file build/kernel.elf' \
    -ex 'target remote 127.0.0.1:1237' \
    -ex "hbreak *$entry" \
    -ex 'condition 1 tasks[current].user.kind == 2' \
    -ex 'continue' \
    -ex 'python import gdb; v=lambda e:int(gdb.parse_and_eval(e)); assert v("$cs")==0x1b and v("$ss")==0x23 and v("$esp")==0x80000000; assert v("$cr3")!=v("user_kernel_cr3"); pd=v("$cr3")&0xfffff000; m=gdb.selected_inferior(); u=lambda a:int.from_bytes(bytes(m.read_memory(a,4)),"little"); pde=u(pd+4*(0x40000000>>22)); pt=pde&0xfffff000; code=u(pt); data=u(pt+4); assert pde&7==7 and code&7==5 and data&7==7; print("PASS: dynamic ELF entry reached CPL3 with private CR3, RO code and RW data")' \
    -ex 'delete 1' \
    -ex "hbreak *$main" \
    -ex 'condition 2 tasks[current].user.kind == 2' \
    -ex 'continue' \
    -ex 'python import gdb; v=lambda e:int(gdb.parse_and_eval(e)); m=gdb.selected_inferior(); assert (v("$esp")+4)%16==0 and not (v("$eflags")&0x400); assert int.from_bytes(bytes(m.read_memory(0x40001004,4)),"little")==0x1234abcd; assert bytes(m.read_memory(0x40001020,5000))==bytes(5000); print("PASS: C entry stack alignment, clear DF, initialized data and 5000-byte BSS verified")' \
    -ex 'delete 2' \
    -ex 'hbreak elf_demo_done' \
    -ex 'continue' \
    -ex 'python import gdb; v=lambda e:int(gdb.parse_and_eval(e)); assert (v("elf_passed"),v("elf_negative_passes"),v("elf_allocations"),v("elf_rollback_passes"),v("elf_reaped"))==(1,34,7,8,1); assert v("elf_entry_seen")==0x40000080; assert v("elf_code_pte")&7==5 and v("elf_data_pte")&7==7; assert v("free_pages")==v("elf_initial_pages"); print("PASS: 34 malformed ELF cases, all allocation failures and task-stack rollback recovered")' \
    -ex 'monitor screendump build/day18-screen.png -f png' \
    -ex 'hbreak keyboard_ready' \
    -ex 'continue' \
    -ex 'printf "PASS: ELF demo reaches original blocking keyboard consumer\n"' \
    -ex 'disconnect' > build/day18-elf-gdb.txt 2>&1

grep -Fq 'D18 ELF32 data/BSS/stack OK' build/day18-elf-serial.txt
grep -Fq 'D18 ELF32 entry=40000080 image=4332 alloc=7 invalid=34 rollback=8' build/day18-elf-serial.txt
grep -Fq 'ELF OK data/BSS/stack; code=RO data=RW rollback=8 reaped=1' build/day18-elf-serial.txt
grep -Fq 'PASS: dynamic ELF entry reached CPL3' build/day18-elf-gdb.txt
grep -Fq 'PASS: C entry stack alignment' build/day18-elf-gdb.txt
grep -Fq 'PASS: 34 malformed ELF cases' build/day18-elf-gdb.txt
grep -Fq 'PASS: ELF demo reaches original blocking keyboard consumer' build/day18-elf-gdb.txt
cat build/day18-elf-gdb.txt
