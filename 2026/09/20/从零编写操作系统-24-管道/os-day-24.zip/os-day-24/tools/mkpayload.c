#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum {
    SECTOR_SIZE = 512,
    HEADER_SIZE = 512,
};

static uint32_t parse_u32(const char *s, const char *name)
{
    char *end = NULL;
    errno = 0;
    unsigned long value = strtoul(s, &end, 0);
    if (errno != 0 || *s == '\0' || *end != '\0' || value > UINT32_MAX) {
        fprintf(stderr, "invalid %s: %s\n", name, s);
        exit(1);
    }
    return (uint32_t)value;
}

static void put32(uint8_t *p, uint32_t value)
{
    p[0] = (uint8_t)value;
    p[1] = (uint8_t)(value >> 8);
    p[2] = (uint8_t)(value >> 16);
    p[3] = (uint8_t)(value >> 24);
}

static void write_file(const char *path, const uint8_t *data, size_t len)
{
    FILE *f = fopen(path, "wb");
    if (f == NULL) {
        perror(path);
        exit(1);
    }
    if (fwrite(data, 1, len, f) != len) {
        perror(path);
        fclose(f);
        exit(1);
    }
    if (fclose(f) != 0) {
        perror(path);
        exit(1);
    }
}

static uint16_t checksum16(const uint8_t *data, size_t len)
{
    uint32_t sum = 0;
    for (size_t i = 0; i < len; i++) {
        sum += data[i];
    }
    return (uint16_t)sum;
}

int main(int argc, char **argv)
{
    if (argc != 12) {
        fprintf(stderr, "usage: %s payload.bin header.bin bad-magic.bin oversized-file.bin oversized-memory.bin file-bytes file-max memory-max magic memory-bytes entry-offset\n", argv[0]);
        return 1;
    }

    const char *payload_path = argv[1];
    const char *header_path = argv[2];
    const char *bad_magic_path = argv[3];
    const char *oversized_header_path = argv[4];
    const char *oversized_memory_path = argv[5];
    uint32_t payload_bytes = parse_u32(argv[6], "payload-bytes");
    uint32_t file_max = parse_u32(argv[7], "file-max");
    uint32_t memory_max = parse_u32(argv[8], "memory-max");
    uint32_t magic = parse_u32(argv[9], "magic");

    uint32_t memory_bytes = parse_u32(argv[10], "memory-bytes");
    uint32_t entry = parse_u32(argv[11], "entry-offset");
    if (memory_bytes < payload_bytes || memory_bytes > memory_max || entry >= payload_bytes) {
        fprintf(stderr, "invalid kernel memory/entry bounds\n"); return 1;
    }
    if (payload_bytes < 64 || payload_bytes > file_max) {
        fprintf(stderr, "payload size %u outside 64..%u\n", payload_bytes, file_max);
        return 1;
    }

    uint8_t *payload = malloc(payload_bytes);
    if (payload == NULL) {
        perror("malloc");
        return 1;
    }

    FILE *input = fopen(payload_path, "rb");
    if (!input) { perror(payload_path); free(payload); return 1; }
    if (fread(payload, 1, payload_bytes, input) != payload_bytes || fgetc(input) != EOF || ferror(input)) {
        fprintf(stderr, "kernel file size mismatch\n"); fclose(input); free(payload); return 1;
    }
    fclose(input);

    uint8_t header[HEADER_SIZE];
    memset(header, 0, sizeof(header));
    put32(header + 0, magic);
    put32(header + 4, 1);
    put32(header + 8, payload_bytes);
    put32(header + 12, memory_bytes);
    put32(header + 16, entry);
    put32(header + 20, checksum16(payload, payload_bytes));

    uint8_t bad_magic[HEADER_SIZE];
    memcpy(bad_magic, header, sizeof(bad_magic));
    put32(bad_magic + 0, 0);

    uint8_t oversized[HEADER_SIZE];
    memcpy(oversized, header, sizeof(oversized));
    put32(oversized + 8, file_max + 1);
    put32(oversized + 12, file_max + 1);

    uint8_t oversized_memory[HEADER_SIZE];
    memcpy(oversized_memory, header, sizeof(oversized_memory));
    put32(oversized_memory + 12, memory_max + 1);

    write_file(header_path, header, sizeof(header));
    write_file(bad_magic_path, bad_magic, sizeof(bad_magic));
    write_file(oversized_header_path, oversized, sizeof(oversized));
    write_file(oversized_memory_path, oversized_memory,
               sizeof(oversized_memory));

    free(payload);
    return 0;
}
