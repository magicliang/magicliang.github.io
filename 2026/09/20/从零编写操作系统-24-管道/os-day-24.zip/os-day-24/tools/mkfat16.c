#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum { SECTOR = 512, PARTITION_SECTORS = 14336, FAT_SECTORS = 56,
       ROOT_SECTORS = 32, DATA_SECTOR = 145 };

static void put16(uint8_t *p, uint16_t v) { p[0] = v; p[1] = v >> 8; }
static void put32(uint8_t *p, uint32_t v)
{ p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24; }

static void fail(const char *what)
{
    if (errno) perror(what); else fprintf(stderr, "%s\n", what);
    exit(1);
}

static void fat_entry(uint8_t *image, unsigned copy, uint16_t cluster,
                      uint16_t value)
{
    size_t offset = (size_t)(1 + copy * FAT_SECTORS) * SECTOR + cluster * 2u;
    put16(image + offset, value);
}

static void directory_entry(uint8_t *entry, const char name[11], uint8_t attr,
                            uint16_t cluster, uint32_t size)
{
    memcpy(entry, name, 11);
    entry[11] = attr;
    put16(entry + 26, cluster);
    put32(entry + 28, size);
}

static void make_name(const char *input, char output[11])
{
    memset(output, ' ', 11);
    unsigned base = 0, ext = 0, dotted = 0;
    for (; *input; ++input) {
        unsigned char ch = (unsigned char)*input;
        if (ch == '.') {
            if (dotted || !base) fail("invalid 8.3 name");
            dotted = 1; continue;
        }
        if (ch >= 'a' && ch <= 'z') ch -= 'a' - 'A';
        if (!((ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') ||
              ch == '_' || ch == '-')) fail("invalid 8.3 name");
        if ((!dotted && base == 8) || (dotted && ext == 3))
            fail("invalid 8.3 name");
        output[dotted ? 8 + ext++ : base++] = (char)ch;
    }
    if (!base || (dotted && !ext)) fail("invalid 8.3 name");
}

static uint8_t *read_input(const char *path, size_t *size)
{
    FILE *file = fopen(path, "rb");
    if (!file) fail(path);
    if (fseek(file, 0, SEEK_END) != 0) fail("seek input");
    long length = ftell(file);
    if (length <= 0 || (unsigned long)length > UINT32_MAX) fail("input size");
    rewind(file);
    uint8_t *bytes = malloc((size_t)length);
    if (!bytes) fail("allocate input");
    if (fread(bytes, 1, (size_t)length, file) != (size_t)length ||
        fgetc(file) != EOF || fclose(file) != 0)
        fail("read input");
    *size = (size_t)length;
    return bytes;
}

int main(int argc, char **argv)
{
    if (argc < 4 || ((argc - 4) & 1)) {
        fprintf(stderr, "usage: %s output.img README.TXT mode [NAME FILE]...\n", argv[0]);
        return 1;
    }
    if (strcmp(argv[3], "normal") && argc != 4)
        fail("extra files are only valid in normal mode");
    FILE *input = fopen(argv[2], "rb");
    if (!input) fail(argv[2]);
    if (fseek(input, 0, SEEK_END) != 0) fail("seek README");
    long length = ftell(input);
    if (length <= 1024 || length > 1536) fail("README size must be 1025..1536 bytes");
    rewind(input);
    uint8_t content[1536];
    if (fread(content, 1, (size_t)length, input) != (size_t)length ||
        fgetc(input) != EOF) fail("read README");
    fclose(input);

    size_t bytes = (size_t)PARTITION_SECTORS * SECTOR;
    uint8_t *image = calloc(1, bytes);
    if (!image) fail("allocate FAT image");
    uint8_t *bpb = image;
    bpb[0] = 0xeb; bpb[1] = 0x3c; bpb[2] = 0x90;
    memcpy(bpb + 3, "BUILDOS ", 8);
    put16(bpb + 11, SECTOR);
    bpb[13] = 1;
    put16(bpb + 14, 1);
    bpb[16] = 2;
    put16(bpb + 17, 512);
    put16(bpb + 19, PARTITION_SECTORS);
    bpb[21] = 0xf8;
    put16(bpb + 22, FAT_SECTORS);
    put16(bpb + 24, 63);
    put16(bpb + 26, 16);
    put32(bpb + 28, 2048);
    bpb[36] = 0x80; bpb[38] = 0x29;
    put32(bpb + 39, 0x21092026);
    memcpy(bpb + 43, "BUILDOS    ", 11);
    memcpy(bpb + 54, "FAT16   ", 8);
    bpb[510] = 0x55; bpb[511] = 0xaa;

    for (unsigned copy = 0; copy < 2; ++copy) {
        fat_entry(image, copy, 0, 0xfff8);
        fat_entry(image, copy, 1, 0xffff);
        fat_entry(image, copy, 2, 9);
        fat_entry(image, copy, 9, 4);
        fat_entry(image, copy, 4, 0xffff);
    }
    if (!strcmp(argv[3], "loop")) {
        for (unsigned copy = 0; copy < 2; ++copy) fat_entry(image, copy, 9, 2);
    } else if (!strcmp(argv[3], "short")) {
        for (unsigned copy = 0; copy < 2; ++copy) fat_entry(image, copy, 9, 0xffff);
    } else if (!strcmp(argv[3], "badbpb")) {
        bpb[13] = 0;
    } else if (!strcmp(argv[3], "mirror")) {
        fat_entry(image, 1, 9, 5);
    } else if (!strcmp(argv[3], "badcluster")) {
        for (unsigned copy = 0; copy < 2; ++copy) fat_entry(image, copy, 9, 0xfff7);
    } else if (!strcmp(argv[3], "reserved")) {
        for (unsigned copy = 0; copy < 2; ++copy) fat_entry(image, copy, 9, 0xfff0);
    } else if (!strcmp(argv[3], "outofrange")) {
        for (unsigned copy = 0; copy < 2; ++copy) fat_entry(image, copy, 9, 0x4000);
    } else if (strcmp(argv[3], "normal") && strcmp(argv[3], "rootbound") &&
               strcmp(argv[3], "dirhi") && strcmp(argv[3], "emptycluster") &&
               strcmp(argv[3], "oversize")) {
        fail("unknown mode");
    }

    uint8_t *root = image + (1 + 2 * FAT_SECTORS) * SECTOR;
    directory_entry(root, "BUILDOS    ", 0x08, 0, 0);
    memset(root + 32, 'L', 11); root[32 + 11] = 0x0f;
    memset(root + 64, 'X', 11); root[64] = 0xe5;
    directory_entry(root + 96, "SUBDIR     ", 0x10, 3, 0);
    directory_entry(root + 128, "README  TXT", 0x20, 2, (uint32_t)length);
    directory_entry(root + 160, "EMPTY   TXT", 0x20, 0, 0);
    unsigned root_offset = 192;
    if (!strcmp(argv[3], "rootbound")) put16(bpb + 17, 1);
    if (!strcmp(argv[3], "dirhi")) put16(root + 128 + 20, 1);
    if (!strcmp(argv[3], "emptycluster")) put16(root + 160 + 26, 3);
    if (!strcmp(argv[3], "oversize")) put32(root + 128 + 28, UINT32_MAX);

    const uint16_t chain[3] = { 2, 9, 4 };
    size_t copied = 0;
    for (unsigned i = 0; i < 3 && copied < (size_t)length; ++i) {
        size_t take = (size_t)length - copied;
        if (take > SECTOR) take = SECTOR;
        size_t sector = DATA_SECTOR + (chain[i] - 2u);
        memcpy(image + sector * SECTOR, content + copied, take);
        copied += take;
    }

    uint16_t next_cluster = 10;
    for (int arg = 4; arg < argc; arg += 2) {
        char name[11];
        make_name(argv[arg], name);
        size_t file_length;
        uint8_t *file_bytes = read_input(argv[arg + 1], &file_length);
        uint32_t clusters = ((uint32_t)file_length + SECTOR - 1u) / SECTOR;
        if (arg == 4 && clusters > 20) fail("SHELL.EXE chain too long");
        if (root_offset + 32u >= ROOT_SECTORS * SECTOR)
            fail("root directory full");
        if ((uint32_t)DATA_SECTOR + next_cluster - 2u + clusters >=
            PARTITION_SECTORS)
            fail("data area full");
        uint16_t first_cluster = arg == 4 ? 10u : next_cluster;
        directory_entry(root + root_offset, name, 0x20, first_cluster,
                        (uint32_t)file_length);
        root_offset += 32;
        for (uint32_t i = 0; i < clusters; ++i) {
            uint16_t cluster = arg == 4 ?
                (uint16_t)((i & 1u) ? 30u + i / 2u : 10u + i / 2u) :
                (uint16_t)(next_cluster + i);
            uint32_t ni = i + 1u;
            uint16_t value = ni == clusters ? 0xffffu :
                (arg == 4 ? (uint16_t)((ni & 1u) ? 30u + ni / 2u :
                                                     10u + ni / 2u) :
                            (uint16_t)(next_cluster + ni));
            for (unsigned copy = 0; copy < 2; ++copy)
                fat_entry(image, copy, cluster, value);
            size_t take = file_length - (size_t)i * SECTOR;
            if (take > SECTOR) take = SECTOR;
            size_t sector = DATA_SECTOR + (cluster - 2u);
            memcpy(image + sector * SECTOR, file_bytes + (size_t)i * SECTOR,
                   take);
        }
        next_cluster = arg == 4 ? 50u :
                       (uint16_t)(next_cluster + clusters);
        free(file_bytes);
    }
    root[root_offset] = 0;

    FILE *output = fopen(argv[1], "wb");
    if (!output || fwrite(image, 1, bytes, output) != bytes || fclose(output) != 0)
        fail(argv[1]);
    free(image);
    return 0;
}
