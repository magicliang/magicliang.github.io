#!/bin/sh
set -eu
GDB=${GDB:-gdb-multiarch}

i686-elf-readelf -h -l build/day22-user.elf > build/day22-readelf.txt
i686-elf-nm -n build/day22-user-debug.elf > build/day22-user-symbols.txt
grep -q 'Class:.*ELF32' build/day22-readelf.txt
grep -q 'Machine:.*Intel 80386' build/day22-readelf.txt
test "$(grep -c '^  LOAD' build/day22-readelf.txt)" -eq 2
test "$(i686-elf-nm -n build/day22-user-debug.elf | awk '$3 == "day22_mode" {print "0x" $1}')" = 0x40001000

"$QEMU" $QEMU_COMMON -snapshot -drive file=build/mbr.img,format=raw,if=ide \
    -display none -serial file:build/day22-fd-serial.txt -monitor stdio \
    -S -gdb tcp:127.0.0.1:1256 > build/day22-fd-qemu.txt 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
timeout -k 5 180 "$GDB" -q -nx -batch \
    -ex 'set architecture i386' \
    -ex 'set tcp connect-timeout 5' \
    -ex 'set tcp auto-retry on' \
    -ex 'file build/kernel.elf' \
    -ex 'target remote 127.0.0.1:1256' \
    -ex 'hbreak fd_exit_closed_observed if tasks[current].program_kind == 8' \
    -ex 'continue' \
    -ex 'python import gdb; v=lambda e:int(gdb.parse_and_eval(e)); assert v("tasks[current].state")==2 and all(v("tasks[current].fds[%d]"%i)==0 for i in range(8)); assert v("tasks[current].user.pages[0]") and v("tasks[current].kernel_stack"); assert v("fd_exit_closes")==6; print("PASS: faulting child closed every fd before ZOMBIE publication")' \
    -ex 'delete breakpoints' \
    -ex 'hbreak fd_demo_done' \
    -ex 'continue' \
    -ex 'python import gdb; v=lambda e:int(gdb.parse_and_eval(e)); assert v("fd_passed")==1 and v("fd_terminal_mode")==0 and v("fd_root_status")==22; assert v("fd_reaped")==5 and v("fd_exit_closes")==14 and v("fd_exit_tasks")==5; assert v("fd_pointer_faults")==5 and v("file_peak_live")==7; assert v("file_allocations")==v("file_releases")==16; assert v("free_pages")==v("fd_initial_pages"); assert all(v("tasks[%d].pid"%i)==0 and all(v("tasks[%d].fds[%d]"%(i,j))==0 for j in range(8)) for i in range(4)); print("PASS: independent/shared offsets, short EOF, limits, rollback, exit cleanup and page recovery verified")' \
    -ex 'monitor screendump build/day22-fd-screen.png -f png' \
    -ex 'disconnect' > build/day22-fd-gdb.txt 2>&1
kill "$pid" 2>/dev/null || true
wait "$pid" 2>/dev/null || true
trap - EXIT HUP INT TERM

grep -Fq 'D22 CHILD shared offset +19' build/day22-fd-serial.txt
grep -Fq 'D22 CHILD fault after shared +11' build/day22-fd-serial.txt
grep -Fq 'D22 readonly source accepted' build/day22-fd-serial.txt
grep -Fq 'D22 FD independent/shared offsets, EOF, errors and limits OK' build/day22-fd-serial.txt
grep -Fq 'FD OK mode=0 reaped=5 exit-closes=14 rollback=0' build/day22-fd-serial.txt
if grep -Fq 'D22 USER CHECK FAILED' build/day22-fd-serial.txt; then exit 1; fi

"$QEMU" $QEMU_COMMON -snapshot -drive file=build/mbr-fd-fail.img,format=raw,if=ide \
    -display none -serial file:build/day22-fd-fail-serial.txt -monitor none \
    -S -gdb tcp:127.0.0.1:1257 > build/day22-fd-fail-qemu.txt 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
timeout -k 5 180 "$GDB" -q -nx -batch \
    -ex 'set architecture i386' \
    -ex 'set tcp connect-timeout 5' \
    -ex 'set tcp auto-retry on' \
    -ex 'file build/kernel-fd-fail.elf' \
    -ex 'target remote 127.0.0.1:1257' \
    -ex 'hbreak fd_demo_done' \
    -ex 'continue' \
    -ex 'python import gdb; v=lambda e:int(gdb.parse_and_eval(e)); assert v("fd_passed")==1 and v("fd_root_status")==0; assert v("fd_spawn_rollbacks")==7 and v("fd_reaped")==2; assert v("file_allocations")==v("file_releases") and v("free_pages")==v("fd_initial_pages"); print("PASS: six ELF allocation failures plus kernel-stack failure rolled back mapped refs, then recovered")' \
    -ex 'disconnect' > build/day22-fd-fail-gdb.txt 2>&1
kill "$pid" 2>/dev/null || true
wait "$pid" 2>/dev/null || true
trap - EXIT HUP INT TERM
grep -Fq 'D22 FAIL mapped refs rollback and recovery OK' build/day22-fd-fail-serial.txt
grep -Fq 'FD OK mode=2 reaped=2 exit-closes=6 rollback=7' build/day22-fd-fail-serial.txt

"${PYTHON:-python3}" tools/check-fd-terminal.py
cat build/day22-fd-gdb.txt
cat build/day22-fd-fail-gdb.txt
cat build/day22-fd-terminal-done.txt
