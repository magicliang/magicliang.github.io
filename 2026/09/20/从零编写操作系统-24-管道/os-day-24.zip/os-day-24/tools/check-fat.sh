#!/bin/sh
set -eu
GDB=${GDB:-gdb-multiarch}
README_BYTES=$(wc -c < disk/README.TXT)

test "$(wc -c < build/fat16.bin)" -eq $((14336 * 512))
test "$(od -An -tu2 -j11 -N2 build/fat16.bin | tr -d ' ')" -eq 512
test "$(od -An -tu1 -j13 -N1 build/fat16.bin | tr -d ' ')" -eq 1
test "$(od -An -tu2 -j19 -N2 build/fat16.bin | tr -d ' ')" -eq 14336
test "$(od -An -tu2 -j22 -N2 build/fat16.bin | tr -d ' ')" -eq 56
test "$(od -An -tu4 -j28 -N4 build/fat16.bin | tr -d ' ')" -eq 2048
test "$(od -An -tu2 -j512 -N2 build/fat16.bin | tr -d ' ')" -eq 65528
test "$(od -An -tu2 -j516 -N2 build/fat16.bin | tr -d ' ')" -eq 9
test "$(od -An -tu2 -j520 -N2 build/fat16.bin | tr -d ' ')" -eq 65535
test "$(od -An -tu2 -j530 -N2 build/fat16.bin | tr -d ' ')" -eq 4

"$QEMU" $QEMU_COMMON -snapshot -drive file=build/mbr.img,format=raw,if=ide \
    -display none -serial file:build/day21-fat-serial.txt -monitor stdio \
    -S -gdb tcp:127.0.0.1:1244 > build/day21-fat-qemu.txt 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
timeout -k 5 180 "$GDB" -q -nx -batch \
    -ex 'set architecture i386' \
    -ex 'set tcp connect-timeout 5' \
    -ex 'set tcp auto-retry on' \
    -ex 'file build/kernel.elf' \
    -ex 'target remote 127.0.0.1:1244' \
    -ex 'hbreak fat_demo_done' \
    -ex 'continue' \
    -ex "python import gdb; v=lambda e:int(gdb.parse_and_eval(e)); assert v('fat_passed')==1 and v('fat_result')==$README_BYTES and v('fat_partition_start')==2048 and v('fat_partition_sectors')==14336 and v('fat_clusters')==14191; assert v('fat_file_size')==$README_BYTES and v('fat_read_bytes')==$README_BYTES and v('fat_chain_steps')==3 and v('fat_root_entries_seen')==5 and v('fat_slice_checks')==3; print('PASS: FAT16 geometry, root filtering, offset reads and non-contiguous 2->9->4 chain verified')" \
    -ex "dump binary memory build/day21-readback.txt fat_readback fat_readback+$README_BYTES" \
    -ex 'monitor screendump build/day21-screen.png -f png' \
    -ex 'hbreak keyboard_ready' \
    -ex 'continue' \
    -ex 'printf "PASS: FAT demo reaches original blocking keyboard consumer\n"' \
    -ex 'disconnect' > build/day21-fat-gdb.txt 2>&1
kill "$pid" 2>/dev/null || true
wait "$pid" 2>/dev/null || true
trap - EXIT HUP INT TERM
cmp disk/README.TXT build/day21-readback.txt

run_failure()
{
    name=$1
    image=$2
    elf=$3
    port=$4
    assertion=$5
    "$QEMU" $QEMU_COMMON -snapshot -drive file="$image",format=raw,if=ide \
        -display none -serial file:"build/day21-$name-serial.txt" -monitor stdio \
        -S -gdb tcp:127.0.0.1:"$port" > "build/day21-$name-qemu.txt" 2>&1 &
    pid=$!
    trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
    timeout -k 5 180 "$GDB" -q -nx -batch \
        -ex 'set architecture i386' \
        -ex 'set tcp connect-timeout 5' \
        -ex 'set tcp auto-retry on' \
        -ex "file $elf" \
        -ex "target remote 127.0.0.1:$port" \
        -ex 'hbreak fat_demo_done' \
        -ex 'continue' \
        -ex "python import gdb; v=lambda e:int(gdb.parse_and_eval(e)); $assertion; print('PASS: $name FAT corruption rejected')" \
        -ex 'disconnect' > "build/day21-$name-gdb.txt" 2>&1
    kill "$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
    trap - EXIT HUP INT TERM
}

run_failure loop build/mbr-fat-loop-test.img build/kernel-fat-loop.elf 1245 \
    'assert v("fat_passed")==1 and v("fat_result")==-7 and v("fat_bad_cluster")==2 and v("fat_chain_steps")==2'
run_failure short build/mbr-fat-short-test.img build/kernel-fat-short.elf 1246 \
    'assert v("fat_passed")==1 and v("fat_result")==-7 and v("fat_bad_cluster")==0xffff and v("fat_chain_steps")==2'
run_failure badbpb build/mbr-fat-badbpb-test.img build/kernel-fat-badbpb.elf 1247 \
    'assert v("fat_passed")==1 and v("fat_result")==-4 and v("fat_clusters")==0'
run_failure mirror build/mbr-fat-mirror-test.img build/kernel-fat-mirror.elf 1248 \
    'assert v("fat_passed")==1 and v("fat_result")==-8 and v("fat_bad_cluster")==9 and v("fat_chain_steps")==2'
run_failure rootbound build/mbr-fat-rootbound-test.img build/kernel-fat-rootbound.elf 1249 \
    'assert v("fat_passed")==1 and v("fat_result")==-5 and v("fat_root_entries_seen")==0'
run_failure dirhi build/mbr-fat-dirhi-test.img build/kernel-fat-dirhi.elf 1250 \
    'assert v("fat_passed")==1 and v("fat_result")==-3'
run_failure emptycluster build/mbr-fat-emptycluster-test.img build/kernel-fat-emptycluster.elf 1251 \
    'assert v("fat_passed")==1 and v("fat_result")==-7'
run_failure badcluster build/mbr-fat-badcluster-test.img build/kernel-fat-badcluster.elf 1252 \
    'assert v("fat_passed")==1 and v("fat_result")==-7 and v("fat_bad_cluster")==0xfff7 and v("fat_chain_steps")==2'
run_failure reserved build/mbr-fat-reserved-test.img build/kernel-fat-reserved.elf 1253 \
    'assert v("fat_passed")==1 and v("fat_result")==-7 and v("fat_bad_cluster")==0xfff0 and v("fat_chain_steps")==2'
run_failure outofrange build/mbr-fat-outofrange-test.img build/kernel-fat-outofrange.elf 1254 \
    'assert v("fat_passed")==1 and v("fat_result")==-7 and v("fat_bad_cluster")==0x4000 and v("fat_chain_steps")==2'
run_failure oversize build/mbr-fat-oversize-test.img build/kernel-fat-oversize.elf 1255 \
    'assert v("fat_passed")==1 and v("fat_result")==-7 and v("fat_chain_steps")==0'

grep -Fq 'D21 FAT mode=0 result=' build/day21-fat-serial.txt
grep -Fq 'FAT OK mode=0' build/day21-fat-serial.txt
grep -Fq 'D21 FAT mode=1 result=-7' build/day21-loop-serial.txt
grep -Fq 'D21 FAT mode=2 result=-7' build/day21-short-serial.txt
grep -Fq 'D21 FAT mode=3 result=-4' build/day21-badbpb-serial.txt
grep -Fq 'D21 FAT mode=4 result=-8' build/day21-mirror-serial.txt
grep -Fq 'D21 FAT mode=5 result=-5' build/day21-rootbound-serial.txt
grep -Fq 'D21 FAT mode=6 result=-3' build/day21-dirhi-serial.txt
grep -Fq 'D21 FAT mode=7 result=-7' build/day21-emptycluster-serial.txt
grep -Fq 'D21 FAT mode=8 result=-7' build/day21-badcluster-serial.txt
grep -Fq 'D21 FAT mode=9 result=-7' build/day21-reserved-serial.txt
grep -Fq 'D21 FAT mode=10 result=-7' build/day21-outofrange-serial.txt
grep -Fq 'D21 FAT mode=11 result=-7' build/day21-oversize-serial.txt
sed -n '/PASS:/p' build/day21-fat-gdb.txt
sed -n '/PASS:/p' build/day21-loop-gdb.txt
sed -n '/PASS:/p' build/day21-short-gdb.txt
sed -n '/PASS:/p' build/day21-badbpb-gdb.txt
sed -n '/PASS:/p' build/day21-mirror-gdb.txt
sed -n '/PASS:/p' build/day21-rootbound-gdb.txt
sed -n '/PASS:/p' build/day21-dirhi-gdb.txt
sed -n '/PASS:/p' build/day21-emptycluster-gdb.txt
sed -n '/PASS:/p' build/day21-badcluster-gdb.txt
sed -n '/PASS:/p' build/day21-reserved-gdb.txt
sed -n '/PASS:/p' build/day21-outofrange-gdb.txt
sed -n '/PASS:/p' build/day21-oversize-gdb.txt
