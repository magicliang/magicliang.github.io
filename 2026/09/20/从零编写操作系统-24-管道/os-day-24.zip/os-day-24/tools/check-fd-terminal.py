"""Drive the Day 22 terminal through QEMU HMP sendkey events."""
import os
import pathlib
import re
import shlex
import socket
import subprocess
import time

root = pathlib.Path("build")
monitor_path = "build/fd-terminal-monitor.sock"
pathlib.Path(monitor_path).unlink(missing_ok=True)
qemu_log = open(root / "day22-fd-terminal-qemu.txt", "w")
qemu = subprocess.Popen([
    os.environ["QEMU"], *shlex.split(os.environ["QEMU_COMMON"]),
    "-snapshot", "-drive", "file=build/mbr-fd-terminal.img,format=raw,if=ide",
    "-display", "none", "-serial", "file:build/day22-fd-terminal-serial.txt",
    "-monitor", f"unix:{monitor_path},server=on,wait=off",
    "-S", "-gdb", "tcp:127.0.0.1:1258",
], stdout=qemu_log, stderr=qemu_log)

def run_gdb(commands, label):
    script = ("set architecture i386\nset tcp connect-timeout 5\n"
              "set tcp auto-retry on\nfile build/kernel-fd-terminal.elf\n"
              "target remote 127.0.0.1:1258\n" + commands + "\ndetach\n")
    path = root / f"day22-fd-terminal-{label}.gdb"
    path.write_text(script)
    result = subprocess.run(
        [os.environ.get("GDB", "gdb-multiarch"), "-q", "-nx", "-batch", "-x", str(path)],
        text=True, capture_output=True, timeout=180)
    output = result.stdout + result.stderr
    (root / f"day22-fd-terminal-{label}.txt").write_text(output)
    assert result.returncode == 0, output
    return output

def wait_for(predicate):
    for _ in range(200):
        if predicate():
            return
        time.sleep(0.05)
    raise AssertionError("timeout")

def serial_text():
    path = root / "day22-fd-terminal-serial.txt"
    return path.read_text(errors="replace") if path.exists() else ""

try:
    wait_for(lambda: pathlib.Path(monitor_path).exists())
    monitor = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    monitor.connect(monitor_path)
    monitor.settimeout(2)
    monitor.recv(8192)

    def hmp(command):
        monitor.sendall((command + "\n").encode())
        data = b""
        while b"(qemu)" not in data:
            data += monitor.recv(8192)
        return data.decode(errors="replace")

    first = run_gdb(
        "hbreak schedule_locked_depth if tasks[current].program_kind == 11 && tasks[current].state == 3\n"
        "continue\ndelete breakpoints\n"
        "python\n"
        "v=lambda e:int(gdb.parse_and_eval(e))\n"
        "assert v('current') > 0 and v('tasks[current].trap_depth') == 1\n"
        "assert v('tasks[current].state') == 3 and not v('$eflags') & 0x200\n"
        "assert v('tasks[current].waiting_on') == v('&keyboard_waiters')\n"
        "print('BLOCK tick=%d blocks=%d slot=%d' % (v('timer_ticks'),v('keyboard_blocks'),v('current')))\n"
        "end", "blocked")
    match = re.search(r"BLOCK tick=(\d+) blocks=(\d+) slot=(\d+)", first)
    assert match, first
    blocked_tick, blocked_count = map(int, match.group(1, 2))
    time.sleep(0.2)
    second = run_gdb(
        "python\n"
        "v=lambda e:int(gdb.parse_and_eval(e))\n"
        "reader=next(i for i in range(1,4) if v('tasks[%d].program_kind'%i)==11)\n"
        "assert v('tasks[%d].state'%reader)==3 and v('tasks[%d].trap_depth'%reader)==1\n"
        "assert v('keyboard_blocks')>0\n"
        "regs=gdb.execute('monitor info registers',to_string=True)\n"
        "assert 'HLT=1' in regs and v('current')==0 and v('$eflags')&0x200\n"
        "print('IDLE tick=%d blocks=%d' % (v('timer_ticks'),v('keyboard_blocks')))\n"
        "end", "idle")
    match = re.search(r"IDLE tick=(\d+) blocks=(\d+)", second)
    assert match and int(match.group(1)) > blocked_tick
    assert int(match.group(2)) == blocked_count

    for key in ("a", "b", "ret"):
        hmp("sendkey " + key + " 20")
        time.sleep(0.1)
    wait_for(lambda: "FD OK mode=1" in serial_text())
    final = run_gdb(
        "python\n"
        "v=lambda e:int(gdb.parse_and_eval(e))\n"
        "assert v('fd_passed')==1 and v('fd_terminal_mode')==1 and v('fd_root_status')==0\n"
        "assert v('fd_terminal_blocks')>=3 and v('fd_reaped')==1\n"
        "assert v('file_allocations')==v('file_releases') and v('free_pages')==v('fd_initial_pages')-1\n"
        "assert all(v('tasks[%d].pid'%i)==0 for i in range(1,4))\n"
        "gdb.execute('monitor screendump build/day22-fd-terminal-screen.png -f png')\n"
        "print('PASS: terminal reader blocked in trap depth 1, idle PIT advanced, HMP keys produced ab\\\\n')\n"
        "end", "done")
    assert "PASS: terminal reader blocked" in final
    assert "D22 TERMINAL read ab\\n one byte at a time" in serial_text()
    print("PASS: real QEMU PS/2 input woke the fd reader without polling")
finally:
    qemu.terminate()
    qemu.wait(timeout=5)
    qemu_log.close()
