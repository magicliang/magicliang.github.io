#!/bin/sh
set -eu
GDB=${GDB:-gdb-multiarch}
"$QEMU" $QEMU_COMMON -snapshot -drive file=build/mbr.img,format=raw,if=ide \
    -display none -serial file:build/syscall-serial.txt -monitor none \
    -S -gdb tcp:127.0.0.1:1235 > build/syscall-qemu.txt 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
timeout -k 5 120 "$GDB" -q -nx -batch \
    -ex 'set architecture i386' \
    -ex 'set tcp connect-timeout 5' \
    -ex 'set tcp auto-retry on' \
    -ex 'file build/kernel.elf' \
    -ex 'target remote 127.0.0.1:1235' \
    -ex 'hbreak syscall_dispatch' \
    -ex 'continue' \
    -ex 'delete breakpoints' \
    -ex 'python import gdb,struct; v=lambda e:int(gdb.parse_and_eval(e)); m=gdb.selected_inferior(); w=lambda a,n:struct.unpack("<%dI"%n,bytes(m.read_memory(a,4*n))); f=w(w(v("$esp")+4,1)[0],19); assert f[12:16]==(128,0,v("&user_syscall_return")-v("&user_blob_start")+0x40000000,0x1b); assert f[17:19]==(0x80000000,0x23); assert f[8:12]==(0x40001100,0x22334455,19,1); assert f[4:7]==(0xaabbccdd,0x66778899,0x13579bdf); assert f[16]&0x601==0x601; assert v("$cs")==8 and v("$ss")==0x10 and not (v("$eflags")&0x200); assert v("idt[128].flags")==0xee; print("PASS: CPL3 int80 used DPL3 interrupt gate; 76-byte frame, post-INT EIP, GPR and saved IF/DF/CF verified")' \
    -ex 'hbreak syscall_demo_done' \
    -ex 'continue' \
    -ex 'delete breakpoints' \
    -ex 'python import gdb; v=lambda e:int(gdb.parse_and_eval(e)); got=[v("syscall_results[%d]"%i)&0xffffffff for i in range(13)]; want=[19,0,(-38)&0xffffffff,0,(-22)&0xffffffff,(-14)&0xffffffff,(-14)&0xffffffff,(-14)&0xffffffff,(-14)&0xffffffff,(-14)&0xffffffff,16,15,1]; assert got==want,(got,want); assert (v("syscall_count"),v("syscall_write_count"),v("syscall_yield_count"),v("syscall_error_count"))==(12,3,1,7); assert v("syscall_copy_checks")==4; assert v("syscall_irq_ticks")>=1 and v("syscall_yield_switched")==1; assert (v("syscall_yield_after")-v("syscall_yield_before"))&0xffffffff; assert (v("syscall_bad_gate_vector"),v("syscall_bad_gate_error"))==(13,0x102); assert v("syscall_bad_gate_eip")==0x40000000+v("&user_bad_gate_fault")-v("&user_blob_start"); assert v("syscall_bad_gate_survivor_growth")>0; assert v("syscall_reaped")==4 and v("free_pages")==v("syscall_initial_pages"); assert v("user_passed")==1 and v("user_reaped")==6; print("PASS: write/yield, copy-to-user and all return paths verified; bad DPL gate isolated; survivor and page recovery verified")' \
    -ex 'monitor screendump build/day17-screen.png -f png' \
    -ex 'hbreak keyboard_ready' \
    -ex 'continue' \
    -ex 'printf "PASS: syscall demo reaches original blocking keyboard consumer\n"' \
    -ex 'disconnect' > build/syscall-gdb.txt 2>&1
grep -Fq 'D17 WRITE % NO-NUL' build/syscall-serial.txt
grep -Fq 'D17 int80 write/yield and user-copy checks=4' build/syscall-serial.txt
grep -Fq 'D17 READONLY OK' build/syscall-serial.txt
grep -Fq 'D17 CROSS-PAGE' build/syscall-serial.txt
if grep -Fq 'LEAKFAIL' build/syscall-serial.txt; then
    echo 'FAIL: invalid cross-page write leaked a validated prefix' >&2
    exit 1
fi
grep -Fq 'D17 gate DPL #GP error=102' build/syscall-serial.txt
grep -Fq 'SYSCALL OK calls=12 writes=3 errors=7' build/syscall-serial.txt
grep -Fq 'PASS: CPL3 int80 used DPL3 interrupt gate' build/syscall-gdb.txt
grep -Fq 'PASS: write/yield, copy-to-user and all return paths verified' build/syscall-gdb.txt
grep -Fq 'PASS: syscall demo reaches original blocking keyboard consumer' build/syscall-gdb.txt
cat build/syscall-gdb.txt
