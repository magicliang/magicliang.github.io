#!/bin/sh
set -eu
base=$1
file_max=$2
memory_max=$3
magic=$4
version=$5
test "$version" -eq 1
symbol() { i686-elf-nm "$base.elf" | awk -v name="$1" '$3 == name { print "0x" $1 }'; }
start=$(symbol __kernel_start)
file_end=$(symbol __file_end)
end=$(symbol __kernel_end)
entry=$(i686-elf-readelf -h "$base.elf" | awk '/Entry point address:/ {print $4}')
size=$(wc -c < "$base.bin")
test "$size" -eq "$((file_end - start))"
test "$((start))" -eq 1048576
test -z "$(i686-elf-nm -u "$base.elf")"
header=$base-header.bin
if [ "$base" = build/kernel ]; then header=build/header.bin; fi
build/mkpayload "$base.bin" "$header" "$base-badmagic.bin" \
    "$base-oversized.bin" "$base-memory-oversized.bin" "$size" \
    "$file_max" "$memory_max" "$magic" "$((end - start))" \
    "$((entry - start))"
if [ "$base" = build/kernel ]; then
    mv "$base-badmagic.bin" build/header-badmagic.bin
    mv "$base-oversized.bin" build/header-oversized.bin
    mv "$base-memory-oversized.bin" build/header-memory-oversized.bin
fi
