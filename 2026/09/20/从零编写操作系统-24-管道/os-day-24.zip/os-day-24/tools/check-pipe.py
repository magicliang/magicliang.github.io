#!/usr/bin/env python3
import os
import re
import shlex
import socket
import subprocess
import time
from pathlib import Path

BUILD = Path("build")
SERIAL = BUILD / "day24-pipe-serial.txt"
QEMU_LOG = BUILD / "day24-pipe-qemu.txt"
MONITOR = BUILD / "day24-pipe-monitor.sock"
INPUT_LOG = BUILD / "day24-pipe-input.txt"
SCREEN = BUILD / "day24-pipe-screen.png"
GDB_LOG = BUILD / "day24-pipe-gdb.txt"


def serial_bytes():
    return SERIAL.read_bytes() if SERIAL.exists() else b""


def wait_for(predicate, timeout=150):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if predicate():
            return
        time.sleep(0.05)
    raise RuntimeError("timed out waiting for guest output")


def hmp(sock, command):
    sock.sendall((command + "\n").encode())
    data = b""
    while b"(qemu)" not in data:
        data += sock.recv(8192)
    return data


def key_name(ch):
    if ch == " ":
        return "spc"
    if ch == ".":
        return "dot"
    if ch == "|":
        return "shift-backslash"
    if "a" <= ch <= "z" or "0" <= ch <= "9" or ch == "-":
        return ch
    raise ValueError("unsupported test key: %r" % ch)


def send_line(sock, line, inputs):
    before = serial_bytes().count(b"# ")
    inputs.append(line)
    for ch in line:
        hmp(sock, "sendkey %s 12" % key_name(ch))
        time.sleep(0.02)
    hmp(sock, "sendkey ret 12")
    wait_for(lambda: serial_bytes().count(b"# ") > before)


def run_gdb_evidence():
    gdb = os.environ.get("GDB", "gdb-multiarch")
    proof = (
        "python v=lambda e:int(gdb.parse_and_eval(e)); "
        "c=v('pipe_creates'); r=v('pipe_releases'); rb=v('pipe_read_blocks'); "
        "wb=v('pipe_write_blocks'); eof=v('pipe_eofs'); bp=v('pipe_broken_writes'); "
        "used=v('pipe_slot.used'); readers=v('pipe_slot.readers'); writers=v('pipe_slot.writers'); "
        "print('STATE creates=%d releases=%d rblock=%d wblock=%d eof=%d broken=%d used=%d readers=%d writers=%d'%(c,r,rb,wb,eof,bp,used,readers,writers)); "
        "assert c==r==8 and rb>0 and wb>0 and eof>=2 and bp>=2; "
        "assert used==0 and readers==0 and writers==0; "
        "print('PASS: GDB observed blocking, EOF, broken-pipe wakeup and final reclamation')"
    )
    result = subprocess.run([
        gdb, "-q", "-nx", "-batch",
        "-ex", "set architecture i386",
        "-ex", "set tcp connect-timeout 5",
        "-ex", "file build/kernel-shell.elf",
        "-ex", "target remote 127.0.0.1:1265",
        "-ex", proof,
        "-ex", "detach",
    ], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30, check=True)
    GDB_LOG.write_bytes(result.stdout)
    assert b"PASS: GDB observed" in result.stdout


def main():
    for path in (SERIAL, QEMU_LOG, MONITOR, INPUT_LOG, SCREEN, GDB_LOG):
        try:
            path.unlink()
        except FileNotFoundError:
            pass
    qemu = os.environ.get("QEMU", "qemu-system-i386")
    command = [qemu] + shlex.split(os.environ["QEMU_COMMON"])
    with QEMU_LOG.open("wb") as output:
        proc = subprocess.Popen(command + [
            "-snapshot", "-drive", "file=build/mbr-shell.img,format=raw,if=ide",
            "-display", "none", "-serial", "file:" + str(SERIAL),
            "-monitor", "unix:" + str(MONITOR) + ",server=on,wait=off",
            "-gdb", "tcp:127.0.0.1:1265"
        ], stdout=output, stderr=subprocess.STDOUT)
    inputs = []
    try:
        wait_for(MONITOR.exists, 10)
        monitor = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        monitor.connect(str(MONITOR))
        monitor.settimeout(5)
        monitor.recv(8192)
        wait_for(lambda: serial_bytes().endswith(b"# "))
        for line in (
            "cat readme.txt | wc",
            "echo abc|wc",
            "cat readme.txt | head",
            "cat readme.txt | nosuch",
            "pipetest",
            "echo x || wc",
            "echo recovered",
        ):
            send_line(monitor, line, inputs)
        hmp(monitor, "screendump %s -f png" % SCREEN)
        inputs.append("exit")
        for ch in "exit":
            hmp(monitor, "sendkey %s 12" % ch)
            time.sleep(0.02)
        hmp(monitor, "sendkey ret 12")
        wait_for(lambda: b"SHELL OK" in serial_bytes())
        run_gdb_evidence()
        monitor.close()
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
    INPUT_LOG.write_text("\n".join(inputs) + "\n", encoding="utf-8")
    serial = serial_bytes().replace(b"\r\n", b"\n")
    assert b"# cat readme.txt | wc\n27 1479\n" in serial
    assert b"# echo abc|wc\n1 4\n" in serial
    head = serial.split(b"# cat readme.txt | head\n", 1)[1].split(b"# ", 1)[0]
    assert head.startswith(b"B") and b"shell: left command failed\n" in head
    missing = serial.split(b"# cat readme.txt | nosuch\n", 1)[1].split(b"# ", 1)[0]
    assert b"shell: command not found\n" in missing
    assert b"# pipetest\nPIPE API OK\n" in serial
    assert b"# echo x || wc\nshell: invalid pipeline\n" in serial
    assert b"# echo recovered\nrecovered\n" in serial
    match = re.search(rb"PIPE STATS creates=(\d+) releases=(\d+) rblock=(\d+) wblock=(\d+) eof=(\d+) broken=(\d+) read=(\d+) written=(\d+)", serial)
    assert match, serial[-1000:]
    values = [int(value) for value in match.groups()]
    creates, releases, rblock, wblock, eof, broken, read, written = values
    assert creates == releases == 8
    assert rblock > 0 and wblock > 0 and eof >= 2 and broken >= 2
    assert read < written and written >= 1479 + 4
    assert b"PANIC" not in serial and SCREEN.stat().st_size > 1000
    print("PASS: Day24 bounded pipe, backpressure, EOF, broken pipe, rollback and recovery")


if __name__ == "__main__":
    main()
