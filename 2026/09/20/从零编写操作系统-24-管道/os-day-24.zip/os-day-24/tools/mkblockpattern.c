#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    if (argc != 2) return 2;
    errno = 0;
    char *end = 0;
    unsigned long lba = strtoul(argv[1], &end, 0);
    if (errno || !end || *end || lba > UINT32_MAX) return 2;
    for (unsigned i = 0; i < 512; ++i) {
        uint8_t value = (uint8_t)((uint32_t)lba * 13u +
                                  ((uint32_t)lba >> 8) * 17u +
                                  i * 37u + (i >> 3));
        if (putchar(value) == EOF) return 1;
    }
    return fflush(stdout) == 0 ? 0 : 1;
}
