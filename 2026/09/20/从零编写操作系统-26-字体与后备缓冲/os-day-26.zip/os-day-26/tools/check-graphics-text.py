#!/usr/bin/env python3
import os
import shlex
import struct
import subprocess
import time
from pathlib import Path

BUILD = Path("build")
SERIAL = BUILD / "day26-graphics-text-serial.txt"
QEMU_LOG = BUILD / "day26-graphics-text-qemu.txt"
GDB_LOG = BUILD / "day26-graphics-text-gdb.txt"
SCREEN = BUILD / "day26-screen.png"


def stop(proc):
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()


def main():
    for path in (SERIAL, QEMU_LOG, GDB_LOG, SCREEN):
        try:
            path.unlink()
        except FileNotFoundError:
            pass

    qemu = os.environ.get("QEMU", "qemu-system-i386")
    common = shlex.split(os.environ["QEMU_COMMON"])
    with QEMU_LOG.open("wb") as output:
        proc = subprocess.Popen([qemu] + common + [
            "-drive", "file=build/mbr-graphics-text.img,format=raw,if=ide",
            "-display", "none", "-serial", "file:" + str(SERIAL),
            "-monitor", "none", "-S", "-gdb", "tcp:127.0.0.1:1267",
        ], stdout=output, stderr=subprocess.STDOUT)
    try:
        time.sleep(1)
        gdb = os.environ.get("GDB", "gdb-multiarch")
        proof = (
            "python v=lambda e:int(gdb.parse_and_eval(e)); m=gdb.selected_inferior(); "
            "assert v('graphics_text_pages')==16 and v('graphics_text_rollback_pages')==7; "
            "assert v('graphics_text_pages_after_alloc')+16==v('graphics_text_pages_before'); "
            "assert v('graphics_text_pages_after_free')==v('graphics_text_pages_before'); "
            "assert v('graphics_text_clipped_rects')==2 and v('graphics_text_rejected_rects')==2; "
            "assert v('graphics_text_clip_pixels')==204 and v('graphics_text_guard_errors')==0; "
            "assert v('graphics_text_wraps')==1 and v('graphics_text_scrolls')==8; "
            "assert v('graphics_text_cursor_column')==6 and v('graphics_text_cursor_row')==10; "
            "rows=bytes(m.read_memory(v('&graphics_text_a_rows'),8)); "
            "assert rows==bytes([0x0c,0x1e,0x33,0x33,0x3f,0x33,0x33,0]); "
            "import functools; fb=bytes(m.read_memory(0xa0000,64000)); "
            "assert fb[8]==1 and fb[10]==15 and fb[11]==15; "
            "h=functools.reduce(lambda a,b:((a^b)*16777619)&0xffffffff,fb,2166136261); "
            "assert h==v('graphics_text_surface_hash')==v('graphics_text_frame_hash'); "
            "print('STATE pages=%d rollback=%d free=%d/%d/%d clip=%d/%d pixels=%d guard=%d wrap=%d scroll=%d cursor=%d,%d hash=%#x'%(v('graphics_text_pages'),v('graphics_text_rollback_pages'),v('graphics_text_pages_before'),v('graphics_text_pages_after_alloc'),v('graphics_text_pages_after_free'),v('graphics_text_clipped_rects'),v('graphics_text_rejected_rects'),v('graphics_text_clip_pixels'),v('graphics_text_guard_errors'),v('graphics_text_wraps'),v('graphics_text_scrolls'),v('graphics_text_cursor_column'),v('graphics_text_cursor_row'),h)); "
            "print('PASS: paged backbuffer, rollback, clipping, glyph, terminal and flush verified')"
        )
        result = subprocess.run([
            gdb, "-q", "-nx", "-batch",
            "-ex", "set architecture i386",
            "-ex", "set tcp connect-timeout 5",
            "-ex", "file build/kernel-graphics-text.elf",
            "-ex", "target remote 127.0.0.1:1267",
            "-ex", "hbreak graphics_text_demo_done",
            "-ex", "continue",
            "-ex", proof,
            "-ex", "monitor screendump build/day26-screen.png -f png",
            "-ex", "detach",
        ], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
           timeout=180, check=True)
        GDB_LOG.write_bytes(result.stdout)
        assert b"PASS: paged backbuffer" in result.stdout
    finally:
        stop(proc)

    serial = SERIAL.read_bytes().replace(b"\r\n", b"\n")
    assert b"D25 VIDEO MODE 13h\n" in serial
    assert b"D04 PM OK - BootInfo v2\n" in serial
    assert b"D26 BACKBUFFER pages=16 rollback=7" in serial
    assert b"D26 CLIP clipped=2 rejected=2 pixels=204 guard=0\n" in serial
    assert b"D26 TEXT wraps=1 scrolls=8 cursor=6,10 A=c,1e,33,33,3f,33,33,0\n" in serial
    assert b"GRAPHICS TEXT OK clipped, rendered, flushed and freed\n" in serial
    assert b"PANIC" not in serial
    png = SCREEN.read_bytes()
    assert png[:8] == b"\x89PNG\r\n\x1a\n"
    assert struct.unpack(">II", png[16:24]) == (640, 400)
    print("PASS: Day26 paged backbuffer, safe clipping and 8x8 text terminal")


if __name__ == "__main__":
    main()
