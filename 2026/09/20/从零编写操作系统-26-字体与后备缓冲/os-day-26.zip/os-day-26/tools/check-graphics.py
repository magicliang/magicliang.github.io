#!/usr/bin/env python3
import os
import shlex
import struct
import subprocess
import time
from pathlib import Path

BUILD = Path("build")
SERIAL = BUILD / "day25-graphics-serial.txt"
QEMU_LOG = BUILD / "day25-graphics-qemu.txt"
GDB_LOG = BUILD / "day25-graphics-gdb.txt"
SCREEN = BUILD / "day25-screen.png"
FAIL_SERIAL = BUILD / "day25-graphics-fail-serial.txt"
FAIL_QEMU = BUILD / "day25-graphics-fail-qemu.txt"


def stop(proc):
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()


def main():
    for path in (SERIAL, QEMU_LOG, GDB_LOG, SCREEN, FAIL_SERIAL, FAIL_QEMU):
        try:
            path.unlink()
        except FileNotFoundError:
            pass
    qemu = os.environ.get("QEMU", "qemu-system-i386")
    common = shlex.split(os.environ["QEMU_COMMON"])
    command = [qemu] + common
    with QEMU_LOG.open("wb") as output:
        proc = subprocess.Popen(command + [
            "-drive", "file=build/mbr-graphics.img,format=raw,if=ide",
            "-display", "none", "-serial", "file:" + str(SERIAL),
            "-monitor", "none", "-S", "-gdb", "tcp:127.0.0.1:1266",
        ], stdout=output, stderr=subprocess.STDOUT)
    try:
        time.sleep(1)
        gdb = os.environ.get("GDB", "gdb-multiarch")
        proof = (
            "python v=lambda e:int(gdb.parse_and_eval(e)); m=gdb.selected_inferior(); "
            "assert v('graphics_base')==0xa0000 and v('graphics_width')==320 and v('graphics_height')==200; "
            "assert v('graphics_pitch')==320 and v('graphics_mode')==0x13 and v('graphics_bpp')==8; "
            "assert v('graphics_rejected')==2 and v('graphics_guard_before')==v('graphics_guard_after'); "
            "fb=bytes(m.read_memory(0xa0000,64001)); "
            "assert fb[0]==15 and fb[319]==15 and fb[320]==15 and fb[63999]==15; "
            "assert fb[32000]==15 and fb[80*320+72]==14; "
            "elig=bytes(m.read_memory(v('&eligible'),2048)); assert not (elig[20]&1); "
            "print('STATE base=%#x size=%dx%d pitch=%d mode=%#x bpp=%d pixels=%d rejected=%d guard=%d hash=%#x'%(v('graphics_base'),v('graphics_width'),v('graphics_height'),v('graphics_pitch'),v('graphics_mode'),v('graphics_bpp'),v('graphics_pixels'),v('graphics_rejected'),v('graphics_guard_after'),v('graphics_hash'))); "
            "print('PASS: BootInfo v2, framebuffer pixels, bounds and allocator exclusion verified')"
        )
        result = subprocess.run([
            gdb, "-q", "-nx", "-batch",
            "-ex", "set architecture i386",
            "-ex", "set tcp connect-timeout 5",
            "-ex", "file build/kernel-graphics.elf",
            "-ex", "target remote 127.0.0.1:1266",
            "-ex", "hbreak graphics_demo_done",
            "-ex", "continue",
            "-ex", proof,
            "-ex", "monitor screendump build/day25-screen.png -f png",
            "-ex", "detach",
        ], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
           timeout=180, check=True)
        GDB_LOG.write_bytes(result.stdout)
        assert b"PASS: BootInfo v2" in result.stdout
    finally:
        stop(proc)

    serial = SERIAL.read_bytes().replace(b"\r\n", b"\n")
    assert b"D25 VIDEO MODE 13h\n" in serial
    assert b"D04 PM OK - BootInfo v2\n" in serial
    assert b"D25 GRAPHICS base=0xa0000 320x200 pitch=320 bpp=8" in serial
    assert b"GRAPHICS OK framebuffer reserved and bounds checked\n" in serial
    assert b"PANIC" not in serial
    png = SCREEN.read_bytes()
    assert png[:8] == b"\x89PNG\r\n\x1a\n"
    # QEMU doubles the legacy 320x200 scanout in its screendump output.
    assert struct.unpack(">II", png[16:24]) == (640, 400)

    with FAIL_QEMU.open("wb") as output:
        failed = subprocess.Popen(command + [
            "-drive", "file=build/mbr-graphics-fail.img,format=raw,if=ide",
            "-display", "none", "-serial", "file:" + str(FAIL_SERIAL),
            "-monitor", "none",
        ], stdout=output, stderr=subprocess.STDOUT)
    time.sleep(3)
    stop(failed)
    failure = FAIL_SERIAL.read_bytes().replace(b"\r\n", b"\n")
    assert b"D25 VIDEO FAIL\n" in failure
    assert b"D04 PM OK" not in failure and b"D25 GRAPHICS" not in failure
    print("PASS: Day25 Mode 13h, BootInfo v2, visible pixels, bounds and fail-closed setup")


if __name__ == "__main__":
    main()
