#include <stdint.h>
#include "bootinfo.h"
#include "console.h"
#include "graphics.h"
#include "font8x8_basic.h"
#include "memory.h"
#include "runtime.h"

volatile uint32_t graphics_base, graphics_width, graphics_height;
volatile uint32_t graphics_pitch, graphics_mode, graphics_bpp;
volatile uint32_t graphics_pixels, graphics_rejected, graphics_hash;
volatile uint32_t graphics_guard_before, graphics_guard_after;

static int put_pixel(const struct bootinfo *info, unsigned x, unsigned y,
                     uint8_t color)
{
    if (x >= info->display_width || y >= info->display_height) {
        ++graphics_rejected;
        return 0;
    }
    volatile uint8_t *frame = (volatile uint8_t *)(uintptr_t)info->video;
    frame[y * info->display_pitch + x] = color;
    ++graphics_pixels;
    return 1;
}

static void fill_rect(const struct bootinfo *info, unsigned x, unsigned y,
                      unsigned width, unsigned height, uint8_t color)
{
    for (unsigned row = 0; row < height; ++row)
        for (unsigned column = 0; column < width; ++column)
            KASSERT(put_pixel(info, x + column, y + row, color));
}

__attribute__((noinline, noipa)) void graphics_demo_done(void)
{ __asm__ volatile("nop" ::: "memory"); }

_Noreturn void graphics_demo(const struct bootinfo *info)
{
    KASSERT(info && info->magic == 0x31495442 && info->version == 2 &&
            info->size == sizeof(*info));
    KASSERT(info->video == 0xa0000 && info->display_width == 320 &&
            info->display_height == 200 && info->display_pitch == 320 &&
            info->display_mode == 0x13 && info->display_depth == 8);
    KASSERT(!page_free(info->video));

    graphics_base = info->video;
    graphics_width = info->display_width;
    graphics_height = info->display_height;
    graphics_pitch = info->display_pitch;
    graphics_mode = info->display_mode;
    graphics_bpp = info->display_depth;

    volatile uint8_t *frame = (volatile uint8_t *)(uintptr_t)info->video;
    graphics_guard_before = frame[64000];
    for (unsigned y = 0; y < info->display_height; ++y)
        for (unsigned x = 0; x < info->display_width; ++x)
            KASSERT(put_pixel(info, x, y,
                    (uint8_t)(1 + ((x / 20 + y / 16) % 5))));

    fill_rect(info, 24, 28, 272, 144, 1);
    fill_rect(info, 30, 34, 260, 132, 3);
    fill_rect(info, 44, 52, 232, 96, 9);
    fill_rect(info, 56, 64, 208, 72, 0);
    fill_rect(info, 72, 80, 176, 40, 14);
    fill_rect(info, 88, 92, 144, 16, 15);

    for (unsigned x = 0; x < 320; ++x) {
        KASSERT(put_pixel(info, x, 0, 15));
        KASSERT(put_pixel(info, x, 199, 15));
    }
    for (unsigned y = 0; y < 200; ++y) {
        KASSERT(put_pixel(info, 0, y, 15));
        KASSERT(put_pixel(info, 319, y, 15));
    }
    KASSERT(!put_pixel(info, 320, 0, 12));
    KASSERT(!put_pixel(info, 0, 200, 12));
    graphics_guard_after = frame[64000];
    KASSERT(graphics_guard_after == graphics_guard_before &&
            graphics_rejected == 2);

    uint32_t hash = 2166136261u;
    for (unsigned i = 0; i < 64000; ++i)
        hash = (hash ^ frame[i]) * 16777619u;
    graphics_hash = hash;
    kprintf("D25 GRAPHICS base=%p 320x200 pitch=320 bpp=8 pixels=%u rejected=%u hash=%x\n",
            (void *)graphics_base, graphics_pixels, graphics_rejected,
            graphics_hash);
    kprintf("GRAPHICS OK framebuffer reserved and bounds checked\n");
    graphics_demo_done();
    for (;;) __asm__ volatile("sti; hlt; cli" ::: "memory");
}

#define SURFACE_PAGES 16u
#define SURFACE_BYTES (SURFACE_PAGES * PAGE_BYTES)
#define TEXT_COLUMNS 40u
#define TEXT_ROWS 25u
#define SURFACE_GUARD 0xa5u

struct surface {
    uint32_t pages[SURFACE_PAGES];
    uint32_t page_count;
    uint32_t width;
    uint32_t height;
    uint32_t pitch;
};

struct text_terminal {
    uint8_t cells[TEXT_ROWS][TEXT_COLUMNS];
    uint8_t colors[TEXT_ROWS][TEXT_COLUMNS];
    uint32_t column;
    uint32_t row;
    uint32_t wraps;
    uint32_t scrolls;
    uint8_t foreground;
    uint8_t background;
};

volatile uint32_t graphics_text_pages_before, graphics_text_pages_after_alloc;
volatile uint32_t graphics_text_pages_after_free, graphics_text_pages;
volatile uint32_t graphics_text_rollback_pages;
volatile uint32_t graphics_text_clipped_rects, graphics_text_rejected_rects;
volatile uint32_t graphics_text_clip_pixels, graphics_text_guard_errors;
volatile uint32_t graphics_text_wraps, graphics_text_scrolls;
volatile uint32_t graphics_text_cursor_column, graphics_text_cursor_row;
volatile uint32_t graphics_text_surface_hash, graphics_text_frame_hash;
volatile uint8_t graphics_text_a_rows[8];

static uint8_t *surface_byte(struct surface *surface, uint32_t offset)
{
    KASSERT(offset < SURFACE_BYTES);
    return (uint8_t *)(uintptr_t)surface->pages[offset / PAGE_BYTES] +
           offset % PAGE_BYTES;
}

static int surface_create(struct surface *surface, uint32_t fail_after)
{
    memset(surface, 0, sizeof(*surface));
    surface->width = 320;
    surface->height = 200;
    surface->pitch = 320;
    for (uint32_t i = 0; i < SURFACE_PAGES; ++i) {
        uint32_t page = i == fail_after ? 0 : page_alloc();
        if (!page) {
            graphics_text_rollback_pages = surface->page_count;
            while (surface->page_count) {
                --surface->page_count;
                KASSERT(page_free(surface->pages[surface->page_count]));
                surface->pages[surface->page_count] = 0;
            }
            return 0;
        }
        surface->pages[surface->page_count++] = page;
    }
    for (uint32_t i = 0; i < SURFACE_BYTES; ++i)
        *surface_byte(surface, i) = SURFACE_GUARD;
    return 1;
}

static void surface_destroy(struct surface *surface)
{
    while (surface->page_count) {
        --surface->page_count;
        KASSERT(page_free(surface->pages[surface->page_count]));
        surface->pages[surface->page_count] = 0;
    }
}

static uint32_t surface_fill_rect(struct surface *surface, int32_t x,
                                  int32_t y, uint32_t width,
                                  uint32_t height, uint8_t color)
{
    int64_t left = x, top = y;
    int64_t right = left + (int64_t)width;
    int64_t bottom = top + (int64_t)height;
    if (!width || !height || right <= 0 || bottom <= 0 ||
        left >= (int64_t)surface->width || top >= (int64_t)surface->height) {
        ++graphics_text_rejected_rects;
        return 0;
    }
    int clipped = left < 0 || top < 0 ||
                  right > (int64_t)surface->width ||
                  bottom > (int64_t)surface->height;
    if (left < 0) left = 0;
    if (top < 0) top = 0;
    if (right > (int64_t)surface->width) right = surface->width;
    if (bottom > (int64_t)surface->height) bottom = surface->height;
    if (clipped) ++graphics_text_clipped_rects;

    uint32_t written = 0;
    for (int64_t row = top; row < bottom; ++row)
        for (int64_t column = left; column < right; ++column) {
            uint32_t offset = (uint32_t)row * surface->pitch +
                              (uint32_t)column;
            *surface_byte(surface, offset) = color;
            ++written;
        }
    return written;
}

static const uint8_t *glyph_for(uint8_t character)
{
    if (character < 0x20 || character > 0x7e) character = '?';
    return font8x8_basic[character - 0x20];
}

static void surface_draw_glyph(struct surface *surface, int32_t x, int32_t y,
                               uint8_t character, uint8_t foreground,
                               uint8_t background)
{
    const uint8_t *glyph = glyph_for(character);
    for (int32_t row = 0; row < 8; ++row)
        for (int32_t column = 0; column < 8; ++column)
            surface_fill_rect(surface, x + column, y + row, 1, 1,
                glyph[row] & (1u << column) ? foreground : background);
}

static void terminal_clear(struct text_terminal *terminal)
{
    memset(terminal->cells, ' ', sizeof(terminal->cells));
    memset(terminal->colors, terminal->foreground, sizeof(terminal->colors));
    terminal->column = 0;
    terminal->row = 0;
}

static void terminal_init(struct text_terminal *terminal)
{
    memset(terminal, 0, sizeof(*terminal));
    terminal->foreground = 15;
    terminal->background = 1;
    terminal_clear(terminal);
}

static void terminal_newline(struct text_terminal *terminal)
{
    terminal->column = 0;
    ++terminal->row;
    if (terminal->row < TEXT_ROWS) return;
    memmove(terminal->cells[0], terminal->cells[1],
            (TEXT_ROWS - 1) * TEXT_COLUMNS);
    memmove(terminal->colors[0], terminal->colors[1],
            (TEXT_ROWS - 1) * TEXT_COLUMNS);
    memset(terminal->cells[TEXT_ROWS - 1], ' ', TEXT_COLUMNS);
    memset(terminal->colors[TEXT_ROWS - 1], terminal->foreground,
           TEXT_COLUMNS);
    terminal->row = TEXT_ROWS - 1;
    ++terminal->scrolls;
}

static void terminal_putc(struct text_terminal *terminal, uint8_t character)
{
    if (character == '\n') {
        terminal_newline(terminal);
        return;
    }
    if (character == '\r') {
        terminal->column = 0;
        return;
    }
    if (character == '\b') {
        if (terminal->column) --terminal->column;
        else if (terminal->row) {
            --terminal->row;
            terminal->column = TEXT_COLUMNS - 1;
        }
        terminal->cells[terminal->row][terminal->column] = ' ';
        return;
    }
    if (character < 0x20 || character > 0x7e) character = '?';
    terminal->cells[terminal->row][terminal->column] = character;
    terminal->colors[terminal->row][terminal->column] = terminal->foreground;
    ++terminal->column;
    if (terminal->column == TEXT_COLUMNS) {
        ++terminal->wraps;
        terminal_newline(terminal);
    }
}

static void terminal_puts(struct text_terminal *terminal, const char *text)
{
    while (*text) terminal_putc(terminal, (uint8_t)*text++);
}

static void terminal_draw(struct surface *surface,
                          const struct text_terminal *terminal)
{
    for (uint32_t row = 0; row < TEXT_ROWS; ++row)
        for (uint32_t column = 0; column < TEXT_COLUMNS; ++column)
            surface_draw_glyph(surface, (int32_t)(column * 8),
                (int32_t)(row * 8), terminal->cells[row][column],
                terminal->colors[row][column], terminal->background);
    surface_fill_rect(surface, (int32_t)(terminal->column * 8),
        (int32_t)(terminal->row * 8 + 7), 8, 1, 14);
}

static uint32_t surface_hash(struct surface *surface)
{
    uint32_t hash = 2166136261u;
    for (uint32_t i = 0; i < 64000; ++i)
        hash = (hash ^ *surface_byte(surface, i)) * 16777619u;
    return hash;
}

static uint32_t frame_hash(volatile uint8_t *frame)
{
    uint32_t hash = 2166136261u;
    for (uint32_t i = 0; i < 64000; ++i)
        hash = (hash ^ frame[i]) * 16777619u;
    return hash;
}

static void surface_flush(struct surface *surface, volatile uint8_t *frame)
{
    for (uint32_t i = 0; i < 64000; ++i)
        frame[i] = *surface_byte(surface, i);
}

__attribute__((noinline, noipa)) void graphics_text_demo_done(void)
{ __asm__ volatile("nop" ::: "memory"); }

_Noreturn void graphics_text_demo(const struct bootinfo *info)
{
    static const uint8_t expected_a[8] =
        {0x0c, 0x1e, 0x33, 0x33, 0x3f, 0x33, 0x33, 0x00};
    KASSERT(info && info->magic == 0x31495442 && info->version == 2 &&
            info->size == sizeof(*info));
    KASSERT(info->video == 0xa0000 && info->display_width == 320 &&
            info->display_height == 200 && info->display_pitch == 320 &&
            info->display_mode == 0x13 && info->display_depth == 8);
    KASSERT(!page_free(info->video));

    struct surface surface;
    graphics_text_pages_before = page_free_count();
    KASSERT(!surface_create(&surface, 7));
    KASSERT(graphics_text_rollback_pages == 7 &&
            page_free_count() == graphics_text_pages_before);
    KASSERT(surface_create(&surface, UINT32_MAX));
    graphics_text_pages = surface.page_count;
    graphics_text_pages_after_alloc = page_free_count();
    KASSERT(surface.page_count == SURFACE_PAGES &&
            graphics_text_pages_after_alloc + SURFACE_PAGES ==
            graphics_text_pages_before);

    KASSERT(surface_fill_rect(&surface, (-2147483647 - 1), 0, 16, 16, 2) == 0);
    KASSERT(surface_fill_rect(&surface, 300, 190, UINT32_MAX,
                              UINT32_MAX, 2) == 200);
    KASSERT(surface_fill_rect(&surface, 400, 300, 16, 16, 2) == 0);
    KASSERT(surface_fill_rect(&surface, 318, 198, 8, 8, 2) == 4);
    graphics_text_clip_pixels = 204;
    KASSERT(graphics_text_clipped_rects == 2 &&
            graphics_text_rejected_rects == 2);

    struct text_terminal terminal;
    terminal_init(&terminal);
    terminal_puts(&terminal,
        "0123456789012345678901234567890123456789ABCDE\n");
    for (uint32_t i = 0; i < 30; ++i)
        terminal_puts(&terminal, "scroll probe line\n");
    KASSERT(terminal.wraps == 1 && terminal.scrolls > 5);
    terminal_clear(&terminal);
    terminal_puts(&terminal, "DAY 26 GRAPHICS TERMINAL\n");
    terminal_puts(&terminal, "A GLYPH: 8X8 LSB-FIRST\n");
    terminal_puts(&terminal, "SURFACE: 16 PHYSICAL PAGES\n");
    terminal_puts(&terminal, "CLIP: SIGNED HALF-OPEN RECTS\n");
    terminal_puts(&terminal, "WRAP AND SCROLL KEEP CELL STATE\n\n");
    terminal_puts(&terminal, " !\"#$%&'()*+,-./0123456789:;<=>?\n");
    terminal_puts(&terminal, "@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_\n");
    terminal_puts(&terminal, "`abcdefghijklmnopqrstuvwxyz{|}~\n\n");
    terminal_puts(&terminal, "CURSOR");
    graphics_text_wraps = terminal.wraps;
    graphics_text_scrolls = terminal.scrolls;
    graphics_text_cursor_column = terminal.column;
    graphics_text_cursor_row = terminal.row;

    terminal_draw(&surface, &terminal);
    for (uint32_t i = 0; i < 8; ++i) {
        graphics_text_a_rows[i] = glyph_for('A')[i];
        KASSERT(graphics_text_a_rows[i] == expected_a[i]);
    }
    for (uint32_t i = 64000; i < SURFACE_BYTES; ++i)
        if (*surface_byte(&surface, i) != SURFACE_GUARD)
            ++graphics_text_guard_errors;
    KASSERT(graphics_text_guard_errors == 0);

    graphics_text_surface_hash = surface_hash(&surface);
    volatile uint8_t *frame = (volatile uint8_t *)(uintptr_t)info->video;
    surface_flush(&surface, frame);
    graphics_text_frame_hash = frame_hash(frame);
    KASSERT(graphics_text_frame_hash == graphics_text_surface_hash);
    surface_destroy(&surface);
    graphics_text_pages_after_free = page_free_count();
    KASSERT(graphics_text_pages_after_free == graphics_text_pages_before);

    kprintf("D26 BACKBUFFER pages=%u rollback=%u free=%u/%u/%u\n",
            graphics_text_pages, graphics_text_rollback_pages,
            graphics_text_pages_before, graphics_text_pages_after_alloc,
            graphics_text_pages_after_free);
    kprintf("D26 CLIP clipped=%u rejected=%u pixels=%u guard=%u\n",
            graphics_text_clipped_rects, graphics_text_rejected_rects,
            graphics_text_clip_pixels, graphics_text_guard_errors);
    kprintf("D26 TEXT wraps=%u scrolls=%u cursor=%u,%u A=%x,%x,%x,%x,%x,%x,%x,%x\n",
            graphics_text_wraps, graphics_text_scrolls,
            graphics_text_cursor_column, graphics_text_cursor_row,
            graphics_text_a_rows[0], graphics_text_a_rows[1],
            graphics_text_a_rows[2], graphics_text_a_rows[3],
            graphics_text_a_rows[4], graphics_text_a_rows[5],
            graphics_text_a_rows[6], graphics_text_a_rows[7]);
    kprintf("D26 FRAME hash=%x\n", graphics_text_frame_hash);
    kprintf("GRAPHICS TEXT OK clipped, rendered, flushed and freed\n");
    graphics_text_demo_done();
    for (;;) __asm__ volatile("sti; hlt; cli" ::: "memory");
}
