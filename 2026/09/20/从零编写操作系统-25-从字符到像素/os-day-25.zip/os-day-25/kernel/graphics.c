#include <stdint.h>
#include "bootinfo.h"
#include "console.h"
#include "graphics.h"
#include "memory.h"
#include "runtime.h"

volatile uint32_t graphics_base, graphics_width, graphics_height;
volatile uint32_t graphics_pitch, graphics_mode, graphics_bpp;
volatile uint32_t graphics_pixels, graphics_rejected, graphics_hash;
volatile uint32_t graphics_guard_before, graphics_guard_after;

static int put_pixel(const struct bootinfo *info, unsigned x, unsigned y,
                     uint8_t color)
{
    if (x >= info->display_width || y >= info->display_height) {
        ++graphics_rejected;
        return 0;
    }
    volatile uint8_t *frame = (volatile uint8_t *)(uintptr_t)info->video;
    frame[y * info->display_pitch + x] = color;
    ++graphics_pixels;
    return 1;
}

static void fill_rect(const struct bootinfo *info, unsigned x, unsigned y,
                      unsigned width, unsigned height, uint8_t color)
{
    for (unsigned row = 0; row < height; ++row)
        for (unsigned column = 0; column < width; ++column)
            KASSERT(put_pixel(info, x + column, y + row, color));
}

__attribute__((noinline, noipa)) void graphics_demo_done(void)
{ __asm__ volatile("nop" ::: "memory"); }

_Noreturn void graphics_demo(const struct bootinfo *info)
{
    KASSERT(info && info->magic == 0x31495442 && info->version == 2 &&
            info->size == sizeof(*info));
    KASSERT(info->video == 0xa0000 && info->display_width == 320 &&
            info->display_height == 200 && info->display_pitch == 320 &&
            info->display_mode == 0x13 && info->display_depth == 8);
    KASSERT(!page_free(info->video));

    graphics_base = info->video;
    graphics_width = info->display_width;
    graphics_height = info->display_height;
    graphics_pitch = info->display_pitch;
    graphics_mode = info->display_mode;
    graphics_bpp = info->display_depth;

    volatile uint8_t *frame = (volatile uint8_t *)(uintptr_t)info->video;
    graphics_guard_before = frame[64000];
    for (unsigned y = 0; y < info->display_height; ++y)
        for (unsigned x = 0; x < info->display_width; ++x)
            KASSERT(put_pixel(info, x, y,
                    (uint8_t)(1 + ((x / 20 + y / 16) % 5))));

    fill_rect(info, 24, 28, 272, 144, 1);
    fill_rect(info, 30, 34, 260, 132, 3);
    fill_rect(info, 44, 52, 232, 96, 9);
    fill_rect(info, 56, 64, 208, 72, 0);
    fill_rect(info, 72, 80, 176, 40, 14);
    fill_rect(info, 88, 92, 144, 16, 15);

    for (unsigned x = 0; x < 320; ++x) {
        KASSERT(put_pixel(info, x, 0, 15));
        KASSERT(put_pixel(info, x, 199, 15));
    }
    for (unsigned y = 0; y < 200; ++y) {
        KASSERT(put_pixel(info, 0, y, 15));
        KASSERT(put_pixel(info, 319, y, 15));
    }
    KASSERT(!put_pixel(info, 320, 0, 12));
    KASSERT(!put_pixel(info, 0, 200, 12));
    graphics_guard_after = frame[64000];
    KASSERT(graphics_guard_after == graphics_guard_before &&
            graphics_rejected == 2);

    uint32_t hash = 2166136261u;
    for (unsigned i = 0; i < 64000; ++i)
        hash = (hash ^ frame[i]) * 16777619u;
    graphics_hash = hash;
    kprintf("D25 GRAPHICS base=%p 320x200 pitch=320 bpp=8 pixels=%u rejected=%u hash=%x\n",
            (void *)graphics_base, graphics_pixels, graphics_rejected,
            graphics_hash);
    kprintf("GRAPHICS OK framebuffer reserved and bounds checked\n");
    graphics_demo_done();
    for (;;) __asm__ volatile("sti; hlt; cli" ::: "memory");
}
