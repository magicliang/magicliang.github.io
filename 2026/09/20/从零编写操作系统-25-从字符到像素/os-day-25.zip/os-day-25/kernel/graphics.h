#ifndef GRAPHICS_H
#define GRAPHICS_H

struct bootinfo;
_Noreturn void graphics_demo(const struct bootinfo *info);

#endif
