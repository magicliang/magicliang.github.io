#!/usr/bin/env python3
"""Drive the Day 29 FAT-loaded Shell through the bounded window terminal."""
import hashlib
import os
import shlex
import socket
import subprocess
import time
from pathlib import Path

BUILD = Path("build")
QEMU = os.environ.get("QEMU", "qemu-system-i386")
GDB = os.environ.get("GDB", "gdb-multiarch")
COMMON = shlex.split(os.environ["QEMU_COMMON"])
PORT = 1272
SERIAL = BUILD / "day29-window-shell-serial.txt"
QLOG = BUILD / "day29-window-shell-qemu.txt"
MONITOR = BUILD / "day29-window-shell-monitor.sock"
SCREEN = BUILD / "day29-window-shell-screen.png"


def stop(process):
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()


def connect_monitor():
    monitor = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    for _ in range(200):
        try:
            monitor.connect(str(MONITOR))
            break
        except (FileNotFoundError, ConnectionRefusedError):
            time.sleep(.05)
    else:
        raise AssertionError("QEMU monitor did not appear")
    monitor.settimeout(5)
    monitor.recv(8192)
    return monitor


def hmp(monitor, command):
    monitor.sendall((command + "\n").encode())
    output = b""
    while b"(qemu)" not in output:
        output += monitor.recv(8192)
    return output.decode(errors="replace")


def key_name(character):
    if character == " ":
        return "spc"
    if character == ".":
        return "dot"
    if character == "|":
        return "shift-backslash"
    if "a" <= character <= "z" or "0" <= character <= "9" or character == "-":
        return character
    raise ValueError("unsupported key %r" % character)


def send_line(monitor, line):
    for character in line:
        hmp(monitor, "sendkey %s 20" % key_name(character))
        time.sleep(.03)
    hmp(monitor, "sendkey ret 20")


def gdb_run(commands, output_name, timeout=150):
    script = (
        "set architecture i386\n"
        "set tcp connect-timeout 5\n"
        "set tcp auto-retry on\n"
        "file build/kernel-window-shell.elf\n"
        f"target remote 127.0.0.1:{PORT}\n"
        + commands + "\n"
    )
    script_path = BUILD / (output_name + ".cmd")
    script_path.write_text(script)
    result = subprocess.run(
        [GDB, "-q", "-nx", "-batch", "-x", str(script_path)],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        timeout=timeout, check=False,
    )
    (BUILD / output_name).write_text(result.stdout)
    assert result.returncode == 0, result.stdout
    return result.stdout


def read_counter(expression):
    output = gdb_run(
        "python\nprint(int(gdb.parse_and_eval('%s')))\nend\ndetach" % expression,
        "day29-counter-gdb.txt", timeout=30,
    )
    for line in reversed(output.splitlines()):
        if line.isdigit():
            return int(line)
    raise AssertionError(output)


def wait_counter(expression, expected, timeout=30):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if read_counter(expression) >= expected:
            return
        time.sleep(.1)
    diagnostic = {name: read_counter(name) for name in (
        "shell_prompts", "keyboard_irqs", "keyboard_routed",
        "keyboard_bytes", "graphics_window_shell_keyboard_chars",
        "terminal_input_bytes", "terminal_read_blocks")}
    raise AssertionError("timed out waiting for %s >= %d" %
                         (expression, expected) + ": " + repr(diagnostic))


def main():
    for path in (SERIAL, QLOG, MONITOR, SCREEN):
        path.unlink(missing_ok=True)
    qlog = QLOG.open("wb")
    process = subprocess.Popen([
        QEMU, *COMMON, "-snapshot",
        "-drive", "file=build/mbr-window-shell.img,format=raw,if=ide",
        "-display", "none", "-serial", "file:" + str(SERIAL),
        "-monitor", "unix:" + str(MONITOR) + ",server=on,wait=off",
        "-S", "-gdb", f"tcp:127.0.0.1:{PORT}",
    ], stdout=qlog, stderr=subprocess.STDOUT)
    monitor = connect_monitor()
    try:
        elf = (BUILD / "day23-user.elf").read_bytes()
        elf_sha = hashlib.sha256(elf).hexdigest()
        initial = gdb_run(
            "hbreak disk_spawn_published\ncontinue\n"
            "hbreak shell_prompt_observed\ncontinue\n"
            "python\n"
            "v=lambda x:int(gdb.parse_and_eval(x))\n"
            "assert v('disk_exec_size')==%d\n" % len(elf) +
            "assert v('shell_prompts')==1 and v('shell_user_cs')==0x1b\n"
            "assert v('shell_user_eip')>=0x40000000 and v('shell_user_eip')<0x40002000\n"
            "assert v('file_live_count()')==2 and v('file_total_refs()')==3\n"
            "print('LOADED size=%d sha256=%s cs=%%x eip=%%x prompts=%%d refs=%%d' %% "
            "(v('shell_user_cs'),v('shell_user_eip'),v('shell_prompts'),v('file_total_refs()')))\n" %
            (len(elf), elf_sha) +
            "end\ndelete breakpoints\ndetach",
            "day29-window-shell-load-gdb.txt",
        )
        assert "sha256=" + elf_sha in initial

        send_line(monitor, "echo hello")
        wait_counter("shell_prompts", 2)

        send_line(monitor, "cat readme.txt")
        for command in ("mouse_move -80 60", "mouse_move 40 30",
                        "mouse_move -30 -20", "mouse_move 25 15"):
            hmp(monitor, command)
            time.sleep(.04)
        wait_counter("shell_prompts", 3)

        send_line(monitor, "cat readme.txt | wc")
        for command in ("mouse_move 15 -10", "mouse_move -10 8"):
            hmp(monitor, command)
        wait_counter("shell_prompts", 4)

        final_commands = (
            "hbreak graphics_window_shell_done\ncontinue\n"
            "python\n"
            "v=lambda x:int(gdb.parse_and_eval(x))\n"
            "mem=lambda a,n:bytes(gdb.selected_inferior().read_memory(a,n))\n"
            "base=v('&graphics_window_shell_log[0]')\n"
            "log=mem(base,v('graphics_window_shell_log_length'))\n"
            "assert b'# echo hello\\nhello\\n' in log\n"
            "assert b'# cat readme.txt\\n' in log\n"
            "assert b'# cat readme.txt | wc\\n27 1479\\n' in log\n"
            "assert log.endswith(b'# exit\\n')\n"
            "assert v('terminal_output_high_water')==64\n"
            "assert v('terminal_write_blocks')>0 and v('terminal_read_blocks')>0\n"
            "assert v('terminal_output_bytes')==v('terminal_output_consumed')\n"
            "assert v('terminal_input_dropped')==0\n"
            "assert v('graphics_window_shell_mouse_packets')>=6\n"
            "assert v('graphics_window_shell_redraws')>v('graphics_window_shell_mouse_packets')\n"
            "assert v('pipe_creates')==v('pipe_releases') and v('pipe_creates')>=1\n"
            "assert v('pipe_read_blocks')>0 and v('pipe_write_blocks')>0\n"
            "assert v('file_live_count()')==0 and v('file_total_refs()')==0\n"
            "print('FINAL input=%d output=%d high=%d/%d block=%d/%d mouse=%d redraws=%d pipe=%d/%d pblock=%d/%d log=%d' % "
            "(v('terminal_input_bytes'),v('terminal_output_bytes'),v('terminal_input_high_water'),"
            "v('terminal_output_high_water'),v('terminal_read_blocks'),v('terminal_write_blocks'),"
            "v('graphics_window_shell_mouse_packets'),v('graphics_window_shell_redraws'),"
            "v('pipe_creates'),v('pipe_releases'),v('pipe_read_blocks'),v('pipe_write_blocks'),"
            "v('graphics_window_shell_log_length')))\n"
            "end\nmonitor screendump build/day29-window-shell-screen.png -f png\n"
            "delete breakpoints\ndetach"
        )
        final_script = BUILD / "day29-window-shell-final-gdb.cmd"
        final_script.write_text(
            "set architecture i386\nset tcp connect-timeout 5\n"
            "set tcp auto-retry on\nfile build/kernel-window-shell.elf\n"
            f"target remote 127.0.0.1:{PORT}\n" + final_commands + "\n"
        )
        final_proc = subprocess.Popen(
            [GDB, "-q", "-nx", "-batch", "-x", str(final_script)],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        )
        time.sleep(.5)
        send_line(monitor, "exit")
        final_output, _ = final_proc.communicate(timeout=150)
        (BUILD / "day29-window-shell-gdb.txt").write_text(final_output)
        assert final_proc.returncode == 0, final_output
        assert "FINAL input=" in final_output
        deadline = time.time() + 10
        while time.time() < deadline:
            if SERIAL.exists() and b"WINDOW SHELL OK" in SERIAL.read_bytes():
                break
            time.sleep(.05)
        else:
            raise AssertionError("final serial success marker missing")
        serial = SERIAL.read_bytes().replace(b"\r\n", b"\n")
        assert b"D29 TERMINAL" in serial and b"D29 UI" in serial
        assert b"D29 ELF" in serial and b"PANIC" not in serial
        png = SCREEN.read_bytes()
        assert png[:8] == b"\x89PNG\r\n\x1a\n" and len(png) > 1000
    finally:
        monitor.close()
        stop(process)
        qlog.close()
    print("PASS: Day29 FAT Shell, bounded window terminal, pipe and responsive UI")


if __name__ == "__main__":
    main()
