#!/usr/bin/env python3
"""Drive the Day 27 PS/2 mouse through QEMU HMP and inspect IRQ12."""
import os
import shlex
import socket
import subprocess
import threading
import time
from pathlib import Path

BUILD = Path("build")
QEMU = os.environ.get("QEMU", "qemu-system-i386")
GDB = os.environ.get("GDB", "gdb-multiarch")
COMMON = shlex.split(os.environ["QEMU_COMMON"])


def stop(process):
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()


def connect_monitor(path):
    monitor = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    for _ in range(100):
        try:
            monitor.connect(path)
            break
        except (FileNotFoundError, ConnectionRefusedError):
            time.sleep(.05)
    else:
        raise AssertionError("QEMU monitor did not appear")
    monitor.settimeout(3)
    monitor.recv(8192)
    return monitor


def hmp(monitor, command):
    monitor.sendall((command + "\n").encode())
    output = b""
    while b"(qemu)" not in output:
        output += monitor.recv(8192)
    return output.decode(errors="replace")


def gdb(image, port, commands, output, timeout=30):
    script = (
        "set architecture i386\n"
        "set tcp connect-timeout 5\n"
        "set tcp auto-retry on\n"
        f"file build/kernel-{image}.elf\n"
        f"target remote 127.0.0.1:{port}\n"
        + commands + "\ndetach\n"
    )
    script_path = BUILD / (output + ".cmd")
    script_path.write_text(script)
    result = subprocess.run(
        [GDB, "-q", "-nx", "-batch", "-x", str(script_path)], text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        timeout=timeout, check=False,
    )
    (BUILD / output).write_text(result.stdout)
    assert result.returncode == 0, result.stdout
    return result.stdout


def launch(image, port, label):
    socket_path = str(BUILD / f"day27-{label}-monitor.sock")
    Path(socket_path).unlink(missing_ok=True)
    serial = BUILD / f"day27-{label}-serial.txt"
    qemu_log = (BUILD / f"day27-{label}-qemu.txt").open("wb")
    process = subprocess.Popen([
        QEMU, *COMMON,
        "-drive", f"file=build/mbr-{image}.img,format=raw,if=ide",
        "-display", "none", "-serial", "file:" + str(serial),
        "-monitor", f"unix:{socket_path},server=on,wait=off",
        "-S", "-gdb", f"tcp:127.0.0.1:{port}",
    ], stdout=qemu_log, stderr=subprocess.STDOUT)
    return process, qemu_log, connect_monitor(socket_path), serial


def normal_case():
    process, qemu_log, monitor, serial_path = launch("mouse", 1268, "mouse")
    try:
        ready = gdb("mouse", 1268,
            "hbreak graphics_mouse_ready\ncontinue\n"
            "python\n"
            "v=lambda x:int(gdb.parse_and_eval(x))\n"
            "assert v('mouse_ack')==2 and v('mouse_bat')==0xaa and v('mouse_id')==0\n"
            "assert v('mouse_resends')==1\n"
            "assert v('graphics_mouse_selftest_packets')==2\n"
            "assert v('graphics_mouse_selftest_sync')==3\n"
            "assert v('graphics_mouse_selftest_overflow')==1\n"
            "assert v('$eflags') & 0x200 == 0\n"
            "print('INIT ack=%d bat=%#x id=%d resend=%d selftest=%d/%d/%d' % "
            "(v('mouse_ack'),v('mouse_bat'),v('mouse_id'),v('mouse_resends'),"
            "v('graphics_mouse_selftest_packets'),v('graphics_mouse_selftest_sync'),"
            "v('graphics_mouse_selftest_overflow')))\nend\n"
            "delete breakpoints", "day27-mouse-ready-gdb.txt")
        assert "INIT ack=2 bat=0xaa id=0 resend=1 selftest=2/3/1" in ready

        injection = threading.Timer(.2, lambda: hmp(monitor, "mouse_move 1 1"))
        injection.start()
        frame = gdb("mouse", 1268,
            "hbreak *mouse_irq\ncontinue\n"
            "python\n"
            "import struct\n"
            "f=struct.unpack('<17I',bytes(gdb.selected_inferior().read_memory(int(gdb.parse_and_eval('$ebx')),68)))\n"
            "assert f[12:14]==(44,0) and f[15]==8 and f[16]&0x200\n"
            "assert int(gdb.parse_and_eval('$eflags')) & 0x600 == 0\n"
            "print('IRQ frame vector=%d error=%d cs=%d saved_if=1 handler_if_df=0' % (f[12],f[13],f[15]))\n"
            "end\ndelete breakpoints", "day27-mouse-frame-gdb.txt")
        injection.join()
        assert "IRQ frame vector=44" in frame

        gdb("mouse", 1268, "set variable mouse_consumer_paused=1",
            "day27-mouse-pause-gdb.txt")
        for _ in range(90):
            hmp(monitor, "mouse_move 1 0")
        time.sleep(.2)
        overflow = gdb("mouse", 1268,
            "python\n"
            "v=lambda x:int(gdb.parse_and_eval(x))\n"
            "assert v('mouse_dropped')>0 and v('mouse_resets')==0\n"
            "print('QUEUE dropped=%d irqs=%d routed=%d' % "
            "(v('mouse_dropped'),v('mouse_irqs'),v('mouse_routed')))\n"
            "end\nset variable mouse_consumer_paused=0",
            "day27-mouse-overflow-gdb.txt")
        assert "QUEUE dropped=" in overflow

        time.sleep(.2)
        hmp(monitor, "mouse_move 1 0")  # Wake the overflow reset path.
        time.sleep(.2)
        hmp(monitor, "mouse_move -1000 -1000")
        time.sleep(.5)
        hmp(monitor, "mouse_move 2000 2000")
        time.sleep(1)
        edge = gdb("mouse", 1268,
            "python\n"
            "v=lambda x:int(gdb.parse_and_eval(x))\n"
            "assert v('graphics_mouse_edges')==15\n"
            "print('EDGES mask=%#x pos=%d,%d' % (v('graphics_mouse_edges'),"
            "v('graphics_mouse_x'),v('graphics_mouse_y')))\nend",
            "day27-mouse-edges-gdb.txt")
        assert "EDGES mask=0xf" in edge
        for state in (1, 0, 2, 0, 4, 0):
            hmp(monitor, f"mouse_button {state}")
            time.sleep(.05)
        for key in ("k", "b", "d"):
            hmp(monitor, f"sendkey {key} 20")
            time.sleep(.06)
        time.sleep(.5)
        final = gdb("mouse", 1268,
            "python\n"
            "v=lambda x:int(gdb.parse_and_eval(x))\n"
            "s=bytes(gdb.selected_inferior().read_memory(v('&graphics_mouse_keyboard'),3))\n"
            "assert v('graphics_mouse_edges')==15 and v('graphics_mouse_buttons')==7\n"
            "assert v('graphics_mouse_button_changes')>=6 and v('mouse_resets')==1\n"
            "assert v('graphics_mouse_keyboard_chars')==3 and s==b'kbd'\n"
            "assert v('keyboard_irqs')>=6 and v('keyboard_routed')==v('keyboard_irqs')\n"
            "assert v('mouse_slave_eois')==v('mouse_irqs')\n"
            "assert v('mouse_master_eois')==v('mouse_irqs')\n"
            "print('STATE pos=%d,%d edges=%#x buttons=%#x changes=%d packets=%d reset=%d irq=%d route=%d eoi=%d/%d keys=%s' % "
            "(v('graphics_mouse_x'),v('graphics_mouse_y'),v('graphics_mouse_edges'),"
            "v('graphics_mouse_buttons'),v('graphics_mouse_button_changes'),"
            "v('graphics_mouse_packets'),v('mouse_resets'),v('mouse_irqs'),"
            "v('mouse_routed'),v('mouse_slave_eois'),v('mouse_master_eois'),s.decode()))\n"
            "end\nmonitor info pic\n"
            "monitor screendump build/day27-screen.png -f png",
            "day27-mouse-gdb.txt", timeout=60)
        assert "STATE pos=" in final and "keys=kbd" in final
        serial = serial_path.read_bytes().replace(b"\r\n", b"\n")
        assert b"D27 INIT ack=2 bat=aa id=0 resend=1 eoi_mode=0\n" in serial
        assert b"D27 SELFTEST packets=2 sync=3 overflow=1\n" in serial
        assert b"D27 CURSOR" in serial and b"edges=f buttons=7" in serial
        assert b"D27 SHARED keyboard=kbd" in serial
        assert b"MOUSE OK shared controller, packets, clipping and recovery\n" in serial
        assert b"PANIC" not in serial
        png = (BUILD / "day27-screen.png").read_bytes()
        assert png[:8] == b"\x89PNG\r\n\x1a\n"
    finally:
        monitor.close()
        stop(process)
        qemu_log.close()


def eoi_failure(image, port, label, slave_eois, master_eois):
    process, qemu_log, monitor, _ = launch(image, port, label)
    try:
        gdb(image, port, "hbreak graphics_mouse_ready\ncontinue\ndelete breakpoints",
            f"day27-{label}-ready-gdb.txt")
        hmp(monitor, "mouse_move 2 1")
        time.sleep(.15)
        hmp(monitor, "mouse_move 2 1")
        time.sleep(.15)
        proof = gdb(image, port,
            "python\n"
            "v=lambda x:int(gdb.parse_and_eval(x))\n"
            "assert v('mouse_irqs')==1\n"
            f"assert v('mouse_slave_eois')=={slave_eois}\n"
            f"assert v('mouse_master_eois')=={master_eois}\n"
            "print('STALLED irq=%d slave_eoi=%d master_eoi=%d' % "
            "(v('mouse_irqs'),v('mouse_slave_eois'),v('mouse_master_eois')))\n"
            "end\nmonitor info pic", f"day27-{label}-gdb.txt")
        assert "STALLED irq=1" in proof
    finally:
        monitor.close()
        stop(process)
        qemu_log.close()


def main():
    subprocess.run([
        "cc", "-std=c11", "-Wall", "-Wextra", "-Werror",
        "-D", "KEYBOARD_HOST_TEST", "kernel/keyboard.c",
        "tools/check-mouse-parser.c", "-o", "build/check-mouse-parser",
    ], check=True)
    parser = subprocess.run(["build/check-mouse-parser"], text=True,
                            stdout=subprocess.PIPE, check=True)
    (BUILD / "day27-mouse-parser.txt").write_text(parser.stdout)
    normal_case()
    eoi_failure("mouse-no-slave", 1269, "no-slave", 0, 1)
    eoi_failure("mouse-no-master", 1270, "no-master", 1, 0)
    print("PASS: Day27 shared PS/2 routing, packets, clipping and cascaded EOI")


if __name__ == "__main__":
    main()
