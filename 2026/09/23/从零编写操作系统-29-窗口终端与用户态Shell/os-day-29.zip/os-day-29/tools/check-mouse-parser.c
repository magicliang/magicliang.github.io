#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include "../kernel/keyboard.h"

static int feed(struct mouse_parser *parser, struct mouse_event *event,
                uint8_t a, uint8_t b, uint8_t c)
{
    assert(mouse_parse(parser, a, event) == 0);
    assert(mouse_parse(parser, b, event) == 0);
    return mouse_parse(parser, c, event);
}

int main(void)
{
    struct mouse_parser parser = {0};
    struct mouse_event event = {0};

    assert(feed(&parser, &event, 0x09, 5, 3) == 1);
    assert(event.dx == 5 && event.dy == -3 && event.buttons == 1);
    assert(feed(&parser, &event, 0x3e, 0xfb, 0xf9) == 1);
    assert(event.dx == -5 && event.dy == 7 && event.buttons == 6);

    assert(mouse_parse(&parser, 0x00, &event) == 0);
    assert(parser.sync_losses == 1);
    assert(mouse_parse(&parser, 0x08, &event) == 0);
    mouse_parser_reset(&parser);              /* Lost byte two. */
    assert(mouse_parse(&parser, 0x00, &event) == 0);
    assert(parser.sync_losses == 2);

    assert(feed(&parser, &event, 0x08, 0xfa, 0) == -1); /* Stray ACK. */
    assert(parser.sync_losses == 3);
    assert(feed(&parser, &event, 0x48, 0, 0) == -1);    /* X overflow. */
    assert(parser.overflow_packets == 1);
    assert(feed(&parser, &event, 0x08, 12, 8) == 1);
    assert(event.dx == 12 && event.dy == -8 && parser.packets == 3);

    puts("PASS: 3-byte sign/Y decode, lost-byte reset, ACK rejection, "
         "overflow rejection and legal-packet recovery");
}
