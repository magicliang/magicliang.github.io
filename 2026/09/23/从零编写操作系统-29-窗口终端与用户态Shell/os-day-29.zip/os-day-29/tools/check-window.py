#!/usr/bin/env python3
"""Drive the Day 28 window manager through QEMU HMP and inspect state."""
import os
import shlex
import socket
import subprocess
import time
from pathlib import Path

BUILD = Path("build")
QEMU = os.environ.get("QEMU", "qemu-system-i386")
GDB = os.environ.get("GDB", "gdb-multiarch")
COMMON = shlex.split(os.environ["QEMU_COMMON"])
PORT = 1271


def stop(process):
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()


def connect_monitor(path):
    monitor = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    for _ in range(100):
        try:
            monitor.connect(path)
            break
        except (FileNotFoundError, ConnectionRefusedError):
            time.sleep(.05)
    else:
        raise AssertionError("QEMU monitor did not appear")
    monitor.settimeout(3)
    monitor.recv(8192)
    return monitor


def hmp(monitor, command):
    monitor.sendall((command + "\n").encode())
    output = b""
    while b"(qemu)" not in output:
        output += monitor.recv(8192)
    return output.decode(errors="replace")


def gdb(commands, output, timeout=30):
    script = (
        "set architecture i386\n"
        "set tcp connect-timeout 5\n"
        "set tcp auto-retry on\n"
        "file build/kernel-window.elf\n"
        f"target remote 127.0.0.1:{PORT}\n"
        + commands + "\ndetach\n"
    )
    script_path = BUILD / (output + ".cmd")
    script_path.write_text(script)
    result = subprocess.run(
        [GDB, "-q", "-nx", "-batch", "-x", str(script_path)], text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        timeout=timeout, check=False,
    )
    (BUILD / output).write_text(result.stdout)
    assert result.returncode == 0, result.stdout
    return result.stdout


def main():
    socket_path = str(BUILD / "day28-window-monitor.sock")
    Path(socket_path).unlink(missing_ok=True)
    serial_path = BUILD / "day28-window-serial.txt"
    qemu_log = (BUILD / "day28-window-qemu.txt").open("wb")
    process = subprocess.Popen([
        QEMU, *COMMON,
        "-drive", "file=build/mbr-window.img,format=raw,if=ide",
        "-display", "none", "-serial", "file:" + str(serial_path),
        "-monitor", f"unix:{socket_path},server=on,wait=off",
        "-S", "-gdb", f"tcp:127.0.0.1:{PORT}",
    ], stdout=qemu_log, stderr=subprocess.STDOUT)
    monitor = connect_monitor(socket_path)
    try:
        ready = gdb(
            "hbreak graphics_window_ready\ncontinue\n"
            "python\n"
            "v=lambda x:int(gdb.parse_and_eval(x))\n"
            "assert v('graphics_window_x[0]')==20 and v('graphics_window_y[0]')==40\n"
            "assert v('graphics_window_x[1]')==105 and v('graphics_window_y[1]')==70\n"
            "assert v('graphics_window_z[0]')==0 and v('graphics_window_z[1]')==1\n"
            "assert v('graphics_window_focus')==1 and v('graphics_window_dragged')==-1\n"
            "pixel=lambda x,y:bytes(gdb.selected_inferior().read_memory(0xa0000+y*320+x,1))[0]\n"
            "assert pixel(120,90)==2\n"
            "print('INITIAL A=20,40 B=105,70 focus=1 z=0,1 overlap=%d' % pixel(120,90))\n"
            "end\ndelete breakpoints",
            "day28-window-ready-gdb.txt",
        )
        assert "INITIAL A=20,40 B=105,70 focus=1 z=0,1 overlap=2" in ready

        for command in (
            "mouse_move -120 -55",
            "mouse_button 1",
            "mouse_move 30 20",
            "mouse_button 0",
            "sendkey a 20",
            "mouse_move 150 10",
            "mouse_button 1",
            "mouse_button 0",
            "sendkey b 20",
        ):
            hmp(monitor, command)
            time.sleep(.15)
        time.sleep(.5)

        final = gdb(
            "python\n"
            "v=lambda x:int(gdb.parse_and_eval(x))\n"
            "mem=lambda a,n:bytes(gdb.selected_inferior().read_memory(v(a),n))\n"
            "pixel=lambda x,y:bytes(gdb.selected_inferior().read_memory(0xa0000+y*320+x,1))[0]\n"
            "assert v('graphics_window_x[0]')==50 and v('graphics_window_y[0]')==60\n"
            "assert v('graphics_window_x[1]')==105 and v('graphics_window_y[1]')==70\n"
            "assert v('graphics_window_focus')==1 and v('graphics_window_dragged')==-1\n"
            "assert v('graphics_window_z[0]')==0 and v('graphics_window_z[1]')==1\n"
            "assert v('graphics_window_focus_changes')==2 and v('graphics_window_z_changes')==2\n"
            "assert v('graphics_window_input_count[0]')==1 and mem('&graphics_window_text[0]',1)==b'a'\n"
            "assert v('graphics_window_input_count[1]')==1 and mem('&graphics_window_text[1]',1)==b'b'\n"
            "assert pixel(20,40)==3 and pixel(120,90)==2\n"
            "print('FINAL A=%d,%d B=%d,%d focus=%d top=%d drag=%d changes=%d/%d text=%s/%s pixels=%d/%d packets=%d redraws=%d' % "
            "(v('graphics_window_x[0]'),v('graphics_window_y[0]'),v('graphics_window_x[1]'),v('graphics_window_y[1]'),"
            "v('graphics_window_focus'),v('graphics_window_z[1]'),v('graphics_window_dragged'),"
            "v('graphics_window_focus_changes'),v('graphics_window_z_changes'),"
            "mem('&graphics_window_text[0]',1).decode(),mem('&graphics_window_text[1]',1).decode(),"
            "pixel(20,40),pixel(120,90),v('graphics_window_packets'),v('graphics_window_redraws')))\n"
            "end\nmonitor screendump build/day28-screen.png -f png",
            "day28-window-gdb.txt",
        )
        assert "FINAL A=50,60 B=105,70 focus=1 top=1 drag=-1 changes=2/2 text=a/b pixels=3/2" in final
        serial = serial_path.read_bytes().replace(b"\r\n", b"\n")
        assert b"D28 INIT windows=2 focus=1 z=0,1 mouse=160,100\n" in serial
        assert b"D28 WINDOWS A=50,60 B=105,70 focus=1 top=1 drag=-1\n" in serial
        assert b"D28 EVENTS focus_changes=2 z_changes=2" in serial
        assert b"D28 INPUT A=a/1 B=b/1\n" in serial
        assert b"WINDOW OK z-order, focus, drag, restore and routed input\n" in serial
        assert b"PANIC" not in serial
        png = (BUILD / "day28-screen.png").read_bytes()
        assert png[:8] == b"\x89PNG\r\n\x1a\n"
    finally:
        monitor.close()
        stop(process)
        qemu_log.close()
    print("PASS: Day28 z-order, focus, title drag, restore and routed input")


if __name__ == "__main__":
    main()
