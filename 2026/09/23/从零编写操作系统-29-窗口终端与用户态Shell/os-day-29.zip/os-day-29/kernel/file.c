#include <stddef.h>
#include <stdint.h>
#include "console.h"
#include "fat.h"
#include "file.h"
#include "keyboard.h"
#include "runtime.h"
#include "task.h"

enum file_type {
    FILE_FREE, FILE_FAT, FILE_TERMINAL_IN, FILE_TERMINAL_OUT,
    FILE_PIPE_READ, FILE_PIPE_WRITE
};

struct pipe {
    unsigned used, read_at, write_at;
    unsigned readers, writers;
    struct wait_queue read_waiters, write_waiters;
    uint8_t bytes[PIPE_CAPACITY];
};

struct open_file {
    enum file_type type;
    uint32_t refs;
    uint32_t offset;
    unsigned readable, writable;
    struct fat_file fat;
    struct pipe *pipe;
    unsigned graphics_terminal;
};

#define TERMINAL_QUEUE_CAPACITY 64u
struct graphics_terminal {
    unsigned active;
    unsigned input_used, input_read, input_write;
    unsigned output_used, output_read, output_write;
    unsigned input_endpoints, output_endpoints;
    struct wait_queue input_waiters, output_waiters;
    uint8_t input[TERMINAL_QUEUE_CAPACITY];
    uint8_t output[TERMINAL_QUEUE_CAPACITY];
};

static struct open_file files[OPEN_FILE_MAX];
static struct pipe pipe_slot;
static struct graphics_terminal graphics_terminal;
volatile uint32_t file_allocations, file_releases, file_peak_live;
volatile uint32_t file_reads, file_writes, file_short_reads;
volatile uint32_t pipe_creates, pipe_releases;
volatile uint32_t pipe_read_blocks, pipe_write_blocks;
volatile uint32_t pipe_eofs, pipe_broken_writes;
volatile uint32_t pipe_bytes_read, pipe_bytes_written;
volatile uint32_t terminal_input_bytes, terminal_output_bytes;
volatile uint32_t terminal_output_consumed;
volatile uint32_t terminal_read_blocks, terminal_write_blocks;
volatile uint32_t terminal_input_high_water;
volatile uint32_t terminal_output_high_water;
volatile uint32_t terminal_input_dropped, terminal_endpoint_releases;

void file_graphics_terminal_begin(void)
{
    uint32_t flags = irq_save();
    KASSERT(!graphics_terminal.active && !graphics_terminal.input_endpoints &&
            !graphics_terminal.output_endpoints);
    graphics_terminal = (struct graphics_terminal){.active=1};
    terminal_input_bytes = terminal_output_bytes = 0;
    terminal_output_consumed = 0;
    terminal_read_blocks = terminal_write_blocks = 0;
    terminal_input_high_water = terminal_output_high_water = 0;
    terminal_input_dropped = terminal_endpoint_releases = 0;
    irq_restore(flags);
}

unsigned file_graphics_terminal_input_space(void)
{
    uint32_t flags = irq_save();
    unsigned space = graphics_terminal.active ?
        TERMINAL_QUEUE_CAPACITY - graphics_terminal.input_used : 0;
    irq_restore(flags);
    return space;
}

int file_graphics_terminal_push(uint8_t byte)
{
    uint32_t flags = irq_save();
    if (!graphics_terminal.active ||
        graphics_terminal.input_used == TERMINAL_QUEUE_CAPACITY) {
        ++terminal_input_dropped;
        irq_restore(flags);
        return 0;
    }
    graphics_terminal.input[graphics_terminal.input_write] = byte;
    graphics_terminal.input_write =
        (graphics_terminal.input_write + 1) % TERMINAL_QUEUE_CAPACITY;
    ++graphics_terminal.input_used;
    ++terminal_input_bytes;
    if (graphics_terminal.input_used > terminal_input_high_water)
        terminal_input_high_water = graphics_terminal.input_used;
    (void)wake_one_locked(&graphics_terminal.input_waiters);
    irq_restore(flags);
    return 1;
}

unsigned file_graphics_terminal_drain(uint8_t *buffer, unsigned capacity)
{
    if (!buffer || !capacity) return 0;
    uint32_t flags = irq_save();
    unsigned count = capacity;
    if (count > graphics_terminal.output_used)
        count = graphics_terminal.output_used;
    for (unsigned i = 0; i < count; ++i) {
        buffer[i] = graphics_terminal.output[graphics_terminal.output_read];
        graphics_terminal.output_read =
            (graphics_terminal.output_read + 1) % TERMINAL_QUEUE_CAPACITY;
    }
    graphics_terminal.output_used -= count;
    terminal_output_consumed += count;
    if (count) (void)wake_one_locked(&graphics_terminal.output_waiters);
    irq_restore(flags);
    return count;
}

unsigned file_graphics_terminal_output_pending(void)
{
    uint32_t flags = irq_save();
    unsigned pending = graphics_terminal.output_used;
    irq_restore(flags);
    return pending;
}

void file_graphics_terminal_end(void)
{
    uint32_t flags = irq_save();
    KASSERT(graphics_terminal.active &&
            !graphics_terminal.input_used && !graphics_terminal.output_used &&
            !graphics_terminal.input_endpoints &&
            !graphics_terminal.output_endpoints &&
            !graphics_terminal.input_waiters.mask &&
            !graphics_terminal.output_waiters.mask);
    graphics_terminal.active = 0;
    irq_restore(flags);
}

static struct open_file *file_alloc(enum file_type type, unsigned readable,
                                    unsigned writable)
{
    uint32_t flags = irq_save();
    for (unsigned i = 0; i < OPEN_FILE_MAX; ++i) {
        if (files[i].type != FILE_FREE || files[i].refs) continue;
        files[i] = (struct open_file){.type=type, .refs=1,
                                     .readable=readable, .writable=writable};
        ++file_allocations;
        unsigned live = file_live_count();
        if (live > file_peak_live) file_peak_live = live;
        irq_restore(flags);
        return &files[i];
    }
    irq_restore(flags);
    return 0;
}

static int fat_error(int error)
{
    if (error == FAT_ENOENT) return -FILE_ENOENT;
    if (error == FAT_ENAME) return -FILE_ENAMETOOLONG;
    if (error == FAT_EINVAL) return -FILE_EINVAL;
    return -FILE_EIO;
}

int file_open(const char *path, unsigned flags, struct open_file **result)
{
    if (!result || flags) return -FILE_EINVAL;
    struct fat_file fat;
    preempt_disable();
    __asm__ volatile("sti" ::: "memory");
    int opened = fat_open(path, &fat);
    __asm__ volatile("cli" ::: "memory");
    preempt_enable();
    if (opened != FAT_OK) return fat_error(opened);
    struct open_file *file = file_alloc(FILE_FAT, 1, 0);
    if (!file) return -FILE_ENFILE;
    file->fat = fat;
    *result = file;
    return 0;
}

int file_open_terminal(int input, struct open_file **result)
{
    if (!result) return -FILE_EINVAL;
    struct open_file *file = file_alloc(input ? FILE_TERMINAL_IN :
                                        FILE_TERMINAL_OUT, input, !input);
    if (!file) return -FILE_ENFILE;
    if (graphics_terminal.active) {
        file->graphics_terminal = 1;
        if (input) ++graphics_terminal.input_endpoints;
        else ++graphics_terminal.output_endpoints;
    }
    *result = file;
    return 0;
}

int file_pipe_create(struct open_file **read_end,
                     struct open_file **write_end)
{
    if (!read_end || !write_end) return -FILE_EINVAL;
    uint32_t flags = irq_save();
    if (pipe_slot.readers || pipe_slot.writers) {
        irq_restore(flags);
        return -FILE_ENFILE;
    }
    int slots[2] = {-1, -1};
    for (unsigned i = 0; i < OPEN_FILE_MAX; ++i) {
        if (files[i].type != FILE_FREE || files[i].refs) continue;
        if (slots[0] < 0) slots[0] = (int)i;
        else { slots[1] = (int)i; break; }
    }
    if (slots[1] < 0) { irq_restore(flags); return -FILE_ENFILE; }
    pipe_slot = (struct pipe){.readers=1, .writers=1};
    files[slots[0]] = (struct open_file){
        .type=FILE_PIPE_READ, .refs=1, .readable=1, .pipe=&pipe_slot
    };
    files[slots[1]] = (struct open_file){
        .type=FILE_PIPE_WRITE, .refs=1, .writable=1, .pipe=&pipe_slot
    };
    file_allocations += 2;
    unsigned live = file_live_count();
    if (live > file_peak_live) file_peak_live = live;
    ++pipe_creates;
    *read_end = &files[slots[0]];
    *write_end = &files[slots[1]];
    irq_restore(flags);
    return 0;
}

int file_get(struct open_file *file)
{
    uint32_t flags = irq_save();
    if (!file || file < files || file >= files + OPEN_FILE_MAX ||
        file->type == FILE_FREE || !file->refs || file->refs == UINT32_MAX) {
        irq_restore(flags);
        return 0;
    }
    ++file->refs;
    irq_restore(flags);
    return 1;
}

void file_put(struct open_file *file)
{
    uint32_t flags = irq_save();
    KASSERT(file && file >= files && file < files + OPEN_FILE_MAX &&
            file->type != FILE_FREE && file->refs);
    if (--file->refs == 0) {
        struct pipe *pipe = file->pipe;
        enum file_type type = file->type;
        unsigned graphical = file->graphics_terminal;
        *file = (struct open_file){0};
        ++file_releases;
        if (graphical && type == FILE_TERMINAL_IN) {
            KASSERT(graphics_terminal.input_endpoints == 1);
            graphics_terminal.input_endpoints = 0;
            ++terminal_endpoint_releases;
        } else if (graphical && type == FILE_TERMINAL_OUT) {
            KASSERT(graphics_terminal.output_endpoints == 1);
            graphics_terminal.output_endpoints = 0;
            ++terminal_endpoint_releases;
        }
        if (type == FILE_PIPE_READ) {
            KASSERT(pipe && pipe->readers == 1);
            pipe->readers = 0;
            (void)wake_all_locked(&pipe->write_waiters);
        } else if (type == FILE_PIPE_WRITE) {
            KASSERT(pipe && pipe->writers == 1);
            pipe->writers = 0;
            (void)wake_all_locked(&pipe->read_waiters);
        }
        if (pipe && !pipe->readers && !pipe->writers) {
            KASSERT(!pipe->read_waiters.mask && !pipe->write_waiters.mask);
            *pipe = (struct pipe){0};
            ++pipe_releases;
        }
    }
    irq_restore(flags);
}

int file_read(struct open_file *file, void *buffer, uint32_t length)
{
    if (!file || (!buffer && length) || length > FILE_IO_MAX)
        return -FILE_EINVAL;
    if (!file->readable) return -FILE_EBADF;
    if (!length) return 0;
    int result;
    if (file->type == FILE_FAT) {
        preempt_disable();
        __asm__ volatile("sti" ::: "memory");
        result = fat_read_at(&file->fat, file->offset, buffer, length);
        __asm__ volatile("cli" ::: "memory");
        if (result > 0) file->offset += (uint32_t)result;
        preempt_enable();
        if (result < 0) return fat_error(result);
        if ((uint32_t)result < length) ++file_short_reads;
    } else if (file->type == FILE_TERMINAL_IN) {
        if (file->graphics_terminal) {
            uint32_t flags = irq_save();
            while (!graphics_terminal.input_used &&
                   graphics_terminal.active) {
                ++terminal_read_blocks;
                task_block_locked(&graphics_terminal.input_waiters);
            }
            if (!graphics_terminal.input_used) {
                irq_restore(flags);
                return 0;
            }
            *(uint8_t *)buffer =
                graphics_terminal.input[graphics_terminal.input_read];
            graphics_terminal.input_read =
                (graphics_terminal.input_read + 1) % TERMINAL_QUEUE_CAPACITY;
            --graphics_terminal.input_used;
            irq_restore(flags);
        } else {
            int byte = keyboard_read_char();
            if (byte < 0) return -FILE_EIO;
            *(uint8_t *)buffer = (uint8_t)byte;
        }
        result = 1;
        ++file_short_reads;
    } else if (file->type == FILE_PIPE_READ) {
        struct pipe *pipe = file->pipe;
        uint32_t flags = irq_save();
        while (!pipe->used && pipe->writers) {
            ++pipe_read_blocks;
            task_block_locked(&pipe->read_waiters);
        }
        if (!pipe->used) {
            ++pipe_eofs;
            irq_restore(flags);
            result = 0;
        } else {
            uint32_t count = length;
            if (count > pipe->used) count = pipe->used;
            for (uint32_t i = 0; i < count; ++i) {
                ((uint8_t *)buffer)[i] = pipe->bytes[pipe->read_at];
                pipe->read_at = (pipe->read_at + 1) % PIPE_CAPACITY;
            }
            pipe->used -= count;
            pipe_bytes_read += count;
            (void)wake_one_locked(&pipe->write_waiters);
            irq_restore(flags);
            result = (int)count;
            if (count < length) ++file_short_reads;
        }
    } else {
        return -FILE_EBADF;
    }
    ++file_reads;
    return result;
}

int file_write(struct open_file *file, const void *buffer, uint32_t length)
{
    if (!file || (!buffer && length) || length > FILE_IO_MAX)
        return -FILE_EINVAL;
    if (file->type == FILE_FAT) return -FILE_EROFS;
    if (!file->writable) return -FILE_EBADF;
    const uint8_t *bytes = buffer;
    if (file->type == FILE_TERMINAL_OUT) {
        if (file->graphics_terminal) {
            uint32_t flags = irq_save();
            while (graphics_terminal.output_used == TERMINAL_QUEUE_CAPACITY &&
                   graphics_terminal.active) {
                ++terminal_write_blocks;
                task_block_locked(&graphics_terminal.output_waiters);
            }
            if (!graphics_terminal.active) {
                irq_restore(flags);
                return -FILE_EPIPE;
            }
            uint32_t count = length;
            if (count > TERMINAL_QUEUE_CAPACITY - graphics_terminal.output_used)
                count = TERMINAL_QUEUE_CAPACITY - graphics_terminal.output_used;
            for (uint32_t i = 0; i < count; ++i) {
                graphics_terminal.output[graphics_terminal.output_write] =
                    bytes[i];
                graphics_terminal.output_write =
                    (graphics_terminal.output_write + 1) %
                    TERMINAL_QUEUE_CAPACITY;
            }
            graphics_terminal.output_used += count;
            terminal_output_bytes += count;
            if (graphics_terminal.output_used > terminal_output_high_water)
                terminal_output_high_water = graphics_terminal.output_used;
            irq_restore(flags);
            length = count;
        } else {
            for (uint32_t i = 0; i < length; ++i)
                console_putc((char)bytes[i]);
        }
    } else if (file->type == FILE_PIPE_WRITE) {
        struct pipe *pipe = file->pipe;
        uint32_t flags = irq_save();
        while (pipe->used == PIPE_CAPACITY && pipe->readers) {
            ++pipe_write_blocks;
            task_block_locked(&pipe->write_waiters);
        }
        if (!pipe->readers) {
            ++pipe_broken_writes;
            irq_restore(flags);
            return -FILE_EPIPE;
        }
        uint32_t count = length;
        if (count > PIPE_CAPACITY - pipe->used)
            count = PIPE_CAPACITY - pipe->used;
        for (uint32_t i = 0; i < count; ++i) {
            pipe->bytes[pipe->write_at] = bytes[i];
            pipe->write_at = (pipe->write_at + 1) % PIPE_CAPACITY;
        }
        pipe->used += count;
        pipe_bytes_written += count;
        (void)wake_one_locked(&pipe->read_waiters);
        irq_restore(flags);
        length = count;
    } else {
        return -FILE_EBADF;
    }
    ++file_writes;
    return (int)length;
}

int file_pread(struct open_file *file, uint32_t offset, void *buffer,
               uint32_t length)
{
    if (!file || file->type != FILE_FAT || (!buffer && length))
        return -FILE_EINVAL;
    preempt_disable();
    __asm__ volatile("sti" ::: "memory");
    int result = fat_read_at(&file->fat, offset, buffer, length);
    __asm__ volatile("cli" ::: "memory");
    preempt_enable();
    return result < 0 ? fat_error(result) : result;
}

uint32_t file_size(const struct open_file *file)
{ return file && file->type == FILE_FAT ? file->fat.size : 0; }

unsigned file_live_count(void)
{
    unsigned count = 0;
    for (unsigned i = 0; i < OPEN_FILE_MAX; ++i)
        if (files[i].type != FILE_FREE) ++count;
    return count;
}

unsigned file_total_refs(void)
{
    unsigned count = 0;
    for (unsigned i = 0; i < OPEN_FILE_MAX; ++i) count += files[i].refs;
    return count;
}

uint32_t file_offset(const struct open_file *file)
{ return file ? file->offset : 0; }

unsigned file_pipe_live_count(void)
{ return pipe_slot.readers || pipe_slot.writers; }
