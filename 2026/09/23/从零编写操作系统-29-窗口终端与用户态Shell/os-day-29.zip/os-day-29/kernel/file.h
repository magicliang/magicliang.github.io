#ifndef FILE_H
#define FILE_H

#include <stdint.h>

#define FD_MAX 8u
#define OPEN_FILE_MAX 7u
#define FILE_IO_MAX 256u
#define PIPE_CAPACITY 64u

#define FILE_EIO 5
#define FILE_EBADF 9
#define FILE_EINVAL 22
#define FILE_ENFILE 23
#define FILE_EMFILE 24
#define FILE_EROFS 30
#define FILE_EPIPE 32
#define FILE_ENAMETOOLONG 36
#define FILE_ENOENT 2

struct open_file;

int file_open(const char *path, unsigned flags, struct open_file **result);
int file_open_terminal(int input, struct open_file **result);
int file_pipe_create(struct open_file **read_end,
                     struct open_file **write_end);
int file_get(struct open_file *file);
void file_put(struct open_file *file);
int file_read(struct open_file *file, void *buffer, uint32_t length);
int file_write(struct open_file *file, const void *buffer, uint32_t length);
int file_pread(struct open_file *file, uint32_t offset, void *buffer,
               uint32_t length);
uint32_t file_size(const struct open_file *file);

/* Day 29: the UI owns these producer/consumer operations.  User programs
 * still see only ordinary terminal file objects. */
void file_graphics_terminal_begin(void);
int file_graphics_terminal_push(uint8_t byte);
unsigned file_graphics_terminal_drain(uint8_t *buffer, unsigned capacity);
unsigned file_graphics_terminal_input_space(void);
unsigned file_graphics_terminal_output_pending(void);
void file_graphics_terminal_end(void);

unsigned file_live_count(void);
unsigned file_total_refs(void);
uint32_t file_offset(const struct open_file *file);
unsigned file_pipe_live_count(void);

extern volatile uint32_t file_allocations, file_releases, file_peak_live;
extern volatile uint32_t file_reads, file_writes, file_short_reads;
extern volatile uint32_t pipe_creates, pipe_releases;
extern volatile uint32_t pipe_read_blocks, pipe_write_blocks;
extern volatile uint32_t pipe_eofs, pipe_broken_writes;
extern volatile uint32_t pipe_bytes_read, pipe_bytes_written;
extern volatile uint32_t terminal_input_bytes, terminal_output_bytes;
extern volatile uint32_t terminal_output_consumed;
extern volatile uint32_t terminal_read_blocks, terminal_write_blocks;
extern volatile uint32_t terminal_input_high_water;
extern volatile uint32_t terminal_output_high_water;
extern volatile uint32_t terminal_input_dropped, terminal_endpoint_releases;

#endif
