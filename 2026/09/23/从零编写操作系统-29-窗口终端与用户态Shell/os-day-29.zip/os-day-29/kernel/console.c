#include <stdarg.h>
#include <stdint.h>
#include "console.h"

static volatile uint16_t *const vga = (volatile uint16_t *)0xb8000;
static unsigned row, column;
static int serial_available;

static void outb(uint16_t port, uint8_t value)
{
    __asm__ volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
}

static uint8_t console_inb(uint16_t port)
{
    uint8_t value;
    __asm__ volatile ("inb %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

void console_init(void)
{
    /* Reset our state explicitly, including the intentional bad-BSS experiment. */
    row = column = 0;
    serial_available = 1;
    outb(0x3f9, 0);       /* Polling only; UART interrupts disabled. */
    outb(0x3fb, 0x80);    /* DLAB: divisor 1, 115200 baud. */
    outb(0x3f8, 1);
    outb(0x3f9, 0);
    outb(0x3fb, 3);       /* 8 data bits, no parity, 1 stop bit. */
    outb(0x3fa, 0xc7);    /* Enable/clear FIFOs. */
    outb(0x3fc, 3);       /* DTR and RTS; no IRQ delivery. */
    outb(0x3d4, 0x0a);
    outb(0x3d5, 0x20);    /* Hide BIOS cursor; software position only. */
    for (unsigned i = 0; i < 80 * 25; ++i) vga[i] = 0x0f20;
}

static void serial_putc(char c)
{
    if (!serial_available) return;
    /* ponytail: bounded polling, replace with a timed driver when timers exist. */
    for (unsigned retry = 0; retry < 100000; ++retry) {
        uint8_t status = console_inb(0x3fd);
        if (status != 0xff && (status & 0x20)) {
            outb(0x3f8, (uint8_t)c);
            return;
        }
    }
    serial_available = 0; /* Keep VGA/panic usable after a dead UART. */
}

void console_putc(char c)
{
    if (c == '\n') serial_putc('\r');
    serial_putc(c);
    if (c == '\n') { column = 0; ++row; }
    else if (c == '\r') column = 0;
    else if (c == '\b') {
        if (column) --column;
        else if (row) { --row; column = 79; }
        vga[row * 80 + column] = 0x0f20;
    } else {
        vga[row * 80 + column++] = 0x0f00 | (uint8_t)c;
        if (column == 80) { column = 0; ++row; }
    }
    if (row == 25) {
        for (unsigned i = 0; i < 80 * 24; ++i) vga[i] = vga[i + 80];
        for (unsigned i = 80 * 24; i < 80 * 25; ++i) vga[i] = 0x0f20;
        row = 24;
    }
}

static void puts_raw(const char *s)
{
    if (!s) s = "(null)";
    while (*s) console_putc(*s++);
}

static void number(uint32_t value, unsigned base)
{
    char digits[32];
    unsigned count = 0;
    do { digits[count++] = "0123456789abcdef"[value % base]; value /= base; } while (value);
    while (count) console_putc(digits[--count]);
}

void kprintf(const char *format, ...)
{
    va_list args;
    va_start(args, format);
    while (*format) {
        if (*format != '%') { console_putc(*format++); continue; }
        ++format;
        if (!*format) { console_putc('%'); break; }
        switch (*format) {
        case 's': puts_raw(va_arg(args, const char *)); break;
        case 'c': console_putc((char)va_arg(args, int)); break;
        case 'd': {
            int value = va_arg(args, int);
            uint32_t magnitude = (uint32_t)value;
            if (value < 0) { console_putc('-'); magnitude = 0u - magnitude; }
            number(magnitude, 10); break;
        }
        case 'u': number(va_arg(args, unsigned), 10); break;
        case 'x': number(va_arg(args, unsigned), 16); break;
        case 'p': puts_raw("0x"); number((uintptr_t)va_arg(args, void *), 16); break;
        case '%': console_putc('%'); break;
        default: console_putc('%'); console_putc(*format); break;
        }
        ++format;
    }
    va_end(args);
}

_Noreturn void panic(const char *file, unsigned line, const char *reason)
{
    __asm__ volatile ("cli" : : : "memory");
    kprintf("\nPANIC %s:%u: %s\n", file, line, reason);
    /* A stable symbol lets GDB inspect the halted frame without unwinding it. */
    __asm__ volatile (".global panic_halt\npanic_halt:\nhlt\njmp panic_halt" : : : "memory");
    __builtin_unreachable();
}
