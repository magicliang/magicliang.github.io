#include "keyboard.h"
#ifndef KEYBOARD_HOST_TEST
#include "console.h"
#include "task.h"
#endif

/* US set 1 only; zero entries deliberately ignore unsupported keys. */
int keyboard_parse(struct key_parser *p, uint8_t byte)
{
    static const uint8_t pause_tail[] = {0x1d, 0x45, 0xe1, 0x9d, 0xc5};
    static const char plain[128] = {
        [2]='1',[3]='2',[4]='3',[5]='4',[6]='5',[7]='6',[8]='7',[9]='8',[10]='9',[11]='0',
        [12]='-',[13]='=',[14]='\b',[16]='q',[17]='w',[18]='e',[19]='r',[20]='t',[21]='y',
        [22]='u',[23]='i',[24]='o',[25]='p',[26]='[',[27]=']',[28]='\n',
        [30]='a',[31]='s',[32]='d',[33]='f',[34]='g',[35]='h',[36]='j',[37]='k',[38]='l',
        [39]=';',[40]='\'',[41]='`',[43]='\\',[44]='z',[45]='x',[46]='c',[47]='v',
        [48]='b',[49]='n',[50]='m',[51]=',',[52]='.',[53]='/',[57]=' '
    };
    static const char shifted[128] = {
        [2]='!',[3]='@',[4]='#',[5]='$',[6]='%',[7]='^',[8]='&',[9]='*',[10]='(',[11]=')',
        [12]='_',[13]='+',[26]='{',[27]='}',[39]=':',[40]='"',[41]='~',[43]='|',
        [51]='<',[52]='>',[53]='?'
    };
    if (p->pause) {
        if (byte == pause_tail[p->pause - 1]) {
            if (++p->pause == 6) p->pause = 0;
            return 0;
        }
        /* Mismatch drops the partial Pause; reconsider this byte once. */
        p->pause = 0;
    }
    if (byte == 0xe1) { p->pause = 1; p->extended = 0; return 0; }
    if (byte == 0xe0) { p->extended = 1; return 0; }
    if (p->extended) { p->extended = 0; return 0; } /* Includes PrintScreen fake shifts. */
    unsigned code = byte & 0x7f, down = !(byte & 0x80);
    if (code == 42) { p->left = down; return 0; }
    if (code == 54) { p->right = down; return 0; }
    if (code == 58) {
        if (down && !p->caps_down) p->caps ^= 1;
        p->caps_down = down;
        return 0;
    }
    if (!down) return 0;
    char c = plain[code];
    unsigned shift = p->left || p->right;
    if (c >= 'a' && c <= 'z') { if (shift ^ p->caps) c -= 'a' - 'A'; }
    else if (shift && shifted[code]) c = shifted[code];
    return c;
}

void mouse_parser_reset(struct mouse_parser *p)
{
    p->index = 0;
}

int mouse_parse(struct mouse_parser *p, uint8_t byte,
                struct mouse_event *event)
{
    if (!p->index) {
        if (!(byte & 0x08)) {
            ++p->sync_losses;
            return 0;
        }
        p->bytes[p->index++] = byte;
        return 0;
    }
    p->bytes[p->index++] = byte;
    if (p->index != 3) return 0;
    p->index = 0;

    uint8_t flags = p->bytes[0];
    if (flags & 0xc0) {
        ++p->overflow_packets;
        return -1;
    }
    if (!!(flags & 0x10) != !!(p->bytes[1] & 0x80) ||
        !!(flags & 0x20) != !!(p->bytes[2] & 0x80)) {
        ++p->sync_losses;
        return -1;
    }
    event->dx = (int8_t)p->bytes[1];
    event->dy = -(int8_t)p->bytes[2];
    event->buttons = flags & 7;
    ++p->packets;
    return 1;
}

#ifndef KEYBOARD_HOST_TEST
#define QUEUE_SIZE 64
static volatile uint8_t raw[QUEUE_SIZE];
static volatile unsigned head, tail;
static volatile uint8_t mouse_raw[QUEUE_SIZE];
static volatile unsigned mouse_head, mouse_tail;
volatile uint32_t keyboard_dropped, keyboard_irqs, keyboard_resets;
volatile uint32_t mouse_irqs, mouse_dropped, mouse_bytes, mouse_resets;
volatile uint32_t mouse_routed, keyboard_routed;
volatile uint32_t mouse_ack, mouse_bat, mouse_id, mouse_resends;
volatile uint32_t mouse_slave_eois, mouse_master_eois;
volatile unsigned keyboard_consumer_paused; /* GDB diagnostic: producer continues. */
volatile unsigned mouse_consumer_paused;
volatile unsigned keyboard_line_length;
char keyboard_line[64];
static struct key_parser parser;
static struct mouse_parser mouse_parser;
static struct wait_queue keyboard_waiters;
static uint32_t seen_dropped, mouse_seen_dropped;
static unsigned keyboard_started, mouse_started, mouse_eoi_mode;
volatile uint32_t keyboard_blocks, keyboard_wakes, keyboard_bytes;
static uint8_t inb(uint16_t port) { uint8_t v; __asm__ volatile("inb %1,%0":"=a"(v):"Nd"(port):"memory"); return v; }
static void outb(uint16_t port, uint8_t v) { __asm__ volatile("outb %0,%1"::"a"(v),"Nd"(port):"memory"); }
static int write_port(uint16_t port, uint8_t byte)
{
    for (unsigned n = 0; n < 100000; ++n)
        if (!(inb(0x64) & 2)) { outb(port, byte); return 1; }
    return 0;
}
static int read_byte(unsigned auxiliary)
{
    for (unsigned n = 0; n < 100000; ++n) {
        uint8_t status = inb(0x64);
        if (status & 1) {
            uint8_t byte = inb(0x60);
            if (!(status & 0xc0) && !!(status & 0x20) == !!auxiliary)
                return byte;
            return -1;
        }
    }
    return -1;
}
static int device_command(unsigned auxiliary, uint8_t byte,
                          unsigned inject_resend)
{
    for (unsigned attempt = 0; attempt < 3; ++attempt) {
        if (auxiliary && !write_port(0x64, 0xd4)) return 0;
        if (!write_port(0x60, byte)) return 0;
        int response = read_byte(auxiliary);
        if (response == 0xfa && inject_resend && !mouse_resends)
            response = 0xfe;
        if (response == 0xfa) {
            if (auxiliary) ++mouse_ack;
            return 1;
        }
        if (response != 0xfe) return 0;
        if (auxiliary) ++mouse_resends;
    }
    return 0;
}

static void route_keyboard(uint8_t byte)
{
    unsigned next = (head + 1) % QUEUE_SIZE;
    ++keyboard_routed;
    if (next == tail) ++keyboard_dropped;
    else { raw[head] = byte; head = next; }
    keyboard_wakes += wake_one_locked(&keyboard_waiters);
}

static void route_mouse(uint8_t byte)
{
    unsigned next = (mouse_head + 1) % QUEUE_SIZE;
    ++mouse_routed;
    if (next == mouse_tail) ++mouse_dropped;
    else { mouse_raw[mouse_head] = byte; mouse_head = next; }
}

static void ps2_receive(void)
{
    uint8_t status = inb(0x64);
    if (!(status & 1)) return;
    uint8_t byte = inb(0x60);
    if (status & 0xc0) {
        if (status & 0x20) ++mouse_dropped;
        else ++keyboard_dropped;
    } else if (status & 0x20) route_mouse(byte);
    else route_keyboard(byte);
}

static int controller_init(unsigned enable_mouse)
{
    /* timer_demo already remapped both PICs; device IRQs remain masked here. */
    if (!write_port(0x64, 0xad) || !write_port(0x64, 0xa7)) return 0;
    unsigned n;
    for (n = 0; n < 256 && (inb(0x64) & 1); ++n) (void)inb(0x60);
    if (inb(0x64) & 1) return 0;
    if (!write_port(0x64, 0x20)) return 0;
    int mode = read_byte(0);
    if (mode < 0 || !write_port(0x64, 0x60) ||
        !write_port(0x60, (mode & ~0x53) | 0x20) || !write_port(0x64, 0xae)) return 0;
    if (!device_command(0, 0xf5, 0) || !device_command(0, 0xf0, 0) ||
        !device_command(0, 1, 0) || !device_command(0, 0xf4, 0)) return 0;

    if (enable_mouse) {
        if (!write_port(0x64, 0xa8) || !device_command(1, 0xff, 0)) return 0;
        int bat = read_byte(1), id = read_byte(1);
        if (bat != 0xaa || id != 0) return 0;
        mouse_bat = (uint32_t)bat;
        mouse_id = (uint32_t)id;
        if (!device_command(1, 0xf4, 1)) return 0;
    }

    uint8_t final_mode = enable_mouse ? (uint8_t)((mode & ~0x73) | 0x03)
                                      : (uint8_t)((mode & ~0x52) | 0x21);
    if (!write_port(0x64, 0x60) || !write_port(0x60, final_mode)) return 0;
    outb(0x21, inb(0x21) & ~2u); /* Preserve the PIT's mask bit. */
    if (enable_mouse) {
        outb(0x21, inb(0x21) & ~4u);
        outb(0xa1, inb(0xa1) & ~0x10u);
    }
    keyboard_started = 1;
    mouse_started = enable_mouse;
    return 1;
}
void keyboard_irq(void)
{
    ++keyboard_irqs;
    ps2_receive();
    outb(0x20, 0x20);
}
void mouse_irq(void)
{
    ++mouse_irqs;
    ps2_receive();
    if (mouse_eoi_mode != 1) { outb(0xa0, 0x20); ++mouse_slave_eois; }
    if (mouse_eoi_mode != 2) { outb(0x20, 0x20); ++mouse_master_eois; }
}
void mouse_set_eoi_mode(unsigned mode) { mouse_eoi_mode = mode; }
void keyboard_ready(void) { __asm__ volatile("" ::: "memory"); }
int keyboard_start(void)
{
    uint32_t flags = irq_save();
    if (!keyboard_started) keyboard_started = controller_init(0);
    irq_restore(flags);
    return keyboard_started;
}
int mouse_start(void)
{
    uint32_t flags = irq_save();
    if (!mouse_started) mouse_started = controller_init(1);
    irq_restore(flags);
    return mouse_started;
}

int keyboard_poll_char(void)
{
    uint32_t flags = irq_save();
    if (seen_dropped != keyboard_dropped) {
        seen_dropped = keyboard_dropped;
        tail = head;
        parser = (struct key_parser){0};
        ++keyboard_resets;
        irq_restore(flags);
        return -1;
    }
    if (tail == head) { irq_restore(flags); return -2; }
    uint8_t byte = raw[tail];
    tail = (tail + 1) % QUEUE_SIZE;
    ++keyboard_bytes;
    irq_restore(flags);
    return keyboard_parse(&parser, byte);
}

int mouse_poll_event(struct mouse_event *event)
{
    for (;;) {
        uint32_t flags = irq_save();
        if (!mouse_consumer_paused && mouse_seen_dropped != mouse_dropped) {
            mouse_seen_dropped = mouse_dropped;
            mouse_tail = mouse_head;
            mouse_parser_reset(&mouse_parser);
            ++mouse_resets;
            irq_restore(flags);
            return -1;
        }
        if (mouse_consumer_paused || mouse_tail == mouse_head) {
            irq_restore(flags);
            return 0;
        }
        uint8_t byte = mouse_raw[mouse_tail];
        mouse_tail = (mouse_tail + 1) % QUEUE_SIZE;
        ++mouse_bytes;
        irq_restore(flags);
        int result = mouse_parse(&mouse_parser, byte, event);
        if (result) return result;
    }
}
int keyboard_read_char(void)
{
    if (!keyboard_start()) return -1;
    for (;;) {
        uint32_t flags = irq_save();
        if (!keyboard_consumer_paused && seen_dropped != keyboard_dropped) {
            seen_dropped = keyboard_dropped;
            tail = head;
            parser = (struct key_parser){0};
            keyboard_line_length = 0;
            keyboard_line[0] = 0;
            ++keyboard_resets;
            irq_restore(flags);
            return -1;
        }
        if (keyboard_consumer_paused || tail == head) {
            ++keyboard_blocks;
            task_block_locked(&keyboard_waiters);
            irq_restore(flags);
            continue;
        }
        uint8_t byte = raw[tail];
        tail = (tail + 1) % QUEUE_SIZE;
        ++keyboard_bytes;
        irq_restore(flags);
        int c = keyboard_parse(&parser, byte);
        if (c) return c;
    }
}
void keyboard_loop(void)
{
    (void)irq_save();
    if (!keyboard_start()) { kprintf("KEYBOARD INIT FAIL\n"); return; }
    console_init();
    kprintf("D09 PS/2 IRQ1 raw set1 translation=off\nRelease all keys after overflow; retry your line.\n> ");
    keyboard_ready();
    for (;;) {
        int c = keyboard_read_char();
        __asm__ volatile("sti" ::: "memory");
        if (c < 0) {
            kprintf("\nOVERFLOW dropped=%u: release ALL keys, retry line\n> ", seen_dropped);
            continue;
        }
        if (c == '\n') {
            kprintf("\nLINE: %s\n> ", keyboard_line);
            keyboard_line_length = 0; keyboard_line[0] = 0;
        } else if (c == '\b') {
            if (keyboard_line_length) { keyboard_line[--keyboard_line_length] = 0; console_putc('\b'); }
        } else if (c && keyboard_line_length < sizeof(keyboard_line) - 1) {
            keyboard_line[keyboard_line_length++] = c;
            keyboard_line[keyboard_line_length] = 0; console_putc(c);
        }
    }
}
#endif
