#include <stdint.h>
#include <stddef.h>
#include "runtime.h"
#include "console.h"
#include "exceptions.h"
#include "timer.h"
#include "keyboard.h"

#include "bootinfo.h"
#include "memory.h"
#include "paging.h"
#include "heap.h"
#include "task.h"
#include "user.h"
#include "block.h"
#include "fat.h"
#include "graphics.h"
volatile uint32_t initialized = 0x12345678;
volatile uint32_t zeroed;
volatile uint8_t zero_array[37];

static void result(const char *text)
{
    kprintf("%s\n", text);
}

static uint32_t add_one(uint32_t value) { return value + 1; }

void console_demo_done(void) { __asm__ volatile("" ::: "memory"); }

void kernel_main(const struct bootinfo *info)
{
    console_init(); /* entry cleared BSS/set stack; UART and VGA precede diagnostics. */
    unsigned expected_bootinfo = 1;
#if defined(TEST_GRAPHICS) || defined(TEST_GRAPHICS_TEXT) || \
    defined(TEST_MOUSE) || defined(TEST_MOUSE_NO_SLAVE_EOI) || \
    defined(TEST_MOUSE_NO_MASTER_EOI) || defined(TEST_WINDOW) || \
    defined(TEST_WINDOW_SHELL)
    expected_bootinfo = 2;
#endif
    if (info->magic != 0x31495442 || info->version != expected_bootinfo ||
        info->size != sizeof(*info)) {
        result("KERNEL BOOTINFO FAIL"); return;
    }
    if (initialized != 0x12345678 || add_one(41) != 42) {
        result("KERNEL DATA/CALL FAIL"); return;
    }
    if (zeroed != 0) { result("KERNEL BSS FAIL"); return; }
    for (size_t i = 0; i < sizeof(zero_array); ++i)
        if (zero_array[i] != 0) { result("KERNEL BSS FAIL"); return; }
    char bytes[8];
    memset(bytes, 0, sizeof(bytes));
    memcpy(bytes, "abcd", 4);
    memmove(bytes + 1, bytes, 4);
    if (memcmp(bytes, "aabcd", 5) != 0) { result("KERNEL RUNTIME FAIL"); return; }
    memmove(bytes, bytes + 1, 4);
    if (memcmp(bytes, "abcd", 4) != 0 || bytes[7] != 0) { result("KERNEL RUNTIME FAIL"); return; }
    exceptions_init();
    exception_probe();
    kprintf("EXCEPTION RETURN OK\n");
#ifdef TEST_DIVIDE
    divide_zero();
#endif
#ifdef TEST_UD2
    invalid_opcode();
#endif
#ifdef TEST_GP
    general_protection();
#endif
#if defined(TEST_TIMER_MONITOR)
    timer_demo(1);
#elif defined(TEST_TIMER_NOEOI)
    timer_demo(2);
#else
    timer_demo(0);
#endif
    console_init();
    result("KERNEL_MAIN OK");
    /* Exercise wrap and repeated scroll on the real text buffer. */
    for (unsigned i = 0; i < 80; ++i) console_putc('W');
    for (unsigned i = 0; i < 28; ++i) kprintf("scroll %u\n", i);
    kprintf("FMT %s %c %d %u %x %p %%\n", "ok", 'Z', (-2147483647 - 1), 0xffffffffu,
            0xdeadbeefu, (void *)0x1234);
    kprintf("ZERO %d %u %x %p NULL %s\n", 0, 0u, 0u, (void *)0, (const char *)0);
    kprintf("unknown=%q trailing=%");
    kprintf("\nabc\rR\bB\n");
    kprintf("CONSOLE OK\n");
#ifdef TEST_PANIC
    KASSERT(2 + 2 == 5);
#endif
    console_demo_done();
    memory_demo(info);
    paging_demo();
#ifdef TEST_PAGEFAULT
    paging_unhandled();
#endif
    heap_demo();
#ifdef TEST_HEAPFAULT
    heap_fault();
#endif
#ifdef TEST_TASKSTARVE
    task_demo(1);
#else
    task_demo(0);
#endif
#ifdef TEST_PREEMPT_MASK
    preempt_demo(1);
#else
    preempt_demo(0);
#endif
#ifdef TEST_WAIT_LOST
    wait_demo(1);
#else
    wait_demo(0);
#endif
    user_demo();
    syscall_demo();
    elf_demo();
#ifdef TEST_PROCESS_FAIL
    process_demo(1);
#else
    process_demo(0);
#endif
#if defined(TEST_BLOCK_TIMEOUT)
    block_demo(1);
#elif defined(TEST_BLOCK_ERROR)
    block_demo(2);
#elif defined(TEST_BLOCK_NODRQ)
    block_demo(3);
#else
    block_demo(0);
#endif
#if defined(TEST_BLOCK_TIMEOUT) || defined(TEST_BLOCK_ERROR) || defined(TEST_BLOCK_NODRQ)
    /* A failed ATA command intentionally leaves the channel unavailable. */
#elif defined(TEST_FAT_LOOP)
    fat_demo(1);
#elif defined(TEST_FAT_SHORT)
    fat_demo(2);
#elif defined(TEST_FAT_BADBPB)
    fat_demo(3);
#elif defined(TEST_FAT_MIRROR)
    fat_demo(4);
#elif defined(TEST_FAT_ROOTBOUND)
    fat_demo(5);
#elif defined(TEST_FAT_DIRHI)
    fat_demo(6);
#elif defined(TEST_FAT_EMPTYCLUSTER)
    fat_demo(7);
#elif defined(TEST_FAT_BADCLUSTER)
    fat_demo(8);
#elif defined(TEST_FAT_RESERVED)
    fat_demo(9);
#elif defined(TEST_FAT_OUTOFRANGE)
    fat_demo(10);
#elif defined(TEST_FAT_OVERSIZE)
    fat_demo(11);
#else
    fat_demo(0);
#endif
#if !defined(TEST_BLOCK_TIMEOUT) && !defined(TEST_BLOCK_ERROR) && \
    !defined(TEST_BLOCK_NODRQ) && !defined(TEST_FAT_LOOP) && \
    !defined(TEST_FAT_SHORT) && !defined(TEST_FAT_BADBPB) && \
    !defined(TEST_FAT_MIRROR) && !defined(TEST_FAT_ROOTBOUND) && \
    !defined(TEST_FAT_DIRHI) && !defined(TEST_FAT_EMPTYCLUSTER) && \
    !defined(TEST_FAT_BADCLUSTER) && !defined(TEST_FAT_RESERVED) && \
    !defined(TEST_FAT_OUTOFRANGE) && !defined(TEST_FAT_OVERSIZE)
#ifdef TEST_SHELL
    fd_demo(0);
    shell_start();
#elif defined(TEST_GRAPHICS_TEXT)
    fd_demo(0);
    graphics_text_demo(info);
#elif defined(TEST_MOUSE)
    fd_demo(0);
    graphics_mouse_demo(info, 0);
#elif defined(TEST_MOUSE_NO_SLAVE_EOI)
    fd_demo(0);
    graphics_mouse_demo(info, 1);
#elif defined(TEST_MOUSE_NO_MASTER_EOI)
    fd_demo(0);
    graphics_mouse_demo(info, 2);
#elif defined(TEST_WINDOW)
    fd_demo(0);
    graphics_window_demo(info);
#elif defined(TEST_WINDOW_SHELL)
    fd_demo(0);
    graphics_window_shell_demo(info);
#elif defined(TEST_GRAPHICS)
    fd_demo(0);
    graphics_demo(info);
#elif defined(TEST_FD_TERMINAL)
    fd_demo(1);
#elif defined(TEST_FD_FAIL)
    fd_demo(2);
#else
    fd_demo(0);
#endif
#endif
#if !defined(TEST_SHELL) && !defined(TEST_GRAPHICS) && \
    !defined(TEST_GRAPHICS_TEXT) && !defined(TEST_MOUSE) && \
    !defined(TEST_MOUSE_NO_SLAVE_EOI) && !defined(TEST_MOUSE_NO_MASTER_EOI) && \
    !defined(TEST_WINDOW) && !defined(TEST_WINDOW_SHELL)
    task_keyboard_start();
#endif
}
