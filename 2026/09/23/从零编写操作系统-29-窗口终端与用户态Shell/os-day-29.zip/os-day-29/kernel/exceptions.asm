bits 32
section .text
extern trap_dispatch
%macro ISR 1
global isr%1
isr%1:
%if %1 != 8 && %1 != 10 && %1 != 11 && %1 != 12 && %1 != 13 && %1 != 14 && %1 != 17
    push dword 0
%endif
    push dword %1
    jmp exception_common
%endmacro
%assign n 0
%rep 45
ISR n
%assign n n+1
%endrep
ISR 128
exception_common:
    pushad
    xor eax, eax
    mov ax, ds
    push eax
    mov ax, es
    push eax
    mov ax, fs
    push eax
    mov ax, gs
    push eax
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    cld
    mov ebx, esp
    and esp, -16
    sub esp, 12
    push ebx
    call trap_dispatch
    mov esp, ebx
    pop eax
    mov gs, ax
    pop eax
    mov fs, ax
    pop eax
    mov es, ax
    pop eax
    mov ds, ax
    popad
    add esp, 8
    iretd

global exception_probe, probe_resume, probe_restored
exception_probe:
    pushfd
    pushad
    mov eax, 0x11111111
    mov ecx, 0x22222222
    mov edx, 0x33333333
    mov ebx, 0x44444444
    mov ebp, 0x55555555
    mov esi, 0x66666666
    mov edi, 0x77777777
    std
    int3
probe_resume:
    pushfd
    pushad
probe_restored:
    cld
    add esp, 36
    popad
    popfd
    ret

global divide_zero, divide_fault, invalid_opcode, ud_fault, general_protection, gp_fault
divide_zero:
    xor edx, edx
    mov eax, 1
    xor ecx, ecx
divide_fault:
    div ecx
    ret
invalid_opcode:
ud_fault:
    ud2
    ret
general_protection:
    mov ax, 0x18
gp_fault:
    mov ds, ax
    ret

section .rodata
align 4
global exception_stubs
exception_stubs:
%assign n 0
%rep 45
    dd isr%+n
%assign n n+1
%endrep
