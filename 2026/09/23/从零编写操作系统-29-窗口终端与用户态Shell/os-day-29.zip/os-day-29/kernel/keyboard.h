#ifndef KEYBOARD_H
#define KEYBOARD_H
#include <stdint.h>
struct key_parser { uint8_t left, right, caps, caps_down, extended, pause; };
struct mouse_parser {
    uint8_t bytes[3], index;
    uint32_t sync_losses, overflow_packets, packets;
};
struct mouse_event { int16_t dx, dy; uint8_t buttons; };
int keyboard_parse(struct key_parser *p, uint8_t byte);
int mouse_parse(struct mouse_parser *p, uint8_t byte,
                struct mouse_event *event);
void mouse_parser_reset(struct mouse_parser *p);
void keyboard_irq(void);
void mouse_irq(void);
int keyboard_start(void);
int mouse_start(void);
int keyboard_read_char(void);
int keyboard_poll_char(void);
int mouse_poll_event(struct mouse_event *event);
void mouse_set_eoi_mode(unsigned mode);
void keyboard_loop(void);
extern volatile uint32_t keyboard_blocks;
extern volatile uint32_t keyboard_irqs, keyboard_dropped, keyboard_bytes;
extern volatile uint32_t mouse_irqs, mouse_dropped, mouse_bytes;
extern volatile uint32_t mouse_resets, mouse_routed, keyboard_routed;
extern volatile uint32_t mouse_ack, mouse_bat, mouse_id, mouse_resends;
extern volatile uint32_t mouse_slave_eois, mouse_master_eois;
extern volatile unsigned mouse_consumer_paused;
#endif
