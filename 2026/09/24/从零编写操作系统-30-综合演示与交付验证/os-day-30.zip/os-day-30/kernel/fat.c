#include <stddef.h>
#include <stdint.h>
#include "block.h"
#include "console.h"
#include "fat.h"
#include "runtime.h"

#define SECTOR_BYTES 512u
#define FAT16_MIN_CLUSTERS 4085u
#define FAT16_MAX_CLUSTERS 65525u
#define FAT16_EOC_MIN 0xfff8u
#define FAT16_BAD 0xfff7u
#define FAT_SEEN_BYTES 8192u

struct fat_volume {
    uint32_t partition_start, partition_sectors, total_sectors;
    uint32_t fat_start, root_start, data_start;
    uint32_t sectors_per_fat, root_sectors, cluster_count;
    uint16_t root_entries;
    uint8_t sectors_per_cluster, fat_count;
};

volatile int32_t fat_result;
volatile uint32_t fat_passed, fat_partition_start, fat_partition_sectors;
volatile uint32_t fat_clusters, fat_root_entries_seen, fat_file_size;
volatile uint32_t fat_file_hash, fat_read_bytes, fat_chain_steps;
volatile uint32_t fat_bad_cluster, fat_last_lba, fat_slice_checks;
volatile uint32_t fat_directory_reads, fat_directory_files;
uint8_t fat_readback[1536];

static struct fat_volume volume;
static uint8_t sector_a[SECTOR_BYTES], sector_b[SECTOR_BYTES];
static uint8_t seen[FAT_SEEN_BYTES];

static uint16_t get16(const uint8_t *p)
{ return (uint16_t)p[0] | ((uint16_t)p[1] << 8); }

static uint32_t get32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static int add_ok(uint32_t a, uint32_t b, uint32_t *out)
{
    if (a > UINT32_MAX - b) return 0;
    *out = a + b;
    return 1;
}

static int read_sector(uint32_t lba, uint8_t *buffer)
{
    fat_last_lba = lba;
    return block_read_sector(lba, buffer) == BLOCK_OK ? FAT_OK : FAT_EIO;
}

static int data_cluster(uint16_t cluster)
{
    return cluster >= 2 && cluster < 0xfff0u &&
           (uint32_t)cluster < volume.cluster_count + 2u;
}

static int cluster_lba(uint16_t cluster, uint32_t sector_index,
                       uint32_t *lba)
{
    if (!data_cluster(cluster) || sector_index >= volume.sectors_per_cluster)
        return FAT_ECHAIN;
    uint32_t relative = (uint32_t)(cluster - 2u) * volume.sectors_per_cluster;
    if (!add_ok(relative, sector_index, &relative) ||
        !add_ok(relative, volume.data_start, &relative) ||
        relative >= volume.total_sectors ||
        !add_ok(volume.partition_start, relative, lba))
        return FAT_ECORRUPT;
    return FAT_OK;
}

static int fat_next(uint16_t cluster, uint16_t *next)
{
    if (!data_cluster(cluster)) { fat_bad_cluster = cluster; return FAT_ECHAIN; }
    uint32_t offset = (uint32_t)cluster * 2u;
    uint32_t fat_sector = offset / SECTOR_BYTES;
    uint32_t within = offset % SECTOR_BYTES;
    if (fat_sector >= volume.sectors_per_fat) return FAT_ECORRUPT;
    uint32_t lba1, lba2;
    if (!add_ok(volume.partition_start, volume.fat_start + fat_sector, &lba1) ||
        !add_ok(lba1, volume.sectors_per_fat, &lba2))
        return FAT_ECORRUPT;
    if (read_sector(lba1, sector_a) != FAT_OK ||
        read_sector(lba2, sector_b) != FAT_OK)
        return FAT_EIO;
    uint16_t first = get16(sector_a + within);
    uint16_t second = get16(sector_b + within);
    if (first != second) { fat_bad_cluster = cluster; return FAT_EMIRROR; }
    *next = first;
    return FAT_OK;
}

static int validate_chain(const struct fat_file *file)
{
    fat_chain_steps = 0;
    if (!file->size) return file->first_cluster ? FAT_ECHAIN : FAT_OK;
    if (!data_cluster(file->first_cluster)) {
        fat_bad_cluster = file->first_cluster; return FAT_ECHAIN;
    }
    uint32_t cluster_bytes = (uint32_t)volume.sectors_per_cluster * SECTOR_BYTES;
    uint32_t needed = file->size / cluster_bytes;
    if (file->size % cluster_bytes) ++needed;
    if (!needed || needed > volume.cluster_count) return FAT_ECHAIN;
    memset(seen, 0, sizeof(seen));
    uint16_t cluster = file->first_cluster;
    for (uint32_t i = 0; i < needed; ++i) {
        if (!data_cluster(cluster)) { fat_bad_cluster = cluster; return FAT_ECHAIN; }
        uint32_t byte = cluster >> 3;
        uint8_t bit = (uint8_t)(1u << (cluster & 7));
        if (seen[byte] & bit) { fat_bad_cluster = cluster; return FAT_ECHAIN; }
        seen[byte] |= bit;
        ++fat_chain_steps;
        uint16_t next;
        int result = fat_next(cluster, &next);
        if (result != FAT_OK) return result;
        if (i + 1u == needed) {
            if (next < FAT16_EOC_MIN) { fat_bad_cluster = next; return FAT_ECHAIN; }
        } else {
            if (next >= FAT16_EOC_MIN || next == FAT16_BAD ||
                (next >= 0xfff0u && next < FAT16_EOC_MIN) ||
                !data_cluster(next)) {
                fat_bad_cluster = next; return FAT_ECHAIN;
            }
        }
        cluster = next;
    }
    return FAT_OK;
}

int fat_mount(void)
{
    memset(&volume, 0, sizeof(volume));
    if (read_sector(0, sector_a) != FAT_OK) return FAT_EIO;
    if (sector_a[510] != 0x55 || sector_a[511] != 0xaa) return FAT_ECORRUPT;
    const uint8_t *part = sector_a + 446;
    uint32_t start = get32(part + 8), length = get32(part + 12);
    if (part[4] != 0x04 || !start || !length) return FAT_ENOPART;
    uint32_t capacity = block_sector_count();
    if (start >= capacity || length > capacity - start) return FAT_ECORRUPT;
    if (read_sector(start, sector_a) != FAT_OK) return FAT_EIO;
    if (sector_a[510] != 0x55 || sector_a[511] != 0xaa) return FAT_ECORRUPT;

    uint16_t bytes = get16(sector_a + 11);
    uint8_t spc = sector_a[13], fats = sector_a[16];
    uint16_t reserved = get16(sector_a + 14);
    uint16_t roots = get16(sector_a + 17);
    uint32_t total = get16(sector_a + 19);
    uint32_t fat_size = get16(sector_a + 22);
    if (!total) total = get32(sector_a + 32);
    if (bytes != SECTOR_BYTES || !spc || (spc & (spc - 1u)) ||
        !reserved || fats != 2 || !roots || !fat_size)
        return FAT_ENOTSUP;
    if (get32(sector_a + 28) != start || !total || total > length)
        return FAT_ECORRUPT;

    uint32_t root_bytes = (uint32_t)roots * 32u;
    uint32_t root_sectors = (root_bytes + SECTOR_BYTES - 1u) / SECTOR_BYTES;
    if (fat_size > UINT32_MAX / fats) return FAT_ECORRUPT;
    uint32_t first_data = reserved + fats * fat_size;
    if (!add_ok(first_data, root_sectors, &first_data) || first_data >= total)
        return FAT_ECORRUPT;
    uint32_t clusters = (total - first_data) / spc;
    if (clusters < FAT16_MIN_CLUSTERS || clusters >= FAT16_MAX_CLUSTERS)
        return FAT_ENOTSUP;
    if (fat_size > UINT32_MAX / SECTOR_BYTES ||
        fat_size * SECTOR_BYTES / 2u < clusters + 2u)
        return FAT_ECORRUPT;

    volume.partition_start = start;
    volume.partition_sectors = length;
    volume.total_sectors = total;
    volume.fat_start = reserved;
    volume.sectors_per_fat = fat_size;
    volume.root_start = reserved + fats * fat_size;
    volume.root_sectors = root_sectors;
    volume.data_start = first_data;
    volume.cluster_count = clusters;
    volume.root_entries = roots;
    volume.sectors_per_cluster = spc;
    volume.fat_count = fats;
    fat_partition_start = start;
    fat_partition_sectors = length;
    fat_clusters = clusters;
    return FAT_OK;
}

static int make_name(const char *input, uint8_t output[11])
{
    if (!input) return FAT_ENAME;
    for (unsigned i = 0; i < 11; ++i) output[i] = ' ';
    unsigned base = 0, ext = 0, dotted = 0;
    for (; *input; ++input) {
        uint8_t ch = (uint8_t)*input;
        if (ch == '.') {
            if (dotted || !base) return FAT_ENAME;
            dotted = 1; continue;
        }
        if (ch >= 'a' && ch <= 'z') ch -= 'a' - 'A';
        if (!((ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') ||
              ch == '_' || ch == '-')) return FAT_ENAME;
        if (!dotted) {
            if (base == 8) return FAT_ENAME;
            output[base++] = ch;
        } else {
            if (ext == 3) return FAT_ENAME;
            output[8 + ext++] = ch;
        }
    }
    return base ? FAT_OK : FAT_ENAME;
}

int fat_open(const char *name, struct fat_file *file)
{
    uint8_t wanted[11];
    if (!file) return FAT_EINVAL;
    int result = make_name(name, wanted);
    if (result != FAT_OK) return result;
    uint32_t entry_index = 0;
    for (uint32_t s = 0; s < volume.root_sectors; ++s) {
        uint32_t lba;
        if (!add_ok(volume.partition_start, volume.root_start + s, &lba))
            return FAT_ECORRUPT;
        if (read_sector(lba, sector_a) != FAT_OK) return FAT_EIO;
        for (unsigned offset = 0;
             offset < SECTOR_BYTES && entry_index < volume.root_entries;
             offset += 32, ++entry_index) {
            const uint8_t *entry = sector_a + offset;
            if (entry[0] == 0) return FAT_ENOENT;
            if (entry[0] == 0xe5 || entry[0] == 0x05 ||
                entry[11] == 0x0f || (entry[11] & 0x18))
                continue;
            ++fat_root_entries_seen;
            if (memcmp(entry, wanted, 11) != 0) continue;
            if (get16(entry + 20) != 0) return FAT_ECORRUPT;
            memcpy(file->name, entry, 11);
            file->first_cluster = get16(entry + 26);
            file->size = get32(entry + 28);
            if (!file->size && file->first_cluster) return FAT_ECHAIN;
            return FAT_OK;
        }
    }
    return FAT_ENOENT;
}

static void display_name(const uint8_t raw[11], char output[13])
{
    unsigned end = 8;
    while (end && raw[end - 1] == ' ') --end;
    unsigned length = 0;
    for (unsigned i = 0; i < end; ++i) output[length++] = (char)raw[i];
    unsigned extension = 3;
    while (extension && raw[8 + extension - 1] == ' ') --extension;
    if (extension) {
        output[length++] = '.';
        for (unsigned i = 0; i < extension; ++i)
            output[length++] = (char)raw[8 + i];
    }
    output[length] = 0;
}

int fat_readdir(uint32_t index, struct fat_dirent *result)
{
    if (!result) return FAT_EINVAL;
    uint32_t entry_index = 0, visible = 0;
    for (uint32_t s = 0; s < volume.root_sectors; ++s) {
        uint32_t lba;
        if (!add_ok(volume.partition_start, volume.root_start + s, &lba))
            return FAT_ECORRUPT;
        if (read_sector(lba, sector_a) != FAT_OK) return FAT_EIO;
        ++fat_directory_reads;
        for (unsigned offset = 0;
             offset < SECTOR_BYTES && entry_index < volume.root_entries;
             offset += 32, ++entry_index) {
            const uint8_t *entry = sector_a + offset;
            if (entry[0] == 0) return 0;
            if (entry[0] == 0xe5 || entry[0] == 0x05 ||
                entry[11] == 0x0f || (entry[11] & 0x18))
                continue;
            if (visible++ != index) continue;
            if (get16(entry + 20) != 0) return FAT_ECORRUPT;
            memset(result, 0, sizeof(*result));
            display_name(entry, result->name);
            result->attributes = entry[11];
            result->size = get32(entry + 28);
            if (!result->size && get16(entry + 26)) return FAT_ECHAIN;
            if (fat_directory_files < visible)
                fat_directory_files = visible;
            return 1;
        }
    }
    return 0;
}

int fat_read_at(const struct fat_file *file, uint32_t offset,
                void *buffer, uint32_t length)
{
    if (!file || (!buffer && length)) return FAT_EINVAL;
    if (offset >= file->size || !length) return 0;
    uint32_t available = file->size - offset;
    if (length > available) length = available;
    int result = validate_chain(file);
    if (result != FAT_OK) return result;

    uint32_t cluster_bytes = (uint32_t)volume.sectors_per_cluster * SECTOR_BYTES;
    uint32_t skip = offset / cluster_bytes;
    uint32_t within_cluster = offset % cluster_bytes;
    uint16_t cluster = file->first_cluster;
    for (uint32_t i = 0; i < skip; ++i) {
        result = fat_next(cluster, &cluster);
        if (result != FAT_OK) return result;
    }

    uint8_t *out = buffer;
    uint32_t done = 0;
    while (done < length) {
        for (uint32_t s = within_cluster / SECTOR_BYTES;
             s < volume.sectors_per_cluster && done < length; ++s) {
            uint32_t lba;
            result = cluster_lba(cluster, s, &lba);
            if (result != FAT_OK || read_sector(lba, sector_a) != FAT_OK)
                return result != FAT_OK ? result : FAT_EIO;
            uint32_t begin = within_cluster % SECTOR_BYTES;
            uint32_t take = SECTOR_BYTES - begin;
            if (take > length - done) take = length - done;
            memcpy(out + done, sector_a + begin, take);
            done += take;
            within_cluster = 0;
        }
        if (done < length) {
            result = fat_next(cluster, &cluster);
            if (result != FAT_OK) return result;
        }
    }
    return (int)done;
}

static uint32_t hash_bytes(const uint8_t *bytes, uint32_t length)
{
    uint32_t hash = 2166136261u;
    for (uint32_t i = 0; i < length; ++i) hash = (hash ^ bytes[i]) * 16777619u;
    return hash;
}

void fat_demo_done(void) { __asm__ volatile("nop" ::: "memory"); }

void fat_demo(unsigned mode)
{
    fat_result = 0;
    fat_passed = fat_partition_start = fat_partition_sectors = 0;
    fat_clusters = fat_root_entries_seen = fat_file_size = 0;
    fat_file_hash = fat_read_bytes = fat_chain_steps = 0;
    fat_bad_cluster = fat_last_lba = fat_slice_checks = 0;
    memset(fat_readback, 0xcc, sizeof(fat_readback));
    fat_result = fat_mount();
    if (mode == 3) {
        KASSERT(fat_result == FAT_ENOTSUP || fat_result == FAT_ECORRUPT);
    } else if (mode == 5) {
        KASSERT(fat_result == FAT_OK);
        struct fat_file file;
        fat_result = fat_open("README.TXT", &file);
        KASSERT(fat_result == FAT_ENOENT && fat_root_entries_seen == 0);
    } else if (mode == 6 || mode == 7) {
        KASSERT(fat_result == FAT_OK);
        struct fat_file file;
        fat_result = fat_open(mode == 6 ? "README.TXT" : "EMPTY.TXT", &file);
        KASSERT(fat_result == (mode == 6 ? FAT_ECORRUPT : FAT_ECHAIN));
    } else {
        KASSERT(fat_result == FAT_OK);
        struct fat_file file, empty;
        KASSERT(fat_open("readme.txt", &file) == FAT_OK);
        KASSERT(fat_open("EMPTY.TXT", &empty) == FAT_OK && !empty.size &&
                !empty.first_cluster);
        KASSERT(fat_open("TOO-LONG-NAME.TXT", &empty) == FAT_ENAME);
        KASSERT(fat_open("MISSING.TXT", &empty) == FAT_ENOENT);
        fat_file_size = file.size;
        fat_result = fat_read_at(&file, 0, fat_readback, sizeof(fat_readback));
        if (!mode) {
            KASSERT(fat_result == (int32_t)file.size && file.size <= sizeof(fat_readback));
            fat_read_bytes = (uint32_t)fat_result;
            fat_file_hash = hash_bytes(fat_readback, fat_read_bytes);
            uint8_t slice[600];
            KASSERT(fat_read_at(&file, 300, slice, sizeof(slice)) == (int)sizeof(slice));
            KASSERT(memcmp(slice, fat_readback + 300, sizeof(slice)) == 0);
            ++fat_slice_checks;
            KASSERT(fat_read_at(&file, 1400, slice, sizeof(slice)) == 79);
            KASSERT(memcmp(slice, fat_readback + 1400, 79) == 0);
            ++fat_slice_checks;
            KASSERT(fat_read_at(&file, file.size, fat_readback, 1) == 0);
            ++fat_slice_checks;
        } else if (mode == 4) {
            KASSERT(fat_result == FAT_EMIRROR);
        } else {
            KASSERT(fat_result == FAT_ECHAIN);
        }
    }
    fat_passed = 1;
    kprintf("D21 FAT mode=%u result=%d part=%u+%u clusters=%u file=%u read=%u hash=%x steps=%u slices=%u bad=%x lba=%u\n",
            mode, fat_result, fat_partition_start, fat_partition_sectors,
            fat_clusters, fat_file_size, fat_read_bytes, fat_file_hash,
            fat_chain_steps, fat_slice_checks, fat_bad_cluster, fat_last_lba);
    kprintf("FAT OK mode=%u\n", mode);
    fat_demo_done();
}
