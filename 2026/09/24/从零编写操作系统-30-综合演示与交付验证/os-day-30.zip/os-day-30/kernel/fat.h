#ifndef FAT_H
#define FAT_H

#include <stdint.h>

enum fat_error {
    FAT_OK = 0,
    FAT_EIO = -1,
    FAT_ENOPART = -2,
    FAT_ECORRUPT = -3,
    FAT_ENOTSUP = -4,
    FAT_ENOENT = -5,
    FAT_ENAME = -6,
    FAT_ECHAIN = -7,
    FAT_EMIRROR = -8,
    FAT_EINVAL = -9,
};

struct fat_file {
    uint8_t name[11];
    uint16_t first_cluster;
    uint32_t size;
};

struct fat_dirent {
    char name[13];
    uint8_t attributes;
    uint16_t reserved;
    uint32_t size;
};

int fat_mount(void);
int fat_open(const char *name, struct fat_file *file);
int fat_readdir(uint32_t index, struct fat_dirent *entry);
int fat_read_at(const struct fat_file *file, uint32_t offset,
                void *buffer, uint32_t length);
void fat_demo(unsigned mode);

extern volatile int32_t fat_result;
extern volatile uint32_t fat_passed, fat_partition_start, fat_partition_sectors;
extern volatile uint32_t fat_clusters, fat_root_entries_seen, fat_file_size;
extern volatile uint32_t fat_file_hash, fat_read_bytes, fat_chain_steps;
extern volatile uint32_t fat_bad_cluster, fat_last_lba, fat_slice_checks;
extern volatile uint32_t fat_directory_reads, fat_directory_files;
extern uint8_t fat_readback[1536];

#endif
