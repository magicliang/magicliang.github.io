#include "task.h"
#include "memory.h"
#include "runtime.h"
#include "console.h"
#include "timer.h"
#include "keyboard.h"
#include "user.h"
#include "syscall.h"
#include "elf.h"
#include "file.h"
#include "fat.h"
#define TASK_SLOTS 6u
#define PROCESS_SLOTS 4u
#define LEGACY_SLOTS 3u
#define CANARY 0x51accafeu
#define PROCESS_SHELL_KIND 12u
enum task_state { DEAD, RUNNABLE, RUNNING, BLOCKED, ZOMBIE };
struct task {
    uint32_t *saved_sp;
    uint32_t kernel_stack;
    enum task_state state;
    void (*entry)(void *);
    void *arg;
    unsigned trap_depth, preempt_count;
    struct wait_queue *waiting_on;
    unsigned sleeping;
    uint32_t wake_tick;
    struct user_space user;
    unsigned user_stop, user_fault;
    uint32_t user_error, user_address, user_eip;
    int32_t pid, parent_pid, waiting_pid;
    uint32_t exit_status;
    unsigned program_kind;
    struct wait_queue exit_waiters;
    struct open_file *fds[FD_MAX];
};
static struct task tasks[TASK_SLOTS];
static unsigned current;
static unsigned task_limit = LEGACY_SLOTS;
volatile uint32_t task_counts[2], task_local_address[2], task_stack_used[2];
volatile uint32_t task_switches, task_reaped, task_passed, task_initial_pages;
static unsigned starvation;
static unsigned preempt_active;
static unsigned idle_active;
volatile unsigned need_resched;
volatile uint32_t preempt_switches, preempt_deferred;
extern void switch_context(uint32_t **old_sp, uint32_t *new_sp);
extern void task_trampoline(void);
extern int task_register_probe(unsigned seed);
volatile uint32_t syscall_yield_before, syscall_yield_after, syscall_yield_switched;
volatile uint32_t shell_user_cs, shell_user_eip;
static unsigned syscall_yield_owner, syscall_yield_target, syscall_yield_stage;
static unsigned syscall_yield_probe_active;
static void process_publish_exit(struct task *task);
static void process_drive_release(void);
uint32_t irq_save(void)
{
    uint32_t flags;
    __asm__ volatile("pushfl; popl %0; cli" : "=r"(flags) : : "memory");
    return flags;
}
void irq_restore(uint32_t flags)
{ __asm__ volatile("pushl %0; popfl" : : "r"(flags) : "memory", "cc"); }

int task_fd_has_free_current(void)
{
    uint32_t flags = irq_save();
    int available = 0;
    for (unsigned i = 0; i < FD_MAX; ++i)
        if (!tasks[current].fds[i]) { available = 1; break; }
    irq_restore(flags);
    return available;
}

int task_fd_install_current(struct open_file *file)
{
    KASSERT(file);
    uint32_t flags = irq_save();
    for (unsigned i = 0; i < FD_MAX; ++i) {
        if (tasks[current].fds[i]) continue;
        tasks[current].fds[i] = file;
        irq_restore(flags);
        return (int)i;
    }
    irq_restore(flags);
    return -FILE_EMFILE;
}

int task_fd_install_pair_current(struct open_file *first,
                                 struct open_file *second, int fds[2])
{
    KASSERT(first && second && fds);
    uint32_t flags = irq_save();
    int slots[2] = {-1, -1};
    for (unsigned i = 0; i < FD_MAX; ++i) {
        if (tasks[current].fds[i]) continue;
        if (slots[0] < 0) slots[0] = (int)i;
        else { slots[1] = (int)i; break; }
    }
    if (slots[1] < 0) { irq_restore(flags); return -FILE_EMFILE; }
    tasks[current].fds[slots[0]] = first;
    tasks[current].fds[slots[1]] = second;
    fds[0] = slots[0];
    fds[1] = slots[1];
    irq_restore(flags);
    return 0;
}

struct open_file *task_fd_acquire_current(int fd)
{
    uint32_t flags = irq_save();
    struct open_file *file = 0;
    if (fd >= 0 && (unsigned)fd < FD_MAX) file = tasks[current].fds[fd];
    if (file && !file_get(file)) file = 0;
    irq_restore(flags);
    return file;
}

int task_fd_close_current(int fd)
{
    uint32_t flags = irq_save();
    if (fd < 0 || (unsigned)fd >= FD_MAX || !tasks[current].fds[fd]) {
        irq_restore(flags);
        return -FILE_EBADF;
    }
    struct open_file *file = tasks[current].fds[fd];
    tasks[current].fds[fd] = 0;
    irq_restore(flags);
    file_put(file);
    return 0;
}

static unsigned task_fd_close_all(struct task *task)
{
    unsigned closed = 0;
    for (unsigned i = 0; i < FD_MAX; ++i) {
        struct open_file *file = task->fds[i];
        if (!file) continue;
        task->fds[i] = 0;
        file_put(file);
        ++closed;
    }
    return closed;
}
/* A suspended scheduler returns with IF=0; its caller restores its own flags. */
static void schedule_locked_depth(unsigned allowed_depth)
{
    uint32_t flags;
    __asm__ volatile("pushfl; popl %0" : "=r"(flags));
    KASSERT(!(flags & 0x200));
    KASSERT(tasks[current].trap_depth == allowed_depth &&
            !tasks[current].preempt_count);
    unsigned old = current;
    need_resched = 0; /* Consume before switching; a new task may request again. */
    for (unsigned n = 1; n <= task_limit + idle_active; ++n) {
        unsigned next = (old + n) % task_limit;
        if (idle_active) {
            if (n <= task_limit && next == 0) continue;
            if (n == task_limit + 1) next = 0;
        }
        if (tasks[next].state != RUNNABLE) continue;
        current = next;
        tasks[next].state = RUNNING;
        if (next != old) {
            if (syscall_yield_stage == 1 && syscall_yield_owner == old) {
                syscall_yield_target = next;
                KASSERT(tasks[next].user.pages[4]);
                syscall_yield_before = *(uint32_t *)tasks[next].user.pages[4];
                syscall_yield_switched = 1;
                syscall_yield_stage = 2;
            } else if (syscall_yield_stage == 2 && next == syscall_yield_owner) {
                syscall_yield_after = *(uint32_t *)tasks[syscall_yield_target].user.pages[4];
                syscall_yield_stage = 0;
            }
            if (preempt_active) ++preempt_switches;
            else ++task_switches;
            user_switch(tasks[next].user.pages[0], tasks[next].kernel_stack + PAGE_BYTES);
            switch_context(&tasks[old].saved_sp, tasks[next].saved_sp);
        }
        return;
    }
    panic(__FILE__, __LINE__, "no runnable bootstrap");
}
static void schedule_locked(void) { schedule_locked_depth(0); }
static int task_create_space(void (*entry)(void *), void *arg, const struct user_space *space)
{
    uint32_t flags = irq_save();
    if (!entry && !space) { irq_restore(flags); return 0; }
    for (unsigned i = 1; i < LEGACY_SLOTS; ++i) {
        struct task *t = &tasks[i];
        if (t->state != DEAD || t->kernel_stack) continue;
        int injected = space &&
            ((space->kind == USER_SPACE_BLOB && user_fail_after == 6) ||
             (space->kind == USER_SPACE_ELF &&
              elf_fail_after == space->page_count));
        uint32_t page = injected ? 0 : page_alloc();
        if (!page) { irq_restore(flags); return 0; }
        memset((void *)page, 0xa5, PAGE_BYTES);
        *(uint32_t *)page = CANARY;
        uint32_t *sp = (uint32_t *)(page + PAGE_BYTES);
        *--sp = (uint32_t)task_trampoline;
        *--sp = 0; /* EBP */
        *--sp = 0; /* EBX */
        *--sp = 0; /* ESI */
        *--sp = 0; /* EDI */
        *t = (struct task){.saved_sp=sp, .kernel_stack=page, .state=DEAD,
                          .entry=entry, .arg=arg};
        if (space) t->user = *space;
        t->state = RUNNABLE;
        irq_restore(flags);
        return 1;
    }
    irq_restore(flags);
    return 0;
}
int task_create(void (*entry)(void *), void *arg)
{ return task_create_space(entry, arg, 0); }
void task_yield(void)
{
    uint32_t flags = irq_save();
    tasks[current].state = RUNNABLE;
    schedule_locked();
    irq_restore(flags);
}
void task_request_reschedule(void)
{
    KASSERT(current && tasks[current].user.pages[0]);
    if (syscall_yield_probe_active) {
        syscall_yield_owner = current;
        syscall_yield_stage = 1;
    }
    need_resched = 1;
}
_Noreturn void task_exit(void)
{
    (void)irq_save();
    KASSERT(current != 0);
    KASSERT(!tasks[current].waiting_on && !tasks[current].sleeping);
    if (tasks[current].pid)
        process_publish_exit(&tasks[current]);
    else
        tasks[current].state = DEAD;
    schedule_locked();
    panic(__FILE__, __LINE__, "exited task resumed");
}
void task_start(void)
{
    if (tasks[current].user.pages[0])
        enter_user(tasks[current].user.entry, tasks[current].user.stack_top);
    /* D13 retains IF=0; only the separately initialized D14 PIT permits STI. */
    if (preempt_active) __asm__ volatile("sti" ::: "memory");
    tasks[current].entry(tasks[current].arg);
}
void task_sample(void) { __asm__ volatile("" ::: "memory"); }
void task_starving(void) { __asm__ volatile("" ::: "memory"); }
void task_demo_done(void) { __asm__ volatile("" ::: "memory"); }
static void counter(void *arg)
{
    unsigned id = (uintptr_t)arg;
    volatile uint32_t local[8];
    for (unsigned j = 0; j < 8; ++j) local[j] = 0x1000u * (id + 1) + j;
    task_local_address[id] = (uintptr_t)local;
    if (starvation && id == 0) {
        kprintf("D13 NO-YIELD A running; B=0 (cooperative only)\n");
        task_starving();
        for (;;) ++task_counts[0];
    }
    if (id == 1) __asm__ volatile("sti" ::: "memory"); /* PIC remains fully masked. */
    for (unsigned i = 0; i < 128; ++i) {
        KASSERT(task_counts[id] == i);
        KASSERT(task_counts[1 - id] == i + id);
        ++task_counts[id];
        task_sample();
        KASSERT(task_register_probe(id + 1));
        uint32_t observed = irq_save();
        KASSERT(!!(observed & 0x200) == id);
        irq_restore(observed);
        for (unsigned j = 0; j < 8; ++j)
            KASSERT(local[j] == 0x1000u * (id + 1) + j);
    }
}
void task_demo(unsigned starve)
{
    uint32_t flags = irq_save();
    starvation = starve;
    task_initial_pages = page_free_count();
    tasks[0].state = RUNNING;
    KASSERT(task_create(counter, (void *)0));
    KASSERT(task_create(counter, (void *)1));
    KASSERT(!task_create(counter, 0));
    KASSERT(page_free_count() == task_initial_pages - 2);
    while (tasks[1].state != DEAD || tasks[2].state != DEAD) task_yield();
    for (unsigned i = 1; i < LEGACY_SLOTS; ++i) {
        uint32_t page = tasks[i].kernel_stack;
        KASSERT(*(uint32_t *)page == CANARY);
        unsigned untouched = 4;
        while (untouched < PAGE_BYTES && *(uint8_t *)(page + untouched) == 0xa5) ++untouched;
        task_stack_used[i - 1] = PAGE_BYTES - untouched;
        KASSERT(task_stack_used[i - 1] < PAGE_BYTES - 256);
        KASSERT(page_free(page));
        tasks[i].kernel_stack = 0;
        ++task_reaped;
    }
    KASSERT(task_counts[0] == 128 && task_counts[1] == 128);
    KASSERT(page_free_count() == task_initial_pages);
    /* Exercise an IF=1 continuation with PIC masks still 0xff, no live IRQs. */
    __asm__ volatile("sti" ::: "memory");
    task_yield();
    uint32_t restored = irq_save();
    KASSERT(restored & 0x200);
    task_yield();
    restored = irq_save();
    KASSERT(!(restored & 0x200));
    task_passed = 1;
    kprintf("D13 TASKS A=%u B=%u switches=%u reaped=%u\n", task_counts[0], task_counts[1], task_switches, task_reaped);
    kprintf("D13 stack used A=%u B=%u of 4096; locals/registers OK\n", task_stack_used[0], task_stack_used[1]);
    kprintf("TASKS OK pages recovered; IF=0/1 preserved\n");
    task_demo_done();
    irq_restore(flags);
}

/* No nested IRQ enable in handlers; depth is nevertheless owned by each task. */
void task_trap_enter(void) { ++tasks[current].trap_depth; }
static void wait_tick(void);
void task_tick(void)
{
    if (preempt_active) need_resched = 1;
    if (idle_active) wait_tick();
}
static void preempt_pending(void)
{
    if (!preempt_active || !need_resched || tasks[current].trap_depth) return;
    if (tasks[current].preempt_count) { ++preempt_deferred; return; }
    tasks[current].state = RUNNABLE;
    schedule_locked();
}
void task_trap_leave(unsigned interrupted_if)
{
    KASSERT(tasks[current].trap_depth);
    --tasks[current].trap_depth;
    if (!tasks[current].trap_depth && tasks[current].user_stop) task_exit();
    if (!tasks[current].trap_depth) process_drive_release();
    if (interrupted_if) preempt_pending();
}
void preempt_disable(void)
{
    uint32_t flags = irq_save();
    ++tasks[current].preempt_count;
    irq_restore(flags);
}
void preempt_enable(void)
{
    uint32_t flags = irq_save();
    KASSERT(tasks[current].preempt_count);
    --tasks[current].preempt_count;
    /* Original IF=0 belongs to the caller: defer until a later safe IRQ exit. */
    if (flags & 0x200) preempt_pending();
    irq_restore(flags);
}

volatile uint32_t preempt_counts[2], preempt_probe_passes, preempt_stack_used[2];
volatile uint32_t preempt_passed, preempt_initial_pages, preempt_reaped;
volatile uint32_t preempt_critical_ticks, preempt_nested_ok, preempt_if0_ok, preempt_enable_ok;
volatile unsigned preempt_cli_release = 1, preempt_work_release = 1;
volatile uint32_t preempt_cli_ticks, preempt_cli_switches;
volatile unsigned preempt_mask_requested, preempt_mask_actual;
static unsigned preempt_diagnostic;
extern void preempt_register_probe(unsigned seed);
void preempt_progress_sample(void) { __asm__ volatile("" ::: "memory"); }
void preempt_cli_sample(void) { __asm__ volatile("" ::: "memory"); }
void preempt_mask_sample(void) { __asm__ volatile("" ::: "memory"); }
void preempt_demo_done(void) { __asm__ volatile("" ::: "memory"); }
void preempt_probe_check(const uint32_t *r)
{
    uint32_t flags = irq_save();
    /* PUSHAD: EDI ESI EBP ESP EBX EDX ECX EAX, then PUSHFD. */
    KASSERT(r[0] == 0x77777777u + current && r[1] == 0x66666666u + current);
    KASSERT(r[2] == 0x55555555u + current && r[4] == 0x44444444u + current);
    KASSERT(r[5] == 0x33333333u + current && r[6] == 0x22222222u + current && r[7] == 0x11111111u + current);
    KASSERT((r[8] & 0xed5) == 0x645 && (r[8] & 0x200));
    ++preempt_probe_passes;
    irq_restore(flags);
}
static void busy_counter(void *arg)
{
    unsigned id = (uintptr_t)arg;
    if (preempt_diagnostic && id == 0) {
        uint32_t flags = irq_save();
        timer_mask(1);
        preempt_mask_requested = preempt_mask_actual = 1;
        kprintf("D14 IRQ0 masked: A busy, B stalled; GDB releases mask\n");
        preempt_mask_sample();
        irq_restore(flags);
        while (preempt_mask_requested) ++preempt_counts[id];
        timer_mask(0);
        preempt_mask_actual = 0;
    }
    /* Independent CPU work. No yield/HLT/calls inside this progress loop. */
    while (!preempt_work_release || preempt_counts[0] < 200000 || preempt_counts[1] < 200000)
        ++preempt_counts[id];
    for (unsigned n = 0; n < 4; ++n) {
        uint32_t switches = preempt_switches;
        preempt_register_probe(id + 1);
        KASSERT(preempt_switches > switches);
    }
}
void preempt_demo(unsigned diagnostic)
{
    uint32_t original = irq_save();
    preempt_diagnostic = diagnostic;
    preempt_initial_pages = page_free_count();
    KASSERT(task_create(busy_counter, (void *)0));
    KASSERT(task_create(busy_counter, (void *)1));
    preempt_active = 1;
    timer_start();
    preempt_disable();
    preempt_disable();
    __asm__ volatile("sti" ::: "memory");
    uint32_t start = timer_ticks;
    while (timer_ticks - start < 3) __asm__ volatile("" ::: "memory");
    KASSERT(preempt_switches == 0 && need_resched);
    preempt_critical_ticks = timer_ticks - start;
    preempt_enable();
    KASSERT(preempt_switches == 0 && tasks[0].preempt_count == 1);
    preempt_nested_ok = 1;
    preempt_enable();
    KASSERT(preempt_switches > 0);
    preempt_enable_ok = 1;
    preempt_disable();
    start = timer_ticks;
    while (timer_ticks - start < 2) __asm__ volatile("" ::: "memory");
    uint32_t enabled = irq_save();
    uint32_t held_switches = preempt_switches;
    preempt_enable();
    KASSERT(preempt_switches == held_switches && need_resched);
    uint32_t observed = irq_save();
    KASSERT(!(observed & 0x200));
    preempt_if0_ok = 1;
    preempt_cli_ticks = timer_ticks;
    preempt_cli_switches = preempt_switches;
    preempt_cli_sample();
    while (!preempt_cli_release) __asm__ volatile("" ::: "memory");
    /* Bounded real CLI window, separate from the IRQ-enabled deferred test. */
    for (volatile unsigned n = 0; n < 2000000; ++n) { }
    KASSERT(timer_ticks == preempt_cli_ticks && preempt_switches == preempt_cli_switches);
    irq_restore(enabled);
    preempt_progress_sample();
    while (tasks[1].state != DEAD || tasks[2].state != DEAD)
        __asm__ volatile("hlt" ::: "memory");
    (void)irq_save();
    timer_mask(1);
    preempt_active = 0;
    need_resched = 0;
    for (unsigned i = 1; i < LEGACY_SLOTS; ++i) {
        uint32_t page = tasks[i].kernel_stack;
        KASSERT(*(uint32_t *)page == CANARY);
        KASSERT(tasks[i].trap_depth == 0 && tasks[i].preempt_count == 0);
        unsigned untouched = 4;
        while (untouched < PAGE_BYTES && *(uint8_t *)(page + untouched) == 0xa5) ++untouched;
        preempt_stack_used[i - 1] = PAGE_BYTES - untouched;
        KASSERT(preempt_stack_used[i - 1] < PAGE_BYTES - 256);
        KASSERT(page_free(page));
        tasks[i].kernel_stack = 0;
        ++preempt_reaped;
    }
    KASSERT(preempt_counts[0] >= 200000 && preempt_counts[1] >= 200000);
    KASSERT(preempt_probe_passes == 8 && preempt_deferred >= 3);
    KASSERT(page_free_count() == preempt_initial_pages);
    preempt_passed = 1;
    kprintf("D14 PREEMPT A=%u B=%u switches=%u\n", preempt_counts[0], preempt_counts[1], preempt_switches);
    kprintf("D14 seven-GPR/flags/DF probes=%u; deferred ticks=%u\n", preempt_probe_passes, preempt_critical_ticks);
    kprintf("D14 nested/IF0/CLI OK; stacks=%u,%u reaped=%u\n", preempt_stack_used[0], preempt_stack_used[1], preempt_reaped);
    kprintf("PREEMPT OK pages recovered; returning to keyboard\n");
    preempt_demo_done();
    irq_restore(original);
}

volatile uint32_t wait_blocks, wait_wakes, wait_idle_halts, wait_sleep_passes;
volatile uint32_t wait_passed, wait_initial_pages, wait_reaped, wait_stack_used[2];
volatile uint32_t wait_produced, wait_consumed, wait_phase, wait_woken[3];
volatile uint32_t wait_pending_seen, wait_lost, wait_rescued, wait_lost_tick;
static struct wait_queue event_waiters;
static volatile unsigned wait_event, wait_armed;
static unsigned wait_broken;

static void require_locked(void)
{
    uint32_t flags;
    __asm__ volatile("pushfl; popl %0" : "=r"(flags));
    KASSERT(!(flags & 0x200));
}
static void block_current(void)
{
    require_locked();
    KASSERT(idle_active && current && tasks[current].state == RUNNING);
    KASSERT(tasks[current].trap_depth <= 1 && !tasks[current].preempt_count);
    unsigned depth = tasks[current].trap_depth;
    tasks[current].state = BLOCKED;
    ++wait_blocks;
    schedule_locked_depth(depth);
}
void task_block_locked(struct wait_queue *q)
{
    require_locked();
    struct task *t = &tasks[current];
    KASSERT(q && !t->waiting_on && !t->sleeping && !(q->mask & (1u << current)));
    t->waiting_on = q;
    q->mask |= 1u << current;
    block_current();
    KASSERT(!t->waiting_on && !(q->mask & (1u << current)));
}
int wake_one_locked(struct wait_queue *q)
{
    require_locked();
    for (unsigned i = 1; i < task_limit; ++i) {
        if (!(q->mask & (1u << i))) continue;
        KASSERT(tasks[i].state == BLOCKED && tasks[i].waiting_on == q);
        q->mask &= ~(1u << i);
        tasks[i].waiting_on = 0;
        tasks[i].state = RUNNABLE;
        need_resched = 1;
        ++wait_wakes;
        return 1;
    }
    return 0;
}
unsigned wake_all_locked(struct wait_queue *q)
{
    unsigned count = 0;
    while (wake_one_locked(q)) ++count;
    return count;
}
static int tick_reached(uint32_t now, uint32_t deadline)
{
    return (uint32_t)(now - deadline) < 0x80000000u;
}
void sleep_ticks(uint32_t ticks)
{
    KASSERT(ticks <= 0x7fffffffu);
    if (!ticks) return;
    uint32_t flags = irq_save();
    struct task *t = &tasks[current];
    KASSERT(!t->waiting_on && !t->sleeping);
    t->wake_tick = timer_ticks + ticks;
    t->sleeping = 1;
    block_current();
    KASSERT(!t->sleeping && tick_reached(timer_ticks, t->wake_tick));
    irq_restore(flags);
}
void wait_lost_observed(void) { __asm__ volatile("" ::: "memory"); }
void wait_pending_observed(void) { __asm__ volatile("" ::: "memory"); }
void wait_idle_observed(void) { __asm__ volatile("" ::: "memory"); }
void wait_demo_done(void) { __asm__ volatile("" ::: "memory"); }
static void wait_tick(void)
{
    for (unsigned i = 1; i < task_limit; ++i) {
        struct task *t = &tasks[i];
        if (t->state != BLOCKED || !t->sleeping || !tick_reached(timer_ticks, t->wake_tick)) continue;
        t->sleeping = 0;
        t->state = RUNNABLE;
    }
    if (wait_armed) {
        wait_armed = 0;
        wait_event = 1;
        ++wait_produced;
        wait_woken[wait_phase] = wake_one_locked(&event_waiters);
    }
    if (wait_broken && wait_phase == 1 && wait_event && tasks[1].state == BLOCKED) {
        KASSERT(event_waiters.mask == 2 && wait_woken[1] == 0);
        if (!wait_lost) {
            wait_lost = 1;
            wait_lost_tick = timer_ticks;
            wait_lost_observed();
        }
        if (timer_ticks - wait_lost_tick >= 3) {
            KASSERT(wake_one_locked(&event_waiters));
            ++wait_rescued;
        }
    }
}
static void event_consumer(void *arg)
{
    (void)arg;
    for (wait_phase = 0; wait_phase < 3; ++wait_phase) {
        uint32_t flags = irq_save();
        wait_event = 0;
        KASSERT(!event_waiters.mask);
        wait_armed = 1;
        if (wait_phase == 0) {
            irq_restore(flags);
            while (!wait_event) __asm__ volatile("hlt" ::: "memory");
            (void)irq_save();
        }
        while (!wait_event) {
            if (wait_phase == 1 && wait_broken) {
                irq_restore(flags);
                while (!wait_event) __asm__ volatile("hlt" ::: "memory");
                (void)irq_save();
            } else if (wait_phase == 1) {
                uint32_t tick = timer_ticks, produced = wait_produced;
                unsigned n;
                for (n = 0; n < 1000000 && !timer_pending(); ++n) { }
                KASSERT(n < 1000000 && timer_ticks == tick && wait_produced == produced);
                wait_pending_seen = 1;
                wait_pending_observed();
            }
            task_block_locked(&event_waiters);
        }
        wait_event = 0;
        ++wait_consumed;
        KASSERT(!event_waiters.mask && !tasks[current].waiting_on);
        KASSERT(!wake_one_locked(&event_waiters));
        irq_restore(flags);
    }
}
static void sleeper(void *arg)
{
    (void)arg;
    sleep_ticks(0);
    for (unsigned n = 0; n < 8; ++n) {
        uint32_t tick = timer_ticks;
        sleep_ticks(3);
        KASSERT(timer_ticks - tick >= 3);
        ++wait_sleep_passes;
    }
}
static void idle_once(void)
{
    (void)irq_save();
    KASSERT(current == 0);
    if (tasks[1].state == RUNNABLE || tasks[2].state == RUNNABLE) task_yield();
    else {
        ++wait_idle_halts;
        wait_idle_observed();
        __asm__ volatile("sti; hlt" ::: "memory");
    }
}
static void keyboard_consumer(void *arg)
{
    (void)arg;
    keyboard_loop();
}
void wait_demo(unsigned broken)
{
    (void)irq_save();
    wait_broken = broken;
    wait_initial_pages = page_free_count();
    KASSERT(tick_reached(0, 0) && tick_reached(1, 0xfffffffeu));
    KASSERT(!tick_reached(0xfffffffeu, 1) && !tick_reached(0, 0x7fffffffu));
    KASSERT(task_create(event_consumer, 0) && task_create(sleeper, 0));
    idle_active = preempt_active = 1;
    timer_start();
    kprintf("D15 WAIT %s: real PIT producer, three event orders\n", broken ? "BROKEN" : "FIXED");
    while (tasks[1].state != DEAD || tasks[2].state != DEAD) idle_once();
    (void)irq_save();
    for (unsigned i = 1; i < LEGACY_SLOTS; ++i) {
        struct task *t = &tasks[i];
        uint32_t page = t->kernel_stack;
        KASSERT(*(uint32_t *)page == CANARY && !t->waiting_on && !t->sleeping);
        KASSERT(!t->trap_depth && !t->preempt_count);
        unsigned untouched = 4;
        while (untouched < PAGE_BYTES && *(uint8_t *)(page + untouched) == 0xa5) ++untouched;
        wait_stack_used[i - 1] = PAGE_BYTES - untouched;
        KASSERT(wait_stack_used[i - 1] < PAGE_BYTES - 256 && page_free(page));
        t->kernel_stack = 0;
        ++wait_reaped;
    }
    KASSERT(wait_produced == 3 && wait_consumed == 3 && !event_waiters.mask);
    KASSERT(wait_woken[0] == 0 && wait_woken[1] == !broken && wait_woken[2] == 1);
    KASSERT(wait_pending_seen == !broken && wait_lost == broken && wait_rescued == broken);
    KASSERT(wait_sleep_passes == 8 && page_free_count() == wait_initial_pages);
    wait_passed = 1;
    kprintf("D15 events produced=%u consumed=%u woken=%u,%u,%u\n", wait_produced, wait_consumed, wait_woken[0], wait_woken[1], wait_woken[2]);
    kprintf("D15 pending=%u lost=%u rescued=%u sleeps=%u idle=%u\n", wait_pending_seen, wait_lost, wait_rescued, wait_sleep_passes, wait_idle_halts);
    kprintf("WAIT OK stacks=%u,%u reaped=%u pages recovered\n", wait_stack_used[0], wait_stack_used[1], wait_reaped);
    wait_demo_done();
    wait_broken = 0;
    idle_active = preempt_active = 0;
    need_resched = 0;
    timer_mask(1);
}
void task_keyboard_start(void)
{
    (void)irq_save();
    idle_active = preempt_active = 1;
    timer_start();
    KASSERT(task_create(keyboard_consumer, 0));
    for (;;) idle_once();
}


volatile uint32_t user_round, user_passed, user_reaped, user_initial_pages;
volatile uint32_t user_rollback_passes, user_irq_frames[2], user_stack_used[2];
volatile uint32_t user_fault_vectors[3], user_fault_errors[3], user_fault_eips[3], user_survivor_growth[3];
extern char user_blob_start, user_write_fault, user_cli_fault, user_out_fault;
volatile uint32_t user_final_counts[2], user_frame_address[2];
volatile uint32_t user_sentinel = 0x51a7cafe;
void user_round_ready(void) { __asm__ volatile("" ::: "memory"); }
void user_fault_observed(void) { __asm__ volatile("" ::: "memory"); }
void user_demo_done(void) { __asm__ volatile("" ::: "memory"); }
static int task_create_user(unsigned mode)
{
    struct user_space space;
    if (!user_space_create(&space, mode, (uint32_t)&user_sentinel)) return 0;
    if (task_create_space(0, 0, &space)) return 1;
    user_space_destroy(&space);
    return 0;
}
int task_user_trap(struct trap_frame *frame, uint32_t address)
{
    struct task *t = &tasks[current];
    KASSERT(current && t->user.pages[0] && (frame->cs & 3) == 3);
    uint32_t cr3;
    __asm__ volatile("mov %%cr3,%0" : "=r"(cr3));
    uint32_t *tail = (uint32_t *)(frame + 1);
    KASSERT(cr3 == t->user.pages[0] && frame->cs == 0x1b && tail[1] == 0x23);
    if (t->pid && t->program_kind == PROCESS_SHELL_KIND) {
        shell_user_cs = frame->cs;
        shell_user_eip = frame->eip;
    }
    KASSERT((uint32_t)frame > t->kernel_stack && (uint32_t)(tail + 2) <= t->kernel_stack + PAGE_BYTES);
    if (!t->pid && current < LEGACY_SLOTS)
        user_frame_address[current - 1] = (uint32_t)frame;
    if (frame->vector == 32) {
        if (!t->pid && current < LEGACY_SLOTS)
            ++user_irq_frames[current - 1];
        if (t->user.kind == USER_SPACE_BLOB) {
            uint32_t *data = (uint32_t *)t->user.pages[4];
            if (data[1] < 10) data[5] = 1; /* Day 16's pre-fault IRQ marker. */
        }
    }
    if (frame->vector != 13 && frame->vector != 14) return 0;
    t->user_fault = frame->vector;
    t->user_error = frame->error;
    t->user_eip = frame->eip;
    t->user_address = address;
    if (t->pid) t->exit_status = 0x10000u | frame->vector;
    t->user_stop = 1; /* Retire only after the common tail decrements trap_depth. */
    return 1;
}
void user_demo(void)
{
    (void)irq_save();
    user_init();
    user_initial_pages = page_free_count();
    for (user_fail_after = 0; user_fail_after < 7; ++user_fail_after) {
        KASSERT(!task_create_user(0));
        KASSERT(page_free_count() == user_initial_pages);
        KASSERT(tasks[1].state == DEAD && !tasks[1].kernel_stack && !tasks[1].user.pages[0]);
        ++user_rollback_passes;
    }
    for (user_round = 0; user_round < 3; ++user_round) {
        KASSERT(task_create_user(0) && task_create_user(user_round + 1));
        KASSERT(page_free_count() == user_initial_pages - 14);
        volatile uint32_t *a = (uint32_t *)tasks[1].user.pages[4];
        volatile uint32_t *b = (uint32_t *)tasks[2].user.pages[4];
        preempt_active = 1;
        timer_start();
        kprintf("D16 ring3 round=%u private VA=40001000 bad=%u\n", user_round, user_round + 1);
        user_round_ready();
        __asm__ volatile("sti" ::: "memory");
        while (tasks[2].state != DEAD || !a[2]) __asm__ volatile("hlt" ::: "memory");
        (void)irq_save();
        KASSERT(tasks[2].user_fault == (user_round == 0 ? 14u : 13u));
        KASSERT(tasks[2].user_error == (user_round == 0 ? 7u : 0u));
        if (!user_round) KASSERT(tasks[2].user_address == (uint32_t)&user_sentinel);
        KASSERT(user_sentinel == 0x51a7cafe && a[2] && b[2]);
        user_fault_vectors[user_round] = tasks[2].user_fault;
        user_fault_errors[user_round] = tasks[2].user_error;
        user_fault_eips[user_round] = tasks[2].user_eip;
        uintptr_t instruction = (uintptr_t)(user_round == 0 ? &user_write_fault : user_round == 1 ? &user_cli_fault : &user_out_fault);
        KASSERT(tasks[2].user_eip == USER_CODE + instruction - (uintptr_t)&user_blob_start);
        user_fault_observed();
        uint32_t before = a[0], tick = timer_ticks;
        __asm__ volatile("sti" ::: "memory");
        while (timer_ticks - tick < 4) __asm__ volatile("hlt" ::: "memory");
        (void)irq_save();
        KASSERT(a[0] > before);
        user_survivor_growth[user_round] = a[0] - before;
        tasks[1].user_stop = 1; /* No exit syscall: supervisor ends the finite lab. */
        __asm__ volatile("sti" ::: "memory");
        while (tasks[1].state != DEAD) __asm__ volatile("hlt" ::: "memory");
        (void)irq_save();
        timer_mask(1);
        preempt_active = need_resched = 0;
        KASSERT(user_irq_frames[0] && user_irq_frames[1]);
        for (unsigned i = 1; i < LEGACY_SLOTS; ++i) {
            struct task *t = &tasks[i];
            user_final_counts[i - 1] = *(uint32_t *)t->user.pages[4];
            KASSERT(!t->trap_depth && !t->preempt_count && *(uint32_t *)t->kernel_stack == CANARY);
            unsigned untouched = 4;
            while (untouched < PAGE_BYTES && *(uint8_t *)(t->kernel_stack + untouched) == 0xa5) ++untouched;
            user_stack_used[i - 1] = PAGE_BYTES - untouched;
            KASSERT(user_stack_used[i - 1] < PAGE_BYTES - 256);
            user_space_destroy(&t->user);
            KASSERT(page_free(t->kernel_stack));
            t->kernel_stack = 0;
            ++user_reaped;
        }
        KASSERT(page_free_count() == user_initial_pages);
        kprintf("D16 fault=%u error=%u eip=%x survivor+=%u\n", user_fault_vectors[user_round], user_fault_errors[user_round], user_fault_eips[user_round], user_survivor_growth[user_round]);
    }
    user_passed = 1;
    kprintf("USER OK ring3 CR3/TSS; rollback=%u reaped=%u pages=%u\n", user_rollback_passes, user_reaped, page_free_count());
    user_demo_done();
}

volatile uint32_t syscall_passed, syscall_initial_pages, syscall_reaped;
volatile uint32_t syscall_stack_used[2];
volatile uint32_t syscall_results[13];
volatile uint32_t syscall_copy_checks;
volatile uint32_t syscall_bad_gate_vector, syscall_bad_gate_error, syscall_bad_gate_eip;
volatile uint32_t syscall_bad_gate_survivor_growth;
extern volatile unsigned syscall_wait_for_irq;
extern char user_blob_start, user_bad_gate_fault;
__attribute__((noinline)) void syscall_demo_done(void)
{ __asm__ volatile("" ::: "memory"); }

__attribute__((optimize("Os"))) static void syscall_prepare_space(struct user_space *space)
{
    uint32_t *pt = (uint32_t *)space->pages[1];
    pt[3] = space->pages[5] | 3; /* Present supervisor alias: must be rejected. */
    pt[4] = space->pages[3] | 5;
    pt[5] = space->pages[5] | 7; /* Two user aliases make a legal cross-page source. */
    char *data = (char *)space->pages[4];
    memcpy(data + 256, "D17 WRITE % NO-NUL\n", 19);
    memcpy(data + PAGE_BYTES - 8, "LEAKFAIL", 8);
    memcpy((void *)(space->pages[3] + PAGE_BYTES - 8), "D17 CROS", 8);
    memcpy((void *)space->pages[5], "S-PAGE\n", 7);
}

__attribute__((optimize("Os"))) static void syscall_copy_probe(struct user_space *space)
{
    static const char source[16] = "COPY-TO-USER-OK";
    static const char guard[8] = "GUARD123";
    uint32_t *pt = (uint32_t *)space->pages[1];
    uint32_t kernel_cr3;
    __asm__ volatile("mov %%cr3,%0" : "=r"(kernel_cr3));
    pt[2] = space->pages[5] | 7;
    __asm__ volatile("mov %0,%%cr3" : : "r"(space->pages[0]) : "memory");
    KASSERT(copy_to_user(0x40001ff8u, source, sizeof(source)));
    KASSERT(!memcmp((void *)(space->pages[4] + PAGE_BYTES - 8), source, 8));
    KASSERT(!memcmp((void *)space->pages[5], source + 8, 8));
    ++syscall_copy_checks;

    memcpy((void *)(space->pages[4] + PAGE_BYTES - 8), guard, sizeof(guard));
    pt[2] = space->pages[5] | 5;
    KASSERT(!copy_to_user(0x40001ff8u, source, sizeof(source)));
    KASSERT(!memcmp((void *)(space->pages[4] + PAGE_BYTES - 8), guard,
                    sizeof(guard)));
    ++syscall_copy_checks;

    uint32_t saved_pde = ((uint32_t *)space->pages[0])[USER_CODE >> 22];
    ((uint32_t *)space->pages[0])[USER_CODE >> 22] = saved_pde & ~2u;
    KASSERT(!copy_to_user(USER_DATA, source, 1));
    ((uint32_t *)space->pages[0])[USER_CODE >> 22] = saved_pde;
    KASSERT(copy_to_user(0xffffffffu, source, 0));
    syscall_copy_checks += 2;
    __asm__ volatile("mov %0,%%cr3" : : "r"(kernel_cr3) : "memory");
    pt[2] = 0;
}

__attribute__((optimize("Os"))) static void syscall_reap_tasks(void)
{
    for (unsigned i = 1; i < LEGACY_SLOTS; ++i) {
        struct task *t = &tasks[i];
        KASSERT(!t->trap_depth && !t->preempt_count && *(uint32_t *)t->kernel_stack == CANARY);
        unsigned untouched = 4;
        while (untouched < PAGE_BYTES && *(uint8_t *)(t->kernel_stack + untouched) == 0xa5) ++untouched;
        syscall_stack_used[i - 1] = PAGE_BYTES - untouched;
        KASSERT(syscall_stack_used[i - 1] < PAGE_BYTES - 256);
        user_space_destroy(&t->user);
        KASSERT(page_free(t->kernel_stack));
        t->kernel_stack = 0;
        ++syscall_reaped;
    }
}

__attribute__((optimize("Os"))) void syscall_demo(void)
{
    (void)irq_save();
    syscall_initial_pages = page_free_count();
    struct user_space tester, counter_space;
    KASSERT(user_space_create(&tester, 10, 0));
    syscall_copy_probe(&tester);
    syscall_prepare_space(&tester);
    KASSERT(user_range_ok(tester.pages[0], USER_CODE, 1, 0));
    KASSERT(!user_range_ok(tester.pages[0], USER_CODE, 1, 1));
    uint32_t *pd = (uint32_t *)tester.pages[0];
    uint32_t saved_pde = pd[USER_CODE >> 22];
    pd[USER_CODE >> 22] = saved_pde & ~4u;
    KASSERT(!user_range_ok(tester.pages[0], USER_CODE, 1, 0));
    pd[USER_CODE >> 22] = saved_pde & ~2u;
    KASSERT(user_range_ok(tester.pages[0], USER_CODE, 1, 0));
    KASSERT(!user_range_ok(tester.pages[0], USER_DATA, 1, 1));
    pd[USER_CODE >> 22] = saved_pde;
    KASSERT(user_range_ok(tester.pages[0], 0x40004ff8u, 15, 0));
    KASSERT(!user_range_ok(tester.pages[0], 0x40001ff8u, 16, 0));
    KASSERT(!user_range_ok(tester.pages[0], 0x40003000u, 4, 0));
    KASSERT(!user_range_ok(tester.pages[0], 0xfffffff0u, 32, 0));
    KASSERT(user_space_create(&counter_space, 11, 0));
    KASSERT(task_create_space(0, 0, &tester));
    KASSERT(task_create_space(0, 0, &counter_space));
    KASSERT(page_free_count() == syscall_initial_pages - 14);
    syscall_wait_for_irq = 1;
    syscall_yield_probe_active = 1;
    preempt_active = 1;
    timer_start();
    kprintf("D17 int80 write/yield and user-copy checks=%u\n",
            syscall_copy_checks);
    __asm__ volatile("sti" ::: "memory");
    volatile uint32_t *results = (uint32_t *)tasks[1].user.pages[4];
    while (!results[2]) __asm__ volatile("hlt" ::: "memory");
    (void)irq_save();
    kprintf("D17 returns write=%x yield=%x unknown=%x zero=%x long=%x low=%x wrap=%x upper=%x missing=%x supervisor=%x ro=%x cross=%x regs=%x\n",
            results[8], results[9], results[10], results[11], results[12], results[13],
            results[14], results[15], results[16], results[17], results[18], results[19],
            results[20]);
    KASSERT(results[8] == 19 && results[9] == 0);
    KASSERT(results[10] == (uint32_t)-38 && results[11] == 0);
    KASSERT(results[12] == (uint32_t)-22);
    KASSERT(results[13] == (uint32_t)-14 && results[14] == (uint32_t)-14);
    KASSERT(results[15] == (uint32_t)-14 && results[16] == (uint32_t)-14);
    KASSERT(results[17] == (uint32_t)-14 && results[18] == 16);
    KASSERT(results[19] == 15 && results[20] == 1);
    for (unsigned i = 0; i < 13; ++i) syscall_results[i] = results[i + 8];
    KASSERT(syscall_count == 12 && syscall_write_count == 3);
    KASSERT(syscall_yield_count == 1 && syscall_error_count == 7);
    KASSERT(syscall_irq_ticks && syscall_yield_switched);
    KASSERT(syscall_yield_after != syscall_yield_before);
    syscall_yield_probe_active = 0;
    tasks[1].user_stop = tasks[2].user_stop = 1;
    __asm__ volatile("sti" ::: "memory");
    while (tasks[1].state != DEAD || tasks[2].state != DEAD)
        __asm__ volatile("hlt" ::: "memory");
    (void)irq_save();
    timer_mask(1);
    preempt_active = need_resched = 0;
    syscall_reap_tasks();
    KASSERT(page_free_count() == syscall_initial_pages);

    KASSERT(task_create_user(12) && task_create_user(11));
    KASSERT(page_free_count() == syscall_initial_pages - 14);
    preempt_active = 1;
    timer_start();
    __asm__ volatile("sti" ::: "memory");
    while (tasks[1].state != DEAD) __asm__ volatile("hlt" ::: "memory");
    (void)irq_save();
    syscall_bad_gate_vector = tasks[1].user_fault;
    syscall_bad_gate_error = tasks[1].user_error;
    syscall_bad_gate_eip = tasks[1].user_eip;
    KASSERT(syscall_bad_gate_vector == 13 && syscall_bad_gate_error == 0x102);
    KASSERT(syscall_bad_gate_eip == USER_CODE + (uintptr_t)&user_bad_gate_fault -
                                          (uintptr_t)&user_blob_start);
    volatile uint32_t *survivor = (uint32_t *)tasks[2].user.pages[4];
    uint32_t before = survivor[0], tick = timer_ticks;
    __asm__ volatile("sti" ::: "memory");
    while (timer_ticks - tick < 4) __asm__ volatile("hlt" ::: "memory");
    (void)irq_save();
    syscall_bad_gate_survivor_growth = survivor[0] - before;
    KASSERT(syscall_bad_gate_survivor_growth);
    tasks[2].user_stop = 1;
    __asm__ volatile("sti" ::: "memory");
    while (tasks[2].state != DEAD) __asm__ volatile("hlt" ::: "memory");
    (void)irq_save();
    timer_mask(1);
    preempt_active = need_resched = 0;
    syscall_reap_tasks();
    KASSERT(page_free_count() == syscall_initial_pages);
    syscall_passed = 1;
    kprintf("D17 gate DPL #GP error=%x eip=%x survivor+=%u\n",
            syscall_bad_gate_error, syscall_bad_gate_eip,
            syscall_bad_gate_survivor_growth);
    kprintf("SYSCALL OK calls=%u writes=%u errors=%u irq_ticks=%u yield_delta=%u reaped=%u\n",
            syscall_count, syscall_write_count, syscall_error_count,
            syscall_irq_ticks, syscall_yield_after - syscall_yield_before,
            syscall_reaped);
    syscall_demo_done();
}

volatile uint32_t elf_passed, elf_initial_pages, elf_rollback_passes;
volatile uint32_t elf_reaped, elf_allocations, elf_entry_seen;
volatile uint32_t elf_code_pte, elf_data_pte, elf_result_physical;
extern char day18_elf_start, day18_elf_end;
__attribute__((noinline, noipa)) void elf_demo_done(void)
{ __asm__ volatile("nop" ::: "memory"); }

__attribute__((optimize("Os"))) void elf_demo(void)
{
    (void)irq_save();
    elf_initial_pages = page_free_count();
    elf_negative_tests();
    KASSERT(elf_negative_passes == 34 && page_free_count() == elf_initial_pages);

    uint32_t image_size = (uintptr_t)&day18_elf_end -
                          (uintptr_t)&day18_elf_start;
    struct user_space space = {0};
    elf_fail_after = UINT32_MAX;
    KASSERT(elf_load(&day18_elf_start, image_size, &space) == ELF_OK);
    elf_allocations = space.page_count;
    KASSERT(elf_allocations == 7);
    user_space_destroy(&space);
    KASSERT(page_free_count() == elf_initial_pages);

    for (elf_fail_after = 0; elf_fail_after < elf_allocations;
         ++elf_fail_after) {
        KASSERT(elf_load(&day18_elf_start, image_size, &space) == ELF_ERR_NOMEM);
        KASSERT(!space.pages[0] && page_free_count() == elf_initial_pages);
        ++elf_rollback_passes;
    }
    KASSERT(elf_load(&day18_elf_start, image_size, &space) == ELF_OK);
    KASSERT(!task_create_space(0, 0, &space));
    KASSERT(tasks[1].state == DEAD && !tasks[1].kernel_stack &&
            !tasks[1].user.pages[0]);
    user_space_destroy(&space);
    ++elf_rollback_passes;
    KASSERT(page_free_count() == elf_initial_pages);

    elf_fail_after = UINT32_MAX;
    KASSERT(elf_load(&day18_elf_start, image_size, &space) == ELF_OK);
    elf_entry_seen = space.entry;
    uint32_t code_physical, data_physical;
    KASSERT(user_space_physical(&space, space.entry, 0, &code_physical));
    KASSERT(!user_space_physical(&space, space.entry, 1, 0));
    KASSERT(user_space_physical(&space, 0x40001000u, 1, &data_physical));
    elf_result_physical = data_physical;
    uint32_t *load_pt = (uint32_t *)space.pages[1];
    elf_code_pte = load_pt[(space.entry - USER_CODE) / PAGE_BYTES];
    elf_data_pte = load_pt[1];
    KASSERT((elf_code_pte & 7) == 5 && (elf_data_pte & 7) == 7);
    KASSERT(*(uint32_t *)data_physical == 0);
    KASSERT(task_create_space(0, 0, &space));
    KASSERT(page_free_count() == elf_initial_pages - elf_allocations - 1);

    preempt_active = 1;
    timer_start();
    kprintf("D18 ELF32 entry=%x image=%u alloc=%u invalid=%u rollback=%u\n",
            elf_entry_seen, image_size, elf_allocations,
            elf_negative_passes, elf_rollback_passes);
    __asm__ volatile("sti" ::: "memory");
    while (*(volatile uint32_t *)elf_result_physical != 0x18c0ffeeu)
        __asm__ volatile("hlt" ::: "memory");
    (void)irq_save();
    KASSERT(((uint32_t *)elf_result_physical)[5] == 0);
    tasks[1].user_stop = 1;
    __asm__ volatile("sti" ::: "memory");
    while (tasks[1].state != DEAD) __asm__ volatile("hlt" ::: "memory");
    (void)irq_save();
    timer_mask(1);
    preempt_active = need_resched = 0;
    KASSERT(!tasks[1].trap_depth && !tasks[1].preempt_count);
    KASSERT(*(uint32_t *)tasks[1].kernel_stack == CANARY);
    user_space_destroy(&tasks[1].user);
    KASSERT(page_free(tasks[1].kernel_stack));
    tasks[1].kernel_stack = 0;
    ++elf_reaped;
    KASSERT(page_free_count() == elf_initial_pages);
    elf_passed = 1;
    kprintf("ELF OK data/BSS/stack; code=RO data=RW rollback=%u reaped=%u pages=%u\n",
            elf_rollback_passes, elf_reaped, page_free_count());
    elf_demo_done();
}

enum process_program {
    PROCESS_DEMO = 1,
    PROCESS_COUNT,
    PROCESS_BADPTR,
    PROCESS_ORPHAN,
    PROCESS_FAILTEST,
    PROCESS_FDDEMO,
    PROCESS_FDSHARE,
    PROCESS_FDBADPTR,
    PROCESS_FDHOLD,
    PROCESS_FDFAIL,
    PROCESS_FDTERM,
    PROCESS_SHELL = PROCESS_SHELL_KIND,
    PROCESS_DISK
};

#define PROCESS_MODE_ADDRESS 0x40001000u
#define PROCESS_PROGRESS_ADDRESS 0x40001004u
#define PROCESS_RELEASE_ADDRESS 0x40001008u
#define ERR_ENOENT 2
#define ERR_ECHILD 10
#define ERR_EAGAIN 11
#define ERR_ENOMEM 12
#define ERR_EFAULT 14
#define ERR_EINVAL 22

extern char day19_elf_start, day19_elf_end;
extern char day22_elf_start, day22_elf_end;
static uint32_t next_pid = 1;
static unsigned process_failure_enabled, process_failure_step;
static unsigned fd_failure_enabled, fd_failure_step;
static unsigned process_release_pending;
static int32_t process_release_parent;
static uint32_t process_release_snapshots[TASK_SLOTS];

volatile uint32_t process_passed, process_initial_pages;
volatile uint32_t process_reaped, process_wait_reaped;
volatile uint32_t process_wait_blocks, process_wait_immediate;
volatile uint32_t process_wait_after_block;
volatile uint32_t process_wait_faults, process_spawn_rollbacks;
volatile uint32_t process_orphan_reparented, process_survivor_growth;
volatile uint32_t day30_badptr_pid, day30_badptr_tick;
volatile uint32_t day30_survivor_tick, day30_survivor_count;
volatile uint32_t day30_event_sequence, day30_badptr_sequence;
volatile uint32_t day30_survivor_sequence;
volatile uint32_t day30_survivor_pids[2];
volatile uint32_t day30_survivor_before[2], day30_survivor_after[2];
volatile uint32_t process_peak_slots, process_zombie_pages;
volatile int32_t process_blocked_parent_pid, process_blocked_target_pid;
volatile uint32_t process_blocked_trap_depth, process_blocked_wait_mask;
volatile uint32_t process_failure_passed;
volatile uint32_t fd_passed, fd_initial_pages, fd_reaped;
volatile uint32_t fd_exit_closes, fd_exit_tasks, fd_spawn_rollbacks;
volatile uint32_t fd_terminal_mode, fd_terminal_blocks;
volatile uint32_t fd_root_status;
volatile uint32_t shell_prompts, shell_root_status, shell_initial_pages;
volatile uint32_t shell_baseline_pages, shell_prompt_checks;
static unsigned shell_prompt_prefix;
volatile uint32_t disk_exec_size, disk_exec_reads, disk_exec_last_offset;
volatile int32_t disk_exec_result;
volatile uint32_t day30_demo_size, day30_demo_reads, day30_demo_pid;
volatile uint32_t day30_reaped_delta, day30_final_pages;

__attribute__((noinline, noipa)) void disk_exec_opened(void)
{ __asm__ volatile("nop" ::: "memory"); }

__attribute__((noinline, noipa)) void elf_source_read_observed(void)
{ __asm__ volatile("nop" ::: "memory"); }

__attribute__((noinline, noipa)) void disk_spawn_published(void)
{ __asm__ volatile("nop" ::: "memory"); }

__attribute__((noinline, noipa)) void shell_prompt_observed(void)
{ __asm__ volatile("nop" ::: "memory"); }

__attribute__((noinline, noipa)) void shell_demo_done(void)
{ __asm__ volatile("nop" ::: "memory"); }

__attribute__((noinline, noipa)) void process_wait_blocked(void)
{ __asm__ volatile("nop" ::: "memory"); }

__attribute__((noinline, noipa)) void process_bootstrap_observed(void)
{ __asm__ volatile("nop" ::: "memory"); }

__attribute__((noinline, noipa)) void process_demo_done(void)
{ __asm__ volatile("nop" ::: "memory"); }

static int name_equal(const char *left, const char *right)
{
    while (*left && *left == *right) { ++left; ++right; }
    return *left == *right;
}

static unsigned process_kind(const char *name)
{
    if (name_equal(name, "DEMO")) return PROCESS_DEMO;
    if (name_equal(name, "COUNT")) return PROCESS_COUNT;
    if (name_equal(name, "BADPTR")) return PROCESS_BADPTR;
    if (name_equal(name, "ORPHAN")) return PROCESS_ORPHAN;
    if (name_equal(name, "FAILTEST")) return PROCESS_FAILTEST;
    if (name_equal(name, "FDDEMO")) return PROCESS_FDDEMO;
    if (name_equal(name, "FDSHARE")) return PROCESS_FDSHARE;
    if (name_equal(name, "FDBADPTR")) return PROCESS_FDBADPTR;
    if (name_equal(name, "FDHOLD")) return PROCESS_FDHOLD;
    if (name_equal(name, "FDFAIL")) return PROCESS_FDFAIL;
    if (name_equal(name, "FDTERM")) return PROCESS_FDTERM;
    return 0;
}

static unsigned process_live_count(void)
{
    unsigned count = 0;
    for (unsigned i = 1; i < task_limit; ++i)
        if (tasks[i].pid) ++count;
    return count;
}

static int process_has_slot(void)
{
    for (unsigned i = 1; i < task_limit; ++i)
        if (tasks[i].state == DEAD && !tasks[i].kernel_stack &&
            !tasks[i].pid)
            return 1;
    return 0;
}

static int process_create(struct user_space *space, unsigned kind,
                          int32_t parent_pid, struct open_file *mapped[3],
                          int32_t *created_pid)
{
    uint32_t flags = irq_save();
    KASSERT((task_limit == PROCESS_SLOTS || task_limit == TASK_SLOTS) &&
            space && space->pages[0]);
    if (next_pid > INT32_MAX) { irq_restore(flags); return 0; }
    for (unsigned i = 1; i < task_limit; ++i) {
        struct task *task = &tasks[i];
        if (task->state != DEAD || task->kernel_stack || task->pid) continue;
        uint32_t stack = elf_fail_after == space->page_count ? 0 : page_alloc();
        if (!stack) { irq_restore(flags); return 0; }
        memset((void *)stack, 0xa5, PAGE_BYTES);
        *(uint32_t *)stack = CANARY;
        uint32_t *sp = (uint32_t *)(stack + PAGE_BYTES);
        *--sp = (uint32_t)task_trampoline;
        *--sp = 0;
        *--sp = 0;
        *--sp = 0;
        *--sp = 0;
        int32_t pid = (int32_t)next_pid++;
        *task = (struct task){.saved_sp=sp, .kernel_stack=stack,
                              .state=DEAD, .user=*space, .pid=pid,
                              .parent_pid=parent_pid,
                              .program_kind=kind};
        for (unsigned fd = 0; fd < 3; ++fd) task->fds[fd] = mapped[fd];
        *space = (struct user_space){0};
        task->state = RUNNABLE;
        unsigned live = process_live_count();
        if (live > process_peak_slots) process_peak_slots = live;
        *created_pid = pid;
        irq_restore(flags);
        return 1;
    }
    irq_restore(flags);
    return 0;
}

static void mapped_put(struct open_file *mapped[3])
{
    for (unsigned i = 0; i < 3; ++i)
        if (mapped[i]) { file_put(mapped[i]); mapped[i] = 0; }
}

static int stage_io_map(unsigned io_map, struct open_file *mapped[3])
{
    if (!io_map) return 0;
    if ((io_map & 0xfffff000u) != 0xd2200000u) return -ERR_EINVAL;
    for (unsigned target = 0; target < 3; ++target) {
        unsigned encoded = (io_map >> (target * 4)) & 0xfu;
        if (!encoded) continue;
        if (encoded > FD_MAX) { mapped_put(mapped); return -ERR_EINVAL; }
        mapped[target] = task_fd_acquire_current((int)encoded - 1);
        if (!mapped[target]) { mapped_put(mapped); return -FILE_EBADF; }
    }
    return 0;
}

int32_t task_spawn_process(const char *name, unsigned io_map)
{
    unsigned kind = process_kind(name);
    if (!kind) return -ERR_ENOENT;
    struct open_file *mapped[3] = {0};
    int map_result = stage_io_map(io_map, mapped);
    if (map_result) return map_result;
    uint32_t flags = irq_save();
    int available = process_has_slot() && next_pid <= INT32_MAX;
    irq_restore(flags);
    if (!available) { mapped_put(mapped); return -ERR_EAGAIN; }

    unsigned injected = UINT32_MAX;
    if (process_failure_enabled &&
        tasks[current].program_kind == PROCESS_FAILTEST &&
        kind == PROCESS_COUNT && process_failure_step < 8)
        injected = process_failure_step++;
    if (fd_failure_enabled &&
        tasks[current].program_kind == PROCESS_FDFAIL &&
        kind == PROCESS_FDSHARE && fd_failure_step < 7)
        injected = fd_failure_step++;
    elf_fail_after = injected;
    struct user_space space = {0};
    const void *image = &day19_elf_start;
    uint32_t image_size = (uintptr_t)&day19_elf_end -
                          (uintptr_t)&day19_elf_start;
    if (kind >= PROCESS_FDDEMO) {
        image = &day22_elf_start;
        image_size = (uintptr_t)&day22_elf_end - (uintptr_t)&day22_elf_start;
    }
    int loaded = elf_load(image, image_size, &space);
    if (loaded != ELF_OK) {
        elf_fail_after = UINT32_MAX;
        if (injected != UINT32_MAX) ++process_spawn_rollbacks;
        if (injected != UINT32_MAX && kind >= PROCESS_FDDEMO)
            ++fd_spawn_rollbacks;
        mapped_put(mapped);
        return loaded == ELF_ERR_NOMEM ? -ERR_ENOMEM : -ERR_EINVAL;
    }
    uint32_t mode_physical;
    KASSERT(user_space_physical(&space, PROCESS_MODE_ADDRESS, 1,
                                &mode_physical));
    *(uint32_t *)mode_physical = kind;
    int32_t pid;
    if (!process_create(&space, kind, tasks[current].pid, mapped, &pid)) {
        user_space_destroy(&space);
        elf_fail_after = UINT32_MAX;
        if (injected != UINT32_MAX) ++process_spawn_rollbacks;
        if (injected != UINT32_MAX && kind >= PROCESS_FDDEMO)
            ++fd_spawn_rollbacks;
        mapped_put(mapped);
        return injected != UINT32_MAX ? -ERR_ENOMEM : -ERR_EAGAIN;
    }
    for (unsigned i = 0; i < 3; ++i) mapped[i] = 0;
    elf_fail_after = UINT32_MAX;
    return pid;
}

static int disk_source_read(void *context, uint32_t offset, void *buffer,
                            uint32_t length)
{
    ++disk_exec_reads;
    disk_exec_last_offset = offset;
    elf_source_read_observed();
    return file_pread((struct open_file *)context, offset, buffer, length);
}

static unsigned disk_program_kind(const char *name)
{ return name_equal(name, "SHELL.EXE") ? PROCESS_SHELL : PROCESS_DISK; }

int32_t task_spawn_file(const char *name, unsigned io_map,
                        const struct process_args *args)
{
    if (!name || !args || !args->argc) return -ERR_EINVAL;
    struct open_file *mapped[3] = {0};
    int map_result = stage_io_map(io_map, mapped);
    if (map_result) return map_result;
    uint32_t flags = irq_save();
    int available = process_has_slot() && next_pid <= INT32_MAX;
    irq_restore(flags);
    if (!available) { mapped_put(mapped); return -ERR_EAGAIN; }

    struct open_file *executable = 0;
    int opened = file_open(name, 0, &executable);
    if (opened) { mapped_put(mapped); return opened; }
    disk_exec_size = file_size(executable);
    uint32_t reads_before = disk_exec_reads;
    int day30_demo = name_equal(name, "DEMO.EXE");
    disk_exec_opened();
    const struct elf_source source = {
        disk_exec_size, executable, disk_source_read
    };
    struct user_space space = {0};
    int loaded = elf_load_source(&source, &space);
    file_put(executable);
    executable = 0;
    if (loaded != ELF_OK) {
        mapped_put(mapped);
        disk_exec_result = loaded;
        if (loaded == ELF_ERR_NOMEM) return -ERR_ENOMEM;
        if (loaded == ELF_ERR_SOURCE) return -FILE_EIO;
        return -8; /* ENOEXEC */
    }
    if (!user_space_build_stack(&space, args)) {
        user_space_destroy(&space);
        mapped_put(mapped);
        return -ERR_EINVAL;
    }
    int32_t pid;
    if (!process_create(&space, disk_program_kind(name), tasks[current].pid,
                        mapped, &pid)) {
        user_space_destroy(&space);
        mapped_put(mapped);
        return -ERR_EAGAIN;
    }
    for (unsigned i = 0; i < 3; ++i) mapped[i] = 0;
    disk_exec_result = ELF_OK;
    disk_spawn_published();
    if (day30_demo) {
        day30_demo_size = disk_exec_size;
        day30_demo_reads = disk_exec_reads - reads_before;
        day30_demo_pid = (uint32_t)pid;
    }
    return pid;
}

void task_note_write(const void *bytes, uint32_t length)
{
    const char *text = bytes;
    if (tasks[current].program_kind != PROCESS_SHELL) return;
    for (uint32_t i = 0; i < length; ++i) {
        if (shell_prompt_prefix && text[i] == ' ') {
            KASSERT(process_live_count() == 1 && file_live_count() == 2 &&
                    file_total_refs() == 3);
            if (!shell_prompts) shell_baseline_pages = page_free_count();
            else KASSERT(page_free_count() == shell_baseline_pages);
            ++shell_prompts;
            ++shell_prompt_checks;
            shell_prompt_observed();
            shell_prompt_prefix = 0;
        } else {
            shell_prompt_prefix = text[i] == '#';
        }
    }
}

void task_request_exit(uint32_t status)
{
    KASSERT(current && tasks[current].pid && tasks[current].user.pages[0]);
    tasks[current].exit_status = status & 0xffu;
    tasks[current].user_stop = 1;
}

void task_note_wait_fault(void) { ++process_wait_faults; }

static void process_reap_slot(unsigned slot, int waited)
{
    struct task *task = &tasks[slot];
    KASSERT(current != slot && task->pid && task->state == ZOMBIE);
    KASSERT(!task->trap_depth && !task->preempt_count &&
            !task->waiting_on && !task->sleeping && !task->exit_waiters.mask);
    for (unsigned fd = 0; fd < FD_MAX; ++fd) KASSERT(!task->fds[fd]);
    KASSERT(task->kernel_stack && *(uint32_t *)task->kernel_stack == CANARY);
    int32_t pid = task->pid;
    uint32_t status = task->exit_status;
    if (!task->parent_pid &&
        (task->program_kind == PROCESS_FDDEMO ||
         task->program_kind == PROCESS_FDFAIL ||
         task->program_kind == PROCESS_FDTERM))
        fd_root_status = status;
    if (!task->parent_pid && task->program_kind == PROCESS_SHELL)
        shell_root_status = status;
    user_space_destroy(&task->user);
    KASSERT(page_free(task->kernel_stack));
    *task = (struct task){0};
    ++process_reaped;
    if (waited) ++process_wait_reaped;
    kprintf("D19 REAP pid=%d status=%x by=%s pages=%u\n", pid, status,
            waited ? "wait" : "pid0", page_free_count());
}

static struct task *process_child(int32_t parent, int32_t pid,
                                  unsigned *slot)
{
    for (unsigned i = 1; i < TASK_SLOTS; ++i) {
        if (tasks[i].pid == pid && tasks[i].parent_pid == parent) {
            if (slot) *slot = i;
            return &tasks[i];
        }
    }
    return 0;
}

int32_t task_wait_process(int32_t pid, uintptr_t status_address)
{
    if (pid <= 0) return -ERR_ECHILD;
    uint32_t flags = irq_save();
    KASSERT(current && tasks[current].pid &&
            tasks[current].trap_depth == 1 &&
            !tasks[current].preempt_count);
    unsigned blocked = 0;
    for (;;) {
        unsigned slot;
        struct task *child = process_child(tasks[current].pid, pid, &slot);
        if (!child) { irq_restore(flags); return -ERR_ECHILD; }
        if (child->state == ZOMBIE) {
            uint32_t status = child->exit_status;
            if (!copy_to_user(status_address, &status, sizeof(status))) {
                irq_restore(flags);
                return -ERR_EFAULT;
            }
            if (blocked) ++process_wait_after_block;
            else ++process_wait_immediate;
            process_reap_slot(slot, 1);
            irq_restore(flags);
            return pid;
        }
        struct task *parent = &tasks[current];
        KASSERT(!parent->waiting_on && !parent->sleeping &&
                !(child->exit_waiters.mask & (1u << current)));
        parent->waiting_on = &child->exit_waiters;
        parent->waiting_pid = pid;
        child->exit_waiters.mask |= 1u << current;
        parent->state = BLOCKED;
        ++process_wait_blocks;
        process_blocked_parent_pid = parent->pid;
        process_blocked_target_pid = pid;
        process_blocked_trap_depth = parent->trap_depth;
        process_blocked_wait_mask = child->exit_waiters.mask;
        process_wait_blocked();
        schedule_locked_depth(1);
        blocked = 1;
        KASSERT(!parent->waiting_on && parent->waiting_pid == pid);
        parent->waiting_pid = 0;
    }
}

static void process_note_badptr_exit(struct task *badptr)
{
    unsigned survivors = 0;
    memset(process_release_snapshots, 0, sizeof(process_release_snapshots));
    for (unsigned i = 1; i < task_limit; ++i) {
        struct task *count = &tasks[i];
        if (!count->pid || count->program_kind != PROCESS_COUNT ||
            count->parent_pid != badptr->parent_pid)
            continue;
        uint32_t progress;
        KASSERT(user_space_physical(&count->user, PROCESS_PROGRESS_ADDRESS,
                                    1, &progress));
        process_release_snapshots[i] = *(uint32_t *)progress;
        if (survivors < 2) {
            day30_survivor_pids[survivors] = (uint32_t)count->pid;
            day30_survivor_before[survivors] = *(uint32_t *)progress;
        }
        ++survivors;
    }
    if (!survivors) return;
    process_release_parent = badptr->parent_pid;
    process_release_pending = survivors;
    process_zombie_pages = page_free_count();
    if (survivors == 2) {
        day30_badptr_pid = (uint32_t)badptr->pid;
        day30_badptr_tick = timer_ticks;
        day30_badptr_sequence = ++day30_event_sequence;
        day30_survivor_count = survivors;
        kprintf("D30 BADPTR seq=%u pid=%d vector=%u cr2=%x tick=%u survivors=%u\n",
                day30_badptr_sequence,
                badptr->pid, badptr->user_fault, badptr->user_address,
                timer_ticks, survivors);
    }
}

__attribute__((noinline, noipa)) void fd_exit_closed_observed(void)
{ __asm__ volatile("nop" ::: "memory"); }

static void process_publish_exit(struct task *task)
{
    require_locked();
    KASSERT(task->pid > 0 && task->state == RUNNING &&
            !task->waiting_on && !task->sleeping);
    unsigned closed = task_fd_close_all(task);
    if (closed) {
        fd_exit_closes += closed;
        ++fd_exit_tasks;
        fd_exit_closed_observed();
    }
    if (task->program_kind == PROCESS_BADPTR)
        process_note_badptr_exit(task);
    for (unsigned i = 1; i < TASK_SLOTS; ++i) {
        if (tasks[i].pid && tasks[i].parent_pid == task->pid) {
            tasks[i].parent_pid = 0;
            ++process_orphan_reparented;
        }
    }
    if (process_release_pending && process_release_parent == task->pid)
        process_release_parent = 0;
    task->state = ZOMBIE;
    if (task->exit_waiters.mask)
        KASSERT(wake_one_locked(&task->exit_waiters));
}

static void process_drive_release(void)
{
    if (!process_release_pending) return;
    unsigned found = 0;
    uint32_t growth = 0;
    for (unsigned i = 1; i < task_limit; ++i) {
        struct task *count = &tasks[i];
        if (!count->pid || count->program_kind != PROCESS_COUNT ||
            count->parent_pid != process_release_parent)
            continue;
        uint32_t progress;
        KASSERT(user_space_physical(&count->user, PROCESS_PROGRESS_ADDRESS,
                                    1, &progress));
        uint32_t now = *(uint32_t *)progress;
        if (now == process_release_snapshots[i]) return;
        growth += now - process_release_snapshots[i];
        if (found < 2) day30_survivor_after[found] = now;
        ++found;
    }
    if (found != process_release_pending) return;
    for (unsigned i = 1; i < task_limit; ++i) {
        struct task *count = &tasks[i];
        if (!count->pid || count->program_kind != PROCESS_COUNT ||
            count->parent_pid != process_release_parent)
            continue;
        uint32_t release;
        KASSERT(user_space_physical(&count->user, PROCESS_RELEASE_ADDRESS,
                                    1, &release));
        *(uint32_t *)release = 1;
    }
    process_survivor_growth += growth;
    if (found == 2) {
        day30_survivor_tick = timer_ticks;
        day30_survivor_sequence = ++day30_event_sequence;
        kprintf("D30 SURVIVORS seq=%u count=%u growth=%u,%u tick=%u after-fault=%u\n",
                day30_survivor_sequence,
                found,
                day30_survivor_after[0] - day30_survivor_before[0],
                day30_survivor_after[1] - day30_survivor_before[1],
                timer_ticks, timer_ticks - day30_badptr_tick);
    }
    process_release_pending = 0;
}

static void process_observe_blocked(void)
{
    for (unsigned i = 1; i < TASK_SLOTS; ++i) {
        struct task *task = &tasks[i];
        if (!task->pid || task->state != BLOCKED || !task->waiting_pid ||
            !process_zombie_pages)
            continue;
        struct task *target = process_child(task->pid, task->waiting_pid, 0);
        if (!target || target->program_kind != PROCESS_COUNT ||
            target->state != RUNNABLE)
            continue;
        uint32_t progress;
        KASSERT(user_space_physical(&target->user, PROCESS_PROGRESS_ADDRESS,
                                    1, &progress));
        if (!*(uint32_t *)progress) continue;
        int badptr_zombie = 0;
        for (unsigned j = 1; j < TASK_SLOTS; ++j)
            if (tasks[j].pid && tasks[j].parent_pid == task->pid &&
                tasks[j].program_kind == PROCESS_BADPTR &&
                tasks[j].state == ZOMBIE)
                badptr_zombie = 1;
        if (badptr_zombie) {
            process_blocked_parent_pid = task->pid;
            process_blocked_target_pid = task->waiting_pid;
            process_blocked_trap_depth = task->trap_depth;
            process_blocked_wait_mask = task->waiting_on->mask;
            process_bootstrap_observed();
            return;
        }
    }
}

static void process_reap_orphans(void)
{
    for (unsigned i = 1; i < TASK_SLOTS; ++i)
        if (tasks[i].pid && !tasks[i].parent_pid &&
            tasks[i].state == ZOMBIE)
            process_reap_slot(i, 0);
}

static void process_run_root(const char *name)
{
    int32_t pid = task_spawn_process(name, 0);
    KASSERT(pid > 0);
    while (process_live_count()) {
        process_observe_blocked();
        process_drive_release();
        process_reap_orphans();
        if (process_live_count()) task_yield();
    }
    KASSERT(page_free_count() == process_initial_pages);
}

void process_demo(unsigned failure_mode)
{
    (void)irq_save();
    KASSERT(current == 0 && task_limit == LEGACY_SLOTS);
    task_limit = PROCESS_SLOTS;
    process_initial_pages = page_free_count();
    preempt_active = 1;
    timer_start();
    if (failure_mode) {
        process_failure_enabled = 1;
        process_run_root("FAILTEST");
        process_failure_enabled = 0;
        KASSERT(process_failure_step == 8 && process_spawn_rollbacks == 8);
        process_failure_passed = 1;
    } else {
        process_run_root("DEMO");
        KASSERT(process_wait_reaped == 4 && process_wait_faults == 10);
        process_run_root("ORPHAN");
        KASSERT(process_orphan_reparented == 2 && process_peak_slots == 3);
        KASSERT(process_survivor_growth >= 3);
    }
    uint32_t saved_next_pid = next_pid;
    next_pid = (uint32_t)INT32_MAX + 1u;
    KASSERT(task_spawn_process("COUNT", 0) == -ERR_EAGAIN &&
            page_free_count() == process_initial_pages);
    next_pid = saved_next_pid;
    timer_mask(1);
    preempt_active = need_resched = 0;
    task_limit = LEGACY_SLOTS;
    KASSERT(page_free_count() == process_initial_pages);
    process_passed = 1;
    kprintf("PROCESS OK mode=%s reaped=%u wait=%u blocks=%u faults=%u rollback=%u survivor+=%u pages=%u\n",
            failure_mode ? "failure" : "normal", process_reaped,
            process_wait_reaped, process_wait_blocks, process_wait_faults,
            process_spawn_rollbacks, process_survivor_growth,
            page_free_count());
    process_demo_done();
}

__attribute__((noinline, noipa)) void fd_demo_done(void)
{ __asm__ volatile("nop" ::: "memory"); }

static unsigned fd_map3(unsigned first, unsigned second, unsigned third)
{
    return 0xd2200000u | (first + 1u) | ((second + 1u) << 4) |
           ((third + 1u) << 8);
}

static void fd_idle_once(void)
{
    (void)irq_save();
    for (unsigned i = 1; i < TASK_SLOTS; ++i) {
        if (tasks[i].state == RUNNABLE) { task_yield(); return; }
    }
    __asm__ volatile("sti; hlt; cli" ::: "memory");
}

void fd_demo(unsigned mode)
{
    (void)irq_save();
    KASSERT(current == 0 && task_limit == LEGACY_SLOTS &&
            !file_live_count() && !file_total_refs());
    task_limit = PROCESS_SLOTS;
    fd_initial_pages = page_free_count();
    fd_root_status = 0xffffffffu;
    uint32_t reaped_before = process_reaped;
    uint32_t blocks_before = keyboard_blocks;

    struct open_file *input, *output;
    KASSERT(file_open_terminal(1, &input) == 0 &&
            task_fd_install_current(input) == 0);
    KASSERT(file_open_terminal(0, &output) == 0 &&
            task_fd_install_current(output) == 1);
    KASSERT(file_get(output) && task_fd_install_current(output) == 2);

    const char *program = mode == 1 ? "FDTERM" :
                          mode == 2 ? "FDFAIL" : "FDDEMO";
    if (mode == 2) fd_failure_enabled = 1;
    KASSERT(task_spawn_process(program, fd_map3(0, 1, 1)) > 0);
    task_fd_close_all(&tasks[0]);

    idle_active = preempt_active = 1;
    timer_start();
    while (process_live_count()) {
        process_reap_orphans();
        if (process_live_count()) fd_idle_once();
    }
    (void)irq_save();
    process_reap_orphans();
    timer_mask(1);
    idle_active = preempt_active = need_resched = 0;
    task_limit = LEGACY_SLOTS;
    fd_failure_enabled = 0;
    fd_reaped += process_reaped - reaped_before;
    fd_terminal_blocks += keyboard_blocks - blocks_before;
    KASSERT(page_free_count() == fd_initial_pages &&
            !file_live_count() && !file_total_refs());
    if (mode == 2) KASSERT(fd_failure_step == 7 && fd_spawn_rollbacks == 7);
    KASSERT(fd_root_status == (mode ? 0u : 22u));
    fd_terminal_mode = mode;
    fd_passed = 1;
    kprintf("FD OK mode=%u reaped=%u exit-closes=%u rollback=%u blocks=%u pages=%u\n",
            mode, fd_reaped, fd_exit_closes, fd_spawn_rollbacks,
            fd_terminal_blocks, page_free_count());
    fd_demo_done();
}

_Noreturn void shell_start(void)
{
    (void)irq_save();
    KASSERT(current == 0 && task_limit == LEGACY_SLOTS &&
            !file_live_count() && !file_total_refs());
    task_limit = PROCESS_SLOTS;
    shell_initial_pages = page_free_count();
    shell_root_status = 0xffffffffu;
    idle_active = preempt_active = 1;
    timer_start();
    struct open_file *input, *output;
    KASSERT(file_open_terminal(1, &input) == 0 &&
            task_fd_install_current(input) == 0);
    KASSERT(file_open_terminal(0, &output) == 0 &&
            task_fd_install_current(output) == 1);
    KASSERT(file_get(output) && task_fd_install_current(output) == 2);
    KASSERT(keyboard_start());
    struct process_args args = {.argc=1};
    memcpy(args.values[0], "SHELL.EXE", sizeof("SHELL.EXE"));
    KASSERT(task_spawn_file("SHELL.EXE", fd_map3(0, 1, 2), &args) > 0);
    task_fd_close_all(&tasks[0]);
    while (process_live_count()) {
        process_reap_orphans();
        if (process_live_count()) fd_idle_once();
    }
    (void)irq_save();
    process_reap_orphans();
    timer_mask(1);
    idle_active = preempt_active = need_resched = 0;
    task_limit = LEGACY_SLOTS;
    KASSERT(shell_root_status == 0 && page_free_count() == shell_initial_pages &&
            !file_live_count() && !file_total_refs() &&
            !file_pipe_live_count() && pipe_releases == pipe_creates);
    kprintf("PIPE STATS creates=%u releases=%u rblock=%u wblock=%u eof=%u broken=%u read=%u written=%u\n",
            pipe_creates, pipe_releases, pipe_read_blocks, pipe_write_blocks,
            pipe_eofs, pipe_broken_writes, pipe_bytes_read,
            pipe_bytes_written);
    kprintf("SHELL OK prompts=%u pages=%u\n", shell_prompts,
            page_free_count());
    shell_demo_done();
    for (;;) __asm__ volatile("sti; hlt; cli" ::: "memory");
}

static _Noreturn void shell_start_graphics_mode(void (*poll)(void),
                                                void (*finish)(void),
                                                unsigned final_demo)
{
    (void)irq_save();
    KASSERT(current == 0 && task_limit == LEGACY_SLOTS &&
            !file_live_count() && !file_total_refs() && poll && finish);
    file_graphics_terminal_begin();
    task_limit = final_demo ? TASK_SLOTS : PROCESS_SLOTS;
    shell_initial_pages = page_free_count();
    shell_root_status = 0xffffffffu;
    uint32_t reaped_before = process_reaped;
    if (final_demo) {
        day30_badptr_pid = day30_badptr_tick = 0;
        day30_survivor_tick = day30_survivor_count = 0;
        day30_event_sequence = day30_badptr_sequence = 0;
        day30_survivor_sequence = 0;
        memset((void *)day30_survivor_pids, 0, sizeof(day30_survivor_pids));
        memset((void *)day30_survivor_before, 0, sizeof(day30_survivor_before));
        memset((void *)day30_survivor_after, 0, sizeof(day30_survivor_after));
        day30_demo_size = day30_demo_reads = day30_demo_pid = 0;
        fat_directory_reads = fat_directory_files = 0;
    }
    idle_active = preempt_active = 1;
    timer_start();
    KASSERT(mouse_start());
    struct open_file *input, *output;
    KASSERT(file_open_terminal(1, &input) == 0 &&
            task_fd_install_current(input) == 0);
    KASSERT(file_open_terminal(0, &output) == 0 &&
            task_fd_install_current(output) == 1);
    KASSERT(file_get(output) && task_fd_install_current(output) == 2);
    struct process_args args = {.argc=1};
    memcpy(args.values[0], "SHELL.EXE", sizeof("SHELL.EXE"));
    KASSERT(task_spawn_file("SHELL.EXE", fd_map3(0, 1, 2), &args) > 0);
    task_fd_close_all(&tasks[0]);
    while (process_live_count()) {
        process_reap_orphans();
        if (final_demo) process_drive_release();
        poll();
        if (process_live_count()) fd_idle_once();
    }
    (void)irq_save();
    process_reap_orphans();
    finish();
    timer_mask(1);
    idle_active = preempt_active = need_resched = 0;
    task_limit = LEGACY_SLOTS;
    KASSERT(shell_root_status == 0 &&
            !file_live_count() && !file_total_refs() &&
            !file_pipe_live_count() && pipe_releases == pipe_creates &&
            terminal_output_bytes == terminal_output_consumed &&
            !terminal_input_dropped && terminal_endpoint_releases == 2);
    day30_reaped_delta = process_reaped - reaped_before;
    day30_final_pages = page_free_count();
    kprintf("D29 TERMINAL input=%u output=%u consumed=%u high=%u/%u block=%u/%u endpoints=%u\n",
            terminal_input_bytes, terminal_output_bytes,
            terminal_output_consumed, terminal_input_high_water,
            terminal_output_high_water, terminal_read_blocks,
            terminal_write_blocks, terminal_endpoint_releases);
    kprintf("D29 ELF size=%u reads=%u prompts=%u pipe=%u/%u rblock=%u wblock=%u\n",
            disk_exec_size, disk_exec_reads, shell_prompts,
            pipe_creates, pipe_releases, pipe_read_blocks,
            pipe_write_blocks);
    kprintf("WINDOW SHELL OK FAT ELF, bounded terminal and responsive UI\n");
    if (final_demo) {
        KASSERT(day30_demo_size && day30_demo_reads && day30_demo_pid &&
                day30_badptr_pid && day30_survivor_count == 2 &&
                day30_badptr_sequence &&
                day30_survivor_sequence > day30_badptr_sequence &&
                day30_survivor_tick >= day30_badptr_tick &&
                day30_survivor_after[0] > day30_survivor_before[0] &&
                day30_survivor_after[1] > day30_survivor_before[1] &&
                fat_directory_reads && fat_directory_files >= 2);
        kprintf("D30 FINAL demo=%u/%u pid=%u reaped=%u dir=%u/%u prompts=%u pages=%u\n",
                day30_demo_size, day30_demo_reads, day30_demo_pid,
                day30_reaped_delta, fat_directory_files, fat_directory_reads,
                shell_prompts, day30_final_pages);
        kprintf("FINAL DEMO OK FAT ls, pipe, two survivors, cleanup\n");
    }
    file_graphics_terminal_end();
    shell_demo_done();
    for (;;) __asm__ volatile("sti; hlt; cli" ::: "memory");
}

_Noreturn void shell_start_graphics(void (*poll)(void), void (*finish)(void))
{ shell_start_graphics_mode(poll, finish, 0); }

_Noreturn void shell_start_final(void (*poll)(void), void (*finish)(void))
{ shell_start_graphics_mode(poll, finish, 1); }
