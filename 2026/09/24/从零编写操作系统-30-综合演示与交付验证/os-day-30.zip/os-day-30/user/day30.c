#include <stddef.h>
#include <stdint.h>

#define SYS_YIELD 2u
#define SYS_SPAWN 3u
#define SYS_EXIT 4u
#define SYS_WAIT 5u
#define SYS_FD_WRITE 8u
#define ERR_ECHILD 10
#define FAULT_STATUS(vector) (0x10000u | (vector))

static int32_t call2(uint32_t number, uintptr_t first, uintptr_t second)
{
    int32_t result;
    __asm__ volatile("int $0x80" : "=a"(result)
                     : "a"(number), "b"(first), "c"(second)
                     : "memory", "cc");
    return result;
}

static int32_t write_fd(int fd, const void *buffer, uint32_t length)
{
    int32_t result;
    __asm__ volatile("int $0x80" : "=a"(result)
                     : "a"(SYS_FD_WRITE), "b"(fd), "c"(buffer), "d"(length)
                     : "memory", "cc");
    return result;
}

static size_t text_length(const char *text)
{ size_t length = 0; while (text[length]) ++length; return length; }

static int write_all(const char *text)
{
    uint32_t length = (uint32_t)text_length(text), written = 0;
    while (written < length) {
        int32_t result = write_fd(1, text + written, length - written);
        if (result <= 0) return -1;
        written += (uint32_t)result;
    }
    return 0;
}

static int write_unsigned(uint32_t value)
{
    char digits[10];
    unsigned count = 0;
    do { digits[count++] = (char)('0' + value % 10); value /= 10; } while (value);
    while (count) {
        if (write_fd(1, &digits[--count], 1) != 1) return -1;
    }
    return 0;
}

static int32_t spawn(const char *name)
{ return call2(SYS_SPAWN, (uintptr_t)name, 0); }

static int32_t wait_pid(int32_t pid, uint32_t *status)
{ return call2(SYS_WAIT, (uintptr_t)pid, (uintptr_t)status); }

static int fail(const char *message, int code)
{ (void)write_all(message); return code; }

int day30_main(int argc, char **argv)
{
    (void)argv;
    if (argc != 1) return fail("DEMO bad arguments\n", 2);
    if (write_all("DEMO start: two counters and one bad pointer\n")) return 3;
    int32_t first = spawn("COUNT");
    int32_t second = spawn("COUNT");
    int32_t bad = spawn("BADPTR");
    if (first <= 0 || second <= first || bad <= second)
        return fail("DEMO spawn failed\n", 4);
    if (write_all("DEMO pids count=") || write_unsigned((uint32_t)first) ||
        write_all(",") || write_unsigned((uint32_t)second) ||
        write_all(" badptr=") || write_unsigned((uint32_t)bad) ||
        write_all("\n"))
        return 5;
    (void)call2(SYS_YIELD, 0, 0);
    uint32_t status = 0;
    if (wait_pid(bad, &status) != bad || status != FAULT_STATUS(14))
        return fail("DEMO badptr status failed\n", 6);
    if (write_all("DEMO badptr #PF isolated\n")) return 7;
    if (wait_pid(first, &status) != first || status != 7)
        return fail("DEMO first counter failed\n", 8);
    if (wait_pid(second, &status) != second || status != 7)
        return fail("DEMO second counter failed\n", 9);
    if (wait_pid(bad, &status) != -ERR_ECHILD)
        return fail("DEMO duplicate wait failed\n", 10);
    if (write_all("DEMO OK: both counters advanced after fault\n")) return 11;
    return 0;
}
