#!/usr/bin/env python3
"""Run Day 30 once, after QMP hard reset, and in a fresh QEMU process."""
import hashlib
import json
import os
import shlex
import socket
import subprocess
import time
from pathlib import Path

BUILD = Path("build")
QEMU = os.environ.get("QEMU", "qemu-system-i386")
GDB = os.environ.get("GDB", "gdb-multiarch")
COMMON = shlex.split(os.environ["QEMU_COMMON"])
# The cumulative checks normally fail closed on any guest reset. Day 30 is the
# one test that intentionally asks QMP to reset the same virtual machine.
RESET_COMMON = [argument for argument in COMMON if argument != "-no-reboot"]
QMP_LOG = BUILD / "day30-qmp.txt"
HMP_LOG = BUILD / "day30-hmp.txt"


def connect_unix(path):
    client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    for _ in range(300):
        try:
            client.connect(str(path))
            return client
        except (FileNotFoundError, ConnectionRefusedError):
            time.sleep(.05)
    raise AssertionError("monitor did not appear: " + str(path))


class Qmp:
    def __init__(self, path, label):
        self.label = label
        self.socket = connect_unix(path)
        self.stream = self.socket.makefile("rwb", buffering=0)
        greeting = self._receive()
        assert "QMP" in greeting, greeting
        self.execute("qmp_capabilities")

    def _record(self, direction, value):
        with QMP_LOG.open("a") as output:
            output.write("%s %s %s\n" %
                         (self.label, direction, json.dumps(value, sort_keys=True)))

    def _receive(self):
        line = self.stream.readline()
        if not line:
            raise AssertionError("QMP disconnected")
        value = json.loads(line)
        self._record("<-", value)
        return value

    def execute(self, command, arguments=None):
        request = {"execute": command, "id": command + "-" + self.label}
        if arguments is not None:
            request["arguments"] = arguments
        self._record("->", request)
        self.stream.write((json.dumps(request) + "\r\n").encode())
        while True:
            response = self._receive()
            if response.get("id") == request["id"]:
                assert "error" not in response, response
                return response.get("return")

    def close(self):
        self.stream.close()
        self.socket.close()


class Hmp:
    def __init__(self, path, label):
        self.label = label
        self.socket = connect_unix(path)
        self.socket.settimeout(5)
        greeting = b""
        while b"(qemu)" not in greeting:
            greeting += self.socket.recv(8192)

    def execute(self, command):
        self.socket.sendall((command + "\n").encode())
        output = b""
        while b"(qemu)" not in output:
            output += self.socket.recv(8192)
        decoded = output.decode(errors="replace")
        with HMP_LOG.open("a") as transcript:
            transcript.write("%s > %s\n%s\n" %
                             (self.label, command, decoded.rstrip()))
        return decoded

    def close(self):
        self.socket.close()


def stop(process):
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()


def start_instance(label, port, serial):
    hmp_path = BUILD / ("day30-%s-hmp.sock" % label)
    qmp_path = BUILD / ("day30-%s-qmp.sock" % label)
    qemu_log = BUILD / ("day30-%s-qemu.txt" % label)
    for path in (hmp_path, qmp_path, serial, qemu_log):
        path.unlink(missing_ok=True)
    output = qemu_log.open("wb")
    process = subprocess.Popen([
        QEMU, *RESET_COMMON, "-snapshot",
        "-drive", "file=build/mbr-final.img,format=raw,if=ide",
        "-display", "none", "-serial", "file:" + str(serial),
        "-monitor", "unix:" + str(hmp_path) + ",server=on,wait=off",
        "-qmp", "unix:" + str(qmp_path) + ",server=on,wait=off",
        "-S", "-gdb", "tcp:127.0.0.1:%d" % port,
    ], stdout=output, stderr=subprocess.STDOUT)
    return process, output, Hmp(hmp_path, label), Qmp(qmp_path, label)


def key_name(character):
    if character == " ": return "spc"
    if character == ".": return "dot"
    if character == "|": return "shift-backslash"
    if character == "-": return "minus"
    if "a" <= character <= "z" or "0" <= character <= "9":
        return character
    raise ValueError("unsupported key %r" % character)


def send_line(hmp, line):
    for character in line:
        hmp.execute("sendkey %s 20" % key_name(character))
        time.sleep(.02)
    hmp.execute("sendkey ret 20")


def gdb_run(port, commands, output_name=None, timeout=180):
    script = (
        "set architecture i386\n"
        "set tcp connect-timeout 5\n"
        "set tcp auto-retry on\n"
        "file build/kernel-final.elf\n"
        "target remote 127.0.0.1:%d\n" % port + commands + "\n"
    )
    script_path = BUILD / ("day30-%s.gdb" % (output_name or "probe"))
    script_path.write_text(script)
    result = subprocess.run(
        [GDB, "-q", "-nx", "-batch", "-x", str(script_path)],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        timeout=timeout, check=False,
    )
    if output_name:
        (BUILD / ("day30-%s-gdb.txt" % output_name)).write_text(result.stdout)
    assert result.returncode == 0, result.stdout
    return result.stdout


def read_counter(port, expression):
    output = gdb_run(
        port,
        "python\nprint(int(gdb.parse_and_eval('%s')))\nend\ndetach" % expression,
        timeout=30,
    )
    for line in reversed(output.splitlines()):
        if line.isdigit(): return int(line)
    raise AssertionError(output)


def wait_counter(port, expression, expected, timeout=60):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if read_counter(port, expression) >= expected: return
        time.sleep(.1)
    raise AssertionError("timeout waiting for %s >= %u" % (expression, expected))


def wait_serial(serial, marker, count=1, timeout=30):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if serial.exists() and serial.read_bytes().count(marker) >= count:
            return
        time.sleep(.05)
    raise AssertionError("serial marker missing: " + repr(marker))


def begin_round(port, label):
    output = gdb_run(
        port,
        "hbreak shell_prompt_observed\ncontinue\n"
        "python\n"
        "v=lambda x:int(gdb.parse_and_eval(x))\n"
        "assert v('shell_prompts')==1 and v('shell_user_cs')==0x1b\n"
        "assert v('file_live_count()')==2 and v('file_total_refs()')==3\n"
        "print('READY %s cs=%%x eip=%%x pages=%%u refs=%%u' %% "
        "(v('shell_user_cs'),v('shell_user_eip'),v('graphics_window_shell_initial_pages'),v('file_total_refs()')))\n"
        "end\ndelete breakpoints\ndetach" % label,
        label + "-ready",
    )
    assert "READY " + label in output


def exercise_round(port, hmp, qmp, label, screen, serial, marker_count,
                   demo_size):
    sequence = (
        ("ls", 2),
        ("cat readme.txt", 3),
        ("cat readme.txt | wc", 4),
        ("demo", 5),
        ("echo after-reset", 6),
    )
    for command, prompts in sequence:
        send_line(hmp, command)
        if command == "cat readme.txt":
            hmp.execute("mouse_move -60 40")
            hmp.execute("mouse_move 25 -15")
        wait_counter(port, "shell_prompts", prompts)
    qmp.execute("screendump", {"filename": str(screen.resolve()),
                               "format": "png"})
    final = subprocess.Popen(
        [GDB, "-q", "-nx", "-batch", "-x",
         str(write_final_script(port, label, demo_size))],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
    )
    time.sleep(.4)
    send_line(hmp, "exit")
    output, _ = final.communicate(timeout=180)
    (BUILD / ("day30-%s-final-gdb.txt" % label)).write_text(output)
    assert final.returncode == 0, output
    assert "FINAL " + label in output
    wait_serial(serial, b"FINAL DEMO OK", marker_count)
    image = screen.read_bytes()
    assert image[:8] == b"\x89PNG\r\n\x1a\n" and len(image) > 1000


def write_final_script(port, label, demo_size):
    path = BUILD / ("day30-%s-final.gdb" % label)
    commands = (
        "set architecture i386\nset tcp connect-timeout 5\nset tcp auto-retry on\n"
        "file build/kernel-final.elf\ntarget remote 127.0.0.1:%d\n" % port +
        "hbreak shell_demo_done\ncontinue\npython\n"
        "v=lambda x:int(gdb.parse_and_eval(x))\n"
        "mem=lambda a,n:bytes(gdb.selected_inferior().read_memory(a,n))\n"
        "log=mem(v('&graphics_window_shell_log[0]'),v('graphics_window_shell_log_length'))\n"
        "assert b'# ls\\nREADME.TXT 1479\\n' in log\n"
        "assert b'DEMO.EXE %d\\n' in log\n" % demo_size +
        "assert b'# cat readme.txt | wc\\n27 1479\\n' in log\n"
        "assert b'DEMO badptr #PF isolated\\n' in log\n"
        "assert b'DEMO OK: both counters advanced after fault\\n' in log\n"
        "assert b'# echo after-reset\\nafter-reset\\n' in log\n"
        "assert log.endswith(b'# exit\\n')\n"
        "assert v('day30_demo_size')==%d and v('day30_demo_reads')>0\n" % demo_size +
        "assert v('day30_survivor_count')==2\n"
        "assert v('day30_survivor_sequence')>v('day30_badptr_sequence')>0\n"
        "assert v('day30_survivor_after[0]')>v('day30_survivor_before[0]')\n"
        "assert v('day30_survivor_after[1]')>v('day30_survivor_before[1]')\n"
        "assert v('fat_directory_files')==13 and v('fat_directory_reads')>0\n"
        "assert v('graphics_window_shell_initial_pages')==v('graphics_window_shell_final_pages')\n"
        "assert v('day30_final_pages')==v('graphics_window_shell_final_pages')\n"
        "assert v('file_live_count()')==0 and v('file_total_refs()')==0\n"
        "assert v('terminal_output_bytes')==v('terminal_output_consumed')\n"
        "assert v('terminal_endpoint_releases')==2 and v('day30_reaped_delta')>=10\n"
        "print('FINAL %s demo=%%u/%%u bad=%%u seq=%%u<%%u growth=%%u,%%u dir=%%u/%%u reaped=%%u pages=%%u prompts=%%u' %% "
        "(v('day30_demo_size'),v('day30_demo_reads'),v('day30_badptr_pid'),"
        "v('day30_badptr_sequence'),v('day30_survivor_sequence'),"
        "v('day30_survivor_after[0]')-v('day30_survivor_before[0]'),"
        "v('day30_survivor_after[1]')-v('day30_survivor_before[1]'),"
        "v('fat_directory_files'),v('fat_directory_reads'),v('day30_reaped_delta'),"
        "v('day30_final_pages'),v('shell_prompts')))\n" % label +
        "end\ndelete breakpoints\ndetach\n"
    )
    path.write_text(commands)
    return path


def main():
    QMP_LOG.unlink(missing_ok=True)
    HMP_LOG.unlink(missing_ok=True)
    demo = (BUILD / "day30-user.elf").read_bytes()
    demo_size = len(demo)
    image_sha = hashlib.sha256((BUILD / "mbr-final.img").read_bytes()).hexdigest()
    demo_sha = hashlib.sha256(demo).hexdigest()

    serial = BUILD / "day30-warm-serial.txt"
    process, output, hmp, qmp = start_instance("warm", 1273, serial)
    try:
        begin_round(1273, "first")
        exercise_round(1273, hmp, qmp, "first",
                       BUILD / "day30-first-screen.png", serial, 1,
                       demo_size)
        qmp.execute("system_reset")
        wait_serial(serial, b"D03 STAGE2 OK", 2)
        begin_round(1273, "warm-reset")
        exercise_round(1273, hmp, qmp, "warm-reset",
                       BUILD / "day30-reset-screen.png", serial, 2,
                       demo_size)
    finally:
        qmp.close()
        hmp.close()
        stop(process)
        output.close()

    serial = BUILD / "day30-fresh-serial.txt"
    process, output, hmp, qmp = start_instance("fresh", 1274, serial)
    try:
        begin_round(1274, "fresh-process")
        exercise_round(1274, hmp, qmp, "fresh-process",
                       BUILD / "day30-fresh-screen.png", serial, 1,
                       demo_size)
    finally:
        qmp.close()
        hmp.close()
        stop(process)
        output.close()

    warm = (BUILD / "day30-warm-serial.txt").read_bytes().replace(b"\r\n", b"\n")
    fresh = (BUILD / "day30-fresh-serial.txt").read_bytes().replace(b"\r\n", b"\n")
    assert warm.count(b"FINAL DEMO OK") == 2 and fresh.count(b"FINAL DEMO OK") == 1
    assert warm.count(b"D30 BADPTR seq=1") == 2 and fresh.count(b"D30 BADPTR seq=1") == 1
    assert b"PANIC" not in warm and b"PANIC" not in fresh
    print("D30 image sha256=" + image_sha)
    print("D30 demo size=%d sha256=%s" % (demo_size, demo_sha))
    print("PASS: Day30 first run, QMP hard reset, fresh process and cleanup")


if __name__ == "__main__":
    main()
