#include "syscall.h"
#include "console.h"
#include "memory.h"
#include "runtime.h"
#include "task.h"
#include "timer.h"
#include "user.h"

#define PAGE_MASK 0xfffff000u
#define PAGE_OFFSET 0x00000fffu
#define PAGE_PRESENT 0x001u
#define PAGE_WRITE 0x002u
#define PAGE_USER 0x004u

#define ERR_EFAULT 14
#define ERR_EINVAL 22
#define ERR_ENOSYS 38

volatile uint32_t syscall_count;
volatile uint32_t syscall_write_count;
volatile uint32_t syscall_yield_count;
volatile uint32_t syscall_error_count;
volatile uint32_t syscall_irq_ticks;
volatile unsigned syscall_wait_for_irq;

static int user_page_ok(uint32_t cr3, uintptr_t address, int write_access,
                        uint32_t *physical)
{
    uint32_t *directory = (uint32_t *)(cr3 & PAGE_MASK);
    uint32_t pde = directory[address >> 22];
    uint32_t required = PAGE_PRESENT | PAGE_USER;
    if ((pde & required) != required || (write_access && !(pde & PAGE_WRITE)))
        return 0;
    uint32_t *table = (uint32_t *)(pde & PAGE_MASK);
    uint32_t pte = table[(address >> 12) & 1023u];
    if ((pte & required) != required || (write_access && !(pte & PAGE_WRITE)))
        return 0;
    if (physical) *physical = (pte & PAGE_MASK) | (address & PAGE_OFFSET);
    return 1;
}

int user_range_ok(uint32_t cr3, uintptr_t address, size_t length,
                  int write_access)
{
    if (!length) return 1;
    if (address < USER_CODE || address >= USER_STACK) return 0;
    if (length > (size_t)(USER_STACK - address)) return 0;
    uintptr_t last = address + length - 1;
    uintptr_t page = address & PAGE_MASK;
    uintptr_t last_page = last & PAGE_MASK;
    for (;;) {
        if (!user_page_ok(cr3, page, write_access, 0)) return 0;
        if (page == last_page) return 1;
        page += PAGE_BYTES;
    }
}

static uint32_t current_cr3(void)
{
    uint32_t cr3;
    __asm__ volatile("mov %%cr3,%0" : "=r"(cr3));
    return cr3;
}

int copy_from_user(void *destination, uintptr_t address, size_t length)
{
    uint32_t cr3 = current_cr3();
    if (!user_range_ok(cr3, address, length, 0)) return 0;
    uint8_t *out = destination;
    while (length) {
        uint32_t physical;
        KASSERT(user_page_ok(cr3, address, 0, &physical));
        size_t chunk = PAGE_BYTES - (address & PAGE_OFFSET);
        if (chunk > length) chunk = length;
        memcpy(out, (const void *)physical, chunk);
        out += chunk;
        address += chunk;
        length -= chunk;
    }
    return 1;
}

int copy_to_user(uintptr_t address, const void *source, size_t length)
{
    uint32_t cr3 = current_cr3();
    if (!user_range_ok(cr3, address, length, 1)) return 0;
    const uint8_t *in = source;
    while (length) {
        uint32_t physical;
        KASSERT(user_page_ok(cr3, address, 1, &physical));
        size_t chunk = PAGE_BYTES - (address & PAGE_OFFSET);
        if (chunk > length) chunk = length;
        memcpy((void *)physical, in, chunk);
        in += chunk;
        address += chunk;
        length -= chunk;
    }
    return 1;
}

static int32_t syscall_write(uintptr_t address, size_t length)
{
    char bytes[SYSCALL_WRITE_MAX];
    if (length > sizeof(bytes)) return -ERR_EINVAL;
    if (!length) return 0;
    if (!copy_from_user(bytes, address, length)) return -ERR_EFAULT;

    uint32_t before = timer_ticks;
    __asm__ volatile("sti" ::: "memory");
    if (syscall_wait_for_irq) {
        while (timer_ticks == before) __asm__ volatile("pause");
        syscall_irq_ticks = timer_ticks - before;
        syscall_wait_for_irq = 0;
    }
    for (size_t i = 0; i < length; ++i) console_putc(bytes[i]);
    __asm__ volatile("cli" ::: "memory");
    ++syscall_write_count;
    return (int32_t)length;
}

void syscall_dispatch(struct trap_frame *frame)
{
    KASSERT((frame->cs & 3) == 3 && frame->vector == 128 && frame->error == 0);
    ++syscall_count;
    int32_t result;
    if (frame->eax == SYS_WRITE)
        result = syscall_write(frame->ebx, frame->ecx);
    else if (frame->eax == SYS_YIELD) {
        ++syscall_yield_count;
        task_request_reschedule();
        result = 0;
    } else
        result = -ERR_ENOSYS;
    if (result < 0) ++syscall_error_count;
    frame->eax = (uint32_t)result;
}
