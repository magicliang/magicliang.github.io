#include "task.h"
#include "memory.h"
#include "runtime.h"
#include "console.h"
#include "timer.h"
#include "keyboard.h"
#include "user.h"
#include "syscall.h"
#define SLOTS 3u
#define CANARY 0x51accafeu
enum task_state { DEAD, RUNNABLE, RUNNING, BLOCKED };
struct task {
    uint32_t *saved_sp;
    uint32_t kernel_stack;
    enum task_state state;
    void (*entry)(void *);
    void *arg;
    unsigned trap_depth, preempt_count;
    struct wait_queue *waiting_on;
    unsigned sleeping;
    uint32_t wake_tick;
    struct user_space user;
    unsigned user_stop, user_fault;
    uint32_t user_error, user_address, user_eip;
};
static struct task tasks[SLOTS];
static unsigned current;
volatile uint32_t task_counts[2], task_local_address[2], task_stack_used[2];
volatile uint32_t task_switches, task_reaped, task_passed, task_initial_pages;
static unsigned starvation;
static unsigned preempt_active;
static unsigned idle_active;
volatile unsigned need_resched;
volatile uint32_t preempt_switches, preempt_deferred;
extern void switch_context(uint32_t **old_sp, uint32_t *new_sp);
extern void task_trampoline(void);
extern int task_register_probe(unsigned seed);
volatile uint32_t syscall_yield_before, syscall_yield_after, syscall_yield_switched;
static unsigned syscall_yield_owner, syscall_yield_target, syscall_yield_stage;
static unsigned syscall_yield_probe_active;
uint32_t irq_save(void)
{
    uint32_t flags;
    __asm__ volatile("pushfl; popl %0; cli" : "=r"(flags) : : "memory");
    return flags;
}
void irq_restore(uint32_t flags)
{ __asm__ volatile("pushl %0; popfl" : : "r"(flags) : "memory", "cc"); }
/* A suspended scheduler returns with IF=0; its caller restores its own flags. */
static void schedule_locked(void)
{
    uint32_t flags;
    __asm__ volatile("pushfl; popl %0" : "=r"(flags));
    KASSERT(!(flags & 0x200));
    KASSERT(!tasks[current].trap_depth && !tasks[current].preempt_count);
    unsigned old = current;
    need_resched = 0; /* Consume before switching; a new task may request again. */
    for (unsigned n = 1; n <= SLOTS + idle_active; ++n) {
        unsigned next = (old + n) % SLOTS;
        if (idle_active) {
            if (n <= SLOTS && next == 0) continue;
            if (n == SLOTS + 1) next = 0;
        }
        if (tasks[next].state != RUNNABLE) continue;
        current = next;
        tasks[next].state = RUNNING;
        if (next != old) {
            if (syscall_yield_stage == 1 && syscall_yield_owner == old) {
                syscall_yield_target = next;
                KASSERT(tasks[next].user.pages[4]);
                syscall_yield_before = *(uint32_t *)tasks[next].user.pages[4];
                syscall_yield_switched = 1;
                syscall_yield_stage = 2;
            } else if (syscall_yield_stage == 2 && next == syscall_yield_owner) {
                syscall_yield_after = *(uint32_t *)tasks[syscall_yield_target].user.pages[4];
                syscall_yield_stage = 0;
            }
            if (preempt_active) ++preempt_switches;
            else ++task_switches;
            user_switch(tasks[next].user.pages[0], tasks[next].kernel_stack + PAGE_BYTES);
            switch_context(&tasks[old].saved_sp, tasks[next].saved_sp);
        }
        return;
    }
    panic(__FILE__, __LINE__, "no runnable bootstrap");
}
static int task_create_space(void (*entry)(void *), void *arg, const struct user_space *space)
{
    uint32_t flags = irq_save();
    if (!entry && !space) { irq_restore(flags); return 0; }
    for (unsigned i = 1; i < SLOTS; ++i) {
        struct task *t = &tasks[i];
        if (t->state != DEAD || t->kernel_stack) continue;
        uint32_t page = space && user_fail_after == 6 ? 0 : page_alloc();
        if (!page) { irq_restore(flags); return 0; }
        memset((void *)page, 0xa5, PAGE_BYTES);
        *(uint32_t *)page = CANARY;
        uint32_t *sp = (uint32_t *)(page + PAGE_BYTES);
        *--sp = (uint32_t)task_trampoline;
        *--sp = 0; /* EBP */
        *--sp = 0; /* EBX */
        *--sp = 0; /* ESI */
        *--sp = 0; /* EDI */
        *t = (struct task){.saved_sp=sp, .kernel_stack=page, .state=DEAD,
                          .entry=entry, .arg=arg};
        if (space) t->user = *space;
        t->state = RUNNABLE;
        irq_restore(flags);
        return 1;
    }
    irq_restore(flags);
    return 0;
}
int task_create(void (*entry)(void *), void *arg)
{ return task_create_space(entry, arg, 0); }
void task_yield(void)
{
    uint32_t flags = irq_save();
    tasks[current].state = RUNNABLE;
    schedule_locked();
    irq_restore(flags);
}
void task_request_reschedule(void)
{
    KASSERT(current && tasks[current].user.pages[0]);
    if (syscall_yield_probe_active) {
        syscall_yield_owner = current;
        syscall_yield_stage = 1;
    }
    need_resched = 1;
}
_Noreturn void task_exit(void)
{
    (void)irq_save();
    KASSERT(current != 0);
    KASSERT(!tasks[current].waiting_on && !tasks[current].sleeping);
    tasks[current].state = DEAD;
    schedule_locked();
    panic(__FILE__, __LINE__, "dead task resumed");
}
void task_start(void)
{
    if (tasks[current].user.pages[0]) enter_user(USER_CODE, USER_STACK);
    /* D13 retains IF=0; only the separately initialized D14 PIT permits STI. */
    if (preempt_active) __asm__ volatile("sti" ::: "memory");
    tasks[current].entry(tasks[current].arg);
}
void task_sample(void) { __asm__ volatile("" ::: "memory"); }
void task_starving(void) { __asm__ volatile("" ::: "memory"); }
void task_demo_done(void) { __asm__ volatile("" ::: "memory"); }
static void counter(void *arg)
{
    unsigned id = (uintptr_t)arg;
    volatile uint32_t local[8];
    for (unsigned j = 0; j < 8; ++j) local[j] = 0x1000u * (id + 1) + j;
    task_local_address[id] = (uintptr_t)local;
    if (starvation && id == 0) {
        kprintf("D13 NO-YIELD A running; B=0 (cooperative only)\n");
        task_starving();
        for (;;) ++task_counts[0];
    }
    if (id == 1) __asm__ volatile("sti" ::: "memory"); /* PIC remains fully masked. */
    for (unsigned i = 0; i < 128; ++i) {
        KASSERT(task_counts[id] == i);
        KASSERT(task_counts[1 - id] == i + id);
        ++task_counts[id];
        task_sample();
        KASSERT(task_register_probe(id + 1));
        uint32_t observed = irq_save();
        KASSERT(!!(observed & 0x200) == id);
        irq_restore(observed);
        for (unsigned j = 0; j < 8; ++j)
            KASSERT(local[j] == 0x1000u * (id + 1) + j);
    }
}
void task_demo(unsigned starve)
{
    uint32_t flags = irq_save();
    starvation = starve;
    task_initial_pages = page_free_count();
    tasks[0].state = RUNNING;
    KASSERT(task_create(counter, (void *)0));
    KASSERT(task_create(counter, (void *)1));
    KASSERT(!task_create(counter, 0));
    KASSERT(page_free_count() == task_initial_pages - 2);
    while (tasks[1].state != DEAD || tasks[2].state != DEAD) task_yield();
    for (unsigned i = 1; i < SLOTS; ++i) {
        uint32_t page = tasks[i].kernel_stack;
        KASSERT(*(uint32_t *)page == CANARY);
        unsigned untouched = 4;
        while (untouched < PAGE_BYTES && *(uint8_t *)(page + untouched) == 0xa5) ++untouched;
        task_stack_used[i - 1] = PAGE_BYTES - untouched;
        KASSERT(task_stack_used[i - 1] < PAGE_BYTES - 256);
        KASSERT(page_free(page));
        tasks[i].kernel_stack = 0;
        ++task_reaped;
    }
    KASSERT(task_counts[0] == 128 && task_counts[1] == 128);
    KASSERT(page_free_count() == task_initial_pages);
    /* Exercise an IF=1 continuation with PIC masks still 0xff, no live IRQs. */
    __asm__ volatile("sti" ::: "memory");
    task_yield();
    uint32_t restored = irq_save();
    KASSERT(restored & 0x200);
    task_yield();
    restored = irq_save();
    KASSERT(!(restored & 0x200));
    task_passed = 1;
    kprintf("D13 TASKS A=%u B=%u switches=%u reaped=%u\n", task_counts[0], task_counts[1], task_switches, task_reaped);
    kprintf("D13 stack used A=%u B=%u of 4096; locals/registers OK\n", task_stack_used[0], task_stack_used[1]);
    kprintf("TASKS OK pages recovered; IF=0/1 preserved\n");
    task_demo_done();
    irq_restore(flags);
}

/* No nested IRQ enable in handlers; depth is nevertheless owned by each task. */
void task_trap_enter(void) { ++tasks[current].trap_depth; }
static void wait_tick(void);
void task_tick(void)
{
    if (preempt_active) need_resched = 1;
    if (idle_active) wait_tick();
}
static void preempt_pending(void)
{
    if (!preempt_active || !need_resched || tasks[current].trap_depth) return;
    if (tasks[current].preempt_count) { ++preempt_deferred; return; }
    tasks[current].state = RUNNABLE;
    schedule_locked();
}
void task_trap_leave(unsigned interrupted_if)
{
    KASSERT(tasks[current].trap_depth);
    --tasks[current].trap_depth;
    if (!tasks[current].trap_depth && tasks[current].user_stop) task_exit();
    if (interrupted_if) preempt_pending();
}
void preempt_disable(void)
{
    uint32_t flags = irq_save();
    ++tasks[current].preempt_count;
    irq_restore(flags);
}
void preempt_enable(void)
{
    uint32_t flags = irq_save();
    KASSERT(tasks[current].preempt_count);
    --tasks[current].preempt_count;
    /* Original IF=0 belongs to the caller: defer until a later safe IRQ exit. */
    if (flags & 0x200) preempt_pending();
    irq_restore(flags);
}

volatile uint32_t preempt_counts[2], preempt_probe_passes, preempt_stack_used[2];
volatile uint32_t preempt_passed, preempt_initial_pages, preempt_reaped;
volatile uint32_t preempt_critical_ticks, preempt_nested_ok, preempt_if0_ok, preempt_enable_ok;
volatile unsigned preempt_cli_release = 1, preempt_work_release = 1;
volatile uint32_t preempt_cli_ticks, preempt_cli_switches;
volatile unsigned preempt_mask_requested, preempt_mask_actual;
static unsigned preempt_diagnostic;
extern void preempt_register_probe(unsigned seed);
void preempt_progress_sample(void) { __asm__ volatile("" ::: "memory"); }
void preempt_cli_sample(void) { __asm__ volatile("" ::: "memory"); }
void preempt_mask_sample(void) { __asm__ volatile("" ::: "memory"); }
void preempt_demo_done(void) { __asm__ volatile("" ::: "memory"); }
void preempt_probe_check(const uint32_t *r)
{
    uint32_t flags = irq_save();
    /* PUSHAD: EDI ESI EBP ESP EBX EDX ECX EAX, then PUSHFD. */
    KASSERT(r[0] == 0x77777777u + current && r[1] == 0x66666666u + current);
    KASSERT(r[2] == 0x55555555u + current && r[4] == 0x44444444u + current);
    KASSERT(r[5] == 0x33333333u + current && r[6] == 0x22222222u + current && r[7] == 0x11111111u + current);
    KASSERT((r[8] & 0xed5) == 0x645 && (r[8] & 0x200));
    ++preempt_probe_passes;
    irq_restore(flags);
}
static void busy_counter(void *arg)
{
    unsigned id = (uintptr_t)arg;
    if (preempt_diagnostic && id == 0) {
        uint32_t flags = irq_save();
        timer_mask(1);
        preempt_mask_requested = preempt_mask_actual = 1;
        kprintf("D14 IRQ0 masked: A busy, B stalled; GDB releases mask\n");
        preempt_mask_sample();
        irq_restore(flags);
        while (preempt_mask_requested) ++preempt_counts[id];
        timer_mask(0);
        preempt_mask_actual = 0;
    }
    /* Independent CPU work. No yield/HLT/calls inside this progress loop. */
    while (!preempt_work_release || preempt_counts[0] < 200000 || preempt_counts[1] < 200000)
        ++preempt_counts[id];
    for (unsigned n = 0; n < 4; ++n) {
        uint32_t switches = preempt_switches;
        preempt_register_probe(id + 1);
        KASSERT(preempt_switches > switches);
    }
}
void preempt_demo(unsigned diagnostic)
{
    uint32_t original = irq_save();
    preempt_diagnostic = diagnostic;
    preempt_initial_pages = page_free_count();
    KASSERT(task_create(busy_counter, (void *)0));
    KASSERT(task_create(busy_counter, (void *)1));
    preempt_active = 1;
    timer_start();
    preempt_disable();
    preempt_disable();
    __asm__ volatile("sti" ::: "memory");
    uint32_t start = timer_ticks;
    while (timer_ticks - start < 3) __asm__ volatile("" ::: "memory");
    KASSERT(preempt_switches == 0 && need_resched);
    preempt_critical_ticks = timer_ticks - start;
    preempt_enable();
    KASSERT(preempt_switches == 0 && tasks[0].preempt_count == 1);
    preempt_nested_ok = 1;
    preempt_enable();
    KASSERT(preempt_switches > 0);
    preempt_enable_ok = 1;
    preempt_disable();
    start = timer_ticks;
    while (timer_ticks - start < 2) __asm__ volatile("" ::: "memory");
    uint32_t enabled = irq_save();
    uint32_t held_switches = preempt_switches;
    preempt_enable();
    KASSERT(preempt_switches == held_switches && need_resched);
    uint32_t observed = irq_save();
    KASSERT(!(observed & 0x200));
    preempt_if0_ok = 1;
    preempt_cli_ticks = timer_ticks;
    preempt_cli_switches = preempt_switches;
    preempt_cli_sample();
    while (!preempt_cli_release) __asm__ volatile("" ::: "memory");
    /* Bounded real CLI window, separate from the IRQ-enabled deferred test. */
    for (volatile unsigned n = 0; n < 2000000; ++n) { }
    KASSERT(timer_ticks == preempt_cli_ticks && preempt_switches == preempt_cli_switches);
    irq_restore(enabled);
    preempt_progress_sample();
    while (tasks[1].state != DEAD || tasks[2].state != DEAD)
        __asm__ volatile("hlt" ::: "memory");
    (void)irq_save();
    timer_mask(1);
    preempt_active = 0;
    need_resched = 0;
    for (unsigned i = 1; i < SLOTS; ++i) {
        uint32_t page = tasks[i].kernel_stack;
        KASSERT(*(uint32_t *)page == CANARY);
        KASSERT(tasks[i].trap_depth == 0 && tasks[i].preempt_count == 0);
        unsigned untouched = 4;
        while (untouched < PAGE_BYTES && *(uint8_t *)(page + untouched) == 0xa5) ++untouched;
        preempt_stack_used[i - 1] = PAGE_BYTES - untouched;
        KASSERT(preempt_stack_used[i - 1] < PAGE_BYTES - 256);
        KASSERT(page_free(page));
        tasks[i].kernel_stack = 0;
        ++preempt_reaped;
    }
    KASSERT(preempt_counts[0] >= 200000 && preempt_counts[1] >= 200000);
    KASSERT(preempt_probe_passes == 8 && preempt_deferred >= 3);
    KASSERT(page_free_count() == preempt_initial_pages);
    preempt_passed = 1;
    kprintf("D14 PREEMPT A=%u B=%u switches=%u\n", preempt_counts[0], preempt_counts[1], preempt_switches);
    kprintf("D14 seven-GPR/flags/DF probes=%u; deferred ticks=%u\n", preempt_probe_passes, preempt_critical_ticks);
    kprintf("D14 nested/IF0/CLI OK; stacks=%u,%u reaped=%u\n", preempt_stack_used[0], preempt_stack_used[1], preempt_reaped);
    kprintf("PREEMPT OK pages recovered; returning to keyboard\n");
    preempt_demo_done();
    irq_restore(original);
}

volatile uint32_t wait_blocks, wait_wakes, wait_idle_halts, wait_sleep_passes;
volatile uint32_t wait_passed, wait_initial_pages, wait_reaped, wait_stack_used[2];
volatile uint32_t wait_produced, wait_consumed, wait_phase, wait_woken[3];
volatile uint32_t wait_pending_seen, wait_lost, wait_rescued, wait_lost_tick;
static struct wait_queue event_waiters;
static volatile unsigned wait_event, wait_armed;
static unsigned wait_broken;

static void require_locked(void)
{
    uint32_t flags;
    __asm__ volatile("pushfl; popl %0" : "=r"(flags));
    KASSERT(!(flags & 0x200));
}
static void block_current(void)
{
    require_locked();
    KASSERT(idle_active && current && tasks[current].state == RUNNING);
    KASSERT(!tasks[current].trap_depth && !tasks[current].preempt_count);
    tasks[current].state = BLOCKED;
    ++wait_blocks;
    schedule_locked();
}
void task_block_locked(struct wait_queue *q)
{
    require_locked();
    struct task *t = &tasks[current];
    KASSERT(q && !t->waiting_on && !t->sleeping && !(q->mask & (1u << current)));
    t->waiting_on = q;
    q->mask |= 1u << current;
    block_current();
    KASSERT(!t->waiting_on && !(q->mask & (1u << current)));
}
int wake_one_locked(struct wait_queue *q)
{
    require_locked();
    for (unsigned i = 1; i < SLOTS; ++i) {
        if (!(q->mask & (1u << i))) continue;
        KASSERT(tasks[i].state == BLOCKED && tasks[i].waiting_on == q);
        q->mask &= ~(1u << i);
        tasks[i].waiting_on = 0;
        tasks[i].state = RUNNABLE;
        need_resched = 1;
        ++wait_wakes;
        return 1;
    }
    return 0;
}
static int tick_reached(uint32_t now, uint32_t deadline)
{
    return (uint32_t)(now - deadline) < 0x80000000u;
}
void sleep_ticks(uint32_t ticks)
{
    KASSERT(ticks <= 0x7fffffffu);
    if (!ticks) return;
    uint32_t flags = irq_save();
    struct task *t = &tasks[current];
    KASSERT(!t->waiting_on && !t->sleeping);
    t->wake_tick = timer_ticks + ticks;
    t->sleeping = 1;
    block_current();
    KASSERT(!t->sleeping && tick_reached(timer_ticks, t->wake_tick));
    irq_restore(flags);
}
void wait_lost_observed(void) { __asm__ volatile("" ::: "memory"); }
void wait_pending_observed(void) { __asm__ volatile("" ::: "memory"); }
void wait_idle_observed(void) { __asm__ volatile("" ::: "memory"); }
void wait_demo_done(void) { __asm__ volatile("" ::: "memory"); }
static void wait_tick(void)
{
    for (unsigned i = 1; i < SLOTS; ++i) {
        struct task *t = &tasks[i];
        if (t->state != BLOCKED || !t->sleeping || !tick_reached(timer_ticks, t->wake_tick)) continue;
        t->sleeping = 0;
        t->state = RUNNABLE;
    }
    if (wait_armed) {
        wait_armed = 0;
        wait_event = 1;
        ++wait_produced;
        wait_woken[wait_phase] = wake_one_locked(&event_waiters);
    }
    if (wait_broken && wait_phase == 1 && wait_event && tasks[1].state == BLOCKED) {
        KASSERT(event_waiters.mask == 2 && wait_woken[1] == 0);
        if (!wait_lost) {
            wait_lost = 1;
            wait_lost_tick = timer_ticks;
            wait_lost_observed();
        }
        if (timer_ticks - wait_lost_tick >= 3) {
            KASSERT(wake_one_locked(&event_waiters));
            ++wait_rescued;
        }
    }
}
static void event_consumer(void *arg)
{
    (void)arg;
    for (wait_phase = 0; wait_phase < 3; ++wait_phase) {
        uint32_t flags = irq_save();
        wait_event = 0;
        KASSERT(!event_waiters.mask);
        wait_armed = 1;
        if (wait_phase == 0) {
            irq_restore(flags);
            while (!wait_event) __asm__ volatile("hlt" ::: "memory");
            (void)irq_save();
        }
        while (!wait_event) {
            if (wait_phase == 1 && wait_broken) {
                irq_restore(flags);
                while (!wait_event) __asm__ volatile("hlt" ::: "memory");
                (void)irq_save();
            } else if (wait_phase == 1) {
                uint32_t tick = timer_ticks, produced = wait_produced;
                unsigned n;
                for (n = 0; n < 1000000 && !timer_pending(); ++n) { }
                KASSERT(n < 1000000 && timer_ticks == tick && wait_produced == produced);
                wait_pending_seen = 1;
                wait_pending_observed();
            }
            task_block_locked(&event_waiters);
        }
        wait_event = 0;
        ++wait_consumed;
        KASSERT(!event_waiters.mask && !tasks[current].waiting_on);
        KASSERT(!wake_one_locked(&event_waiters));
        irq_restore(flags);
    }
}
static void sleeper(void *arg)
{
    (void)arg;
    sleep_ticks(0);
    for (unsigned n = 0; n < 8; ++n) {
        uint32_t tick = timer_ticks;
        sleep_ticks(3);
        KASSERT(timer_ticks - tick >= 3);
        ++wait_sleep_passes;
    }
}
static void idle_once(void)
{
    (void)irq_save();
    KASSERT(current == 0);
    if (tasks[1].state == RUNNABLE || tasks[2].state == RUNNABLE) task_yield();
    else {
        ++wait_idle_halts;
        wait_idle_observed();
        __asm__ volatile("sti; hlt" ::: "memory");
    }
}
static void keyboard_consumer(void *arg)
{
    (void)arg;
    keyboard_loop();
}
void wait_demo(unsigned broken)
{
    (void)irq_save();
    wait_broken = broken;
    wait_initial_pages = page_free_count();
    KASSERT(tick_reached(0, 0) && tick_reached(1, 0xfffffffeu));
    KASSERT(!tick_reached(0xfffffffeu, 1) && !tick_reached(0, 0x7fffffffu));
    KASSERT(task_create(event_consumer, 0) && task_create(sleeper, 0));
    idle_active = preempt_active = 1;
    timer_start();
    kprintf("D15 WAIT %s: real PIT producer, three event orders\n", broken ? "BROKEN" : "FIXED");
    while (tasks[1].state != DEAD || tasks[2].state != DEAD) idle_once();
    (void)irq_save();
    for (unsigned i = 1; i < SLOTS; ++i) {
        struct task *t = &tasks[i];
        uint32_t page = t->kernel_stack;
        KASSERT(*(uint32_t *)page == CANARY && !t->waiting_on && !t->sleeping);
        KASSERT(!t->trap_depth && !t->preempt_count);
        unsigned untouched = 4;
        while (untouched < PAGE_BYTES && *(uint8_t *)(page + untouched) == 0xa5) ++untouched;
        wait_stack_used[i - 1] = PAGE_BYTES - untouched;
        KASSERT(wait_stack_used[i - 1] < PAGE_BYTES - 256 && page_free(page));
        t->kernel_stack = 0;
        ++wait_reaped;
    }
    KASSERT(wait_produced == 3 && wait_consumed == 3 && !event_waiters.mask);
    KASSERT(wait_woken[0] == 0 && wait_woken[1] == !broken && wait_woken[2] == 1);
    KASSERT(wait_pending_seen == !broken && wait_lost == broken && wait_rescued == broken);
    KASSERT(wait_sleep_passes == 8 && page_free_count() == wait_initial_pages);
    wait_passed = 1;
    kprintf("D15 events produced=%u consumed=%u woken=%u,%u,%u\n", wait_produced, wait_consumed, wait_woken[0], wait_woken[1], wait_woken[2]);
    kprintf("D15 pending=%u lost=%u rescued=%u sleeps=%u idle=%u\n", wait_pending_seen, wait_lost, wait_rescued, wait_sleep_passes, wait_idle_halts);
    kprintf("WAIT OK stacks=%u,%u reaped=%u pages recovered\n", wait_stack_used[0], wait_stack_used[1], wait_reaped);
    wait_demo_done();
    wait_broken = 0;
    idle_active = preempt_active = 0;
    need_resched = 0;
    timer_mask(1);
}
void task_keyboard_start(void)
{
    (void)irq_save();
    idle_active = preempt_active = 1;
    timer_start();
    KASSERT(task_create(keyboard_consumer, 0));
    for (;;) idle_once();
}


volatile uint32_t user_round, user_passed, user_reaped, user_initial_pages;
volatile uint32_t user_rollback_passes, user_irq_frames[2], user_stack_used[2];
volatile uint32_t user_fault_vectors[3], user_fault_errors[3], user_fault_eips[3], user_survivor_growth[3];
extern char user_blob_start, user_write_fault, user_cli_fault, user_out_fault;
volatile uint32_t user_final_counts[2], user_frame_address[2];
volatile uint32_t user_sentinel = 0x51a7cafe;
void user_round_ready(void) { __asm__ volatile("" ::: "memory"); }
void user_fault_observed(void) { __asm__ volatile("" ::: "memory"); }
void user_demo_done(void) { __asm__ volatile("" ::: "memory"); }
static int task_create_user(unsigned mode)
{
    struct user_space space;
    if (!user_space_create(&space, mode, (uint32_t)&user_sentinel)) return 0;
    if (task_create_space(0, 0, &space)) return 1;
    user_space_destroy(&space);
    return 0;
}
int task_user_trap(struct trap_frame *frame, uint32_t address)
{
    struct task *t = &tasks[current];
    KASSERT(current && t->user.pages[0] && (frame->cs & 3) == 3);
    uint32_t cr3;
    __asm__ volatile("mov %%cr3,%0" : "=r"(cr3));
    uint32_t *tail = (uint32_t *)(frame + 1);
    KASSERT(cr3 == t->user.pages[0] && frame->cs == 0x1b && tail[1] == 0x23);
    KASSERT((uint32_t)frame > t->kernel_stack && (uint32_t)(tail + 2) <= t->kernel_stack + PAGE_BYTES);
    user_frame_address[current - 1] = (uint32_t)frame;
    if (frame->vector == 32) {
        ++user_irq_frames[current - 1];
        uint32_t *data = (uint32_t *)t->user.pages[4];
        if (data[1] < 10) data[5] = 1; /* Day 16's pre-fault IRQ marker. */
    }
    if (frame->vector != 13 && frame->vector != 14) return 0;
    t->user_fault = frame->vector;
    t->user_error = frame->error;
    t->user_eip = frame->eip;
    t->user_address = address;
    t->user_stop = 1; /* Retire only after the common tail decrements trap_depth. */
    return 1;
}
void user_demo(void)
{
    (void)irq_save();
    user_init();
    user_initial_pages = page_free_count();
    for (user_fail_after = 0; user_fail_after < 7; ++user_fail_after) {
        KASSERT(!task_create_user(0));
        KASSERT(page_free_count() == user_initial_pages);
        KASSERT(tasks[1].state == DEAD && !tasks[1].kernel_stack && !tasks[1].user.pages[0]);
        ++user_rollback_passes;
    }
    for (user_round = 0; user_round < 3; ++user_round) {
        KASSERT(task_create_user(0) && task_create_user(user_round + 1));
        KASSERT(page_free_count() == user_initial_pages - 14);
        volatile uint32_t *a = (uint32_t *)tasks[1].user.pages[4];
        volatile uint32_t *b = (uint32_t *)tasks[2].user.pages[4];
        preempt_active = 1;
        timer_start();
        kprintf("D16 ring3 round=%u private VA=40001000 bad=%u\n", user_round, user_round + 1);
        user_round_ready();
        __asm__ volatile("sti" ::: "memory");
        while (tasks[2].state != DEAD || !a[2]) __asm__ volatile("hlt" ::: "memory");
        (void)irq_save();
        KASSERT(tasks[2].user_fault == (user_round == 0 ? 14u : 13u));
        KASSERT(tasks[2].user_error == (user_round == 0 ? 7u : 0u));
        if (!user_round) KASSERT(tasks[2].user_address == (uint32_t)&user_sentinel);
        KASSERT(user_sentinel == 0x51a7cafe && a[2] && b[2]);
        user_fault_vectors[user_round] = tasks[2].user_fault;
        user_fault_errors[user_round] = tasks[2].user_error;
        user_fault_eips[user_round] = tasks[2].user_eip;
        uintptr_t instruction = (uintptr_t)(user_round == 0 ? &user_write_fault : user_round == 1 ? &user_cli_fault : &user_out_fault);
        KASSERT(tasks[2].user_eip == USER_CODE + instruction - (uintptr_t)&user_blob_start);
        user_fault_observed();
        uint32_t before = a[0], tick = timer_ticks;
        __asm__ volatile("sti" ::: "memory");
        while (timer_ticks - tick < 4) __asm__ volatile("hlt" ::: "memory");
        (void)irq_save();
        KASSERT(a[0] > before);
        user_survivor_growth[user_round] = a[0] - before;
        tasks[1].user_stop = 1; /* No exit syscall: supervisor ends the finite lab. */
        __asm__ volatile("sti" ::: "memory");
        while (tasks[1].state != DEAD) __asm__ volatile("hlt" ::: "memory");
        (void)irq_save();
        timer_mask(1);
        preempt_active = need_resched = 0;
        KASSERT(user_irq_frames[0] && user_irq_frames[1]);
        for (unsigned i = 1; i < SLOTS; ++i) {
            struct task *t = &tasks[i];
            user_final_counts[i - 1] = *(uint32_t *)t->user.pages[4];
            KASSERT(!t->trap_depth && !t->preempt_count && *(uint32_t *)t->kernel_stack == CANARY);
            unsigned untouched = 4;
            while (untouched < PAGE_BYTES && *(uint8_t *)(t->kernel_stack + untouched) == 0xa5) ++untouched;
            user_stack_used[i - 1] = PAGE_BYTES - untouched;
            KASSERT(user_stack_used[i - 1] < PAGE_BYTES - 256);
            user_space_destroy(&t->user);
            KASSERT(page_free(t->kernel_stack));
            t->kernel_stack = 0;
            ++user_reaped;
        }
        KASSERT(page_free_count() == user_initial_pages);
        kprintf("D16 fault=%u error=%u eip=%x survivor+=%u\n", user_fault_vectors[user_round], user_fault_errors[user_round], user_fault_eips[user_round], user_survivor_growth[user_round]);
    }
    user_passed = 1;
    kprintf("USER OK ring3 CR3/TSS; rollback=%u reaped=%u pages=%u\n", user_rollback_passes, user_reaped, page_free_count());
    user_demo_done();
}

volatile uint32_t syscall_passed, syscall_initial_pages, syscall_reaped;
volatile uint32_t syscall_stack_used[2];
volatile uint32_t syscall_results[13];
volatile uint32_t syscall_copy_checks;
volatile uint32_t syscall_bad_gate_vector, syscall_bad_gate_error, syscall_bad_gate_eip;
volatile uint32_t syscall_bad_gate_survivor_growth;
extern volatile unsigned syscall_wait_for_irq;
extern char user_blob_start, user_bad_gate_fault;
__attribute__((noinline)) void syscall_demo_done(void)
{ __asm__ volatile("" ::: "memory"); }

__attribute__((optimize("Os"))) static void syscall_prepare_space(struct user_space *space)
{
    uint32_t *pt = (uint32_t *)space->pages[1];
    pt[3] = space->pages[5] | 3; /* Present supervisor alias: must be rejected. */
    pt[4] = space->pages[3] | 5;
    pt[5] = space->pages[5] | 7; /* Two user aliases make a legal cross-page source. */
    char *data = (char *)space->pages[4];
    memcpy(data + 256, "D17 WRITE % NO-NUL\n", 19);
    memcpy(data + PAGE_BYTES - 8, "LEAKFAIL", 8);
    memcpy((void *)(space->pages[3] + PAGE_BYTES - 8), "D17 CROS", 8);
    memcpy((void *)space->pages[5], "S-PAGE\n", 7);
}

__attribute__((optimize("Os"))) static void syscall_copy_probe(struct user_space *space)
{
    static const char source[16] = "COPY-TO-USER-OK";
    static const char guard[8] = "GUARD123";
    uint32_t *pt = (uint32_t *)space->pages[1];
    uint32_t kernel_cr3;
    __asm__ volatile("mov %%cr3,%0" : "=r"(kernel_cr3));
    pt[2] = space->pages[5] | 7;
    __asm__ volatile("mov %0,%%cr3" : : "r"(space->pages[0]) : "memory");
    KASSERT(copy_to_user(0x40001ff8u, source, sizeof(source)));
    KASSERT(!memcmp((void *)(space->pages[4] + PAGE_BYTES - 8), source, 8));
    KASSERT(!memcmp((void *)space->pages[5], source + 8, 8));
    ++syscall_copy_checks;

    memcpy((void *)(space->pages[4] + PAGE_BYTES - 8), guard, sizeof(guard));
    pt[2] = space->pages[5] | 5;
    KASSERT(!copy_to_user(0x40001ff8u, source, sizeof(source)));
    KASSERT(!memcmp((void *)(space->pages[4] + PAGE_BYTES - 8), guard,
                    sizeof(guard)));
    ++syscall_copy_checks;

    uint32_t saved_pde = ((uint32_t *)space->pages[0])[USER_CODE >> 22];
    ((uint32_t *)space->pages[0])[USER_CODE >> 22] = saved_pde & ~2u;
    KASSERT(!copy_to_user(USER_DATA, source, 1));
    ((uint32_t *)space->pages[0])[USER_CODE >> 22] = saved_pde;
    KASSERT(copy_to_user(0xffffffffu, source, 0));
    syscall_copy_checks += 2;
    __asm__ volatile("mov %0,%%cr3" : : "r"(kernel_cr3) : "memory");
    pt[2] = 0;
}

__attribute__((optimize("Os"))) static void syscall_reap_tasks(void)
{
    for (unsigned i = 1; i < SLOTS; ++i) {
        struct task *t = &tasks[i];
        KASSERT(!t->trap_depth && !t->preempt_count && *(uint32_t *)t->kernel_stack == CANARY);
        unsigned untouched = 4;
        while (untouched < PAGE_BYTES && *(uint8_t *)(t->kernel_stack + untouched) == 0xa5) ++untouched;
        syscall_stack_used[i - 1] = PAGE_BYTES - untouched;
        KASSERT(syscall_stack_used[i - 1] < PAGE_BYTES - 256);
        user_space_destroy(&t->user);
        KASSERT(page_free(t->kernel_stack));
        t->kernel_stack = 0;
        ++syscall_reaped;
    }
}

__attribute__((optimize("Os"))) void syscall_demo(void)
{
    (void)irq_save();
    syscall_initial_pages = page_free_count();
    struct user_space tester, counter_space;
    KASSERT(user_space_create(&tester, 10, 0));
    syscall_copy_probe(&tester);
    syscall_prepare_space(&tester);
    KASSERT(user_range_ok(tester.pages[0], USER_CODE, 1, 0));
    KASSERT(!user_range_ok(tester.pages[0], USER_CODE, 1, 1));
    uint32_t *pd = (uint32_t *)tester.pages[0];
    uint32_t saved_pde = pd[USER_CODE >> 22];
    pd[USER_CODE >> 22] = saved_pde & ~4u;
    KASSERT(!user_range_ok(tester.pages[0], USER_CODE, 1, 0));
    pd[USER_CODE >> 22] = saved_pde & ~2u;
    KASSERT(user_range_ok(tester.pages[0], USER_CODE, 1, 0));
    KASSERT(!user_range_ok(tester.pages[0], USER_DATA, 1, 1));
    pd[USER_CODE >> 22] = saved_pde;
    KASSERT(user_range_ok(tester.pages[0], 0x40004ff8u, 15, 0));
    KASSERT(!user_range_ok(tester.pages[0], 0x40001ff8u, 16, 0));
    KASSERT(!user_range_ok(tester.pages[0], 0x40003000u, 4, 0));
    KASSERT(!user_range_ok(tester.pages[0], 0xfffffff0u, 32, 0));
    KASSERT(user_space_create(&counter_space, 11, 0));
    KASSERT(task_create_space(0, 0, &tester));
    KASSERT(task_create_space(0, 0, &counter_space));
    KASSERT(page_free_count() == syscall_initial_pages - 14);
    syscall_wait_for_irq = 1;
    syscall_yield_probe_active = 1;
    preempt_active = 1;
    timer_start();
    kprintf("D17 int80 write/yield and user-copy checks=%u\n",
            syscall_copy_checks);
    __asm__ volatile("sti" ::: "memory");
    volatile uint32_t *results = (uint32_t *)tasks[1].user.pages[4];
    while (!results[2]) __asm__ volatile("hlt" ::: "memory");
    (void)irq_save();
    kprintf("D17 returns write=%x yield=%x unknown=%x zero=%x long=%x low=%x wrap=%x upper=%x missing=%x supervisor=%x ro=%x cross=%x regs=%x\n",
            results[8], results[9], results[10], results[11], results[12], results[13],
            results[14], results[15], results[16], results[17], results[18], results[19],
            results[20]);
    KASSERT(results[8] == 19 && results[9] == 0);
    KASSERT(results[10] == (uint32_t)-38 && results[11] == 0);
    KASSERT(results[12] == (uint32_t)-22);
    KASSERT(results[13] == (uint32_t)-14 && results[14] == (uint32_t)-14);
    KASSERT(results[15] == (uint32_t)-14 && results[16] == (uint32_t)-14);
    KASSERT(results[17] == (uint32_t)-14 && results[18] == 16);
    KASSERT(results[19] == 15 && results[20] == 1);
    for (unsigned i = 0; i < 13; ++i) syscall_results[i] = results[i + 8];
    KASSERT(syscall_count == 12 && syscall_write_count == 3);
    KASSERT(syscall_yield_count == 1 && syscall_error_count == 7);
    KASSERT(syscall_irq_ticks && syscall_yield_switched);
    KASSERT(syscall_yield_after != syscall_yield_before);
    syscall_yield_probe_active = 0;
    tasks[1].user_stop = tasks[2].user_stop = 1;
    __asm__ volatile("sti" ::: "memory");
    while (tasks[1].state != DEAD || tasks[2].state != DEAD)
        __asm__ volatile("hlt" ::: "memory");
    (void)irq_save();
    timer_mask(1);
    preempt_active = need_resched = 0;
    syscall_reap_tasks();
    KASSERT(page_free_count() == syscall_initial_pages);

    KASSERT(task_create_user(12) && task_create_user(11));
    KASSERT(page_free_count() == syscall_initial_pages - 14);
    preempt_active = 1;
    timer_start();
    __asm__ volatile("sti" ::: "memory");
    while (tasks[1].state != DEAD) __asm__ volatile("hlt" ::: "memory");
    (void)irq_save();
    syscall_bad_gate_vector = tasks[1].user_fault;
    syscall_bad_gate_error = tasks[1].user_error;
    syscall_bad_gate_eip = tasks[1].user_eip;
    KASSERT(syscall_bad_gate_vector == 13 && syscall_bad_gate_error == 0x102);
    KASSERT(syscall_bad_gate_eip == USER_CODE + (uintptr_t)&user_bad_gate_fault -
                                          (uintptr_t)&user_blob_start);
    volatile uint32_t *survivor = (uint32_t *)tasks[2].user.pages[4];
    uint32_t before = survivor[0], tick = timer_ticks;
    __asm__ volatile("sti" ::: "memory");
    while (timer_ticks - tick < 4) __asm__ volatile("hlt" ::: "memory");
    (void)irq_save();
    syscall_bad_gate_survivor_growth = survivor[0] - before;
    KASSERT(syscall_bad_gate_survivor_growth);
    tasks[2].user_stop = 1;
    __asm__ volatile("sti" ::: "memory");
    while (tasks[2].state != DEAD) __asm__ volatile("hlt" ::: "memory");
    (void)irq_save();
    timer_mask(1);
    preempt_active = need_resched = 0;
    syscall_reap_tasks();
    KASSERT(page_free_count() == syscall_initial_pages);
    syscall_passed = 1;
    kprintf("D17 gate DPL #GP error=%x eip=%x survivor+=%u\n",
            syscall_bad_gate_error, syscall_bad_gate_eip,
            syscall_bad_gate_survivor_growth);
    kprintf("SYSCALL OK calls=%u writes=%u errors=%u irq_ticks=%u yield_delta=%u reaped=%u\n",
            syscall_count, syscall_write_count, syscall_error_count,
            syscall_irq_ticks, syscall_yield_after - syscall_yield_before,
            syscall_reaped);
    syscall_demo_done();
}
