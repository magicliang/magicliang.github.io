# 从零编写操作系统：第 04 篇配套实验

本版累计保留第 03 篇 EDD 读盘、载荷头与 checksum 校验，随后收集 E820、建立 BootInfo、实测 A20、加载 flat GDT 并进入 32 位保护模式。32 位汇编从 BootInfo 读取显存地址输出标识；尚未执行 C 或载荷。`sample.elf` 仍是第 01 篇独立链接样例。

## 运行

宿主需要已启动的 Podman Linux 环境。以下命令从本目录执行：

```sh
# 第一次才构建；已有工具链无需重建
podman build -t localhost/build-an-os:day01 .
podman run --rm -it -v "$PWD:/work" -w /work localhost/build-an-os:day01 sh
```

在容器中执行：

```sh
make help
make build
make check
make run
make screenshot
```

`make run` 启动第 04 篇镜像。串口依次输出 `D03 STAGE2 OK`、`D03 PAYLOAD OK`、`D04 E820 OK`、`D04 A20 OK`、`D04 PM OK - BootInfo v1`。设置文本模式 3 会清除此前屏幕，最终 VGA 屏幕保留 PM 标识。`make screenshot` 保存 `build/day04-screen.png`。

`make check-pm` 单独复现保护模式寄存器、BootInfo、A20 开启和故障镜像；`make check` 再运行此前 ELF、读盘和坏头等回归。不要并行运行两个 check，它们使用容器内同一个 GDB 端口。

## 手动调试

仍在同一容器中执行：

```sh
make debug &
gdb-multiarch -q
```

GDB 命令：

```text
set architecture i386
target remote 127.0.0.1:1234
hbreak *0x8e00
continue
info registers eip cr0 cs
si 10
info registers eip cr0 cs ds ss esp
x/10wx 0x5000
monitor quit
quit
```

`monitor quit` 终止 QEMU 后远程连接会关闭。若 `quit` 询问是否退出活动会话，输入 `y`。不要让手动调试实例与 `make check` 同时占用容器的 1234 端口。调试端口不映射到宿主。

## 文件与证据

- `layout.mk`：镜像布局的单一来源；Makefile 从它生成 `build/layout.inc` 给 NASM 使用。
- `boot/`：累计 MBR、stage2 和 `bootinfo.inc`。`mbr.asm` 也可用 `DAY02_ONLY` 构建第 02 篇兼容变体。
- `tools/mkpayload.c`：生成确定性载荷、LBA 9 头部和坏头实验文件；第 03 篇只读取，不执行载荷。
- `sample/`：第 01 篇保留的 C 函数、NASM 汇编入口与链接脚本。
- `tools/check.sh`：ELF 格式、入口、反汇编、缺失符号失败、空盘、MBR 布局、EDD 读取、载荷头、checksum、过大载荷、截短镜像、坏头与坏签名路径检查。
- [环境记录](docs/environment.md)：实测版本、来源和复现边界。
- [实验记录](docs/day01-evidence.md)：实际输出与手动场景。
- [第 02 篇实验记录](docs/day02-evidence.md)：启动扇区、显存与坏签名证据。
- [第 03 篇实验记录](docs/day03-evidence.md)：两阶段 BIOS 读取、布局与故障路径证据。

- [第 04 篇实验记录](docs/day04-evidence.md)：BootInfo 布局、保护模式寄存器、A20、E820 容量和坏 GDT 异常链。

生成文件全部进入忽略的 `build/`。交叉 GCC 当前只构建 C 编译器，不包含目标 libc 或 libgcc；本例不需要这些库，后续内核运行时另行补齐。
