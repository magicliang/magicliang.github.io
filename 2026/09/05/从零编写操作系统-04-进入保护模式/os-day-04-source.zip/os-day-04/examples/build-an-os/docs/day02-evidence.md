# 第 02 篇实验记录：第一个启动扇区

记录时间：2026-09-05

本篇从第 01 篇工具链项目继续，新增 BIOS 可执行的 MBR 启动扇区。默认启动镜像是 `build/mbr.img`；坏签名实验使用 `build/mbr-badsig.img`。仍未实现第二阶段加载器或 C 内核。

## 实验环境

沿用 `docs/environment.md` 中的工具版本：

```text
QEMU emulator version 7.2.22
SeaBIOS 1.16.2
NASM version 2.16.01
i686-elf-gcc 13.2.0
i686-elf-ld 2.42
gdb-multiarch 13.1
```

QEMU 参数仍固定为 `pc-i440fx-7.2`、`qemu32`、单 CPU、64 MiB、TCG、SeaBIOS `bios-256k.bin`。

## 构建产物

```text
build/mbr.bin         512 字节启动扇区
build/mbr.img         1 MiB 可启动磁盘镜像
build/mbr-badsig.img  将 0x55aa 改成 0x0000 的坏签名镜像
```

静态检查：

```text
wc -c build/mbr.bin -> 512
offset 510..511 -> 55 aa
offset 446..509 -> all zero
```

保留 446..509 的 64 字节区域，是为了后续继续把该扇区当作 MBR 使用，不让教学标识或临时变量占用分区表位置。

## 正常启动路径

执行命令：

```sh
podman run --rm -v "$PWD:/work" -w /work/examples/build-an-os localhost/build-an-os:day01 make check
```

GDB 在 MBR 的 `hlt` 指令处停住：

```text
Hardware assisted breakpoint 1 at 0x7c36

Breakpoint 1, 0x00007c36 in ?? ()
MBR_EIP=0x7c36
```

`ndisasm` 对应位置：

```text
00007C00  FA                cli
00007C01  FC                cld
00007C02  31C0              xor ax,ax
00007C04  8ED8              mov ds,ax
00007C06  8EC0              mov es,ax
00007C08  8ED0              mov ss,ax
00007C0A  BC007C            mov sp,0x7c00
00007C0E  8816617C          mov [0x7c61],dl
00007C19  B82007            mov ax,0x720
00007C1C  B9D007            mov cx,0x7d0
00007C1F  F3AB              rep stosw
00007C36  F4                hlt
00007C37  EBFD              jmp short 0x7c36
```

VGA 文本显存 `0xb8000` 的前 24 个字节：

```text
0xb8000: 0x4f 0x0f 0x53 0x0f 0x44 0x0f 0x41 0x0f
0xb8008: 0x59 0x0f 0x30 0x0f 0x32 0x0f 0x20 0x0f
0xb8010: 0x44 0x0f 0x4c 0x0f 0x3d 0x0f 0x38 0x0f
0xb8018: 0x30 0x0f 0x20 0x07 0x20 0x07 0x20 0x07
```

偶数字节解码为 `OSDAY02 DL=80`，奇数字节 `0x0f` 是白字黑底属性。`DL=80` 表示 SeaBIOS 从第一块硬盘启动时传给引导扇区的启动盘编号。

同一次实测还通过 QEMU monitor 保存了屏幕图：

```text
make screenshot
build/day02-screen.png: PNG image data, 720 x 400, 8-bit/color RGB, non-interlaced
```

图中第一行只有 `OSDAY02 DL=80`，其余位置由启动扇区清成空格。

## 坏签名路径

`build/mbr-badsig.img` 只改写最后两个字节：

```sh
printf '\0\0' | dd of=build/mbr-badsig.img bs=1 seek=510 conv=notrunc status=none
```

QEMU 输出：

```text
SeaBIOS (version 1.16.2-debian-1.16.2-1)
Booting from Hard Disk...
Boot failed: not a bootable disk

Booting from Floppy...
Boot failed: could not read the boot disk

Booting from DVD/CD...
Boot failed: Could not read from CDROM (code 0003)
No bootable device.
```

这条失败路径证明 BIOS 检查扇区末尾签名；坏签名时不会把本篇 MBR 当作可启动程序执行。

## 自动检查结果

```text
PASS: ELF32/i386 entry, missing-symbol rejection, blank disk reset, MBR signature/layout, VGA marker and bad signature path
```

第 01 篇的 ELF、缺失符号、空盘复位单步检查仍保留。第 02 篇新增的可观察能力只到启动扇区执行、写显存和停机循环；还没有磁盘分块读取、第二阶段加载器或 C 内核。
