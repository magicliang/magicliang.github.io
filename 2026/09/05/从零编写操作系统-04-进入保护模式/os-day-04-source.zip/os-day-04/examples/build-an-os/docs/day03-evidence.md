# 第 03 篇实验记录：两阶段 BIOS 读取

复核补充：同一版本重新执行 `make -B check` 退出 0。`mbr-corrupt.img` 只将载荷第 100 字节改为 0，保留合法头部及首尾标识；实际输出 `D03 STAGE2 OK`、`D03 HEADER FAIL`，未输出 `D03 PAYLOAD OK`。这验证了内容校验分支，校验和只是检测本实验中的意外损坏，不提供真实性保证。

布局检查同时固定本版支持的 64 KiB 暂存窗口，并要求块长整除窗口的 128 个扇区。多输出载荷生成使用 GNU Make grouped target，避免并行构建同时覆盖同一组产物。

读盘依据：[Phoenix EDD 1.1 原厂文档镜像 §3.1.1–3.2.2](https://wiki.sensi.org/download/doc/ata_edd_11.pdf#page=14)；[SeaBIOS rel-1.16.2 extended_access](https://github.com/coreboot/seabios/blob/rel-1.16.2/src/disk.c#L163-L190)。每次 32 扇区且不跨 64 KiB 物理边界是本系列的保守策略；SeaBIOS 的 [process_op 检查](https://github.com/coreboot/seabios/blob/rel-1.16.2/src/block.c#L626-L637) 仅限制总传输量，不等同于地址跨界检查。

记录时间：2026-09-05

本篇在第 02 篇 MBR 的基础上增加第二阶段加载器。第 03 篇仍停在 16 位实模式：MBR 用 BIOS EDD `int 13h AH=41h` 检查扩展读支持，再用 `AH=42h` 读取 stage2；stage2 再次检查 EDD，读取 LBA 9 的载荷头，校验头部后只按实际 `file_size` 读取 LBA 10 起的载荷到低端内存 `0x10000`。本篇不打开 A20，不进入保护模式，不跳转 `0x100000`，也不执行 kernel。

## 镜像布局

`build/payload-layout.txt` 由 Makefile 生成。本次实测内容：

```text
mbr_lba=0
stage2_lba=1
stage2_sectors=8
header_lba=9
payload_lba=10
payload_bytes=20000
payload_sectors=40
payload_reserved_sectors=128
payload_load=0x10000
fat16_start_lba=2048
read_chunk_sectors=32
```

含义：

- LBA 0 是 MBR，偏移 446..509 的 64 字节保留为全零。
- LBA 1..8 是 4 KiB stage2 保留区。
- LBA 9 是 512 字节载荷头，字段包含 magic、version、file_size、memory_size、entry、checksum 和首尾标识。
- LBA 10 起保留 128 个扇区作为后续 kernel 载荷区；当前确定性载荷为 20000 字节，实际读取 40 个扇区，跨至少两个 32 扇区读块。
- stage2 每次最多读 32 个扇区，目标偏移固定为 0，段地址按块推进；这是系列自己的保守规则，避免单次 BIOS 传输跨物理 64 KiB 边界。
- LBA 2048 记录为后续 FAT16 分区起点；当前没有写入分区表。

## 构建产物

```text
build/day02-mbr.bin       512 字节，第 02 篇兼容 MBR 变体
build/mbr.bin             512 字节，第 03 篇 MBR
build/stage2.bin          4096 字节，16 位第二阶段加载器
build/header.bin          512 字节，载荷头
build/kernel.bin          20000 字节，确定性 kernel 载荷占位数据
build/kernel.pad          65536 字节，写入镜像的载荷保留区
build/mbr.img             2097152 字节，第 03 篇启动镜像
build/mbr-truncated.img   9216 字节，保留头部和 payload 区前 8 个扇区后的故障镜像
build/mbr-badmagic.img    坏 magic 头部故障镜像
build/mbr-oversized-header.img  头部声明 file_size 超上限的故障镜像
```

`make check` 同时检查第 02 篇 MBR 变体仍包含 `OSDAY02 DL=`，第 03 篇 MBR 包含 `OSDAY03 DL=`，两个 MBR 的签名都是 `55 aa`，且 446..509 均为 `00`。

## 正常读取路径

执行：

```sh
podman run --rm -v "$PWD:/work" -w /work/examples/build-an-os localhost/build-an-os:day01 make -B check
```

正常镜像的串口输出记录在 `build/qemu-day03.txt`。串口只作为第 03 篇自动化测试的最小探针，不代表已经进入后续内核运行时：

```text
D03 STAGE2 OK
D03 PAYLOAD OK
```

这说明 BIOS 已经执行 MBR，MBR 成功读入 stage2 并跳转；stage2 校验载荷头后按实际 20000 字节计算出 40 个扇区，分两块读取 payload，并完成首尾标识和 checksum 校验。随后 stage2 在实模式 `hlt` 循环停住。

同一次实测保存了屏幕图：

```text
make screenshot
build/day03-screen.png: PNG image data, 720 x 400, 8-bit/color RGB, non-interlaced
```

VGA 文本屏幕显示 `OSDAY03 DL=80 S1`、`D03 STAGE2 OK`、`D03 PAYLOAD OK` 和 `D03 HALT`。

## 故障路径

过大载荷由宿主构建阶段拒绝。`make check` 运行：

```sh
make -s check-layout PAYLOAD_BYTES=65537
```

该命令退出非 0，输出记录在 `build/oversized-payload.txt`：

```text
payload size 65537 exceeds max 65536
make[1]: *** [Makefile:53: check-layout] Error 1
```

坏 magic 头部由 stage2 在运行期拒绝。实际 QEMU 串口输出记录在 `build/qemu-badmagic.txt`：

```text
D03 STAGE2 OK
D03 HEADER FAIL
```

头部声明 `file_size > 65536` 的镜像也由 stage2 在运行期拒绝。实际 QEMU 串口输出记录在 `build/qemu-oversized-header.txt`：

```text
D03 STAGE2 OK
D03 HEADER FAIL
```

截短镜像保留 MBR、stage2、LBA 9 头部和 payload 区前 8 个扇区，但头部仍声明 20000 字节，即需要读取 40 个扇区。实际 QEMU 串口输出记录在 `build/qemu-truncated.txt`：

```text
D03 STAGE2 OK
D03 READ FAIL
```

这条路径证明读失败来自 stage2 的 BIOS `AH=42h` 载荷读取，不是坏签名、坏头或未进入 stage2。

坏签名路径仍保留为 BIOS 级失败，输出记录在 `build/qemu-badsig.txt`：

```text
Boot failed: not a bootable disk
```

## 自动检查结果

```text
PASS: ELF32/i386 entry, missing-symbol rejection, blank disk reset, MBR signatures/layout, day-02 variant, EDD header/payload reads, runtime header validation, checksum/content checks, oversized/truncated payload failures and bad signature path
```
