#!/bin/sh
set -eu
export LC_ALL=C
mkdir -p build
test "$(i686-elf-gcc -dumpmachine)" = i686-elf
test "$(i686-elf-gcc -dumpfullversion)" = 13.2.0
i686-elf-ld --version | grep -q '2.42'
nasm -v | grep -q '2.16.01'
"$QEMU" --version | grep -q 'version 7.2.22 '
gdb-multiarch --version | grep -q '13.1'
printf '%s  %s\n' 2da2018c7555e50b660a84a273a14a79cb87b9070fe6a90e9f151a53e357f7e6 /usr/share/seabios/bios-256k.bin | sha256sum -c - > build/bios-check.txt
i686-elf-readelf -h build/sample.elf > build/elf-header.txt
i686-elf-objdump -dr -Mintel build/sample.elf > build/disassembly.txt
nasm -v > build/nasm-version.txt
grep -q 'Class:.*ELF32' build/elf-header.txt
grep -q 'Machine:.*Intel 80386' build/elf-header.txt
grep -q 'Entry point address:.*0x100000' build/elf-header.txt
grep -q '<add_one>:' build/disassembly.txt
if i686-elf-ld -T sample/linker.ld build/entry.o -o build/missing.elf > build/missing-symbol.txt 2>&1; then
    echo 'FAIL: missing add_one unexpectedly linked' >&2
    exit 1
fi
grep -q 'undefined reference.*add_one' build/missing-symbol.txt
test "$(wc -c < build/blank.img)" -eq 1048576
test "$(od -An -tx1 -j510 -N2 build/blank.img | tr -d ' \n')" = 0000
test "$(wc -c < build/mbr.bin)" -eq 512
test "$(wc -c < build/day02-mbr.bin)" -eq 512
test "$(wc -c < build/stage2.bin)" -eq 4096
test "$(wc -c < build/kernel.bin)" -le "$PAYLOAD_MAX_BYTES"
test "$(wc -c < build/kernel.bin)" -eq "$PAYLOAD_BYTES"
test "$(wc -c < build/kernel.bin)" -gt 16384
test "$(wc -c < build/header.bin)" -eq 512
test "$(wc -c < build/kernel.pad)" -eq "$PAYLOAD_MAX_BYTES"
test "$(wc -c < build/mbr.img)" -eq 2097152
test "$(wc -c < build/mbr-truncated.img)" -eq 9216
test "$(od -An -tx1 -j510 -N2 build/mbr.bin | tr -d ' \n')" = 55aa
test "$(od -An -tx1 -j510 -N2 build/day02-mbr.bin | tr -d ' \n')" = 55aa
test "$(od -An -v -tx1 -j446 -N64 build/mbr.bin | tr -d ' \n' | tr -d 0)" = ""
test "$(od -An -v -tx1 -j446 -N64 build/day02-mbr.bin | tr -d ' \n' | tr -d 0)" = ""
grep -q 'OSDAY02 DL=' build/day02-mbr.bin
grep -q 'OSDAY03 DL=' build/mbr.bin
grep -q 'stage2_lba=1' build/payload-layout.txt
grep -q 'header_lba=9' build/payload-layout.txt
grep -q 'payload_lba=10' build/payload-layout.txt
grep -q 'payload_sectors=40' build/payload-layout.txt
grep -q 'payload_load=0x10000' build/payload-layout.txt
grep -q 'fat16_start_lba=2048' build/payload-layout.txt
grep -q 'read_chunk_sectors=32' build/payload-layout.txt
if make -s check-layout PAYLOAD_BYTES="$(( PAYLOAD_MAX_BYTES + 1 ))" > build/oversized-payload.txt 2>&1; then
    echo 'FAIL: oversized payload unexpectedly passed' >&2
    exit 1
fi
ndisasm -b 16 -o 0x7c00 build/mbr.bin > build/mbr-disassembly.txt
"$QEMU" $QEMU_BLANK_FLAGS -display none -serial none -monitor none -S -gdb tcp:127.0.0.1:1234 > build/qemu-debug.txt 2>&1 &
qemu_pid=$!
trap 'kill "$qemu_pid" 2>/dev/null || true; wait "$qemu_pid" 2>/dev/null || true' EXIT HUP INT TERM
# GDB retries the connection while QEMU starts; timeout bounds startup failures.
timeout 15 gdb-multiarch -q -nx -batch -ex 'set architecture i386' -ex 'set tcp connect-timeout 5' -ex 'set tcp auto-retry on' -ex 'target remote 127.0.0.1:1234' -ex 'printf "RESET_EIP=%#x\n", $eip' -ex 'x/16bx 0xfffffff0' -ex 'stepi' -ex 'printf "STEP_EIP=%#x\n", $eip' -ex 'disconnect' > build/gdb.txt 2>&1
kill -0 "$qemu_pid"
grep -q 'RESET_EIP=0xfff0' build/gdb.txt
grep -q 'STEP_EIP=' build/gdb.txt
if grep -q 'STEP_EIP=0xfff0' build/gdb.txt; then
    echo 'FAIL: CPU did not advance' >&2
    exit 1
fi
kill "$qemu_pid" 2>/dev/null || true
wait "$qemu_pid" 2>/dev/null || true
trap - EXIT HUP INT TERM
timeout 8 "$QEMU" $QEMU_FLAGS -display none -serial stdio -monitor none > build/qemu-day03.txt 2>&1 || true
grep -q 'D03 STAGE2 OK' build/qemu-day03.txt
grep -q 'D03 PAYLOAD OK' build/qemu-day03.txt
timeout 8 "$QEMU" $QEMU_TRUNCATED_FLAGS -display none -serial stdio -monitor none > build/qemu-truncated.txt 2>&1 || true
grep -q 'D03 STAGE2 OK' build/qemu-truncated.txt
grep -q 'D03 READ FAIL' build/qemu-truncated.txt
timeout 8 "$QEMU" $QEMU_BADMAGIC_FLAGS -display none -serial stdio -monitor none > build/qemu-badmagic.txt 2>&1 || true
grep -q 'D03 STAGE2 OK' build/qemu-badmagic.txt
grep -q 'D03 HEADER FAIL' build/qemu-badmagic.txt
timeout 8 "$QEMU" $QEMU_OVERSIZED_HEADER_FLAGS -display none -serial stdio -monitor none > build/qemu-oversized-header.txt 2>&1 || true
grep -q 'D03 STAGE2 OK' build/qemu-oversized-header.txt
grep -q 'D03 HEADER FAIL' build/qemu-oversized-header.txt
timeout 8 "$QEMU" $QEMU_CORRUPT_FLAGS -display none -serial stdio -monitor none > build/qemu-corrupt.txt 2>&1 || true
grep -q 'D03 STAGE2 OK' build/qemu-corrupt.txt
grep -q 'D03 HEADER FAIL' build/qemu-corrupt.txt
if grep -q 'D03 PAYLOAD OK' build/qemu-corrupt.txt; then
    echo 'FAIL: corrupt payload accepted' >&2
    exit 1
fi
timeout 8 "$QEMU" $QEMU_BADSIG_FLAGS -nographic > build/qemu-badsig.txt 2>&1 || true
grep -q 'Boot failed: not a bootable disk' build/qemu-badsig.txt
printf '%s\n' 'PASS: ELF32/i386 entry, missing-symbol rejection, blank disk reset, MBR signatures/layout, day-02 variant, EDD header/payload reads, runtime header validation, checksum/content checks, oversized/truncated payload failures and bad signature path'
