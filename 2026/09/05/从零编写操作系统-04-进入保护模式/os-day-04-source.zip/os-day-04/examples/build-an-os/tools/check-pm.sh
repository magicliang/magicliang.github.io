#!/bin/sh
set -eu
"$QEMU" $QEMU_COMMON -drive file=build/mbr.img,format=raw,if=ide -display none -serial file:build/pm-serial.txt -monitor none -S -gdb tcp:127.0.0.1:1234 > build/pm-qemu.txt 2>&1 &
qemu_pid=$!
trap 'kill "$qemu_pid" 2>/dev/null || true; wait "$qemu_pid" 2>/dev/null || true' EXIT HUP INT TERM
timeout 20 gdb-multiarch -q -nx -batch -ex 'set architecture i386' -ex 'set tcp connect-timeout 5' -ex 'set tcp auto-retry on' -ex 'target remote 127.0.0.1:1234' -ex 'hbreak *0x8e00' -ex 'continue' -ex 'printf "PM_ENTRY=%#x CR0=%#x CS=%#x\n", $eip, $cr0, $cs' -ex 'si 10' -ex 'printf "PM_READY=%#x CR0=%#x CS=%#x DS=%#x SS=%#x ESP=%#x\n", $eip, $cr0, $cs, $ds, $ss, $esp' -ex 'x/10wx 0x5000' -ex 'x/36wx 0x5100' -ex 'dump binary memory build/bootinfo.bin 0x5000 0x5400' -ex 'disconnect' > build/gdb-pm.txt 2>&1
grep -q 'PM_ENTRY=0x8e00 CR0=0x11 CS=0x8' build/gdb-pm.txt
grep -q 'CR0=0x11 CS=0x8 DS=0x10 SS=0x10 ESP=0x7c00' build/gdb-pm.txt
kill "$qemu_pid" 2>/dev/null || true
wait "$qemu_pid" 2>/dev/null || true
trap - EXIT HUP INT TERM
cat > build/check-bootinfo.gdb <<'GDB'
python
import struct
b = open('build/bootinfo.bin', 'rb').read()
assert struct.unpack_from('<IHHB', b) == (0x31495442, 1, 40, 0x80)
address, count, stride, payload, size, video, cols, rows, pitch, mode, cell = struct.unpack_from('<IHHIIIHHHBB', b, 12)
assert (address, stride, payload, size, video, cols, rows, pitch, mode, cell) == (0x5100, 24, 0x10000, 20000, 0xb8000, 80, 25, 160, 3, 2)
assert 0 < count <= 32
entries = [struct.unpack_from('<QQII', b, 0x100 + 24*i) for i in range(count)]
assert all(length and attributes == 1 for base, length, kind, attributes in entries)
assert any(kind == 1 for base, length, kind, attributes in entries)
print('BootInfo v1:', count, 'E820 entries;', entries)
end
GDB
gdb-multiarch -q -nx -batch -x build/check-bootinfo.gdb
for variant in normal a20off a20fail e820full badgdt; do
    disk=build/mbr.img
    test "$variant" = normal || disk=build/mbr-$variant.img
    result=0
    timeout 4 "$QEMU" $QEMU_COMMON -drive file="$disk",format=raw,if=ide -display none -serial stdio -monitor none -d int,cpu_reset -D "build/$variant-exceptions.txt" > "build/$variant-serial.txt" 2>&1 || result=$?
    if [ "$variant" = badgdt ]; then
        test "$result" -eq 0
    else
        test "$result" -eq 124
    fi
done
grep -q 'D04 PM OK - BootInfo v1' build/normal-serial.txt
grep -q 'D04 PM OK - BootInfo v1' build/a20off-serial.txt
grep -q 'D04 A20 ENABLE' build/a20off-serial.txt
grep -q 'D04 E820 FAIL' build/e820full-serial.txt
! grep -q 'D04 PM OK' build/e820full-serial.txt
grep -q 'D04 A20 FAIL' build/a20fail-serial.txt
! grep -q 'D04 PM OK' build/a20fail-serial.txt
grep -q 'v=0d e=0008' build/badgdt-exceptions.txt
grep -q 'v=08 e=0000' build/badgdt-exceptions.txt
grep -q 'Triple fault' build/badgdt-exceptions.txt
! grep -q 'D04 PM OK' build/badgdt-serial.txt
printf '%s\n' 'PASS: protected-mode registers, BootInfo bytes, E820 map, VGA/serial PM marker, forced A20 failure, bad-GDT #GP(0008) -> #DF -> triple fault'
