#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum {
    SECTOR_SIZE = 512,
    HEADER_SIZE = 512,
};

static uint32_t parse_u32(const char *s, const char *name)
{
    char *end = NULL;
    errno = 0;
    unsigned long value = strtoul(s, &end, 0);
    if (errno != 0 || *s == '\0' || *end != '\0' || value > UINT32_MAX) {
        fprintf(stderr, "invalid %s: %s\n", name, s);
        exit(1);
    }
    return (uint32_t)value;
}

static void put32(uint8_t *p, uint32_t value)
{
    p[0] = (uint8_t)value;
    p[1] = (uint8_t)(value >> 8);
    p[2] = (uint8_t)(value >> 16);
    p[3] = (uint8_t)(value >> 24);
}

static void write_file(const char *path, const uint8_t *data, size_t len)
{
    FILE *f = fopen(path, "wb");
    if (f == NULL) {
        perror(path);
        exit(1);
    }
    if (fwrite(data, 1, len, f) != len) {
        perror(path);
        fclose(f);
        exit(1);
    }
    if (fclose(f) != 0) {
        perror(path);
        exit(1);
    }
}

static uint16_t checksum16(const uint8_t *data, size_t len)
{
    uint32_t sum = 0;
    for (size_t i = 0; i < len; i++) {
        sum += data[i];
    }
    return (uint16_t)sum;
}

int main(int argc, char **argv)
{
    if (argc != 8) {
        fprintf(stderr, "usage: %s payload.bin header.bin bad-magic.bin oversized-header.bin payload-bytes max-bytes magic\n", argv[0]);
        return 1;
    }

    const char *payload_path = argv[1];
    const char *header_path = argv[2];
    const char *bad_magic_path = argv[3];
    const char *oversized_header_path = argv[4];
    uint32_t payload_bytes = parse_u32(argv[5], "payload-bytes");
    uint32_t max_bytes = parse_u32(argv[6], "max-bytes");
    uint32_t magic = parse_u32(argv[7], "magic");

    if (payload_bytes < 64 || payload_bytes > max_bytes) {
        fprintf(stderr, "payload size %u outside 64..%u\n", payload_bytes, max_bytes);
        return 1;
    }

    uint8_t *payload = malloc(payload_bytes);
    if (payload == NULL) {
        perror("malloc");
        return 1;
    }

    for (uint32_t i = 0; i < payload_bytes; i++) {
        payload[i] = (uint8_t)((i * 37u + 11u) & 0xffu);
    }
    memcpy(payload, "D03PAYLOAD-BEGIN", 16);
    memcpy(payload + payload_bytes - 15, "D03PAYLOAD-END!", 15);

    uint8_t header[HEADER_SIZE];
    memset(header, 0, sizeof(header));
    put32(header + 0, magic);
    put32(header + 4, 1);
    put32(header + 8, payload_bytes);
    put32(header + 12, payload_bytes);
    put32(header + 16, 0);
    put32(header + 20, checksum16(payload, payload_bytes));
    memcpy(header + 24, "D03PAYLOAD-BEGIN", 16);
    memcpy(header + 40, "D03PAYLOAD-END!", 15);

    uint8_t bad_magic[HEADER_SIZE];
    memcpy(bad_magic, header, sizeof(bad_magic));
    put32(bad_magic + 0, 0);

    uint8_t oversized[HEADER_SIZE];
    memcpy(oversized, header, sizeof(oversized));
    put32(oversized + 8, max_bytes + 1);
    put32(oversized + 12, max_bytes + 1);

    write_file(payload_path, payload, payload_bytes);
    write_file(header_path, header, sizeof(header));
    write_file(bad_magic_path, bad_magic, sizeof(bad_magic));
    write_file(oversized_header_path, oversized, sizeof(oversized));

    free(payload);
    return 0;
}
