# 第 04 篇：保护模式实测记录

2026-09-05，在既有 `localhost/build-an-os:day01` 中运行。未重建工具链，未执行载荷或 C 内核；`sample.elf` 不在启动路径。平台固定为 QEMU 7.2.22、`pc-i440fx-7.2`、TCG、qemu32、64 MiB、SeaBIOS 1.16.2。以下是真实模拟器运行结果，不代表真机兼容测试。

## 复现

仓库根目录执行：

```sh
podman run --rm -v "$PWD/examples/build-an-os:/work" -w /work localhost/build-an-os:day01 make check screenshot
```

`make check-pm` 运行本篇检查；完整 `make check` 同时执行既有 ELF、空盘复位、MBR 签名、分块读取、checksum、坏头、超大头、截短镜像、坏签名回归。生成输出位于忽略的 `build/`。截图为 `build/day04-screen.png`，显示 `D04 PM OK - BootInfo v1`。Mode 3 设置清屏，因此此前 D03 校验信息保留在串口日志，不在最终 VGA 画面。

## BootInfo v1

`boot/bootinfo.inc` 是生产端、32 位汇编读取端共享的偏移来源。全部小端、紧凑布局，地址均为物理地址，没有依赖 C 编译器对齐。

| 偏移 | 宽度 | 内容与实测值 |
| --- | --- | --- |
| 0 | u32 | magic `0x31495442`，内存字节 `BTI1` |
| 4 / 6 | u16 / u16 | version 1 / size 40 |
| 8 | u8 | BIOS 启动盘 `0x80`；9..11 为零 |
| 12 / 16 / 18 | u32 / u16 / u16 | map `0x5100` / count 6 / stride 24 |
| 20 / 24 | u32 / u32 | payload start `0x10000` / 实际文件长度 20000 |
| 28 | u32 | 文本显存 `0xb8000` |
| 32 / 34 / 36 | u16 / u16 / u16 | 80 列 / 25 行 / 每行 160 字节 |
| 38 / 39 | u8 / u8 | BIOS mode 3 / 每字符单元 2 字节 |

BootInfo 位于 `[0x5000,0x5028)`；map 容量 32 条，占 `[0x5100,0x5400)`。E820 每项为 u64 base、u64 length、u32 type、u32 attributes。20 字节响应规范化到 24 字节，attributes=1；不把不存在的属性字节当作 BIOS 返回。32 位代码校验 magic/version/size 并从 BootInfo 读取显存地址输出标识。

实际载荷文件区间为 `[0x10000,0x14e20)`；现阶段应继续保留整个 `[0x10000,0x20000)` 暂存区。该长度不是可分配内存承诺；还需排除 BootInfo、map、栈、MBR、stage2、头缓冲、VGA 等自占范围，第 10 篇再实现分配器。栈由 `0x7c00` 向下使用；stage2 位于 `[0x8000,0x9000)`，头缓冲在 `0x9000`。

## 正常路径证据

`build/gdb-pm.txt`：

```text
PM_ENTRY=0x8e00 CR0=0x11 CS=0x8
PM_READY=0x8e1f CR0=0x11 CS=0x8 DS=0x10 SS=0x10 ESP=0x7c00
0x5000: 0x31495442 0x00280001 0x00000080 0x00005100
0x5010: 0x00180006 0x00010000 0x00004e20 0x000b8000
0x5020: 0x00190050 0x020300a0
```

`CR0 & 1 = 1`，入口 CS 已装载 0x08。再单步十条指令后数据段和栈段为 0x10，平坦段下线性地址等于 EIP。GDB dump 实际内存，脚本读取 `bootinfo.bin` 逐字段断言，得到六项：

```text
(base, length, type, attributes)
(0,          654336,   1, 1)
(654336,     1024,     2, 1)
(983040,     65536,    2, 1)
(1048576,    65929216, 1, 1)
(66977792,   131072,   2, 1)
(4294705152, 262144,   2, 1)
```

`build/normal-serial.txt`：

```text
D03 STAGE2 OK
D03 PAYLOAD OK
D04 E820 OK
D04 A20 OK
D04 PM OK - BootInfo v1
```

## 故障与恢复边界

每个变体只替换独立副本的 stage2；正常镜像不被修改。

| 镜像 | 注入 | 实测结果 |
| --- | --- | --- |
| `mbr-a20off.img` | 检测前清除端口 92 bit1 | `D04 A20 ENABLE` 后重新实测成功，输出 PM OK |
| `mbr-a20fail.img` | 地址别名检测返回值强制为失败 | 尝试端口 92 后再次失败，输出 `D04 A20 FAIL` 并 halt；无 PM OK |
| `mbr-e820full.img` | 将 map 容量限制为 1 | 下次 BIOS 调用前发现容量已满，输出 `D04 E820 FAIL`；无 PM OK |
| `mbr-badgdt.img` | GDTR limit=7，排除 selector 0x08 | 远跳转产生 `#GP(0x0008)`，异常递送失败升级为 `#DF`，随后 triple fault；QEMU 因 `-no-reboot` 退出 |

`build/badgdt-exceptions.txt` 关键原始行：

```text
0: v=0d e=0008 i=0 cpl=0 IP=0000:00008068 pc=00008068
check_exception old: 0xd new 0xd
1: v=08 e=0000 i=0 cpl=0 IP=0000:00008068 pc=00008068
check_exception old: 0x8 new 0xd
Triple fault
```

这里没有有效保护模式 IDT，不能恢复异常；不能称为“捕获并处理了 #GP”。CLI 只屏蔽可屏蔽中断，未解决 NMI/异常问题。当前平台未注入 NMI；后续需建立 IDT 和中断机制再开放中断。

E820 路径检查 CF、SMAP、长度、EBX 续传、零长度、容量及 128 次调用上限。最后一次成功响应 EBX=0 的条目先保留再结束；CF 结束只在已有有效项时接受。24 字节响应属性被保留，不按 bit0 过滤；本次 SeaBIOS 是20字节返回路径，24字节、畸形签名和反复续传上限仅有静态分支审查，尚未注入验证。A20 回退仅支持本平台端口92，尚未实现8042或BIOS兼容回退。
