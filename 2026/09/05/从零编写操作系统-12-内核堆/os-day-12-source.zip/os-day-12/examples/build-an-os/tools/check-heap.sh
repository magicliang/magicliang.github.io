#!/bin/sh
set -eu
for variant in normal heapfault; do
    elf=build/kernel.elf disk=build/mbr.img
    if [ "$variant" = heapfault ]; then elf=build/kernel-heapfault.elf; disk=build/mbr-heapfault.img; fi
    "$QEMU" $QEMU_COMMON -drive file="$disk",format=raw,if=ide -display none -serial file:build/heap-$variant-serial.txt -monitor none -S -gdb tcp:127.0.0.1:1234 > build/heap-$variant-qemu.txt 2>&1 &
    pid=$!
    trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
    cat > build/heap.gdb <<GDB
set architecture i386
set tcp connect-timeout 5
set tcp auto-retry on
file $elf
target remote 127.0.0.1:1234
hbreak heap_demo_done
continue
python
import gdb, struct
from pathlib import Path
m = gdb.selected_inferior()
v = lambda e: int(gdb.parse_and_eval(e))
u32 = lambda a: struct.unpack('<I', bytes(m.read_memory(a,4)))[0]
assert v('heap_passed') == 1 and v('heap_allocations') == 512 and v('heap_rejections') == 6
assert v('paging_passed') == 1 and v('paging_faults') == 2
assert v('\$cr0') & 0x80010001 == 0x80010001
assert v('\$cr3') == v('directory')
assert v('free_pages') == v('paging_initial_pages') - 18
assert all(v('arenas[%d]' % i) == 0 for i in range(4))
allocated = bytes(m.read_memory(v('&allocated'),2048))
assert sum(b.bit_count() for b in allocated) == 18
for d in list(range(16)) + [256]:
    address = u32(v('directory') + d*4) & 0xfffff000
    n = address//4096
    assert allocated[n//8] & (1 << (n%8))
n = v('directory')//4096
assert allocated[n//8] & (1 << (n%8))
text = Path('build/heap-$variant-serial.txt').read_text()
for marker in ['physical-page failure unchanged; recovery OK', 'sizes/patterns first-fit split/coalesce OK', 'overflow/invalid/double/tail/metadata reject OK', 'IF=0/1 preserved; exhausted=512 recovered=4 pages', 'HEAP OK retained paging tables=18']:
    assert marker in text
print('PASS: heap 16-byte alignment, sizes/patterns, exact split/no-split, both coalesce orders, first-fit')
print('PASS: overflow/invalid/double/immediate-tail/metadata rejection without mutation; IF=0/1 preserved')
print('PASS: 512 allocations exhausted, four 4076-byte allocations recovered, all arenas returned; 18 live paging tables')
end
delete breakpoints
GDB
    if [ "$variant" = normal ]; then
        cat >> build/heap.gdb <<'GDB'
monitor screendump build/day12-screen.png -f png
hbreak keyboard_ready
continue
printf "PASS: heap kernel reaches keyboard_ready\n"
GDB
    else
        cat >> build/heap.gdb <<'GDB'
hbreak *panic_halt
continue
python
assert bytes(m.read_memory(v('$eip'),1)) == b'\xf4'
assert v('heap_rejections') == 7
assert 'D12 TAIL DAMAGE rejected unchanged' in Path('build/heap-heapfault-serial.txt').read_text()
assert 'heap tail corruption demonstration' in Path('build/heap-heapfault-serial.txt').read_text()
print('PASS: immediate tail damage rejected unchanged, diagnostic panic HLT instruction')
end
monitor screendump build/day12-heapfault.png -f png
GDB
    fi
    printf 'disconnect\n' >> build/heap.gdb
    timeout -k 5 120 gdb-multiarch -q -nx -batch -x build/heap.gdb > build/heap-$variant-gdb.txt 2>&1
    cat build/heap-$variant-gdb.txt
    kill "$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
    trap - EXIT HUP INT TERM
done
{ sleep 5; printf 'info registers\nquit\n'; } | "$QEMU" $QEMU_COMMON -drive file=build/mbr-heapfault.img,format=raw,if=ide -display none -serial file:build/heap-halted-serial.txt -monitor stdio > build/heap-halted-registers.txt 2>&1
grep -q 'HLT=1' build/heap-halted-registers.txt
grep -q 'D12 TAIL DAMAGE rejected unchanged' build/heap-halted-serial.txt
printf 'PASS: tail-corruption diagnostic actual HLT=1\n'
