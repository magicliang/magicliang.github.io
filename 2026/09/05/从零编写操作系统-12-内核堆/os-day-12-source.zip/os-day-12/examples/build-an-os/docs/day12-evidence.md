# 第 12 篇：页支持的内核堆实测

日期：2026-09-05。逻辑前置为第 11 篇冻结源码 `851ec46333fdc377201598bf93a6bb6cdf3d8aec`；本篇实现经历 WIP 保存后继续完成，最终源码 SHA 由文章和附件标识。复用 `localhost/build-an-os:day01`，未安装或重建镜像。目标沿用 QEMU `pc-i440fx-7.2`、TCG、qemu32、单 CPU、64 MiB、SeaBIOS、IDE raw。

## 重跑与产物

在 `examples/build-an-os` 下执行：

```sh
podman run --rm -v "$PWD:/work" -w /work localhost/build-an-os:day01 make check-heap
podman run --rm -v "$PWD:/work" -w /work localhost/build-an-os:day01 make check
podman run --rm -v "$PWD:/work" -w /work localhost/build-an-os:day01 make screenshot
podman run --rm -v "$PWD:/work" -w /work localhost/build-an-os:day01 make help
```

`tools/check-heap.sh` 用 GDB 自带 Python 检查真实客体，不依赖容器内独立 python3。检查共用容器 loopback GDB 1234 端口，Makefile 串行执行。正常、故障镜像分别截图为 `build/day12-screen.png`、`build/day12-heapfault.png`；两张 PNG 已打开检查，前者显示 HEAP OK，后者显示尾字节破坏诊断和 panic。产物位于忽略的 `build/`，没有用绘制图片代替 QEMU 截图。

## 实测结果

正常 `kernel.bin` 为 20980 字节，运行区终点 `__kernel_end=0x10abd0`，距起点 43984 字节；完整运行区仍包含原 16 KiB 栈。文件和内存均低于现有 65536 字节 loader 上限，无需修改装载器或链接边界。串口实际输出：

```text
E820 records=6 free=16085 kernel_end=0x10abd0
PG+WP enabled CR3=0x10b000 same stack=0x10ab70
PAGING OK retained tables=18 free=16067
D12 page-backed heap align=16 arenas=4
physical-page failure unchanged; recovery OK
sizes/patterns first-fit split/coalesce OK
overflow/invalid/double/tail/metadata reject OK
IF=0/1 preserved; exhausted=512 recovered=4 pages
HEAP OK retained paging tables=18
```

`heap_demo_done` 时 GDB 核对 `heap_passed=1`、`heap_allocations=512`、`heap_rejections=6`，四个 arena 地址全部归零。核对 CR0.PE/PG/WP、CR3、剩余页数和 allocated 位图恰有 18 位；逐个确认目录与 17 个页表地址仍在位图内，随后正常继续到 `keyboard_ready`。没有重新初始化分配器或回收活跃页表。

不同尺寸 1、15、16、17、127、511、1023 字节对象均实际写入并逐字节读回；检查 16 字节对齐。4044 字节请求产生 4064 字节块，剩下的恰好 32 字节还能满足 1 字节请求；4060 字节请求则吸收不足最小块的 16 字节余量。释放中间块后 next allocation 返回相同地址；先左后右和先右后左释放都能合并回整页。

0、UINT32_MAX、UINT32_MAX−20、4077 字节请求被拒绝。未知地址、对齐的内部地址、空指针与重复释放被拒绝；17 字节对象直接破坏偏移 17 的首个尾字节，元数据 span 也单独破坏一次。每次失败核对 arena 全字节 FNV 指纹与物理空闲页计数不变；这是辅助测试指纹，不是抗碰撞完整性证明。恢复注入字节后对象能释放，说明故障检查未破坏可恢复状态。`kmalloc` 同样拒绝带损坏 canary 的 arena。

真实物理页失败场景：先保留一个堆对象，再用 `page_alloc()` 取尽所有剩余物理页，临时以各页首字串成回收链。此时新的整页堆请求返回空，既有 arena 不变，也没有登记失败的页；归还该链后空闲计数恢复。堆自身耗尽则分配 512 个最小块，下一次返回空；逆序释放后四个 4076 字节对象都能分配。最后逐页验证只剩一个 4096 字节空闲块并归还所有 arena。

IF=0 与 IF=1 下调用分配及 IF=1 下调用释放，返回后通过 EFLAGS 检查调用者 IF 得到保留。当前测试时 PIC 仍全屏蔽，不将此声明为定时器抢占压力测试；临界区的 CLI 防护适用于当前单 CPU 普通可屏蔽中断。

## 故障镜像

`mbr-heapfault.img` 先完成正常自检，再分配 17 字节、翻转偏移 17 的首个 canary 字节。`kfree` 返回 0 且指纹/页计数不变，演示主动 `KASSERT` 停机。串口实际内容：

```text
D12 TAIL DAMAGE rejected unchanged
PANIC kernel/heap.c:218: !"heap tail corruption demonstration"
```

GDB 检查第 7 次拒绝、panic 指令字节为 HLT；另一次无 GDB 自由运行由 QEMU monitor 检查 `HLT=1`，串口仍含尾破坏标识。故障并非 CPU 自动捕获写越界，而是下一次堆检查发现 canary 改变后显式停机。

## 实现边界

最多四个独立 4 KiB arena，共 16 KiB 物理 backing；每块 16 字节头、4 字节紧邻请求尾的 canary。最大请求 4076 字节，分配不会跨页。隐式块链 first fit 与整堆验证均为有界线性扫描；没有复杂 free-list 索引、通用 VM、自动扩容或 realloc。正常空页保留以供复用，演示的内部 `release()` 只在全部空闲时回收。

物理页通过已建立的低 64 MiB identity 映射访问，不能推断连续返回的页一定相邻。类型化页访问依赖本实验的 i686 GCC freestanding 地址/ABI 契约，不声称严格可移植 ISO C malloc。校验 tag 和 canary 是调试措施；不能检测所有越界或人为伪造，也不能识别同一地址重用后的陈旧指针（ABA）。合并后的重复释放可归类为无效指针。未加入 SMP/NMI 同步，后续任务栈应直接取得独立物理页。

每次分配/释放先整堆验证；其他对象损坏也会使当前操作失败，必须修复诊断注入或停机处理，不能绕过检查继续分配。头部 XOR tag 不是安全校验，不能抵抗蓄意伪造；canary 在后续分配/释放检查时发现变化，不是在越界写发生的瞬间触发 CPU 异常。

## 回归结果

`make check-heap` 和完整 `make check` 均退出 0。完整检查保留 ELF/漏符号、启动扇区/EDD/镜像头/损坏/截短、保护模式/A20/E820、C 入口/BSS、console/panic、CPU 异常、时钟/EOI、键盘、物理页与分页的原有检查脚本和断言，最后加入本篇堆检查；没有删除或放宽历史断言。完整输出保存于 `build/day12-full.log`，本篇定向输出于 `build/day12-target.log`；细节还保留 `heap-{normal,heapfault}-{serial,gdb}.txt` 与 `heap-halted-{serial,registers}.txt`。

`make screenshot` 与 `make help` 也退出 0，分别保存 `build/day12-screenshot.log`、`build/day12-help.log`；help 已列出当前第 12 篇镜像、堆检查和两张截图。`git diff --check` 无错误。
