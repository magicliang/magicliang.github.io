#ifndef HEAP_H
#define HEAP_H
#include <stddef.h>
void *kmalloc(size_t size);
/* Returns 0 for invalid, duplicate or damaged allocations; never changes them. */
int kfree(void *pointer);
void heap_demo(void);
void heap_fault(void);
#endif
