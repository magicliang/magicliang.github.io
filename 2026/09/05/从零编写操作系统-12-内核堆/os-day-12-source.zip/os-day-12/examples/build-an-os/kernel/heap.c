#include "heap.h"
#include "memory.h"
#include "runtime.h"
#include "console.h"

#define ARENAS 4u
#define HEADER 16u
#define MIN_BLOCK 32u
#define CANARY 0xcafebabeu
struct block { uint32_t span, requested, used, tag; };
_Static_assert(sizeof(struct block) == HEADER, "aligned heap header");
/* Independent identity-mapped physical pages; never merge across arenas. */
static uint32_t arenas[ARENAS];
volatile uint32_t heap_passed, heap_allocations, heap_rejections;
static uint32_t irq_save(void)
{
    uint32_t f;
    __asm__ volatile("pushfl; popl %0; cli" : "=r"(f) : : "memory");
    return f;
}
static void irq_restore(uint32_t f)
{ __asm__ volatile("pushl %0; popfl" : : "r"(f) : "memory", "cc"); }
static uint32_t tag(const struct block *b)
{ return 0x48454150u ^ (uintptr_t)b ^ b->span ^ b->requested ^ b->used; }
static void header(struct block *b, uint32_t span, uint32_t n, uint32_t used)
{
    b->span = span; b->requested = n; b->used = used; b->tag = tag(b);
}
static int valid(void)
{
    for (unsigned i = 0; i < ARENAS; ++i) if (arenas[i]) {
        for (unsigned off = 0; off < PAGE_BYTES;) {
            struct block *b = (void *)(uintptr_t)(arenas[i] + off);
            if (b->span < MIN_BLOCK || b->span % 16 || b->span > PAGE_BYTES - off ||
                b->used > 1 || b->tag != tag(b)) return 0;
            if (b->used) {
                uint32_t tail;
                if (!b->requested || b->requested > b->span - HEADER - 4) return 0;
                memcpy(&tail, (char *)b + HEADER + b->requested, 4);
                if (tail != CANARY) return 0;
            } else if (b->requested) return 0;
            off += b->span;
        }
    }
    return 1;
}
void *kmalloc(size_t n)
{
    if (!n || n > SIZE_MAX - HEADER - 4 - 15) return 0;
    uint32_t need = (n + HEADER + 4 + 15) & ~15u;
    if (need > PAGE_BYTES) return 0;
    uint32_t f = irq_save();
    void *answer = 0;
    if (!valid()) goto done;
    for (unsigned i = 0; i < ARENAS; ++i) {
        if (!arenas[i]) {
            uint32_t page = page_alloc();
            if (!page) goto done;
            arenas[i] = page;
            header((void *)(uintptr_t)page, PAGE_BYTES, 0, 0);
        }
        for (unsigned off = 0; off < PAGE_BYTES;) {
            struct block *b = (void *)(uintptr_t)(arenas[i] + off);
            if (!b->used && b->span >= need) {
                uint32_t span = b->span;
                if (span - need >= MIN_BLOCK) {
                    header((void *)((char *)b + need), span - need, 0, 0);
                    span = need;
                }
                header(b, span, n, 1);
                uint32_t tail = CANARY;
                answer = (char *)b + HEADER;
                memcpy((char *)answer + n, &tail, 4);
                goto done;
            }
            off += b->span;
        }
    }
done:
    irq_restore(f);
    return answer;
}
int kfree(void *p)
{
    uint32_t f = irq_save();
    int ok = 0;
    if (!valid()) goto done;
    for (unsigned i = 0; i < ARENAS; ++i) if (arenas[i]) {
        struct block *previous = 0;
        for (unsigned off = 0; off < PAGE_BYTES;) {
            struct block *b = (void *)(uintptr_t)(arenas[i] + off);
            if ((uintptr_t)p == (uintptr_t)b + HEADER) {
                if (!b->used) goto done;
                uint32_t span = b->span;
                if (off + span < PAGE_BYTES) {
                    struct block *next = (void *)((char *)b + span);
                    if (!next->used) span += next->span;
                }
                header(b, span, 0, 0);
                if (previous && !previous->used)
                    header(previous, previous->span + span, 0, 0);
                ok = 1;
                goto done;
            }
            previous = b;
            off += b->span;
        }
    }
done:
    irq_restore(f);
    return ok;
}
static uint32_t fingerprint(void)
{
    uint32_t hash = 2166136261u;
    for (unsigned i = 0; i < ARENAS; ++i) if (arenas[i])
        for (unsigned j = 0; j < PAGE_BYTES; ++j)
            hash = (hash ^ *(uint8_t *)(uintptr_t)(arenas[i] + j)) * 16777619u;
    return hash;
}
static void reject(void *p)
{
    uint32_t before = fingerprint(), pages = page_free_count();
    KASSERT(!kfree(p));
    KASSERT(before == fingerprint() && pages == page_free_count());
    ++heap_rejections;
}
static void release(void)
{
    KASSERT(valid());
    for (unsigned i = 0; i < ARENAS; ++i) if (arenas[i]) {
        struct block *b = (void *)(uintptr_t)arenas[i];
        KASSERT(!b->used && b->span == PAGE_BYTES);
        KASSERT(page_free(arenas[i])); arenas[i] = 0;
    }
}
void heap_demo_done(void) { __asm__ volatile("" : : : "memory"); }
void heap_demo(void)
{
    console_init();
    kprintf("D12 page-backed heap align=16 arenas=4\n");
    uint32_t initial = page_free_count(), f = irq_save();
    void *a = kmalloc(1);
    uint32_t observed = irq_save();
    KASSERT(!(observed & 0x200));
    __asm__ volatile("sti" : : : "memory");
    void *b = kmalloc(15);
    observed = irq_save(); KASSERT(observed & 0x200); irq_restore(observed);
    KASSERT(kfree(b));
    observed = irq_save(); KASSERT(observed & 0x200); irq_restore(f);
    KASSERT(kfree(a));
    uint32_t chain = 0, page;
    a = kmalloc(1);
    while ((page = page_alloc())) {
        *(uint32_t *)(uintptr_t)page = chain; chain = page;
    }
    uint32_t before = fingerprint();
    KASSERT(!kmalloc(4076) && page_free_count() == 0 && before == fingerprint());
    KASSERT(arenas[0] && !arenas[1] && !arenas[2] && !arenas[3]);
    while (chain) {
        page = chain; chain = *(uint32_t *)(uintptr_t)page;
        KASSERT(page_free(page));
    }
    KASSERT(kfree(a) && page_free_count() == initial - 1);
    kprintf("physical-page failure unchanged; recovery OK\n");
    unsigned sizes[] = {1, 15, 16, 17, 127, 511, 1023};
    void *items[ARENAS * PAGE_BYTES / MIN_BLOCK];
    for (unsigned i = 0; i < 7; ++i) {
        items[i] = kmalloc(sizes[i]); KASSERT(items[i] && !((uintptr_t)items[i] % 16));
        memset(items[i], i + 1, sizes[i]);
    }
    reject((char *)items[2] + 16); reject((void *)0xb8000); reject(0);
    for (unsigned i = 0; i < 7; ++i) {
        for (unsigned j = 0; j < sizes[i]; ++j) KASSERT(((uint8_t *)items[i])[j] == i + 1);
        KASSERT(kfree(items[i]));
    }
    reject(items[0]);
    KASSERT(!kmalloc(0) && !kmalloc(SIZE_MAX) && !kmalloc(SIZE_MAX - 20) && !kmalloc(4077));
    a = kmalloc(4044); b = kmalloc(1);
    KASSERT((uintptr_t)b - (uintptr_t)a == 4064); /* exact 32-byte split */
    KASSERT(kfree(b) && kfree(a));
    a = kmalloc(4060);
    KASSERT(((struct block *)a - 1)->span == PAGE_BYTES); /* 16-byte remainder absorbed */
    KASSERT(kfree(a));
    a = kmalloc(17); b = kmalloc(17); void *c = kmalloc(17);
    KASSERT(kfree(b) && kmalloc(17) == b); /* first-fit reuse */
    KASSERT(kfree(c) && kfree(b) && kfree(a));
    a = kmalloc(17); ((uint8_t *)a)[17] ^= 1;
    reject(a); KASSERT(!kmalloc(1));
    ((uint8_t *)a)[17] ^= 1;
    struct block *h = (struct block *)a - 1;
    h->span ^= 16; reject(a); h->span ^= 16;
    KASSERT(kfree(a));
    kprintf("sizes/patterns first-fit split/coalesce OK\n");
    kprintf("overflow/invalid/double/tail/metadata reject OK\n");
    unsigned count = 0;
    while ((a = kmalloc(1))) { KASSERT(count < sizeof(items)/sizeof(items[0])); items[count++] = a; }
    KASSERT(count == 512 && !kmalloc(1)); heap_allocations = count;
    KASSERT(page_free_count() == initial - ARENAS);
    while (count) KASSERT(kfree(items[--count]));
    for (unsigned i = 0; i < ARENAS; ++i) { items[i] = kmalloc(4076); KASSERT(items[i]); }
    KASSERT(!kmalloc(1));
    for (unsigned i = 0; i < ARENAS; ++i) KASSERT(kfree(items[i]));
    release();
    KASSERT(page_free_count() == initial);
    heap_passed = 1;
    kprintf("IF=0/1 preserved; exhausted=512 recovered=4 pages\n");
    kprintf("HEAP OK retained paging tables=18\n");
    heap_demo_done();
}
void heap_fault(void)
{
    console_init();
    uint8_t *p = kmalloc(17); KASSERT(p);
    p[17] ^= 1;
    reject(p);
    kprintf("D12 TAIL DAMAGE rejected unchanged\n");
    KASSERT(!"heap tail corruption demonstration");
}
