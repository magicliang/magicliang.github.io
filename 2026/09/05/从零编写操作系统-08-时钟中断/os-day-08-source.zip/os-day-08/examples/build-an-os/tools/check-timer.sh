#!/bin/sh
set -eu
start() {
    "$QEMU" $QEMU_COMMON -drive file="$disk",format=raw,if=ide -display none -serial file:build/timer-$variant-serial.txt -monitor none -S -gdb tcp:127.0.0.1:1234 > build/timer-$variant-qemu.txt 2>&1 &
    qemu_pid=$!
    trap 'kill "$qemu_pid" 2>/dev/null || true; wait "$qemu_pid" 2>/dev/null || true' EXIT HUP INT TERM
}
stop() {
    kill "$qemu_pid" 2>/dev/null || true
    wait "$qemu_pid" 2>/dev/null || true
    trap - EXIT HUP INT TERM
}
variant=normal
elf=build/kernel.elf
disk=build/mbr.img
start
cat > build/timer.gdb <<'GDB'
set architecture i386
set tcp connect-timeout 5
set tcp auto-retry on
file build/kernel.elf
target remote 127.0.0.1:1234
hbreak *timer_irq
continue
python
import gdb, struct
m = gdb.selected_inferior()
fp = int(gdb.parse_and_eval('$ebx'))
f = struct.unpack('<17I', bytes(m.read_memory(fp,68)))
assert f[12:14] == (32,0) and f[15] == 8
assert f[16] & 0x200
assert int(gdb.parse_and_eval('$eflags')) & 0x600 == 0
print('PASS: hardware IRQ0 unified frame vector=32 error=0 saved IF=1')
end
delete breakpoints
hbreak timer_observed
continue
python
assert int(gdb.parse_and_eval('timer_ticks')) >= 10
print('PASS: first foreground count', int(gdb.parse_and_eval('timer_ticks')))
end
continue
python
assert int(gdb.parse_and_eval('timer_ticks')) >= 20
print('PASS: second foreground count', int(gdb.parse_and_eval('timer_ticks')))
end
monitor screendump build/day08-screen.png -f png
delete breakpoints
hbreak _start.halt
continue
python
assert int(gdb.parse_and_eval('$eflags')) & 0x200 == 0
print('PASS: finite timer demo returned with IF=0')
end
monitor info pic
disconnect
GDB
timeout 20 gdb-multiarch -q -nx -batch -x build/timer.gdb > build/gdb-timer-normal.txt 2>&1
grep -q 'pic0:.*imr=ff isr=00.*irq_base=20' build/gdb-timer-normal.txt
grep -q 'pic1:.*imr=ff isr=00.*irq_base=28' build/gdb-timer-normal.txt
grep -q 'TIMER OK' build/timer-normal-serial.txt
grep -q 'CONSOLE OK' build/timer-normal-serial.txt
stop
if [ "${1:-}" = screenshot ]; then exit 0; fi
for variant in timer-monitor timer-noeoi; do
    elf=build/kernel-$variant.elf
    disk=build/mbr-$variant.img
    start
    sample() {
        cat > build/timer-sample.gdb <<GDB
set architecture i386
set tcp connect-timeout 5
set tcp auto-retry on
file $elf
target remote 127.0.0.1:1234
$1
printf "SAMPLE %u %u %u\\n", timer_ticks, timer_mask_actual, timer_isr
detach
GDB
        timeout 10 gdb-multiarch -q -nx -batch -x build/timer-sample.gdb > build/timer-$variant-$2.txt 2>&1
        grep '^SAMPLE' build/timer-$variant-$2.txt
    }
    sample '' boot > /dev/null
    sleep 1
    sample '' a > build/timer-a.txt
    sleep 1
    sample '' b > build/timer-b.txt
    sample 'set variable timer_mask_requested = 255' mask > /dev/null
    sleep 1
    sample '' c > build/timer-c.txt
    sleep 1
    sample '' d > build/timer-d.txt
    sample 'set variable timer_mask_requested = 254' unmask > /dev/null
    sleep 1
    sample '' e > build/timer-e.txt
    sleep 1
    sample '' f > build/timer-f.txt
    set -- $(cat build/timer-a.txt); a=$2
    set -- $(cat build/timer-b.txt); b=$2
    set -- $(cat build/timer-c.txt); c=$2; test "$3" = 255
    set -- $(cat build/timer-d.txt); d=$2; test "$3" = 255
    set -- $(cat build/timer-e.txt); e=$2; test "$3" = 254; isr_e=$4
    set -- $(cat build/timer-f.txt); f=$2; test "$3" = 254; isr_f=$4
    test "$c" = "$d"
    if [ "$variant" = timer-monitor ]; then
        test "$a" -gt 0; test "$b" -gt "$a"; test "$e" -gt "$d"; test "$f" -gt "$e"
    else
        test "$a" = 1; test "$b" = 1; test "$c" = 1; test "$e" = 1; test "$f" = 1
        test "$isr_e" = 1; test "$isr_f" = 1
    fi
    printf 'PASS: %s real-time samples %s %s masked %s %s restored %s %s ISR=%s/%s\n' "$variant" "$a" "$b" "$c" "$d" "$e" "$f" "$isr_e" "$isr_f" | tee build/timer-$variant-summary.txt
    stop
done
printf '%s\n' 'PASS: real PIT progression, IRQ0 mask/resume, missing EOI ISR0 persists after IMR restore'
