#include <stdint.h>
#include <stddef.h>
#include "runtime.h"
#include "console.h"
#include "exceptions.h"
#include "timer.h"
#include <limits.h>

struct bootinfo {
    uint32_t magic;
    uint16_t version, size;
    uint8_t drive, reserved[3];
    uint32_t map;
    uint16_t count, stride;
    uint32_t payload, payload_bytes, video;
    uint16_t columns, rows, pitch;
    uint8_t mode, cell_bytes;
};
_Static_assert(sizeof(struct bootinfo) == 40, "BootInfo v1 size");
_Static_assert(offsetof(struct bootinfo, video) == 28, "BootInfo video offset");
volatile uint32_t initialized = 0x12345678;
volatile uint32_t zeroed;
volatile uint8_t zero_array[37];

static void result(const char *text)
{
    kprintf("%s\n", text);
}

static uint32_t add_one(uint32_t value) { return value + 1; }

void kernel_main(const struct bootinfo *info)
{
    console_init(); /* entry cleared BSS/set stack; UART and VGA precede diagnostics. */
    if (info->magic != 0x31495442 || info->version != 1 || info->size != sizeof(*info)) {
        result("KERNEL BOOTINFO FAIL"); return;
    }
    if (initialized != 0x12345678 || add_one(41) != 42) {
        result("KERNEL DATA/CALL FAIL"); return;
    }
    if (zeroed != 0) { result("KERNEL BSS FAIL"); return; }
    for (size_t i = 0; i < sizeof(zero_array); ++i)
        if (zero_array[i] != 0) { result("KERNEL BSS FAIL"); return; }
    char bytes[8];
    memset(bytes, 0, sizeof(bytes));
    memcpy(bytes, "abcd", 4);
    memmove(bytes + 1, bytes, 4);
    if (memcmp(bytes, "aabcd", 5) != 0) { result("KERNEL RUNTIME FAIL"); return; }
    memmove(bytes, bytes + 1, 4);
    if (memcmp(bytes, "abcd", 4) != 0 || bytes[7] != 0) { result("KERNEL RUNTIME FAIL"); return; }
    exceptions_init();
    exception_probe();
    kprintf("EXCEPTION RETURN OK\n");
#ifdef TEST_DIVIDE
    divide_zero();
#endif
#ifdef TEST_UD2
    invalid_opcode();
#endif
#ifdef TEST_GP
    general_protection();
#endif
#if defined(TEST_TIMER_MONITOR)
    timer_demo(1);
#elif defined(TEST_TIMER_NOEOI)
    timer_demo(2);
#else
    timer_demo(0);
#endif
    console_init();
    result("KERNEL_MAIN OK");
    /* Exercise wrap and repeated scroll on the real text buffer. */
    for (unsigned i = 0; i < 80; ++i) console_putc('W');
    for (unsigned i = 0; i < 28; ++i) kprintf("scroll %u\n", i);
    kprintf("FMT %s %c %d %u %x %p %%\n", "ok", 'Z', INT_MIN, UINT_MAX,
            0xdeadbeefu, (void *)0x1234);
    kprintf("ZERO %d %u %x %p NULL %s\n", 0, 0u, 0u, (void *)0, (const char *)0);
    kprintf("unknown=%q trailing=%");
    kprintf("\nabc\rR\bB\n");
    kprintf("CONSOLE OK\n");
#ifdef TEST_PANIC
    KASSERT(2 + 2 == 5);
#endif
}
