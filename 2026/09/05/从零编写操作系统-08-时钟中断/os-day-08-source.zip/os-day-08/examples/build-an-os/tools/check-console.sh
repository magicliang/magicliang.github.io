#!/bin/sh
set -eu
for variant in normal panic uart-timeout; do
    disk=build/mbr.img
    elf=build/kernel.elf
    stop='_start.halt'
    if [ "$variant" = panic ]; then
        disk=build/mbr-panic.img
        elf=build/kernel-panic.elf
        stop=panic_halt
    fi
    "$QEMU" $QEMU_COMMON -drive file="$disk",format=raw,if=ide -display none -serial file:build/console-$variant-serial.txt -monitor none -S -gdb tcp:127.0.0.1:1234 > build/console-$variant-qemu.txt 2>&1 &
    qemu_pid=$!
    trap 'kill "$qemu_pid" 2>/dev/null || true; wait "$qemu_pid" 2>/dev/null || true' EXIT HUP INT TERM
    cat > build/console.gdb <<GDB
set architecture i386
set tcp connect-timeout 5
set tcp auto-retry on
file $elf
target remote 127.0.0.1:1234
hbreak *kernel_main
continue
python
if '$variant' == 'uart-timeout':
    # Force UART LSR reads to report not-ready; no source fault switch needed.
    gdb.selected_inferior().write_memory(int(gdb.parse_and_eval('&inb')), b'\\x31\\xc0\\xc3')
end
hbreak kernel/main.c:$(awk '/i < 28/ {print NR}' kernel/main.c)
continue
python
mem = gdb.selected_inferior()
assert bytes(mem.read_memory(0xb80a0, 160))[::2] == b'W' * 80
assert int(gdb.parse_and_eval('row')) == 2 and int(gdb.parse_and_eval('column')) == 0
print('PASS: exact 80-column wrap')
end
hbreak $stop
continue
printf "STOP EIP=%#x ESP=%#x EFLAGS=%#x CR0=%#x\\n", \$eip, \$esp, \$eflags, \$cr0
bt
x/3i \$eip
python
from pathlib import Path
mem = gdb.selected_inferior()
vga = bytes(mem.read_memory(0xb8000, 4000))
rows = [vga[i:i+160:2].decode('ascii').rstrip() for i in range(0,4000,160)]
Path('build/console-$variant-vga.txt').write_text('\\n'.join(rows)+'\\n')
assert all(vga[i] == 0x0f for i in range(1,4000,2))
assert not int(gdb.parse_and_eval('\$eflags')) & 0x200
assert int(gdb.parse_and_eval('\$cr0')) & 0x80000001 == 1
text = '\\n'.join(rows)
assert 'FMT ok Z -2147483648 4294967295 deadbeef 0x1234 %' in text
assert 'ZERO 0 0 0 0x0 NULL (null)' in text
assert 'unknown=%q trailing=%' in text
assert 'Bbc' in rows
assert 'CONSOLE OK' in rows
assert rows[0] == ('scroll 11' if '$variant' == 'panic' else 'scroll 9')
assert 'scroll 27' in rows
if '$variant' == 'uart-timeout':
    assert int(gdb.parse_and_eval('serial_available')) == 0
if '$variant' == 'panic':
    assert 'PANIC kernel/main.c:' in text and '2 + 2 == 5' in text
    assert bytes(mem.read_memory(int(gdb.parse_and_eval('\$eip')),1)) == b'\\xf4'
else:
    assert 'PANIC' not in text
print('PASS: $variant VGA scroll, controls, format boundaries, IF=0 and protected mode')
end
monitor screendump build/console-$variant.png -f png
disconnect
GDB
    timeout 20 gdb-multiarch -q -nx -batch -x build/console.gdb > build/gdb-console-$variant.txt 2>&1
    grep -q 'PASS:' build/gdb-console-$variant.txt
    if [ "$variant" != uart-timeout ]; then
    grep -q 'FMT ok Z -2147483648 4294967295 deadbeef 0x1234 %' build/console-$variant-serial.txt
    grep -q 'ZERO 0 0 0 0x0 NULL (null)' build/console-$variant-serial.txt
    grep -q 'CONSOLE OK' build/console-$variant-serial.txt
    else
        ! grep -q 'CONSOLE OK' build/console-uart-timeout-serial.txt
    fi
    if [ "$variant" = panic ]; then
        grep -q 'PANIC kernel/main.c:.*2 + 2 == 5' build/console-panic-serial.txt
    else
        ! grep -q 'PANIC' build/console-normal-serial.txt
    fi
    kill "$qemu_pid" 2>/dev/null || true
    wait "$qemu_pid" 2>/dev/null || true
    trap - EXIT HUP INT TERM
done
printf '%s\n' 'PASS: real QEMU COM1/VGA formatting, scroll and assertion halt'
# No breakpoint: prove QEMU actually executed HLT, not only reached its address.
{ sleep 2; printf 'info registers\nquit\n'; } | "$QEMU" $QEMU_COMMON -drive file=build/mbr-panic.img,format=raw,if=ide -display none -serial file:build/panic-halted-serial.txt -monitor stdio > build/panic-halted-registers.txt 2>&1
grep -q 'HLT=1' build/panic-halted-registers.txt
grep -q 'PANIC kernel/main.c:.*2 + 2 == 5' build/panic-halted-serial.txt
printf '%s\n' 'PASS: UART not-ready bounded fallback and actual panic HLT=1'
