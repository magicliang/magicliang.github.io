# 第 06 篇：COM1、VGA console、格式化与 panic 实测

验证日期：2026-09-05。基于第 05 篇源码提交 `1dc5f44af6932021332cc798d83459a4e3695132`。复用已运行的 Podman VM 与 `localhost/build-an-os:day01`，没有重建工具链。

## 命令与结果

在宿主运行：

```sh
podman run --rm -v "$PWD/examples/build-an-os:/work" -w /work localhost/build-an-os:day01 make check screenshot
```

退出码 0。`check-pm`、`check-kernel`、`check-console` 和原 `check.sh` 全通过。之后扩充 console 断言，再运行 `make check-console screenshot`，退出码 0。扩充仅改变检查脚本，没有改变内核二进制。

完整回归保留：ELF32/i386、未定义符号为空、故意缺符号链接失败、MBR 签名、空盘、EDD 读头和载荷、checksum、坏头/坏签名/截短/超限、A20 强制关闭及失败、E820 容量耗尽、坏 GDT 导致 #GP(0008) → #DF → triple fault、真实 C/cdecl/栈/data/BSS/runtime、独立跳过 BSS 清零以及单扇区分批读取变体。

## 正常 console

环境仍是 QEMU 7.2.22、`pc-i440fx-7.2`、TCG、`qemu32`、单核、64 MiB、SeaBIOS。`kernel.bin` 是 2804 字节 / 6 扇区，保留 64 KiB 文件装载上限。`make screenshot` 产生 `build/day06-screen.png`；已实际查看，字符未截断。

COM1 与 VGA 都出现：

```text
FMT ok Z -2147483648 4294967295 deadbeef 0x1234 %
ZERO 0 0 0 0x0 NULL (null)
unknown=%q trailing=%
CONSOLE OK
```

`check-console.sh` 在第 80 个 `W` 输出后通过 GDB 读取物理 VGA，断言整行正好 80 个 `W`、`row=2,column=0`。28 行滚屏和随后诊断输出完成后，正常屏幕第一行精确为 `scroll 9`，仍包含 `scroll 27`；最后一行空白。控制字符序列 `abc\rR\bB\n` 的 VGA 行精确为 `Bbc`。所有 2000 个字符属性字节均为 `0x0f`。

原始产物：`build/console-normal-serial.txt`、`build/console-normal-vga.txt`、`build/gdb-console-normal.txt`、`build/console-normal.png`。

## 独立 panic 镜像

`build/mbr-panic.img` 使用单独 `kernel-main-panic.o` / `kernel-panic.elf` / header；正常镜像没有启用 `TEST_PANIC`。

两端实际输出 `PANIC kernel/main.c:60: 2 + 2 == 5`。GDB 在 `panic_halt` 前捕获：

```text
STOP EIP=0x100992 ESP=0x104b48 EFLAGS=0x6 CR0=0x11
#0 panic (file="kernel/main.c", line=60, reason="2 + 2 == 5")
#1 kernel_main (info=0x5000)
#2 _start
0x100992: hlt
0x100993: jmp 0x100992
```

另开无断点 QEMU 实际执行 HLT，再读 monitor 寄存器：

```text
EIP=00100993 EFL=00000006 CPL=0 II=0 A20=1 SMM=0 HLT=1
CR0=00000011 CR2=00000000 CR3=00000000 CR4=00000000
```

IF=0；CR0.PE=1、PG=0；EIP 在 HLT 后的 jmp 处，QEMU 报告 CPU 已 halt。没有把断点停住冒充实际 HLT。原始证据：`build/gdb-console-panic.txt`、`build/console-panic-vga.txt`、`build/console-panic-serial.txt`、`build/console-panic.png`、`build/panic-halted-registers.txt`。

## 串口不就绪注入

第三次运行沿用正常磁盘镜像。GDB 在 C 入口将本次运行内存中的 `inb` 指令改为 `xor eax,eax; ret`，使 UART LSR 持续返回 0，不修改源码或磁盘。这是软件故障注入，不是实际拔除设备。

内核在 100000 次轮询后将 `serial_available` 置为 0，继续完成相同 VGA 检查并抵达正常停机地址；串口没有 `CONSOLE OK`。证据：`build/gdb-console-uart-timeout.txt`、`build/console-uart-timeout-vga.txt`。证明不会因本模块 UART 等待无限卡住；此前 BIOS/stage2 串口例程不在该证明范围。

边界：ASCII 文本、固定 COM1/VGA、32 位指针、无中断/IDT/分页、单核早期启动；格式串和字符串指针需有效。panic 保留断言调用栈，不是通用异常处理器。所有 `build/` 产物仍被忽略，检查脚本可重新生成证据。
