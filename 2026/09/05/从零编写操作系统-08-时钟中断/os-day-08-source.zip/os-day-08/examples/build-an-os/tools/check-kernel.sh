#!/bin/sh
set -eu
i686-elf-readelf -h -l build/kernel.elf > build/kernel-elf.txt
i686-elf-nm -n build/kernel.elf > build/kernel-symbols.txt
i686-elf-objdump -dr -Mintel build/kernel.elf > build/kernel-disassembly.txt
test -z "$(i686-elf-nm -u build/kernel.elf)"
grep -q 'Class:.*ELF32' build/kernel-elf.txt
grep -q 'Machine:.*Intel 80386' build/kernel-elf.txt
"$QEMU" $QEMU_COMMON -drive file=build/mbr.img,format=raw,if=ide -display none -serial file:build/kernel-gdb-serial.txt -monitor none -S -gdb tcp:127.0.0.1:1234 > build/kernel-qemu.txt 2>&1 &
qemu_pid=$!
trap 'kill "$qemu_pid" 2>/dev/null || true; wait "$qemu_pid" 2>/dev/null || true' EXIT HUP INT TERM
cat > build/kernel.gdb <<'GDB'
set architecture i386
set tcp connect-timeout 5
set tcp auto-retry on
file build/kernel.elf
target remote 127.0.0.1:1234
hbreak *_start
continue
python
assert int(gdb.parse_and_eval('$esi')) == 0x5000
bss = int(gdb.parse_and_eval('&__bss_start'))
end = int(gdb.parse_and_eval('&__bss_end'))
assert bytes(gdb.selected_inferior().read_memory(bss, end-bss)) == b'\xa5' * (end-bss)
print('DIRTY_BSS_PROVEN')
end
hbreak *kernel_main
continue
printf "KERNEL_ENTRY=%#x ESP=%#x ARG=%#x DATA=%#x BSS=%#x\n", $eip, $esp, *(unsigned int*)($esp+4), initialized, zeroed
python
import struct
esp = int(gdb.parse_and_eval('$esp'))
assert esp % 16 == 12
assert int(gdb.parse_and_eval('*(unsigned int*)($esp+4)')) == 0x5000
assert int(gdb.parse_and_eval('initialized')) == 0x12345678
assert bytes(gdb.selected_inferior().read_memory(bss, end-bss)) == b'\0' * (end-bss)
assert int(gdb.parse_and_eval('$cr0')) & 0x80000001 == 1
h = open('build/header.bin', 'rb').read()
magic,version,size,memory,entry,checksum = struct.unpack_from('<6I',h)
payload = open('build/kernel.bin', 'rb').read()
assert (magic,version,size) == (0x334f5342,1,len(payload))
assert memory == int(gdb.parse_and_eval('&__kernel_end')) - 0x100000
assert entry == int(gdb.parse_and_eval('&_start')) - 0x100000
assert checksum == sum(payload) % 65536
assert bytes(gdb.selected_inferior().read_memory(0x100000,size)) == payload
print('PASS: ELF/header/copy, dirty then cleared BSS, cdecl argument, aligned call, data and no paging')
end
disconnect
GDB
timeout 20 gdb-multiarch -q -nx -batch -x build/kernel.gdb > build/gdb-kernel.txt 2>&1
grep -q 'DIRTY_BSS_PROVEN' build/gdb-kernel.txt
grep -q 'PASS: ELF/header/copy' build/gdb-kernel.txt
kill "$qemu_pid" 2>/dev/null || true
wait "$qemu_pid" 2>/dev/null || true
trap - EXIT HUP INT TERM
for variant in normal badbss chunk1; do
    disk=build/mbr.img
    test "$variant" = normal || disk=build/mbr-$variant.img
    status=0
    timeout 3 "$QEMU" $QEMU_COMMON -drive file="$disk",format=raw,if=ide -display none -serial stdio -monitor none > "build/kernel-$variant.txt" 2>&1 || status=$?
    test "$status" -eq 124
done
test "$(wc -c < build/kernel.bin)" -gt 512
grep -q 'KERNEL_MAIN OK' build/kernel-normal.txt
grep -q 'KERNEL_MAIN OK' build/kernel-chunk1.txt
grep -q 'KERNEL BSS FAIL' build/kernel-badbss.txt
! grep -q 'KERNEL_MAIN OK' build/kernel-badbss.txt
printf '%s\n' 'PASS: kernel_main C/data/BSS/runtime and independent SKIP_BSS_CLEAR rejection'
