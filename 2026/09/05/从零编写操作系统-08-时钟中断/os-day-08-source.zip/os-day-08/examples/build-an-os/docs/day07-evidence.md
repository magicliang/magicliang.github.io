# 第 07 篇：CPU 异常入口实测

日期：2026-09-05。基线源码：`6c70cce3618ee01a7a0226db0f2643e812a4bea9`。本记录对应第 07 篇累计变更，使用现有 Podman VM 和 `localhost/build-an-os:day01`，没有重建工具链镜像。

## 重跑

在 `examples/build-an-os` 执行：

```sh
podman run --rm -v "$PWD:/work" -w /work localhost/build-an-os:day01 make check
```

只检查第 07 篇时将最后的目标改为 `check-exceptions`。所有 GDB 检查串行使用容器端口 1234。目标固定为 `pc-i440fx-7.2`、TCG、`qemu32`、单核 64 MiB、SeaBIOS；不是实际硬件覆盖。

## 本次观察

- 正常 INT3：vector=3、error=0、EIP=`0x100de2`（`probe_resume`）、CS=8、EFLAGS=`0x412`。frame 地址 `0x105a24`，大小 68；GS/FS/ES/DS 均为 `0x10`。
- EDI/ESI/EBP 为 `0x77777777/0x66666666/0x55555555`；EBX/EDX/ECX/EAX 为 `0x44444444/0x33333333/0x22222222/0x11111111`。PUSHAD 保存 ESP=`0x105a54`，即 frame+48，不是异常前 ESP。
- C 函数首条指令 ESP=`0x105a0c`，模 16 为 12，说明 CALL 前按 16 字节对齐；实时 DF=0、IF=0，而 frame 内 DF=1。IRETD 后在 `probe_restored` 检查全部 GPR、原 ESP 与全部保存 EFLAGS 相同，DF 恢复为 1。探针随后 CLD，再恢复调用方现场。
- 真 #DE：vector=0、error=0、EIP=`0x100df4`（汇编 `divide_fault: div ecx`）。真 #UD：vector=6、error=0、EIP=`0x100df7`（`ud_fault: ud2`）。真 #GP：vector=13、error=`0x18`、EIP=`0x100dfe`（`gp_fault: mov ds, ax`）。这些 fault 不修正 EIP，输出后直接 panic。
- 四个无断点启动均观察到 QEMU `HLT=1`；正常镜像串口有 `CONSOLE OK` 且无 PANIC，三个 fault 镜像均有对应 vector/error 及 `unhandled CPU exception`。这证明它们没有走三重故障重启，而不是仅在 HLT 前下断点。

地址取决于当前编译结果；检查脚本按 ELF 标签比较，未把这些数值硬编码为未来契约。IDTR limit 实测为 2047；全部 256 项 flags 检查为前 32 项 `0x8e`，其余 0。

## 产物与回归

`build/gdb-exception-{normal,divide,ud2,gp}.txt` 保存逐项断言和 frame；`build/exception-*-serial.txt` 是 COM1；`build/exception-*-registers.txt` 保存无断点 HLT 观察。截图为 `day07-screen.png`（只取正常镜像的 INT3 返回点，故障变体不覆写）、`day07-console.png`（正常最终画面）、`day07-divide.png`、`day07-ud2.png`、`day07-gp.png`，均在忽略的 build 目录。

累计 `make check` 保留保护模式、E820、A20、故障 GDT、C ABI、装载/BSS/runtime、UART 超时、VGA 换行滚屏、格式边界、断言 panic 与读盘/镜像故障回归。旧 bad-GDT 实验本来用于证明未安装 IDT 时三重故障；它与本篇四个异常镜像的可诊断 HLT 是不同实验。正常 payload 4660 字节，异常 payload 各 4660 字节，assertion 镜像 4708 字节，全部低于 loader 的 65536 字节限制。

## 规范与边界

Intel SDM Vol.3A [253668-078US](https://cdrdv2-public.intel.com/671190/253668-sdm-vol-3a.pdf) Table 6-1、§6.11–6.13 规定 gate、同级 frame、错误码和 IRET 行为；[Vol.2 指令手册](https://cdrdv2-public.intel.com/774492/325383-sdm-vol-2abcd.pdf) 说明 PUSHAD、CLD、UD2。

本实现面向固定 qemu32 教学配置：经典错误码集合为 8、10、11、12、13、14、17；现代扩展（例如 CET #CP）需要重新审核 stub 分类。`int 13` 是软件中断，不压 #GP 的 CPU 错误码，不能代替非法 selector 实验。

没有 STI、PIC/PIT、IRQ handler 或 EOI；关闭 IF 不阻止同步 CPU 异常。未切换特权级，所以 frame 没有旧 SS/ESP。只对白名单 INT3 返回，其余异常 panic。没有声称运行测试过全部 32 向量，也没有提供损坏栈情况下的可靠 double-fault 恢复。
