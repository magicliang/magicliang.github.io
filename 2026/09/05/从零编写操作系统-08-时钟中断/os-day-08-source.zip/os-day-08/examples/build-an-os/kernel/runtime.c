#include "runtime.h"
#include <stdint.h>

void *memcpy(void *restrict dest, const void *restrict src, size_t n)
{
    unsigned char *d = dest;
    const unsigned char *s = src;
    for (size_t i = 0; i < n; ++i)
        d[i] = s[i];
    return dest;
}

void *memmove(void *dest, const void *src, size_t n)
{
    unsigned char *d = dest;
    const unsigned char *s = src;
    if (d == s || n == 0)
        return dest;
    if ((uintptr_t)d < (uintptr_t)s) {
        for (size_t i = 0; i < n; ++i)
            d[i] = s[i];
    } else {
        while (n != 0) {
            --n;
            d[n] = s[n];
        }
    }
    return dest;
}

void *memset(void *dest, int value, size_t n)
{
    unsigned char *d = dest;
    for (size_t i = 0; i < n; ++i)
        d[i] = (unsigned char)value;
    return dest;
}

int memcmp(const void *lhs, const void *rhs, size_t n)
{
    const unsigned char *a = lhs;
    const unsigned char *b = rhs;
    for (size_t i = 0; i < n; ++i) {
        if (a[i] != b[i])
            return (int)a[i] - (int)b[i];
    }
    return 0;
}
