#ifndef CONSOLE_H
#define CONSOLE_H

void console_init(void);
void console_putc(char c);
/* Only s,c,d,u,x,p,%: no flags, widths, precision, lengths or floats.
 * Unknown conversions are printed literally and consume no argument. */
void kprintf(const char *format, ...);
_Noreturn void panic(const char *file, unsigned line, const char *reason);
#define KASSERT(condition) do { if (!(condition)) panic(__FILE__, __LINE__, #condition); } while (0)

#endif
