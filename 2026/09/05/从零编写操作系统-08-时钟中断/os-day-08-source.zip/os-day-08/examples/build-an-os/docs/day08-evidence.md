# 第 08 篇：PIC/PIT 与真实 IRQ0 实测

日期：2026-09-05。源码基线 `1737b2d320dcb333fd70d2b2720c36c897f4b8e5` 加本篇累计变更。使用现有 Podman VM、`localhost/build-an-os:day01`，没有重建镜像或停止 VM。目标仍为 `pc-i440fx-7.2`、TCG、qemu32、单 CPU、64 MiB、SeaBIOS。

## 重跑

在仓库根目录执行：

```sh
podman run --rm -v "$PWD/examples/build-an-os:/work" -w /work localhost/build-an-os:day01 make check-timer
podman run --rm -v "$PWD/examples/build-an-os:/work" -w /work localhost/build-an-os:day01 make check
podman run --rm -v "$PWD/examples/build-an-os:/work" -w /work localhost/build-an-os:day01 make screenshot
```

检查共用容器 GDB 端口 1234，必须串行。正常截图位于 `build/day08-screen.png`。`make screenshot` 运行正常镜像并停在第二次前台打印后的检查点，再继续验证退出；两个诊断变体不会覆盖它。

## 实际样本

正常镜像的首个硬件 IRQ0：统一 frame 的 vector=32、error=0、CS=8、保存的 IF=1；进入 C 时实时 IF=0、DF=0。GDB 在 `timer_irq` 第一条指令处检查由公共汇编入口保存在 EBX 中的 frame 指针。此后前台两次打印分别读到 10、20 tick。只有 `timer_irq` 递增计数，主循环和 GDB 都未写入 tick。

正常镜像随后保持 IF=0，把主从 IMR 都设成 0xff，再完成原 console 演示并返回 `_start.halt`。QEMU `info pic` 实测主 `irq_base=20 imr=ff isr=00`、从 `irq_base=28 imr=ff isr=00`。主 IRR 可以留下新到但被屏蔽的请求，这不是尚未 EOI 的 ISR 状态。

持续诊断镜像采用独立编译的 main：正常 EOI 对照为 `mbr-timer-monitor.img`，漏 EOI 为 `mbr-timer-noeoi.img`。每次 GDB 读取后 `detach` 恢复真实 QEMU 执行，宿主等待 1 秒再连接采样；改变 mask 后先等待 1 秒，再测稳定区间。下表来自累计检查本次运行，数值不是固定预期：

| 镜像 | 开放 IRQ0 两次 count | 屏蔽后两次 count | 恢复后两次 count | 恢复后的 ISR |
| --- | --- | --- | --- | --- |
| 正常 EOI 诊断 | 97 → 204 | 209 → 209 | 315 → 420 | 0 → 0 |
| 漏 EOI 诊断 | 1 → 1 | 1 → 1 | 1 → 1 | 1 → 1 |

mask 样本同步读回实际主 IMR：屏蔽期 255，恢复期 254。ISR 通过 OCW3=0x0b 后读取主命令口获得。漏 EOI 的 ISR0 在恢复 IMR 后仍置位，证明清 mask 不会清 ISR。此实验没有用 GDB 软件递增模拟时钟，也没有把停在调试器内等待的时间当成运行时间。未实施软件补 EOI 的第三个实验。

## 验证产物

`build/gdb-timer-normal.txt` 包含 frame、10/20 tick、IF=0 与 PIC 输出；`build/timer-normal-serial.txt` 保留 `TIMER OK` 和 `CONSOLE OK`。`build/timer-timer-{monitor,noeoi}-{a,b,c,d,e,f}.txt` 保存每次独立 GDB 采样，两个 `*-summary.txt` 汇总实际值。样本会因调度、启动和 GDB 开销改变，检查只要求增长或稳定，不要求一秒恰好 100 tick。

累计检查保留 INT3 完整 GPR/ESP/EFLAGS/DF 恢复、C 栈对齐、真实 #DE/#UD/#GP 错误码及停机；IDT 检查只把第 32 项适配为新 IRQ0 gate，第 33–255 项仍要求 non-present。保护模式、E820、A20、GDT 故障、入口/BSS/runtime、UART 超时、VGA/格式化、panic 与镜像故障检查继续运行。

正常 payload 5444 字节，持续/漏 EOI 诊断均 5444 字节，panic 5492 字节，均小于 65536 字节装载限制。i686-elf-gcc 使用现有 `-Wall -Wextra -Werror` 编译通过；宿主 ARM Clang 对 x86 asm 的约束诊断不代表目标交叉编译结果。

## 实现边界

PIC 两片 ICW1=0x11，ICW2=0x20/0x28，ICW3=0x04/0x02，ICW4=0x01。只有 IRQ0 有 gate 且开放，IRQ0 只向主片发送非特定 EOI；没有从片 IRQ、spurious IRQ 或 APIC 驱动。PIT channel 0 控制字 0x34，divisor=11932；按 QEMU 的 1193182 Hz 输入常量计算约 99.998491 Hz，这是计算值而非精密测量。

正常前台从 CLI 后检查 count，睡眠时使用同一个 volatile asm 中紧邻的 `sti; hlt` 和 memory clobber。诊断镜像故意忙轮询，以便 mask 后仍能处理外部 GDB 的恢复请求。volatile 提供可见访问，单核 CLI 才保护前台临界快照；没有多核同步、调度或任务切换。tick 为 32 位中断次数，屏蔽期间不精确积存每次 PIT 脉冲，也不是墙钟。此次是 QEMU 真运行覆盖，不是物理硬件测试。

规范依据为 [Intel 8259A 原厂手册](https://pdos.csail.mit.edu/6.828/2010/readings/hardware/8259A.pdf)、[Intel 8254 原厂手册](https://www.cs.cmu.edu/~410/doc/8254.pdf)、[Intel STI 指令条目](https://www.intel.com/content/dam/www/public/us/en/documents/manuals/64-ia-32-architectures-software-developer-vol-2b-manual.pdf) 与 [QEMU PIT 输入常量](https://raw.githubusercontent.com/qemu/qemu/master/include/hw/timer/i8254.h)。
