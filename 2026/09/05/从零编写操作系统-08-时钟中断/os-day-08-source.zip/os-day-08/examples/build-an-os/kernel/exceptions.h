#ifndef EXCEPTIONS_H
#define EXCEPTIONS_H
#include <stdint.h>
struct trap_frame {
    uint32_t gs, fs, es, ds;
    uint32_t edi, esi, ebp, pushad_esp, ebx, edx, ecx, eax;
    uint32_t vector, error, eip, cs, eflags;
};
void exceptions_init(void);
void exception_probe(void);
void divide_zero(void);
void invalid_opcode(void);
void general_protection(void);
void trap_dispatch(struct trap_frame *frame);
#endif
