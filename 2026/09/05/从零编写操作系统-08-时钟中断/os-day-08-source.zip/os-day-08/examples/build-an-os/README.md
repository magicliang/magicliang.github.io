# 从零编写操作系统：第 08 篇配套实验

当前启动路径执行真实 C 内核：交叉编译生成 `kernel.elf`，`objcopy` 提取可装载字节；stage2 沿用镜像头和 checksum，暂存于 `0x10000`，完成 E820、A20 与保护模式切换后复制到 `0x100000`。内核入口清 BSS、建立 16 KiB 栈，并按 cdecl 传入 BootInfo。没有分页，也没有在启动器中增加通用 ELF 解析器。

## 运行

在本目录执行，宿主已有启动的 Podman Linux 环境：

```sh
podman run --rm -it -v "$PWD:/work" -w /work localhost/build-an-os:day01 sh
```

容器中执行：

```sh
make build
make check
make run
make screenshot
```

首次没有工具链镜像时才运行 `podman build -t localhost/build-an-os:day01 .`。现有镜像不需要重建。

正常串口先保留 `D04 PM OK - BootInfo v1`、`KERNEL_MAIN OK`，最后输出 `CONSOLE OK`。C 内核初始化会清屏；滚屏演示后 VGA 首行为 `scroll 9`，末尾为格式化边界与成功标识。`make screenshot` 在正常时钟演示的 20 tick 处生成 `build/day08-screen.png`，随后仍验证 console 返回。

`make check-console` 检查真实 COM1/VGA、80 列换行、滚屏、格式化边界、串口持续不就绪和独立 `mbr-panic.img` 的断言停机；`make check-pm` 保留第 04 篇保护模式和故障实验；`make check-kernel` 验证第 05 篇入口、装载边界、C ABI、运行时函数与坏 BSS；`make check` 同时跑此前 ELF、读盘、坏头、损坏、截短和坏签名回归。检查共用容器内 GDB 1234 端口，不要另开调试实例同时运行。

## 手动调试

同一容器内执行：

```sh
make debug &
gdb-multiarch build/kernel.elf
```

GDB 中执行：

```text
target remote 127.0.0.1:1234
hbreak *kernel_main
continue
info registers esp cr0
x/wx $esp+4
p/x initialized
p/x zeroed
p/x &__stack_top
monitor quit
quit
```

必须用 `hbreak *kernel_main` 才停在函数第一条指令、尚未执行 C 序言的位置；此时 `ESP % 16 = 12`，返回地址后面的参数是 `0x5000`。`call` 之前 ESP 为 16 字节对齐。`monitor quit` 会关闭远程连接。

## 文件与契约

- `kernel/`：C 内核、入口、链接脚本与四个最小内存函数；`sample/` 仍保留第 01 篇独立链接样例。
- `boot/`：累计 MBR、stage2 和 BootInfo v1。BootInfo 仍为 40 字节，payload 字段仍表示低端暂存位置及文件长度；最终内核地址由链接契约固定。
- `tools/kernel-header.sh`：从 ELF 符号与入口提取 memory/entry，核对 binary 文件长度；`mkpayload.c` 读取实际 binary，生成校验和与坏头，不再制造确定性载荷。
- `tools/check-kernel.sh`：GDB 比较装载字节、清零前后 BSS、参数、栈和已初始化数据，并检查正常、跳过清零和单扇区分批读取镜像。
- [第 05 篇实测记录](docs/day05-evidence.md)：地址、命令、结果和运行边界；此前的 [01](docs/day01-evidence.md)、[02](docs/day02-evidence.md)、[03](docs/day03-evidence.md)、[04](docs/day04-evidence.md) 记录对应当时快照。

所有产物写入忽略的 `build/`。当前工具链没有目标 libc/libgcc；最终 ELF 的未定义符号必须为空，编译禁止 SSE、MMX 和硬件浮点。本篇安装 256 项 IDT，其中 0–31 项是 present 的 CPU 异常入口，32 项是 IRQ0；33–255 项保持 non-present。仅开放 IRQ0，不实现分页或动态分配。

## Console 与 panic 契约

初始化顺序是 stage2 完成 BIOS/E820/A20 → 保护模式复制内核 → entry 清 BSS、建栈 → `console_init` 配置 UART 并清 VGA → BootInfo/data/BSS/runtime 自检 → 格式化与滚屏演示。坏 BSS 镜像会在输出模块显式重置自身状态后继续报告 `KERNEL BSS FAIL`。

COM1 为 115200、8N1、无中断轮询。单次发送最多读取 LSR 100000 次；超限后停用串口，后续 VGA 仍可用。这是迭代上限，不是毫秒期限。VGA 固定 `0xb8000`、80×25、白字黑底，换行归零列并下移、回车归零列、退格擦除前一格（可跨行），最底行继续输出时向上搬移 24 行。

`kprintf` 仅支持 `%s %c %d %u %x %p %%`；`%p` 是带 `0x` 的不补零 32 位十六进制，`%s` 空指针输出 `(null)`。不支持宽度、精度、长度修饰、浮点或 UTF-8 排版；未知转换原样输出且不消费参数，末尾孤立 `%` 原样输出。格式串和非空字符串指针必须有效，参数类型需匹配。串口把 LF 转成 CRLF，CR/BS 直接发送；VGA 的退格擦除不等同于所有串口终端的显示策略。

`KASSERT` 失败先 `cli`，再把文件、行号和表达式同时写往两端，最后在 `panic_halt` 的 `hlt/jmp` 循环停机。它保留当前栈供 GDB 查看，不是任意 CPU 异常的寄存器捕获器。当前仅单核 IRQ0，handler 不调用输出；前台时钟输出在 IF=0 的临界区，不提供可重入或多核输出锁。

[第 06 篇实测记录](docs/day06-evidence.md) 包含可重跑命令、真实输出、故障注入方式与证据路径。`build/mbr-panic.img` 只替换 C 内核，不修改正常镜像。

## CPU 异常入口（第 07 篇）

`make check-exceptions` 构建并检查正常 INT3 恢复，以及独立的 `mbr-divide.img`、`mbr-ud2.img`、`mbr-gp.img`。正常启动先运行真实 INT3，经 IRETD 返回，再清屏运行第 06 篇 console 演示；串口保留 `EXCEPTION RETURN OK`，最终 VGA 布局不变。坏 BSS 在安装 IDT 前退出。`make check` 包含这项检查。

`kernel/exceptions.asm` 将 CPU 错误码与软件补零统一，保存全部 GPR 和 DS/ES/FS/GS；进入 C 前加载数据段、CLD 并动态对齐栈，返回时恢复现场、清理 vector/error 后 IRETD。68 字节 frame 仅适用于当前 ring 0 同级入口，没有 CPU 未压入的旧 SS/ESP；`pushad_esp` 是 PUSHAD 前的 ESP。

本例采用固定 `qemu32` 目标的经典错误码集合 8、10、11、12、13、14、17，未启用分页/CET 等扩展，不是所有现代 x86 异常的完整分类。CPU 异常不是外部硬件 IRQ；第 07 篇冻结快照的 IF 始终为 0；当前累计代码在异常探针结束后增加第 08 篇 PIC/PIT 演示。真实 #GP 用超出 GDT 的 selector 0x18 装载 DS；`int 13` 不产生 CPU 错误码，不能用来测试 #GP 的错误码入口。

[第 07 篇实测记录](docs/day07-evidence.md) 给出 trap frame、C ABI、DF/GPR 恢复和停机证据。`build/day07-screen.png` 是 INT3 返回点截图，`build/day07-{divide,ud2,gp}.png` 是异常诊断截图。普通同栈 #DF 入口不能保证从损坏栈中恢复；未测试的异常入口不宣称已完成运行覆盖。

## 时钟 IRQ（第 08 篇）

`make check-timer` 验证 IRQ0 真实 frame、正常镜像 10→20 tick，以及两个独立诊断镜像：`mbr-timer-monitor.img` 在 GDB 两次采样之间真正运行一秒，展示 count 增长、屏蔽稳定、恢复增长；`mbr-timer-noeoi.img` 故意漏主 PIC EOI，count 始终为 1，ISR0 为 1，恢复 IMR 后仍不增长。GDB 只写诊断 mask 请求，从不写 tick。两个诊断镜像持续运行，使用忙轮询保证 IRQ0 被屏蔽后仍能处理恢复请求。

正常镜像在 `timer_demo(0)` 中完成约 0.2 秒的有限演示，20 tick 后保持 IF=0、屏蔽主从全部 IRQ，再运行原 console 演示并返回 `_start.halt`。`make screenshot` 只用正常镜像，在清屏前取时钟截图；故障镜像不会覆盖它。`make check` 保留全部早期检查并加入时钟检查。

PIC 主从按 ICW1–4 重映射到 0x20/0x28，仅主 IRQ0 解除屏蔽。PIT channel 0 使用 Mode 2、低字节后高字节写 divisor=11932；按 QEMU 输入常量计算约 99.99849 Hz，不保证真实墙钟精度。IRQ0 复用 68 字节 frame，只递增 `timer_ticks` 并发主片 EOI；打印在前台，未实现任务切换。单核共享数据使用 CLI 临界快照；volatile 仅保证访问可见，不能替代同步。正常等待从 CLI 检查开始，然后在同一 asm 中紧邻 STI/HLT。

[第 08 篇实测记录](docs/day08-evidence.md) 给出本次实际样本、产物和边界。
