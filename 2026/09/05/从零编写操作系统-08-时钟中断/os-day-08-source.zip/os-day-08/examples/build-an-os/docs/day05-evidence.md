# 第 05 篇：C 内核实测记录

2026-09-05，既有 `localhost/build-an-os:day01` 工具链，QEMU 7.2.22 / pc-i440fx-7.2 / TCG / qemu32 / 64 MiB / SeaBIOS。以下是实际模拟器证据，不是物理机器兼容声明。

## 复现与产物

仓库根目录执行：

```sh
podman run --rm -v "$PWD/examples/build-an-os:/work" -w /work localhost/build-an-os:day01 make check screenshot
```

`build/kernel.elf` 是 ELF32 / Intel 80386，入口 `0x100000`；`build/kernel.bin` 是 objcopy 从它提取的 1012 字节可装载内容，共 2 个磁盘扇区。启动器读取的是 binary，不解析 ELF program headers。`tools/kernel-header.sh` 使用 readelf/nm 得到入口和链接边界，并确认 `binary 长度 = __file_end - __kernel_start`，再由宿主 C 工具读取 binary 计算 checksum。

镜像头沿用 v1，小端 u32：magic、version、file bytes、memory bytes、entry offset、checksum。当前 file=1012、memory=17488、entry=0；checksum 是实际文件字节和 mod 65536。entry 是相对 `0x100000` 的偏移。stage2 校验 `64 <= file <= memory <= 65536`、`entry < file`，仍以 64 KiB 为低端暂存和高端装载上限。BootInfo v1 仍为 40 字节，无字段扩展，C 用静态断言核对 size/video 偏移，并在入口校验 magic/version/size。

## 链接和 C ABI

`build/kernel-symbols.txt` 的实际边界：

| 范围 | 地址 |
| --- | --- |
| text | `[0x100000, 0x10037e)` |
| data | `[0x1003f0, 0x1003f4)` |
| 文件结束 | `0x1003f4` |
| BSS | `[0x100400, 0x100445)` |
| stack | `[0x100450, 0x104450)`，16 KiB |

rodata 和对齐间隙也属于文件内容，栈与 BSS 不占 binary 文件字节。stage2 先用 `0xa5` 污染整个高端 memory 区间，再复制 file bytes；入口通过 `__bss_start/__bss_end` 清零，设置栈顶，预留 12 字节后压入 BootInfo 指针，保证 `call` 前 ESP 16 字节对齐。`cld` 在 stage2 和入口均明确执行。

`build/gdb-kernel.txt` 实际输出：

```text
Breakpoint 1, 0x00100000 in _start ()
DIRTY_BSS_PROVEN
Breakpoint 2, kernel_main (info=0x5000) at kernel/main.c:36
KERNEL_ENTRY=0x10009c ESP=0x10443c ARG=0x5000 DATA=0x12345678 BSS=0
PASS: ELF/header/copy, dirty then cleared BSS, cdecl argument, aligned call, data and no paging
```

GDB 在 `_start` 比较整段 BSS 等于 `0xa5`，在 `kernel_main` 第一条指令比较整段 BSS 等于零；同时比较高端 file bytes 与真实 binary 完全一致。CR0.PE=1、CR0.PG=0，`ESP % 16=12`、`[ESP+4]=0x5000`。C 再检查已初始化变量、零变量/数组、普通函数调用，并客体验证 memcpy/memset/memcmp 和两个方向的重叠 memmove。

`nm -u build/kernel.elf` 无输出，不依赖 libc、libgcc、宿主入口或启动对象。构建指定 freestanding、no PIE、no stack protector、no SSE/SSE2/MMX、soft float；未引入除法或浮点运算。

## 正常与故障结果

正常 `build/kernel-normal.txt` 最后为 `KERNEL_MAIN OK`；屏幕第二行同样显示此标识，截图 `build/day05-screen.png`。

独立 `kernel-entry-badbss.o` 仅定义 `SKIP_BSS_CLEAR`，另行链接/生成自己的 binary 和匹配头，不篡改正常镜像。`build/kernel-badbss.txt` 输出 `KERNEL BSS FAIL`，没有成功标识。它通过了读盘/checksum/PM，失败发生在 C 对脏 BSS 的检查，证明成功不依赖 QEMU 初始 RAM 为零。

`ONE_SECTOR_READS` 变体把每批读盘降至一个扇区，以当前两扇区内核实际覆盖批次递进路径，仍输出成功标识。截短镜像动态删除最后一个所需扇区，得到 `D03 READ FAIL`；坏 magic、超大头、损坏首字节均得到 `D03 HEADER FAIL`。构建工具拒绝超大 file/memory。第 04 篇 A20 强制关闭后开启、A20 强制失败、E820 容量耗尽、坏 GDT 三重故障以及 MBR/空盘/ELF 样例回归均保留。

固定机器的 E820 实测包含从 `0x100000` 开始的可用 RAM。当前是约定地址、固定机器实验，尚未按任意固件内存图自动选择装载地址，也未实现内存分配、分页、通用 console/printf/panic。
