bits 32
section .entry
global _start
extern kernel_main, __bss_start, __bss_end, __stack_top
_start:
    cld
    mov ebx, esi
%ifndef SKIP_BSS_CLEAR
    mov edi, __bss_start
    mov ecx, __bss_end
    sub ecx, edi
    xor eax, eax
    rep stosb
%endif
    mov esp, __stack_top
    and esp, -16
    sub esp, 12
    push ebx
    call kernel_main
.halt:
    cli
    hlt
    jmp .halt
