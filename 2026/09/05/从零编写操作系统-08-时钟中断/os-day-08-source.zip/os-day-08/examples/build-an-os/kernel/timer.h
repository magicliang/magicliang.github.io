#ifndef TIMER_H
#define TIMER_H
void timer_irq(void);
void timer_demo(unsigned mode);
#endif
