#!/bin/sh
set -eu
export LC_ALL=C
mkdir -p build
test "$(i686-elf-gcc -dumpmachine)" = i686-elf
test "$(i686-elf-gcc -dumpfullversion)" = 13.2.0
i686-elf-ld --version | grep -q '2.42'
nasm -v | grep -q '2.16.01'
"$QEMU" --version | grep -q 'version 7.2.22 '
gdb-multiarch --version | grep -q '13.1'
printf '%s  %s\n' 2da2018c7555e50b660a84a273a14a79cb87b9070fe6a90e9f151a53e357f7e6 /usr/share/seabios/bios-256k.bin | sha256sum -c - > build/bios-check.txt
i686-elf-readelf -h build/sample.elf > build/elf-header.txt
i686-elf-objdump -dr -Mintel build/sample.elf > build/disassembly.txt
nasm -v > build/nasm-version.txt
grep -q 'Class:.*ELF32' build/elf-header.txt
grep -q 'Machine:.*Intel 80386' build/elf-header.txt
grep -q 'Entry point address:.*0x100000' build/elf-header.txt
grep -q '<add_one>:' build/disassembly.txt
if i686-elf-ld -T sample/linker.ld build/entry.o -o build/missing.elf > build/missing-symbol.txt 2>&1; then
    echo 'FAIL: missing add_one unexpectedly linked' >&2
    exit 1
fi
grep -q 'undefined reference.*add_one' build/missing-symbol.txt
test "$(wc -c < build/blank.img)" -eq 1048576
test "$(od -An -tx1 -j510 -N2 build/blank.img | tr -d ' \n')" = 0000
test "$(wc -c < build/mbr.bin)" -eq 512
test "$(od -An -tx1 -j510 -N2 build/mbr.bin | tr -d ' \n')" = 55aa
test "$(od -An -v -tx1 -j446 -N64 build/mbr.bin | tr -d ' \n' | tr -d 0)" = ""
ndisasm -b 16 -o 0x7c00 build/mbr.bin > build/mbr-disassembly.txt
halt_addr="$(awk '$2 == "F4" && $3 == "hlt" { print "0x" $1; exit }' build/mbr-disassembly.txt)"
test -n "$halt_addr"
"$QEMU" $QEMU_BLANK_FLAGS -display none -serial none -monitor none -S -gdb tcp:127.0.0.1:1234 > build/qemu-debug.txt 2>&1 &
qemu_pid=$!
trap 'kill "$qemu_pid" 2>/dev/null || true; wait "$qemu_pid" 2>/dev/null || true' EXIT HUP INT TERM
# GDB retries the connection while QEMU starts; timeout bounds startup failures.
timeout 15 gdb-multiarch -q -nx -batch -ex 'set architecture i386' -ex 'set tcp connect-timeout 5' -ex 'set tcp auto-retry on' -ex 'target remote 127.0.0.1:1234' -ex 'printf "RESET_EIP=%#x\n", $eip' -ex 'x/16bx 0xfffffff0' -ex 'stepi' -ex 'printf "STEP_EIP=%#x\n", $eip' -ex 'disconnect' > build/gdb.txt 2>&1
kill -0 "$qemu_pid"
grep -q 'RESET_EIP=0xfff0' build/gdb.txt
grep -q 'STEP_EIP=' build/gdb.txt
if grep -q 'STEP_EIP=0xfff0' build/gdb.txt; then
    echo 'FAIL: CPU did not advance' >&2
    exit 1
fi
kill "$qemu_pid" 2>/dev/null || true
wait "$qemu_pid" 2>/dev/null || true
trap - EXIT HUP INT TERM
"$QEMU" $QEMU_FLAGS -display none -serial none -monitor none -S -gdb tcp:127.0.0.1:1234 > build/qemu-mbr-debug.txt 2>&1 &
qemu_pid=$!
trap 'kill "$qemu_pid" 2>/dev/null || true; wait "$qemu_pid" 2>/dev/null || true' EXIT HUP INT TERM
timeout 20 gdb-multiarch -q -nx -batch -ex 'set architecture i386' -ex 'set tcp connect-timeout 5' -ex 'set tcp auto-retry on' -ex 'target remote 127.0.0.1:1234' -ex "hbreak *$halt_addr" -ex 'continue' -ex 'printf "MBR_EIP=%#x\n", $eip' -ex 'x/32xb 0xb8000' -ex 'disconnect' > build/gdb-mbr.txt 2>&1
grep -q 'MBR_EIP=' build/gdb-mbr.txt
grep -q '0xb8000:.*0x4f.*0x0f.*0x53.*0x0f.*0x44.*0x0f.*0x41.*0x0f' build/gdb-mbr.txt
grep -q '0xb8008:.*0x59.*0x0f.*0x30.*0x0f.*0x32.*0x0f.*0x20.*0x0f' build/gdb-mbr.txt
grep -q '0xb8010:.*0x44.*0x0f.*0x4c.*0x0f.*0x3d.*0x0f' build/gdb-mbr.txt
kill "$qemu_pid" 2>/dev/null || true
wait "$qemu_pid" 2>/dev/null || true
trap - EXIT HUP INT TERM
timeout 8 "$QEMU" $QEMU_BADSIG_FLAGS -nographic > build/qemu-badsig.txt 2>&1 || true
grep -q 'Boot failed: not a bootable disk' build/qemu-badsig.txt
printf '%s\n' 'PASS: ELF32/i386 entry, missing-symbol rejection, blank disk reset, MBR signature/layout, VGA marker and bad signature path'
