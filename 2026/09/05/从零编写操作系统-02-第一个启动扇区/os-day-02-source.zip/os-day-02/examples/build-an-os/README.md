# 从零编写操作系统：第 02 篇配套实验

本版在第 01 篇的编译链和固件调试基础上，增加第一个 BIOS 可执行的 512 字节启动扇区。`sample.elf` 仍是独立的 ELF32/i386 链接样例；`mbr.img` 才是 QEMU 默认启动的磁盘镜像。尚未实现第二阶段加载器或 C 内核。

## 运行

宿主需要已启动的 Podman Linux 环境。以下命令从本目录执行：

```sh
podman build -t localhost/build-an-os:day01 .
podman run --rm -it -v "$PWD:/work" -w /work localhost/build-an-os:day01 sh
```

在容器中执行：

```sh
make help
make build
make check
make run
make screenshot
```

`make run` 会用 curses 显示启动第 02 篇 MBR。该扇区向 VGA 文本显存写入 `OSDAY02 DL=80` 后停在 `hlt` 循环。`make screenshot` 会把同一屏幕保存到 `build/day02-screen.png`，是本篇非交互复现屏幕结果的稳定入口。

## 手动调试

仍在同一容器中执行：

```sh
make debug &
gdb-multiarch -q
```

GDB 命令：

```text
set architecture i386
target remote 127.0.0.1:1234
info registers eip cs
x/16bx 0xfffffff0
stepi
info registers eip cs
monitor quit
quit
```

`monitor quit` 终止 QEMU 后远程连接会关闭。若 `quit` 询问是否退出活动会话，输入 `y`。不要让手动调试实例与 `make check` 同时占用容器的 1234 端口。调试端口不映射到宿主。

## 文件与证据

- `boot/`：第 02 篇 MBR 启动扇区。
- `sample/`：第 01 篇保留的 C 函数、NASM 汇编入口与链接脚本。
- `tools/check.sh`：ELF 格式、入口、反汇编、缺失符号失败、空盘、MBR 布局、VGA 标识与坏签名路径检查。
- [环境记录](docs/environment.md)：实测版本、来源和复现边界。
- [实验记录](docs/day01-evidence.md)：实际输出与手动场景。
- [第 02 篇实验记录](docs/day02-evidence.md)：启动扇区、显存与坏签名证据。

生成文件全部进入忽略的 `build/`。交叉 GCC 当前只构建 C 编译器，不包含目标 libc 或 libgcc；本例不需要这些库，后续内核运行时另行补齐。
