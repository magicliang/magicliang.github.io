bits 16
org 0x7c00

start:
    cli
    cld
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7c00
    sti

    mov [boot_drive], dl
    mov ax, 0xb800
    mov es, ax
    xor di, di
    mov ax, 0x0720
    mov cx, 80 * 25
    rep stosw
    xor di, di
    mov si, message

.write:
    lodsb
    test al, al
    jz .done
    mov ah, 0x0f
    stosw
    jmp .write

.done:
    mov al, [boot_drive]
    call write_hex8

hang:
    hlt
    jmp hang

write_hex8:
    push ax
    shr al, 4
    call write_hex4
    pop ax
    and al, 0x0f
    call write_hex4
    ret

write_hex4:
    cmp al, 10
    jb .digit
    add al, 'A' - 10
    jmp .emit

.digit:
    add al, '0'

.emit:
    mov ah, 0x0f
    stosw
    ret

message:
    db 'OSDAY02 DL=', 0

boot_drive:
    db 0

times 446 - ($ - $$) db 0
times 64 db 0
dw 0xaa55
