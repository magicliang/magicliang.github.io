# 从零编写操作系统：第 06 篇配套实验

当前启动路径执行真实 C 内核：交叉编译生成 `kernel.elf`，`objcopy` 提取可装载字节；stage2 沿用镜像头和 checksum，暂存于 `0x10000`，完成 E820、A20 与保护模式切换后复制到 `0x100000`。内核入口清 BSS、建立 16 KiB 栈，并按 cdecl 传入 BootInfo。没有分页，也没有在启动器中增加通用 ELF 解析器。

## 运行

在本目录执行，宿主已有启动的 Podman Linux 环境：

```sh
podman run --rm -it -v "$PWD:/work" -w /work localhost/build-an-os:day01 sh
```

容器中执行：

```sh
make build
make check
make run
make screenshot
```

首次没有工具链镜像时才运行 `podman build -t localhost/build-an-os:day01 .`。现有镜像不需要重建。

正常串口先保留 `D04 PM OK - BootInfo v1`、`KERNEL_MAIN OK`，最后输出 `CONSOLE OK`。C 内核初始化会清屏；滚屏演示后 VGA 首行为 `scroll 9`，末尾为格式化边界与成功标识。截图生成于 `build/day06-screen.png`。

`make check-console` 检查真实 COM1/VGA、80 列换行、滚屏、格式化边界、串口持续不就绪和独立 `mbr-panic.img` 的断言停机；`make check-pm` 保留第 04 篇保护模式和故障实验；`make check-kernel` 验证第 05 篇入口、装载边界、C ABI、运行时函数与坏 BSS；`make check` 同时跑此前 ELF、读盘、坏头、损坏、截短和坏签名回归。检查共用容器内 GDB 1234 端口，不要另开调试实例同时运行。

## 手动调试

同一容器内执行：

```sh
make debug &
gdb-multiarch build/kernel.elf
```

GDB 中执行：

```text
target remote 127.0.0.1:1234
hbreak *kernel_main
continue
info registers esp cr0
x/wx $esp+4
p/x initialized
p/x zeroed
p/x &__stack_top
monitor quit
quit
```

必须用 `hbreak *kernel_main` 才停在函数第一条指令、尚未执行 C 序言的位置；此时 `ESP % 16 = 12`，返回地址后面的参数是 `0x5000`。`call` 之前 ESP 为 16 字节对齐。`monitor quit` 会关闭远程连接。

## 文件与契约

- `kernel/`：C 内核、入口、链接脚本与四个最小内存函数；`sample/` 仍保留第 01 篇独立链接样例。
- `boot/`：累计 MBR、stage2 和 BootInfo v1。BootInfo 仍为 40 字节，payload 字段仍表示低端暂存位置及文件长度；最终内核地址由链接契约固定。
- `tools/kernel-header.sh`：从 ELF 符号与入口提取 memory/entry，核对 binary 文件长度；`mkpayload.c` 读取实际 binary，生成校验和与坏头，不再制造确定性载荷。
- `tools/check-kernel.sh`：GDB 比较装载字节、清零前后 BSS、参数、栈和已初始化数据，并检查正常、跳过清零和单扇区分批读取镜像。
- [第 05 篇实测记录](docs/day05-evidence.md)：地址、命令、结果和运行边界；此前的 [01](docs/day01-evidence.md)、[02](docs/day02-evidence.md)、[03](docs/day03-evidence.md)、[04](docs/day04-evidence.md) 记录对应当时快照。

所有产物写入忽略的 `build/`。当前工具链没有目标 libc/libgcc；最终 ELF 的未定义符号必须为空，编译禁止 SSE、MMX 和硬件浮点。本篇不安装 IDT、不开放 IRQ、不实现分页或动态分配。

## Console 与 panic 契约

初始化顺序是 stage2 完成 BIOS/E820/A20 → 保护模式复制内核 → entry 清 BSS、建栈 → `console_init` 配置 UART 并清 VGA → BootInfo/data/BSS/runtime 自检 → 格式化与滚屏演示。坏 BSS 镜像会在输出模块显式重置自身状态后继续报告 `KERNEL BSS FAIL`。

COM1 为 115200、8N1、无中断轮询。单次发送最多读取 LSR 100000 次；超限后停用串口，后续 VGA 仍可用。这是迭代上限，不是毫秒期限。VGA 固定 `0xb8000`、80×25、白字黑底，换行归零列并下移、回车归零列、退格擦除前一格（可跨行），最底行继续输出时向上搬移 24 行。

`kprintf` 仅支持 `%s %c %d %u %x %p %%`；`%p` 是带 `0x` 的不补零 32 位十六进制，`%s` 空指针输出 `(null)`。不支持宽度、精度、长度修饰、浮点或 UTF-8 排版；未知转换原样输出且不消费参数，末尾孤立 `%` 原样输出。格式串和非空字符串指针必须有效，参数类型需匹配。串口把 LF 转成 CRLF，CR/BS 直接发送；VGA 的退格擦除不等同于所有串口终端的显示策略。

`KASSERT` 失败先 `cli`，再把文件、行号和表达式同时写往两端，最后在 `panic_halt` 的 `hlt/jmp` 循环停机。它保留当前栈供 GDB 查看，不是任意 CPU 异常的寄存器捕获器。当前单核且未开启 IRQ，不提供可重入或多核输出锁。

[第 06 篇实测记录](docs/day06-evidence.md) 包含可重跑命令、真实输出、故障注入方式与证据路径。`build/mbr-panic.img` 只替换 C 内核，不修改正常镜像。
