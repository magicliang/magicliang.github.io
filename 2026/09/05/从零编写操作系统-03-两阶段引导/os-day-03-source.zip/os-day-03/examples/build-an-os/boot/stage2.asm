bits 16
org 0x8000

%include "build/layout.inc"
HEADER_SEGMENT equ 0x0900
HEADER_OFFSET equ 0
HEADER_FILE_SIZE equ 8
HEADER_MEMORY_SIZE equ 12
HEADER_ENTRY equ 16
HEADER_CHECKSUM equ 20
HEADER_FIRST_MARKER equ 24
HEADER_LAST_MARKER equ 40
FIRST_MARKER_LEN equ 16
LAST_MARKER_LEN equ 15

start:
    cli
    cld
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7c00
    mov [boot_drive], dl
    call serial_init

    mov ax, 0xb800
    mov es, ax
    mov di, 320
    mov si, stage2_msg
    call write_string
    mov si, stage2_msg
    call serial_write

    call check_edd
    call read_header
    call validate_header
    call read_payload
    call verify_payload
    xor ax, ax
    mov ds, ax
    mov ax, 0xb800
    mov es, ax
    mov di, 480
    mov si, ok_msg
    call write_string
    mov si, ok_msg
    call serial_write
    mov di, 640
    mov si, halt_msg
    call write_string
.hang:
    cli
    hlt
    jmp .hang

check_edd:
    mov ah, 0x41
    mov bx, 0x55aa
    mov dl, [boot_drive]
    int 0x13
    jc header_error
    cmp bx, 0xaa55
    jne header_error
    test cx, 1
    jz header_error
    ret

read_header:
    mov word [dap_count], 1
    mov word [dap_offset], HEADER_OFFSET
    mov word [dap_segment], HEADER_SEGMENT
    mov dword [dap_lba], HEADER_LBA
    mov dword [dap_lba + 4], 0
    call read_dap
    ret

validate_header:
    mov ax, HEADER_SEGMENT
    mov ds, ax
    cmp dword [HEADER_OFFSET], HEADER_MAGIC
    jne header_error
    cmp dword [HEADER_OFFSET + 4], HEADER_VERSION
    jne header_error
    mov eax, [HEADER_OFFSET + HEADER_FILE_SIZE]
    test eax, eax
    jz header_error
    cmp eax, 64
    jb header_error
    cmp eax, PAYLOAD_MAX_BYTES
    ja header_error
    xor bx, bx
    mov es, bx
    mov [es:file_size], eax
    mov eax, [HEADER_OFFSET + HEADER_MEMORY_SIZE]
    cmp eax, [es:file_size]
    jb header_error
    cmp eax, PAYLOAD_MAX_BYTES
    ja header_error
    mov eax, [HEADER_OFFSET + HEADER_ENTRY]
    cmp eax, [es:file_size]
    jae header_error
    mov ax, [HEADER_OFFSET + HEADER_CHECKSUM]
    mov [es:expected_checksum], ax
    xor ax, ax
    mov ds, ax
    ret

read_payload:
    mov eax, [file_size]
    add eax, 511
    shr eax, 9
    mov [remaining_sectors], ax
    mov word [buffer_segment], PAYLOAD_SEGMENT
    mov dword [next_lba], PAYLOAD_LBA
    mov dword [next_lba + 4], 0

.next:
    mov ax, [remaining_sectors]
    test ax, ax
    jz .done
    cmp ax, READ_CHUNK_SECTORS
    jbe .use_remaining
    mov ax, READ_CHUNK_SECTORS

.use_remaining:
    mov [dap_count], ax
    mov [last_count], ax
    mov word [dap_offset], 0
    mov bx, [buffer_segment]
    mov [dap_segment], bx
    mov eax, [next_lba]
    mov [dap_lba], eax
    mov eax, [next_lba + 4]
    mov [dap_lba + 4], eax
    call read_dap
    mov ax, [last_count]
    sub [remaining_sectors], ax
    movzx eax, ax
    add [next_lba], eax
    adc dword [next_lba + 4], 0
    shl ax, 5
    add [buffer_segment], ax
    jmp .next

.done:
    ret

read_dap:
    xor ax, ax
    mov ds, ax
    mov si, dap
    mov ah, 0x42
    mov dl, [boot_drive]
    int 0x13
    jc read_error
    ret

verify_payload:
    xor ax, ax
    mov es, ax
    mov ax, PAYLOAD_SEGMENT
    mov ds, ax
    xor si, si
    mov di, first_marker
    mov cx, FIRST_MARKER_LEN
    call compare_bytes
    jc header_error
    mov eax, [es:file_size]
    sub eax, LAST_MARKER_LEN
    mov si, ax
    mov di, last_marker
    mov cx, LAST_MARKER_LEN
    call compare_bytes
    jc header_error
    call checksum_payload
    cmp ax, [es:expected_checksum]
    jne header_error
    ret

compare_bytes:
    repe cmpsb
    jne .bad
    clc
    ret
.bad:
    stc
    ret

checksum_payload:
    mov ax, PAYLOAD_SEGMENT
    mov ds, ax
    xor esi, esi
    mov ecx, [es:file_size]
    xor ebx, ebx
.next_byte:
    test ecx, ecx
    jz .done
    xor eax, eax
    mov al, [esi]
    add bx, ax
    inc esi
    dec ecx
    jmp .next_byte
.done:
    mov ax, bx
    ret

serial_init:
    mov dx, 0x3f9
    xor al, al
    out dx, al
    mov dx, 0x3fb
    mov al, 0x80
    out dx, al
    mov dx, 0x3f8
    mov al, 0x03
    out dx, al
    mov dx, 0x3f9
    xor al, al
    out dx, al
    mov dx, 0x3fb
    mov al, 0x03
    out dx, al
    mov dx, 0x3fa
    mov al, 0xc7
    out dx, al
    mov dx, 0x3fc
    mov al, 0x0b
    out dx, al
    ret

header_error:
    xor ax, ax
    mov ds, ax
    mov ax, 0xb800
    mov es, ax
    mov di, 480
    mov si, header_err_msg
    call write_string
    mov si, header_err_msg
    call serial_write
    jmp halt

read_error:
    xor ax, ax
    mov ds, ax
    mov ax, 0xb800
    mov es, ax
    mov di, 480
    mov si, read_err_msg
    call write_string
    mov si, read_err_msg
    call serial_write

halt:
    cli
    hlt
    jmp halt

write_string:
    lodsb
    test al, al
    jz .ret
    mov ah, 0x0e
    stosw
    jmp write_string
.ret:
    ret

serial_write:
    lodsb
    test al, al
    jz .newline
    call serial_putc
    jmp serial_write

.newline:
    mov al, 13
    call serial_putc
    mov al, 10
    call serial_putc
    ret

serial_putc:
    push ax
.wait:
    mov dx, 0x3fd
    in al, dx
    test al, 0x20
    jz .wait
    pop ax
    mov dx, 0x3f8
    out dx, al
    ret

stage2_msg:
    db 'D03 STAGE2 OK', 0
ok_msg:
    db 'D03 PAYLOAD OK', 0
halt_msg:
    db 'D03 HALT', 0
header_err_msg:
    db 'D03 HEADER FAIL', 0
read_err_msg:
    db 'D03 READ FAIL', 0
first_marker:
    db 'D03PAYLOAD-BEGIN'
last_marker:
    db 'D03PAYLOAD-END!'
boot_drive:
    db 0
remaining_sectors:
    dw 0
buffer_segment:
    dw 0
last_count:
    dw 0
next_lba:
    dq 0
file_size:
    dd 0
expected_checksum:
    dw 0

align 4
dap:
    db 0x10
    db 0
dap_count:
    dw 0
dap_offset:
    dw 0
dap_segment:
    dw 0
dap_lba:
    dq 0

times 4096 - ($ - $$) db 0
