#include <stdint.h>
#include <stddef.h>
#include "runtime.h"

struct bootinfo {
    uint32_t magic;
    uint16_t version, size;
    uint8_t drive, reserved[3];
    uint32_t map;
    uint16_t count, stride;
    uint32_t payload, payload_bytes, video;
    uint16_t columns, rows, pitch;
    uint8_t mode, cell_bytes;
};
_Static_assert(sizeof(struct bootinfo) == 40, "BootInfo v1 size");
_Static_assert(offsetof(struct bootinfo, video) == 28, "BootInfo video offset");
volatile uint32_t initialized = 0x12345678;
volatile uint32_t zeroed;
volatile uint8_t zero_array[37];

static void result(const char *text)
{
    volatile uint16_t *screen = (volatile uint16_t *)0xb80a0;
    for (; *text; ++text) {
        uint8_t ready;
        *screen++ = 0x0f00 | (uint8_t)*text;
        do { __asm__ volatile ("inb %1, %0" : "=a"(ready) : "Nd"((uint16_t)0x3fd)); } while (!(ready & 0x20));
        __asm__ volatile ("outb %0, %1" : : "a"((uint8_t)*text), "Nd"((uint16_t)0x3f8));
    }
    __asm__ volatile ("outb %0, %1" : : "a"((uint8_t)'\n'), "Nd"((uint16_t)0x3f8));
}

static uint32_t add_one(uint32_t value) { return value + 1; }

void kernel_main(const struct bootinfo *info)
{
    if (info->magic != 0x31495442 || info->version != 1 || info->size != sizeof(*info)) {
        result("KERNEL BOOTINFO FAIL"); return;
    }
    if (initialized != 0x12345678 || add_one(41) != 42) {
        result("KERNEL DATA/CALL FAIL"); return;
    }
    if (zeroed != 0) { result("KERNEL BSS FAIL"); return; }
    for (size_t i = 0; i < sizeof(zero_array); ++i)
        if (zero_array[i] != 0) { result("KERNEL BSS FAIL"); return; }
    char bytes[8];
    memset(bytes, 0, sizeof(bytes));
    memcpy(bytes, "abcd", 4);
    memmove(bytes + 1, bytes, 4);
    if (memcmp(bytes, "aabcd", 5) != 0) { result("KERNEL RUNTIME FAIL"); return; }
    memmove(bytes, bytes + 1, 4);
    if (memcmp(bytes, "abcd", 4) != 0 || bytes[7] != 0) { result("KERNEL RUNTIME FAIL"); return; }
    result("KERNEL_MAIN OK");
}
