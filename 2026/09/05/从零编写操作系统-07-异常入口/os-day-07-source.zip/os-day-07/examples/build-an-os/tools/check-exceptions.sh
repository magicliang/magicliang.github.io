#!/bin/sh
set -eu
for variant in normal divide ud2 gp; do
    elf=build/kernel.elf
    disk=build/mbr.img
    if [ "$variant" != normal ]; then elf=build/kernel-$variant.elf; disk=build/mbr-$variant.img; fi
    "$QEMU" $QEMU_COMMON -drive file="$disk",format=raw,if=ide -display none -serial file:build/exception-$variant-serial.txt -monitor none -S -gdb tcp:127.0.0.1:1234 > build/exception-$variant-qemu.txt 2>&1 &
    qemu_pid=$!
    trap 'kill "$qemu_pid" 2>/dev/null || true; wait "$qemu_pid" 2>/dev/null || true' EXIT HUP INT TERM
    cat > build/exceptions.gdb <<GDB
set architecture i386
set tcp connect-timeout 5
set tcp auto-retry on
file $elf
target remote 127.0.0.1:1234
hbreak *trap_dispatch
continue
python
import gdb, struct
m = gdb.selected_inferior()
u32 = lambda a: struct.unpack('<I', bytes(m.read_memory(a,4)))[0]
esp = int(gdb.parse_and_eval('\$esp'))
assert esp % 16 == 12
assert int(gdb.parse_and_eval('\$eflags')) & 0x600 == 0
fp = u32(esp+4)
f = struct.unpack('<17I', bytes(m.read_memory(fp,68)))
assert f[:4] == (16,16,16,16)
assert f[4:7] == (0x77777777,0x66666666,0x55555555)
assert f[7] == fp+48
assert f[8:12] == (0x44444444,0x33333333,0x22222222,0x11111111)
assert f[12:16] == (3,0,int(gdb.parse_and_eval('&probe_resume')),8)
assert f[16] & 0x600 == 0x400
assert int(gdb.parse_and_eval('idtr.limit')) == 2047
assert all(int(gdb.parse_and_eval('idt[%d].flags'%i)) == (0x8e if i < 32 else 0) for i in range(256))
print('PASS: frame', tuple(hex(x) for x in f), 'C ESP', hex(esp), 'DF=0')
end
delete breakpoints
hbreak *probe_restored
continue
python
r = struct.unpack('<9I', bytes(m.read_memory(int(gdb.parse_and_eval('\$esp')),36)))
assert r[:3] == f[4:7] and r[4:8] == f[8:12]
assert r[3] == fp+64
assert r[8] == f[16]
assert int(gdb.parse_and_eval('\$eflags')) & 0x400
print('PASS: IRETD restored all GPRs, ESP and EFLAGS including DF')
end
delete breakpoints
GDB
    if [ "$variant" = normal ]; then
        printf "monitor screendump build/day07-screen.png -f png\n" >> build/exceptions.gdb
        cat >> build/exceptions.gdb <<'GDB'
hbreak _start.halt
continue
python
assert int(gdb.parse_and_eval('breakpoint_count')) == 1
assert int(gdb.parse_and_eval('$eflags')) & 0x600 == 0
print('PASS: normal boot resumed through console demo')
end
monitor screendump build/day07-console.png -f png
GDB
    else
        case "$variant" in divide) vector=0; error=0; label=divide_fault;; ud2) vector=6; error=0; label=ud_fault;; gp) vector=13; error=24; label=gp_fault;; esac
        cat >> build/exceptions.gdb <<GDB
hbreak *trap_dispatch
continue
python
esp = int(gdb.parse_and_eval('\$esp'))
f = struct.unpack('<17I', bytes(m.read_memory(u32(esp+4),68)))
assert esp % 16 == 12
assert f[12:16] == ($vector,$error,int(gdb.parse_and_eval('&$label')),8)
assert int(gdb.parse_and_eval('\$eflags')) & 0x600 == 0
print('PASS: $variant CPU fault frame', tuple(hex(x) for x in f))
end
delete breakpoints
hbreak *panic_halt
continue
python
assert bytes(m.read_memory(int(gdb.parse_and_eval('\$eip')),1)) == b'\\xf4'
print('PASS: exception panic reached HLT')
end
monitor screendump build/day07-$variant.png -f png
GDB
    fi
    printf 'disconnect\n' >> build/exceptions.gdb
    timeout 20 gdb-multiarch -q -nx -batch -x build/exceptions.gdb > build/gdb-exception-$variant.txt 2>&1
    grep -q 'PASS: IRETD' build/gdb-exception-$variant.txt
    kill "$qemu_pid" 2>/dev/null || true
    wait "$qemu_pid" 2>/dev/null || true
    trap - EXIT HUP INT TERM
    { sleep 2; printf 'info registers\nquit\n'; } | "$QEMU" $QEMU_COMMON -drive file="$disk",format=raw,if=ide -display none -serial file:build/exception-$variant-halted-serial.txt -monitor stdio > build/exception-$variant-registers.txt 2>&1
    grep -q 'HLT=1' build/exception-$variant-registers.txt
    if [ "$variant" = normal ]; then
        grep -q 'CONSOLE OK' build/exception-$variant-halted-serial.txt
        ! grep -q PANIC build/exception-$variant-halted-serial.txt
    else
        grep -q "EXCEPTION vector=$vector error=$(printf '%x' "$error")" build/exception-$variant-halted-serial.txt
        grep -q 'unhandled CPU exception' build/exception-$variant-halted-serial.txt
    fi
done
printf '%s\n' 'PASS: INT3 recovery, CPU #DE/#UD/#GP frames, ABI/DF/GPR restore and actual HLT'
