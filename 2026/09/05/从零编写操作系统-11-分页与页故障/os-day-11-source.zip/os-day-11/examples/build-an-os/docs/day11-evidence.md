# 第 11 篇：分页与页故障实测

日期：2026-09-05。环境沿用 `localhost/build-an-os:day01`；QEMU `pc-i440fx-7.2`、TCG、qemu32、单 CPU、64 MiB、SeaBIOS、IDE raw。未安装或重建工具链。此记录对应本篇累计源码；历史篇地址以各自冻结快照为准。

## 重跑

在 `examples/build-an-os` 目录执行单行命令：

```sh
podman run --rm -v "$PWD:/work" -w /work localhost/build-an-os:day01 make check-paging
podman run --rm -v "$PWD:/work" -w /work localhost/build-an-os:day01 make check
podman run --rm -v "$PWD:/work" -w /work localhost/build-an-os:day01 make screenshot
```

检查脚本共享 GDB 1234 端口，Makefile 串行执行检查。`screenshot` 包含真实分页检查，输出正常镜像 `day11-screen.png` 和独立故障镜像 `day11-pagefault.png`；故障变体不会覆盖正常截图。

## 正常客体结果

`kernel.bin` 15748 字节，完整运行区终点 `__kernel_end=0x109750`，包含 BSS、位图和 16 KiB 栈，仍在 64 KiB loader 内存上限之内。页表来自分配器，不占静态 68 KiB BSS。

```text
E820 records=6 free=16086 kernel_end=0x109750
PG+WP enabled CR3=0x10a000 same stack=0x1096f0
remap A -> B + INVLPG OK
PAGE FAULT CR2=0x40000000 error=0 EIP=0x102cd0
nonpresent read repaired; same EIP retry OK
PAGE FAULT CR2=0x40000000 error=3 EIP=0x102cd6
WP readonly write repaired; same EIP retry OK
PAGING OK retained tables=18 free=16068
```

GDB 检查 CR0.PE/PG/WP 全为 1，CR4.PAE/PSE/PGE 为 0，CR3 等于对齐物理页目录地址。逐项核对 16384 个低地址 PTE 的物理页号和 P/RW/US=1/1/0，以及 16 个低地址 PDE、独立高地址 PDE 和其余空 PDE。开分页前后保存的 ESP 相等且位于原 C 栈内；之后正常运行到 `keyboard_ready`。

A/B 内容分别为 `0x12345678`、`0x87654321`。先读 A，再更新同一 VA 的 PTE 并 `INVLPG`，真实读到 B。未映射 read 与 present readonly write 均由 CPU 产生 #PF；GDB 在 handler 核对 CR2、vector=14、错误码、精确汇编 EIP、当前 PTE 和预期阶段，然后在相同汇编指令再次命中硬件断点，确认没有跳过指令。恢复写入后物理 B 内容是 `0xfeedface`。

最终高地址 PTE 清零，A/B 在 `INVLPG` 后释放；GDB 确认 allocated 位图恰好 18 位，目录、16 个 identity 页表和 1 个高地址页表均仍归分配器持有。初始化表树时若分配失败，按已分配数量释放；该回滚分支通过代码检查，未把低内存失败注入声称为客体实测。

## 未处理故障

`mbr-pagefault.img` 完成相同测试后，在没有武装恢复条件时再次执行高地址读。打印 CR2、原始错误码及完整同级 trap frame 后进入 `panic_halt`；GDB 检查该地址确为 HLT 指令，另一次自由运行由 QEMU monitor 得到 `HLT=1`，串口含 `unhandled page fault`。该镜像与正常镜像使用不同 ELF，故障变体代码地址不能替代上面的正常地址。

产物均在忽略的 `build/`：`paging-{normal,pagefault}-{serial,gdb}.txt`、`paging-halted-{serial,registers}.txt`、两张 PNG。GDB 脚本还断言每个检查点；不是仅靠串口 PASS 标记判断成功。

## 回归结果

完整 `make check` 退出码 0；既有 ELF/装载/保护模式/C 入口/console/CPU 异常/时钟/键盘/物理页检查全部保留并通过。没有删除或放宽历史测试断言。

## 边界

低 64 MiB 全部 supervisor RW，包括内核 text、VGA、页表与物理页的 identity 别名。高地址 readonly 测试仅约束该虚拟别名；同一物理页仍有 RW identity 别名，因此不声称内核 text 只读、W^X 或安全隔离。映射 MMIO/保留空洞不等于把它们释放给分配器，演示不主动读写这些空洞。

当前固定非 PAE 4 KiB 分页，无 NX、ring 3、进程地址空间、多核 TLB shootdown 或通用 VM API。PSE=0 的模式未构造保留位错误测试。handler 在输出前保存 CR2，仅修复精确白名单故障，不分配内存、不调整 EIP；其他故障停机。活跃表树建立后不再调用分配器初始化或释放活跃表页。
