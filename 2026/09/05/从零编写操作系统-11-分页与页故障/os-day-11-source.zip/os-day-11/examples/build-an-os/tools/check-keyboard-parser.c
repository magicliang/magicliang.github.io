#include <assert.h>
#include <stdio.h>
#include "../kernel/keyboard.h"
int main(void)
{
    struct key_parser p = {0};
    assert(keyboard_parse(&p, 30) == 'a');
    assert(!keyboard_parse(&p, 0x9e));
    keyboard_parse(&p, 42); keyboard_parse(&p, 54); keyboard_parse(&p, 0xaa);
    assert(keyboard_parse(&p, 30) == 'A');
    keyboard_parse(&p, 0xb6); assert(keyboard_parse(&p, 30) == 'a');
    keyboard_parse(&p, 58); keyboard_parse(&p, 58);
    assert(keyboard_parse(&p, 30) == 'A');
    keyboard_parse(&p, 42); assert(keyboard_parse(&p, 30) == 'a');
    assert(keyboard_parse(&p, 2) == '!');
    keyboard_parse(&p, 0xaa); keyboard_parse(&p, 0xba); keyboard_parse(&p, 58);
    keyboard_parse(&p, 0xba);
    unsigned char special[] = {0xe1,0x1d,0x45,0xe1,0x9d,0xc5,0xe0,0x2a,0xe0,0x37,0xe0,0xb7,0xe0,0xaa};
    for (unsigned i=0; i<sizeof special; ++i) assert(!keyboard_parse(&p, special[i]));
    assert(keyboard_parse(&p, 30) == 'a');
    keyboard_parse(&p, 0xe1); keyboard_parse(&p, 0x1d);
    assert(keyboard_parse(&p, 30) == 'a'); /* finite mismatch recovery */
    keyboard_parse(&p, 0xe0); assert(!keyboard_parse(&p, 30));
    assert(keyboard_parse(&p, 30) == 'a'); /* truncated E0 consumes one byte */
    assert(keyboard_parse(&p, 14) == '\b' && keyboard_parse(&p, 28) == '\n');
    puts("PASS: set1 release, dual Shift, Caps repeat/XOR, Pause/PrintScreen and partial prefixes");
}
