#include "memory.h"
#include "runtime.h"
#include "console.h"

#define FRAMES (MEMORY_CAP / PAGE_BYTES)
struct e820 { uint64_t base, length; uint32_t type, attributes; };
_Static_assert(sizeof(struct e820) == 24, "normalized E820 stride");
static uint8_t eligible[FRAMES / 8], allocated[FRAMES / 8];
static uint32_t free_pages, next_frame;
volatile uint32_t memory_initial_pages, memory_exhausted_pages, memory_test_passed;
extern char __kernel_start[], __kernel_end[];

static uint32_t irq_save(void)
{
    uint32_t flags;
    __asm__ volatile("pushfl; popl %0; cli" : "=r"(flags) : : "memory");
    return flags;
}
static void irq_restore(uint32_t flags)
{
    __asm__ volatile("pushl %0; popfl" : : "r"(flags) : "memory", "cc");
}
static int bit(const uint8_t *map, unsigned n) { return (map[n / 8] >> (n % 8)) & 1; }
static void set(uint8_t *map, unsigned n) { map[n / 8] |= 1u << (n % 8); }
static void clear(uint8_t *map, unsigned n) { map[n / 8] &= ~(1u << (n % 8)); }

/* Validate before clipping. Unsupported attributes reserve, never release. */
static int map_build(const struct e820 *map, unsigned count)
{
    memset(eligible, 0, sizeof(eligible));
    memset(allocated, 0, sizeof(allocated));
    free_pages = 0;
    next_frame = 0;
    for (unsigned i = 0; i < count; ++i)
        if (!map[i].length || map[i].length > UINT64_MAX - map[i].base) return 0;
    for (unsigned reserve = 0; reserve < 2; ++reserve) {
        for (unsigned i = 0; i < count; ++i) {
            int usable = map[i].type == 1 && map[i].attributes == 1;
            if (usable == (int)reserve || map[i].base >= MEMORY_CAP) continue;
            uint64_t end64 = map[i].base + map[i].length;
            uint32_t start = (uint32_t)map[i].base;
            uint32_t end = end64 > MEMORY_CAP ? MEMORY_CAP : (uint32_t)end64;
            unsigned first = reserve ? start / PAGE_BYTES : (start + PAGE_BYTES - 1) / PAGE_BYTES;
            unsigned last = reserve ? (end + PAGE_BYTES - 1) / PAGE_BYTES : end / PAGE_BYTES;
            for (unsigned n = first; n < last; ++n) {
                if (reserve) clear(eligible, n); else set(eligible, n);
            }
        }
    }
    for (unsigned n = 0; n < FRAMES; ++n) {
        uint32_t address = n * PAGE_BYTES;
        if (address < 0x100000 || (address < (uintptr_t)__kernel_end &&
            address + PAGE_BYTES > (uintptr_t)__kernel_start)) clear(eligible, n);
        free_pages += bit(eligible, n);
    }
    return 1;
}

uint32_t page_alloc(void)
{
    uint32_t flags = irq_save(), address = 0;
    if (free_pages) for (unsigned n = next_frame; n < FRAMES; ++n) {
        if (bit(eligible, n) && !bit(allocated, n)) {
            set(allocated, n); --free_pages; next_frame = n + 1;
            address = n * PAGE_BYTES; break;
        }
    }
    irq_restore(flags);
    return address;
}
int page_free(uint32_t address)
{
    uint32_t flags = irq_save();
    int ok = 0;
    if (address < MEMORY_CAP && address % PAGE_BYTES == 0) {
        unsigned n = address / PAGE_BYTES;
        if (bit(eligible, n) && bit(allocated, n)) {
            clear(allocated, n); ++free_pages;
            if (n < next_frame) next_frame = n;
            ok = 1;
        }
    }
    irq_restore(flags);
    return ok;
}
uint32_t page_free_count(void)
{
    uint32_t flags = irq_save(), count = free_pages;
    irq_restore(flags);
    return count;
}

static void synthetic_checks(void)
{
    struct e820 map[] = {
        {0x200001, 0x9fff, 1, 1}, {0x203fff, 2, 2, 1},
        {0x205010, 1, 1, 0}, {0x206010, 1, 99, 1},
        {0x207010, 1, 1, 9}, {0x100000000ull, 0x10000, 1, 1}
    };
    KASSERT(map_build(map, 6));
    KASSERT(!bit(eligible, 0x200) && bit(eligible, 0x201) && bit(eligible, 0x202));
    for (unsigned n = 0x203; n <= 0x207; ++n) KASSERT(!bit(eligible, n));
    KASSERT(bit(eligible, 0x208) && bit(eligible, 0x209) && free_pages == 4);
    struct e820 swap = map[0]; map[0] = map[1]; map[1] = swap;
    KASSERT(map_build(map, 6) && free_pages == 4 && !bit(eligible, 0x203));
    map[0] = (struct e820){MEMORY_CAP - 4096, 8192, 1, 1};
    KASSERT(map_build(map, 1) && free_pages == 1 && bit(eligible, FRAMES - 1));
    map[0] = (struct e820){UINT64_MAX - 7, 16, 1, 1};
    KASSERT(!map_build(map, 1) && free_pages == 0);
    map[0] = (struct e820){0x200000, 0, 1, 1};
    KASSERT(!map_build(map, 1));
    kprintf("SYNTHETIC map overlap/round/high/overflow OK\n");
}
void memory_demo_done(void) { __asm__ volatile("" : : : "memory"); }
void memory_demo(const struct bootinfo *info)
{
    console_init();
    kprintf("D10 physical pages 4 KiB cap=64 MiB\n");
    synthetic_checks();
    KASSERT(info->map == 0x5100 && info->stride == 24 && info->count && info->count <= 32);
    KASSERT(map_build((const struct e820 *)(uintptr_t)info->map, info->count));
    memory_initial_pages = page_free_count();
    KASSERT(memory_initial_pages > 3);
    kprintf("E820 records=%u free=%u kernel_end=%p\n", (unsigned)info->count,
            memory_initial_pages, __kernel_end);
    uint32_t saved = irq_save();
    KASSERT(!(saved & 0x200));
    uint32_t a = page_alloc();
    uint32_t observed = irq_save();
    KASSERT(!(observed & 0x200));
    __asm__ volatile("sti" : : : "memory");
    uint32_t b = page_alloc();
    observed = irq_save();
    KASSERT(observed & 0x200);
    irq_restore(observed);
    KASSERT(page_free(b));
    observed = irq_save();
    KASSERT(observed & 0x200);
    irq_restore(saved);
    b = page_alloc();
    kprintf("allocator preserves IF=0 and IF=1 OK\n");
    KASSERT(a && b && a != b && !(a % PAGE_BYTES) && !(b % PAGE_BYTES));
    *(volatile uint32_t *)(uintptr_t)a = 0x12345678;
    *(volatile uint32_t *)(uintptr_t)b = 0x87654321;
    KASSERT(*(volatile uint32_t *)(uintptr_t)a == 0x12345678);
    KASSERT(*(volatile uint32_t *)(uintptr_t)b == 0x87654321);
    uint32_t before = page_free_count();
    KASSERT(!page_free(a + 1) && !page_free(0) && !page_free(0x100000));
    KASSERT(!page_free(MEMORY_CAP) && page_free_count() == before);
    KASSERT(page_free(a) && !page_free(a) && page_free_count() == before + 1);
    KASSERT(page_free(b) && page_free_count() == memory_initial_pages);
    kprintf("unique/write/free OK; invalid/double free rejected\n");
    unsigned count = 0;
    uint32_t address, last = 0;
    while ((address = page_alloc()) != 0) {
        KASSERT(address > last); last = address;
        volatile uint32_t *page = (volatile uint32_t *)(uintptr_t)address;
        for (unsigned j = 0; j < PAGE_BYTES / 4; ++j) page[j] = address ^ j;
        ++count;
    }
    memory_exhausted_pages = count;
    KASSERT(count == memory_initial_pages && page_free_count() == 0 && !page_alloc());
    KASSERT(page_free(last) && page_alloc() == last && !page_alloc());
    for (unsigned n = 0; n < FRAMES; ++n) if (bit(allocated, n)) {
        address = n * PAGE_BYTES;
        volatile uint32_t *page = (volatile uint32_t *)(uintptr_t)address;
        for (unsigned j = 0; j < PAGE_BYTES / 4; ++j) KASSERT(page[j] == (address ^ j));
        KASSERT(page_free(address));
    }
    KASSERT(page_free_count() == memory_initial_pages);
    kprintf("exhausted=%u one-page reuse OK\n", count);
    kprintf("all-page patterns OK recovered=%u\n", page_free_count());
    memory_test_passed = 1;
    kprintf("MEMORY OK\n");
    memory_demo_done();
}
