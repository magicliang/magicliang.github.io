#ifndef KEYBOARD_H
#define KEYBOARD_H
#include <stdint.h>
struct key_parser { uint8_t left, right, caps, caps_down, extended, pause; };
int keyboard_parse(struct key_parser *p, uint8_t byte);
void keyboard_irq(void);
void keyboard_loop(void);
#endif
