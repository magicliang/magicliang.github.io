"""Real QEMU keyboard events: HMP sendkey -> PS/2 -> IRQ1 -> foreground."""
import os
import pathlib
import shlex
import socket
import subprocess
import time

root = pathlib.Path('build')
sockpath = str(root.resolve() / 'keyboard-monitor.sock')
pathlib.Path(sockpath).unlink(missing_ok=True)
log = open(root / 'keyboard-qemu.txt', 'w')
q = subprocess.Popen([os.environ['QEMU'], *shlex.split(os.environ['QEMU_COMMON']),
    '-drive', 'file=build/mbr.img,format=raw,if=ide', '-display', 'none',
    '-serial', 'file:build/keyboard-serial.txt', '-monitor', f'unix:{sockpath},server=on,wait=off',
    '-S', '-gdb', 'tcp:127.0.0.1:1234'], stdout=log, stderr=log)

def gdb(commands, label):
    script = ('set architecture i386\nset tcp connect-timeout 5\nset tcp auto-retry on\n'
              'file build/kernel.elf\ntarget remote 127.0.0.1:1234\n' + commands + '\ndetach\n')
    (root / 'keyboard.gdb').write_text(script)
    try:
        r = subprocess.run(['gdb-multiarch', '-q', '-nx', '-batch', '-x', 'build/keyboard.gdb'],
                       text=True, capture_output=True, timeout=15)
    except subprocess.TimeoutExpired as exc:
        (root / f'keyboard-{label}.txt').write_bytes((exc.stdout or b'') + (exc.stderr or b''))
        raise
    (root / f'keyboard-{label}.txt').write_text(r.stdout + r.stderr)
    assert r.returncode == 0, r.stdout + r.stderr

def wait_for(predicate):
    for _ in range(100):
        if predicate(): return
        time.sleep(.05)
    raise AssertionError('timeout')

def serial(): return (root / 'keyboard-serial.txt').read_text()

try:
    gdb('hbreak keyboard_ready\ncontinue\npython\nassert int(gdb.parse_and_eval("$eflags")) & 0x200 == 0\nend\ndelete breakpoints', 'ready')
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect(sockpath)
    s.settimeout(2)
    def hmp(command):
        s.sendall((command+'\n').encode())
        data = b''
        while b'(qemu)' not in data:
            data += s.recv(8192)
        return data.decode(errors='replace')
    s.recv(8192)
    import threading
    injection = threading.Timer(.2, lambda: hmp('sendkey shift 20'))
    injection.start()
    gdb('\nhbreak *keyboard_irq\ncontinue\npython\nimport struct\nf = struct.unpack("<17I", bytes(gdb.selected_inferior().read_memory(int(gdb.parse_and_eval("$ebx")), 68)))\nassert f[12:14] == (33, 0) and f[15] == 8 and f[16] & 0x200\nassert int(gdb.parse_and_eval("$eflags")) & 0x600 == 0\nprint("PASS: hardware IRQ1 unified frame, saved IF=1 and handler IF=DF=0")\nend\ndelete breakpoints', 'frame')
    injection.join()
    time.sleep(.1)  # Let the real Shift release reach the foreground before 'a'.
    def key(name):
        hmp('sendkey '+name+' 20')
        time.sleep(.07)
    for name in ['a','b','backspace','shift-c','caps_lock','d','caps_lock','pause','print','e','ret']:
        key(name)
    wait_for(lambda: 'LINE: aCDe' in serial())
    gdb('python\nassert int(gdb.parse_and_eval("keyboard_irqs")) >= 20\nassert int(gdb.parse_and_eval("keyboard_dropped")) == 0\nend\nset variable keyboard_consumer_paused = 1', 'ordinary')
    for _ in range(45): key('a')
    gdb('python\nassert int(gdb.parse_and_eval("keyboard_dropped")) > 0\nassert int(gdb.parse_and_eval("keyboard_resets")) == 0\nend\nset variable keyboard_consumer_paused = 0\nprintf "DROPPED %u IRQ %u\\n", keyboard_dropped, keyboard_irqs', 'overflow')
    # IRQ1 wakes the paused HLT after debugger clears the flag; all injected keys released.
    key('ret')
    wait_for(lambda: 'OVERFLOW dropped=' in serial())
    for name in ['o','k','ret']: key(name)
    wait_for(lambda: 'LINE: ok' in serial())
    time.sleep(.1)
    registers = hmp('info registers')
    (root / 'keyboard-idle.txt').write_text(registers)
    import re
    assert 'HLT=1' in registers, registers
    assert int(re.search(r'EFL=([0-9a-fA-F]+)', registers).group(1), 16) & 0x200
    gdb('python\nassert int(gdb.parse_and_eval("keyboard_resets")) == 1\nassert int(gdb.parse_and_eval("keyboard_line_length")) == 0\nend\nmonitor info pic\nmonitor screendump build/day09-screen.png -f png', 'recovered')
    assert 'imr=fd isr=00' in (root / 'keyboard-recovered.txt').read_text()
    print('PASS: HMP real IRQ1 editing/Shift/Caps/Pause/PrintScreen, paused-consumer overflow, reset and LINE: ok')
finally:
    q.terminate()
    q.wait(timeout=5)
    log.close()
