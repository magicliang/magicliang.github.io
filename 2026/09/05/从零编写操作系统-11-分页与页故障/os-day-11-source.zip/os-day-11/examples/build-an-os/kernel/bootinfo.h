#ifndef BOOTINFO_H
#define BOOTINFO_H
#include <stdint.h>
#include <stddef.h>
struct bootinfo {
    uint32_t magic;
    uint16_t version, size;
    uint8_t drive, reserved[3];
    uint32_t map;
    uint16_t count, stride;
    uint32_t payload, payload_bytes, video;
    uint16_t columns, rows, pitch;
    uint8_t mode, cell_bytes;
};
_Static_assert(sizeof(struct bootinfo) == 40, "BootInfo v1 size");
_Static_assert(offsetof(struct bootinfo, video) == 28, "BootInfo video offset");
#endif
