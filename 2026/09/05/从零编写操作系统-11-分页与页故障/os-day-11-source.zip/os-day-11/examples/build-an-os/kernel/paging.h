#ifndef PAGING_H
#define PAGING_H
#include "exceptions.h"
void paging_demo(void);
void paging_fault(struct trap_frame *frame, uint32_t address);
void paging_unhandled(void);
#endif
