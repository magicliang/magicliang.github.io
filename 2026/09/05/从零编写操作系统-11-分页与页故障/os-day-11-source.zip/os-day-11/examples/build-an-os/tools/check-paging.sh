#!/bin/sh
set -eu
for variant in normal pagefault; do
    elf=build/kernel.elf disk=build/mbr.img
    if [ "$variant" = pagefault ]; then elf=build/kernel-pagefault.elf; disk=build/mbr-pagefault.img; fi
    "$QEMU" $QEMU_COMMON -drive file="$disk",format=raw,if=ide -display none -serial file:build/paging-$variant-serial.txt -monitor none -S -gdb tcp:127.0.0.1:1234 > build/paging-$variant-qemu.txt 2>&1 &
    pid=$!
    trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
    cat > build/paging.gdb <<GDB
set architecture i386
set tcp connect-timeout 5
set tcp auto-retry on
file $elf
target remote 127.0.0.1:1234
hbreak paging_enabled
continue
python
import gdb, struct
from pathlib import Path
m = gdb.selected_inferior()
v = lambda e: int(gdb.parse_and_eval(e))
u32 = lambda a: struct.unpack('<I', bytes(m.read_memory(a,4)))[0]
pd = v('directory')
assert v('\$cr0') & 0x80010001 == 0x80010001
assert v('\$cr4') & 0xb0 == 0
assert v('\$cr3') == pd and pd % 4096 == 0
assert v('paging_stack_before') == v('paging_stack_after')
assert v('&__stack_bottom') <= v('paging_stack_after') < v('&__stack_top')
for d in range(1024):
    pde = u32(pd + d*4)
    if d < 16:
        assert pde & 7 == 3
        for t in range(1024):
            pte = u32((pde & 0xfffff000) + t*4)
            assert pte & 7 == 3 and pte & 0xfffff000 == (d*1024+t)*4096
    elif d == 256:
        assert pde & 7 == 3 and pde & 0xfffff000 == v('test_table')
    else:
        assert pde == 0
assert all(u32(v('test_table')+t*4) == 0 for t in range(1024))
print('PASS: CR0 PG/WP, CR3 physical, 16384 supervisor RW identity PTEs, same C stack')
end
delete breakpoints
hbreak paging_fault
continue
python
f = gdb.parse_and_eval('*frame')
assert int(f['vector']) == 14 and int(f['error']) == 0
assert int(f['eip']) == v('&paging_read_fault') and v('address') == 0x40000000
assert u32(v('test_table')) == 0 and v('expected_fault') == 1
read_eip = int(f['eip'])
end
delete breakpoints
hbreak *&paging_read_fault
continue
python
assert v('\$eip') == read_eip and v('paging_faults') == 1
assert u32(v('test_table')) & 7 == 3
print('PASS: nonpresent #PF error 0 repaired and same read instruction retried')
end
delete breakpoints
hbreak paging_fault
continue
python
f = gdb.parse_and_eval('*frame')
assert int(f['error']) == 3 and int(f['vector']) == 14
assert int(f['eip']) == v('&paging_write_fault') and v('address') == 0x40000000
assert u32(v('test_table')) & 7 == 1 and v('expected_fault') == 2
write_eip = int(f['eip'])
end
delete breakpoints
hbreak *&paging_write_fault
continue
python
assert v('\$eip') == write_eip and v('paging_faults') == 2
assert u32(v('test_table')) & 7 == 3
print('PASS: WP #PF error 3 repaired and same write instruction retried')
end
delete breakpoints
hbreak paging_demo_done
continue
python
assert v('paging_passed') == 1 and v('paging_faults') == 2
assert v('free_pages') == v('paging_initial_pages') - 18
assert u32(v('test_table')) == 0
allocated = bytes(m.read_memory(v('&allocated'),2048))
assert sum(b.bit_count() for b in allocated) == 18
for d in list(range(16)) + [256]:
    n = (u32(pd+d*4) & 0xfffff000)//4096
    assert allocated[n//8] & (1 << (n%8))
n = pd//4096
assert allocated[n//8] & (1 << (n%8))
text = Path('build/paging-$variant-serial.txt').read_text()
for marker in ['remap A -> B + INVLPG OK','same EIP retry OK','PAGING OK retained tables=18']:
    assert marker in text
print('PASS: remap A/B values, released data pages, 18 live table pages; free=%d CR3=%#x' % (v('free_pages'),pd))
end
delete breakpoints
GDB
    if [ "$variant" = normal ]; then
        cat >> build/paging.gdb <<'GDB'
monitor screendump build/day11-screen.png -f png
hbreak keyboard_ready
continue
printf "PASS: paged kernel reaches keyboard_ready\n"
GDB
    else
        cat >> build/paging.gdb <<'GDB'
hbreak *panic_halt
continue
python
assert bytes(m.read_memory(v('$eip'),1)) == b'\xf4'
assert v('$cr2') == 0x40000000
assert 'unhandled page fault' in Path('build/paging-pagefault-serial.txt').read_text()
print('PASS: unexpected page fault reaches panic HLT instruction')
end
monitor screendump build/day11-pagefault.png -f png
GDB
    fi
    printf 'disconnect\n' >> build/paging.gdb
    timeout -k 5 120 gdb-multiarch -q -nx -batch -x build/paging.gdb > build/paging-$variant-gdb.txt 2>&1
    cat build/paging-$variant-gdb.txt
    kill "$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
    trap - EXIT HUP INT TERM
done
{ sleep 4; printf 'info registers\nquit\n'; } | "$QEMU" $QEMU_COMMON -drive file=build/mbr-pagefault.img,format=raw,if=ide -display none -serial file:build/paging-halted-serial.txt -monitor stdio > build/paging-halted-registers.txt 2>&1
grep -q 'HLT=1' build/paging-halted-registers.txt
grep -q 'unhandled page fault' build/paging-halted-serial.txt
printf 'PASS: unhandled page fault actual HLT=1\n'
