bits 32
section .text
global paging_read, paging_read_fault, paging_write, paging_write_fault
paging_read:
paging_read_fault:
    mov eax, [0x40000000]
    ret
paging_write:
paging_write_fault:
    mov dword [0x40000000], 0xfeedface
    ret
