#include "paging.h"
#include "memory.h"
#include "runtime.h"
#include "console.h"
#define PRESENT 1u
#define WRITE 2u
#define TEST_VA 0x40000000u
static uint32_t *directory;
static uint32_t *test_table;
static uint32_t repair_page;
static unsigned expected_fault;
volatile unsigned paging_faults;
volatile unsigned paging_passed;
volatile uint32_t paging_initial_pages, paging_stack_before, paging_stack_after;
extern char paging_read_fault, paging_write_fault;
extern uint32_t paging_read(void);
extern void paging_write(void);

static void invalidate(uint32_t address)
{
    __asm__ volatile("invlpg (%0)" : : "r"(address) : "memory");
}
static void test_map(uint32_t physical, uint32_t flags)
{
    KASSERT(!(physical & 4095));
    test_table[0] = physical | flags;
    invalidate(TEST_VA);
}
void paging_enabled(void) { __asm__ volatile("" : : : "memory"); }
void paging_demo_done(void) { __asm__ volatile("" : : : "memory"); }

/* Called only before enabling PG. Roll back every owned page on exhaustion. */
static int build_tables(void)
{
    uint32_t pages[18];
    unsigned count = 0;
    while (count < 18) {
        uint32_t page = page_alloc();
        if (!page) {
            while (count) KASSERT(page_free(pages[--count]));
            return 0;
        }
        pages[count++] = page;
        memset((void *)page, 0, PAGE_BYTES);
    }
    directory = (uint32_t *)pages[0];
    for (unsigned d = 0; d < 16; ++d) {
        uint32_t *table = (uint32_t *)pages[d + 1];
        for (unsigned t = 0; t < 1024; ++t)
            table[t] = ((d * 1024 + t) * PAGE_BYTES) | PRESENT | WRITE;
        directory[d] = pages[d + 1] | PRESENT | WRITE;
    }
    test_table = (uint32_t *)pages[17];
    directory[TEST_VA >> 22] = pages[17] | PRESENT | WRITE;
    return 1;
}
void paging_fault(struct trap_frame *frame, uint32_t address)
{
    kprintf("PAGE FAULT CR2=%p error=%x EIP=%p\n", (void *)address,
            frame->error, (void *)frame->eip);
    if (address == TEST_VA && frame->cs == 8 &&
        ((expected_fault == 1 && frame->error == 0 &&
          frame->eip == (uint32_t)&paging_read_fault && !test_table[0]) ||
         (expected_fault == 2 && frame->error == 3 &&
          frame->eip == (uint32_t)&paging_write_fault &&
          (test_table[0] & 7) == PRESENT))) {
        test_map(repair_page, PRESENT | WRITE);
        expected_fault = 0;
        ++paging_faults;
        return; /* IRETD retries the original instruction, with its original EIP. */
    }
    kprintf("vector=%u cs=%x flags=%x eax=%x ebx=%x ecx=%x edx=%x\n",
            frame->vector, frame->cs, frame->eflags, frame->eax, frame->ebx,
            frame->ecx, frame->edx);
    kprintf("esi=%x edi=%x ebp=%x pushad_esp=%x ds=%x es=%x fs=%x gs=%x\n",
            frame->esi, frame->edi, frame->ebp, frame->pushad_esp,
            frame->ds, frame->es, frame->fs, frame->gs);
    panic(__FILE__, __LINE__, "unhandled page fault");
}
void paging_demo(void)
{
    console_init();
    kprintf("D11 paging 10/10/12 supervisor RW identity 64 MiB\n");
    paging_initial_pages = page_free_count();
    KASSERT(build_tables());
    __asm__ volatile("mov %%esp,%0" : "=m"(paging_stack_before));
    uint32_t cr0, cr4;
    __asm__ volatile("mov %%cr4,%0" : "=r"(cr4));
    cr4 &= ~((1u << 4) | (1u << 5) | (1u << 7)); /* PSE/PAE/PGE off. */
    __asm__ volatile("mov %0,%%cr4; mov %1,%%cr3" : : "r"(cr4), "r"(directory) : "memory");
    __asm__ volatile("mov %%cr0,%0" : "=r"(cr0));
    cr0 |= 0x80010000u; /* PG and WP; retain PE. */
    __asm__ volatile("mov %0,%%cr0" : : "r"(cr0) : "memory");
    __asm__ volatile("mov %%esp,%0" : "=m"(paging_stack_after));
    KASSERT(paging_stack_before == paging_stack_after);
    paging_enabled();
    kprintf("PG+WP enabled CR3=%p same stack=%p\n", directory, (void *)paging_stack_after);
    uint32_t a = page_alloc(), b = page_alloc();
    KASSERT(a && b && a != b);
    *(volatile uint32_t *)a = 0x12345678;
    *(volatile uint32_t *)b = 0x87654321;
    test_map(a, PRESENT | WRITE);
    KASSERT(paging_read() == 0x12345678);
    test_map(b, PRESENT | WRITE);
    KASSERT(paging_read() == 0x87654321);
    kprintf("remap A -> B + INVLPG OK\n");
    repair_page = b;
    test_map(0, 0);
    expected_fault = 1;
    KASSERT(paging_read() == 0x87654321 && !expected_fault && paging_faults == 1);
    kprintf("nonpresent read repaired; same EIP retry OK\n");
    test_map(b, PRESENT);
    expected_fault = 2;
    paging_write();
    KASSERT(!expected_fault && paging_faults == 2 && *(volatile uint32_t *)b == 0xfeedface);
    kprintf("WP readonly write repaired; same EIP retry OK\n");
    test_map(0, 0);
    KASSERT(page_free(a) && page_free(b));
    KASSERT(page_free_count() == paging_initial_pages - 18);
    kprintf("PAGING OK retained tables=18 free=%u\n", page_free_count());
    paging_passed = 1;
    paging_demo_done();
}
void paging_unhandled(void)
{
    (void)paging_read(); /* No expectation armed: deliberately panic. */
}
