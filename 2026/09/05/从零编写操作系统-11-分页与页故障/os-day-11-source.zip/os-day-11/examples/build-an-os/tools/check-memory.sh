#!/bin/sh
set -eu
"$QEMU" $QEMU_COMMON -drive file=build/mbr.img,format=raw,if=ide -display none -serial file:build/memory-serial.txt -monitor none -S -gdb tcp:127.0.0.1:1234 > build/memory-qemu.txt 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT HUP INT TERM
cat > build/memory.gdb <<'GDB'
set architecture i386
set tcp connect-timeout 5
set tcp auto-retry on
file build/kernel.elf
target remote 127.0.0.1:1234
hbreak memory_demo_done
continue
python
from pathlib import Path
assert int(gdb.parse_and_eval('memory_test_passed')) == 1
initial = int(gdb.parse_and_eval('memory_initial_pages'))
assert initial == int(gdb.parse_and_eval('memory_exhausted_pages')) == int(gdb.parse_and_eval('free_pages'))
assert int(gdb.parse_and_eval('$cr0')) & 0x80000001 == 1
m = gdb.selected_inferior()
eligible = bytes(m.read_memory(int(gdb.parse_and_eval('&eligible')), 2048))
allocated = bytes(m.read_memory(int(gdb.parse_and_eval('&allocated')), 2048))
assert sum(x.bit_count() for x in eligible) == initial and not any(allocated)
end = int(gdb.parse_and_eval('&__kernel_end'))
assert end <= 0x110000
for n in range((end + 4095) // 4096):
    assert not eligible[n // 8] & (1 << (n % 8))
text = Path('build/memory-serial.txt').read_text()
for marker in ['SYNTHETIC map overlap/round/high/overflow OK', 'allocator preserves IF=0 and IF=1 OK', 'unique/write/free OK; invalid/double free rejected', 'one-page reuse OK', 'all-page patterns OK', 'MEMORY OK']:
    assert marker in text, marker
vga = bytes(m.read_memory(0xb8000, 4000))
Path('build/memory-vga.txt').write_text('\n'.join(vga[i:i+160:2].decode('ascii').rstrip() for i in range(0,4000,160)))
print('PASS: guest allocation, exhaustion, patterns, invalid free, recovered bitmaps; pages=%d end=%#x' % (initial,end))
end
monitor screendump build/day10-screen.png -f png
delete breakpoints
hbreak keyboard_ready
continue
printf "PASS: memory demo returns to keyboard_ready\n"
detach
GDB
timeout 120 gdb-multiarch -q -nx -batch -x build/memory.gdb > build/memory-gdb.txt 2>&1
cat build/memory-gdb.txt
