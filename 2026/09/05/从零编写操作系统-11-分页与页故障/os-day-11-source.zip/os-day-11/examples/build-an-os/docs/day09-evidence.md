# 第 09 篇：PS/2 IRQ1 与输入队列实测

日期：2026-09-05。基线 `ba236d1c7b51167a1b4cbc11a7dd1ae3b1f33366` 加本篇变更。使用现有 `localhost/build-an-os:day01`，没有重建镜像、安装依赖或停止 Podman VM。固定平台仍为 QEMU 7.2.22、pc-i440fx-7.2、qemu32、TCG、单 CPU、64 MiB 与 SeaBIOS；不代表物理硬件兼容性。

## 重跑与产物

仓库根目录运行：

```sh
podman run --rm -v "$PWD/examples/build-an-os:/work" -w /work localhost/build-an-os:day01 make check-keyboard
podman run --rm -v "$PWD/examples/build-an-os:/work" -w /work localhost/build-an-os:day01 make check
```

`check-keyboard.sh` 使用已有 cc 编译同一个 `keyboard_parse` 的宿主检查，再用已有 GDB 内嵌 Python 驱动 QEMU、HMP 与子 GDB；镜像没有独立 python3。`build/keyboard-parser.txt`、`keyboard-ready.txt`、`keyboard-frame.txt`、`keyboard-ordinary.txt`、`keyboard-overflow.txt`、`keyboard-idle.txt`、`keyboard-recovered.txt`、`keyboard-serial.txt` 和 `day09-screen.png` 为本次验证产物。完整累计日志为 `build/day09-allchecks.txt`。

累计 `make check` 最终退出码 0；保护模式、C 入口/runtime、console/UART/panic、异常、timer、keyboard 和早期 ELF/启动/读盘故障检查全部通过。`git diff --check` 无错误。

## 本次实测

硬件 frame 为 vector=33、error=0、CS=8、保存 IF=1；C 入口 IF=DF=0。帧探针在 GDB continue 后通过外部 HMP 发 Shift，等待真实 release 再输入普通字符，避免停机期间发送输入造成不送达。空闲时通过 HMP（非 GDB 断点）观察 `EFL=00000246`、`HLT=1`，对应 IF=1 的实际休眠。恢复后 PIC 为 `imr=fd isr=00`。

暂停消费时观察 dropped=27、IRQ=126；用于唤醒恢复的 Enter 可能再增加一个丢弃，截图为 dropped=28。计数受事件调度影响，检查要求大于零而不硬编码 27/28。截图显示 `LINE: aCDe`、溢出提示、`LINE: ok`，已人工查看实际 VGA 像素。正常 payload 7748 字节，低于 65536 字节装载限制。

## 设备与输入合同

沿用 PIC 重映射和异常公共 frame，只增加 vector 33。初始化 IF=0 且 IRQ1 屏蔽，关闭键盘/鼠标接口、有限清旧输出、读取控制器模式、清 translation 与设备 IRQ 位，再启用键盘接口。F5、F0、01、F4 各有界检查 ACK；最后设置控制器 IRQ1 并写主 IMR=0xfd。未知回复/超时失败，保留屏蔽状态，不尝试无限重发；运行中不混发键盘命令。

IRQ1 每次最多读一个字节，检查状态、入队或累加丢弃计数，然后主 PIC EOI；不解析、不打印。64 槽队列可容纳 63 字节。单核前台在 CLI 临界区出队与检查空，空时同一 asm 的 `sti; hlt` 保证检查到休眠之间不丢唤醒。前台解析和输出时允许 IRQ。

宿主数组检查覆盖普通 make/break、两侧 Shift 各自释放、Caps 重复按下与 Shift XOR、标点、Pause、PrintScreen 和后续普通字符。E0 后消费一个字节并忽略（含伪 Shift）；Pause 匹配五字节尾，失配丢弃已匹配部分并重处理当前字节一次。截断 E0 可能吞掉随后一个普通字节，损坏字节流不保证自动重建完整状态。

真实 HMP 键序列 `a b backspace shift-c caps_lock d caps_lock pause print e ret` 必须得到 `LINE: aCDe`。IRQ 计数来自设备中断，不是宿主直接调用解析器。暂停 consumer 后仍注入 45 次 `a` 的按下/释放，必须观察 dropped>0、尚无 reset；恢复消费并以 Enter 唤醒后，必须提示溢出并清队列、解析器、修饰键和当前行，随后 `o k ret` 得到 `LINE: ok` 且 reset=1。所有注入键按时释放后才重试；清状态不能重建仍物理按住的键。

正常行最多 63 字符，满后忽略新字符；退格与回车仍工作。VGA 退格擦除一个单元格，UART 仅输出 BS，终端是否视觉擦除取决于终端。本篇不提供命令执行、扩展方向键、键盘 LED 同步、USB 或多核队列。

早期 console/timer/exception 检查仅将正常结束检查点移到 `console_demo_done`，该点在启动键盘之前，原 VGA/串口/IF/PIC 断言保留。IDT 存在断言增加 vector 33，34–255 仍要求 non-present。第 08 篇诊断镜像保持独立，时钟漏 EOI、mask/resume 和原有加载故障继续执行。

## 固定来源

实现前逐段读取 QEMU 官方 v7.2.0 [pckbd.c](https://github.com/qemu/qemu/blob/v7.2.0/hw/input/pckbd.c) 的控制器命令/状态/模式/IRQ 更新，以及 [ps2.c](https://github.com/qemu/qemu/blob/v7.2.0/hw/input/ps2.c) 的 set1、Pause/PrintScreen、扫描码选择与 ACK 实现。来源版本与实际运行补丁版本分开记录。

## 交互终端复核

同日 root 在真实 `make run` curses 窗口输入 `a b Backspace c Enter`，屏幕显示 `LINE: ac`；随后切到 QEMU monitor 执行 quit，正常退出码为 0。该路径不经宿主解析器测试函数。
