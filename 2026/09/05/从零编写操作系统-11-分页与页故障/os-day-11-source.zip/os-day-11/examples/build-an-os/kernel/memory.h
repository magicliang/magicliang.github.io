#ifndef MEMORY_H
#define MEMORY_H
#include <stdint.h>
#include "bootinfo.h"
#define PAGE_BYTES 4096u
#define MEMORY_CAP (64u * 1024u * 1024u)
/* Physical addresses; 0 means exhaustion. Free returns 0 on invalid ownership. */
uint32_t page_alloc(void);
int page_free(uint32_t address);
uint32_t page_free_count(void);
void memory_demo(const struct bootinfo *info);
#endif
