# 第 10 篇实测记录

实验日期：2026-09-05。沿用第 01 篇既有 Podman 镜像、QEMU 7.2.22、SeaBIOS 1.16.2、qemu32、单 CPU、64 MiB RAM。无新工具安装、镜像重建或分页支持。

## 实现边界

- `kernel/bootinfo.h` 提取原有 40 字节 BootInfo 定义，偏移断言不变；stage2 仍把旧式 20 字节记录补成 attributes=1 的 24 字节记录。
- `kernel/memory.c` 的 eligible/allocated 位图各 2048 字节，放在 BSS，随完整内核运行区和 16 KiB 栈保留。没有为耗尽测试添加 64 KiB PFN 数组。
- 先在 64 位检查零长度和加法溢出，再截取 `[0,64 MiB)`。零长度或溢出令初始化失败，由内核断言停机。合成测试在真实初始化之前调用同一私有算法；不支持带活动分配的重新初始化。
- 可用区向内取整；非 type=1、未知类型或 attributes!=1 的范围向外保留。第二遍保留覆盖第一遍释放，顺序无关。低于 1 MiB 全部保留是实验策略；内核保留到链接器 `__kernel_end`，不是文件末尾。
- 首次适配从最低候选页扫描，分配后前移、释放后降低候选；对外仍返回最低空闲页。每个分配/释放/计数快照保存恢复 IF；无中断处理程序输出，无多核同步保证。新页未清零。

[ACPI 6.5 第 15 章](https://uefi.org/specs/ACPI/6.5/15_System_Address_Map_Interfaces.html) 将扩展属性 bit 0 定义为 reserved/must be 1，不称其为 Enabled。这里只接受 attributes=1 是保守兼容策略；不把不兼容描述符释放为 RAM。未知和保留区覆盖优先也是本实现策略，不声称 ACPI 规定了重叠记录排序。

## 可复现检查

在本实验目录运行：

```sh
podman run --rm -v "$PWD:/work" -w /work localhost/build-an-os:day01 make check
```

只跑本篇：

```sh
podman run --rm -v "$PWD:/work" -w /work localhost/build-an-os:day01 make check-memory
```

`check-memory` 启动真实客体并停在 `memory_demo_done`：从客体读取两个位图、空闲数、CR0、链接边界和 VGA；截图后继续到 `keyboard_ready`。串口和 GDB 不依赖宿主模拟 allocator 返回值。

合成图覆盖：未对齐可用区、跨两页的两字节保留区、不兼容属性、未知类型、保留覆盖的记录顺序互换、4 GiB 以上地址、64 MiB 边界截取、64 位加法溢出和零长度。它们是客体内合成测试，不是 SeaBIOS 真的返回过异常图。

真实固件图为 6 项；分配两个不同页面写不同值；未对齐地址、页零、内核地址、cap 外地址、double free 均返回失败且不改变计数。检查 IF=0 和 IF=1 调用后状态恢复。耗尽所有页，逐页写入全部 1024 个 uint32_t 的地址相关模式；耗尽返回 0，释放一页再分配恰好取回该页，再次耗尽；逐页验证模式后全部释放，计数回到初值。

产物：`build/memory-serial.txt`、`build/memory-gdb.txt`、`build/memory-vga.txt`、`build/day10-screen.png`。截图取自客体 VGA，在键盘界面清屏之前。

## 验证状态

客体实际返回 6 个 E820 项，初始与最终空闲页数均为 16087，耗尽分配数为 16087，`__kernel_end=0x108d70`（运行占用 36208 字节，小于 65536 字节上限）。`make check` 完整通过：保护模式、内核/BSS、串口/VGA、异常、时钟、真实键盘、物理页和旧读盘/损坏镜像故障回归全部通过；新检查回到键盘入口。首次全量回归发现无提示的首次适配重复扫描导致旧检查的 2 秒采样仍处在耗尽循环，增加最低候选位置后原检查不变通过。测试仅覆盖上述固定模拟机；没有真实硬件、超过 64 MiB、多核并发、DMA 或分页 E2E 结论。
