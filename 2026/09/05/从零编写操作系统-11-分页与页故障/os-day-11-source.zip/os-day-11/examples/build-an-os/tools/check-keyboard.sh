#!/bin/sh
set -eu
cc -std=c11 -Wall -Wextra -Werror -D KEYBOARD_HOST_TEST kernel/keyboard.c tools/check-keyboard-parser.c -o build/check-keyboard-parser
build/check-keyboard-parser > build/keyboard-parser.txt
gdb-multiarch -q -nx -batch -ex "python exec(compile(open('tools/check-keyboard.py').read(), 'tools/check-keyboard.py', 'exec'))"
