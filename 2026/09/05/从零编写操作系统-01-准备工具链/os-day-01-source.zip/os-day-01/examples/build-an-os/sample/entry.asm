bits 32
section .text
global _start
extern add_one
_start:
    mov esp, 0x90000
    sub esp, 12
    push dword 7
    call add_one
    add esp, 16
    cli
.halt:
    hlt
    jmp .halt
section .note.GNU-stack noalloc noexec nowrite progbits
