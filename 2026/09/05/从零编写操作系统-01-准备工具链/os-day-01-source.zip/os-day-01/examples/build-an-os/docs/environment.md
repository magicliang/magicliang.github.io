# 第 01 篇环境基线

实验日期：2026-09-05。执行环境为 ARM macOS → Podman Linux VM → Debian 12 aarch64 容器。目标为 ELF32/i386，QEMU 客体为单 CPU 的 x86 PC；不是 ARM 操作系统。

## 版本

| 工具或对象 | 固定实验值 |
|---|---|
| GNU GCC / target | 13.2.0 / i686-elf |
| GNU Binutils | 2.42 |
| NASM | 2.16.01，Debian 包 2.16.01-1 |
| QEMU | 7.2.22，Debian 包 1:7.2+dfsg-7+deb12u18+b3 |
| GDB | gdb-multiarch 13.1，Debian 包 13.1-3 |
| GNU Make | 4.3，Debian 包 4.3-4.1 |
| SeaBIOS | 1.16.2，Debian 包 1.16.2-1 |
| machine / CPU / accelerator | pc-i440fx-7.2 / qemu32 / tcg |
| CPU / RAM | 1 / 64 MiB |
| BIOS 文件 | /usr/share/seabios/bios-256k.bin |
| BIOS SHA-256 | 2da2018c7555e50b660a84a273a14a79cb87b9070fe6a90e9f151a53e357f7e6 |

Debian 基础镜像 `docker.io/library/debian:bookworm-slim` 本次解析到的清单摘要：

```text
sha256:6bd27d44e6c32a66bbd72d7cb2b76a8ae3497ec2e5274a81abd1b37f6013fa1f
```

GNU 源码从官方站点下载：

- https://ftp.gnu.org/gnu/binutils/binutils-2.42.tar.xz
- https://ftp.gnu.org/gnu/gcc/gcc-13.2.0/gcc-13.2.0.tar.xz

完整包清单见 `packages.txt`，下载文件摘要见 `source-sha256.txt`。摘要记录的是本次实际使用的文件，不声称进行了发布者签名认证。

## 复现边界

Dockerfile 固定基础镜像摘要及 GNU 源码版本；Debian APT 仓库仍为滚动更新的 bookworm 仓库，不是历史快照。重建可能取得不同的系统包，所以 `make check` 同时核对关键工具版本与 BIOS 摘要。发生版本漂移时，应先对照本记录，不能沿用旧的实验通过结论。

只验证了这个 ARM Linux 容器环境。macOS 原生工具链、Windows/WSL 和 x86 Linux 宿主未在本批实测。没有发布预构建容器镜像；读者需要从 Dockerfile 构建。

GCC 构建止于 `all-gcc` / `install-gcc`，没有目标 libc 或目标 libgcc。简单整数样例不需要运行库。第 05–06 篇需要按实际生成的未解析符号补齐内核运行时。

## 资料

核查日期均为 2026-09-05。滚动工具手册只用于解释命令；运行版本以上表和实际输出为准。

- [GCC freestanding](https://gcc.gnu.org/onlinedocs/gcc/Standards.html)
- [GNU ld 链接脚本](https://sourceware.org/binutils/docs/ld/Scripts.html)
- [NASM 输出格式](https://www.nasm.us/doc/nasm09.html)
- [QEMU PC 模型](https://www.qemu.org/docs/master/system/i386/pc.html)
- [QEMU GDB 接口](https://www.qemu.org/docs/master/system/gdb.html)
- [QEMU 7.2 x86 复位实现](https://github.com/qemu/qemu/blob/v7.2.0/target/i386/cpu.c#L5731-L5749)

QEMU 7.2 的复位实现设置 CS 可见值 0xf000、隐藏基址 0xffff0000、EIP 0xfff0。相加后的线性地址为 0xfffffff0；复位时分页关闭。这个入口属于固件，不是自制 ELF 的入口。
