# 第 01 篇实验记录

日期：2026-09-05。环境见 [environment.md](environment.md)。这是工具链与固件调试实验，尚未启动自制内核。

## 手动空盘启动

在 Linux 容器中，以 Makefile 声明的机器、CPU、BIOS 和空磁盘参数运行 QEMU `-nographic`。终端实际显示：

```text
SeaBIOS (version 1.16.2-debian-1.16.2-1)
Booting from Hard Disk...
Boot failed: not a bootable disk

Booting from Floppy...
Boot failed: could not read the boot disk

Booting from DVD/CD...
Boot failed: Could not read from CDROM (code 0003)
No bootable device.
```

按 `Ctrl-a`，再按 `x`，实际返回 `QEMU: Terminated` 并回到容器 Shell。这里没有自制引导扇区，启动失败是本篇的正确结果。

## 手动 GDB 单步

同一配置加 `-S -gdb tcp:127.0.0.1:1234`，GDB 在同一容器内连接。省略终端颜色控制码后的实际输出：

```text
(gdb) info registers eip cs
eip            0xfff0              0xfff0
cs             0xf000              61440
(gdb) x/16bx 0xfffffff0
0xfffffff0: 0xea 0x5b 0xe0 0x00 0xf0 0x30 0x36 0x2f
0xfffffff8: 0x32 0x33 0x2f 0x39 0x39 0x00 0xfc 0x00
(gdb) stepi
0x0000e05b in ?? ()
(gdb) info registers eip cs
eip            0xe05b              0xe05b
cs             0xf000              61440
```

未指定可执行文件时，GDB 提示没有可执行文件并显示 `??`，不影响读取寄存器和单步固件。`monitor quit` 后执行 `quit`，确认退出活动会话，远程连接关闭并返回 Shell。

## 完整自动检查

执行最终 Dockerfile 构建的 `localhost/build-an-os:day01` 镜像，运行 `make -B check`，退出码为 0。随后运行 `make help`、`make run`，再次观察上述空盘失败与按键退出。

```text
mkdir -p build
touch build/.dir
nasm -f elf32 -g -F dwarf sample/entry.asm -o build/entry.o
i686-elf-gcc -std=c11 -ffreestanding -O0 -g -Wall -Wextra -Werror -fno-pie -fno-stack-protector -fno-asynchronous-unwind-tables -c sample/demo.c -o build/demo.o
i686-elf-ld -z noexecstack -T sample/linker.ld build/entry.o build/demo.o -o build/sample.elf
dd if=/dev/zero of=build/blank.img bs=512 count=2048 status=none
QEMU='qemu-system-i386' QEMU_FLAGS='-machine pc-i440fx-7.2 -accel tcg -cpu qemu32 -smp 1 -m 64M -bios /usr/share/seabios/bios-256k.bin -drive file=build/blank.img,format=raw,if=ide -boot order=c,strict=on -nic none -no-reboot' sh tools/check.sh
PASS: ELF32/i386 entry, disassembly, missing-symbol rejection, blank disk, QEMU reset and single-step
```

ELF 文件头实测摘要：

```text
Class:                             ELF32
Machine:                           Intel 80386
Entry point address:               0x100000
```

自动调试输出：

```text
The target architecture is set to "i386".
warning: No executable has been specified and target does not support
determining executable automatically.  Try using the "file" command.
0x0000fff0 in ?? ()
RESET_EIP=0xfff0
0xfffffff0:	0xea	0x5b	0xe0	0x00	0xf0	0x30	0x36	0x2f
0xfffffff8:	0x32	0x33	0x2f	0x39	0x39	0x00	0xfc	0x00
0x0000e05b in ?? ()
STEP_EIP=0xe05b
```

反汇编：

```text
build/sample.elf:     file format elf32-i386


Disassembly of section .text:

00100000 <_start>:
  100000:	bc 00 00 09 00       	mov    esp,0x90000
  100005:	83 ec 0c             	sub    esp,0xc
  100008:	6a 07                	push   0x7
  10000a:	e8 07 00 00 00       	call   100016 <add_one>
  10000f:	83 c4 10             	add    esp,0x10
  100012:	fa                   	cli

00100013 <_start.halt>:
  100013:	f4                   	hlt
  100014:	eb fd                	jmp    100013 <_start.halt>

00100016 <add_one>:
  100016:	55                   	push   ebp
  100017:	89 e5                	mov    ebp,esp
  100019:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
  10001c:	83 c0 01             	add    eax,0x1
  10001f:	5d                   	pop    ebp
  100020:	c3                   	ret
```
