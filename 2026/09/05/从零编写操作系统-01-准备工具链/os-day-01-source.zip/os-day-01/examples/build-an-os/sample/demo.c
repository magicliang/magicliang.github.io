unsigned add_one(unsigned value)
{
    return value + 1;
}
