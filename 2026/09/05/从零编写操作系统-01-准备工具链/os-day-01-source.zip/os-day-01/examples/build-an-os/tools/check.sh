#!/bin/sh
set -eu
export LC_ALL=C
mkdir -p build
test "$(i686-elf-gcc -dumpmachine)" = i686-elf
test "$(i686-elf-gcc -dumpfullversion)" = 13.2.0
i686-elf-ld --version | grep -q '2.42'
nasm -v | grep -q '2.16.01'
"$QEMU" --version | grep -q 'version 7.2.22 '
gdb-multiarch --version | grep -q '13.1'
printf '%s  %s\n' 2da2018c7555e50b660a84a273a14a79cb87b9070fe6a90e9f151a53e357f7e6 /usr/share/seabios/bios-256k.bin | sha256sum -c - > build/bios-check.txt
i686-elf-readelf -h build/sample.elf > build/elf-header.txt
i686-elf-objdump -dr -Mintel build/sample.elf > build/disassembly.txt
grep -q 'Class:.*ELF32' build/elf-header.txt
grep -q 'Machine:.*Intel 80386' build/elf-header.txt
grep -q 'Entry point address:.*0x100000' build/elf-header.txt
grep -q '<add_one>:' build/disassembly.txt
if i686-elf-ld -T sample/linker.ld build/entry.o -o build/missing.elf > build/missing-symbol.txt 2>&1; then
    echo 'FAIL: missing add_one unexpectedly linked' >&2
    exit 1
fi
grep -q 'undefined reference.*add_one' build/missing-symbol.txt
test "$(wc -c < build/blank.img)" -eq 1048576
test "$(od -An -tx1 -j510 -N2 build/blank.img | tr -d ' \n')" = 0000
"$QEMU" $QEMU_FLAGS -display none -serial none -monitor none -S -gdb tcp:127.0.0.1:1234 > build/qemu-debug.txt 2>&1 &
qemu_pid=$!
trap 'kill "$qemu_pid" 2>/dev/null || true; wait "$qemu_pid" 2>/dev/null || true' EXIT HUP INT TERM
# GDB retries the connection while QEMU starts; timeout bounds startup failures.
timeout 15 gdb-multiarch -q -nx -batch -ex 'set architecture i386' -ex 'set tcp connect-timeout 5' -ex 'set tcp auto-retry on' -ex 'target remote 127.0.0.1:1234' -ex 'printf "RESET_EIP=%#x\n", $eip' -ex 'x/16bx 0xfffffff0' -ex 'stepi' -ex 'printf "STEP_EIP=%#x\n", $eip' -ex 'disconnect' > build/gdb.txt 2>&1
kill -0 "$qemu_pid"
grep -q 'RESET_EIP=0xfff0' build/gdb.txt
grep -q 'STEP_EIP=' build/gdb.txt
if grep -q 'STEP_EIP=0xfff0' build/gdb.txt; then
    echo 'FAIL: CPU did not advance' >&2
    exit 1
fi
printf '%s\n' 'PASS: ELF32/i386 entry, disassembly, missing-symbol rejection, blank disk, QEMU reset and single-step'
