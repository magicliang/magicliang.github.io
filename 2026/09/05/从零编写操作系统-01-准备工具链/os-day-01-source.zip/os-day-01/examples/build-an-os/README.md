# 从零编写操作系统：第 01 篇配套实验

本版只验证编译链和固件调试。`sample.elf` 是 ELF32/i386 链接样例；`blank.img` 是独立的全零磁盘，BIOS 不会加载该 ELF。尚未实现引导扇区或内核。

## 运行

宿主需要已启动的 Podman Linux 环境。以下命令从本目录执行：

```sh
podman build -t localhost/build-an-os:day01 .
podman run --rm -it -v "$PWD:/work" -w /work localhost/build-an-os:day01 sh
```

在容器中执行：

```sh
make help
make build
make check
make run
```

`make run` 的空盘启动失败是本篇预期结果；按 `Ctrl-a`，再按 `x` 退出 QEMU。

## 手动调试

仍在同一容器中执行：

```sh
make debug &
gdb-multiarch -q
```

GDB 命令：

```text
set architecture i386
target remote 127.0.0.1:1234
info registers eip cs
x/16bx 0xfffffff0
stepi
info registers eip cs
monitor quit
quit
```

`monitor quit` 终止 QEMU 后远程连接会关闭。若 `quit` 询问是否退出活动会话，输入 `y`。不要让手动调试实例与 `make check` 同时占用容器的 1234 端口。调试端口不映射到宿主。

## 文件与证据

- `sample/`：C 函数、NASM 汇编入口与链接脚本。
- `tools/check.sh`：ELF 格式、入口、反汇编、缺失符号失败、空盘与 QEMU/GDB 单步检查。
- [环境记录](docs/environment.md)：实测版本、来源和复现边界。
- [实验记录](docs/day01-evidence.md)：实际输出与手动场景。

生成文件全部进入忽略的 `build/`。交叉 GCC 当前只构建 C 编译器，不包含目标 libc 或 libgcc；本例不需要这些库，后续内核运行时另行补齐。
